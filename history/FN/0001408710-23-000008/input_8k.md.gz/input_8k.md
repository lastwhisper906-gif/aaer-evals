# FN 8-K — 0001408710-23-000006 filed 2023-02-06

## item codes, every 8-K on or before 2023-02-07

- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2023-02-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-23-000006:8k_2_02:1]
EX-99.1
2
fn-20230206xex991q223.htm
EX-99.1

[0001408710-23-000006:8k_2_02:2]
Document

[0001408710-23-000006:8k_2_02:3]
Exhibit 99.1

[0001408710-23-000006:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2023 Financial Results

[0001408710-23-000006:8k_2_02:5]
•Record Second Quarter Revenue of $668.7 Million Exceeds Guidance

[0001408710-23-000006:8k_2_02:6]
•Strong Execution Drives Record GAAP and Non-GAAP Operating Margins

[0001408710-23-000006:8k_2_02:7]
BANGKOK, Thailand – February 6, 2023 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 30, 2022.

[0001408710-23-000006:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We delivered strong second quarter results with revenue that exceeded our guidance range, and record operating margins. We continue to effectively manage through a dynamic supply environment with component availability improving for some products, but tightening for others. Positive longer-term supply and demand trends, combined with our demonstrated track record of solid execution gives us confidence that we can continue to deliver strong financial results.”

[0001408710-23-000006:8k_2_02:9]
Second Quarter Fiscal Year 2023 Financial Highlights

[0001408710-23-000006:8k_2_02:10]
GAAP Results

[0001408710-23-000006:8k_2_02:11]
•Revenue for the second quarter of fiscal year 2023 was $668.7 million, compared to $566.6 million for the second quarter of fiscal year 2022.

[0001408710-23-000006:8k_2_02:12]
•GAAP net income for the second quarter of fiscal year 2023 was $63.2 million, compared to $48.9 million for the second quarter of fiscal year 2022.

[0001408710-23-000006:8k_2_02:13]
•GAAP net income per diluted share for the second quarter of fiscal year 2023 was $1.71, compared to $1.30 for the second quarter of fiscal year 2022.

[0001408710-23-000006:8k_2_02:14]
Non-GAAP Results

[0001408710-23-000006:8k_2_02:15]
•Non-GAAP net income for the second quarter of fiscal year 2023 was $70.0 million, compared to $56.2 million for the second quarter of fiscal year 2022.

[0001408710-23-000006:8k_2_02:16]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2023 was $1.90, compared to $1.50 for the second quarter of fiscal year 2022.

[0001408710-23-000006:8k_2_02:17]
Business Outlook

[0001408710-23-000006:8k_2_02:18]
Based on information available as of February 6, 2023, Fabrinet is issuing guidance for its third fiscal quarter ending March 31, 2023, as follows:

[0001408710-23-000006:8k_2_02:19]
•Fabrinet expects third quarter revenue to be in the range of $640 million to $660 million.

[0001408710-23-000006:8k_2_02:20]
•GAAP net income per diluted share is expected to be in the range of $1.59 to $1.66, based on approximately 37.0 million fully diluted shares outstanding.

[0001408710-23-000006:8k_2_02:21]
•Non-GAAP net income per diluted share is expected to be in the range of $1.86 to $1.93, based on approximately 37.0 million fully diluted shares outstanding.

[0001408710-23-000006:8k_2_02:22]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-23-000006:8k_2_02:23]
Conference Call Information

[0001408710-23-000006:8k_2_02:24]
| What: |  | Fabrinet Second Quarter Fiscal Year 2023 Financial Results Call |
| When: |  | February 6, 2023 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-23-000006:8k_2_02:25]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-23-000006:8k_2_02:26]
About Fabrinet

[0001408710-23-000006:8k_2_02:27]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the

[0001408710-23-000006:8k_2_02:28]
United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-23-000006:8k_2_02:29]
Forward-Looking Statements

[0001408710-23-000006:8k_2_02:30]
Use of Non-GAAP Financials

[0001408710-23-000006:8k_2_02:31]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; other expenses in relation to reduction in workforce; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-23-000006:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-23-000006:8k_2_02:33]
Investor Contact:

[0001408710-23-000006:8k_2_02:34]
Garo Toomajanian

[0001408710-23-000006:8k_2_02:35]
ir@fabrinet.com

[0001408710-23-000006:8k_2_02:36]
FABRINET

[0001408710-23-000006:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-23-000006:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | December 30,2022 |  | June 24,2022 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 250,829 |  |  | $ | 197,996 |  |
| Short-term restricted cash | — |  |  | 220 |  |
| Short-term investments | 276,778 |  |  | 280,157 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $1,521 and $1,271, respectively | 520,024 |  |  | 439,330 |  |
| Contract assets | 13,578 |  |  | 13,464 |  |
| Inventories | 536,536 |  |  | 557,145 |  |
| Prepaid expenses | 9,483 |  |  | 11,626 |  |
| Other current assets | 40,543 |  |  | 25,233 |  |
| Total current assets | 1,647,771 |  |  | 1,525,171 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | — |  |  | 149 |  |
| Property, plant and equipment, net | 302,282 |  |  | 292,277 |  |
| Intangibles, net | 3,319 |  |  | 3,508 |  |
| Operating right-of-use assets | 2,805 |  |  | 4,084 |  |
| Deferred tax assets | 11,212 |  |  | 9,800 |  |
| Other non-current assets | 635 |  |  | 652 |  |
| Total non-current assets | 320,253 |  |  | 310,470 |  |
| Total Assets | $ | 1,968,024 |  |  | $ | 1,835,641 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 438,475 |  |  | 439,684 |  |
| Fixed assets payable | 18,920 |  |  | 9,085 |  |
| Contract liabilities | 3,636 |  |  | 1,982 |  |
| Operating lease liabilities, current portion | 2,005 |  |  | 2,319 |  |
| Income tax payable | 2,470 |  |  | 2,898 |  |
| Accrued payroll, bonus and related expenses | 21,940 |  |  | 20,374 |  |
| Accrued expenses | 22,465 |  |  | 24,758 |  |
| Other payables | 27,528 |  |  | 25,231 |  |
| Total current liabilities | 549,595 |  |  | 538,487 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 6,078 |  |  | 15,202 |  |
| Deferred tax liability | 5,934 |  |  | 6,001 |  |
| Operating lease liability, non-current portion | 476 |  |  | 1,476 |  |
| Severance liabilities | 20,335 |  |  | 18,384 |  |
| Other non-current liabilities | 1,475 |  |  | 2,409 |  |
| Total non-current liabilities | 34,298 |  |  | 43,472 |  |
| Total Liabilities | 583,893 |  |  | 581,959 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 30, 2022 and June 24, 2022) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,251,581 shares and 39,048,700 shares issued at December 30, 2022 and June 24, 2022, respectively; and 36,590,939 shares and 36,436,683 shares outstanding at December 30, 2022 and June 24, 2022, respectively) | 393 |  |  | 390 |  |
| Additional paid-in capital | 194,366 |  |  | 196,667 |  |
| Less: Treasury shares (2,660,642 shares and 2,612,017 shares as of December 30, 2022 and June 24, 2022, respectively) | (152,362) |  |  | (147,258) |  |
| Accumulated other comprehensive income (loss) | (2,714) |  |  | (12,793) |  |
| Retained earnings | 1,344,448 |  |  | 1,216,676 |  |
| Total Shareholders’ Equity | 1,384,131 |  |  | 1,253,682 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,968,024 |  |  | $ | 1,835,641 |  |

[0001408710-23-000006:8k_2_02:39]
FABRINET

[0001408710-23-000006:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-23-000006:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Revenues | $ | 668,656 |  |  | $ | 566,633 |  |  | $ | 1,324,085 |  |  | $ | 1,109,955 |  |
| Cost of revenues | (583,441) |  |  | (497,262) |  |  | (1,156,114) |  |  | (976,987) |  |
| Gross profit | 85,215 |  |  | 69,371 |  |  | 167,971 |  |  | 132,968 |  |
| Selling, general and administrative expenses | (18,930) |  |  | (17,791) |  |  | (39,495) |  |  | (38,378) |  |
| Expenses related to reduction in workforce | — |  |  | (135) |  |  | — |  |  | (135) |  |
| Operating income | 66,285 |  |  | 51,445 |  |  | 128,476 |  |  | 94,455 |  |
| Interest income | 2,334 |  |  | 295 |  |  | 3,893 |  |  | 1,056 |  |
| Interest expense | (389) |  |  | (238) |  |  | (780) |  |  | (274) |  |
| Foreign exchange gain (loss), net | (3,904) |  |  | (364) |  |  | (1,819) |  |  | 1,408 |  |
| Other income (expense), net | (68) |  |  | (1,055) |  |  | (209) |  |  | (1,315) |  |
| Income before income taxes | 64,258 |  |  | 50,083 |  |  | 129,561 |  |  | 95,330 |  |
| Income tax expense | (1,101) |  |  | (1,204) |  |  | (1,789) |  |  | (1,800) |  |
| Net income | 63,157 |  |  | 48,879 |  |  | 127,772 |  |  | 93,530 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 1,183 |  |  | (947) |  |  | (278) |  |  | (1,160) |  |
| Change in net unrealized gain (loss) on derivative instruments | 11,188 |  |  | 3,294 |  |  | 9,970 |  |  | 2,077 |  |
| Change in net retirement benefits plan – prior service cost | 57 |  |  | 126 |  |  | 225 |  |  | 324 |  |
| Change in foreign currency translation adjustment | (84) |  |  | — |  |  | 162 |  |  | (164) |  |
| Total other comprehensive income (loss), net of tax | 12,344 |  |  | 2,473 |  |  | 10,079 |  |  | 1,077 |  |
| Net comprehensive income | $ | 75,501 |  |  | $ | 51,352 |  |  | $ | 137,851 |  |  | $ | 94,607 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.73 |  |  | $ | 1.32 |  |  | $ | 3.50 |  |  | $ | 2.53 |  |
| Diluted | $ | 1.71 |  |  | $ | 1.30 |  |  | $ | 3.47 |  |  | $ | 2.50 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,589 |  |  | 37,017 |  |  | 36,558 |  |  | 36,947 |  |
| Diluted | 36,939 |  |  | 37,552 |  |  | 36,848 |  |  | 37,440 |  |

[0001408710-23-000006:8k_2_02:42]
FABRINET

[0001408710-23-000006:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-23-000006:8k_2_02:44]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 30,2022 |  | December 24,2021 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 127,772 |  |  | $ | 93,530 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 21,596 |  |  | 19,114 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment | (337) |  |  | (135) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | 92 |  |  | (13) |  |
| Amortization of discount (premium) of short-term investment | 565 |  |  | 2,079 |  |
| Amortization of deferred debt issuance costs | 16 |  |  | 16 |  |
| (Reversal of) allowance for doubtful accounts | 251 |  |  | (30) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 3,086 |  |  | (673) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (346) |  |  | (513) |  |
| Share-based compensation | 14,498 |  |  | 15,978 |  |
| Deferred income tax | (1,338) |  |  | (986) |  |
| Other non-cash expenses | (321) |  |  | 268 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (79,831) |  |  | (48,046) |  |
| Contract assets | (114) |  |  | (1,270) |  |
| Inventories | 20,475 |  |  | (62,740) |  |
| Other current assets and non-current assets | (11,946) |  |  | (5,568) |  |
| Trade accounts payable | (4,176) |  |  | 44,078 |  |
| Contract liabilities | 1,654 |  |  | 214 |  |
| Income tax payable | (577) |  |  | (1,323) |  |
| Severance liabilities | 1,269 |  |  | 1,708 |  |
| Other current liabilities and non-current liabilities | 12,812 |  |  | 1,880 |  |
| Net cash provided by operating activities | 105,100 |  |  | 57,568 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (74,482) |  |  | (78,786) |  |
| Proceeds from sales of short-term investments | 30,000 |  |  | 19,463 |  |
| Proceeds from maturities of short-term investments | 46,925 |  |  | 57,721 |  |
| Purchase of property, plant and equipment | (23,643) |  |  | (51,917) |  |
| Purchase of intangibles | (412) |  |  | (446) |  |
| Proceeds from disposal of property, plant and equipment | 32 |  |  | 188 |  |
| Net cash used in investing activities | (21,580) |  |  | (53,777) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (9,140) |  |  | (6,094) |  |
| Repayment of finance lease liability | (5) |  |  | — |  |
| Repurchase of ordinary shares | (5,104) |  |  | (4,198) |  |
| Withholding tax related to net share settlement of restricted share units | (16,796) |  |  | (19,481) |  |
| Net cash used in financing activities | (31,045) |  |  | (29,773) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 52,475 |  |  | $ | (25,982) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 198,365 |  |  | $ | 303,123 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 52,475 |  |  | (25,982) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (11) |  |  | (296) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 250,829 |  |  | $ | 276,845 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 18,920 |  |  | $ | 28,740 |  |

[0001408710-23-000006:8k_2_02:45]
FABRINET

[0001408710-23-000006:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-23-000006:8k_2_02:47]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the condensed consolidated balance sheets that sum to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001408710-23-000006:8k_2_02:48]
|  | As of |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Cash and cash equivalents | $ | 250,829 |  |  | $ | 276,531 |  |
| Restricted cash | — |  |  | 314 |  |
| Cash, cash equivalents and restricted cash | $ | 250,829 |  |  | $ | 276,845 |  |

[0001408710-23-000006:8k_2_02:49]
FABRINET

[0001408710-23-000006:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000006:8k_2_02:51]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 63,157 |  |  | $ | 1.71 |  |  | $ | 48,879 |  |  | $ | 1.30 |  |  | $ | 127,772 |  |  | $ | 3.47 |  |  | $ | 93,530 |  |  | $ | 2.50 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,660 |  |  | 0.05 |  |  | 1,421 |  |  | 0.04 |  |  | 3,576 |  |  | 0.10 |  |  | 3,396 |  |  | 0.09 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 92 |  |  | 0.00 |  |
| Total related to gross profit | 1,660 |  |  | 0.05 |  |  | 1,421 |  |  | 0.04 |  |  | 3,576 |  |  | 0.10 |  |  | 3,488 |  |  | 0.09 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,115 |  |  | 0.14 |  |  | 5,265 |  |  | 0.14 |  |  | 10,922 |  |  | 0.29 |  |  | 12,582 |  |  | 0.33 |  |
| Amortization of intangibles | 71 |  |  | 0.00 |  |  | 108 |  |  | 0.00 |  |  | 154 |  |  | 0.01 |  |  | 227 |  |  | 0.01 |  |
| Severance payment and others | — |  |  | — |  |  | 355 |  |  | 0.01 |  |  | — |  |  | — |  |  | 355 |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses | 5,186 |  |  | 0.14 |  |  | 5,728 |  |  | 0.15 |  |  | 11,076 |  |  | 0.30 |  |  | 13,164 |  |  | 0.35 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | — |  |  | — |  |  | 135 |  |  | 0.01 |  |  | — |  |  | — |  |  | 135 |  |  | 0.01 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |
| Total related to other income and expense | 8 |  |  | 0.00 |  |  | 143 |  |  | 0.01 |  |  | 16 |  |  | 0.00 |  |  | 151 |  |  | 0.01 |  |
| Total related to net income & EPS | 6,854 |  |  | 0.19 |  |  | 7,292 |  |  | 0.20 |  |  | 14,668 |  |  | 0.40 |  |  | 16,803 |  |  | 0.45 |  |
| Non-GAAP measures | $ | 70,011 |  |  | $ | 1.90 |  |  | $ | 56,171 |  |  | $ | 1.50 |  |  | $ | 142,440 |  |  | $ | 3.87 |  |  | $ | 110,333 |  |  | $ | 2.95 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,939 |  |  |  |  | 37,552 |  |  |  |  | 36,848 |  |  |  |  | 37,440 |  |
| Non-GAAP diluted shares |  |  | 36,939 |  |  |  |  | 37,552 |  |  |  |  | 36,848 |  |  |  |  | 37,440 |  |

[0001408710-23-000006:8k_2_02:52]
FABRINET

[0001408710-23-000006:8k_2_02:53]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-23-000006:8k_2_02:54]
| (in thousands) |  | Three Months Ended |  | Six Months Ended |
|  |  | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Net cash provided by operating activities |  | $ | 44,466 |  |  | $ | 20,657 |  |  | $ | 105,100 |  |  | $ | 57,568 |  |
| Less: Purchase of property, plant and equipment |  | (13,385) |  |  | (19,395) |  |  | (23,643) |  |  | (51,917) |  |
| Non-GAAP free cash flow |  | $ | 31,081 |  |  | $ | 1,262 |  |  | $ | 81,457 |  |  | $ | 5,651 |  |

[0001408710-23-000006:8k_2_02:55]
FABRINET

[0001408710-23-000006:8k_2_02:56]
GUIDANCE FOR QUARTER ENDING MARCH 31, 2023

[0001408710-23-000006:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000006:8k_2_02:58]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.59 to $1.66 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Related to other income and expense: |  |
| Other expenses in relation to reduction in workforce | 0.09 |
| Total related to other income and expense | 0.09 |
| Total related to net income & EPS | 0.27 |
| Non-GAAP net income per diluted share | $1.86 to $1.93 |
