# FN note change history — 0001408710-22-000060 → 0001408710-23-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-02-07):
[0001408710-23-000008:note_history:1]
As of December 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.5 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively.

- changed (2023-02-07):
[0001408710-23-000008:note_history:2]
As of June 24, 2022, there was an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. This bank guarantee was released in December 2022. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.
  (was, 2022-11-08, similarity 0.6493):
[0001408710-22-000060:note_history:2]
As of September 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.4 million and $1.4 million, or Thai baht 53.0 million and 50.2 million, respectively, and an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

- changed (2023-02-07):
[0001408710-23-000008:note_history:3]
As of December 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.16 billion.
  (was, 2022-11-08, similarity 0.9774):
[0001408710-22-000060:note_history:3]
As of September 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.39 billion.

- changed (2023-02-07):
[0001408710-23-000008:note_history:4]
As of December 30, 2022, the Company had total capital expenditure commitments to third parties of $27.7 million.
  (was, 2022-11-08, similarity 0.9761):
[0001408710-22-000060:note_history:4]
As of September 30, 2022, the Company had total capital expenditure commitments to third parties of $25.9 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:5]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 30, 2022 and for the three and six months ended December 30, 2022 and December 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.
  (was, 2022-11-08, similarity 0.9669):
[0001408710-22-000060:note_history:5]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 30, 2022 and for the three months ended September 30, 2022 and September 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

- changed (2023-02-07):
[0001408710-23-000008:note_history:6]
The results for the three and six months ended December 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.
  (was, 2022-11-08, similarity 0.9537):
[0001408710-22-000060:note_history:6]
The results for the three months ended September 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.

- changed (2023-02-07):
[0001408710-23-000008:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 30, 2022 and December 24, 2021 consisted of 13 weeks. The six months ended  December 30, 2022 and December 24, 2021 consisted of 27 weeks and 26 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.
  (was, 2022-11-08, similarity 0.7599):
[0001408710-22-000060:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 30, 2022 and September 24, 2021 consisted of 14 weeks and 13 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:8]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 18,281 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (15) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 15,202 |  |
  (was, 2022-11-08, similarity 0.9959):
[0001408710-22-000060:note_history:8]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 21,327 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (22) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 15,202 |  |

- changed (2023-02-07):
[0001408710-23-000008:note_history:9]
The movements of long-term borrowings for the six months ended December 30, 2022 and December 24, 2021 were as follows:
  (was, 2022-11-08, similarity 0.9189):
[0001408710-22-000060:note_history:9]
The movements of long-term borrowings for the three months ended September 30, 2022 and September 24, 2021 were as follows:

- changed (2023-02-07):
[0001408710-23-000008:note_history:10]
|  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (9,140) |  |  | (6,094) |  |
| Closing balance | $ | 18,281 |  |  | $ | 33,515 |  |
  (was, 2022-11-08, similarity 0.8883):
[0001408710-22-000060:note_history:10]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (6,094) |  |  | (3,047) |  |
| Closing balance | $ | 21,327 |  |  | $ | 36,562 |  |

- changed (2023-02-07):
[0001408710-23-000008:note_history:11]
As of December 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-11-08, similarity 0.9754):
[0001408710-22-000060:note_history:11]
As of September 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-02-07):
[0001408710-23-000008:note_history:12]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 6,094 |  |
| 2024 | 12,187 |  |
| Total | $ | 18,281 |  |
  (was, 2022-11-08, similarity 0.9128):
[0001408710-22-000060:note_history:12]
| (in thousands) |  |
| 2023 (remaining nine months) | $ | 6,093 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 21,327 |  |

- added (2023-02-07):
[0001408710-23-000008:note_history:13]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan

- added (2023-02-07):
[0001408710-23-000008:note_history:14]
in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 30, 2022, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

- changed (2023-02-07):
[0001408710-23-000008:note_history:15]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2022-11-08, similarity 0.9967):
[0001408710-22-000060:note_history:15]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2023-02-07):
[0001408710-23-000008:note_history:16]
As of December 30, 2022, there was $18.3 million outstanding under the term loan.
  (was, 2022-11-08, similarity 0.9655):
[0001408710-22-000060:note_history:16]
As of September 30, 2022, there was $21.3 million outstanding under the term loan.

- removed (2023-02-07):
[0001408710-22-000060:note_history:17]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 30, 2022, the Company recorded $0.6 million of interest expense in connection with this term loan, including the impact from interest rate swaps.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:18]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 30, 2022 and June 24, 2022:
  (was, 2022-11-08, similarity 0.9829):
[0001408710-22-000060:note_history:18]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 30, 2022 and June 24, 2022:

- changed (2023-02-07):
[0001408710-23-000008:note_history:19]
|  | December 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 102,598 |  |  | $ | 102,106 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 180,476 |  |  | 174,672 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 283,074 |  |  | $ | 276,778 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |
  (was, 2022-11-08, similarity 0.9884):
[0001408710-22-000060:note_history:19]
|  | September 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 87,907 |  |  | $ | 87,038 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 164,105 |  |  | 157,498 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 252,012 |  |  | $ | 244,536 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:20]
The movements of long-term borrowings for the six months ended December 30, 2022 and December 24, 2021 were as follows:
  (was, 2022-11-08, similarity 0.9189):
[0001408710-22-000060:note_history:20]
The movements of long-term borrowings for the three months ended September 30, 2022 and September 24, 2021 were as follows:

- changed (2023-02-07):
[0001408710-23-000008:note_history:21]
|  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (9,140) |  |  | (6,094) |  |
| Closing balance | $ | 18,281 |  |  | $ | 33,515 |  |
  (was, 2022-11-08, similarity 0.8883):
[0001408710-22-000060:note_history:21]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (6,094) |  |  | (3,047) |  |
| Closing balance | $ | 21,327 |  |  | $ | 36,562 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:22]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 18,281 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (15) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 15,202 |  |
  (was, 2022-11-08, similarity 0.9959):
[0001408710-22-000060:note_history:22]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 21,327 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (22) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 15,202 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:23]
As of December 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-11-08, similarity 0.9754):
[0001408710-22-000060:note_history:23]
As of September 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-02-07):
[0001408710-23-000008:note_history:24]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 6,094 |  |
| 2024 | 12,187 |  |
| Total | $ | 18,281 |  |
  (was, 2022-11-08, similarity 0.9128):
[0001408710-22-000060:note_history:24]
| (in thousands) |  |
| 2023 (remaining nine months) | $ | 6,093 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 21,327 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:25]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Ireland (2) | 143 |  |  |  |  | 262 |  |  |  |
| Others | 12,717 |  |  |  |  | 24,883 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |
  (was, 2022-11-08, similarity 0.9509):
[0001408710-22-000060:note_history:25]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 345,080 |  |  |  |  | $ | 245,274 |  |  |  |
| Others (1) | 3,624 |  |  |  |  | 1,316 |  |  |  |
| Total revenue in North America | 348,704 |  |  | 53.2 | % |  | 246,590 |  |  | 45.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 80,033 |  |  |  |  | 64,932 |  |  |  |
| Malaysia | 49,324 |  |  |  |  | 51,749 |  |  |  |
| Israel | 37,277 |  |  |  |  | 27,634 |  |  |  |
| Hong Kong | 32,472 |  |  |  |  | 21,031 |  |  |  |
| China | 23,064 |  |  |  |  | 13,635 |  |  |  |
| Thailand | 12,616 |  |  |  |  | 9,759 |  |  |  |
| Japan | 10,348 |  |  |  |  | 14,977 |  |  |  |
| Others | 3,160 |  |  |  |  | 2,466 |  |  |  |
| Total revenue in Asia-Pacific and others | 248,294 |  |  | 37.9 | % |  | 206,183 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,832 |  |  |  |  | 19,578 |  |  |  |
| Germany | 13,314 |  |  |  |  | 8,425 |  |  |  |
| Ireland (2) | 119 |  |  |  |  | 49,484 |  |  |  |
| Others | 12,166 |  |  |  |  | 13,062 |  |  |  |
| Total revenue in Europe | $ | 58,431 |  |  | 8.9 | % |  | $ | 90,549 |  |  | 16.7 | % |
| Total revenue | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |

- added (2023-02-07):
[0001408710-23-000008:note_history:26]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 243,720 |  |  |  |  | $ | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-07):
[0001408710-23-000008:note_history:27]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Ireland (2) | 143 |  |  |  |  | 262 |  |  |  |
| Others | 12,717 |  |  |  |  | 24,883 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |
  (was, 2022-11-08, similarity 0.9509):
[0001408710-22-000060:note_history:27]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 345,080 |  |  |  |  | $ | 245,274 |  |  |  |
| Others (1) | 3,624 |  |  |  |  | 1,316 |  |  |  |
| Total revenue in North America | 348,704 |  |  | 53.2 | % |  | 246,590 |  |  | 45.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 80,033 |  |  |  |  | 64,932 |  |  |  |
| Malaysia | 49,324 |  |  |  |  | 51,749 |  |  |  |
| Israel | 37,277 |  |  |  |  | 27,634 |  |  |  |
| Hong Kong | 32,472 |  |  |  |  | 21,031 |  |  |  |
| China | 23,064 |  |  |  |  | 13,635 |  |  |  |
| Thailand | 12,616 |  |  |  |  | 9,759 |  |  |  |
| Japan | 10,348 |  |  |  |  | 14,977 |  |  |  |
| Others | 3,160 |  |  |  |  | 2,466 |  |  |  |
| Total revenue in Asia-Pacific and others | 248,294 |  |  | 37.9 | % |  | 206,183 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,832 |  |  |  |  | 19,578 |  |  |  |
| Germany | 13,314 |  |  |  |  | 8,425 |  |  |  |
| Ireland (2) | 119 |  |  |  |  | 49,484 |  |  |  |
| Others | 12,166 |  |  |  |  | 13,062 |  |  |  |
| Total revenue in Europe | $ | 58,431 |  |  | 8.9 | % |  | $ | 90,549 |  |  | 16.7 | % |
| Total revenue | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |

- added (2023-02-07):
[0001408710-23-000008:note_history:28]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 243,720 |  |  |  |  | $ | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2023-02-07):
[0001408710-23-000008:note_history:29]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Lasers, sensors and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |
  (was, 2022-11-08, similarity 0.7723):
[0001408710-22-000060:note_history:29]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 497,561 |  |  | 75.9 | % |  | $ | 427,301 |  |  | 78.6 | % |
| Lasers, sensors and other | 157,868 |  |  | 24.1 | % |  | 116,021 |  |  | 21.4 | % |
| Total | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |

- added (2023-02-07):
[0001408710-23-000008:note_history:30]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2023-02-07):
[0001408710-23-000008:note_history:31]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 30, 2022:
  (was, 2022-11-08, similarity 0.955):
[0001408710-22-000060:note_history:31]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 30, 2022:

- changed (2023-02-07):
[0001408710-23-000008:note_history:32]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 31,601 |  |
| Amounts collected or invoiced | (31,487) |  |
| Ending balance, December 30, 2022 | $ | 13,578 |  |
  (was, 2022-11-08, similarity 0.9869):
[0001408710-22-000060:note_history:32]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 15,803 |  |
| Amounts collected or invoiced | (15,047) |  |
| Ending balance, September 30, 2022 | $ | 14,220 |  |

- changed (2023-02-07):
[0001408710-23-000008:note_history:33]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 12,515 |  |
| Revenue recognized | (10,861) |  |
| Ending balance, December 30, 2022 | $ | 3,636 |  |
  (was, 2022-11-08, similarity 0.9833):
[0001408710-22-000060:note_history:33]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 8,411 |  |
| Revenue recognized | (4,045) |  |
| Ending balance, September 30, 2022 | $ | 6,348 |  |
