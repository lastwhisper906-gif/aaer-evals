# FN notes — 0001408710-23-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-23-000008:notes:1]
[same as prior period, unchanged from 0001408710-22-000060:notes:1]

[0001408710-23-000008:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 30, 2022 and for the three and six months ended December 30, 2022 and December 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

[0001408710-23-000008:notes:3]
[same as prior period, unchanged from 0001408710-22-000060:notes:3]

[0001408710-23-000008:notes:4]
The results for the three and six months ended December 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.

[0001408710-23-000008:notes:5]
[same as prior period, unchanged from 0001408710-22-000060:notes:5]

[0001408710-23-000008:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, or based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

[0001408710-23-000008:notes:7]
[same as prior period, unchanged from 0001408710-22-000060:notes:7]

[0001408710-23-000008:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 30, 2022 and December 24, 2021 consisted of 13 weeks. The six months ended  December 30, 2022 and December 24, 2021 consisted of 27 weeks and 26 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.

[0001408710-23-000008:notes:9]
Adoption of New Accounting Standards
In November 2021, the Financial Accounting Standard Board issued Accounting Standards Update ("ASU") 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. The Company adopted this standard in the first quarter of fiscal year 2023 with no material impact on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-23-000008:notes:10]
[same as prior period, unchanged from 0001408710-22-000060:notes:10]

[0001408710-23-000008:notes:11]
[same as prior period, unchanged from 0001408710-22-000060:notes:11]

[0001408710-23-000008:notes:12]
[same as prior period, unchanged from 0001408710-22-000060:notes:12]

[0001408710-23-000008:notes:13]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Ireland (2) | 143 |  |  |  |  | 262 |  |  |  |
| Others | 12,717 |  |  |  |  | 24,883 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

[0001408710-23-000008:notes:14]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 243,720 |  |  |  |  | $ | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

[0001408710-23-000008:notes:15]
[same as prior period, unchanged from 0001408710-22-000060:notes:14]

[0001408710-23-000008:notes:16]
[same as prior period, unchanged from 0001408710-22-000060:notes:15]

[0001408710-23-000008:notes:17]
[same as prior period, unchanged from 0001408710-22-000060:notes:16]

[0001408710-23-000008:notes:18]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Lasers, sensors and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

[0001408710-23-000008:notes:19]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

[0001408710-23-000008:notes:20]
[same as prior period, unchanged from 0001408710-22-000060:notes:18]

[0001408710-23-000008:notes:21]
[same as prior period, unchanged from 0001408710-22-000060:notes:19]

[0001408710-23-000008:notes:22]
[same as prior period, unchanged from 0001408710-22-000060:notes:20]

[0001408710-23-000008:notes:23]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 30, 2022:

[0001408710-23-000008:notes:24]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 31,601 |  |
| Amounts collected or invoiced | (31,487) |  |
| Ending balance, December 30, 2022 | $ | 13,578 |  |

[0001408710-23-000008:notes:25]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 12,515 |  |
| Revenue recognized | (10,861) |  |
| Ending balance, December 30, 2022 | $ | 3,636 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-23-000008:notes:26]
[same as prior period, unchanged from 0001408710-22-000060:notes:24]

[0001408710-23-000008:notes:27]
[same as prior period, unchanged from 0001408710-22-000060:notes:25]

[0001408710-23-000008:notes:28]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Net income attributable to shareholders | $ | 63,157 |  |  | $ | 48,879 |  |  | $ | 127,772 |  |  | $ | 93,530 |  |
| Weighted-average number of ordinary shares outstanding | 36,589 |  |  | 37,017 |  |  | 36,558 |  |  | 36,947 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 350 |  |  | 535 |  |  | 290 |  |  | 493 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,939 |  |  | 37,552 |  |  | 36,848 |  |  | 37,440 |  |
| Basic earnings per ordinary share | $ | 1.73 |  |  | $ | 1.32 |  |  | $ | 3.50 |  |  | $ | 2.53 |  |
| Diluted earnings per ordinary share | $ | 1.71 |  |  | $ | 1.30 |  |  | $ | 3.47 |  |  | $ | 2.50 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-23-000008:notes:29]
[same as prior period, unchanged from 0001408710-22-000060:notes:27]

[0001408710-23-000008:notes:30]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of December 30, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 236,504 |  |  | $ | — |  |  | $ | 236,504 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 14,325 |  |  | — |  |  | 14,325 |  |  | — |  |  | — |  |
| Liquidity funds | 30,127 |  |  | — |  |  | — |  |  | — |  |  | 30,127 |  |
| Corporate debt securities | 242,902 |  |  | (5,991) |  |  | — |  |  | 236,911 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 10,045 |  |  | (305) |  |  | — |  |  | 9,740 |  |  | — |  |
| Total | $ | 533,903 |  |  | $ | (6,296) |  |  | $ | 250,829 |  |  | $ | 246,651 |  |  | $ | 30,127 |  |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 187,630 |  |  | $ | — |  |  | $ | 187,630 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 10,367 |  |  | (1) |  |  | 10,366 |  |  | — |  |  | — |  |
| Liquidity funds | 31,477 |  |  | — |  |  | — |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | 234,689 |  |  | (5,671) |  |  | — |  |  | 229,018 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 20,007 |  |  | (345) |  |  | — |  |  | 19,662 |  |  | — |  |
| Total | $ | 484,170 |  |  | $ | (6,017) |  |  | $ | 197,996 |  |  | $ | 248,680 |  |  | $ | 31,477 |  |

[0001408710-23-000008:notes:31]
[same as prior period, unchanged from 0001408710-22-000060:notes:29]

[0001408710-23-000008:notes:32]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 30, 2022 and June 24, 2022:

[0001408710-23-000008:notes:33]
|  | December 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 102,598 |  |  | $ | 102,106 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 180,476 |  |  | 174,672 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 283,074 |  |  | $ | 276,778 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-23-000008:notes:34]
[same as prior period, unchanged from 0001408710-22-000060:notes:32]

[0001408710-23-000008:notes:35]
[same as prior period, unchanged from 0001408710-22-000060:notes:33]

[0001408710-23-000008:notes:36]
[same as prior period, unchanged from 0001408710-22-000060:notes:34]

[0001408710-23-000008:notes:37]
[same as prior period, unchanged from 0001408710-22-000060:notes:35]

[0001408710-23-000008:notes:38]
[same as prior period, unchanged from 0001408710-22-000060:notes:36]

[0001408710-23-000008:notes:39]
[same as prior period, unchanged from 0001408710-22-000060:notes:37]

[0001408710-23-000008:notes:40]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 30, 2022 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 14,325 |  |  |  | $ | — |  |  | $ | 14,325 |  |
| Liquidity funds | — |  |  | 30,127 |  |  |  | — |  |  | 30,127 |  |
| Corporate debt securities | — |  |  | 236,911 |  |  |  | — |  |  | 236,911 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 9,740 |  |  |  | — |  |  | 9,740 |  |
| Derivative assets – current portion | — |  |  | 5,835 |  | (1) |  | — |  |  | 5,835 |  |
| Derivative assets – non-current portion | — |  |  | 37 |  | (2) |  | — |  |  | 37 |  |
| Total | $ | — |  |  | $ | 296,975 |  |  |  | $ | — |  |  | $ | 296,975 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (764) |  |  |  | $ | — |  |  | $ | (764) |  |
| Total | $ | — |  |  | $ | (764) |  | (3) |  | $ | — |  |  | $ | (764) |  |

[0001408710-23-000008:notes:41]
[same as prior period, unchanged from 0001408710-22-000060:notes:39]

[0001408710-23-000008:notes:42]
(1)Foreign currency forward contracts with an aggregate notional amount of $126.0 million and an interest rate swap agreement with a notional amount of $64.2 million.

[0001408710-23-000008:notes:43]
[same as prior period, unchanged from 0001408710-22-000060:notes:41]

[0001408710-23-000008:notes:44]
(3)Foreign currency forward contracts with an aggregate notional amount of $4.0 million and 0.8 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-23-000008:notes:45]
[same as prior period, unchanged from 0001408710-22-000060:notes:43]

[0001408710-23-000008:notes:46]
[same as prior period, unchanged from 0001408710-22-000060:notes:44]

[0001408710-23-000008:notes:47]
[same as prior period, unchanged from 0001408710-22-000060:notes:45]

[0001408710-23-000008:notes:48]
[same as prior period, unchanged from 0001408710-22-000060:notes:46]

[0001408710-23-000008:notes:49]
[same as prior period, unchanged from 0001408710-22-000060:notes:47]

[0001408710-23-000008:notes:50]
[same as prior period, unchanged from 0001408710-22-000060:notes:48]

[0001408710-23-000008:notes:51]
[same as prior period, unchanged from 0001408710-22-000060:notes:49]

[0001408710-23-000008:notes:52]
[same as prior period, unchanged from 0001408710-22-000060:notes:50]

[0001408710-23-000008:notes:53]
[same as prior period, unchanged from 0001408710-22-000060:notes:51]

[0001408710-23-000008:notes:54]
As of December 30, 2022, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $130.0 million and maturity dates ranging from January 2023 through July 2023 and one outstanding Canadian dollar foreign currency forward contract with an aggregate notional amount of 0.8 million Canadian dollars and a maturity date in March 2023.

[0001408710-23-000008:notes:55]
[same as prior period, unchanged from 0001408710-22-000060:notes:53]

[0001408710-23-000008:notes:56]
As of December 30, 2022, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 30, 2022, the amount in accumulated other comprehensive income (“AOCI”) that is expected to be reclassified into earnings within 12 months was a gain of $4.7 million.

[0001408710-23-000008:notes:57]
[same as prior period, unchanged from 0001408710-22-000060:notes:55]

[0001408710-23-000008:notes:58]
During the three and six months ended December 30, 2022, the Company included an unrealized gain of $4.2 million and $4.0 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000008:notes:59]
During the three and six months ended December 24, 2021, the Company included an unrealized gain of $1.1 million and $0.5 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000008:notes:60]
[same as prior period, unchanged from 0001408710-22-000060:notes:57]

[0001408710-23-000008:notes:61]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of December 30, 2022 and June 24, 2022, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-23-000008:notes:62]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under a credit facility agreement with Bank of America to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-23-000008:notes:63]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 10) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America Credit Facility Agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-23-000008:notes:64]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-23-000008:notes:65]
As of December 30, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $0.1 million.

[0001408710-23-000008:notes:66]
[same as prior period, unchanged from 0001408710-22-000060:notes:64]

[0001408710-23-000008:notes:67]
[same as prior period, unchanged from 0001408710-22-000060:notes:65]

[0001408710-23-000008:notes:68]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) | Financialstatementsline item |  | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | 14,754 |  |  | $ | 3,685 |  |  | $ | 11,762 |  |  | $ | 1,549 |  |
| Interest rate swaps | Othercomprehensiveincome |  | 310 |  |  | 595 |  |  | 826 |  |  | 1,003 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 15,064 |  |  | $ | 4,280 |  |  | $ | 12,588 |  |  | $ | 2,552 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 5,534 |  |  | $ | 2,984 |  |  | $ | 9,328 |  |  | $ | 5,099 |  |
| Foreign currency forward contracts | SG&A |  | 230 |  |  | 124 |  |  | 390 |  |  | 212 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (9,485) |  |  | (3,849) |  |  | (11,990) |  |  | (5,273) |  |
| Interest rate swaps | Interest expense |  | (155) |  |  | (245) |  |  | (346) |  |  | (513) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (3,876) |  |  | $ | (986) |  |  | $ | (2,618) |  |  | $ | (475) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 11,188 |  |  | $ | 3,294 |  |  | $ | 9,970 |  |  | $ | 2,077 |  |

[0001408710-23-000008:notes:69]
[same as prior period, unchanged from 0001408710-22-000060:notes:67]

[0001408710-23-000008:notes:70]
[same as prior period, unchanged from 0001408710-22-000060:notes:68]

[0001408710-23-000008:notes:71]
|  | December 30,2022 |  | June 24,2022 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 683 |  |  | $ | (39) |  |  | $ | — |  |  | $ | (1,561) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 4,725 |  |  | — |  |  | — |  |  | (4,821) |  |
| Interest rate swaps | 464 |  |  | (725) |  |  | 110 |  |  | (1,197) |  |
| Derivatives, gross balances | $ | 5,872 |  |  | $ | (764) |  |  | $ | 110 |  |  | $ | (7,579) |  |

[0001408710-23-000008:notes:72]
[same as prior period, unchanged from 0001408710-22-000060:notes:70]

[0001408710-23-000008:notes:73]
[same as prior period, unchanged from 0001408710-22-000060:notes:71]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-23-000008:notes:74]
[same as prior period, unchanged from 0001408710-22-000060:notes:72]

[0001408710-23-000008:notes:75]
| (in thousands) | As of December 30,2022 |  | As of June 24,2022 |
| Raw materials | $ | 187,005 |  |  | $ | 275,730 |  |
| Work in progress | 294,453 |  |  | 217,638 |  |
| Finished goods | 24,238 |  |  | 15,203 |  |
| Goods in transit | 30,840 |  |  | 48,574 |  |
| Total inventories | $ | 536,536 |  |  | $ | 557,145 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-23-000008:notes:76]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-23-000008:notes:77]
Operating leases

[0001408710-23-000008:notes:78]
As of December 30, 2022, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-23-000008:notes:79]
| (in thousands) |  |  |
| 2023 (remaining six months) | $ | 1,236 |  |  |
| 2024 | 1,297 |  |  |
| 2025 | 49 |  |  |
| Total undiscounted lease payments | 2,582 |  |  |
| Less imputed interest | (101) |  |  |
| Total present value of lease liabilities | $ | 2,481 |  | (1) |

[0001408710-23-000008:notes:80]
(1)Includes current portion of operating lease liabilities of $2.0 million.

[0001408710-23-000008:notes:81]
[same as prior period, unchanged from 0001408710-22-000060:notes:78]

[0001408710-23-000008:notes:82]
Rental expense for long-term leases for the three and six months ended December 30, 2022 was $0.6 million and $1.2 million, respectively, and for the three and six ended December 24, 2021 was $0.7 million and $1.4 million, respectively. Rental expense for short-term leases for the three and six months ended December 30, 2022 and December 24, 2021 was immaterial.

[0001408710-23-000008:notes:83]
[same as prior period, unchanged from 0001408710-22-000060:notes:80]

[0001408710-23-000008:notes:84]
As of December 30, 2022, the Company had one finance lease agreement with a de minimis amount.

[0001408710-23-000008:notes:85]
[same as prior period, unchanged from 0001408710-22-000060:notes:82]

[0001408710-23-000008:notes:86]
|  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Weighted-average remaining lease term (in years) | 1.4 |  | 1.8 |
| Weighted-average discount rate | 3.5 | % |  | 3.4 | % |

[0001408710-23-000008:notes:87]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and six months ended December 30, 2022 and December 24, 2021:

[0001408710-23-000008:notes:88]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 661 |  |  | $ | 709 |  |  | $ | 1,302 |  |  | $ | 1,398 |  |
| Financing cash flows from finance leases | $ | 3 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |
| ROU assets obtained in exchange for lease liabilities | $ | 69 |  |  | $ | — |  |  | $ | 69 |  |  | $ | 38 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-23-000008:notes:89]
[same as prior period, unchanged from 0001408710-22-000060:notes:86]

[0001408710-23-000008:notes:90]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of December 30, 2022 |  |  |  |  |  |  |  |
| Software | $ | 11,046 |  |  | $ | (8,262) |  |  | $ | — |  |  | $ | 2,784 |  |
| Customer relationships | 4,373 |  |  | (3,784) |  |  | (54) |  |  | 535 |  |
| Total intangibles | $ | 15,419 |  |  | $ | (12,046) |  |  | $ | (54) |  |  | $ | 3,319 |  |

[0001408710-23-000008:notes:91]
[same as prior period, unchanged from 0001408710-22-000060:notes:88]

[0001408710-23-000008:notes:92]
The Company recorded amortization expense relating to intangibles of $0.4 million for each of the three months ended December 30, 2022 and December 24, 2021, and $0.8 million for each of the six months ended December 30, 2022 and December 24, 2021.

[0001408710-23-000008:notes:93]
[same as prior period, unchanged from 0001408710-22-000060:notes:90]

[0001408710-23-000008:notes:94]
| (years) | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Software | 3.4 |  | 3.8 |
| Customer relationships | 2.8 |  | 3.1 |
| Total intangibles | 3.5 |  | 3.8 |

[0001408710-23-000008:notes:95]
Based on the carrying amount of intangibles as of December 30, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-23-000008:notes:96]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 666 |  |
| 2024 | 1,201 |  |
| 2025 | 725 |  |
| 2026 | 508 |  |
| 2027 | 192 |  |
| Thereafter | 27 |  |
| Total | $ | 3,319 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-23-000008:notes:97]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-23-000008:notes:98]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 18,281 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (15) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 15,202 |  |

[0001408710-23-000008:notes:99]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-23-000008:notes:100]
The movements of long-term borrowings for the six months ended December 30, 2022 and December 24, 2021 were as follows:

[0001408710-23-000008:notes:101]
|  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (9,140) |  |  | (6,094) |  |
| Closing balance | $ | 18,281 |  |  | $ | 33,515 |  |

[0001408710-23-000008:notes:102]
As of December 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-23-000008:notes:103]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 6,094 |  |
| 2024 | 12,187 |  |
| Total | $ | 18,281 |  |

[0001408710-23-000008:notes:104]
Credit facility agreements:

[0001408710-23-000008:notes:105]
Bank of Ayudhya Public Company Limited

[0001408710-23-000008:notes:106]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-23-000008:notes:107]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-23-000008:notes:108]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan

[0001408710-23-000008:notes:109]
in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 30, 2022, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-23-000008:notes:110]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-23-000008:notes:111]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-23-000008:notes:112]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-23-000008:notes:113]
As of December 30, 2022, there was $18.3 million outstanding under the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-23-000008:notes:114]
Income taxes
As of December 30, 2022 and June 24, 2022, the liability for uncertain tax positions including accrued interest and penalties was $0.8 million and $1.6 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the expiration of statutes of limitations with respect to these positions.

[0001408710-23-000008:notes:115]
[same as prior period, unchanged from 0001408710-22-000060:notes:111]

[0001408710-23-000008:notes:116]
The effective tax rate for the Company for the three months ended December 30, 2022 and December 24, 2021 was 1.7% and 2.4%, respectively, of net income. The decrease was primarily due to an increase in income not subject to tax during the second quarter of fiscal year 2023 as compared to the same period in fiscal year 2022.

[0001408710-23-000008:notes:117]
The effective tax rate for the Company for the six months ended December 30, 2022 and December 24, 2021 was 1.4% and 1.9%, respectively, of net income. The decrease was primarily due to an increase in income not subject to tax during the first half of fiscal year 2023 as compared to the same period in fiscal year 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-23-000008:notes:118]
[same as prior period, unchanged from 0001408710-22-000060:notes:113]

[0001408710-23-000008:notes:119]
[same as prior period, unchanged from 0001408710-22-000060:notes:114]

[0001408710-23-000008:notes:120]
The effect of recording share-based compensation expense for the three and six months ended December 30, 2022 and December 24, 2021 was as follows:

[0001408710-23-000008:notes:121]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,999 |  |  | $ | 3,671 |  |  | $ | 8,900 |  |  | $ | 8,595 |  |
| Performance share units | 2,776 |  |  | 3,015 |  |  | 5,598 |  |  | 7,383 |  |
| Total share-based compensation expense | 6,775 |  |  | 6,686 |  |  | 14,498 |  |  | 15,978 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,775 |  |  | $ | 6,686 |  |  | $ | 14,498 |  |  | $ | 15,978 |  |

[0001408710-23-000008:notes:122]
[same as prior period, unchanged from 0001408710-22-000060:notes:117]

[0001408710-23-000008:notes:123]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Cost of revenue | $ | 1,660 |  |  | $ | 1,421 |  |  | $ | 3,576 |  |  | $ | 3,396 |  |
| Selling, general and administrative expense | 5,115 |  |  | 5,265 |  |  | 10,922 |  |  | 12,582 |  |
| Total share-based compensation expense | $ | 6,775 |  |  | $ | 6,686 |  |  | $ | 14,498 |  |  | $ | 15,978 |  |

[0001408710-23-000008:notes:124]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 30, 2022 and December 24, 2021.

[0001408710-23-000008:notes:125]
[same as prior period, unchanged from 0001408710-22-000060:notes:120]

[0001408710-23-000008:notes:126]
[same as prior period, unchanged from 0001408710-22-000060:notes:121]

[0001408710-23-000008:notes:127]
As of December 30, 2022, there were 362,057 restricted share units outstanding, 204,016 performance share units outstanding and 1,963,486 ordinary shares available for future grant under the 2020 Plan.

[0001408710-23-000008:notes:128]
As of December 30, 2022, there were 41,996 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-23-000008:notes:129]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of December 30, 2022, there were no awards outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-23-000008:notes:130]
[same as prior period, unchanged from 0001408710-22-000060:notes:125]

[0001408710-23-000008:notes:131]
[same as prior period, unchanged from 0001408710-22-000060:notes:126]

[0001408710-23-000008:notes:132]
[same as prior period, unchanged from 0001408710-22-000060:notes:127]

[0001408710-23-000008:notes:133]
[same as prior period, unchanged from 0001408710-22-000060:notes:128]

[0001408710-23-000008:notes:134]
[same as prior period, unchanged from 0001408710-22-000060:notes:129]

[0001408710-23-000008:notes:135]
[same as prior period, unchanged from 0001408710-22-000060:notes:130]

[0001408710-23-000008:notes:136]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 148,830 |  |  | $ | 119.14 |  |
| Vested | (189,375) |  |  | $ | 64.23 |  |
| Forfeited | (15,028) |  |  | $ | 89.86 |  |
| Balance as of December 30, 2022 | 404,053 |  |  | $ | 95.91 |  |

[0001408710-23-000008:notes:137]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 154,893 |  |  | $ | 102.70 |  |
| Vested | (271,396) |  |  | $ | 50.74 |  |
| Forfeited | (18,101) |  |  | $ | 68.49 |  |
| Balance as of December 24, 2021 | 507,271 |  |  | $ | 72.29 |  |

[0001408710-23-000008:notes:138]
[same as prior period, unchanged from 0001408710-22-000060:notes:133]

[0001408710-23-000008:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | $ | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 30, 2022 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-23-000008:notes:140]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Vested | (190,213) |  |  | 48.65 |  |
| Forfeited | (52,097) |  |  | $ | 48.65 |  |
| Balance as of December 24, 2021 | 295,550 |  |  | $ | 81.55 |  |

[0001408710-23-000008:notes:141]
[same as prior period, unchanged from 0001408710-22-000060:notes:136]

[0001408710-23-000008:notes:142]
As of December 30, 2022, there was $18.7 million and $12.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 and 1.3 years, respectively.

[0001408710-23-000008:notes:143]
For the six months ended December 30, 2022 and December 24, 2021, the Company withheld an aggregate of 165,502 shares and 201,658 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the six months ended December 30, 2022 and December 24, 2021, the Company then remitted cash of $16.8 million and $19.5 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-23-000008:notes:144]
[same as prior period, unchanged from 0001408710-22-000060:notes:138]

[0001408710-23-000008:notes:145]
[same as prior period, unchanged from 0001408710-22-000060:notes:139]

[0001408710-23-000008:notes:146]
For the three and six months ended December 30, 2022, Fabrinet issued 6,034 and 202,881 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000008:notes:147]
For the three and six months ended December 24, 2021, Fabrinet issued 8,153 and 259,951 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000008:notes:148]
[same as prior period, unchanged from 0001408710-22-000060:notes:142]

[0001408710-23-000008:notes:149]
[same as prior period, unchanged from 0001408710-22-000060:notes:143]

[0001408710-23-000008:notes:150]
[same as prior period, unchanged from 0001408710-22-000060:notes:144]

[0001408710-23-000008:notes:151]
During the six months ended December 30, 2022, the Company repurchased 48,625 shares under the program at an average price per share (excluding other direct costs) of $104.94 totaling $5.1 million. As of December 30, 2022, the Company had a remaining authorization to repurchase up to $94.9 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-23-000008:notes:152]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 30, 2022 and December 24, 2021 were as follows:

[0001408710-23-000008:notes:153]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income before reclassification adjustment | (371) |  |  | 12,588 |  |  | — |  |  | 162 |  |  | 12,379 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 93 |  |  | (2,618) |  |  | 225 |  |  | — |  |  | (2,300) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (278) |  |  | $ | 9,970 |  |  | $ | 225 |  |  | $ | 162 |  |  | $ | 10,079 |  |
| Balance as of December 30, 2022 | $ | (6,296) |  |  | $ | 4,888 |  |  | $ | (578) |  |  | $ | (728) |  |  | $ | (2,714) |  |

[0001408710-23-000008:notes:154]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income before reclassification adjustment | (1,173) |  |  | 2,552 |  |  | — |  |  | (164) |  |  | 1,215 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 13 |  |  | (475) |  |  | 324 |  |  | — |  |  | (138) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (1,160) |  |  | $ | 2,077 |  |  | $ | 324 |  |  | $ | (164) |  |  | $ | 1,077 |  |
| Balance as of December 24, 2021 | $ | (852) |  |  | $ | (2,427) |  |  | $ | (1,101) |  |  | $ | (809) |  |  | $ | (5,189) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-23-000008:notes:155]
Commitments and contingencies
Bank guarantees

[0001408710-23-000008:notes:156]
As of December 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.5 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively.

[0001408710-23-000008:notes:157]
As of June 24, 2022, there was an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. This bank guarantee was released in December 2022. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-23-000008:notes:158]
Purchase obligations

[0001408710-23-000008:notes:159]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-23-000008:notes:160]
As of December 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.16 billion.

[0001408710-23-000008:notes:161]
Capital expenditures

[0001408710-23-000008:notes:162]
As of December 30, 2022, the Company had total capital expenditure commitments to third parties of $27.7 million.

[0001408710-23-000008:notes:163]
Indemnification of directors and officers

[0001408710-23-000008:notes:164]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-23-000008:notes:165]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-23-000008:notes:166]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of December 30, 2022, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-23-000008:notes:167]
[same as prior period, unchanged from 0001408710-22-000060:notes:160]

[0001408710-23-000008:notes:168]
[same as prior period, unchanged from 0001408710-22-000060:notes:161]

[0001408710-23-000008:notes:169]
| (in thousands) |  | December 30,2022 |  | June 24,2022 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 253,287 |  |  | $ | 240,750 |  |
| U.S. |  | 25,937 |  |  | 25,938 |  |
| China |  | 18,118 |  |  | 19,686 |  |
| Israel |  | 3,361 |  |  | 4,025 |  |
| Others |  | 1,579 |  |  | 1,878 |  |
| Total |  | $ | 302,282 |  |  | $ | 292,277 |  |

[0001408710-23-000008:notes:170]
[same as prior period, unchanged from 0001408710-22-000060:notes:163]

[0001408710-23-000008:notes:171]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of December 30, 2022 and June 24, 2022.
