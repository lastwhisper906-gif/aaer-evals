# FN note change history — 0001193125-20-284755 → 0001408710-21-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:1]
Commitments and contingencies
Letter of credit and Bank guarantees
  (was, 2020-11-03, similarity 0.7059):
[0001193125-20-284755:note_history:1]
Letter of credit and Bank guarantees

- changed (2021-02-02):
[0001408710-21-000011:note_history:2]
As of December 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of December 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.  This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.
  (was, 2020-11-03, similarity 0.8462):
[0001193125-20-284755:note_history:2]
As of September 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of September 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.

- changed (2021-02-02):
[0001408710-21-000011:note_history:3]
As of December 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of December 25, 2020, the Company had an outstanding bank guarantee of its subsidiary in China to support the subsidiary's operations of Renmibi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. As of June 26, 2020, these bank guarantees were not material.
  (was, 2020-11-03, similarity 0.6893):
[0001193125-20-284755:note_history:3]
As of September 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of September 25, 2020 and June 26, 2020, these bank guarantees were not material.

- changed (2021-02-02):
[0001408710-21-000011:note_history:4]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $515.5 million.
  (was, 2020-11-03, similarity 0.973):
[0001193125-20-284755:note_history:4]
As of September
 25, 2020, the Company had an outstanding commitment to third parties of $10.0 million.

- added (2021-02-02):
[0001408710-21-000011:note_history:5]
Capital expenditure

- added (2021-02-02):
[0001408710-21-000011:note_history:6]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

- added (2021-02-02):
[0001408710-21-000011:note_history:7]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $10.1 million.

- removed (2021-02-02):
[0001193125-20-284755:note_history:8]
| 17. | Commitments and contingencies |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:9]
Accounting policies
Basis of presentation
  (was, 2020-11-03, similarity 0.6774):
[0001193125-20-284755:note_history:9]
Basis of presentation

- changed (2021-02-02):
[0001408710-21-000011:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 25, 2020 and for the three and six months ended December 25, 2020 and December 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.
  (was, 2020-11-03, similarity 0.9665):
[0001193125-20-284755:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as 
of
 September 25, 2020 and for the three months ended September 25, 2020 and September 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 26, 2020.

- changed (2021-02-02):
[0001408710-21-000011:note_history:11]
The results for the three and six months ended December 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.
  (was, 2020-11-03, similarity 0.9537):
[0001193125-20-284755:note_history:11]
The results for the three months ended September 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.

- changed (2021-02-02):
[0001408710-21-000011:note_history:12]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.
  (was, 2020-11-03, similarity 0.9958):
[0001193125-20-284755:note_history:12]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving 
COVID-19
 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the 
COVID-19
 pandemic that could result in material impacts to our unaudited condensed consolidated financial statements in future reporting periods.

- changed (2021-02-02):
[0001408710-21-000011:note_history:13]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 25, 2020 and December 27, 2019 each consisted of 13 weeks. The six months ended December 25, 2020 and December 27, 2019 each consisted of 26 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.
  (was, 2020-11-03, similarity 0.7374):
[0001193125-20-284755:note_history:13]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 25, 2020 and September 27, 2019 each consisted of 13 weeks. Fiscal year 
2021 
will be comprised of 52 weeks and will end on June 25, 2021.

- changed (2021-02-02):
[0001408710-21-000011:note_history:14]
(i)A derivative for which the fair value is a net liability is classified in total as current.
  (was, 2020-11-03, similarity 0.8995):
[0001193125-20-284755:note_history:14]
|  | (i) | A derivative for which the fair value is a net liability is classified in total as a current liability. |

- changed (2021-02-02):
[0001408710-21-000011:note_history:15]
(ii)A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is a liability, it is presented as a current liability.
  (was, 2020-11-03, similarity 0.9611):
[0001193125-20-284755:note_history:15]
|  | (ii) | A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as a non-current asset. If the current portion is a liability, it is presented as a current liability. |

- changed (2021-02-02):
[0001408710-21-000011:note_history:16]
As of December 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).
  (was, 2020-11-03, similarity 0.9908):
[0001193125-20-284755:note_history:16]
As of September 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and 
non-current
 portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

- changed (2021-02-02):
[0001408710-21-000011:note_history:17]
|  | June 26, 2020 |
| (amount in thousands) | As previouslyreported |  | Reclassification |  | Afterreclassification |
| Consolidated Balance Sheet |  |  |  |  |  |
| Current assets |  |  |  |  |  |
| Other current assets | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |
| Accrued expenses | $ | 12,104 |  |  | $ | (3,125) |  |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |
| Other non-current liabilities | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |
  (was, 2020-11-03, similarity 0.816):
[0001193125-20-284755:note_history:17]
|  |  | June 26, 2020 |  |
| (amount in thousands) |  | As previously reported |  |  | Reclassification |  |  | After reclassification |  |
| Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current assets |  | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 12,104 |  |  | $ | (3,125 | ) |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other non-current liabilities |  | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:18]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale
  (was, 2020-11-03, similarity 0.99):
[0001193125-20-284755:note_history:18]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for

- changed (2021-02-02):
[0001408710-21-000011:note_history:19]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.
  (was, 2020-11-03, similarity 0.9824):
[0001193125-20-284755:note_history:19]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive loss (“AOCI”) in the unaudited condensed consolidated balance sheet.

- changed (2021-02-02):
[0001408710-21-000011:note_history:20]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three and six months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.
  (was, 2020-11-03, similarity 0.9967):
[0001193125-20-284755:note_history:20]
Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- changed (2021-02-02):
[0001408710-21-000011:note_history:21]
In December 2019, the FASB issued ASU2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.
  (was, 2020-11-03, similarity 0.9994):
[0001193125-20-284755:note_history:21]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.

- removed (2021-02-02):
[0001193125-20-284755:note_history:22]
| 2. | Accounting policies |

- removed (2021-02-02):
[0001193125-20-284755:note_history:23]
available-for-sale


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:24]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:
  (was, 2020-11-03, similarity 0.9585):
[0001193125-20-284755:note_history:24]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:

- changed (2021-02-02):
[0001408710-21-000011:note_history:25]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 45,703 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (79) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 33,436 |  |  | $ | 39,514 |  |
  (was, 2020-11-03, similarity 0.9015):
[0001193125-20-284755:note_history:25]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | (32 | ) |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  |  | June 2024 |  |  | $ | 48,750 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (12,188 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  | (87 | ) |  |  | (95 | ) |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  | $ | 36,475 |  |  | $ | 39,514 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:26]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.
  (was, 2020-11-03, similarity 0.9756):
[0001193125-20-284755:note_history:26]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

- changed (2021-02-02):
[0001408710-21-000011:note_history:27]
The movements of long-term borrowings for the six months ended December 25, 2020 and December 27, 2019 were as follows:
  (was, 2020-11-03, similarity 0.9189):
[0001193125-20-284755:note_history:27]
The movements of long-term borrowings for the three months ended September 25, 2020 and September 27, 2019 were as follows:

- changed (2021-02-02):
[0001408710-21-000011:note_history:28]
|  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (6,094) |  |  | (63,985) |  |
| Closing balance | $ | 45,703 |  |  | $ | 57,891 |  |
  (was, 2020-11-03, similarity 0.6377):
[0001193125-20-284755:note_history:28]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Opening balance |  | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period |  |  | — |  |  |  | 60,938 |  |
| Repayments during the period |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Closing balance |  | $ | 48,750 |  |  | $ | 60,938 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:29]
As of December 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-11-03, similarity 0.9754):
[0001193125-20-284755:note_history:29]
As
 of
 September 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-02-02):
[0001408710-21-000011:note_history:30]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 9,141 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 45,703 |  |
  (was, 2020-11-03, similarity 0.9057):
[0001193125-20-284755:note_history:30]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 9,140 |  |
| 2022 |  |  | 12,188 |  |
| 2023 |  |  | 15,234 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 48,750 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:31]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of December 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.
  (was, 2020-11-03, similarity 0.9951):
[0001193125-20-284755:note_history:31]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as 
of
 September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- changed (2021-02-02):
[0001408710-21-000011:note_history:32]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.
  (was, 2020-11-03, similarity 0.9147):
[0001193125-20-284755:note_history:32]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the

- changed (2021-02-02):
[0001408710-21-000011:note_history:33]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be re-borrowed. During the three and six months ended December 25, 2020, the Company recorded $0.2 million and $0.4 million, respectively, of interest expense in connection with this term loan.
  (was, 2020-11-03, similarity 0.7804):
[0001193125-20-284755:note_history:33]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $
3.0
 million, commencing on September 30, 2019. The term loan will mature on 
June 30, 2024
. The Borrower m
a
y prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be

- changed (2021-02-02):
[0001408710-21-000011:note_history:34]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2020-11-03, similarity 0.9967):
[0001193125-20-284755:note_history:34]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2021-02-02):
[0001408710-21-000011:note_history:35]
At December 25, 2020, there was $45.7 million outstanding under the term loan.
  (was, 2020-11-03, similarity 0.964):
[0001193125-20-284755:note_history:35]
At September 25, 2020, there was $48.8 million outstanding under the term loan.

- changed (2021-02-02):
[0001408710-21-000011:note_history:36]
From time to time, the Company amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.
  (was, 2020-11-03, similarity 0.9091):
[0001193125-20-284755:note_history:36]
amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

- changed (2021-02-02):
[0001408710-21-000011:note_history:37]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three and six months ended December 27, 2019, the Company recorded $0.5 million of interest expense in connection with this term loan for both periods.
  (was, 2020-11-03, similarity 0.878):
[0001193125-20-284755:note_history:37]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended September 27, 2019
,
 the Company recorded $0.5 million of interest expense in connection with this term loan.

- removed (2021-02-02):
[0001193125-20-284755:note_history:38]
| 12. | Borrowings |

- removed (2021-02-02):
[0001193125-20-284755:note_history:39]
Company’s previous syndicated senior credit facility

- removed (2021-02-02):
[0001193125-20-284755:note_history:40]
agreement.

- removed (2021-02-02):
[0001193125-20-284755:note_history:41]
re-borrowed.

- removed (2021-02-02):
[0001193125-20-284755:note_history:42]
During the three months ended September 25, 2020, the Company recorded $
0.2
 million of interest expense in connection with this term loan.

- removed (2021-02-02):
[0001193125-20-284755:note_history:43]
From time to time,

- removed (2021-02-02):
[0001193125-20-284755:note_history:44]
the Company


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-02-02):
[0001408710-21-000011:note_history:45]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 25, 2020 and June 26, 2020:

- added (2021-02-02):
[0001408710-21-000011:note_history:46]
|  | December 25, 2020 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 82,493 |  |  | $ | 82,508 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 116,454 |  |  | 117,564 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 198,947 |  |  | $ | 200,072 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:47]
The movements of long-term borrowings for the six months ended December 25, 2020 and December 27, 2019 were as follows:
  (was, 2020-11-03, similarity 0.9189):
[0001193125-20-284755:note_history:47]
The movements of long-term borrowings for the three months ended September 25, 2020 and September 27, 2019 were as follows:

- changed (2021-02-02):
[0001408710-21-000011:note_history:48]
|  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (6,094) |  |  | (63,985) |  |
| Closing balance | $ | 45,703 |  |  | $ | 57,891 |  |
  (was, 2020-11-03, similarity 0.6377):
[0001193125-20-284755:note_history:48]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Opening balance |  | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period |  |  | — |  |  |  | 60,938 |  |
| Repayments during the period |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Closing balance |  | $ | 48,750 |  |  | $ | 60,938 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:49]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 45,703 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (79) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 33,436 |  |  | $ | 39,514 |  |
  (was, 2020-11-03, similarity 0.9015):
[0001193125-20-284755:note_history:49]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | (32 | ) |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  |  | June 2024 |  |  | $ | 48,750 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (12,188 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  | (87 | ) |  |  | (95 | ) |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  | $ | 36,475 |  |  | $ | 39,514 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:50]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.
  (was, 2020-11-03, similarity 0.9756):
[0001193125-20-284755:note_history:50]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:51]
As of December 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-11-03, similarity 0.9754):
[0001193125-20-284755:note_history:51]
As
 of
 September 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-02-02):
[0001408710-21-000011:note_history:52]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 9,141 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 45,703 |  |
  (was, 2020-11-03, similarity 0.9057):
[0001193125-20-284755:note_history:52]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 9,140 |  |
| 2022 |  |  | 12,188 |  |
| 2023 |  |  | 15,234 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 48,750 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-02-02):
[0001408710-21-000011:note_history:53]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America | $ | 224,672 |  |  | 49.5 | % |  | $ | 432,074 |  |  | 48.5 | % |
| Asia-Pacific | 153,734 |  |  | 33.9 |  |  | 299,380 |  |  | 33.6 |  |
| Europe | 75,421 |  |  | 16.6 |  |  | 159,012 |  |  | 17.9 |  |
|  | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- added (2021-02-02):
[0001408710-21-000011:note_history:54]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| North America | $ | 223,398 |  |  | 52.4 | % |  | $ | 424,345 |  |  | 51.4 | % |
| Asia-Pacific | 141,147 |  |  | 33.1 |  |  | 259,570 |  |  | 31.4 |  |
| Europe | 61,672 |  |  | 14.5 |  |  | 141,598 |  |  | 17.2 |  |
|  | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

- removed (2021-02-02):
[0001193125-20-284755:note_history:55]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 207,402 |  |  |  | 47.5 | % |
| Asia-Pacific |  |  | 145,646 |  |  |  | 33.4 |  |
| Europe |  |  | 83,591 |  |  |  | 19.1 |  |
|  |  | $ | 436,639 |  |  |  | 100.0 | % |

- removed (2021-02-02):
[0001193125-20-284755:note_history:56]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-02):
[0001408710-21-000011:note_history:57]
Revenues from contracts with customers
Revenue by Geographic Area and End Market
  (was, 2020-11-03, similarity 0.6777):
[0001193125-20-284755:note_history:57]
Revenue by Geographic Area and End Market

- changed (2021-02-02):
[0001408710-21-000011:note_history:58]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.
  (was, 2020-11-03, similarity 0.7192):
[0001193125-20-284755:note_history:58]
the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

- added (2021-02-02):
[0001408710-21-000011:note_history:59]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America | $ | 224,672 |  |  | 49.5 | % |  | $ | 432,074 |  |  | 48.5 | % |
| Asia-Pacific | 153,734 |  |  | 33.9 |  |  | 299,380 |  |  | 33.6 |  |
| Europe | 75,421 |  |  | 16.6 |  |  | 159,012 |  |  | 17.9 |  |
|  | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- added (2021-02-02):
[0001408710-21-000011:note_history:60]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| North America | $ | 223,398 |  |  | 52.4 | % |  | $ | 424,345 |  |  | 51.4 | % |
| Asia-Pacific | 141,147 |  |  | 33.1 |  |  | 259,570 |  |  | 31.4 |  |
| Europe | 61,672 |  |  | 14.5 |  |  | 141,598 |  |  | 17.2 |  |
|  | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

- added (2021-02-02):
[0001408710-21-000011:note_history:61]
The following table presents revenues by end market.

- added (2021-02-02):
[0001408710-21-000011:note_history:62]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 |  |  | 198,709 |  |  | 22.3 |  |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- added (2021-02-02):
[0001408710-21-000011:note_history:63]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| Optical communications | $ | 322,068 |  |  | 75.6 | % |  | $ | 624,447 |  |  | 75.6 | % |
| Lasers, sensors and other | 104,149 |  |  | 24.4 |  |  | 201,066 |  |  | 24.4 |  |
| Total | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

- changed (2021-02-02):
[0001408710-21-000011:note_history:64]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 25, 2020:
  (was, 2020-11-03, similarity 0.955):
[0001193125-20-284755:note_history:64]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 25, 2020:

- changed (2021-02-02):
[0001408710-21-000011:note_history:65]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 35,464 |  |
| Amounts collected or invoiced | (32,497) |  |
| Ending balance, December 25, 2020 | $ | 16,223 |  |
  (was, 2020-11-03, similarity 0.8627):
[0001193125-20-284755:note_history:65]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 26, 2020 |  | $ | 13,256 |  |
| Revenue recognized |  |  | 17,444 |  |
| Amounts collected or invoiced |  |  | (18,943 | ) |
| Ending balance, September 25, 2020 |  | $ | 11,757 |  |

- changed (2021-02-02):
[0001408710-21-000011:note_history:66]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Additions advance payment received during the period | 14,597 |  |
| Revenue recognized | (14,349) |  |
| Ending balance, December 25, 2020 | $ | 1,804 |  |
  (was, 2020-11-03, similarity 0.8577):
[0001193125-20-284755:note_history:66]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 26, 2020 |  | $ | 1,556 |  |
| Additions advance payment received during the period |  |  | 4,308 |  |
| Revenue recognized |  |  | (4,898 | ) |
| Ending balance, September 25, 2020 |  | $ | 966 |  |

- removed (2021-02-02):
[0001193125-20-284755:note_history:67]
| 3. | Revenues from contracts with customers |

- removed (2021-02-02):
[0001193125-20-284755:note_history:68]
Revenues are attributed to a particular geographic area based on

- removed (2021-02-02):
[0001193125-20-284755:note_history:69]
the bill-to-location of

- removed (2021-02-02):
[0001193125-20-284755:note_history:70]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 207,402 |  |  |  | 47.5 | % |
| Asia-Pacific |  |  | 145,646 |  |  |  | 33.4 |  |
| Europe |  |  | 83,591 |  |  |  | 19.1 |  |
|  |  | $ | 436,639 |  |  |  | 100.0 | % |

- removed (2021-02-02):
[0001193125-20-284755:note_history:71]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |

- removed (2021-02-02):
[0001193125-20-284755:note_history:72]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 343,917 |  |  |  | 78.8 | % |
| Lasers, sensors and other |  |  | 92,722 |  |  |  | 21.2 |  |
| Total |  | $ | 436,639 |  |  |  | 100.0 | % |

- removed (2021-02-02):
[0001193125-20-284755:note_history:73]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-02-02):
[0001193125-20-284755:note_history:74]
| 19. | Subsequent events |

- removed (2021-02-02):
[0001193125-20-284755:note_history:75]
On October 1, 2020, the Company extended the payment terms of $24.3 million in funds it had advanced to a customer and accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension is due to the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds will be offset by amount due to this customer for the purchases of certain inventories. (See Note 8)

- removed (2021-02-02):
[0001193125-20-284755:note_history:76]
The Company has also committed to purchase $26.0 million worth of inventories from the customer.
