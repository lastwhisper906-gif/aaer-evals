# FN MD&A — 0001408710-21-000011


## mdna

[0001408710-21-000011:mdna:1]
[same as prior period, unchanged from 0001193125-20-284755:mdna:1]

[0001408710-21-000011:mdna:2]
•our goals and strategies;

[0001408710-21-000011:mdna:3]
•our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity;

[0001408710-21-000011:mdna:4]
•our belief that we will be able to maintain favorable pricing on our services;

[0001408710-21-000011:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2021 will be in line with the portion of those revenues for the six months ended December 25, 2020;

[0001408710-21-000011:mdna:6]
•our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets;

[0001408710-21-000011:mdna:7]
•our expectation that our fiscal year 2021 selling, general and administrative (“SG&A”) expenses will increase as a percentage of revenue compared to fiscal year 2020 SG&A expenses;

[0001408710-21-000011:mdna:8]
•our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”);

[0001408710-21-000011:mdna:9]
•our future capital expenditures and our needs for additional financing;

[0001408710-21-000011:mdna:10]
•the expansion of our manufacturing capacity, including into new geographies;

[0001408710-21-000011:mdna:11]
•the growth rates of our existing markets and potential new markets;

[0001408710-21-000011:mdna:12]
•our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments;

[0001408710-21-000011:mdna:13]
•our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and results of operations;

[0001408710-21-000011:mdna:14]
•our suppliers’ estimates regarding future costs;

[0001408710-21-000011:mdna:15]
•our ability to increase our penetration of existing markets and to penetrate new markets;

[0001408710-21-000011:mdna:16]
•our plans to diversify our sources of revenues;

[0001408710-21-000011:mdna:17]
•our plans to execute acquisitions;

[0001408710-21-000011:mdna:18]
•trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets;

[0001408710-21-000011:mdna:19]
•our ability to attract and retain a qualified management team and other qualified personnel and advisors; and

[0001408710-21-000011:mdna:20]
•competition in our existing and new markets.

[0001408710-21-000011:mdna:21]
[same as prior period, unchanged from 0001193125-20-284755:mdna:22]

[0001408710-21-000011:mdna:22]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, automotive components, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001408710-21-000011:mdna:23]
[same as prior period, unchanged from 0001193125-20-284755:mdna:25]

[0001408710-21-000011:mdna:24]
[same as prior period, unchanged from 0001193125-20-284755:mdna:26]

[0001408710-21-000011:mdna:25]
Recent Developments Related to COVID-19

[0001408710-21-000011:mdna:26]
The global COVID-19 pandemic has impacted us in several ways and created various challenges. At the onset of the pandemic, our PRC subsidiary, which manufactures custom optics components for us and other customers at its facility in Fuzhou, China, experienced a prolonged temporary closure following its customary eight-day Chinese Lunar New Year holiday in January 2020. In accordance with the Chinese government’s official efforts to mitigate the spread of COVID-19, our PRC subsidiary, along with other businesses in various parts of the country, delayed resumption of operations following the holiday closures for approximately two weeks. Furthermore, because of the restrictions in place on travel in China during this period, many of our employees were unable to return from their holiday travel as planned, resulting in fewer than 90% of our employees being able to return to work at our PRC subsidiary before early March. Our other global manufacturing facilities also have been affected by various government restrictions put in place to slow the spread of COVID-19. In Thailand, the government declared a national state of emergency effective March 26, 2020 and required the closure of various businesses, in particular retail establishments, and passed measures restricting movement and activities in Thailand. While our operations in Thailand have not been suspended, we have implemented a number of safety protocols to allow our operations in our facilities there to continue in accordance with government regulations. With the exception of our facility in Santa Clara, California, which closed for approximately one week beginning in late March 2020 before reopening in early April as a previously classified “essential business,” our facilities in the U.S., including in New Jersey, and in the U.K. have remained open while adhering to the local government restrictions and orders implemented in March 2020, including “shelter-in-place” orders and social distancing guidelines.

[0001408710-21-000011:mdna:27]
The health and well-being of our employees continues to be our top priority. Over the last few quarters, we have implemented significant precautionary measures throughout our worldwide operations to ensure our employees and their families remain safe, such as mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) the wearing of face masks throughout our factories at all times, (2) distributing our employees across shifts to better maintain safe personal distances, (3) isolating incoming parts and materials for a week or more prior to unpacking, or applying extreme heat to them to kill potential viruses, (4) directing our non-factory personnel to work remotely, and (5) restricting all non-employee visits to our campuses.

[0001408710-21-000011:mdna:28]
During the winter months of fiscal 2021, we may experience worsening impacts of the pandemic, which could further impact customer demand. During the three months ended December 25, 2020, several countries such as Thailand, China, the U.S., and the U.K., where we have manufacturing facilities, experienced a surge in the number of COVID-19 cases. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended December 25, 2020, any further worsening of the pandemic may have a negative impact on our operations.

[0001408710-21-000011:mdna:29]
Given the unprecedented global, human, and economic impact of the COVID-19 pandemic, the extraordinary economic short-term uncertainty, and the evolving and differing national strategies for dealing with COVID-19, it is extremely challenging to provide a forward-looking disclosure. Despite the uncertainty and concern about the global economy and the health of various industries, we believe it is important to share some relevant perspective as we continue to assess the impacts of COVID-19 on our business in the future:

[0001408710-21-000011:mdna:30]
•With work-from-home protocols in place around the world, global demand for internet bandwidth has grown and we believe it will continue to grow. Because the next-generation telecom and datacom products we manufacture for our customers are important to expand network capacity, we believe this will have a positive impact on our business in the long-term.

[0001408710-21-000011:mdna:31]
•While we believe that the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments, especially if the COVID-19 outbreak intensifies or returns in various geographic areas as happened at the end of our third quarter in fiscal year 2020.

[0001408710-21-000011:mdna:32]
•We expect we will continue to experience some disruptions in our supply chain and the availability of parts and materials will continue to fluctuate, especially if the COVID-19 outbreak intensifies or returns in various geographic areas. However, we believe we can mitigate these disruptions by continuing to identify and secure alternative sources.

[0001408710-21-000011:mdna:33]
•A significant portion of our costs are variable and, because of this, we can adjust manufacturing costs relatively quickly to respond to the changing demand of our customers. However, because parts and materials account for the largest portion of our costs, in combination with the supply chain issues noted above and, to a lesser extent, the expenses associated with the safety and health protocols we have implemented across our global operations, our gross margins will continue to be negatively affected for the foreseeable future.

[0001408710-21-000011:mdna:34]
•The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities.

[0001408710-21-000011:mdna:35]
•Given our $481.0 million in cash, cash equivalents and short-term investments, and our total debt of approximately $45.7 million, as of December 25, 2020, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows that are generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-21-000011:mdna:36]
[same as prior period, unchanged from 0001193125-20-284755:mdna:40]

[0001408710-21-000011:mdna:37]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-21-000011:mdna:38]
[same as prior period, unchanged from 0001193125-20-284755:mdna:43]

[0001408710-21-000011:mdna:39]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-21-000011:mdna:40]
The percentage of our revenues generated from a bill-to location outside of North America increased from 47.6% in the three months ended December 27, 2019 to 50.5% in the three months ended December 25, 2020, primarily because the increase in sales to our customers in North America was lower than the increase in sales to our customers outside of North America.

[0001408710-21-000011:mdna:41]
The percentage of our revenues generated from a bill-to location outside of North America increased from 48.6% in the six months ended December 27, 2019 to 51.5% in the six months ended December 25, 2020, primarily because the increase in sales to our customers in North America was lower than the increase in sales to our customers outside of North America.

[0001408710-21-000011:mdna:42]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2021 will be in line with the portion of revenues attributable to such customers during the six months ended December 25, 2020.

[0001408710-21-000011:mdna:43]
[same as prior period, unchanged from 0001193125-20-284755:mdna:46]

[0001408710-21-000011:mdna:44]
|  | Three Months Ended |  | Six Months Ended |
|  | December 25, 2020 |  | December 27, 2019 |  | December 25, 2020 |  | December 27, 2019 |
| North America | 49.5 | % |  | 52.4 | % |  | 48.5 | % |  | 51.4 | % |
| Asia-Pacific | 33.9 |  |  | 33.1 |  |  | 33.6 |  |  | 31.4 |  |
| Europe | 16.6 |  |  | 14.5 |  |  | 17.9 |  |  | 17.2 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-21-000011:mdna:45]
[same as prior period, unchanged from 0001193125-20-284755:mdna:48]

[0001408710-21-000011:mdna:46]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-21-000011:mdna:47]
[same as prior period, unchanged from 0001193125-20-284755:mdna:52]

[0001408710-21-000011:mdna:48]
[same as prior period, unchanged from 0001193125-20-284755:mdna:53]

[0001408710-21-000011:mdna:49]
[same as prior period, unchanged from 0001193125-20-284755:mdna:54]

[0001408710-21-000011:mdna:50]
[same as prior period, unchanged from 0001193125-20-284755:mdna:55]

[0001408710-21-000011:mdna:51]
[same as prior period, unchanged from 0001193125-20-284755:mdna:56]

[0001408710-21-000011:mdna:52]
[same as prior period, unchanged from 0001193125-20-284755:mdna:57]

[0001408710-21-000011:mdna:53]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2021, we expect our SG&A expenses will increase as compared with our fiscal year 2020 SG&A expenses due to an increase in start-up costs related to our subsidiary in Israel and an increase in management retirement compensation.

[0001408710-21-000011:mdna:54]
The compensation committee of our board of directors approved a fiscal year 2021 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and non-GAAP operating margin targets for our fiscal year ending June 25, 2021. Bonuses under the fiscal year 2021 executive incentive plan are payable after the end of fiscal year 2021. In fiscal year 2020, the compensation committee of our board of directors approved a fiscal year 2020 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2020.

[0001408710-21-000011:mdna:55]
[same as prior period, unchanged from 0001193125-20-284755:mdna:60]

[0001408710-21-000011:mdna:56]
[same as prior period, unchanged from 0001193125-20-284755:mdna:61]

[0001408710-21-000011:mdna:57]
[same as prior period, unchanged from 0001193125-20-284755:mdna:62]

[0001408710-21-000011:mdna:58]
[same as prior period, unchanged from 0001193125-20-284755:mdna:63]

[0001408710-21-000011:mdna:59]
[same as prior period, unchanged from 0001193125-20-284755:mdna:64]

[0001408710-21-000011:mdna:60]
|  | As of December 25, 2020 |  | As of June 26, 2020 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 633,768 |  |  | $ | 21,076 |  |  | 49.6 | % |  | 667,955 |  |  | $ | 21,617 |  |  | 41.8 | % |
| RMB | 87,668 |  |  | 13,419 |  |  | 31.6 |  |  | 158,060 |  |  | 22,402 |  |  | 43.3 |  |
| GBP | 5,902 |  |  | 8,006 |  |  | 18.8 |  |  | 6,220 |  |  | 7,726 |  |  | 14.9 |  |
| Total |  |  | $ | 42,501 |  |  | 100.0 | % |  |  |  | $ | 51,745 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,997,135 |  |  | $ | 66,416 |  |  | 90.8 | % |  | 2,102,392 |  |  | $ | 68,039 |  |  | 89.5 | % |
| RMB | 29,894 |  |  | 4,576 |  |  | 6.2 |  |  | 42,586 |  |  | 6,036 |  |  | 8.0 |  |
| GBP | 1,600 |  |  | 2,170 |  |  | 3.0 |  |  | 1,545 |  |  | 1,919 |  |  | 2.5 |  |
| Total |  |  | $ | 73,162 |  |  | 100.0 | % |  |  |  | $ | 75,994 |  |  | 100.0 | % |

[0001408710-21-000011:mdna:61]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 25, 2020, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 26, 2020, there was $125.0 million of foreign currency forward contracts outstanding and one foreign currency option contract with notional amount of $1.0 million on the Thai baht payables.

[0001408710-21-000011:mdna:62]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 25, 2020 and June 26, 2020, we did not have any derivative contracts denominated in RMB.

[0001408710-21-000011:mdna:63]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of December 25, 2020 and June 26, 2020, we did not have any derivative contracts denominated in GBP.

[0001408710-21-000011:mdna:64]
For the three months ended December 25, 2020 and December 27, 2019, we recorded gain of $1.8 million and $24.0 thousand, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:mdna:65]
For the six months ended December 25, 2020 and December 27, 2019, we recorded gain of $0.3 million and loss of $1.9 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:mdna:66]
[same as prior period, unchanged from 0001193125-20-284755:mdna:70]

[0001408710-21-000011:mdna:67]
[same as prior period, unchanged from 0001193125-20-284755:mdna:71]

[0001408710-21-000011:mdna:68]
•Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules;

[0001408710-21-000011:mdna:69]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and

[0001408710-21-000011:mdna:70]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142.

[0001408710-21-000011:mdna:71]
[same as prior period, unchanged from 0001193125-20-284755:mdna:75]

[0001408710-21-000011:mdna:72]
[same as prior period, unchanged from 0001193125-20-284755:mdna:76]

[0001408710-21-000011:mdna:73]
[same as prior period, unchanged from 0001193125-20-284755:mdna:77]

[0001408710-21-000011:mdna:74]
[same as prior period, unchanged from 0001193125-20-284755:mdna:78]

[0001408710-21-000011:mdna:75]
[same as prior period, unchanged from 0001193125-20-284755:mdna:79]

[0001408710-21-000011:mdna:76]
[same as prior period, unchanged from 0001193125-20-284755:mdna:80]

[0001408710-21-000011:mdna:77]
[same as prior period, unchanged from 0001193125-20-284755:mdna:81]

[0001408710-21-000011:mdna:78]
[same as prior period, unchanged from 0001193125-20-284755:mdna:82]

[0001408710-21-000011:mdna:79]
[same as prior period, unchanged from 0001193125-20-284755:mdna:83]

[0001408710-21-000011:mdna:80]
[same as prior period, unchanged from 0001193125-20-284755:mdna:84]

[0001408710-21-000011:mdna:81]
The corporate income tax rate for our subsidiaries in China and the U.K. is 25% and 19%, respectively.

[0001408710-21-000011:mdna:82]
[same as prior period, unchanged from 0001193125-20-284755:mdna:85]

[0001408710-21-000011:mdna:83]
[same as prior period, unchanged from 0001193125-20-284755:mdna:86]

[0001408710-21-000011:mdna:84]
Our critical accounting policies are disclosed in our Annual Report on Form10-K for the fiscal year ended June 26, 2020. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 326, “Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments” and ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement."

[0001408710-21-000011:mdna:85]
[same as prior period, unchanged from 0001193125-20-284755:mdna:88]

[0001408710-21-000011:mdna:86]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001408710-21-000011:mdna:87]
| (amount in thousands) | Three Months Ended |  | Six Months Ended |
| December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Revenues | $ | 453,827 |  |  | $ | 426,217 |  |  | $ | 890,466 |  |  | $ | 825,513 |  |
| Cost of revenues | (400,806) |  |  | (377,059) |  |  | (786,965) |  |  | (730,368) |  |
| Gross profit | 53,021 |  |  | 49,158 |  |  | 103,501 |  |  | 95,145 |  |
| Selling, general and administrative expenses | (17,156) |  |  | (17,078) |  |  | (34,019) |  |  | (33,078) |  |
| Expenses related to reduction in workforce | — |  |  | (16) |  |  | — |  |  | (16) |  |
| Operating income | 35,865 |  |  | 32,064 |  |  | 69,482 |  |  | 62,051 |  |
| Interest income | 1,111 |  |  | 1,940 |  |  | 2,215 |  |  | 4,038 |  |
| Interest expense | (265) |  |  | (181) |  |  | (516) |  |  | (2,574) |  |
| Foreign exchange gain (loss), net | (533) |  |  | (988) |  |  | (405) |  |  | (2,941) |  |
| Other income (expense), net | 158 |  |  | 397 |  |  | 279 |  |  | 774 |  |
| Income before income taxes | 36,336 |  |  | 33,232 |  |  | 71,055 |  |  | 61,348 |  |
| Income tax expense | (952) |  |  | (2,001) |  |  | (2,620) |  |  | (4,160) |  |
| Net income | 35,384 |  |  | 31,231 |  |  | 68,435 |  |  | 57,188 |  |
| Other comprehensive income (loss), net of tax | 2,247 |  |  | 446 |  |  | (510) |  |  | 234 |  |
| Net comprehensive income | $ | 37,631 |  |  | $ | 31,677 |  |  | $ | 67,925 |  |  | $ | 57,422 |  |

[0001408710-21-000011:mdna:88]
[same as prior period, unchanged from 0001193125-20-284755:mdna:93]

[0001408710-21-000011:mdna:89]
|  | Three Months Ended |  | Six Months Ended |
|  | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (88.3) |  |  | (88.5) |  |  | (88.4) |  |  | (88.5) |  |
| Gross profit | 11.7 |  |  | 11.5 |  |  | 11.6 |  |  | 11.5 |  |
| Selling, general and administrative expenses | (3.8) |  |  | (4.0) |  |  | (3.8) |  |  | (4.0) |  |
| Expenses related to reduction in workforce | — |  |  | — |  |  | — |  |  | — |  |
| Operating income | 7.9 |  |  | 7.5 |  |  | 7.8 |  |  | 7.5 |  |
| Interest income | 0.2 |  |  | 0.4 |  |  | 0.3 |  |  | 0.5 |  |
| Interest expense | — |  |  | — |  |  | (0.1) |  |  | (0.3) |  |
| Foreign exchange gain (loss), net | (0.1) |  |  | (0.2) |  |  | — |  |  | (0.4) |  |
| Other income (expense), net | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Income before income taxes | 8.0 |  |  | 7.8 |  |  | 8.0 |  |  | 7.4 |  |
| Income tax expense | (0.2) |  |  | (0.5) |  |  | (0.3) |  |  | (0.5) |  |
| Net income | 7.8 |  |  | 7.3 |  |  | 7.7 |  |  | 6.9 |  |
| Other comprehensive income (loss), net of tax | 0.5 |  |  | 0.1 |  |  | (0.1) |  |  | — |  |
| Net comprehensive income | 8.3 | % |  | 7.4 | % |  | 7.6 | % |  | 6.9 | % |

[0001408710-21-000011:mdna:90]
38

[0001408710-21-000011:mdna:91]
[same as prior period, unchanged from 0001193125-20-284755:mdna:95]

[0001408710-21-000011:mdna:92]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Optical communications | $ | 347,840 |  |  | $ | 322,068 |  |  | $ | 691,757 |  |  | $ | 624,447 |  |
| Lasers, sensors and other | 105,987 |  |  | 104,149 |  |  | 198,709 |  |  | 201,066 |  |
| Total | $ | 453,827 |  |  | $ | 426,217 |  |  | $ | 890,466 |  |  | $ | 825,513 |  |

[0001408710-21-000011:mdna:93]
[same as prior period, unchanged from 0001193125-20-284755:mdna:97]

[0001408710-21-000011:mdna:94]
Comparison of Three and Six Months Ended December 25, 2020 with Three and Six Months Ended December 27, 2019

[0001408710-21-000011:mdna:95]
Revenues

[0001408710-21-000011:mdna:96]
Our revenues increased by $27.6 million, or 6.5%, to $453.8 million for the three months ended December 25, 2020, compared with $426.2 million for the three months ended December 27, 2019. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services and from newer programs during the three months ended December 25, 2020. Revenues from optical communications products increased by $25.8 million, or 8.0%, for the three months ended December 25, 2020.

[0001408710-21-000011:mdna:97]
Our revenues increased by $65.0 million, or 7.9%, to $890.5 million for the six months ended December 25, 2020, compared with $825.5 million for the six months ended December 27, 2019. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services and from newer programs during the six months ended December 25, 2020. Revenues from optical communications products increased by $67.3 million, or 10.8%, for the six months ended December 25, 2020.

[0001408710-21-000011:mdna:98]
Cost of revenues

[0001408710-21-000011:mdna:99]
Our cost of revenues increased by $23.7 million, or 6.3%, to $400.8 million, or 88.3% of revenues, for the three months ended December 25, 2020, compared with $377.1 million, or 88.5% of revenues, for the three months ended December 27, 2019. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-21-000011:mdna:100]
Our cost of revenues increased by $56.6 million, or 7.7%, to $787.0 million, or 88.4% of revenues, for the six months ended December 25, 2020, compared with $730.4 million, or 88.5% of revenues, for the six months ended December 27, 2019. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-21-000011:mdna:101]
Gross profit

[0001408710-21-000011:mdna:102]
Our gross profit increased by $3.9 million, or 7.9%, to $53.0 million, or 11.7% of revenues, for the three months ended December 25, 2020, compared with $49.2 million, or 11.5% of revenues, for the three months ended December 27, 2019. The increase was primarily due to a more favorable product mix.

[0001408710-21-000011:mdna:103]
Our gross profit increased by $8.4 million, or 8.8%, to $103.5 million, or 11.6% of revenues, for the six months ended December 25, 2020, compared with $95.1 million, or 11.5% of revenues, for the six months ended December 27, 2019. The increase was primarily due to a more favorable product mix.

[0001408710-21-000011:mdna:104]
SG&A expenses

[0001408710-21-000011:mdna:105]
Our SG&A expenses increased by $0.1 million, or 0.5%, to $17.2 million, or 3.8% of revenues, for the three months ended December 25, 2020, compared with $17.1 million, or 4.0% of revenues, for the three months ended December 27, 2019. The increase was primarily due to an increase in start-up costs for our subsidiary in Israel of $0.4 million, offset by a decrease in share-based compensation expenses of $0.3 million and a decrease in executive and management travel expenses of $0.1 million.

[0001408710-21-000011:mdna:106]
Our SG&A expenses increased by $0.9 million, or 2.8%, to $34.0 million, or 3.8% of revenues, for the six months ended December 25, 2020, compared with $33.1 million, or 4.0% of revenues, for the six months ended December 27, 2019. The increase was primarily due to an increase in start-up costs for our subsidiary in Israel of $1.2 million, offset by a decrease in share-based compensation expenses of $0.4 million and the reversal of allowance for doubtful debt of $0.3 million.

[0001408710-21-000011:mdna:107]
Operating income

[0001408710-21-000011:mdna:108]
Our operating income increased by $3.8 million to $35.9 million, or 7.9% of revenues, for the three months ended December 25, 2020, compared with $32.1 million, or 7.5% of revenues, for the three months ended December 27, 2019. The increase was primarily due to an increase in revenues.

[0001408710-21-000011:mdna:109]
Our operating income increased by $7.4 million to $69.5 million, or 7.8% of revenues, for the six months ended December 25, 2020, compared with $62.1 million, or 7.5% of revenues, for the six months ended December 27, 2019. The increase was primarily due to an increase in revenues.

[0001408710-21-000011:mdna:110]
Interest income

[0001408710-21-000011:mdna:111]
Our interest income decreased by $0.8 million, or 42.7%, to $1.1 million, or 0.2% of revenues, for the three months ended December 25, 2020, compared with $1.9 million, or 0.4% of revenues, for the three months ended December 27, 2019. The decrease was primarily due to a lower weighted average interest rate during the three months ended December 25, 2020 compared to same period in fiscal year 2020.

[0001408710-21-000011:mdna:112]
Our interest income decreased by $1.8 million, or 45.1%, to $2.2 million, or 0.3% of revenues, for the six months ended December 25, 2020, compared with $4.0 million, or 0.5% of revenues, for the six months ended December 27, 2019. The decrease was primarily due to a lower weighted average interest rate during the six months ended December 25, 2020 compared to same period in fiscal year 2020.

[0001408710-21-000011:mdna:113]
Interest expense

[0001408710-21-000011:mdna:114]
Our interest expense increased by $0.1 million to $0.3 million for the three months ended December 25, 2020, compared with $0.2 million for the three months ended December 27, 2019. The increase was primarily due to lower amortization of the fair value of interest rate swaps during the three months ended December 25, 2020, compared with the three months ended December 27, 2019.

[0001408710-21-000011:mdna:115]
Our interest expense decreased by $2.1 million to $0.5 million for the six months ended December 25, 2020, compared with $2.6 million for the six months ended December 27, 2019. The decrease was primarily due to lower unrealized loss from mark-to-market of interest rate swaps recognized to earnings during the three months ended December 25, 2020, due to the implementation of cash flow hedge accounting on the interest rate swaps on September 27, 2019.

[0001408710-21-000011:mdna:116]
Foreign exchange gain (loss), net

[0001408710-21-000011:mdna:117]
We recorded foreign exchange loss, net of $0.5 million for the three months ended December 25, 2020, compared with foreign exchange loss, net of $1.0 million for the three months ended December 27, 2019. The decrease in foreign exchange loss was mainly due to the decrease of realized loss from payment/receipt of  $0.9 million. Moreover, there was a reduction of foreign exchange gain (loss) volatility from the application of cash flow hedge accounting for forward contracts which was implemented on December 28, 2019. Unrealized foreign exchange gain from marking-to-market of foreign exchange forward contracts after cash flow hedge application was $1.8 million for the three months ended December 25, 2020, as compared to unrealized foreign exchange loss from marking-to-market of foreign exchange forward contracts of $24 thousand for the three months ended December 27, 2019, offset by an unrealized foreign exchange loss from revaluation of outstanding Thai baht assets and liabilities of $2.6 million for the three months ended December 25, 2020, as compared to an unrealized foreign exchange gain from revaluation of outstanding Thai baht assets and liabilities of $0.2 million for the three months ended December 27, 2019.

[0001408710-21-000011:mdna:118]
We recorded foreign exchange loss, net of $0.4 million for the six months ended December 25, 2020, compared with foreign exchange loss, net of $2.9 million for the six months ended December 27, 2019. The decrease in foreign exchange loss was mainly due to net foreign exchange gain from our subsidiary companies of $1.1 million. Moreover, there was a reduction of foreign exchange gain (loss) volatility from the application of cash flow hedge accounting which was implemented on December 28, 2019. Unrealized foreign exchange gain from marking-to-market of foreign exchange forward contracts after cash flow hedge application was $0.3 million for the six months ended December 25, 2020, as compared to unrealized foreign exchange loss from marking-to-market of foreign exchange forward contracts of $1.9 million for the six months ended December 27, 2019, offset by an unrealized foreign exchange loss from revaluation of outstanding Thai baht assets and liabilities of $0.6 million for the six months ended December 25, 2020, as compared to an unrealized foreign exchange gain from revaluation of outstanding Thai baht assets and liabilities of $6 thousand for the six months ended December 27, 2019.

[0001408710-21-000011:mdna:119]
Income before income taxes

[0001408710-21-000011:mdna:120]
We recorded income before income taxes of $36.3 million and $71.1 million for the three and six months ended December 25, 2020, respectively, compared with $33.2 million and $61.3 million for the three and six months ended December 27, 2019, respectively.

[0001408710-21-000011:mdna:121]
Income tax expense

[0001408710-21-000011:mdna:122]
Our provision for income tax reflects an effective tax rate of 3.0% and 4.9% for the three months ended December 25, 2020 and December 27, 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the second quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000011:mdna:123]
Our provision for income tax reflects an effective tax rate of 3.7% and 5.0% for the six months ended December 25, 2020 and December 27, 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the first six months of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000011:mdna:124]
Net income

[0001408710-21-000011:mdna:125]
We recorded net income of $35.4 million, or 7.8% of revenues, for the three months ended December 25, 2020, compared with $31.2 million, or 7.3% of revenues, for the three months ended December 27, 2019.

[0001408710-21-000011:mdna:126]
We recorded net income of $68.4 million, or 7.7% of revenues, for the six months ended December 25, 2020, compared with $57.2 million, or 6.9% of revenues, for the six months ended December 27, 2019.

[0001408710-21-000011:mdna:127]
Other comprehensive income (loss)

[0001408710-21-000011:mdna:128]
We recorded other comprehensive income of $2.2 million, or 0.5% of revenues, for the three months ended December 25, 2020, compared with other comprehensive income of $0.4 million, or 0.1% of revenues, for the three months ended December 27, 2019. The increase in other comprehensive income was mainly due to the implementation of cash flow hedge accounting for foreign exchange forward contracts on December 28, 2019; therefore, we recorded net changes in unrealized foreign exchange gain of $2.3 million in other comprehensive income (loss) due to the gain from mark-to-market of forward contracts offset with changes in foreign currency translation adjustment of $0.8 million.

[0001408710-21-000011:mdna:129]
We recorded other comprehensive loss of $0.5 million, or 0.1% of revenues, for the six months ended December 25, 2020, compared with other comprehensive income of $0.2 million, or 0.0% of revenues, for the six months ended December 27, 2019. The increase in other comprehensive loss was mainly due to the implementation of cash flow hedge accounting for foreign exchange forward contracts on December 28, 2019; therefore, we recorded increase in unrealized foreign exchange loss of $0.9 million and unrealized loss on available-for-sales securities of $0.3 million.

[0001408710-21-000011:mdna:130]
[same as prior period, unchanged from 0001193125-20-284755:mdna:129]

[0001408710-21-000011:mdna:131]
[same as prior period, unchanged from 0001193125-20-284755:mdna:130]

[0001408710-21-000011:mdna:132]
We primarily finance our operations through cash flow from operations. As of December 25, 2020 and December 27, 2019, we had cash, cash equivalents, and short-term investments of $481.0 million and $442.8 million, respectively, and outstanding debt of $45.7 million and $57.9 million, respectively.

[0001408710-21-000011:mdna:133]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 0.9% for each of the three and six months ended December 25, 2020 and 2.0% for each of the three and six months ended December 27, 2019.

[0001408710-21-000011:mdna:134]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-21-000011:mdna:135]
During the six months ended December 25, 2020, we repaid $6.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of December 25, 2020, we had a long-term borrowing of $45.7 million under such credit facility agreement. (See Note 12 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $261.8 million as of December 25, 2020.

[0001408710-21-000011:mdna:136]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-21-000011:mdna:137]
[same as prior period, unchanged from 0001193125-20-284755:mdna:138]

[0001408710-21-000011:mdna:138]
[same as prior period, unchanged from 0001193125-20-284755:mdna:139]

[0001408710-21-000011:mdna:139]
|  | Six Months Ended |
| (amount in thousands) | December 25, 2020 |  | December 27, 2019 |
| Net cash provided by operating activities | $ | 41,314 |  |  | $ | 52,610 |  |
| Net cash used in investing activities | $ | (24,346) |  |  | $ | (5,731) |  |
| Net cash used in financing activities | $ | (23,629) |  |  | $ | (7,766) |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (6,661) |  |  | $ | 39,113 |  |

[0001408710-21-000011:mdna:140]
[same as prior period, unchanged from 0001193125-20-284755:mdna:141]

[0001408710-21-000011:mdna:141]
Net cash provided by operating activities decreased by $11.3 million, or 21.5%, to $41.3 million for the six months ended December 25, 2020, compared with net cash provided by operating activities of $52.6 million for the six months ended December 27, 2019. This decrease was primarily due to (1) an increase in change in inventories of $61.4 million, (2) a decrease in cash receipts related to the timing of collection of trade accounts receivable of $20.4 million, (3) an increase in change of other current assets and non-current assets of $19.5 million, and (4) an increase in change of contract assets of $4.3 million, offset by (1) a decrease of $68.0 million in payments to trade accounts payable, (2) an increase in change of other current liabilities and non-current liabilities of $19.3 million, and (3) an increase in net income of $11.2 million.

[0001408710-21-000011:mdna:142]
[same as prior period, unchanged from 0001193125-20-284755:mdna:143]

[0001408710-21-000011:mdna:143]
Net cash used in investing activities increased by $18.6 million, or 324.8%, to $24.3 million for the six months ended December 25, 2020, compared with net cash provided by investing activities of $5.7 million for the six months ended December 27, 2019. This increase was primarily due to (1) an increase in purchases of short-term investments, net of proceeds from sales and maturities of $34.0 million and (2) an increase in the purchase of property, plant and equipment and intangibles of $7.7 million, offset by funds provided to our customer in the amount of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand in the second quarter of fiscal year 2020.

[0001408710-21-000011:mdna:144]
[same as prior period, unchanged from 0001193125-20-284755:mdna:145]

[0001408710-21-000011:mdna:145]
Net cash used in financing activities increased by $15.9 million, or 204.3%, to $23.6 million for the six months ended December 25, 2020, compared with net cash used in financing activities of $7.8 million for the six months ended December 27, 2019. This increase was primarily due to (1) an increase of $7.1 million in payments to repurchase ordinary shares, (2) an increase in withholding tax related to net share settlement of restricted share units of $6.0 million, and (3) an increase of $3.0 million in net repayment of loans to a bank.

[0001408710-21-000011:mdna:146]
Off-Balance Sheet Commitments and Arrangements

[0001408710-21-000011:mdna:147]
As of December 25, 2020, we had one outstanding standby letter of credit of 6.0 million Euros related to our support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of December 25, 2020, the standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

[0001408710-21-000011:mdna:148]
[same as prior period, unchanged from 0001193125-20-284755:mdna:149]

[0001408710-21-000011:mdna:149]
[same as prior period, unchanged from 0001193125-20-284755:mdna:150]
