# FN 8-K — 0001408710-21-000008 filed 2021-02-01

## item codes, every 8-K on or before 2021-02-02

- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2021-02-02

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-21-000008:8k_2_02:1]
EX-99.1
2
fn-20201202xex991.htm
EX-99.1

[0001408710-21-000008:8k_2_02:2]
Document

[0001408710-21-000008:8k_2_02:3]
EX-99.1

[0001408710-21-000008:8k_2_02:4]
Exhibit 99.1

[0001408710-21-000008:8k_2_02:5]
Fabrinet Announces Second Quarter Fiscal Year 2021 Financial Results

[0001408710-21-000008:8k_2_02:6]
•Record Second Quarter Revenue of $453.8 million Exceeds Guidance

[0001408710-21-000008:8k_2_02:7]
•Record GAAP and Non-GAAP Net Income per Share Exceed Guidance

[0001408710-21-000008:8k_2_02:8]
BANGKOK, Thailand – February 1, 2021 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 25, 2020.

[0001408710-21-000008:8k_2_02:9]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We delivered record revenue and profitability that exceeded our guidance ranges in the second quarter. Newer programs helped drive revenue upside while margin improvement contributed to strong profitability in the quarter.”

[0001408710-21-000008:8k_2_02:10]
Grady continued, “Based on our anticipated growth, we have broken ground on construction for an additional building at our Chonburi campus. As we look ahead, we are optimistic that the third quarter will represent another record-breaking quarter for the company.”

[0001408710-21-000008:8k_2_02:11]
Second Quarter Fiscal Year 2021 Financial Highlights

[0001408710-21-000008:8k_2_02:12]
GAAP Results

[0001408710-21-000008:8k_2_02:13]
•Revenue for the second quarter of fiscal year 2021 was $453.8 million, compared to $426.2 million in the second quarter of fiscal year 2020.

[0001408710-21-000008:8k_2_02:14]
•GAAP net income for the second quarter of fiscal year 2021 was $35.4 million, compared to GAAP net income of $31.2 million for the second quarter of fiscal year 2020.

[0001408710-21-000008:8k_2_02:15]
•GAAP net income per diluted share for the second quarter of fiscal year 2021 was $0.94, compared to GAAP net income per diluted share of $0.83 for the second quarter of fiscal year 2020.

[0001408710-21-000008:8k_2_02:16]
Non-GAAP Results

[0001408710-21-000008:8k_2_02:17]
•Non-GAAP net income for the second quarter of fiscal year 2021 was $41.5 million, compared to non-GAAP net income of $37.7 million for the second quarter of fiscal year 2020.

[0001408710-21-000008:8k_2_02:18]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2021 was $1.10, compared to non-GAAP net income per diluted share of $1.00 for the second quarter of fiscal year 2020.

[0001408710-21-000008:8k_2_02:19]
Business Outlook

[0001408710-21-000008:8k_2_02:20]
Based on information available as of February 1, 2021, Fabrinet is issuing guidance for its third fiscal quarter ending March 26, 2021, as follows:

[0001408710-21-000008:8k_2_02:21]
•Fabrinet expects third quarter revenue to be in the range of $455 million to $475 million.

[0001408710-21-000008:8k_2_02:22]
•GAAP net income per diluted share is expected to be in the range of $0.94 to $1.01, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000008:8k_2_02:23]
•Non-GAAP net income per diluted share is expected to be in the range of $1.10 to $1.17, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000008:8k_2_02:24]
EX-99.1

[0001408710-21-000008:8k_2_02:25]
Conference Call Information

[0001408710-21-000008:8k_2_02:26]
| What: |  | Fabrinet Second Quarter Fiscal Year 2021 Financial Results Call |
| When: |  | Monday, February 1, 2021 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalPasscode: 3296178 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalPasscode: 3296178 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-21-000008:8k_2_02:27]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001408710-21-000008:8k_2_02:28]
About Fabrinet

[0001408710-21-000008:8k_2_02:29]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-21-000008:8k_2_02:30]
Forward-Looking Statements

[0001408710-21-000008:8k_2_02:31]
EX-99.1

[0001408710-21-000008:8k_2_02:32]
Use of Non-GAAP Financials

[0001408710-21-000008:8k_2_02:33]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-21-000008:8k_2_02:34]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-21-000008:8k_2_02:35]
SOURCE: Fabrinet

[0001408710-21-000008:8k_2_02:36]
Investor Contact:

[0001408710-21-000008:8k_2_02:37]
Garo Toomajanian

[0001408710-21-000008:8k_2_02:38]
ir@fabrinet.com

[0001408710-21-000008:8k_2_02:39]
EX-99.1

[0001408710-21-000008:8k_2_02:40]
FABRINET

[0001408710-21-000008:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-21-000008:8k_2_02:42]
| (in thousands of U.S. dollars, except share data and par value) | December 25,2020 |  | June 26,2020 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 219,221 |  |  | $ | 225,430 |  |
| Short-term restricted cash | 7,402 |  |  | 7,402 |  |
| Short-term investments | 261,817 |  |  | 262,693 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $123 and $336 respectively | 318,430 |  |  | 272,665 |  |
| Contract assets | 16,223 |  |  | 13,256 |  |
| Inventories | 371,996 |  |  | 309,786 |  |
| Other receivable | 24,310 |  |  | 24,310 |  |
| Prepaid expenses | 3,141 |  |  | 5,399 |  |
| Other current assets | 29,187 |  |  | 14,508 |  |
| Total current assets | 1,251,727 |  |  | 1,135,449 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 153 |  |  | — |  |
| Property, plant and equipment, net | 227,670 |  |  | 228,274 |  |
| Intangibles, net | 4,367 |  |  | 4,312 |  |
| Operating right-of-use assets | 7,271 |  |  | 8,068 |  |
| Deferred tax assets | 6,213 |  |  | 5,675 |  |
| Other non-current assets | 236 |  |  | 202 |  |
| Total non-current assets | 245,910 |  |  | 246,531 |  |
| Total Assets | 1,497,637 |  |  | 1,381,980 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | 12,156 |  |  | 12,156 |  |
| Trade accounts payable | 296,948 |  |  | 251,603 |  |
| Fixed assets payable | 7,748 |  |  | 15,127 |  |
| Contract liabilities | 1,804 |  |  | 1,556 |  |
| Operating lease liabilities, current portion | 2,277 |  |  | 1,979 |  |
| Income tax payable | 2,806 |  |  | 2,242 |  |
| Accrued payroll, bonus and related expenses | 17,633 |  |  | 19,265 |  |
| Accrued expenses | 14,504 |  |  | 8,979 |  |
| Other payables | 39,159 |  |  | 21,514 |  |
| Total current liabilities | 395,035 |  |  | 334,421 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 33,436 |  |  | 39,514 |  |
| Deferred tax liability | 4,592 |  |  | 4,729 |  |
| Operating lease liability, non-current portion | 4,737 |  |  | 5,873 |  |
| Severance liabilities | 19,011 |  |  | 17,379 |  |
| Other non-current liabilities | 4,156 |  |  | 5,655 |  |
| Total non-current liabilities | 65,932 |  |  | 73,150 |  |
| Total Liabilities | 460,967 |  |  | 407,571 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 25, 2020 and June 26, 2020) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,698,068 shares and 38,471,967 shares issued at December 25, 2020 and June 26, 2020, respectively; and 36,852,416 shares and 36,727,864 shares outstanding at December 25, 2020 and June 26, 2020, respectively) | 387 |  |  | 385 |  |
| Additional paid-in capital | 177,125 |  |  | 175,610 |  |
| Less: Treasury shares (1,845,652 shares and 1,744,103 shares as of December 25, 2020 and June 26, 2020, respectively) | (75,575) |  |  | (68,501) |  |
| Accumulated other comprehensive income (loss) | (1,657) |  |  | (1,147) |  |
| Retained earnings | 936,390 |  |  | 868,062 |  |
| Total Shareholders’ Equity | 1,036,670 |  |  | 974,409 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,497,637 |  |  | $ | 1,381,980 |  |

[0001408710-21-000008:8k_2_02:43]
The accompanying notes are an integral part of these unaudited condensed consolidated financial statements.

[0001408710-21-000008:8k_2_02:44]
EX-99.1

[0001408710-21-000008:8k_2_02:45]
FABRINET

[0001408710-21-000008:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-21-000008:8k_2_02:47]
(unaudited)

[0001408710-21-000008:8k_2_02:48]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Revenues | $ | 453,827 |  |  | $ | 426,217 |  |  | $ | 890,466 |  |  | $ | 825,513 |  |
| Cost of revenues | (400,806) |  |  | (377,059) |  |  | (786,965) |  |  | (730,368) |  |
| Gross profit | 53,021 |  |  | 49,158 |  |  | 103,501 |  |  | 95,145 |  |
| Selling, general and administrative expenses | (17,156) |  |  | (17,078) |  |  | (34,019) |  |  | (33,078) |  |
| Expenses related to reduction in workforce | — |  |  | (16) |  |  | — |  |  | (16) |  |
| Operating income | 35,865 |  |  | 32,064 |  |  | 69,482 |  |  | 62,051 |  |
| Interest income | 1,111 |  |  | 1,940 |  |  | 2,215 |  |  | 4,038 |  |
| Interest expense | (265) |  |  | (181) |  |  | (516) |  |  | (2,574) |  |
| Foreign exchange gain (loss), net | (533) |  |  | (988) |  |  | (405) |  |  | (2,941) |  |
| Other income (expense), net | 158 |  |  | 397 |  |  | 279 |  |  | 774 |  |
| Income before income taxes | 36,336 |  |  | 33,232 |  |  | 71,055 |  |  | 61,348 |  |
| Income tax expense | (952) |  |  | (2,001) |  |  | (2,620) |  |  | (4,160) |  |
| Net income | 35,384 |  |  | 31,231 |  |  | 68,435 |  |  | 57,188 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (42) |  |  | (82) |  |  | (367) |  |  | (47) |  |
| Change in net unrealized gain (loss) on derivative instruments | 2,385 |  |  | (189) |  |  | (823) |  |  | (150) |  |
| Change in net retirement benefits plan – prior service cost | 50 |  |  | 101 |  |  | 223 |  |  | 184 |  |
| Change in foreign currency translation adjustment | (146) |  |  | 616 |  |  | 457 |  |  | 247 |  |
| Total other comprehensive income (loss), net of tax | 2,247 |  |  | 446 |  |  | (510) |  |  | 234 |  |
| Net comprehensive income (loss) | $ | 37,631 |  |  | $ | 31,677 |  |  | $ | 67,925 |  |  | $ | 57,422 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.96 |  |  | $ | 0.84 |  |  | $ | 1.86 |  |  | $ | 1.55 |  |
| Diluted | $ | 0.94 |  |  | $ | 0.83 |  |  | $ | 1.83 |  |  | $ | 1.52 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,936 |  |  | 37,011 |  |  | 36,877 |  |  | 36,962 |  |
| Diluted | 37,551 |  |  | 37,763 |  |  | 37,467 |  |  | 37,646 |  |

[0001408710-21-000008:8k_2_02:49]
The accompanying notes are an integral part of these unaudited condensed consolidated financial statements.

[0001408710-21-000008:8k_2_02:50]
EX-99.1

[0001408710-21-000008:8k_2_02:51]
FABRINET

[0001408710-21-000008:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-21-000008:8k_2_02:53]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 25,2020 |  | December 27,2019 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 68,435 |  |  | $ | 57,188 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 17,650 |  |  | 15,279 |  |
| (Gain) loss on disposal of property, plant and equipment | (24) |  |  | 242 |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (86) |  |  | (79) |  |
| Amortization of investment discount | 1,003 |  |  | 117 |  |
| Amortization of deferred debt issuance costs | 16 |  |  | 10 |  |
| (Reversal of) allowance for doubtful accounts | (321) |  |  | 6 |  |
| Unrealized (gain) loss on exchange rate and fair value of foreign currency forward contracts | (290) |  |  | 1,205 |  |
| Unrealized loss (gain) on fair value of interest rate swaps | — |  |  | 1,672 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (695) |  |  | (433) |  |
| Share-based compensation | 11,878 |  |  | 12,183 |  |
| Deferred income tax | (461) |  |  | 1,543 |  |
| Other non-cash expenses | (657) |  |  | (851) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (45,410) |  |  | (24,970) |  |
| Contract assets | (2,967) |  |  | 1,333 |  |
| Inventories | (62,211) |  |  | (767) |  |
| Other current assets and non-current assets | (11,983) |  |  | 7,471 |  |
| Trade accounts payable | 45,179 |  |  | (22,816) |  |
| Contract liabilities | 248 |  |  | 121 |  |
| Income tax payable | 548 |  |  | 1,336 |  |
| Severance liabilities | 1,350 |  |  | 2,015 |  |
| Other current liabilities and non-current liabilities | 20,112 |  |  | 805 |  |
| Net cash provided by operating activities | 41,314 |  |  | 52,610 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (126,701) |  |  | (101,727) |  |
| Proceeds from sales of short-term investments | 57,486 |  |  | 72,664 |  |
| Proceeds from maturities of short-term investments | 68,807 |  |  | 62,666 |  |
| Funds provided to customer to support transfer of manufacturing operations | — |  |  | (24,310) |  |
| Purchase of property, plant and equipment | (22,693) |  |  | (15,411) |  |
| Purchase of intangibles | (1,271) |  |  | (808) |  |
| Proceeds from disposal of property, plant and equipment | 26 |  |  | 1,195 |  |
| Net cash used in investing activities | (24,346) |  |  | (5,731) |  |
| Cash flows from financing activities |  |  |  |
| Payment of debt issuance costs | — |  |  | (153) |  |
| Proceeds from long-term borrowings | — |  |  | 60,938 |  |
| Repayment of long-term borrowings | (6,094) |  |  | (63,985) |  |
| Repayment of finance lease liability | (100) |  |  | (189) |  |
| Repurchase of ordinary shares | (7,074) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units | (10,361) |  |  | (4,377) |  |
| Net cash used in financing activities | (23,629) |  |  | (7,766) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (6,661) |  |  | 39,113 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | 232,832 |  |  | 188,241 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (6,661) |  |  | 39,113 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 605 |  |  | 351 |  |
| Cash, cash equivalents and restricted cash at the end of period | 226,776 |  |  | 227,705 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 7,748 |  |  | $ | 14,307 |  |

[0001408710-21-000008:8k_2_02:54]
The accompanying notes are an integral part of these unaudited condensed consolidated financial statements.

[0001408710-21-000008:8k_2_02:55]
EX-99.1

[0001408710-21-000008:8k_2_02:56]
FABRINET

[0001408710-21-000008:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-21-000008:8k_2_02:58]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001408710-21-000008:8k_2_02:59]
|  | As of |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Cash and cash equivalents | $ | 219,221 |  |  | $ | 220,031 |  |
| Restricted cash | 7,555 |  |  | 7,674 |  |
| Cash, cash equivalents and restricted cash | $ | 226,776 |  |  | $ | 227,705 |  |

[0001408710-21-000008:8k_2_02:60]
EX-99.1

[0001408710-21-000008:8k_2_02:61]
FABRINET

[0001408710-21-000008:8k_2_02:62]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000008:8k_2_02:63]
|  | Three Months Ended |  | Six Months Ended |
|  | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 35,384 |  |  | $ | 0.94 |  |  | $ | 31,231 |  |  | $ | 0.83 |  |  | $ | 68,435 |  |  | $ | 1.83 |  |  | $ | 57,188 |  |  | $ | 1.52 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,592 |  |  | 0.04 |  |  | 1,591 |  |  | 0.04 |  |  | 3,417 |  |  | 0.09 |  |  | 3,311 |  |  | 0.09 |  |
| Depreciation of fair value uplift | 83 |  |  | — |  |  | 82 |  |  | — |  |  | 167 |  |  | — |  |  | 161 |  |  | — |  |
| Total related to gross profit | 1,675 |  |  | 0.04 |  |  | 1,673 |  |  | 0.04 |  |  | 3,584 |  |  | 0.10 |  |  | 3,472 |  |  | 0.09 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 4,259 |  |  | 0.11 |  |  | 4,597 |  |  | 0.12 |  |  | 8,461 |  |  | 0.23 |  |  | 8,872 |  |  | 0.24 |  |
| Amortization of intangibles | 124 |  |  | — |  |  | 143 |  |  | — |  |  | 255 |  |  | 0.01 |  |  | 286 |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses | 4,383 |  |  | 0.12 |  |  | 4,740 |  |  | 0.13 |  |  | 8,716 |  |  | 0.23 |  |  | 9,158 |  |  | 0.24 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | — |  |  | — |  |  | 16 |  |  | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |
| Amortization of deferred debt issuance costs | 8 |  |  | — |  |  | 8 |  |  | — |  |  | 16 |  |  | — |  |  | 10 |  |  | — |  |
| Total related to other incomes and other expenses | 8 |  |  | — |  |  | 24 |  |  | — |  |  | 16 |  |  | — |  |  | 26 |  |  | — |  |
| Total related to net income & EPS | 6,066 |  |  | 0.16 |  |  | 6,437 |  |  | 0.17 |  |  | 12,316 |  |  | 0.33 |  |  | 12,656 |  |  | 0.34 |  |
| Non-GAAP measures | $ | 41,450 |  |  | $ | 1.10 |  |  | $ | 37,668 |  |  | $ | 1.00 |  |  | $ | 80,751 |  |  | $ | 2.16 |  |  | $ | 69,844 |  |  | $ | 1.86 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,551 |  |  |  |  | 37,763 |  |  |  |  | 37,467 |  |  |  | 37,646 |
| Non-GAAP diluted shares |  |  | 37,551 |  |  |  |  | 37,763 |  |  |  |  | 37,467 |  |  |  | 37,646 |

[0001408710-21-000008:8k_2_02:64]
EX-99.1

[0001408710-21-000008:8k_2_02:65]
FABRINET

[0001408710-21-000008:8k_2_02:66]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-21-000008:8k_2_02:67]
| (amount in thousands) | Three Months Ended | Six Months Ended |
|  | December 25,2020 |  | December 27,2019 | December 25,2020 |  | December 27,2019 |
| Net cash provided by operating activities | $ | 6,808 |  |  | $ | 49,963 |  | $ | 41,314 |  |  | $ | 52,610 |  |
| Less: Purchase of property, plant and equipment | (10,121) |  |  | (9,068) |  | (22,693) |  |  | (15,411) |  |
| Non-GAAP free cash flow | $ | (3,313) |  |  | $ | 40,895 |  | $ | 18,621 |  |  | $ | 37,199 |  |

[0001408710-21-000008:8k_2_02:68]
FABRINET

[0001408710-21-000008:8k_2_02:69]
GUIDANCE FOR QUARTER ENDING MARCH 26, 2021

[0001408710-21-000008:8k_2_02:70]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000008:8k_2_02:71]
|  | DilutedEPS |
| GAAP net income per diluted share: | $0.94 to $1.01 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.12 |
| Total related to selling, general and administrative expenses | 0.12 |
| Total related to net income & EPS | 0.16 |
| Non-GAAP net income per diluted share | $1.10 to $1.17 |
