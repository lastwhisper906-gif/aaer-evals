# FN notes — 0001408710-21-000011


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-21-000011:notes:1]
Accounting policies
Basis of presentation

[0001408710-21-000011:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 25, 2020 and for the three and six months ended December 25, 2020 and December 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.

[0001408710-21-000011:notes:3]
The balance sheet as of June 26, 2020 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-21-000011:notes:4]
The results for the three and six months ended December 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.

[0001408710-21-000011:notes:5]
[same as prior period, unchanged from 0001193125-20-284755:notes:6]

[0001408710-21-000011:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

[0001408710-21-000011:notes:7]
[same as prior period, unchanged from 0001193125-20-284755:notes:8]

[0001408710-21-000011:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 25, 2020 and December 27, 2019 each consisted of 13 weeks. The six months ended December 25, 2020 and December 27, 2019 each consisted of 26 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.

[0001408710-21-000011:notes:9]
[same as prior period, unchanged from 0001193125-20-284755:notes:10]

[0001408710-21-000011:notes:10]
[same as prior period, unchanged from 0001193125-20-284755:notes:11]

[0001408710-21-000011:notes:11]
As of June 26, 2020, the derivative assets and liabilities were measured at fair value and recognized by offsetting the fair value amounts under master netting arrangements. Also, the Company chose not to separate a derivative into current and non-current portions as follows:

[0001408710-21-000011:notes:12]
(i)A derivative for which the fair value is a net liability is classified in total as current.

[0001408710-21-000011:notes:13]
(ii)A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is a liability, it is presented as a current liability.

[0001408710-21-000011:notes:14]
As of December 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

[0001408710-21-000011:notes:15]
[same as prior period, unchanged from 0001193125-20-284755:notes:16]

[0001408710-21-000011:notes:16]
|  | June 26, 2020 |
| (amount in thousands) | As previouslyreported |  | Reclassification |  | Afterreclassification |
| Consolidated Balance Sheet |  |  |  |  |  |
| Current assets |  |  |  |  |  |
| Other current assets | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |
| Accrued expenses | $ | 12,104 |  |  | $ | (3,125) |  |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |
| Other non-current liabilities | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |

[0001408710-21-000011:notes:17]
[same as prior period, unchanged from 0001193125-20-284755:notes:18]

[0001408710-21-000011:notes:18]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

[0001408710-21-000011:notes:19]
[same as prior period, unchanged from 0001193125-20-284755:notes:20]

[0001408710-21-000011:notes:20]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale

[0001408710-21-000011:notes:21]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.

[0001408710-21-000011:notes:22]
As of June 27, 2020, the Company recorded a cumulative adjustment from CECL in the amount of $0.1 million, net of tax impact, to accumulated retained earnings in the unaudited condensed consolidated balance sheet.

[0001408710-21-000011:notes:23]
On June 27, 2020, the Company also adopted ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This standard is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The Company adopted this standard with no impact on its unaudited condensed consolidated financial statements.

[0001408710-21-000011:notes:24]
[same as prior period, unchanged from 0001193125-20-284755:notes:26]

[0001408710-21-000011:notes:25]
[same as prior period, unchanged from 0001193125-20-284755:notes:27]

[0001408710-21-000011:notes:26]
[same as prior period, unchanged from 0001193125-20-284755:notes:28]

[0001408710-21-000011:notes:27]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three and six months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:notes:28]
[same as prior period, unchanged from 0001193125-20-284755:notes:30]

[0001408710-21-000011:notes:29]
[same as prior period, unchanged from 0001193125-20-284755:notes:31]

[0001408710-21-000011:notes:30]
[same as prior period, unchanged from 0001193125-20-284755:notes:32]

[0001408710-21-000011:notes:31]
[same as prior period, unchanged from 0001193125-20-284755:notes:33]

[0001408710-21-000011:notes:32]
[same as prior period, unchanged from 0001193125-20-284755:notes:34]

[0001408710-21-000011:notes:33]
[same as prior period, unchanged from 0001193125-20-284755:notes:35]

[0001408710-21-000011:notes:34]
[same as prior period, unchanged from 0001193125-20-284755:notes:36]

[0001408710-21-000011:notes:35]
[same as prior period, unchanged from 0001193125-20-284755:notes:37]

[0001408710-21-000011:notes:36]
[same as prior period, unchanged from 0001193125-20-284755:notes:38]

[0001408710-21-000011:notes:37]
[same as prior period, unchanged from 0001193125-20-284755:notes:39]

[0001408710-21-000011:notes:38]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, P-1, F1, or better.

[0001408710-21-000011:notes:39]
[same as prior period, unchanged from 0001193125-20-284755:notes:41]

[0001408710-21-000011:notes:40]
[same as prior period, unchanged from 0001193125-20-284755:notes:42]

[0001408710-21-000011:notes:41]
[same as prior period, unchanged from 0001193125-20-284755:notes:43]

[0001408710-21-000011:notes:42]
In December 2019, the FASB issued ASU2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-21-000011:notes:43]
Revenues from contracts with customers
Revenue by Geographic Area and End Market

[0001408710-21-000011:notes:44]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001408710-21-000011:notes:45]
[same as prior period, unchanged from 0001193125-20-284755:notes:50]

[0001408710-21-000011:notes:46]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America | $ | 224,672 |  |  | 49.5 | % |  | $ | 432,074 |  |  | 48.5 | % |
| Asia-Pacific | 153,734 |  |  | 33.9 |  |  | 299,380 |  |  | 33.6 |  |
| Europe | 75,421 |  |  | 16.6 |  |  | 159,012 |  |  | 17.9 |  |
|  | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

[0001408710-21-000011:notes:47]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| North America | $ | 223,398 |  |  | 52.4 | % |  | $ | 424,345 |  |  | 51.4 | % |
| Asia-Pacific | 141,147 |  |  | 33.1 |  |  | 259,570 |  |  | 31.4 |  |
| Europe | 61,672 |  |  | 14.5 |  |  | 141,598 |  |  | 17.2 |  |
|  | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

[0001408710-21-000011:notes:48]
The following table presents revenues by end market.

[0001408710-21-000011:notes:49]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 |  |  | 198,709 |  |  | 22.3 |  |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

[0001408710-21-000011:notes:50]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| Optical communications | $ | 322,068 |  |  | 75.6 | % |  | $ | 624,447 |  |  | 75.6 | % |
| Lasers, sensors and other | 104,149 |  |  | 24.4 |  |  | 201,066 |  |  | 24.4 |  |
| Total | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

[0001408710-21-000011:notes:51]
[same as prior period, unchanged from 0001193125-20-284755:notes:55]

[0001408710-21-000011:notes:52]
[same as prior period, unchanged from 0001193125-20-284755:notes:56]

[0001408710-21-000011:notes:53]
[same as prior period, unchanged from 0001193125-20-284755:notes:57]

[0001408710-21-000011:notes:54]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 25, 2020:

[0001408710-21-000011:notes:55]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 35,464 |  |
| Amounts collected or invoiced | (32,497) |  |
| Ending balance, December 25, 2020 | $ | 16,223 |  |

[0001408710-21-000011:notes:56]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Additions advance payment received during the period | 14,597 |  |
| Revenue recognized | (14,349) |  |
| Ending balance, December 25, 2020 | $ | 1,804 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-21-000011:notes:57]
Earnings per ordinary share
Basic earnings per ordinary share is computed by dividing reported net income by the weighted-average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the period using the treasury stock method. Dilutive ordinary equivalent shares consist of restricted share units and performance share units.

[0001408710-21-000011:notes:58]
[same as prior period, unchanged from 0001193125-20-284755:notes:64]

[0001408710-21-000011:notes:59]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands except per share amounts) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Net income attributable to shareholders | $ | 35,384 |  |  | $ | 31,231 |  |  | $ | 68,435 |  |  | $ | 57,188 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 36,936 |  |  | 37,011 |  |  | 36,877 |  |  | 36,962 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) | 615 |  |  | 752 |  |  | 590 |  |  | 684 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,551 |  |  | 37,763 |  |  | 37,467 |  |  | 37,646 |  |
| Basic earnings per ordinary share | $ | 0.96 |  |  | $ | 0.84 |  |  | $ | 1.86 |  |  | $ | 1.55 |  |
| Diluted earnings per ordinary share | $ | 0.94 |  |  | $ | 0.83 |  |  | $ | 1.83 |  |  | $ | 1.52 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | 91 |  |  | 50 |  |  | 91 |  |  | 50 |  |

[0001408710-21-000011:notes:60]
(1)These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-21-000011:notes:61]
Cash, cash equivalents and short-term investments
The Company’s cash, cash equivalents, and short-term investments are as follows:

[0001408710-21-000011:notes:62]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of December 25, 2020 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 211,314 |  |  | $ | — |  |  | $ | 211,314 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 7,907 |  |  | — |  |  | 7,907 |  |  | — |  |  | — |  |
| Liquidity funds | 41,245 |  |  | — |  |  | — |  |  | — |  |  | 41,245 |  |
| Certificates of deposit and time deposits | 20,500 |  |  | — |  |  | — |  |  | — |  |  | 20,500 |  |
| Corporate debt securities | 159,485 |  |  | 790 |  |  | — |  |  | 160,275 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 39,462 |  |  | 335 |  |  | — |  |  | 39,797 |  |  | — |  |
| Total | $ | 479,913 |  |  | $ | 1,125 |  |  | $ | 219,221 |  |  | $ | 200,072 |  |  | $ | 61,745 |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 218,117 |  |  | $ | — |  |  | $ | 218,117 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 7,313 |  |  | — |  |  | 7,313 |  |  | — |  |  | — |  |
| Liquidity funds | 41,051 |  |  | — |  |  | — |  |  | — |  |  | 41,051 |  |
| Certificates of deposit and time deposits | 11,800 |  |  | — |  |  | — |  |  | — |  |  | 11,800 |  |
| Corporate debt securities | 159,220 |  |  | 948 |  |  | — |  |  | 160,168 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 49,130 |  |  | 544 |  |  | — |  |  | 49,674 |  |  | — |  |
| Total | $ | 486,631 |  |  | $ | 1,492 |  |  | $ | 225,430 |  |  | $ | 209,842 |  |  | $ | 52,851 |  |

[0001408710-21-000011:notes:63]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-21-000011:notes:64]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 25, 2020 and June 26, 2020:

[0001408710-21-000011:notes:65]
|  | December 25, 2020 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 82,493 |  |  | $ | 82,508 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 116,454 |  |  | 117,564 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 198,947 |  |  | $ | 200,072 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-21-000011:notes:66]
Fair value of financial instruments
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-21-000011:notes:67]
[same as prior period, unchanged from 0001193125-20-284755:notes:77]

[0001408710-21-000011:notes:68]
[same as prior period, unchanged from 0001193125-20-284755:notes:78]

[0001408710-21-000011:notes:69]
[same as prior period, unchanged from 0001193125-20-284755:notes:79]

[0001408710-21-000011:notes:70]
[same as prior period, unchanged from 0001193125-20-284755:notes:80]

[0001408710-21-000011:notes:71]
[same as prior period, unchanged from 0001193125-20-284755:notes:81]

[0001408710-21-000011:notes:72]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 25, 2020 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 7,907 |  |  |  | $ | — |  |  | $ | 7,907 |  |
| Liquidity funds | — |  |  | 41,245 |  |  |  | — |  |  | 41,245 |  |
| Certificates of deposit and time deposits | — |  |  | 20,500 |  |  |  | — |  |  | 20,500 |  |
| Corporate debt securities | — |  |  | 160,275 |  |  |  | — |  |  | 160,275 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 39,797 |  |  |  | — |  |  | 39,797 |  |
| Derivative assets – current portion | — |  |  | 3,071 |  | (1) |  | — |  |  | 3,071 |  |
| Total | $ | — |  |  | $ | 272,795 |  |  |  | $ | — |  |  | $ | 272,795 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 1,676 |  |  |  | $ | — |  |  | $ | 1,676 |  |
| Derivative liabilities – non-current portion | — |  |  | 2,894 |  |  |  | — |  |  | 2,894 |  |
| Total | $ | — |  |  | $ | 4,570 |  | (2) |  | $ | — |  |  | $ | 4,570 |  |

[0001408710-21-000011:notes:73]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 7,313 |  |  |  | $ | — |  |  | $ | 7,313 |  |
| Liquidity funds | — |  |  | 41,051 |  |  |  | — |  |  | 41,051 |  |
| Certificates of deposit and time deposits | — |  |  | 11,800 |  |  |  | — |  |  | 11,800 |  |
| Corporate debt securities | — |  |  | 160,168 |  |  |  | — |  |  | 160,168 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 49,674 |  |  |  | — |  |  | 49,674 |  |
| Derivative assets | — |  |  | 2,823 |  | (3) |  | — |  |  | 2,823 |  |
| Total | $ | — |  |  | $ | 272,829 |  |  |  | $ | — |  |  | $ | 272,829 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 2,148 |  |  |  | $ | — |  |  | $ | 2,148 |  |
| Derivative liabilities – non-current portion | — |  |  | 3,718 |  |  |  | — |  |  | 3,718 |  |
| Total | $ | — |  |  | $ | 5,866 |  | (4) |  | $ | — |  |  | $ | 5,866 |  |

[0001408710-21-000011:notes:74]
(1)Foreign currency forward contracts with a notional amount of $130.0 million and Canadian dollars of 0.6 million.

[0001408710-21-000011:notes:75]
(2)Two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000011:notes:76]
(3)Foreign currency forward contracts with a notional amount of $125.0 million and Canadian dollars of 0.6 million, and option contract with a notional amount of $1.0 million.

[0001408710-21-000011:notes:77]
(4)Two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000011:notes:78]
[same as prior period, unchanged from 0001193125-20-284755:notes:88]

[0001408710-21-000011:notes:79]
[same as prior period, unchanged from 0001193125-20-284755:notes:89]

[0001408710-21-000011:notes:80]
[same as prior period, unchanged from 0001193125-20-284755:notes:90]

[0001408710-21-000011:notes:81]
[same as prior period, unchanged from 0001193125-20-284755:notes:91]

[0001408710-21-000011:notes:82]
[same as prior period, unchanged from 0001193125-20-284755:notes:92]

[0001408710-21-000011:notes:83]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-21-000011:notes:84]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures.

[0001408710-21-000011:notes:85]
Changes in the fair value of these non-designated derivatives are recorded through foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:notes:86]
As of December 25, 2020, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $130.0 million and maturity dates ranging from January 2021 through July 2021 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of Canadian dollars of 0.6 million and a maturity date in March 2021.

[0001408710-21-000011:notes:87]
As of June 26, 2020, the Company had 125 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $125.0 million, one foreign currency contract with notional amount of Canadian dollars 0.6 million and one foreign currency option contract with notional amount of $1.0 million with maturity dates ranging from July 2020 through January 2021.

[0001408710-21-000011:notes:88]
As of December 25, 2020, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 25, 2020, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $1.8 million.

[0001408710-21-000011:notes:89]
During the three and six months ended December 25, 2020, the Company recorded an unrealized gain of $1.8 million and $0.3 million from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:notes:90]
During the six months ended December 27, 2019, the Company recorded an unrealized loss of $1.9 million from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income. During the three months ended December 27, 2019, the amount was not material.

[0001408710-21-000011:notes:91]
[same as prior period, unchanged from 0001193125-20-284755:notes:108]

[0001408710-21-000011:notes:92]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of December 25, 2020 and June 26, 2020, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000011:notes:93]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 12). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-21-000011:notes:94]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 12) and on September 10, 2019, repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 12). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-21-000011:notes:95]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-21-000011:notes:96]
As of December 25, 2020, the amount in AOCI that is expected to be reclassified into earnings within 12 months is a loss of $0.6 million.

[0001408710-21-000011:notes:97]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the three and six months ended December 27, 2019, the Company recorded unrealized loss of nil and $1.7 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000011:notes:98]
[same as prior period, unchanged from 0001193125-20-284755:notes:118]

[0001408710-21-000011:notes:99]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | Financialstatementsline item |  | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Derivatives gain (loss)recognized in othercomprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | 3,149 |  |  | $ | — |  |  | $ | 809 |  |  | $ | — |  |
| Interest rate swaps | Othercomprehensiveincome |  | 386 |  |  | 243 |  |  | 743 |  |  | 282 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 3,535 |  |  | $ | 243 |  |  | $ | 1,552 |  |  | $ | 282 |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 337 |  |  | $ | — |  |  | $ | (1,720) |  |  | $ | — |  |
| Foreign currency forward contracts | SG&A |  | 14 |  |  | — |  |  | (73) |  |  | — |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (1,165) |  |  | — |  |  | 113 |  |  | — |  |
| Interest rate swaps | Interest expense |  | (336) |  |  | (432) |  |  | (695) |  |  | (432) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (1,150) |  |  | $ | (432) |  |  | $ | (2,375) |  |  | $ | (432) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 2,385 |  |  | $ | (189) |  |  | $ | (823) |  |  | $ | (150) |  |

[0001408710-21-000011:notes:100]
[same as prior period, unchanged from 0001193125-20-284755:notes:120]

[0001408710-21-000011:notes:101]
[same as prior period, unchanged from 0001193125-20-284755:notes:121]

[0001408710-21-000011:notes:102]
|  | December 25,2020 |  | June 26,2020 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 1,095 |  |  | $ | — |  |  | $ | 9 |  |  | $ | (611) |  |
| Interest rate swaps | — |  |  | — |  |  | — |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 1,976 |  |  | (140) |  |  | 2,814 |  |  | (83) |  |
| Interest rate swaps | — |  |  | (4,430) |  |  | — |  |  | (5,172) |  |
| Derivatives, gross balances | $ | 3,071 |  |  | $ | (4,570) |  |  | $ | 2,823 |  |  | $ | (5,866) |  |

[0001408710-21-000011:notes:103]
[same as prior period, unchanged from 0001193125-20-284755:notes:125]

[0001408710-21-000011:notes:104]
| Derivative Financial Instruments | Balance Sheet line item |
| Fair Value of Derivative Assets | Other current assets |
| Fair Value of Derivative Liabilities | Accrued expenses |
| Fair Value of Derivative Liabilities | Other non-current liabilities |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-21-000011:notes:105]
Inventories

[0001408710-21-000011:notes:106]
| (amount in thousands) | As of December 25,2020 |  | As of June 26,2020 |
| Raw materials | $ | 143,230 |  |  | $ | 141,522 |  |
| Work in progress | 177,881 |  |  | 136,344 |  |
| Finished goods | 30,194 |  |  | 17,950 |  |
| Goods in transit | 20,691 |  |  | 13,970 |  |
| Inventories | $ | 371,996 |  |  | $ | 309,786 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001408710-21-000011:notes:107]
Other receivable
On October 1, 2019, the Company provided funds in the amount of $24.3 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

[0001408710-21-000011:notes:108]
On October 1, 2020, the Company extended the payment terms of the funds and the accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension was granted in connection with the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds will be offset by the amount due to this customer for the purchases of certain inventories.
As of December 25, 2020, the Company recorded the $24.3 million funds as other receivable in the unaudited condensed consolidated balance sheet.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001408710-21-000011:notes:109]
Restricted cash
As of December 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of December 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

[0001408710-21-000011:notes:110]
As of December 25, 2020, the Company had long-term restricted cash of Renmibi 1.0 million related to bank guarantees of its subsidiary in China to support the subsidiary's operations. The bank guarantee was backed by cash collateral of $0.2 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-21-000011:notes:111]
LeasesThe Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, China, the U.S., the U.K. and Israel under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its ROU assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space between Fabritek and Fabrinet West.
Operating leases

[0001408710-21-000011:notes:112]
As of December 25, 2020, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-21-000011:notes:113]
| (amount in thousands) | As of December 25,2020 |  |
| 2021 (remaining six months) | $ | 1,285 |  |  |
| 2022 | 2,568 |  |  |
| 2023 | 2,448 |  |  |
| 2024 | 1,088 |  |  |
| 2025 | 30 |  |  |
| Total undiscounted lease payments | 7,419 |  |  |
| Less imputed interest | (405) |  |  |
| Total present value of lease liabilities | $ | 7,014 |  | (1) |

[0001408710-21-000011:notes:114]
(1)Included current portion of operating lease liabilities for the period ended December 25, 2020.

[0001408710-21-000011:notes:115]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the three and six months ended December 25, 2020 was $0.6 million and $1.2 million, respectively, and for the three and six months ended December 27, 2019 was $0.5 million and $1.0 million, respectively. Rental expense for short-term leases for the three and six months ended December 25, 2020 was $0.1 million and $0.2 million, respectively, and for the three and six months ended December 27, 2019 was not material.

[0001408710-21-000011:notes:116]
The following summarizes additional information related to the Company’s operating leases:

[0001408710-21-000011:notes:117]
|  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Weighted-average remaining lease term (in years) | 3.1 |  | 3.3 |
| Weighted-average discount rate | 3.7 | % |  | 3.7 | % |

[0001408710-21-000011:notes:118]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and six months ended December 25, 2020 and December 27, 2019:

[0001408710-21-000011:notes:119]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 667 |  |  | $ | 566 |  |  | $ | 1,261 |  |  | $ | 1,024 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 80 |  |  | $ | 100 |  |  | $ | 189 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 43 |  |  | $ | 1,373 |  |  | $ | 7,271 |  |  | $ | 7,558 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-21-000011:notes:120]
Intangibles
The following tables present details of the Company’s intangibles:

[0001408710-21-000011:notes:121]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of December 25, 2020 |  |  |  |  |  |  |  |
| Software | $ | 9,018 |  |  | $ | (6,100) |  |  | $ | — |  |  | $ | 2,918 |  |
| Customer relationships | 4,373 |  |  | (2,954) |  |  | 30 |  |  | 1,449 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 13,510 |  |  | $ | (9,173) |  |  | $ | 30 |  |  | $ | 4,367 |  |

[0001408710-21-000011:notes:122]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 26, 2020 |  |  |  |  |  |  |  |
| Software | $ | 8,317 |  |  | $ | (5,577) |  |  | $ | — |  |  | $ | 2,740 |  |
| Customer relationships | 4,373 |  |  | (2,691) |  |  | (110) |  |  | 1,572 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 12,809 |  |  | $ | (8,387) |  |  | $ | (110) |  |  | $ | 4,312 |  |

[0001408710-21-000011:notes:123]
The Company recorded amortization expense relating to intangibles of $0.5 million and $0.3 million for the three months ended December 25, 2020 and December 27, 2019, respectively, and $0.7 million and $0.6 million for the six months ended December 25, 2020 and December 27, 2019, respectively.

[0001408710-21-000011:notes:124]
[same as prior period, unchanged from 0001193125-20-284755:notes:149]

[0001408710-21-000011:notes:125]
| (years) | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Customer relationships | 4.3 |  | 4.6 |

[0001408710-21-000011:notes:126]
Based on the carrying amount of intangibles as of December 25, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-21-000011:notes:127]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 312 |  |
| 2022 | 1,215 |  |
| 2023 | 1,208 |  |
| 2024 | 924 |  |
| 2025 | 488 |  |
| Thereafter | 220 |  |
| Total | $ | 4,367 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-21-000011:notes:128]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-21-000011:notes:129]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 45,703 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (79) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 33,436 |  |  | $ | 39,514 |  |

[0001408710-21-000011:notes:130]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

[0001408710-21-000011:notes:131]
The movements of long-term borrowings for the six months ended December 25, 2020 and December 27, 2019 were as follows:

[0001408710-21-000011:notes:132]
|  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (6,094) |  |  | (63,985) |  |
| Closing balance | $ | 45,703 |  |  | $ | 57,891 |  |

[0001408710-21-000011:notes:133]
As of December 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-21-000011:notes:134]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 9,141 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 45,703 |  |

[0001408710-21-000011:notes:135]
Credit facility agreements:

[0001408710-21-000011:notes:136]
Bank of Ayudhya Public Company Limited

[0001408710-21-000011:notes:137]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of December 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-21-000011:notes:138]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

[0001408710-21-000011:notes:139]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be re-borrowed. During the three and six months ended December 25, 2020, the Company recorded $0.2 million and $0.4 million, respectively, of interest expense in connection with this term loan.

[0001408710-21-000011:notes:140]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-21-000011:notes:141]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-21-000011:notes:142]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-21-000011:notes:143]
At December 25, 2020, there was $45.7 million outstanding under the term loan.

[0001408710-21-000011:notes:144]
Bank of America, N.A.

[0001408710-21-000011:notes:145]
On May 22, 2014, the Company and a consortium of banks, entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001408710-21-000011:notes:146]
From time to time, the Company amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001408710-21-000011:notes:147]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three and six months ended December 27, 2019, the Company recorded $0.5 million of interest expense in connection with this term loan for both periods.

[0001408710-21-000011:notes:148]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-21-000011:notes:149]
Income taxes
As of December 25, 2020 and June 26, 2020, the liability for uncertain tax positions including accrued interest and penalties was $0.8 million and $1.5 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to interest on these positions.

[0001408710-21-000011:notes:150]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2015 to 2020 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-21-000011:notes:151]
The effective tax rate for the Company for the three months ended December 25, 2020 and December 27, 2019 was 3.0% and 4.9%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the second quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000011:notes:152]
The effective tax rate for the Company for the six months ended December 25, 2020 and December 27, 2019 was 3.7% and 5.0%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the first six months of fiscal year 2021 as compared to the same period in fiscal year 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-21-000011:notes:153]
Share-based compensation
Share-based compensation

[0001408710-21-000011:notes:154]
The grant date fair value of restricted share units and performance share units is based on the market value of Fabrinet's ordinary shares on the date of grant.

[0001408710-21-000011:notes:155]
The effect of recording share-based compensation expense for the three and six months ended December 25, 2020 and December 27, 2019 was as follows:

[0001408710-21-000011:notes:156]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 4,175 |  |  | $ | 4,186 |  |  | $ | 9,424 |  |  | $ | 8,584 |  |
| Performance share units | 1,676 |  |  | 2,002 |  |  | 2,454 |  |  | 3,599 |  |
| Total share-based compensation expense | 5,851 |  |  | 6,188 |  |  | 11,878 |  |  | 12,183 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 5,851 |  |  | $ | 6,188 |  |  | $ | 11,878 |  |  | $ | 12,183 |  |

[0001408710-21-000011:notes:157]
[same as prior period, unchanged from 0001193125-20-284755:notes:190]

[0001408710-21-000011:notes:158]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |  | December 25,2020 |  | December 27,2019 |
| Cost of revenue | $ | 1,592 |  |  | $ | 1,591 |  |  | $ | 3,417 |  |  | $ | 3,311 |  |
| Selling, general and administrative expense | 4,259 |  |  | 4,597 |  |  | 8,461 |  |  | 8,872 |  |
| Total share-based compensation expense | $ | 5,851 |  |  | $ | 6,188 |  |  | $ | 11,878 |  |  | $ | 12,183 |  |

[0001408710-21-000011:notes:159]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 25, 2020 and December 27, 2019.

[0001408710-21-000011:notes:160]
[same as prior period, unchanged from 0001193125-20-284755:notes:193]

[0001408710-21-000011:notes:161]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence.

[0001408710-21-000011:notes:162]
As of December 25, 2020, there were 261,899 restricted share units outstanding, 188,554 performance share units outstanding and 2,522,057 ordinary shares available for future grant under the 2020 Plan.

[0001408710-21-000011:notes:163]
As of December 25, 2020, there were 433,599 restricted share units outstanding and 238,474 performance share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-21-000011:notes:164]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of December 25, 2020, there were 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-21-000011:notes:165]
The 2020 Plan, 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001408710-21-000011:notes:166]
[same as prior period, unchanged from 0001193125-20-284755:notes:203]

[0001408710-21-000011:notes:167]
[same as prior period, unchanged from 0001193125-20-284755:notes:204]

[0001408710-21-000011:notes:168]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to non-employee directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001408710-21-000011:notes:169]
Performance share units granted to executives will vest, if at all, at the end of a two-year performance period based on the Company’s achievement of pre-defined performance criteria, which consist of revenue and non-GAAP operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001408710-21-000011:notes:170]
[same as prior period, unchanged from 0001193125-20-284755:notes:207]

[0001408710-21-000011:notes:171]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 216,776 |  |  | $ | 69.48 |  |
| Issued | (292,874) |  |  | $ | 43.75 |  |
| Forfeited | (13,997) |  |  | $ | 54.23 |  |
| Balance as of December 25, 2020 | 707,662 |  |  | $ | 54.95 |  |

[0001408710-21-000011:notes:172]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 800,751 |  |  | $ | 42.48 |  |
| Granted | 331,900 |  |  | $ | 49.78 |  |
| Issued | (264,275) |  |  | $ | 39.60 |  |
| Forfeited | (23,855) |  |  | $ | 42.09 |  |
| Balance as of December 27, 2019 | 844,521 |  |  | $ | 46.26 |  |

[0001408710-21-000011:notes:173]
[same as prior period, unchanged from 0001193125-20-284755:notes:210]

[0001408710-21-000011:notes:174]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | $ | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of December 25, 2020 | 427,028 |  |  | $ | 57.82 |  |

[0001408710-21-000011:notes:175]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 548,500 |  |  | $ | 40.97 |  |
| Granted | 238,474 |  |  | $ | 48.39 |  |
| Issued | — |  |  | — |  |
| Forfeited | (350,670) |  |  | $ | 36.99 |  |
| Balance as of December 27, 2019 | 436,304 |  |  | $ | 48.22 |  |

[0001408710-21-000011:notes:176]
The fair value of restricted share units and performance share units is based on the market value of Fabrinet's ordinary shares on the date of grant.

[0001408710-21-000011:notes:177]
As of December 25, 2020, there was $17.2 million and $12.1 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.5 years and 1.4 years, respectively.

[0001408710-21-000011:notes:178]
For the six months ended December 25, 2020 and December 27, 2019, the Company withheld an aggregate of 148,958 shares and 86,138 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee obligations for the applicable income and other employment taxes. For the six months ended December 25, 2020 and December 27, 2019, the Company then remitted cash of $10.4 million and $4.4 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-21-000011:notes:179]
Shareholders’ equity
Share capital

[0001408710-21-000011:notes:180]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001408710-21-000011:notes:181]
For the three and six months ended December 25, 2020, Fabrinet issued 17,409 and 226,101 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001408710-21-000011:notes:182]
For the three and six months ended December 27, 2019, Fabrinet issued 19,762 and 178,137 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001408710-21-000011:notes:183]
[same as prior period, unchanged from 0001193125-20-284755:notes:223]

[0001408710-21-000011:notes:184]
[same as prior period, unchanged from 0001193125-20-284755:notes:224]

[0001408710-21-000011:notes:185]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million. During the six months ended December 25, 2020, the Company repurchased 101,549 shares under the program at an average price per share of $69.64, totaling $7.1 million. As of December 25, 2020, the Company had a remaining authorization to purchase up to an additional $92.9 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-21-000011:notes:186]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 25, 2020 and December 27, 2019 were as follows:

[0001408710-21-000011:notes:187]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification adjustment | (289) |  |  | 1,552 |  |  | — |  |  | 457 |  |  | 1,720 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (78) |  |  | (2,375) |  |  | 223 |  |  | — |  |  | (2,230) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (367) |  |  | $ | (823) |  |  | $ | 223 |  |  | $ | 457 |  |  | $ | (510) |  |
| Balance as of December 25, 2020 | $ | 1,123 |  |  | $ | (221) |  |  | $ | (1,786) |  |  | $ | (773) |  |  | $ | (1,657) |  |

[0001408710-21-000011:notes:188]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2019 | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537) |  |  | $ | (833) |  |  | $ | (2,386) |  |
| Other comprehensive income before reclassification adjustment | (126) |  |  | (150) |  |  | 184 |  |  | 247 |  |  | 155 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 79 |  |  | — |  |  | — |  |  | — |  |  | 79 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (47) |  |  | $ | (150) |  |  | $ | 184 |  |  | $ | 247 |  |  | $ | 234 |  |
| Balance as of December 27, 2019 | $ | 905 |  |  | $ | (118) |  |  | $ | (2,353) |  |  | $ | (586) |  |  | $ | (2,152) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-21-000011:notes:189]
Commitments and contingencies
Letter of credit and Bank guarantees

[0001408710-21-000011:notes:190]
As of December 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of December 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.  This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

[0001408710-21-000011:notes:191]
As of December 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of December 25, 2020, the Company had an outstanding bank guarantee of its subsidiary in China to support the subsidiary's operations of Renmibi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. As of June 26, 2020, these bank guarantees were not material.

[0001408710-21-000011:notes:192]
Purchase obligations

[0001408710-21-000011:notes:193]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-21-000011:notes:194]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $515.5 million.

[0001408710-21-000011:notes:195]
Capital expenditure

[0001408710-21-000011:notes:196]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

[0001408710-21-000011:notes:197]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $10.1 million.

[0001408710-21-000011:notes:198]
Indemnification of directors and officers

[0001408710-21-000011:notes:199]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-21-000011:notes:200]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-21-000011:notes:201]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of December 25, 2020, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-21-000011:notes:202]
For the Company’s revenues by geographic region, see “Revenue by Geographic Area and End Market” in Note 3.

[0001408710-21-000011:notes:203]
As of December 25, 2020 and December 27, 2019, the Company had approximately $28.6 million and $30.0 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001408710-21-000011:notes:204]
[same as prior period, unchanged from 0001193125-20-284755:notes:247]

[0001408710-21-000011:notes:205]
The Company had four and three customers, respectively, that each contributed to 10% or more of its total trade accounts receivable as of December 25, 2020 and June 26, 2020.
