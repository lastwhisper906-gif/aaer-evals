# WDC MD&A — 0000106040-25-000008


## mdna

[0000106040-25-000008:mdna:1]
[same as prior period, unchanged from 0000106040-24-000040:mdna:1]

[0000106040-25-000008:mdna:2]
[same as prior period, unchanged from 0000106040-24-000040:mdna:2]

[0000106040-25-000008:mdna:3]
[same as prior period, unchanged from 0000106040-24-000040:mdna:3]

[0000106040-25-000008:mdna:4]
We are a leading developer, manufacturer, and provider of data storage devices and solutions based on both hard disk drive and NAND flash technologies. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful hard disk drives (“HDD”) and flash-based products (“Flash”) solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-25-000008:mdna:5]
[same as prior period, unchanged from 0000106040-24-000040:mdna:5]

[0000106040-25-000008:mdna:6]
[same as prior period, unchanged from 0000106040-24-000040:mdna:6]

[0000106040-25-000008:mdna:7]
[same as prior period, unchanged from 0000106040-24-000040:mdna:7]

[0000106040-25-000008:mdna:8]
[same as prior period, unchanged from 0000106040-24-000040:mdna:8]

[0000106040-25-000008:mdna:9]
On October 30, 2023, we announced that our Board of Directors had completed its strategic review of our business and, after evaluating a comprehensive range of alternatives, authorized us to pursue a plan to separate our HDD and Flash business units to create two independent, public companies, with Sandisk Corporation, currently a wholly owned subsidiary of the Company, holding our Flash business, and Western Digital focusing on our existing HDD business. We believe the separation will better position each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, and operate more efficiently with distinct capital structures. At the beginning of our second quarter of fiscal year 2025, we entered the soft-spin phase of our separation plan. The soft-spin phase represents the period when we begin testing critical processes and systems for each future HDD and Flash company to ensure that both are ready to operate independently at legal separation. We continue to make progress on the work required to execute the separation. The separation will be effected through a pro rata distribution of 80.1% of the outstanding shares of Sandisk Corporation to holders of the Company’s common stock as of February 12, 2025, the record date for the distribution. We expect the distribution to occur on or about February 21, 2025. However, completion of the planned separation is subject to certain conditions, and no assurance can be provided as to the timing of the distribution or that all conditions to the distribution will be met.

[0000106040-25-000008:mdna:10]
[same as prior period, unchanged from 0000106040-24-000040:mdna:10]

[0000106040-25-000008:mdna:11]
Macroeconomic factors such as inflation, changes in interest rates, and recession concerns softened demand for our products during the first half of 2024. As a result, we and our industry experienced a supply-demand imbalance, which resulted in reduced shipments and negatively impacted pricing during those periods. To adapt to these conditions, we implemented measures to reduce operating expenses and proactively manage supply and inventory to align with demand and improve our capital efficiency while continuing to deploy innovative products. These actions enabled us to scale back on capital expenditures, consolidate production lines, and reduce production, which resulted in incremental charges for employee termination, asset impairment, and charges for unabsorbed manufacturing overhead costs in HDD and Flash due to the underutilization of facilities as we temporarily scaled back production.

[0000106040-25-000008:mdna:12]
We have seen an improvement in the supply and demand dynamic in HDD, leading to improved revenues in the first half of fiscal 2025 from the comparable period in the prior year. However, in Flash, we are experiencing what we believe is a mid-cycle slowdown. We expect to incur charges for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity in the remainder of fiscal 2025 as we moderate production levels to align with demand in Flash. We anticipate that digital transformation, including the artificial intelligence data-cycle, will drive improved market conditions in both HDD and Flash in the long term.

[0000106040-25-000008:mdna:13]
[same as prior period, unchanged from 0000106040-24-000040:mdna:13]

[0000106040-25-000008:mdna:14]
[same as prior period, unchanged from 0000106040-24-000040:mdna:14]

[0000106040-25-000008:mdna:15]
As discussed in Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, on September 28, 2024, our wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) completed the sale of 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), our indirect wholly-owned subsidiary in our Flash business that owned our Flash manufacturing facility, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET. The transaction resulted in a pre-tax gain of $113 million.

[0000106040-25-000008:mdna:16]
Subsequent to and in connection with the SDSS sale, we entered into a five-year Supply Agreement with SDSS to purchase certain flash-based products with a minimum annual commitment of $550 million. As a result of this transaction, we expect to incur a modest reduction in annual operating expenses and a reduction in annual capital expenditures related to assembly and testing of flash-based products. We also anticipate that the transition to a contract manufacturing model through SDSS will result in a small increase in our annual cost of revenue for flash-based products.

[0000106040-25-000008:mdna:17]
[same as prior period, unchanged from 0000106040-24-000040:mdna:17]

[0000106040-25-000008:mdna:18]
As previously disclosed, we had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 27, 2024, we made payments aggregating $162 million for tax and interest with respect to years 2008 through 2015 and have no remaining liability as of December 27, 2024 related to all years from 2008 through 2015. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our “Results of Operations” below, as well as in Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, and in the “Short- and Long-term Liquidity – Unrecognized Tax Benefits” section below.

[0000106040-25-000008:mdna:19]
[same as prior period, unchanged from 0000106040-24-000040:mdna:19]

[0000106040-25-000008:mdna:20]
[same as prior period, unchanged from 0000106040-24-000040:mdna:20]

[0000106040-25-000008:mdna:21]
Second Quarter and First Half Overview

[0000106040-25-000008:mdna:22]
[same as prior period, unchanged from 0000106040-24-000040:mdna:22]

[0000106040-25-000008:mdna:23]
|  | Three Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 4,285 |  |  | 100.0 | % |  | $ | 3,032 |  |  | 100.0 | % |  | $ | 1,253 |  |  | 41 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,769 |  |  | 64.6 |  |  | 2,540 |  |  | 83.8 |  |  | 229 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,516 |  |  | 35.4 |  |  | 492 |  |  | 16.2 |  |  | 1,024 |  |  | 208 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 502 |  |  | 11.7 |  |  | 444 |  |  | 14.6 |  |  | 58 |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 238 |  |  | 5.6 |  |  | 198 |  |  | 6.5 |  |  | 40 |  |  | 20 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on business divestiture | (113) |  |  | (2.6) |  |  | — |  |  | — |  |  | (113) |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 44 |  |  | 1.0 |  |  | 36 |  |  | 1.2 |  |  | 8 |  |  | 22 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment and other | (7) |  |  | (0.2) |  |  | 24 |  |  | 0.8 |  |  | (31) |  |  | (129) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 664 |  |  | 15.5 |  |  | 702 |  |  | 23.2 |  |  | (38) |  |  | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 852 |  |  | 19.9 |  |  | (210) |  |  | (6.9) |  |  | 1,062 |  |  | 506 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 11 |  |  | 0.3 |  |  | 12 |  |  | 0.4 |  |  | (1) |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (95) |  |  | (2.2) |  |  | (108) |  |  | (3.6) |  |  | 13 |  |  | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (27) |  |  | (0.6) |  |  | 47 |  |  | 1.6 |  |  | (74) |  |  | (157) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (111) |  |  | (2.6) |  |  | (49) |  |  | (1.6) |  |  | (62) |  |  | 127 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 741 |  |  | 17.3 |  |  | (259) |  |  | (8.5) |  |  | 1,000 |  |  | 386 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 147 |  |  | 3.4 |  |  | 28 |  |  | 0.9 |  |  | 119 |  |  | 425 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 594 |  |  | 13.9 |  |  | (287) |  |  | (9.5) |  |  | 881 |  |  | 307 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  | 0.1 |  |  | 14 |  |  | 0.5 |  |  | (10) |  |  | (71) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: income attributable to preferred shareholders | 9 |  |  | 0.2 |  |  | — |  |  | — |  |  | 9 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 581 |  |  | 13.6 | % |  | $ | (301) |  |  | (9.9) | % |  | $ | 882 |  |  | 293 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-25-000008:mdna:24]
[same as prior period, unchanged from 0000106040-24-000040:mdna:24]

[0000106040-25-000008:mdna:25]
[same as prior period, unchanged from 0000106040-24-000040:mdna:25]

[0000106040-25-000008:mdna:26]
|  | Six Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 8,380 |  |  | 100.0 | % |  | $ | 5,782 |  |  | 100.0 | % |  | $ | 2,598 |  |  | 45 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 5,313 |  |  | 63.4 |  |  | 5,191 |  |  | 89.8 |  |  | 122 |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 3,067 |  |  | 36.6 |  |  | 591 |  |  | 10.2 |  |  | 2,476 |  |  | 419 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,021 |  |  | 12.2 |  |  | 875 |  |  | 15.1 |  |  | 146 |  |  | 17 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 480 |  |  | 5.7 |  |  | 405 |  |  | 7.0 |  |  | 75 |  |  | 19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on business divestiture | (113) |  |  | (1.3) |  |  | — |  |  | — |  |  | (113) |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 87 |  |  | 1.0 |  |  | 36 |  |  | 0.6 |  |  | 51 |  |  | 142 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Litigation matter | 3 |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment and other | (5) |  |  | (0.1) |  |  | 81 |  |  | 1.4 |  |  | (86) |  |  | (106) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 1,473 |  |  | 17.6 |  |  | 1,397 |  |  | 24.2 |  |  | 76 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 1,594 |  |  | 19.0 |  |  | (806) |  |  | (13.9) |  |  | 2,400 |  |  | 298 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 20 |  |  | 0.2 |  |  | 20 |  |  | 0.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (194) |  |  | (2.3) |  |  | (206) |  |  | (3.6) |  |  | 12 |  |  | (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (51) |  |  | (0.6) |  |  | 51 |  |  | 0.9 |  |  | (102) |  |  | (200) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (225) |  |  | (2.7) |  |  | (135) |  |  | (2.3) |  |  | (90) |  |  | 67 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 1,369 |  |  | 16.3 |  |  | (941) |  |  | (16.3) |  |  | 2,310 |  |  | 245 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 282 |  |  | 3.4 |  |  | 31 |  |  | 0.5 |  |  | 251 |  |  | 810 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 1,087 |  |  | 13.0 |  |  | (972) |  |  | (16.8) |  |  | 2,059 |  |  | 212 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: dividends allocated to preferred shareholders | 8 |  |  | 0.1 |  |  | 29 |  |  | 0.5 |  |  | (21) |  |  | (72) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: income attributable to preferred shareholders | 17 |  |  | 0.2 |  |  | — |  |  | — |  |  | 17 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 1,062 |  |  | 12.7 | % |  | $ | (1,001) |  |  | (17.3) | % |  | $ | 2,063 |  |  | 206 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-25-000008:mdna:27]
(1)    Percentages may not total due to rounding.

[0000106040-25-000008:mdna:28]
[same as prior period, unchanged from 0000106040-24-000040:mdna:26]

[0000106040-25-000008:mdna:29]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,409 |  |  | $ | 1,367 |  |  | $ | 4,620 |  |  | $ | 2,561 |  |
| Flash | 1,876 |  |  | 1,665 |  |  | 3,760 |  |  | 3,221 |  |
| Total net revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 929 |  |  | $ | 339 |  |  | $ | 1,772 |  |  | $ | 612 |  |
| Flash | 609 |  |  | 131 |  |  | 1,341 |  |  | (30) |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (26) |  |  | (26) |  |
| Amortization of licenses related to a litigation matter | (10) |  |  | — |  |  | (19) |  |  | — |  |
| Amortization of acquired intangible assets | — |  |  | (1) |  |  | (1) |  |  | (1) |  |
| Recovery from contamination incident | — |  |  | 36 |  |  | — |  |  | 36 |  |
| Total unallocated corporate items | (22) |  |  | 22 |  |  | (46) |  |  | 9 |  |
| Consolidated gross profit | $ | 1,516 |  |  | $ | 492 |  |  | $ | 3,067 |  |  | $ | 591 |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 38.6 | % |  | 24.8 | % |  | 38.4 | % |  | 23.9 | % |
| Flash | 32.5 | % |  | 7.9 | % |  | 35.7 | % |  | (0.9) | % |
| Consolidated gross margin | 35.4 | % |  | 16.2 | % |  | 36.6 | % |  | 10.2 | % |

[0000106040-25-000008:mdna:30]
[same as prior period, unchanged from 0000106040-24-000040:mdna:28]

[0000106040-25-000008:mdna:31]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,346 |  |  | $ | 1,071 |  |  | $ | 4,554 |  |  | $ | 1,943 |  |
| Client | 1,168 |  |  | 1,122 |  |  | 2,377 |  |  | 2,269 |  |
| Consumer | 771 |  |  | 839 |  |  | 1,449 |  |  | 1,570 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,995 |  |  | $ | 1,699 |  |  | $ | 3,832 |  |  | $ | 3,250 |  |
| Americas | 1,428 |  |  | 804 |  |  | 3,118 |  |  | 1,466 |  |
| Europe, Middle East and Africa | 862 |  |  | 529 |  |  | 1,430 |  |  | 1,066 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |

[0000106040-25-000008:mdna:32]
[same as prior period, unchanged from 0000106040-24-000040:mdna:45]

[0000106040-25-000008:mdna:33]
[same as prior period, unchanged from 0000106040-24-000040:mdna:30]

[0000106040-25-000008:mdna:34]
Comparison of Three and Six Months Ended December 27, 2024 to Three and Six Months Ended December 29, 2023

[0000106040-25-000008:mdna:35]
The increase in consolidated net revenue for the three and six months ended December 27, 2024 from the comparable periods in the prior year reflected increases in both HDD and Flash revenue as discussed in more detail below.

[0000106040-25-000008:mdna:36]
HDD revenue increased by 76% for the three months ended December 27, 2024 from the comparable period in the prior year, as a result of a 93% increase in exabytes sold, primarily from higher shipments of our high capacity enterprise drives, partially offset by an 8% decline in average selling prices per gigabyte primarily due to a shift in the product mix to larger capacity drives. HDD revenue increased by 80% for the six months ended December 27, 2024 from the comparable period in the prior year, as a result of a 99% increase in exabytes sold, partially offset by a 9% decline in average selling prices per gigabyte, driven by the same factors described for the three-month period.

[0000106040-25-000008:mdna:37]
Flash revenue increased by 13% for the three months ended December 27, 2024 from the comparable period in the prior year, reflecting a 14% increase in average selling prices per gigabyte primarily due to improved pricing as the supply-demand balance improved. Flash revenue increased by 17% for the six months ended December 27, 2024 from the comparable period in the prior year, resulting from a 26% increase in average selling prices per gigabyte, partially offset by a 7% decline in exabytes sold. The increase in average selling prices per gigabyte was attributable to the same factors described above for the three-month period while the decrease in exabytes sold for the period was driven by softer demand in the Client and Consumer end markets in the first three months of the year.

[0000106040-25-000008:mdna:38]
Cloud revenue increased by 119% for the three months ended December 27, 2024 from the comparable period in the prior year, reflecting a 114% increase in exabytes sold and a 4% increase in average selling prices per gigabyte. The increase in exabytes sold was driven by higher shipments of our high capacity enterprise HDD products stemming from new data center builds. The increase in average selling prices per gigabyte was primarily due to improved pricing in Flash as the supply-demand balance improved. Cloud revenue increased by 134% for the six months ended December 27, 2024 from the comparable period in the prior year, reflecting a 126% increase in exabytes sold and a 5% increase in average selling prices per gigabyte. The increase in exabytes sold and average selling prices per gigabyte are attributed to the same factors described for the three-month period.

[0000106040-25-000008:mdna:39]
Client revenue increased by 4% for the three months ended December 27, 2024 from the comparable period in the prior year, reflecting a 15% increase in average selling prices per gigabyte, partially offset by an 11% decrease in exabytes sold. The increase in average selling prices per gigabyte over the prior year period was primarily due to improved pricing in Flash, partially offset by a decline in pricing in HDD. The decline in exabytes sold reflected a near-term drop in demand for Flash products. Client revenue increased by 5% for the six months ended December 27, 2024 from the comparable period in the prior year, reflecting a 24% increase in average selling prices per gigabyte, partially offset by a 16% decrease in exabytes sold. The increase in average selling prices per gigabyte and the decline in exabytes sold over the prior year are attributed to the same factors described for the three-month period.

[0000106040-25-000008:mdna:40]
Consumer revenue declined by 8% for the three months ended December 27, 2024 from the comparable period in the prior year, reflecting a 5% decrease in exabytes sold and a 3% decline in average selling prices per gigabyte, which were driven by softer demand and pricing declines in both HDD and Flash products. Consumer revenue declined by 8% for the six months ended December 27, 2024 from the comparable period in the prior year, reflecting a 10% decrease in exabytes sold, partially offset by a 3% increase in average selling prices per gigabyte. The decrease in exabytes sold was primarily driven by softer demand in both HDD and Flash products in this end market. The increase in average selling prices per gigabyte was primarily due to improved pricing in both HDD and Flash from the improvement in the supply-demand balance in the first quarter of the year.

[0000106040-25-000008:mdna:41]
The changes in net revenue by geography for the three and six months ended December 27, 2024 from the comparable period in the prior year reflected higher revenue in the Americas region from Cloud customers as noted above.

[0000106040-25-000008:mdna:42]
Our top 10 customers accounted for 51% and 50% of our net revenue for the three and six months ended December 27, 2024, respectively, compared to 39% of our net revenue for both the three and six months ended December 29, 2023. For the three and six months ended December 27, 2024, one customer accounted for 14% of our net revenue. For the three and six months ended December 29, 2023, no single customer accounted for 10% or more of our net revenue.

[0000106040-25-000008:mdna:43]
[same as prior period, unchanged from 0000106040-24-000040:mdna:57]

[0000106040-25-000008:mdna:44]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 15% and 14% of gross revenue for the three and six months ended December 27, 2024 and 18% and 19% for the three and six months ended December 29, 2023, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix, and overall availability of products. The decrease in program amounts in the current period reflects the improved demand and pricing environment. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-25-000008:mdna:45]
[same as prior period, unchanged from 0000106040-24-000040:mdna:41]

[0000106040-25-000008:mdna:46]
Consolidated gross profit increased by $1.02 billion for the three months ended December 27, 2024 from the comparable period in the prior year, primarily due to higher product shipments, improved pricing, and favorable product mix. In addition, the prior year period included charges for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity of $156 million ($49 million in HDD and $107 million in Flash), which were not incurred in the current period. Consolidated gross margin increased by 19 percentage points year over year, mainly due to improved pricing and favorable product mix with approximately 5 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:47]
HDD gross margin for the three months ended December 27, 2024 increased by approximately 14 percentage points year over year, primarily due to higher product shipments with approximately 4 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:48]
Flash gross margin for the three months ended December 27, 2024 increased by approximately 25 percentage points year over year, primarily due to improved pricing and favorable product mix with approximately 6 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:49]
Consolidated gross profit increased by $2.48 billion for the six months ended December 27, 2024 from the comparable period in the prior year, primarily due to higher product shipments, improved pricing, and favorable product mix. In addition, the prior year period included charges for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity of $381 million ($132 million in HDD and $249 million in Flash), which were not incurred in the current period. Consolidated gross margin increased by approximately 26 percentage points year over year, mainly due to improved pricing and favorable product mix with approximately 7 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:50]
HDD gross margin for the six months ended December 27, 2024 increased by approximately 15 percentage points year over year, primarily due to higher product shipments with approximately 5 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:51]
Flash gross margin for the six months ended December 27, 2024 increased by approximately 37 percentage points year over year, primarily due to improved pricing and favorable product mix with approximately 8 percentage points of the increase due to the unabsorbed manufacturing overhead costs incurred in the prior year period but not incurred in the current period.

[0000106040-25-000008:mdna:52]
[same as prior period, unchanged from 0000106040-24-000040:mdna:46]

[0000106040-25-000008:mdna:53]
Research and development (“R&D”) expense increased by $58 million for the three months ended December 27, 2024 from the comparable period in the prior year. The increase was driven by a $39 million increase in compensation and benefits due to higher variable compensation and increased headcount and modest increases in spending for R&D projects as we continue to invest in innovation. R&D expense increased by $146 million for the six months ended December 27, 2024 from the comparable period in the prior year. The increase was primarily driven by a $95 million increase in compensation and benefits due to the same factors as the three-month period and a $36 million increase in material purchases, outside services, hardware and equipment spending due to an increase in spending for R&D projects as we continue to invest in innovation.

[0000106040-25-000008:mdna:54]
[same as prior period, unchanged from 0000106040-24-000040:mdna:63]

[0000106040-25-000008:mdna:55]
Selling, general and administrative (“SG&A”) expense increased by $40 million for the three months ended December 27, 2024 from the comparable period in the prior year. The increase was primarily driven by a $27 million increase in compensation and benefits, which was driven by higher variable compensation and increased headcount, a $9 million increase in legal fees, and a $5 million increase in material purchases, partially offset by a $20 million decrease in strategic review costs. SG&A expense increased by $75 million for the six months ended December 27, 2024 from the comparable period in the prior year. The increase was primarily driven by a $53 million increase in compensation and benefits, which was driven by higher variable compensation and increased headcount, a $19 million increase in legal fees, a $12 million increase in material purchases, and a modest increase in spending due to higher business volume, partially offset by a $37 million decrease in strategic review costs.

[0000106040-25-000008:mdna:56]
The gain on business divestiture was $113 million for both the three and six months ended December 27, 2024, which resulted from our sale of a majority interest in SDSS. For information regarding Gain on business divestiture, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-25-000008:mdna:57]
Employee termination, asset impairment and other was a gain of $7 million for the three months ended December 27, 2024 compared to a loss of $24 million in the prior year. The change was primarily due to a recovery from previously accrued contract termination charges and fewer restructuring actions taken in the current period. Employee termination, asset impairment and other was a gain of $5 million for the six months ended December 27, 2024 compared to a loss of $81 million in the prior year. The change was due to fewer restructuring actions taken in the current period. For information regarding Employee termination, asset impairment and other, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment and Other, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-25-000008:mdna:58]
Business separation costs increased by $8 million for the three months ended December 27, 2024 and by $51 million for the six months ended December 27, 2024 from the comparable periods in the prior year. The increases for the three- and six-month periods primarily reflected the increase in outside service fees to support the planned separation of our HDD and Flash businesses.

[0000106040-25-000008:mdna:59]
[same as prior period, unchanged from 0000106040-24-000040:mdna:51]

[0000106040-25-000008:mdna:60]
Total interest and other expense, net increased by $62 million for the three months ended December 27, 2024 from the comparable period in the prior year, reflecting a decrease in other income, net of $74 million, driven by a $62 million decrease in gains on our strategic investments. Total interest and other expense, net increased by $90 million for the six months ended December 27, 2024 from the comparable period in the prior year, primarily reflecting a decrease in other income, net of $102 million, driven by a $59 million decrease in gains on our strategic investments and a $24 million increase in foreign exchange transaction losses.

[0000106040-25-000008:mdna:61]
[same as prior period, unchanged from 0000106040-24-000040:mdna:53]

[0000106040-25-000008:mdna:62]
Beginning in 2023, the Tax Cuts and Jobs Act (the “2017 Act”) has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in our effective tax rate for the three and six months ended December 27, 2024 and December 29, 2023. The tax effects related to the capitalization of R&D expenses had a material impact on our effective tax rate for the three and six months ended December 27, 2024 but did not have a material impact on the effective tax rate for the three and six months ended December 29, 2023.

[0000106040-25-000008:mdna:63]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant changes to laws related to tax, climate, energy, and health care. The tax measures include, among other things, a Corporate Alternative Minimum Tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The CAMT is effective for us beginning with fiscal year 2024. We do not expect to be subject to the CAMT of 15% for fiscal year 2025 as our annual average AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-25-000008:mdna:64]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of the Pillar Two, some of which are effective for us in fiscal year 2025. For fiscal year 2025, we currently expect to be able to meet certain transitional safe harbors and do not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in fiscal year 2026, there may be material increases in our future tax obligations in certain jurisdictions.

[0000106040-25-000008:mdna:65]
[same as prior period, unchanged from 0000106040-24-000040:mdna:74]

[0000106040-25-000008:mdna:66]
[same as prior period, unchanged from 0000106040-24-000040:mdna:58]

[0000106040-25-000008:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | $ in millions |
| Income (loss) before taxes | $ | 741 |  | $ | (259) |  | $ | 1,369 |  | $ | (941) |
| Income tax expense | 147 |  | 28 |  | 282 |  | 31 |
| Effective tax rate | 20% |  | (11)% |  | 21% |  | (3)% |

[0000106040-25-000008:mdna:68]
The relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during years 2025 through 2031 resulted in decreases to our effective tax rate below the U.S. Federal statutory rate for the three and six months ended December 27, 2024. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in our effective tax rate being closer to the U.S. Federal statutory rate for the three and six months ended December 27, 2024.

[0000106040-25-000008:mdna:69]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 29, 2023 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for the six months ended December 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-25-000008:mdna:70]
[same as prior period, unchanged from 0000106040-24-000040:mdna:62]

[0000106040-25-000008:mdna:71]
47

[0000106040-25-000008:mdna:72]
[same as prior period, unchanged from 0000106040-24-000040:mdna:64]

[0000106040-25-000008:mdna:73]
[same as prior period, unchanged from 0000106040-24-000040:mdna:65]

[0000106040-25-000008:mdna:74]
|  | Six Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 437 |  |  | $ | (718) |  |  |  |
| Investing activities | 78 |  |  | 24 |  |  |  |
| Financing activities | (103) |  |  | 1,151 |  |  |  |
| Effect of exchange rate changes on cash | — |  |  | 1 |  |  |  |
| Net increase in cash and cash equivalents | $ | 412 |  |  | $ | 458 |  |  |  |

[0000106040-25-000008:mdna:75]
We had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024 also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 27, 2024, the Company made payments of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of December 27, 2024 related to all years from 2008 through 2015.

[0000106040-25-000008:mdna:76]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $166 million. Of this amount, $65 million of interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules. See Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-25-000008:mdna:77]
[same as prior period, unchanged from 0000106040-24-000040:mdna:69]

[0000106040-25-000008:mdna:78]
[same as prior period, unchanged from 0000106040-24-000040:mdna:70]

[0000106040-25-000008:mdna:79]
We believe our cash and cash equivalents and our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended June 28, 2024.

[0000106040-25-000008:mdna:80]
A total of $1.60 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of December 27, 2024 and June 28, 2024, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-25-000008:mdna:81]
[same as prior period, unchanged from 0000106040-24-000040:mdna:73]

[0000106040-25-000008:mdna:82]
[same as prior period, unchanged from 0000106040-24-000040:mdna:75]

[0000106040-25-000008:mdna:83]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $1.04 billion for the six months ended December 27, 2024, as compared to $102 million for the six months ended December 29, 2023, which largely reflects an increase in the volume of our business, as discussed above.

[0000106040-25-000008:mdna:84]
[same as prior period, unchanged from 0000106040-24-000040:mdna:77]

[0000106040-25-000008:mdna:85]
|  | Three Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  |  |  |  |
| Days sales outstanding | 55 |  |  | 46 |  |  |  |  |  |
| Days in inventory | 112 |  |  | 115 |  |  |  |  |  |
| Days payable outstanding | (66) |  |  | (63) |  |  |  |  |  |
| Cash conversion cycle | 101 |  |  | 98 |  |  |  |  |  |

[0000106040-25-000008:mdna:86]
[same as prior period, unchanged from 0000106040-24-000040:mdna:79]

[0000106040-25-000008:mdna:87]
For the three months ended December 27, 2024, DSO increased by 9 days from the comparable period in the prior year, of which 3 days reflected an increase from lower trade accounts receivable factoring and the remainder reflected the timing of shipments and customer collections. DIO decreased by 3 days from the comparable period in the prior year, primarily reflecting higher consumption of inventory driven by strong demand in HDD, partially offset by weaker shipments in Flash, in the current period. DPO increased by 3 days from the comparable period in the prior year primarily due to more favorable payment terms and routine variations in the timing of purchases and payments during the period.

[0000106040-25-000008:mdna:88]
[same as prior period, unchanged from 0000106040-24-000040:mdna:81]

[0000106040-25-000008:mdna:89]
Net cash provided by investing activities for the six months ended December 27, 2024 primarily consisted of $191 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $92 million in net proceeds from activity related to Flash Ventures, partially offset by $208 million in capital expenditures, net of proceeds from disposals of assets. Net cash provided by investing activities for the six months ended December 29, 2023 primarily consisted of $79 million in proceeds from net activity related to Flash Ventures and $26 million of proceeds from net activity related to strategic investments, partially offset by $81 million in capital expenditures, net of proceeds from disposals of assets, which includes the proceeds from the sale-leaseback of our Milpitas, California facility.

[0000106040-25-000008:mdna:90]
[same as prior period, unchanged from 0000106040-24-000040:mdna:83]

[0000106040-25-000008:mdna:91]
During the six months ended December 27, 2024, net cash used in financing activities primarily consisted of $225 million for repayment of amounts borrowed under the revolving credit facility and scheduled repayments on the Term Loan A-2 and $80 million for taxes paid on vested stock awards under employee stock plans, partially offset by $150 million of proceeds from drawing on the revolving credit facility and $52 million of proceeds from the issuance of stock under employee stock plans. During the six months ended December 29, 2023, net cash provided by financing activities primarily consisted of $2.20 billion in proceeds from the issuance of the 2028 Convertible Notes and the drawdown of our delayed draw term loan, partially offset by $505 million used to repurchase a portion of the 2024 Convertible Notes, $338 million in repayments of our delayed draw term loan and Term Loan A-2 maturing 2027, and $155 million for the purchase of capped calls to hedge the potential dilution impact of the conversion feature of the 2028 Convertible Notes.

[0000106040-25-000008:mdna:92]
[same as prior period, unchanged from 0000106040-24-000040:mdna:85]

[0000106040-25-000008:mdna:93]
Other than the Flash Ventures related commitments incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity – Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures, our venture with SDSS, and our venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-25-000008:mdna:94]
50

[0000106040-25-000008:mdna:95]
[same as prior period, unchanged from 0000106040-24-000040:mdna:88]

[0000106040-25-000008:mdna:96]
[same as prior period, unchanged from 0000106040-24-000040:mdna:89]

[0000106040-25-000008:mdna:97]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of December 27, 2024. In addition, see the discussions further below related to unrecognized tax benefits, litigation matters, dividend rights with respect to the Series A Preferred Stock, foreign exchange contracts and indemnifications.

[0000106040-25-000008:mdna:98]
|  | Total |  | 1 Year (Remaining Six Months of 2025) |  | 2-3 Years (2026-2027) |  | 4-5 Years (2028-2029) |  | More than 5 Years (Beyond 2029) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,413 |  |  | $ | 1,675 |  |  | $ | 4,738 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 848 |  |  | 173 |  |  | 496 |  |  | 132 |  |  | 47 |  |
| Flash Ventures related commitments(2) | 4,442 |  |  | 1,318 |  |  | 2,196 |  |  | 715 |  |  | 213 |  |
| Operating leases | 485 |  |  | 31 |  |  | 118 |  |  | 81 |  |  | 255 |  |
| Purchase obligations and other commitments | 3,066 |  |  | 112 |  |  | 1,154 |  |  | 1,140 |  |  | 660 |  |
| Mandatory deemed repatriation tax | 331 |  |  | — |  |  | 331 |  |  | — |  |  | — |  |
| Total | $ | 16,585 |  |  | $ | 3,309 |  |  | $ | 9,033 |  |  | $ | 2,568 |  |  | $ | 1,675 |  |

[0000106040-25-000008:mdna:99]
[same as prior period, unchanged from 0000106040-24-000040:mdna:92]

[0000106040-25-000008:mdna:100]
[same as prior period, unchanged from 0000106040-24-000040:mdna:93]

[0000106040-25-000008:mdna:101]
[same as prior period, unchanged from 0000106040-24-000040:mdna:94]

[0000106040-25-000008:mdna:102]
As of December 27, 2024, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $688 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of December 27, 2024 was $72 million. Of these amounts, approximately $594 million could result in potential cash payments. As of December 27, 2024, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-25-000008:mdna:103]
As noted above, we had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024 also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 27, 2024, we made payments of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of December 27, 2024 related to all years from 2008 through 2015.

[0000106040-25-000008:mdna:104]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $166 million. Of this amount, $65 million of interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-25-000008:mdna:105]
51

[0000106040-25-000008:mdna:106]
Litigation Matters

[0000106040-25-000008:mdna:107]
For additional information on the litigation matters, see Part I, Item 1, Note 16, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-25-000008:mdna:108]
[same as prior period, unchanged from 0000106040-24-000040:mdna:101]

[0000106040-25-000008:mdna:109]
As of December 27, 2024, 235,000 shares of our Series A Preferred Stock remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended June 28, 2024 and Part I, Item 1, Note 11, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0000106040-25-000008:mdna:110]
[same as prior period, unchanged from 0000106040-24-000040:mdna:103]

[0000106040-25-000008:mdna:111]
As described in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, the Company issued $1.60 billion aggregate principal amount of convertible senior notes in November 2023, which bear interest at an annual rate of 3.00% and mature on November 15, 2028 (the “2028 Convertible Notes”). The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-25-000008:mdna:112]
The sale price conditional conversion feature of the 2028 Convertible Notes was not triggered during the calendar quarter ended December 31, 2024 and, accordingly, the holders of the 2028 Convertible Notes no longer have the right to convert the notes during the succeeding calendar quarter ending March 31, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of December 27, 2024. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

[0000106040-25-000008:mdna:113]
In addition to our outstanding debt, as of December 27, 2024, we had $2.25 billion available for borrowing under our revolving credit facility maturing in January 2027, subject to customary conditions under the loan agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. The loan agreements governing our revolving credit facility and our Term Loan A-2 maturing 2027 require us to comply with a financial leverage ratio covenant. As of December 27, 2024, we were in compliance with the financial covenant. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Debt, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 28, 2024 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-25-000008:mdna:114]
In connection with the planned separation of our HDD and Flash business units, we expect to enter into an amendment with our existing lenders under the loan agreements governing our Term Loan A-2 and the revolving credit facility maturing in January 2027, which amendment would permit the separation and, upon the consummation of the separation, reduce the commitments under the revolving credit facility, facilitate a potential future debt for equity exchange with respect to the term loan facility and adjust certain exceptions set forth therein. No assurance can be given that we will be able to enter into the amendment on our anticipated timeline or that we will be able to do so on acceptable terms or at all.

[0000106040-25-000008:mdna:115]
52

[0000106040-25-000008:mdna:116]
[same as prior period, unchanged from 0000106040-24-000040:mdna:108]

[0000106040-25-000008:mdna:117]
[same as prior period, unchanged from 0000106040-24-000040:mdna:109]

[0000106040-25-000008:mdna:118]
[same as prior period, unchanged from 0000106040-24-000040:mdna:110]

[0000106040-25-000008:mdna:119]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Current assets | $ | 1,962 |  |  | $ | 2,149 |  |
| Non-current assets | 2,456 |  |  | 2,208 |  |
| Net intercompany receivables from non-guarantor subsidiaries | 623 |  |  | 2,473 |  |
| Current liabilities | 1,426 |  |  | 3,758 |  |
| Non-current liabilities | 7,878 |  |  | 6,626 |  |

[0000106040-25-000008:mdna:120]
[same as prior period, unchanged from 0000106040-24-000040:mdna:112]

[0000106040-25-000008:mdna:121]
|  | Six Months Ended |  | Year Ended |
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Net sales | $ | 2,905 |  |  | $ | 4,066 |  |
| Gross profit | 1,141 |  |  | 1,002 |  |
| Operating income (loss) | 255 |  |  | (927) |  |
| Net income (loss) | 52 |  |  | (1,211) |  |

[0000106040-25-000008:mdna:122]
[same as prior period, unchanged from 0000106040-24-000040:mdna:114]

[0000106040-25-000008:mdna:123]
|  | Six Months Ended |  | Year Ended |
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Intercompany revenue | $ | 597 |  |  | $ | 1,416 |  |
| Net intercompany interest (income) expense | (2) |  |  | 8 |  |
| Intercompany dividend income | 539 |  |  | 567 |  |

[0000106040-25-000008:mdna:124]
[same as prior period, unchanged from 0000106040-24-000040:mdna:135]

[0000106040-25-000008:mdna:125]
[same as prior period, unchanged from 0000106040-24-000040:mdna:116]

[0000106040-25-000008:mdna:126]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of December 27, 2024, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-25-000008:mdna:127]
[same as prior period, unchanged from 0000106040-24-000040:mdna:118]

[0000106040-25-000008:mdna:128]
[same as prior period, unchanged from 0000106040-24-000040:mdna:119]

[0000106040-25-000008:mdna:129]
[same as prior period, unchanged from 0000106040-24-000040:mdna:120]

[0000106040-25-000008:mdna:130]
As of December 27, 2024, our estimated mandatory deemed repatriation tax obligation was $331 million and was expected to be paid within the next twelve months.

[0000106040-25-000008:mdna:131]
[same as prior period, unchanged from 0000106040-24-000040:mdna:123]

[0000106040-25-000008:mdna:132]
[same as prior period, unchanged from 0000106040-24-000040:mdna:124]

[0000106040-25-000008:mdna:133]
[same as prior period, unchanged from 0000106040-24-000040:mdna:125]

[0000106040-25-000008:mdna:134]
[same as prior period, unchanged from 0000106040-24-000040:mdna:126]

[0000106040-25-000008:mdna:135]
[same as prior period, unchanged from 0000106040-24-000040:mdna:127]

[0000106040-25-000008:mdna:136]
[same as prior period, unchanged from 0000106040-24-000040:mdna:128]

[0000106040-25-000008:mdna:137]
[same as prior period, unchanged from 0000106040-24-000040:mdna:129]

[0000106040-25-000008:mdna:138]
[same as prior period, unchanged from 0000106040-24-000040:mdna:130]

[0000106040-25-000008:mdna:139]
[same as prior period, unchanged from 0000106040-24-000040:mdna:131]

[0000106040-25-000008:mdna:140]
[same as prior period, unchanged from 0000106040-24-000040:mdna:132]

[0000106040-25-000008:mdna:141]
[same as prior period, unchanged from 0000106040-24-000040:mdna:133]

[0000106040-25-000008:mdna:142]
[same as prior period, unchanged from 0000106040-24-000040:mdna:134]

[0000106040-25-000008:mdna:143]
55
