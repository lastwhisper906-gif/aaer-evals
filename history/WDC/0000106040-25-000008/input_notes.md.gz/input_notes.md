# WDC notes — 0000106040-25-000008


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-25-000008:notes:1]
[same as prior period, unchanged from 0000106040-24-000040:notes:1]

[0000106040-25-000008:notes:2]
[same as prior period, unchanged from 0000106040-24-000040:notes:2]

[0000106040-25-000008:notes:3]
[same as prior period, unchanged from 0000106040-24-000040:notes:3]

[0000106040-25-000008:notes:4]
[same as prior period, unchanged from 0000106040-24-000040:notes:4]

[0000106040-25-000008:notes:5]
[same as prior period, unchanged from 0000106040-24-000040:notes:5]

[0000106040-25-000008:notes:6]
[same as prior period, unchanged from 0000106040-24-000040:notes:6]

[0000106040-25-000008:notes:7]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: hard disk drives (“HDD”) and flash-based products (“Flash”).

[0000106040-25-000008:notes:8]
[same as prior period, unchanged from 0000106040-24-000040:notes:8]

[0000106040-25-000008:notes:9]
[same as prior period, unchanged from 0000106040-24-000040:notes:9]

[0000106040-25-000008:notes:10]
[same as prior period, unchanged from 0000106040-24-000040:notes:10]

[0000106040-25-000008:notes:11]
[same as prior period, unchanged from 0000106040-24-000040:notes:11]

[0000106040-25-000008:notes:12]
[same as prior period, unchanged from 0000106040-24-000040:notes:12]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-25-000008:notes:13]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-25-000008:notes:14]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations” (“ASU 2022-04”), which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. As required by ASU 2022-04, the Company began to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024. ASU 2022-04 also requires the Company to provide certain annual rollforward information related to those obligations, which will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company will provide this disclosure in its Annual Report on Form 10-K for the year ended June 27, 2025. ASU 2022-04 does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. See Note 15, Supplier Finance Program for information regarding the supplier finance program.

[0000106040-25-000008:notes:15]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-25-000008:notes:16]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. The new guidance requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement within continuing operations in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This standard is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently compiling the information required for these disclosures, assessing the basis of adoption and expects to adopt the guidance for annual reporting periods in its annual report for the year ending June 30, 2028.

[0000106040-25-000008:notes:17]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures” (“ASU 2023-07”), which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. ASU 2023-07 expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company is currently assessing these reporting requirements and expects to provide any required disclosures at the required time.

[0000106040-25-000008:notes:18]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” (“ASU 2023-09”). ASU 2023-09 calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 26, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-25-000008:notes:19]
[same as prior period, unchanged from 0000106040-24-000040:notes:18]

[0000106040-25-000008:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,409 |  |  | $ | 1,367 |  |  | $ | 4,620 |  |  | $ | 2,561 |  |
| Flash | 1,876 |  |  | 1,665 |  |  | 3,760 |  |  | 3,221 |  |
| Total net revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 929 |  |  | $ | 339 |  |  | $ | 1,772 |  |  | $ | 612 |  |
| Flash | 609 |  |  | 131 |  |  | 1,341 |  |  | (30) |  |
| Total gross profit for segments | 1,538 |  |  | 470 |  |  | 3,113 |  |  | 582 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (26) |  |  | (26) |  |
| Amortization of licenses related to a litigation matter | (10) |  |  | — |  |  | (19) |  |  | — |  |
| Amortization of acquired intangible assets | — |  |  | (1) |  |  | (1) |  |  | (1) |  |
| Recovery from contamination incident | — |  |  | 36 |  |  | — |  |  | 36 |  |
| Total unallocated corporate items | (22) |  |  | 22 |  |  | (46) |  |  | 9 |  |
| Consolidated gross profit | $ | 1,516 |  |  | $ | 492 |  |  | $ | 3,067 |  |  | $ | 591 |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 38.6 | % |  | 24.8 | % |  | 38.4 | % |  | 23.9 | % |
| Flash | 32.5 | % |  | 7.9 | % |  | 35.7 | % |  | (0.9) | % |
| Consolidated gross margin | 35.4 | % |  | 16.2 | % |  | 36.6 | % |  | 10.2 | % |

[0000106040-25-000008:notes:21]
[same as prior period, unchanged from 0000106040-24-000040:notes:20]

[0000106040-25-000008:notes:22]
[same as prior period, unchanged from 0000106040-24-000040:notes:21]

[0000106040-25-000008:notes:23]
[same as prior period, unchanged from 0000106040-24-000040:notes:22]

[0000106040-25-000008:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,346 |  |  | $ | 1,071 |  |  | $ | 4,554 |  |  | $ | 1,943 |  |
| Client | 1,168 |  |  | 1,122 |  |  | 2,377 |  |  | 2,269 |  |
| Consumer | 771 |  |  | 839 |  |  | 1,449 |  |  | 1,570 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,995 |  |  | $ | 1,699 |  |  | $ | 3,832 |  |  | $ | 3,250 |  |
| Americas | 1,428 |  |  | 804 |  |  | 3,118 |  |  | 1,466 |  |
| Europe, Middle East and Africa | 862 |  |  | 529 |  |  | 1,430 |  |  | 1,066 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |

[0000106040-25-000008:notes:25]
The Company’s top 10 customers accounted for 51% and 50% of its net revenue for the three and six months ended December 27, 2024, respectively, and 39% of its net revenue for both the three and six months ended December 29, 2023. For the three and six months ended December 27, 2024, one customer accounted for 14% of the Company’s net revenue. No customer accounted for 10% or more of the Company’s net revenue for the three and six months ended December 29, 2023.

[0000106040-25-000008:notes:26]
[same as prior period, unchanged from 0000106040-24-000040:notes:25]

[0000106040-25-000008:notes:27]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed goodwill impairment assessments for each segment and concluded there were no indications of impairment for the periods presented. The following table provides a summary of goodwill activity for the period:

[0000106040-25-000008:notes:28]
|  | HDD |  | Flash |  | Total |
|  | (in millions) |
| Balance at June 28, 2024 | $ | 4,319 |  |  | $ | 5,713 |  |  | $ | 10,032 |  |
| Divestiture (1) | — |  |  | (303) |  |  | (303) |  |
| Balance at December 27, 2024 | $ | 4,319 |  |  | $ | 5,410 |  |  | $ | 9,729 |  |

[0000106040-25-000008:notes:29]
(1)     On September 28, 2024, the Company sold a majority interest in a subsidiary. See further discussion in Note 9, Related Parties and Related Commitments and Contingencies.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-25-000008:notes:30]
[same as prior period, unchanged from 0000106040-24-000040:notes:29]

[0000106040-25-000008:notes:31]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. There were no trade accounts receivable sold during the six months ended December 27, 2024. During the six months ended December 29, 2023, the Company sold trade accounts receivable aggregating to $392 million. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no factored receivables outstanding as of December 27, 2024 and June 28, 2024.

[0000106040-25-000008:notes:32]
[same as prior period, unchanged from 0000106040-24-000040:notes:31]

[0000106040-25-000008:notes:33]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,916 |  |  | $ | 1,727 |  |
| Work-in-process | 957 |  |  | 1,066 |  |
| Finished goods | 547 |  |  | 549 |  |
| Total inventories | $ | 3,420 |  |  | $ | 3,342 |  |

[0000106040-25-000008:notes:34]
[same as prior period, unchanged from 0000106040-24-000040:notes:33]

[0000106040-25-000008:notes:35]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 235 |  |  | $ | 235 |  |
| Buildings and improvements | 1,806 |  |  | 1,820 |  |
| Machinery and equipment | 7,889 |  |  | 8,646 |  |
| Computer equipment and software | 469 |  |  | 471 |  |
| Furniture and fixtures | 51 |  |  | 54 |  |
| Construction-in-process | 683 |  |  | 797 |  |
| Property, plant and equipment, gross | 11,133 |  |  | 12,023 |  |
| Accumulated depreciation | (8,203) |  |  | (8,856) |  |
| Property, plant and equipment, net | $ | 2,930 |  |  | $ | 3,167 |  |

[0000106040-25-000008:notes:36]
[same as prior period, unchanged from 0000106040-24-000040:notes:35]

[0000106040-25-000008:notes:37]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of December 27, 2024 and June 28, 2024, IPR&D included in intangible assets, net was $72 million. During the three and six months ended December 27, 2024 and December 29, 2023, the Company did not record any impairment charges related to IPR&D.

[0000106040-25-000008:notes:38]
[same as prior period, unchanged from 0000106040-24-000040:notes:37]

[0000106040-25-000008:notes:39]
[same as prior period, unchanged from 0000106040-24-000040:notes:38]

[0000106040-25-000008:notes:40]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 160 |  |  | $ | 218 |  |  | $ | 189 |  |  | $ | 244 |  |  |  |
| Charges to operations | 33 |  |  | 26 |  |  | 58 |  |  | 48 |  |  |  |
| Utilization | (22) |  |  | (40) |  |  | (59) |  |  | (83) |  |  |  |
| Changes in estimate related to pre-existing warranties | (6) |  |  | (2) |  |  | (23) |  |  | (7) |  |  |  |
| Warranty accrual, end of period | $ | 165 |  |  | $ | 202 |  |  | $ | 165 |  |  | $ | 202 |  |  |  |

[0000106040-25-000008:notes:41]
[same as prior period, unchanged from 0000106040-24-000040:notes:40]

[0000106040-25-000008:notes:42]
|  | December 27,2024 |  | June 28,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 57 |  |  | $ | 36 |  |  |  |  |  |  |  |
| Long-term portion | 108 |  |  | 153 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 165 |  |  | $ | 189 |  |  |  |  |  |  |  |

[0000106040-25-000008:notes:43]
[same as prior period, unchanged from 0000106040-24-000040:notes:42]

[0000106040-25-000008:notes:44]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | — |  |  | $ | 201 |  |
| Non-current portion of unrecognized tax benefits | 590 |  |  | 565 |  |
| Other non-current liabilities | 598 |  |  | 604 |  |
| Total other liabilities | $ | 1,188 |  |  | $ | 1,370 |  |

[0000106040-25-000008:notes:45]
[same as prior period, unchanged from 0000106040-24-000040:notes:44]

[0000106040-25-000008:notes:46]
[same as prior period, unchanged from 0000106040-24-000040:notes:45]

[0000106040-25-000008:notes:47]
|  | Actuarial Pension Gains |  | Foreign Currency Translation Adjustment |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 28, 2024 | $ | 14 |  |  | $ | (505) |  |  |  |  | $ | (221) |  |  | $ | (712) |  |
| Other comprehensive income (loss) before reclassifications | — |  |  | 21 |  |  |  |  | (40) |  |  | (19) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  | 114 |  |  | 114 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | — |  |  |  |  | (16) |  |  | (16) |  |
| Net current-period other comprehensive income | — |  |  | 21 |  |  |  |  | 58 |  |  | 79 |  |
| Balance at December 27, 2024 | $ | 14 |  |  | $ | (484) |  |  |  |  | $ | (163) |  |  | $ | (633) |  |

[0000106040-25-000008:notes:48]
During the three and six months ended December 27, 2024, the amounts reclassified out of AOCL were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0000106040-25-000008:notes:49]
As of December 27, 2024, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-25-000008:notes:50]
[same as prior period, unchanged from 0000106040-24-000040:notes:55]

[0000106040-25-000008:notes:51]
[same as prior period, unchanged from 0000106040-24-000040:notes:56]

[0000106040-25-000008:notes:52]
[same as prior period, unchanged from 0000106040-24-000040:notes:57]

[0000106040-25-000008:notes:53]
[same as prior period, unchanged from 0000106040-24-000040:notes:58]

[0000106040-25-000008:notes:54]
[same as prior period, unchanged from 0000106040-24-000040:notes:59]

[0000106040-25-000008:notes:55]
[same as prior period, unchanged from 0000106040-24-000040:notes:60]

[0000106040-25-000008:notes:56]
|  | December 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 745 |  |  | $ | — |  |  | $ | — |  |  | $ | 745 |  |
| Foreign exchange contracts | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total assets at fair value | $ | 745 |  |  | $ | 23 |  |  | $ | — |  |  | $ | 768 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 156 |  |  | $ | — |  |  | $ | 156 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 156 |  |  | $ | — |  |  | $ | 156 |  |

[0000106040-25-000008:notes:57]
[same as prior period, unchanged from 0000106040-24-000040:notes:62]

[0000106040-25-000008:notes:58]
[same as prior period, unchanged from 0000106040-24-000040:notes:63]

[0000106040-25-000008:notes:59]
[same as prior period, unchanged from 0000106040-24-000040:notes:64]

[0000106040-25-000008:notes:60]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2025 and the fourth quarter of 2024, respectively.

[0000106040-25-000008:notes:61]
|  | December 27, 2024 |  | June 28, 2024 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,297 |  |  | $ | 2,279 |  |  | $ | 2,296 |  |  | $ | 2,253 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,505 |  |  | 2,487 |  |  | 2,578 |  |  | 2,539 |  |
| 3.00% convertible notes due 2028 | 1,571 |  |  | 2,155 |  |  | 1,568 |  |  | 2,556 |  |
| 2.85% senior notes due 2029 | 497 |  |  | 445 |  |  | 496 |  |  | 434 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 418 |  |  | 496 |  |  | 407 |  |
| Total | $ | 7,366 |  |  | $ | 7,784 |  |  | $ | 7,434 |  |  | $ | 8,189 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-25-000008:notes:62]
Derivative Instruments and Hedging Activities
As of December 27, 2024, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of December 27, 2024, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-25-000008:notes:63]
Changes in fair values of the non-designated foreign exchange contracts were recognized in Other income (expense), net and were largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three and six months ended December 27, 2024 and December 29, 2023, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-25-000008:notes:64]
[same as prior period, unchanged from 0000106040-24-000040:notes:69]

[0000106040-25-000008:notes:65]
[same as prior period, unchanged from 0000106040-24-000040:notes:70]

[0000106040-25-000008:notes:66]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 27, 2024 and June 28, 2024, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-25-000008:notes:67]
Debt
Debt consisted of the following:

[0000106040-25-000008:notes:68]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,513 |  |  | 2,588 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,413 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,366 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (150) |  |  | (1,750) |  |
| Long-term debt | $ | 7,216 |  |  | $ | 5,684 |  |

[0000106040-25-000008:notes:69]
During the three and six months ended December 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 27, 2024 was 6.107%.

[0000106040-25-000008:notes:70]
During the six months ended December 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). As of December 27, 2024, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $2.25 billion as of that date.

[0000106040-25-000008:notes:71]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with a financial leverage ratio covenant. As of December 27, 2024, the Company was in compliance with the financial covenant.

[0000106040-25-000008:notes:72]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

[0000106040-25-000008:notes:73]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-25-000008:notes:74]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended December 31, 2024 and accordingly, the holders of the 2028 Convertible Notes no longer have the right to convert the notes during the succeeding calendar quarter ending March 31, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of December 27, 2024. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

[0000106040-25-000008:notes:75]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-25-000008:notes:76]
[same as prior period, unchanged from 0000106040-24-000040:notes:82]

[0000106040-25-000008:notes:77]
[same as prior period, unchanged from 0000106040-24-000040:notes:83]

[0000106040-25-000008:notes:78]
[same as prior period, unchanged from 0000106040-24-000040:notes:84]

[0000106040-25-000008:notes:79]
|  | December 27,2024 |  | June 28,2024 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 247 |  |  | $ | 244 |  |  |  |
| Fair value of plan assets at end of period | 179 |  |  | 184 |  |  |  |
| Unfunded status | $ | 68 |  |  | $ | 60 |  |  |  |

[0000106040-25-000008:notes:80]
[same as prior period, unchanged from 0000106040-24-000040:notes:86]

[0000106040-25-000008:notes:81]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Current liabilities (included in Accrued expenses) | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities (included in Other liabilities) | 67 |  |  | 59 |  |
| Net amount recognized | $ | 68 |  |  | $ | 60 |  |

[0000106040-25-000008:notes:82]
Net periodic benefit costs were immaterial for the three and six months ended December 27, 2024 and December 29, 2023.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-25-000008:notes:83]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-25-000008:notes:84]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-25-000008:notes:85]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-25-000008:notes:86]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 44 |  |  | 149 |  |
| Investment in Flash Alliance | 111 |  |  | 216 |  |
| Investment in Flash Forward | 123 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 861 |  |  | $ | 991 |  |

[0000106040-25-000008:notes:87]
The Company made net payments to Flash Ventures for purchased flash-based memory wafers and net loans of $1.1 billion and $2.0 billion during the three and six months ended December 27, 2024, respectively, and $0.8 billion and $1.8 billion during the three and six months ended December 29, 2023, respectively.

[0000106040-25-000008:notes:88]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-25-000008:notes:89]
As of December 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $252 million and $313 million, respectively.

[0000106040-25-000008:notes:90]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-25-000008:notes:91]
|  | December 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 583 |  |
| Equity investments | 278 |  |
| Operating lease guarantees | 1,343 |  |
| Inventory and prepayments | 1,393 |  |
| Maximum estimable loss exposure | $ | 3,597 |  |

[0000106040-25-000008:notes:92]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-25-000008:notes:93]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three and six months ended December 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 27, 2024.

[0000106040-25-000008:notes:94]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of December 27, 2024, $944 million remains to be credited against future building depreciation charges. As of December 27, 2024, the Company is also committed to make additional building depreciation prepayments of $303 million, based on the Japanese yen to U.S. dollar exchange rate of 157.86 as of such date, payable as follows: $60 million for the remainder of fiscal year 2025, $30 million in fiscal year 2026, $111 million in fiscal year 2027, $89 million in fiscal year 2028 and $13 million in fiscal year 2029. As of December 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $107 million at varying dates through fiscal year 2035.

[0000106040-25-000008:notes:95]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-25-000008:notes:96]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-25-000008:notes:97]
Off-Balance Sheet Liabilities

[0000106040-25-000008:notes:98]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-25-000008:notes:99]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024.

[0000106040-25-000008:notes:100]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 212 |  |  | $ | 1,343 |  |

[0000106040-25-000008:notes:101]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024:

[0000106040-25-000008:notes:102]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2025 |  | $ | 201 |  |  | $ | 49 |  |  | $ | 250 |  |
| 2026 |  | 406 |  |  | 113 |  |  | 519 |  |
| 2027 |  | 198 |  |  | 97 |  |  | 295 |  |
| 2028 |  | 83 |  |  | 93 |  |  | 176 |  |
| 2029 |  | 25 |  |  | 50 |  |  | 75 |  |
| 2030 |  | 4 |  |  | 24 |  |  | 28 |  |
| Total guarantee obligations |  | $ | 917 |  |  | $ | 426 |  |  | $ | 1,343 |  |

[0000106040-25-000008:notes:103]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-25-000008:notes:104]
Unis Venture

[0000106040-25-000008:notes:105]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 27, 2024, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both December 27, 2024 and June 28, 2024, respectively.

[0000106040-25-000008:notes:106]
Sale of a Majority Interest in a Subsidiary

[0000106040-25-000008:notes:107]
In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies in its flash-based products, on September 28, 2024, the Company’s wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) completed the sale of 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), the Company’s indirect wholly-owned subsidiary in its Flash business that owned its Flash manufacturing facility, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

[0000106040-25-000008:notes:108]
Proceeds from the sale, including working capital adjustments, are $659 million pre-tax. On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive remaining pre-tax proceeds of $187 million in five installments of approximately $37 million on September 28 of each year through September 28, 2029. As of December 27, 2024, the outstanding consideration receivable was recognized at its present value of $370 million, with $243 million within Other current assets and $127 million within Other non-current assets in the Condensed Consolidated Balance Sheets. The present value discount of $27 million as of December 27, 2024 will be accreted using the effective interest method to Interest income in the Condensed Consolidated Statements of Operations over the next five years.

[0000106040-25-000008:notes:109]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS will be recognized one quarter in arrears and will be reported in Other net income (expense), net in the Condensed Consolidated Statements of Operations.

[0000106040-25-000008:notes:110]
The Transaction resulted in a pre-tax gain of $113 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $303 million of goodwill allocated to SDSS.

[0000106040-25-000008:notes:111]
Subsequent to and in connection with the SDSS sale, the Company entered into a five-year Supply Agreement with SDSS to purchase certain flash-based products with a minimum annual commitment of $550 million (“the minimum annual commitment”). The Supply Agreement contains specific penalties the Company must pay if SDSS’s revenue fails to meet the minimum annual commitment. The Supply Agreement also provides that if SDSS’s revenue is higher than the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company a true-up amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by any of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the six months ended December 27, 2024, the Company made purchases of $111 million under the Supply Agreement and had an account payable balance due to SDSS of $117 million as of December 27, 2024.

[0000106040-25-000008:notes:112]
The Company also entered into a Transaction Services Agreement (“TSA”) to provide certain transitional services for one year following the closing of the Transaction. Charges under the TSA were not material.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-25-000008:notes:113]
[same as prior period, unchanged from 0000106040-24-000040:notes:112]

[0000106040-25-000008:notes:114]
[same as prior period, unchanged from 0000106040-24-000040:notes:113]

[0000106040-25-000008:notes:115]
[same as prior period, unchanged from 0000106040-24-000040:notes:114]

[0000106040-25-000008:notes:116]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 321 |  |  | $ | 326 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 45 |  |  | 42 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 298 |  |  | 307 |  |
| Total operating lease liabilities | $ | 343 |  |  | $ | 349 |  |

[0000106040-25-000008:notes:117]
[same as prior period, unchanged from 0000106040-24-000040:notes:116]

[0000106040-25-000008:notes:118]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Cost of operating leases | $ | 17 |  |  | $ | 17 |  |  | $ | 33 |  |  | $ | 31 |  |
| Cash paid for operating leases | 14 |  |  | 17 |  |  | 31 |  |  | 32 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 8 |  |  | 9 |  |  | 19 |  |  | 177 |  |

[0000106040-25-000008:notes:119]
[same as prior period, unchanged from 0000106040-24-000040:notes:118]

[0000106040-25-000008:notes:120]
|  | December 27,2024 |  | June 28,2024 |  |  |
| Weighted average remaining lease term in years | 10.1 |  | 10.4 |  |  |
| Weighted average discount rate | 6.6 | % |  | 6.6 | % |  |  |

[0000106040-25-000008:notes:121]
As of December 27, 2024, minimum lease payments were as follows:

[0000106040-25-000008:notes:122]
|  | Lease Amounts |
|  | (in millions) |
| Remaining six months of 2025 | $ | 31 |  |
| 2026 | 63 |  |
| 2027 | 55 |  |
| 2028 | 44 |  |
| 2029 | 37 |  |
| Thereafter | 255 |  |
| Total future minimum lease payments | 485 |  |
| Less: imputed interest | 142 |  |
| Present value of lease liabilities | $ | 343 |  |

[0000106040-25-000008:notes:123]
[same as prior period, unchanged from 0000106040-24-000040:notes:122]

[0000106040-25-000008:notes:124]
[same as prior period, unchanged from 0000106040-24-000040:notes:123]

[0000106040-25-000008:notes:125]
[same as prior period, unchanged from 0000106040-24-000040:notes:124]

[0000106040-25-000008:notes:126]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of December 27, 2024, the Company had the following minimum long-term commitments:

[0000106040-25-000008:notes:127]
|  | Long-Term Commitments |
|  | (in millions) |
| Remaining six months of 2025 | $ | 112 |  |
| 2026 | 541 |  |
| 2027 | 613 |  |
| 2028 | 570 |  |
| 2029 | 570 |  |
| Thereafter | 660 |  |
| Total | $ | 3,066 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-25-000008:notes:128]
[same as prior period, unchanged from 0000106040-24-000040:notes:127]

[0000106040-25-000008:notes:129]
[same as prior period, unchanged from 0000106040-24-000040:notes:128]

[0000106040-25-000008:notes:130]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |  |
|  | (in millions) |
| RSUs and PSUs | $ | 71 |  |  | $ | 68 |  |  | $ | 143 |  |  | $ | 133 |  |  |
| ESPP | 6 |  |  | 4 |  |  | 18 |  |  | 16 |  |  |
| Total | $ | 77 |  |  | $ | 72 |  |  | $ | 161 |  |  | $ | 149 |  |  |

[0000106040-25-000008:notes:131]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |  |
|  | (in millions) |
| Cost of revenue | $ | 12 |  |  | $ | 13 |  |  | $ | 26 |  |  | $ | 26 |  |  |
| Research and development | 35 |  |  | 32 |  |  | 74 |  |  | 66 |  |  |
| Selling, general and administrative | 30 |  |  | 27 |  |  | 61 |  |  | 57 |  |  |
| Subtotal | 77 |  |  | 72 |  |  | 161 |  |  | 149 |  |  |
| Tax benefit | (11) |  |  | (10) |  |  | (21) |  |  | (20) |  |  |
| Total | $ | 66 |  |  | $ | 62 |  |  | $ | 140 |  |  | $ | 129 |  |  |

[0000106040-25-000008:notes:132]
[same as prior period, unchanged from 0000106040-24-000040:notes:131]

[0000106040-25-000008:notes:133]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 27, 2024:

[0000106040-25-000008:notes:134]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 554 |  |  | 2.4 |
| ESPP | 57 |  |  | 1.9 |
| Total unamortized compensation cost | $ | 611 |  |  |  |

[0000106040-25-000008:notes:135]
[same as prior period, unchanged from 0000106040-24-000040:notes:134]

[0000106040-25-000008:notes:136]
[same as prior period, unchanged from 0000106040-24-000040:notes:135]

[0000106040-25-000008:notes:137]
[same as prior period, unchanged from 0000106040-24-000040:notes:136]

[0000106040-25-000008:notes:138]
[same as prior period, unchanged from 0000106040-24-000040:notes:137]

[0000106040-25-000008:notes:139]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2024 | 13.0 |  |  | $ | 44.42 |  |  |  |
| Granted | 4.1 |  |  | 62.72 |  |  |  |
| Vested | (4.1) |  |  | 44.81 |  |  | $ | 266 |  |
| Forfeited | (0.5) |  |  | 49.53 |  |  |  |
| RSUs and PSUs outstanding at December 27, 2024 | 12.5 |  |  | $ | 51.81 |  |  |  |

[0000106040-25-000008:notes:140]
[same as prior period, unchanged from 0000106040-24-000040:notes:139]

[0000106040-25-000008:notes:141]
[same as prior period, unchanged from 0000106040-24-000040:notes:140]

[0000106040-25-000008:notes:142]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing 5,000,000 authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement. As of December 27, 2024 and June 28, 2024, 235,000 of the Preferred Shares were outstanding.

[0000106040-25-000008:notes:143]
The Preferred Shares have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of December 27, 2024 and June 28, 2024, unpaid and cumulative dividends payable with respect to the Preferred Shares were $30 million and $22 million, respectively.

[0000106040-25-000008:notes:144]
The Preferred Shares are convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate sum of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends. In the event of a standalone spin-off transaction, the holders of the Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately prior to the Company’s conversion notice.

[0000106040-25-000008:notes:145]
As of December 27, 2024 and June 28, 2024, the Preferred Shares outstanding had an aggregate liquidation preference of $265 million and $257 million, respectively, and would have been convertible, if otherwise permitted, into approximately 6 million and 5 million shares of common stock, respectively, on each such date.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-25-000008:notes:146]
Income Tax Expense 
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and six months ended December 27, 2024 and December 29, 2023.

[0000106040-25-000008:notes:147]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant changes to laws related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The CAMT was effective for the Company beginning with fiscal year 2024. The Company does not expect to be subject to CAMT for fiscal year 2025 as its average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-25-000008:notes:148]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, some of which are effective for the Company in fiscal year 2025. For fiscal year 2025, the Company currently expects to be able to meet certain transitional safe harbors and does not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in fiscal year 2026, there may be material increases in the Company’s future tax obligations in certain jurisdictions.

[0000106040-25-000008:notes:149]
[same as prior period, unchanged from 0000106040-24-000040:notes:148]

[0000106040-25-000008:notes:150]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 741 |  | $ | (259) |  | $ | 1,369 |  | $ | (941) |
| Income tax expense | 147 |  | 28 |  | 282 |  | 31 |
| Effective tax rate | 20 | % |  | (11) | % |  | 21 | % |  | (3) | % |

[0000106040-25-000008:notes:151]
The relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines, and Thailand that have or will expire at various dates during years 2025 through 2031 resulted in decreases to the Company’s effective tax rate below the U.S. statutory rate for the three and six months ended December 27, 2024. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in the Company’s effective tax rate being closer to the U.S. Federal statutory rate for the three and six months ended December 27, 2024.

[0000106040-25-000008:notes:152]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, and the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines, and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for the six months ended December 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-25-000008:notes:153]
[same as prior period, unchanged from 0000106040-24-000040:notes:152]

[0000106040-25-000008:notes:154]
[same as prior period, unchanged from 0000106040-24-000040:notes:153]

[0000106040-25-000008:notes:155]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the six months ended December 27, 2024 (in millions):

[0000106040-25-000008:notes:156]
| Accrual balance at June 28, 2024 | $ | 721 |  |
| Gross increases related to current year tax positions | 8 |  |
| Gross increases related to prior year tax positions | 4 |  |
| Gross decreases related to prior year tax positions | (5) |  |
| Settlements | (39) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at December 27, 2024 | $ | 688 |  |

[0000106040-25-000008:notes:157]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of December 27, 2024 were $72 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of December 27, 2024, approximately $594 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-25-000008:notes:158]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024 also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 27, 2024, the Company made a payment of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of December 27, 2024 related to all years from 2008 through 2015.

[0000106040-25-000008:notes:159]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $166 million. Of this amount, $65 million of the interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-25-000008:notes:160]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 27, 2024, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-25-000008:notes:161]
[same as prior period, unchanged from 0000106040-24-000040:notes:160]

[0000106040-25-000008:notes:162]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 594 |  |  |  | $ | (287) |  |  | $ | 1,087 |  |  | $ | (972) |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  |  | 14 |  |  | 8 |  |  | 29 |  |
| Less: income attributable to participating securities(1) | 9 |  |  |  | — |  |  | 17 |  |  | — |  |
| Net income (loss) attributable to common shareholders | 581 |  |  |  | (301) |  |  | 1,062 |  |  | (1,001) |  |
| Re-allocation of participating securities considered potentially dilutive securities | — |  |  |  | — |  |  | 1 |  |  | — |  |
| Diluted net income (loss) attributable to common shareholders | $ | 581 |  |  |  | $ | (301) |  |  | $ | 1,063 |  |  | $ | (1,001) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 346 |  |  |  | 325 |  |  | 345 |  |  | 324 |  |
| RSUs, PSUs, ESPP, and the convertible notes | 11 |  |  |  | — |  |  | 12 |  |  | — |  |
| Diluted | 357 |  |  |  | 325 |  |  | 357 |  |  | 324 |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic | $ | 1.68 |  |  |  | $ | (0.93) |  |  | $ | 3.08 |  |  | $ | (3.09) |  |
| Diluted | $ | 1.63 |  |  |  | $ | (0.93) |  |  | $ | 2.98 |  |  | $ | (3.09) |  |
| Anti-dilutive potential common shares excluded | — |  |  |  | 14 |  |  | — |  |  | 14 |  |

[0000106040-25-000008:notes:163]
[same as prior period, unchanged from 0000106040-24-000040:notes:162]

[0000106040-25-000008:notes:164]
Basic net income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends allocated to preferred shareholders less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The “if-converted” method is used to determine the dilutive impact for the convertible notes and the preferred shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-25-000008:notes:165]
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and the preferred shares. For the three months and six months ended December 27, 2024, all common shares subject to outstanding equity awards are included in the calculation of diluted shares based on the Company’s average stock price during the period. For the three months and six months ended December 29, 2023, the Company recorded a net loss, and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-25-000008:notes:166]
Employee Termination, Asset Impairment and Other
Business Realignment

[0000106040-25-000008:notes:167]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure, and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. In this regard, for the six months ended December 29, 2023, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress, other assets and the recognition of a liability for certain contract termination costs. The Company also took actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in September 2023 as discussed in Note 10, Leases and Other Commitments.

[0000106040-25-000008:notes:168]
[same as prior period, unchanged from 0000106040-24-000040:notes:167]

[0000106040-25-000008:notes:169]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 2 |  |  | $ | 24 |  |  | $ | 2 |  |  | $ | 43 |  |  |  |
| Asset impairments | — |  |  | — |  |  | — |  |  | 94 |  |  |  |
| Other charges (gains): |  |  |  |  |  |  |  |  |  |
| Recovery of non-cancellable PO | (9) |  |  | — |  |  | (9) |  |  | — |  |  |  |
| Contract termination and other | — |  |  | — |  |  | 2 |  |  | 29 |  |  |  |
| Gain on sale-leaseback of facility | — |  |  | — |  |  | — |  |  | (85) |  |  |  |
| Total employee termination, asset impairment and other | $ | (7) |  |  | $ | 24 |  |  | $ | (5) |  |  | $ | 81 |  |  |  |

[0000106040-25-000008:notes:170]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the six months ended December 27, 2024:

[0000106040-25-000008:notes:171]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 28, 2024 | $ | — |  |  | $ | 28 |  |  | $ | 28 |  |  |  |  |  |
| Charges | 2 |  |  | 2 |  |  | 4 |  |  |  |  |  |
| Cash payments | — |  |  | (5) |  |  | (5) |  |  |  |  |  |
| Recovery of non-cancellable PO | — |  |  | (9) |  |  | (9) |  |  |  |  |  |
| Accrual balance at December 27, 2024 | $ | 2 |  |  | $ | 16 |  |  | $ | 18 |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-25-000008:notes:172]
[same as prior period, unchanged from 0000106040-24-000040:notes:171]

[0000106040-25-000008:notes:173]
The Company’s current payment terms with its suppliers under these programs generally range from 60 to 90 days. The Company does not provide any guarantees to any third parties and no assets are pledged in connection with the arrangements.

[0000106040-25-000008:notes:174]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $37 million and $37 million as of December 27, 2024 and June 28, 2024, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-25-000008:notes:175]
Legal Proceedings
Tax

[0000106040-25-000008:notes:176]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

[0000106040-25-000008:notes:177]
Intellectual Property Litigation

[0000106040-25-000008:notes:178]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S. Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

[0000106040-25-000008:notes:179]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the three and six months ended December 27, 2024, the Company recognized incremental charges of $0 and $3 million, respectively, related to plaintiff’s attorney’s fees in Operating expense under Litigation matter; $4 million and $6 million, respectively, of post-judgment interest in Other income (expense), net; and $10 million and $19 million, respectively, in Cost of revenue from the amortization of licenses related to this matter. The Company believes it has meritorious defenses, has filed post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

[0000106040-25-000008:notes:180]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and the prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of December 27, 2024.

[0000106040-25-000008:notes:181]
The ability to predict the ultimate outcome of these matters involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.

[0000106040-25-000008:notes:182]
Other Matters

[0000106040-25-000008:notes:183]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.
