# WDC note change history — 0000106040-24-000040 → 0000106040-25-000008


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:1]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S. Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.
  (was, 2024-10-31, similarity 0.9994):
[0000106040-24-000040:note_history:1]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

- added (2025-01-31):
[0000106040-25-000008:note_history:2]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the three and six months ended December 27, 2024, the Company recognized incremental charges of $0 and $3 million, respectively, related to plaintiff’s attorney’s fees in Operating expense under Litigation matter; $4 million and $6 million, respectively, of post-judgment interest in Other income (expense), net; and $10 million and $19 million, respectively, in Cost of revenue from the amortization of licenses related to this matter. The Company believes it has meritorious defenses, has filed post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

- changed (2025-01-31):
[0000106040-25-000008:note_history:3]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and the prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of December 27, 2024.
  (was, 2024-10-31, similarity 0.9147):
[0000106040-24-000040:note_history:3]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim of U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. SPEX has also requested the court to award it prejudgment interest of $233 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and any prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore, believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the request for prejudgment interest and legal costs in its financial statements as of September 27, 2024.

- removed (2025-01-31):
[0000106040-24-000040:note_history:4]
In the fourth quarter of fiscal 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the first quarter of fiscal 2025, the Company recognized incremental charges of $3 million related to plaintiff’s attorney’s fees in Operating expense under Litigation matter, $2 million of post-judgment interest in Other income (expense), net, and $9 million in Cost of revenue from the subsequent amortization of licenses related to this matter. The Company believes it has meritorious defenses, plans to file post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:5]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 44 |  |  | 149 |  |
| Investment in Flash Alliance | 111 |  |  | 216 |  |
| Investment in Flash Forward | 123 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 861 |  |  | $ | 991 |  |
  (was, 2024-10-31, similarity 0.9895):
[0000106040-24-000040:note_history:5]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 5 |  |
| Notes receivable, Flash Forward | 498 |  |  | 485 |  |
| Investment in Flash Partners | 169 |  |  | 149 |  |
| Investment in Flash Alliance | 236 |  |  | 216 |  |
| Investment in Flash Forward | 143 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,051 |  |  | $ | 991 |  |

- added (2025-01-31):
[0000106040-25-000008:note_history:6]
The Company made net payments to Flash Ventures for purchased flash-based memory wafers and net loans of $1.1 billion and $2.0 billion during the three and six months ended December 27, 2024, respectively, and $0.8 billion and $1.8 billion during the three and six months ended December 29, 2023, respectively.

- changed (2025-01-31):
[0000106040-25-000008:note_history:7]
As of December 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $252 million and $313 million, respectively.
  (was, 2024-10-31, similarity 0.9821):
[0000106040-24-000040:note_history:7]
As of September 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $352 million and $313 million, respectively.

- added (2025-01-31):
[0000106040-25-000008:note_history:8]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2025-01-31):
[0000106040-25-000008:note_history:9]
|  | December 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 583 |  |
| Equity investments | 278 |  |
| Operating lease guarantees | 1,343 |  |
| Inventory and prepayments | 1,393 |  |
| Maximum estimable loss exposure | $ | 3,597 |  |

- changed (2025-01-31):
[0000106040-25-000008:note_history:10]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three and six months ended December 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 27, 2024.
  (was, 2024-10-31, similarity 0.6501):
[0000106040-24-000040:note_history:10]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 27, 2024.

- changed (2025-01-31):
[0000106040-25-000008:note_history:11]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of December 27, 2024, $944 million remains to be credited against future building depreciation charges. As of December 27, 2024, the Company is also committed to make additional building depreciation prepayments of $303 million, based on the Japanese yen to U.S. dollar exchange rate of 157.86 as of such date, payable as follows: $60 million for the remainder of fiscal year 2025, $30 million in fiscal year 2026, $111 million in fiscal year 2027, $89 million in fiscal year 2028 and $13 million in fiscal year 2029. As of December 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $107 million at varying dates through fiscal year 2035.
  (was, 2024-10-31, similarity 0.9912):
[0000106040-24-000040:note_history:11]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of September 27, 2024, $722 million remains to be credited against future building depreciation charges. As of September 27, 2024, the Company is also committed to make additional building depreciation prepayments of $605 million, based on the Japanese yen to U.S. dollars exchange rate of 142.56 as of such date, payable as follows: $337 million for the remainder of fiscal year 2025, $33 million in fiscal year 2026, $123 million in fiscal year 2027, $98 million in fiscal year 2028 and $14 million in fiscal year 2029. As of September 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $315 million at varying dates through fiscal year 2035.

- changed (2025-01-31):
[0000106040-25-000008:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024.
  (was, 2024-10-31, similarity 0.9864):
[0000106040-24-000040:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024.

- changed (2025-01-31):
[0000106040-25-000008:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024:
  (was, 2024-10-31, similarity 0.9808):
[0000106040-24-000040:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024:

- changed (2025-01-31):
[0000106040-25-000008:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2025 |  | $ | 201 |  |  | $ | 49 |  |  | $ | 250 |  |
| 2026 |  | 406 |  |  | 113 |  |  | 519 |  |
| 2027 |  | 198 |  |  | 97 |  |  | 295 |  |
| 2028 |  | 83 |  |  | 93 |  |  | 176 |  |
| 2029 |  | 25 |  |  | 50 |  |  | 75 |  |
| 2030 |  | 4 |  |  | 24 |  |  | 28 |  |
| Total guarantee obligations |  | $ | 917 |  |  | $ | 426 |  |  | $ | 1,343 |  |
  (was, 2024-10-31, similarity 0.9921):
[0000106040-24-000040:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2025 |  | $ | 331 |  |  | $ | 83 |  |  | $ | 414 |  |
| 2026 |  | 428 |  |  | 126 |  |  | 554 |  |
| 2027 |  | 203 |  |  | 107 |  |  | 310 |  |
| 2028 |  | 81 |  |  | 103 |  |  | 184 |  |
| 2029 |  | 22 |  |  | 56 |  |  | 78 |  |
| 2030 |  | 2 |  |  | 16 |  |  | 18 |  |
| Total guarantee obligations |  | $ | 1,067 |  |  | $ | 491 |  |  | $ | 1,558 |  |

- changed (2025-01-31):
[0000106040-25-000008:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2024-10-31, similarity 0.9932):
[0000106040-24-000040:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2025-01-31):
[0000106040-25-000008:note_history:16]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 27, 2024, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both December 27, 2024 and June 28, 2024, respectively.

- added (2025-01-31):
[0000106040-25-000008:note_history:17]
Sale of a Majority Interest in a Subsidiary

- added (2025-01-31):
[0000106040-25-000008:note_history:18]
In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies in its flash-based products, on September 28, 2024, the Company’s wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) completed the sale of 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), the Company’s indirect wholly-owned subsidiary in its Flash business that owned its Flash manufacturing facility, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

- added (2025-01-31):
[0000106040-25-000008:note_history:19]
Proceeds from the sale, including working capital adjustments, are $659 million pre-tax. On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive remaining pre-tax proceeds of $187 million in five installments of approximately $37 million on September 28 of each year through September 28, 2029. As of December 27, 2024, the outstanding consideration receivable was recognized at its present value of $370 million, with $243 million within Other current assets and $127 million within Other non-current assets in the Condensed Consolidated Balance Sheets. The present value discount of $27 million as of December 27, 2024 will be accreted using the effective interest method to Interest income in the Condensed Consolidated Statements of Operations over the next five years.

- added (2025-01-31):
[0000106040-25-000008:note_history:20]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS will be recognized one quarter in arrears and will be reported in Other net income (expense), net in the Condensed Consolidated Statements of Operations.

- added (2025-01-31):
[0000106040-25-000008:note_history:21]
The Transaction resulted in a pre-tax gain of $113 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $303 million of goodwill allocated to SDSS.

- added (2025-01-31):
[0000106040-25-000008:note_history:22]
Subsequent to and in connection with the SDSS sale, the Company entered into a five-year Supply Agreement with SDSS to purchase certain flash-based products with a minimum annual commitment of $550 million (“the minimum annual commitment”). The Supply Agreement contains specific penalties the Company must pay if SDSS’s revenue fails to meet the minimum annual commitment. The Supply Agreement also provides that if SDSS’s revenue is higher than the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company a true-up amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by any of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the six months ended December 27, 2024, the Company made purchases of $111 million under the Supply Agreement and had an account payable balance due to SDSS of $117 million as of December 27, 2024.

- added (2025-01-31):
[0000106040-25-000008:note_history:23]
The Company also entered into a Transaction Services Agreement (“TSA”) to provide certain transitional services for one year following the closing of the Transaction. Charges under the TSA were not material.

- removed (2025-01-31):
[0000106040-24-000040:note_history:24]
During the three months ended September 27, 2024 and September 29, 2023, the Company made net payments to Flash Ventures of $889 million and $939 million, respectively, for purchased flash-based memory wafers and net loans.

- removed (2025-01-31):
[0000106040-24-000040:note_history:25]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2025-01-31):
[0000106040-24-000040:note_history:26]
|  | September 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 503 |  |
| Equity investments | 548 |  |
| Operating lease guarantees | 1,558 |  |
| Inventory and prepayments | 1,166 |  |
| Maximum estimable loss exposure | $ | 3,775 |  |

- removed (2025-01-31):
[0000106040-24-000040:note_history:27]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 27, 2024 and September 29, 2023, the Company recognized approximately 2% and 6% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both September 27, 2024 and June 28, 2024, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:28]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,513 |  |  | 2,588 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,413 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,366 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (150) |  |  | (1,750) |  |
| Long-term debt | $ | 7,216 |  |  | $ | 5,684 |  |
  (was, 2024-10-31, similarity 0.8):
[0000106040-24-000040:note_history:28]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,600 |  |  | $ | 1,600 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,550 |  |  | 2,588 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,450 |  |  | 7,488 |  |
| Issuance costs | (50) |  |  | (54) |  |
| Subtotal | 7,400 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,750) |  |
| Long-term debt | $ | 5,650 |  |  | $ | 5,684 |  |

- changed (2025-01-31):
[0000106040-25-000008:note_history:29]
During the three and six months ended December 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 27, 2024 was 6.107%.
  (was, 2024-10-31, similarity 0.9477):
[0000106040-24-000040:note_history:29]
During the three months ended September 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of September 27, 2024 was 6.696%.

- changed (2025-01-31):
[0000106040-25-000008:note_history:30]
During the six months ended December 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). As of December 27, 2024, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $2.25 billion as of that date.
  (was, 2024-10-31, similarity 0.6345):
[0000106040-24-000040:note_history:30]
During the three months ended September 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- changed (2025-01-31):
[0000106040-25-000008:note_history:31]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with a financial leverage ratio covenant. As of December 27, 2024, the Company was in compliance with the financial covenant.
  (was, 2024-10-31, similarity 0.679):
[0000106040-24-000040:note_history:31]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with certain financial covenants, consisting of a leverage ratio and a minimum liquidity requirement. As of September 27, 2024, the Company was in compliance with these financial covenants.

- added (2025-01-31):
[0000106040-25-000008:note_history:32]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended December 31, 2024 and accordingly, the holders of the 2028 Convertible Notes no longer have the right to convert the notes during the succeeding calendar quarter ending March 31, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of December 27, 2024. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

- changed (2025-01-31):
[0000106040-25-000008:note_history:33]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.
  (was, 2024-10-31, similarity 0.9965):
[0000106040-24-000040:note_history:33]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives.

- removed (2025-01-31):
[0000106040-24-000040:note_history:34]
The Company had issued an outstanding standby letters of credit of $52 million as of September 27, 2024, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.20 billion as of that date.

- removed (2025-01-31):
[0000106040-24-000040:note_history:35]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the notes mentioned above was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the calendar quarter ended September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of September 27, 2024. During the calendar quarter ended September 30, 2024, the sale price conditional conversion feature of the notes mentioned above was not triggered. As a result, the 2028 Convertible Notes are not convertible from October 1, 2024 through December 31, 2024. The Company will re-evaluate in each subsequent calendar quarter to determine if the 2028 Convertible Notes have become convertible.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:36]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,513 |  |  | 2,588 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,413 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,366 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (150) |  |  | (1,750) |  |
| Long-term debt | $ | 7,216 |  |  | $ | 5,684 |  |
  (was, 2024-10-31, similarity 0.8):
[0000106040-24-000040:note_history:36]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,600 |  |  | $ | 1,600 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,550 |  |  | 2,588 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,450 |  |  | 7,488 |  |
| Issuance costs | (50) |  |  | (54) |  |
| Subtotal | 7,400 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,750) |  |
| Long-term debt | $ | 5,650 |  |  | $ | 5,684 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:37]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 44 |  |  | 149 |  |
| Investment in Flash Alliance | 111 |  |  | 216 |  |
| Investment in Flash Forward | 123 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 861 |  |  | $ | 991 |  |
  (was, 2024-10-31, similarity 0.9895):
[0000106040-24-000040:note_history:37]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 5 |  |
| Notes receivable, Flash Forward | 498 |  |  | 485 |  |
| Investment in Flash Partners | 169 |  |  | 149 |  |
| Investment in Flash Alliance | 236 |  |  | 216 |  |
| Investment in Flash Forward | 143 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,051 |  |  | $ | 991 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-31):
[0000106040-25-000008:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,346 |  |  | $ | 1,071 |  |  | $ | 4,554 |  |  | $ | 1,943 |  |
| Client | 1,168 |  |  | 1,122 |  |  | 2,377 |  |  | 2,269 |  |
| Consumer | 771 |  |  | 839 |  |  | 1,449 |  |  | 1,570 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,995 |  |  | $ | 1,699 |  |  | $ | 3,832 |  |  | $ | 3,250 |  |
| Americas | 1,428 |  |  | 804 |  |  | 3,118 |  |  | 1,466 |  |
| Europe, Middle East and Africa | 862 |  |  | 529 |  |  | 1,430 |  |  | 1,066 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
  (was, 2024-10-31, similarity 0.8326):
[0000106040-24-000040:note_history:38]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,208 |  |  | $ | 872 |  |  |  |  |  |
| Client | 1,209 |  |  | 1,147 |  |  |  |  |  |
| Consumer | 678 |  |  | 731 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,837 |  |  | $ | 1,551 |  |  |  |  |  |
| Americas | 1,690 |  |  | 662 |  |  |  |  |  |
| Europe, Middle East and Africa | 568 |  |  | 537 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
