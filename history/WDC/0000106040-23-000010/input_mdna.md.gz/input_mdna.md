# WDC MD&A — 0000106040-23-000010


## mdna

[0000106040-23-000010:mdna:1]
[same as prior period, unchanged from 0000106040-22-000065:mdna:1]

[0000106040-23-000010:mdna:2]
[same as prior period, unchanged from 0000106040-22-000065:mdna:2]

[0000106040-23-000010:mdna:3]
[same as prior period, unchanged from 0000106040-22-000065:mdna:3]

[0000106040-23-000010:mdna:4]
[same as prior period, unchanged from 0000106040-22-000065:mdna:4]

[0000106040-23-000010:mdna:5]
[same as prior period, unchanged from 0000106040-22-000065:mdna:5]

[0000106040-23-000010:mdna:6]
[same as prior period, unchanged from 0000106040-22-000065:mdna:6]

[0000106040-23-000010:mdna:7]
[same as prior period, unchanged from 0000106040-22-000065:mdna:7]

[0000106040-23-000010:mdna:8]
In June 2022, we announced that we are reviewing potential strategic alternatives aimed at further optimizing long-term value for stockholders. The Executive Committee of our Board of Directors is overseeing the assessment process and evaluating a range of alternatives, including options for separating our Flash and HDD business units. As of December 30, 2022, we are still actively working with our financial advisors and our legal counsel in this strategic review process.

[0000106040-23-000010:mdna:9]
[same as prior period, unchanged from 0000106040-22-000065:mdna:11]

[0000106040-23-000010:mdna:10]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry are experiencing a supply-demand imbalance, which has resulted in reduced shipments and negatively impacted pricing, particularly in Flash. We expect the market pressures on Flash pricing to continue for the next few quarters. Since the beginning of fiscal 2023, we have scaled back on capital expenditures, consolidated production lines and reduced bit growth to align with market demand and implemented measures to reduce operating expenses. This has resulted in incremental charges for Employee termination, asset impairment and other charges and manufacturing underutilization charges in HDD in the second quarter of 2023 and may impact near-term results. In addition, we have reduced wafer starts for Flash by 30% as of January 2023 and expect underutilization charges for that business unit to impact near-term results. However, we believe digital transformation will continue to drive long-term growth for data storage in both Flash and HDD and believe that the actions we are taking will position us for more profitable growth as supply and demand levels begin to balance.

[0000106040-23-000010:mdna:11]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. Our BiCS5 based products continue to play a significant role in driving top line results across our end markets. Additionally, hard drive products utilizing OptiNAND and shingled magnetic recording (“SMR”) technologies have commenced commercial shipments and our latest 26-terabyte SMR drives are undergoing qualifications at multiple cloud and OEM customers. We continued commercial shipment of consumer flash devices based on our next generation 3D-flash technology and are beginning productization of BiCS8, which incorporates new 3D-NAND architectural innovations to deliver improved performance and cost-effectiveness. We are aware of the ongoing trends in the HDD Client market as PCs shift from using HDD to Flash technology and as a result, we have and are still undergoing actions to restructure our HDD manufacturing footprint to reflect this market dynamic, including a sharp reduction in our client hard drive production capacity.

[0000106040-23-000010:mdna:12]
The COVID-19 environment has begun to normalize. The responses to COVID-19 taken by ourselves and others in the supply chain contributed to increases in the costs of their services which in turn impacted our operations, but these costs have now largely been normalized in our operating results.

[0000106040-23-000010:mdna:13]
We will continue to actively monitor recent developments impacting our business and may take additional responsive actions that we determine to be in the best interests of our business and stakeholders. See “Adverse global or regional conditions could harm our business,” “Public health crises, including the COVID-19 pandemic, have had, and could in the future, have a negative effect on our business” and “We are dependent on a limited number of qualified suppliers who provide critical services, materials or components, and a disruption in our supply chain could negatively affect our business” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended July 1, 2022 for more information regarding the risks we face as a result of macroeconomic conditions, the COVID-19 pandemic and supply chain disruptions.

[0000106040-23-000010:mdna:14]
[same as prior period, unchanged from 0000106040-22-000065:mdna:73]

[0000106040-23-000010:mdna:15]
In December 2022, we amended the loan agreement governing our revolving credit facility and Term Loan A-2 to modify the leverage ratio requirements of our financial covenant through our quarter ending September 27, 2024 to provide additional financial flexibility as we navigate through the current dynamic economic environment. The amendment also accelerates the due date for amounts outstanding under the loan agreement from January 7, 2027 to November 2, 2023 if, as of that date, our cash and cash equivalents plus available unused capacity under our credit facilities does not exceed by $1 billion the sum of the outstanding balance of our 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months.

[0000106040-23-000010:mdna:16]
Subsequent to the end of the second quarter of 2023, on January 25, 2023, we entered into a new delayed draw term loan agreement, which allows us to draw a single unsecured loan of up to $875 million any time through June 30, 2023. Any amount drawn will be due 364 days after funding or such earlier date that conditions for acceleration of amounts due under the loan agreement have been triggered as described above. Also, on January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. We believe these transactions will provide us with greater financial flexibility to manage our business. Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2022. Additional information regarding the terms of our Series A Preferred Stock is included in Note 17, Subsequent Events, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000010:mdna:17]
[same as prior period, unchanged from 0000106040-22-000065:mdna:9]

[0000106040-23-000010:mdna:18]
As previously disclosed, we have received statutory notices of deficiency and notices of proposed adjustments from the Internal Revenue Service (“IRS”) with respect to 2008 through 2015. During 2022, new information became available which required us to re-measure our unrecognized tax benefits for this IRS matter. Additionally, during 2022, we and the IRS tentatively reached a settlement for resolving this matter. Additional information regarding this tentative settlement and our assessment of the potential tax and interest payments we expect to pay in connection with the settlement is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 13, Income Tax Expense, of the Notes to the Condensed Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity-Unrecognized Tax Benefits” section below.

[0000106040-23-000010:mdna:19]
[same as prior period, unchanged from 0000106040-22-000065:mdna:17]

[0000106040-23-000010:mdna:20]
[same as prior period, unchanged from 0000106040-22-000065:mdna:18]

[0000106040-23-000010:mdna:21]
[same as prior period, unchanged from 0000106040-22-000065:mdna:20]

[0000106040-23-000010:mdna:22]
Second Quarter and First Half Overview

[0000106040-23-000010:mdna:23]
[same as prior period, unchanged from 0000106040-22-000065:mdna:22]

[0000106040-23-000010:mdna:24]
|  | Three Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 3,107 |  |  | 100.0 | % |  | $ | 4,833 |  |  | 100.0 | % |  | $ | (1,726) |  |  | (36) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,579 |  |  | 83.0 |  |  | 3,250 |  |  | 67.2 |  |  | (671) |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 528 |  |  | 17.0 |  |  | 1,583 |  |  | 32.8 |  |  | (1,055) |  |  | (67) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 523 |  |  | 16.8 |  |  | 575 |  |  | 11.9 |  |  | (52) |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 250 |  |  | 8.0 |  |  | 279 |  |  | 5.8 |  |  | (29) |  |  | (10) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 76 |  |  | 2.4 |  |  | 2 |  |  | — |  |  | 74 |  |  | 3,700 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 849 |  |  | 27.3 |  |  | 856 |  |  | 17.7 |  |  | (7) |  |  | (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | (321) |  |  | (10.3) |  |  | 727 |  |  | 15.0 |  |  | (1,048) |  |  | (144) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 3 |  |  | 0.1 |  |  | 1 |  |  | — |  |  | 2 |  |  | 200 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (73) |  |  | (2.3) |  |  | (76) |  |  | (1.6) |  |  | 3 |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 6 |  |  | 0.2 |  |  | (6) |  |  | (0.1) |  |  | 12 |  |  | (200) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (64) |  |  | (2.1) |  |  | (81) |  |  | (1.7) |  |  | 17 |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | (385) |  |  | (12.4) |  |  | 646 |  |  | 13.4 |  |  | (1,031) |  |  | (160) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 61 |  |  | 2.0 |  |  | 82 |  |  | 1.7 |  |  | (21) |  |  | (26) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (446) |  |  | (14.4) | % |  | $ | 564 |  |  | 11.7 | % |  | $ | (1,010) |  |  | (179) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-23-000010:mdna:25]
[same as prior period, unchanged from 0000106040-22-000065:mdna:24]

[0000106040-23-000010:mdna:26]
41

[0000106040-23-000010:mdna:27]
|  |  |  | Six Months Ended |
|  |  |  |  |  |  |  |  |  | December 30,2022 |  | December 31,2021 |  | $ Change |  | % Change |  |  |
|  |  |  | $ in millions |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 6,843 |  |  | 100.0 | % |  | $ | 9,884 |  |  | 100.0 | % |  | $ | (3,041) |  |  | (31) | % |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 5,334 |  |  | 77.9 |  |  | 6,636 |  |  | 67.1 |  |  | (1,302) |  |  | (20) |  |  |  |  |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 1,509 |  |  | 22.1 |  |  | 3,248 |  |  | 32.9 |  |  | (1,739) |  |  | (54) |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 1,075 |  |  | 15.7 |  |  | 1,153 |  |  | 11.7 |  |  | (78) |  |  | (7) |  |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 497 |  |  | 7.3 |  |  | 570 |  |  | 5.8 |  |  | (73) |  |  | (13) |  |  |  |  |  |
| Employee termination, asset impairment, and other charges |  |  |  |  |  |  |  |  |  |  |  |  | 100 |  |  | 1.5 |  |  | 20 |  |  | 0.2 |  |  | 80 |  |  | 400 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 1,672 |  |  | 24.4 |  |  | 1,743 |  |  | 17.6 |  |  | (71) |  |  | (4) |  |  |  |  |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (163) |  |  | (2.4) |  |  | 1,505 |  |  | 15.2 |  |  | (1,668) |  |  | (111) |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  | 0.1 |  |  | 3 |  |  | — |  |  | 2 |  |  | 67 |  |  |  |  |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (143) |  |  | (2.1) |  |  | (154) |  |  | (1.6) |  |  | 11 |  |  | (7) |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  | (4) |  |  | — |  |  | 4 |  |  | (100) |  |  |  |  |  |
| Total interest and other expense, net |  |  |  |  |  |  |  |  |  |  |  |  | (138) |  |  | (2.0) |  |  | (155) |  |  | (1.6) |  |  | 17 |  |  | (11) |  |  |  |  |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | (301) |  |  | (4.4) |  |  | 1,350 |  |  | 13.7 |  |  | (1,651) |  |  | (122) |  |  |  |  |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 118 |  |  | 1.7 |  |  | 176 |  |  | 1.8 |  |  | (58) |  |  | (33) |  |  |  |  |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | $ | (419) |  |  | (6.1) | % |  | $ | 1,174 |  |  | 11.9 | % |  | $ | (1,593) |  |  | (136) | % |  |  |  |  |

[0000106040-23-000010:mdna:28]
(1)    Percentages may not total due to rounding.

[0000106040-23-000010:mdna:29]
[same as prior period, unchanged from 0000106040-22-000065:mdna:25]

[0000106040-23-000010:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,657 |  |  | $ | 2,620 |  |  | $ | 3,379 |  |  | $ | 5,110 |  |
| HDD | 1,450 |  |  | 2,213 |  |  | 3,464 |  |  | 4,774 |  |
| Total net revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 240 |  |  | $ | 946 |  |  | $ | 662 |  |  | $ | 1,867 |  |
| HDD | 300 |  |  | 677 |  |  | 874 |  |  | 1,469 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (14) |  |  | (26) |  |  | (23) |  |
| Amortization of acquired intangible assets | — |  |  | (26) |  |  | (1) |  |  | (65) |  |
| Total unallocated corporate items | (12) |  |  | (40) |  |  | (27) |  |  | (88) |  |
| Consolidated gross profit | $ | 528 |  |  | $ | 1,583 |  |  | $ | 1,509 |  |  | $ | 3,248 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 14.5 | % |  | 36.1 | % |  | 19.6 | % |  | 36.5 | % |
| HDD | 20.7 | % |  | 30.6 | % |  | 25.2 | % |  | 30.8 | % |
| Consolidated gross margin | 17.0 | % |  | 32.8 | % |  | 22.1 | % |  | 32.9 | % |

[0000106040-23-000010:mdna:31]
43

[0000106040-23-000010:mdna:32]
[same as prior period, unchanged from 0000106040-22-000065:mdna:28]

[0000106040-23-000010:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | ($ in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,224 |  |  | $ | 1,920 |  |  | $ | 3,053 |  |  | $ | 4,145 |  |
| Client | 1,089 |  |  | 1,854 |  |  | 2,318 |  |  | 3,707 |  |
| Consumer | 794 |  |  | 1,059 |  |  | 1,472 |  |  | 2,032 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,494 |  |  | $ | 2,610 |  |  | $ | 3,180 |  |  | $ | 5,285 |  |
| Americas | 1,090 |  |  | 1,407 |  |  | 2,513 |  |  | 3,021 |  |
| Europe, Middle East and Africa | 523 |  |  | 816 |  |  | 1,150 |  |  | 1,578 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |

[0000106040-23-000010:mdna:34]
Comparison of Three and Six Months Ended December 30, 2022 to Three and Six Months Ended December 31, 2021

[0000106040-23-000010:mdna:35]
[same as prior period, unchanged from 0000106040-22-000065:mdna:30]

[0000106040-23-000010:mdna:36]
The decrease in consolidated net revenue for the three and six months ended December 30, 2022 from the comparable periods in the prior year reflected decreases in exabytes sold primarily in HDD, as certain customers reduced purchases as they adjusted their production levels and right-sized their inventories and also reflected lower average selling prices primarily in Flash. These items are further discussed below in our discussion by segment.

[0000106040-23-000010:mdna:37]
Flash revenue decreased 37% and 34% for the three and six months ended December 30, 2022, respectively from the comparable periods in the prior year. The decline was primarily driven by a decline in average selling prices per gigabyte caused by a supply-demand imbalance, which was exacerbated by the current macroeconomic environment.

[0000106040-23-000010:mdna:38]
HDD revenue decreased 34% for the three months ended December 30, 2022 from the comparable period in the prior year, substantially all of which was driven by a decrease in exabytes sold. The decline in exabytes sold was primarily driven by customers primarily in our Cloud and to a lesser extent in Client and Consumer end markets due to the macroeconomic pressures noted in “Operational and COVID-19 Pandemic Update” above and our end customers right-sizing their inventories. HDD revenue decreased 27% for the six months ended December 30, 2022 from the comparable period in the prior year, primarily driven by a 22% decrease in exabytes sold as well as a decrease in the average price per gigabyte. The decrease in exabytes sold for the six-month period was largely attributable to the same factors noted above for the three-month period with pricing per gigabyte impacted by a higher mix of enterprise drives.

[0000106040-23-000010:mdna:39]
The decrease in Cloud revenue for the three months ended December 30, 2022 from the comparable period in the prior year reflected a decline in capacity enterprise drives sold to U.S. cloud customers, as they reduced purchases to right-size their inventories. In Client, the decrease in revenue for the three months ended December 30, 2022 from the comparable period in the prior year was primarily driven by the decline in average selling price per gigabyte in Flash and, to a lesser extent, a decline in client SSD shipments for PC applications. In Consumer, the decrease in revenue for the three months ended December 30, 2022 from the comparable period in the prior year primarily reflected the decrease in average selling price per gigabyte in Flash and to a lesser extent, a decline in retail HDD shipments.

[0000106040-23-000010:mdna:40]
The decreases in Cloud and Consumer revenue for the six months ended December 30, 2022 from the comparable period in the prior year primarily reflected the same drivers noted above for the three-month period, respectively. In Client, the decrease in revenue for the six months ended December 30, 2022 from the comparable period in the prior year primarily reflected a decline in average selling price per gigabyte in Flash and, to a lesser extent, a decline in both Flash and HDD shipments for PC applications, due to lower demand as a result of macroeconomic pressures.

[0000106040-23-000010:mdna:41]
The changes in net revenue by geography for the three and six months ended December 30, 2022 from the comparable periods in the prior year reflected a larger decline in Asia from lower Client revenue from OEMs in this region as they reduced purchases to align with current market demand, as well as routine variations in the mix of business.

[0000106040-23-000010:mdna:42]
Our top 10 customers accounted for 47% of our net revenue for the three months ended December 30, 2022, compared to 46% of our net revenue for the three months ended December 31, 2021. Our top 10 customers accounted for 48% of our net revenue for the six months ended December 30, 2022, compared to 44% of our net revenue for the six months ended December 31, 2021. For each of the three and six months ended December 30, 2022 and December 31, 2021, no single customer accounted for 10% or more of our net revenue.

[0000106040-23-000010:mdna:43]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 18% of gross revenue for each period presented. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-23-000010:mdna:44]
[same as prior period, unchanged from 0000106040-22-000065:mdna:39]

[0000106040-23-000010:mdna:45]
Consolidated gross profit decreased by $1.06 billion for the three months ended December 30, 2022 from the comparable period in the prior year, which reflects the impact from the decrease in revenue in both Flash and HDD as well as approximately $100 million of charges in the current period related to manufacturing underutilization in HDD. Consolidated gross margin decreased 15.8 percentage points for the three months ended December 30, 2022 from the comparable period in the prior year, which primarily reflects lower average price per gigabyte in Flash and the impact of the underutilization charges in HDD. Flash gross margin decreased by 21.6 percentage points year over year, primarily reflecting the lower average selling price per gigabyte. HDD gross margin decreased by 9.9 percentage points year over year, of which the underutilization charge reflected approximately 7 percentage points with the remainder primarily driven by lower economies of scale as we tempered production.

[0000106040-23-000010:mdna:46]
Consolidated gross profit decreased by $1.74 billion for the six months ended December 30, 2022 from the comparable period in the prior year, which reflects the decrease in revenue in both HDD and Flash and the approximate $100 million underutilization charge in HDD during the three months ended December 30, 2022, partially offset by a $64 million decrease during the six months ended December 30, 2022 in charges related to amortization expense on acquired intangible assets, some of which became fully amortized. Consolidated gross margin decreased 10.8 percentage points for the six months ended December 30, 2022 from the comparable period in the prior year, which reflects lower gross margin in both Flash and HDD and the underutilization charges noted above. Flash and HDD gross margin decreased by 16.9 and 5.6 percentage points year over year, respectively, reflecting the same factors noted above for the three-month period.

[0000106040-23-000010:mdna:47]
[same as prior period, unchanged from 0000106040-22-000065:mdna:41]

[0000106040-23-000010:mdna:48]
Research and development (“R&D”) expense decreased $52 million and $78 million for the three and six months ended December 30, 2022, respectively, from the comparable periods in the prior year. The declines were primarily driven by a reduction in variable compensation expenses and material use as we took actions to reduce expenses in the current environment.

[0000106040-23-000010:mdna:49]
Selling, general and administrative (“SG&A”) expense decreased $29 million and $73 million for the three and six months ended December 30, 2022, respectively, from the comparable periods in the prior year. The declines were primarily driven by a reduction in expenses related to outside services, variable compensation expenses, and material use as we took actions to reduce expenses in the current environment.

[0000106040-23-000010:mdna:50]
Employee termination, asset impairment and other charges increased $74 million and $80 million for the three and six months ended December 30, 2022, respectively, from the comparable periods in the prior year. The increases were due to restructuring actions taken to adjust our cost structure to align with the current demand environment. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment, and Other Charges of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000010:mdna:51]
[same as prior period, unchanged from 0000106040-22-000065:mdna:45]

[0000106040-23-000010:mdna:52]
Total interest and other expense, net decreased $17 million for each of the three and six months ended December 30, 2022 from the comparable periods in the prior year reflecting lower foreign exchange losses and lower interest expense resulting from the pay-down of principal on our debt.

[0000106040-23-000010:mdna:53]
[same as prior period, unchanged from 0000106040-22-000065:mdna:47]

[0000106040-23-000010:mdna:54]
[same as prior period, unchanged from 0000106040-22-000065:mdna:48]

[0000106040-23-000010:mdna:55]
[same as prior period, unchanged from 0000106040-22-000065:mdna:49]

[0000106040-23-000010:mdna:56]
[same as prior period, unchanged from 0000106040-22-000065:mdna:50]

[0000106040-23-000010:mdna:57]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | $ in millions |
| Income (loss) before taxes | $ | (385) |  |  | $ | 646 |  |  | $ | (301) |  |  | $ | 1,350 |  |
| Income tax expense | 61 |  |  | 82 |  |  | 118 |  |  | 176 |  |
| Effective tax rate | (16) | % |  | 13 | % |  | (39) | % |  | 13 | % |

[0000106040-23-000010:mdna:58]
Beginning in fiscal year 2023, the 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and six months ended December 30, 2022, but did not have a material impact on our effective tax rate. The primary drivers of the difference between the effective tax rate for the three and six months ended December 30, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031.

[0000106040-23-000010:mdna:59]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 31, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and six months ended December 31, 2021 included the discrete effect of an increase to unrecognized tax benefits of $8 million and $25 million, respectively, as a result of ongoing discussions with various taxing authorities.

[0000106040-23-000010:mdna:60]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for the three and six months ended December 30, 2022, but did not have a material impact on the effective tax rate in those periods due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-23-000010:mdna:61]
[same as prior period, unchanged from 0000106040-22-000065:mdna:55]

[0000106040-23-000010:mdna:62]
[same as prior period, unchanged from 0000106040-22-000065:mdna:56]

[0000106040-23-000010:mdna:63]
[same as prior period, unchanged from 0000106040-22-000065:mdna:57]

[0000106040-23-000010:mdna:64]
|  | Six Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 41 |  |  | $ | 1,187 |  |  |  |
| Investing activities | (482) |  |  | (569) |  |  |  |
| Financing activities | (12) |  |  | (1,456) |  |  |  |
| Effect of exchange rate changes on cash | (3) |  |  | (1) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (456) |  |  | $ | (839) |  |  |  |

[0000106040-23-000010:mdna:65]
We and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015. We currently expect to pay tax and interest totaling approximately $720 million to $760 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million. See Part I, Item 1, Note 13, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-23-000010:mdna:66]
[same as prior period, unchanged from 0000106040-22-000065:mdna:60]

[0000106040-23-000010:mdna:67]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities, including the availability under our new delayed term loan agreement and the proceeds from the issuance of our Series A Preferred Stock as discussed in “Key Developments - Financing Activities”, will be sufficient to satisfy our IRS obligation and meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt capital markets to further supplement our liquidity position. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended July 1, 2022.

[0000106040-23-000010:mdna:68]
As noted previously, we are scaling back on capital expenditures and consolidating production lines and reducing bit growth to align with market demand. We are now reducing our expected expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations from our previous estimate of an aggregate of $2.7 billion down to $2.3 billion for 2023. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we have reduced the expected net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures from a cash outflow of $1.3 billion to an amount below $1 billion during 2023. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-23-000010:mdna:69]
A total of $1.33 billion and $1.84 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of December 30, 2022 and December 31, 2021, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-23-000010:mdna:70]
[same as prior period, unchanged from 0000106040-22-000065:mdna:64]

[0000106040-23-000010:mdna:71]
[same as prior period, unchanged from 0000106040-22-000065:mdna:66]

[0000106040-23-000010:mdna:72]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $257 million for the six months ended December 30, 2022, as compared to $715 million for the six months ended December 31, 2021, which largely reflects the reduction in volume of our business. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-23-000010:mdna:73]
|  | Three Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  |  |  |  |
| Days sales outstanding | 56 |  |  | 52 |  |  |  |  |  |
| Days in inventory | 133 |  |  | 102 |  |  |  |  |  |
| Days payables outstanding | (55) |  |  | (68) |  |  |  |  |  |
| Cash conversion cycle | 134 |  |  | 86 |  |  |  |  |  |

[0000106040-23-000010:mdna:74]
[same as prior period, unchanged from 0000106040-22-000065:mdna:69]

[0000106040-23-000010:mdna:75]
For the three months ended December 30, 2022, DSO increased by 4 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO increased by 31 days from the comparable period in the prior year primarily reflecting a decline in products shipped. DPO decreased by 13 days from the comparable period in the prior year primarily due to reductions in capital expenditures and HDD production levels as well as routine variations in the timing of purchases and payments during the period. We have seen no significant deterioration in our receivables as a result of COVID-19 or other market conditions.

[0000106040-23-000010:mdna:76]
[same as prior period, unchanged from 0000106040-22-000065:mdna:71]

[0000106040-23-000010:mdna:77]
Net cash used in investing activities for the six months ended December 30, 2022 primarily consisted of $578 million in capital expenditures partially offset by a $82 million net decrease in notes receivable issuances to Flash Ventures. Net cash used in investing activities for the six months ended December 31, 2021 primarily consisted of $551 million in capital expenditures and a $17 million net increase in notes receivable issuances to Flash Ventures.

[0000106040-23-000010:mdna:78]
Financing Activities

[0000106040-23-000010:mdna:79]
During the six months ended December 30, 2022, cash flows from financing activities primarily consisted of $55 million used for taxes paid on vested stock awards under employee stock plans, partially offset by $48 million from the issuance of stock under employee stock plans. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the period. Cash used in financing activities for the six months ended December 31, 2021 primarily consisted of $2.43 billion for repayment of debt, as well as $80 million for taxes paid on vested stock awards under employee stock plans offset by proceeds of $998 million from the issuance of new debt, and $60 million from the issuance of stock under employee stock plans.

[0000106040-23-000010:mdna:80]
[same as prior period, unchanged from 0000106040-22-000065:mdna:75]

[0000106040-23-000010:mdna:81]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000010:mdna:82]
49

[0000106040-23-000010:mdna:83]
[same as prior period, unchanged from 0000106040-22-000065:mdna:78]

[0000106040-23-000010:mdna:84]
Material Cash Requirements

[0000106040-23-000010:mdna:85]
In addition to cash requirements for unrecognized tax benefits discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of December 30, 2022:

[0000106040-23-000010:mdna:86]
|  | Total |  | 1 Year (Remaining Six Months of 2023) |  | 2-3 Years (2024-2025) |  | 4-5 Years (2026-2027) |  | More than 5 Years (Beyond 2027) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,100 |  |  | $ | — |  |  | $ | 1,363 |  |  | $ | 4,738 |  |  | $ | 999 |  |
| Interest on debt | 1,256 |  |  | 154 |  |  | 609 |  |  | 387 |  |  | 106 |  |
| Flash Ventures related commitments(2) | 5,274 |  |  | 1,950 |  |  | 2,545 |  |  | 913 |  |  | (134) |  |
| Operating leases | 344 |  |  | 24 |  |  | 91 |  |  | 82 |  |  | 147 |  |
| Purchase obligations and other commitments | 3,613 |  |  | 2,591 |  |  | 773 |  |  | 99 |  |  | 150 |  |
| Mandatory Deemed Repatriation Tax | 657 |  |  | — |  |  | 402 |  |  | 255 |  |  | — |  |
| Total | $ | 18,244 |  |  | $ | 4,719 |  |  | $ | 5,783 |  |  | $ | 6,474 |  |  | $ | 1,268 |  |

[0000106040-23-000010:mdna:87]
[same as prior period, unchanged from 0000106040-22-000065:mdna:82]

[0000106040-23-000010:mdna:88]
[same as prior period, unchanged from 0000106040-22-000065:mdna:83]

[0000106040-23-000010:mdna:89]
[same as prior period, unchanged from 0000106040-22-000065:mdna:84]

[0000106040-23-000010:mdna:90]
In addition to our existing debt, as of December 30, 2022, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Furthermore, we entered into a delayed draw term loan agreement as noted in “Key Developments - Financing Activities” which provides us with an additional $875 million unsecured term loan available to borrow through June 30, 2023, subject to customary conditions and certain financial covenants under the loan agreement. The agreements governing these credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require certain of our subsidiaries to provide guarantees to the extent the conditions providing for such guarantees are met. Additional information regarding our indebtedness, including information about principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended July 1, 2022. Our delayed draw term loan agreement and the loan agreement governing our revolving credit facility and our Term Loan A-2 due 2027 require us to comply with a leverage ratio financial covenant. As of December 30, 2022, we were in compliance with the applicable financial covenant.

[0000106040-23-000010:mdna:91]
[same as prior period, unchanged from 0000106040-22-000065:mdna:86]

[0000106040-23-000010:mdna:92]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of December 30, 2022, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-23-000010:mdna:93]
[same as prior period, unchanged from 0000106040-22-000065:mdna:88]

[0000106040-23-000010:mdna:94]
[same as prior period, unchanged from 0000106040-22-000065:mdna:89]

[0000106040-23-000010:mdna:95]
[same as prior period, unchanged from 0000106040-22-000065:mdna:90]

[0000106040-23-000010:mdna:96]
[same as prior period, unchanged from 0000106040-22-000065:mdna:91]

[0000106040-23-000010:mdna:97]
|  |  | December 30,2022 |
|  |  | (in millions) |
| 2024 |  | $ | 199 |  |
| 2025 |  | 203 |  |
| 2026 |  | 255 |  |
| Total |  | $ | 657 |  |

[0000106040-23-000010:mdna:98]
[same as prior period, unchanged from 0000106040-22-000065:mdna:93]

[0000106040-23-000010:mdna:99]
[same as prior period, unchanged from 0000106040-22-000065:mdna:94]

[0000106040-23-000010:mdna:100]
As of December 30, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.04 billion. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of December 30, 2022 was $279 million. Of these amounts, approximately $1.18 billion could result in potential cash payments.

[0000106040-23-000010:mdna:101]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with our foreign subsidiaries and intercompany payable balances for years 2008 through 2015. In September 2018 and March 2019, we filed petitions with the U.S. Tax Court covering years 2008 through 2012, for which we had received statutory notices of deficiency, while years 2013 through 2015 remain in the jurisdiction of the IRS’s Examination function. The IRS has filed various Amendments to Answer with the U.S. Tax Court which, together with the notices of proposed adjustments, would result in additional federal income tax liabilities totaling approximately $1.6 billion and penalties totaling $449 million with respect to years 2008 through 2015. In May 2022, we and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. Based on the tentative settlement for resolution, we now expect to pay tax and interest totaling approximately $720 million to $760 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million. While we continue to work with the IRS to come to a final agreement on the federal tax and interest calculations, we are uncertain as to when a final agreement will be reached and the exact timing of when any payments will be made. However, we believe it is reasonably likely that these payments may be made within the next twelve months and we have classified that portion of these unrecognized tax benefits, including interest in Income taxes payable on our Condensed Consolidated Balance Sheets as of December 30, 2022. This classification and amount may be subject to change in the next twelve months depending on when we are able to reach a final agreement with the IRS.

[0000106040-23-000010:mdna:102]
[same as prior period, unchanged from 0000106040-22-000065:mdna:97]

[0000106040-23-000010:mdna:103]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments in future periods, if not repealed or otherwise modified.

[0000106040-23-000010:mdna:104]
[same as prior period, unchanged from 0000106040-22-000065:mdna:99]

[0000106040-23-000010:mdna:105]
We have generally held a balance of fixed and variable rate debt and periodically have used interest rate swaps to hedge a portion of our fixed rate debt. As of December 30, 2022, our only variable rate debt outstanding was our Term Loan A-2 on which we had pay-fixed interest rate swaps of $2 billion notional amount that would mitigate the impact of fluctuations in variable interest rates on this loan only through February 2023. See Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risks included in this in this Quarterly Report on Form 10-Q for additional information.

[0000106040-23-000010:mdna:106]
[same as prior period, unchanged from 0000106040-22-000065:mdna:101]

[0000106040-23-000010:mdna:107]
[same as prior period, unchanged from 0000106040-22-000065:mdna:102]

[0000106040-23-000010:mdna:108]
[same as prior period, unchanged from 0000106040-22-000065:mdna:103]

[0000106040-23-000010:mdna:109]
[same as prior period, unchanged from 0000106040-22-000065:mdna:104]

[0000106040-23-000010:mdna:110]
[same as prior period, unchanged from 0000106040-22-000065:mdna:105]

[0000106040-23-000010:mdna:111]
[same as prior period, unchanged from 0000106040-22-000065:mdna:106]

[0000106040-23-000010:mdna:112]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the six months ended December 30, 2022 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of December 30, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-23-000010:mdna:113]
[same as prior period, unchanged from 0000106040-22-000065:mdna:108]

[0000106040-23-000010:mdna:114]
[same as prior period, unchanged from 0000106040-22-000065:mdna:109]

[0000106040-23-000010:mdna:115]
[same as prior period, unchanged from 0000106040-22-000065:mdna:110]

[0000106040-23-000010:mdna:116]
[same as prior period, unchanged from 0000106040-22-000065:mdna:111]

[0000106040-23-000010:mdna:117]
52

[0000106040-23-000010:mdna:118]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the year ended July 1, 2022. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the year ended July 1, 2022 for a discussion of our critical accounting policies and estimates. In addition, as disclosed in Part I, Item 1, Note 3, Business Segments, Geographic Information, and Concentrations of Risk, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, as of December 30, 2022, our management identified several factors that warranted a quantitative analysis of impairment for both the Flash and HDD reporting units as of that date. Please refer to that disclosure for additional information on the estimates included in our assessment.

[0000106040-23-000010:mdna:119]
53
