# WDC note change history — 0000106040-22-000065 → 0000106040-23-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:1]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 12 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 66 |  |  | 55 |  |
| Notes receivable, Flash Forward | 737 |  |  | 793 |  |
| Investment in Flash Partners | 174 |  |  | 166 |  |
| Investment in Flash Alliance | 251 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,357 |  |  | $ | 1,396 |  |
  (was, 2022-11-02, similarity 0.9919):
[0000106040-22-000065:note_history:1]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 658 |  |  | 793 |  |
| Investment in Flash Partners | 158 |  |  | 166 |  |
| Investment in Flash Alliance | 229 |  |  | 243 |  |
| Investment in Flash Forward | 106 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,219 |  |  | $ | 1,396 |  |

- changed (2023-02-03):
[0000106040-23-000010:note_history:2]
During the three and six months ended December 30, 2022 and December 31, 2021, the Company made net payments to Flash Ventures of $1.0 billion and $2.0 billion, and $1.1 billion and $2.3 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2022-11-02, similarity 0.7035):
[0000106040-22-000065:note_history:2]
During the three months ended September 30, 2022 and October 1, 2021, the Company made net payments to Flash Ventures of $1.0 billion, and $1.2 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2023-02-03):
[0000106040-23-000010:note_history:3]
As of December 30, 2022 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $368 million and $320 million, respectively.
  (was, 2022-11-02, similarity 0.9784):
[0000106040-22-000065:note_history:3]
As of September 30, 2022 and July 1, 2022, the Company had account payable balances due to Flash Ventures of $295 million and $320 million, respectively.

- added (2023-02-03):
[0000106040-23-000010:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2023-02-03):
[0000106040-23-000010:note_history:5]
|  | December 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 815 |  |
| Equity investments | 542 |  |
| Operating lease guarantees | 1,895 |  |
| Inventory and prepayments | 1,128 |  |
| Maximum estimable loss exposure | $ | 4,380 |  |

- changed (2023-02-03):
[0000106040-23-000010:note_history:6]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $147 million as follows: $124 million for the remaining six months of 2023 and $23 million in 2024, to be credited against future wafer charges.
  (was, 2022-11-02, similarity 0.9943):
[0000106040-22-000065:note_history:6]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $203 million as follows: $182 million for the remaining nine months of 2023 and $21 million in 2024, to be credited against future wafer charges.

- changed (2023-02-03):
[0000106040-23-000010:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022.
  (was, 2022-11-02, similarity 0.9864):
[0000106040-22-000065:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022.

- changed (2023-02-03):
[0000106040-23-000010:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022:
  (was, 2022-11-02, similarity 0.9808):
[0000106040-22-000065:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022:

- changed (2023-02-03):
[0000106040-23-000010:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2023 |  | $ | 285 |  |  | $ | 55 |  |  | $ | 340 |  |
| 2024 |  | 450 |  |  | 99 |  |  | 549 |  |
| 2025 |  | 250 |  |  | 90 |  |  | 340 |  |
| 2026 |  | 261 |  |  | 136 |  |  | 397 |  |
| 2027 |  | 81 |  |  | 116 |  |  | 197 |  |
| 2028 and thereafter |  | 12 |  |  | 60 |  |  | 72 |  |
| Total guarantee obligations |  | $ | 1,339 |  |  | $ | 556 |  |  | $ | 1,895 |  |
  (was, 2022-11-02, similarity 0.9924):
[0000106040-22-000065:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2023 |  | $ | 371 |  |  | $ | 50 |  |  | $ | 421 |  |
| 2024 |  | 376 |  |  | 90 |  |  | 466 |  |
| 2025 |  | 203 |  |  | 82 |  |  | 285 |  |
| 2026 |  | 199 |  |  | 124 |  |  | 323 |  |
| 2027 |  | 53 |  |  | 106 |  |  | 159 |  |
| 2028 and thereafter |  | 3 |  |  | 27 |  |  | 30 |  |
| Total guarantee obligations |  | $ | 1,205 |  |  | $ | 479 |  |  | $ | 1,684 |  |

- changed (2023-02-03):
[0000106040-23-000010:note_history:10]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2022-11-02, similarity 0.9932):
[0000106040-22-000065:note_history:10]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2023-02-03):
[0000106040-23-000010:note_history:11]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of December 30, 2022 and July 1, 2022, respectively.
  (was, 2022-11-02, similarity 0.6696):
[0000106040-22-000065:note_history:11]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three months ended October 1, 2021, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for September 30, 2022 and July 1, 2022, respectively.

- removed (2023-02-03):
[0000106040-22-000065:note_history:12]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2023-02-03):
[0000106040-22-000065:note_history:13]
|  | September 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 493 |  |
| Operating lease guarantees | 1,684 |  |
| Inventory and prepayments | 1,022 |  |
| Maximum estimable loss exposure | $ | 3,925 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:14]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended December 30, 2022 (in millions):
  (was, 2022-11-02, similarity 0.9867):
[0000106040-22-000065:note_history:14]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 30, 2022 (in millions):

- changed (2023-02-03):
[0000106040-23-000010:note_history:15]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 11 |  |
| Gross decreases related to prior year tax positions | (12) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at December 30, 2022 | $ | 1,042 |  |
  (was, 2022-11-02, similarity 0.8394):
[0000106040-22-000065:note_history:15]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross decreases related to prior year tax positions | (18) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at September 30, 2022 | $ | 1,026 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:16]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Subtotal | 7,071 |  |  | 7,022 |  |
| Less current portion of long-term debt | (38) |  |  | — |  |
| Long-term debt | $ | 7,033 |  |  | $ | 7,022 |  |
  (was, 2022-11-02, similarity 0.9042):
[0000106040-22-000065:note_history:16]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Long-term debt | $ | 7,071 |  |  | $ | 7,022 |  |

- added (2023-02-03):
[0000106040-23-000010:note_history:17]
During the six months ended December 30, 2022, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- added (2023-02-03):
[0000106040-23-000010:note_history:18]
In December 2022, the Company amended the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 for the purposes of providing flexibility by adjusting the leverage ratio requirements of the financial covenant thereunder through the Company’s quarter ending September 27, 2024 (such period, the “Covenant Relief Period”). As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

- added (2023-02-03):
[0000106040-23-000010:note_history:19]
| Quarter ending: | Leverage ratio |
| December 30, 2022 | 3.25 to 1.00 |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |

- added (2023-02-03):
[0000106040-23-000010:note_history:20]
As of December 30, 2022, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have Cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.

- added (2023-02-03):
[0000106040-23-000010:note_history:21]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions.

- added (2023-02-03):
[0000106040-23-000010:note_history:22]
Any amount drawn under the Delayed Draw Term Loan Agreement will mature 364 days following the date of the initial draw. However, the due date will be accelerated to November 2, 2023 if conditions for acceleration of amounts due under the Credit Agreement have been triggered as described above.

- added (2023-02-03):
[0000106040-23-000010:note_history:23]
The Delayed Draw Term Loan will bear interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies. The Company will also pay an unused commitment fee on the Delayed Draw Term Loan Agreement of 0.200%.

- added (2023-02-03):
[0000106040-23-000010:note_history:24]
The key covenants, limitations and requirements provided under Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.

- added (2023-02-03):
[0000106040-23-000010:note_history:25]
As described in Note 2, Recent Accounting Pronouncements, the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.

- removed (2023-02-03):
[0000106040-22-000065:note_history:26]
During the three months ended September 30, 2022, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). The terms of the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 requires the Company to comply with a leverage ratio financial covenant. As of September 30, 2022, the Company was in compliance with this financial covenant.

- removed (2023-02-03):
[0000106040-22-000065:note_history:27]
As described in Note 2, Recent Accounting Pronouncements the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:28]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Subtotal | 7,071 |  |  | 7,022 |  |
| Less current portion of long-term debt | (38) |  |  | — |  |
| Long-term debt | $ | 7,033 |  |  | $ | 7,022 |  |
  (was, 2022-11-02, similarity 0.9042):
[0000106040-22-000065:note_history:28]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Long-term debt | $ | 7,071 |  |  | $ | 7,022 |  |


## wdc:DebtInstrumentScheduleOfLeverageRatioTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2023-02-03):
[0000106040-23-000010:note_history:29]
As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

- added (2023-02-03):
[0000106040-23-000010:note_history:30]
| Quarter ending: | Leverage ratio |
| December 30, 2022 | 3.25 to 1.00 |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:31]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 12 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 66 |  |  | 55 |  |
| Notes receivable, Flash Forward | 737 |  |  | 793 |  |
| Investment in Flash Partners | 174 |  |  | 166 |  |
| Investment in Flash Alliance | 251 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,357 |  |  | $ | 1,396 |  |
  (was, 2022-11-02, similarity 0.9919):
[0000106040-22-000065:note_history:31]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 658 |  |  | 793 |  |
| Investment in Flash Partners | 158 |  |  | 166 |  |
| Investment in Flash Alliance | 229 |  |  | 243 |  |
| Investment in Flash Forward | 106 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,219 |  |  | $ | 1,396 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0000106040-23-000010:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,224 |  |  | $ | 1,920 |  |  | $ | 3,053 |  |  | $ | 4,145 |  |
| Client | 1,089 |  |  | 1,854 |  |  | 2,318 |  |  | 3,707 |  |
| Consumer | 794 |  |  | 1,059 |  |  | 1,472 |  |  | 2,032 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,494 |  |  | $ | 2,610 |  |  | $ | 3,180 |  |  | $ | 5,285 |  |
| Americas | 1,090 |  |  | 1,407 |  |  | 2,513 |  |  | 3,021 |  |
| Europe, Middle East and Africa | 523 |  |  | 816 |  |  | 1,150 |  |  | 1,578 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |

- removed (2023-02-03):
[0000106040-22-000065:note_history:33]
|  | Three Months Ended |  |
|  | September 30,2022 |  | October 1,2021 |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |
| Cloud | $ | 1,829 |  |  | $ | 2,225 |  |  |
| Client | 1,229 |  |  | 1,853 |  |  |
| Consumer | 678 |  |  | 973 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |
| Revenue by Geography |  |  |  |  |
| Asia | $ | 1,686 |  |  | $ | 2,675 |  |  |
| Americas | 1,423 |  |  | 1,614 |  |  |
| Europe, Middle East and Africa | 627 |  |  | 762 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0000106040-23-000010:note_history:34]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of December 30, 2022 and July 1, 2022 and changes in contract liabilities for the six months ended December 30, 2022 and December 31, 2021 were not material.
  (was, 2022-11-02, similarity 0.9302):
[0000106040-22-000065:note_history:34]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of September 30, 2022 and July 1, 2022 and changes in contract liabilities for the three months ended September 30, 2022 and October 1, 2021 were not material.

- added (2023-02-03):
[0000106040-23-000010:note_history:35]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically have a duration of longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 30, 2022 was $17 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize this amount as revenue as follows: $14 million during the remainder of 2023, and $3 million in 2024 and thereafter.

- removed (2023-02-03):
[0000106040-22-000065:note_history:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of September 30, 2022 was $26 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize substantially all of this amount as revenue within the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-02-03):
[0000106040-23-000010:note_history:37]
Subsequent EventsOn January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”) from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million. The Preferred Shares will have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. The Preferred Shares will be convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate of the stated value plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the holder beginning on January 31, 2024, or on the date a specified spin-off transaction is completed, if earlier. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days. After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares at an amount equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares. The Preferred Shares will vote on an as-converted equivalent basis along with holders of the Company’s common stock, except to the extent that shares issuable upon conversion of the Preferred Stock would exceed 19.9% of common stock outstanding immediately prior to the original issuance date of the Preferred Stock. In the event of liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock.
