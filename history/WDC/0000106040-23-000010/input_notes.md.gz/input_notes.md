# WDC notes — 0000106040-23-000010


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-23-000010:notes:1]
[same as prior period, unchanged from 0000106040-22-000065:notes:1]

[0000106040-23-000010:notes:2]
[same as prior period, unchanged from 0000106040-22-000065:notes:2]

[0000106040-23-000010:notes:3]
[same as prior period, unchanged from 0000106040-22-000065:notes:3]

[0000106040-23-000010:notes:4]
[same as prior period, unchanged from 0000106040-22-000065:notes:4]

[0000106040-23-000010:notes:5]
[same as prior period, unchanged from 0000106040-22-000065:notes:5]

[0000106040-23-000010:notes:6]
[same as prior period, unchanged from 0000106040-22-000065:notes:6]

[0000106040-23-000010:notes:7]
[same as prior period, unchanged from 0000106040-22-000065:notes:7]

[0000106040-23-000010:notes:8]
[same as prior period, unchanged from 0000106040-22-000065:notes:8]

[0000106040-23-000010:notes:9]
[same as prior period, unchanged from 0000106040-22-000065:notes:9]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-23-000010:notes:10]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-23-000010:notes:11]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with prior standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. The Company adopted the new standard effective July 2, 2022, the first day of the year ending June 30, 2023, using the modified retrospective method. On the date of adoption, the Company recorded a reduction in Additional Paid-In Capital of $128 million, a reduction of unamortized debt discount of $48 million, a reduction of deferred income tax liabilities of $11 million, and an increase to retained earnings of $91 million for the after-tax impact of previously recognized amortization of the debt discount associated with the Company’s convertible senior notes.

[0000106040-23-000010:notes:12]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of 2023. The Company adopted this ASU on July 2, 2022, the first day of the year ending June 30, 2023, and the adoption did not have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-23-000010:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-23-000010:notes:14]
In September 2022, the FASB issued ASU No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”. This guidance requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023. The Company is currently evaluating the extent of the impact of this ASU on its Condensed Consolidated Financial Statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-23-000010:notes:15]
[same as prior period, unchanged from 0000106040-22-000065:notes:13]

[0000106040-23-000010:notes:16]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,657 |  |  | $ | 2,620 |  |  | $ | 3,379 |  |  | $ | 5,110 |  |
| HDD | 1,450 |  |  | 2,213 |  |  | 3,464 |  |  | 4,774 |  |
| Total net revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 240 |  |  | $ | 946 |  |  | $ | 662 |  |  | $ | 1,867 |  |
| HDD | 300 |  |  | 677 |  |  | 874 |  |  | 1,469 |  |
| Total gross profit for segments | 540 |  |  | 1,623 |  |  | 1,536 |  |  | 3,336 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (14) |  |  | (26) |  |  | (23) |  |
| Amortization of acquired intangible assets | — |  |  | (26) |  |  | (1) |  |  | (65) |  |
| Total unallocated corporate items | (12) |  |  | (40) |  |  | (27) |  |  | (88) |  |
| Consolidated gross profit | $ | 528 |  |  | $ | 1,583 |  |  | $ | 1,509 |  |  | $ | 3,248 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 14.5 | % |  | 36.1 | % |  | 19.6 | % |  | 36.5 | % |
| HDD | 20.7 | % |  | 30.6 | % |  | 25.2 | % |  | 30.8 | % |
| Consolidated gross margin | 17.0 | % |  | 32.8 | % |  | 22.1 | % |  | 32.9 | % |

[0000106040-23-000010:notes:17]
[same as prior period, unchanged from 0000106040-22-000065:notes:15]

[0000106040-23-000010:notes:18]
[same as prior period, unchanged from 0000106040-22-000065:notes:16]

[0000106040-23-000010:notes:19]
[same as prior period, unchanged from 0000106040-22-000065:notes:17]

[0000106040-23-000010:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,224 |  |  | $ | 1,920 |  |  | $ | 3,053 |  |  | $ | 4,145 |  |
| Client | 1,089 |  |  | 1,854 |  |  | 2,318 |  |  | 3,707 |  |
| Consumer | 794 |  |  | 1,059 |  |  | 1,472 |  |  | 2,032 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,494 |  |  | $ | 2,610 |  |  | $ | 3,180 |  |  | $ | 5,285 |  |
| Americas | 1,090 |  |  | 1,407 |  |  | 2,513 |  |  | 3,021 |  |
| Europe, Middle East and Africa | 523 |  |  | 816 |  |  | 1,150 |  |  | 1,578 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |

[0000106040-23-000010:notes:21]
The Company’s top 10 customers accounted for 47% and 48% of its net revenue for the three and six months ended December 30, 2022, respectively, and 46% and 44% of its net revenue for the three and six months ended December 31, 2021, respectively. For the three and six months ended December 30, 2022 and December 31, 2021, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-23-000010:notes:22]
[same as prior period, unchanged from 0000106040-22-000065:notes:20]

[0000106040-23-000010:notes:23]
[same as prior period, unchanged from 0000106040-22-000065:notes:21]

[0000106040-23-000010:notes:24]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at July 1, 2022 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |
| Balance at December 30, 2022 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |

[0000106040-23-000010:notes:25]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment.

[0000106040-23-000010:notes:26]
As of December 30, 2022, management identified several continuing factors, including changes in macroeconomic conditions and recent declines of the Company’s market stock price, that warranted quantitative analyses of impairments for both the Flash and HDD reporting units as of such date. The fair value of each operating segment was based on a weighting of two valuation methodologies: an income approach and a market approach.

[0000106040-23-000010:notes:27]
[same as prior period, unchanged from 0000106040-22-000065:notes:25]

[0000106040-23-000010:notes:28]
[same as prior period, unchanged from 0000106040-22-000065:notes:26]

[0000106040-23-000010:notes:29]
The Company reconciled the aggregated estimated fair value of both operating segments to the Company’s market capitalization, including consideration of a control premium representing the estimated amount a market participant would pay to obtain a controlling interest in the Company.

[0000106040-23-000010:notes:30]
As of December 30, 2022, the fair value derived from those valuation methodologies exceeded the carrying value by 9% and 28% for Flash and HDD, respectively. There were no impairment charges recorded for the three and six months ended December 30, 2022.

[0000106040-23-000010:notes:31]
The Company is required to use judgment when applying the goodwill impairment test, including the assignment of assets and liabilities to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units as well as their actual carrying value may change based on future changes in the Company’s results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen or the Company’s stock price decreases further for a sustained period of time, goodwill could become impaired, which could result in an impairment charge and materially adversely affect the Company’s financial condition results of operations.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-23-000010:notes:32]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of December 30, 2022 and July 1, 2022 and changes in contract liabilities for the six months ended December 30, 2022 and December 31, 2021 were not material.

[0000106040-23-000010:notes:33]
[same as prior period, unchanged from 0000106040-22-000065:notes:31]

[0000106040-23-000010:notes:34]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically have a duration of longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 30, 2022 was $17 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize this amount as revenue as follows: $14 million during the remainder of 2023, and $3 million in 2024 and thereafter.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-23-000010:notes:35]
[same as prior period, unchanged from 0000106040-22-000065:notes:33]

[0000106040-23-000010:notes:36]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the six months ended December 30, 2022, the Company sold trade accounts receivable aggregating $391 million. The Company did not sell any trade accounts receivable during the six months ended December 31, 2021. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. As of December 30, 2022 and July 1, 2022, the amount of factored receivables that remained outstanding was $100 million and $300 million, respectively.

[0000106040-23-000010:notes:37]
[same as prior period, unchanged from 0000106040-22-000065:notes:35]

[0000106040-23-000010:notes:38]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,968 |  |  | $ | 1,603 |  |
| Work-in-process | 966 |  |  | 1,162 |  |
| Finished goods | 839 |  |  | 873 |  |
| Total inventories | $ | 3,773 |  |  | $ | 3,638 |  |

[0000106040-23-000010:notes:39]
[same as prior period, unchanged from 0000106040-22-000065:notes:37]

[0000106040-23-000010:notes:40]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 269 |  |  | $ | 269 |  |
| Buildings and improvements | 1,953 |  |  | 1,920 |  |
| Machinery and equipment | 8,692 |  |  | 8,642 |  |
| Computer equipment and software | 506 |  |  | 494 |  |
| Furniture and fixtures | 54 |  |  | 54 |  |
| Construction-in-process | 690 |  |  | 591 |  |
| Property, plant and equipment, gross | 12,164 |  |  | 11,970 |  |
| Accumulated depreciation | (8,476) |  |  | (8,300) |  |
| Property, plant and equipment, net | $ | 3,688 |  |  | $ | 3,670 |  |

[0000106040-23-000010:notes:41]
Other Intangible assets, net

[0000106040-23-000010:notes:42]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Other Intangible assets: |  |  |  |
| Finite-lived intangible assets | $ | 5,492 |  |  | $ | 5,493 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,437) |  |  | (5,360) |  |
| Other Intangible assets, net | $ | 135 |  |  | $ | 213 |  |

[0000106040-23-000010:notes:43]
[same as prior period, unchanged from 0000106040-22-000065:notes:41]

[0000106040-23-000010:notes:44]
[same as prior period, unchanged from 0000106040-22-000065:notes:42]

[0000106040-23-000010:notes:45]
[same as prior period, unchanged from 0000106040-22-000065:notes:43]

[0000106040-23-000010:notes:46]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 340 |  |  | $ | 370 |  |  | $ | 345 |  |  | $ | 363 |  |  |  |
| Charges to operations | 25 |  |  | 36 |  |  | 57 |  |  | 76 |  |  |  |
| Utilization | (60) |  |  | (28) |  |  | (94) |  |  | (51) |  |  |  |
| Changes in estimate related to pre-existing warranties | (16) |  |  | (27) |  |  | (19) |  |  | (37) |  |  |  |
| Warranty accrual, end of period | $ | 289 |  |  | $ | 351 |  |  | $ | 289 |  |  | $ | 351 |  |  |  |

[0000106040-23-000010:notes:47]
[same as prior period, unchanged from 0000106040-22-000065:notes:45]

[0000106040-23-000010:notes:48]
|  | December 30,2022 |  | July 1,2022 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 131 |  |  | $ | 162 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 158 |  |  | 183 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 289 |  |  | $ | 345 |  |  |  |  |  |  |  |

[0000106040-23-000010:notes:49]
[same as prior period, unchanged from 0000106040-22-000065:notes:47]

[0000106040-23-000010:notes:50]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 458 |  |  | $ | 659 |  |
| Non-current portion of unrecognized tax benefits | 452 |  |  | 477 |  |
| Other non-current liabilities | 607 |  |  | 643 |  |
| Total other liabilities | $ | 1,517 |  |  | $ | 1,779 |  |

[0000106040-23-000010:notes:51]
[same as prior period, unchanged from 0000106040-22-000065:notes:49]

[0000106040-23-000010:notes:52]
[same as prior period, unchanged from 0000106040-22-000065:notes:50]

[0000106040-23-000010:notes:53]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at July 1, 2022 | $ | (11) |  |  | $ | (277) |  |  |  |  |  |  | $ | (266) |  |  | $ | (554) |  |
| Other comprehensive income before reclassifications | — |  |  | 15 |  |  |  |  |  |  | 35 |  |  | 50 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 177 |  |  | 177 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | 2 |  |  |  |  |  |  | (44) |  |  | (42) |  |
| Net current-period other comprehensive income | — |  |  | 17 |  |  |  |  |  |  | 168 |  |  | 185 |  |
| Balance at December 30, 2022 | $ | (11) |  |  | $ | (260) |  |  |  |  |  |  | $ | (98) |  |  | $ | (369) |  |

[0000106040-23-000010:notes:54]
During the three and six months ended December 30, 2022, the amounts reclassified out of AOCI were losses related to foreign exchange contracts and gains related to interest rate swap contracts. Losses reclassified out of AOCI related to foreign exchange contracts were $119 million and $181 million for the three and six months ended December 30, 2022, respectively, that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. Gains reclassified out of AOCI related to interest rate swap contracts were $6 million and $4 million for the three and six months ended December 30, 2022, respectively, that were charged to Interest expense in the Condensed Consolidated Statements of Operations.
As of December 30, 2022, substantially all existing net losses related to cash flow hedges recorded in AOCI are expected to be reclassified to earnings within the next twelve months. In addition, as of December 30, 2022, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-23-000010:notes:55]
[same as prior period, unchanged from 0000106040-22-000065:notes:53]

[0000106040-23-000010:notes:56]
[same as prior period, unchanged from 0000106040-22-000065:notes:54]

[0000106040-23-000010:notes:57]
[same as prior period, unchanged from 0000106040-22-000065:notes:55]

[0000106040-23-000010:notes:58]
[same as prior period, unchanged from 0000106040-22-000065:notes:56]

[0000106040-23-000010:notes:59]
[same as prior period, unchanged from 0000106040-22-000065:notes:57]

[0000106040-23-000010:notes:60]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 30, 2022 and July 1, 2022, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-23-000010:notes:61]
|  | December 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 435 |  |  | $ | — |  |  | $ | — |  |  | $ | 435 |  |
| Foreign exchange contracts | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Interest rate swap contracts | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total assets at fair value | $ | 435 |  |  | $ | 111 |  |  | $ | — |  |  | $ | 546 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 97 |  |  | $ | — |  |  | $ | 97 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 97 |  |  | $ | — |  |  | $ | 97 |  |

[0000106040-23-000010:notes:62]
[same as prior period, unchanged from 0000106040-22-000065:notes:60]

[0000106040-23-000010:notes:63]
[same as prior period, unchanged from 0000106040-22-000065:notes:61]

[0000106040-23-000010:notes:64]
[same as prior period, unchanged from 0000106040-22-000065:notes:62]

[0000106040-23-000010:notes:65]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2023 and the fourth quarter of 2022, respectively.

[0000106040-23-000010:notes:66]
|  | December 30, 2022 |  | July 1, 2022 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,097 |  |  | $ | 1,052 |  |  | $ | 1,048 |  |  | $ | 1,040 |  |
| 4.75% senior unsecured notes due 2026 | 2,292 |  |  | 2,169 |  |  | 2,291 |  |  | 2,205 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,691 |  |  | 2,661 |  |  | 2,693 |  |  | 2,621 |  |
| 2.85% senior unsecured notes due 2029 | 496 |  |  | 388 |  |  | 495 |  |  | 412 |  |
| 3.10% senior unsecured notes due 2032 | 495 |  |  | 361 |  |  | 495 |  |  | 389 |  |
| Total | $ | 7,071 |  |  | $ | 6,631 |  |  | $ | 7,022 |  |  | $ | 6,667 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-23-000010:notes:67]
Derivative Instruments and Hedging Activities
As of December 30, 2022, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments through February 2023, on a portion of its term loans.

[0000106040-23-000010:notes:68]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and six months ended December 30, 2022 and December 31, 2021, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-23-000010:notes:69]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCI. For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data - Accumulated other comprehensive loss.

[0000106040-23-000010:notes:70]
[same as prior period, unchanged from 0000106040-22-000065:notes:68]

[0000106040-23-000010:notes:71]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 30, 2022 and July 1, 2022, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-23-000010:notes:72]
Debt
Debt consisted of the following:

[0000106040-23-000010:notes:73]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Subtotal | 7,071 |  |  | 7,022 |  |
| Less current portion of long-term debt | (38) |  |  | — |  |
| Long-term debt | $ | 7,033 |  |  | $ | 7,022 |  |

[0000106040-23-000010:notes:74]
During the six months ended December 30, 2022, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

[0000106040-23-000010:notes:75]
In December 2022, the Company amended the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 for the purposes of providing flexibility by adjusting the leverage ratio requirements of the financial covenant thereunder through the Company’s quarter ending September 27, 2024 (such period, the “Covenant Relief Period”). As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

[0000106040-23-000010:notes:76]
| Quarter ending: | Leverage ratio |
| December 30, 2022 | 3.25 to 1.00 |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |

[0000106040-23-000010:notes:77]
As of December 30, 2022, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have Cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.

[0000106040-23-000010:notes:78]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions.

[0000106040-23-000010:notes:79]
Any amount drawn under the Delayed Draw Term Loan Agreement will mature 364 days following the date of the initial draw. However, the due date will be accelerated to November 2, 2023 if conditions for acceleration of amounts due under the Credit Agreement have been triggered as described above.

[0000106040-23-000010:notes:80]
The Delayed Draw Term Loan will bear interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies. The Company will also pay an unused commitment fee on the Delayed Draw Term Loan Agreement of 0.200%.

[0000106040-23-000010:notes:81]
The key covenants, limitations and requirements provided under Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.

[0000106040-23-000010:notes:82]
As described in Note 2, Recent Accounting Pronouncements, the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-23-000010:notes:83]
[same as prior period, unchanged from 0000106040-22-000065:notes:74]

[0000106040-23-000010:notes:84]
[same as prior period, unchanged from 0000106040-22-000065:notes:75]

[0000106040-23-000010:notes:85]
[same as prior period, unchanged from 0000106040-22-000065:notes:76]

[0000106040-23-000010:notes:86]
|  | December 30,2022 |  | July 1,2022 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 302 |  |  | $ | 294 |  |  |  |
| Fair value of plan assets at end of period | 195 |  |  | 189 |  |  |  |
| Unfunded status | $ | 107 |  |  | $ | 105 |  |  |  |

[0000106040-23-000010:notes:87]
[same as prior period, unchanged from 0000106040-22-000065:notes:78]

[0000106040-23-000010:notes:88]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 106 |  |  | 104 |  |
| Net amount recognized | $ | 107 |  |  | $ | 105 |  |

[0000106040-23-000010:notes:89]
Net periodic benefit costs were not material for the three and six months ended December 30, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-23-000010:notes:90]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-23-000010:notes:91]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-23-000010:notes:92]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-23-000010:notes:93]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 12 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 66 |  |  | 55 |  |
| Notes receivable, Flash Forward | 737 |  |  | 793 |  |
| Investment in Flash Partners | 174 |  |  | 166 |  |
| Investment in Flash Alliance | 251 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,357 |  |  | $ | 1,396 |  |

[0000106040-23-000010:notes:94]
During the three and six months ended December 30, 2022 and December 31, 2021, the Company made net payments to Flash Ventures of $1.0 billion and $2.0 billion, and $1.1 billion and $2.3 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-23-000010:notes:95]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-23-000010:notes:96]
As of December 30, 2022 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $368 million and $320 million, respectively.

[0000106040-23-000010:notes:97]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-23-000010:notes:98]
|  | December 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 815 |  |
| Equity investments | 542 |  |
| Operating lease guarantees | 1,895 |  |
| Inventory and prepayments | 1,128 |  |
| Maximum estimable loss exposure | $ | 4,380 |  |

[0000106040-23-000010:notes:99]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-23-000010:notes:100]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $147 million as follows: $124 million for the remaining six months of 2023 and $23 million in 2024, to be credited against future wafer charges.

[0000106040-23-000010:notes:101]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-23-000010:notes:102]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-23-000010:notes:103]
Off-Balance Sheet Liabilities

[0000106040-23-000010:notes:104]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-23-000010:notes:105]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022.

[0000106040-23-000010:notes:106]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 250 |  |  | $ | 1,895 |  |

[0000106040-23-000010:notes:107]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022:

[0000106040-23-000010:notes:108]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2023 |  | $ | 285 |  |  | $ | 55 |  |  | $ | 340 |  |
| 2024 |  | 450 |  |  | 99 |  |  | 549 |  |
| 2025 |  | 250 |  |  | 90 |  |  | 340 |  |
| 2026 |  | 261 |  |  | 136 |  |  | 397 |  |
| 2027 |  | 81 |  |  | 116 |  |  | 197 |  |
| 2028 and thereafter |  | 12 |  |  | 60 |  |  | 72 |  |
| Total guarantee obligations |  | $ | 1,339 |  |  | $ | 556 |  |  | $ | 1,895 |  |

[0000106040-23-000010:notes:109]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-23-000010:notes:110]
Unis Venture

[0000106040-23-000010:notes:111]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of December 30, 2022 and July 1, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-23-000010:notes:112]
[same as prior period, unchanged from 0000106040-22-000065:notes:103]

[0000106040-23-000010:notes:113]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of December 30, 2022:

[0000106040-23-000010:notes:114]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining six months of 2023 | $ | 24 |  |  |  |  |  |  |  |  |  |
| 2024 | 47 |  |  |  |  |  |  |  |  |  |
| 2025 | 44 |  |  |  |  |  |  |  |  |  |
| 2026 | 43 |  |  |  |  |  |  |  |  |  |
| 2027 | 39 |  |  |  |  |  |  |  |  |  |
| Thereafter | 147 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 344 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 54 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 290 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 39 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 251 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 271 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.1 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.1 | % |  |  |  |  |  |  |  |  |

[0000106040-23-000010:notes:115]
[same as prior period, unchanged from 0000106040-22-000065:notes:106]

[0000106040-23-000010:notes:116]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Cost of operating leases | $ | 14 |  |  | $ | 14 |  |  | $ | 28 |  |  | $ | 27 |  |
| Cash paid for operating leases | 12 |  |  | 12 |  |  | 26 |  |  | 24 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | — |  |  | 11 |  |  | 4 |  |  | 123 |  |

[0000106040-23-000010:notes:117]
[same as prior period, unchanged from 0000106040-22-000065:notes:108]

[0000106040-23-000010:notes:118]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of December 30, 2022, the Company had the following minimum long-term commitments:

[0000106040-23-000010:notes:119]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining six months of 2023 |  | $ | 193 |  |
| 2024 |  | 256 |  |
| 2025 |  | 180 |  |
| 2026 |  | 53 |  |
| 2027 |  | 46 |  |
| Thereafter |  | 150 |  |
| Total |  | $ | 878 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-23-000010:notes:120]
[same as prior period, unchanged from 0000106040-22-000065:notes:111]

[0000106040-23-000010:notes:121]
[same as prior period, unchanged from 0000106040-22-000065:notes:112]

[0000106040-23-000010:notes:122]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 79 |  |  | $ | 78 |  |  | $ | 154 |  |  | $ | 145 |  |  |  |
| ESPP | 7 |  |  | 9 |  |  | 18 |  |  | 18 |  |  |  |
| Total | $ | 86 |  |  | $ | 87 |  |  | $ | 172 |  |  | $ | 163 |  |  |  |

[0000106040-23-000010:notes:123]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 12 |  |  | $ | 14 |  |  | $ | 26 |  |  | $ | 23 |  |  |  |
| Research and development | 40 |  |  | 43 |  |  | 79 |  |  | 83 |  |  |  |
| Selling, general and administrative | 34 |  |  | 30 |  |  | 67 |  |  | 57 |  |  |  |
| Subtotal | 86 |  |  | 87 |  |  | 172 |  |  | 163 |  |  |  |
| Tax benefit | (11) |  |  | (13) |  |  | (24) |  |  | (28) |  |  |  |
| Total | $ | 75 |  |  | $ | 74 |  |  | $ | 148 |  |  | $ | 135 |  |  |  |

[0000106040-23-000010:notes:124]
[same as prior period, unchanged from 0000106040-22-000065:notes:115]

[0000106040-23-000010:notes:125]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 30, 2022:

[0000106040-23-000010:notes:126]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 571 |  |  | 2.4 |
| ESPP | 89 |  |  | 1.9 |
| Total unamortized compensation cost | $ | 660 |  |  |  |

[0000106040-23-000010:notes:127]
[same as prior period, unchanged from 0000106040-22-000065:notes:118]

[0000106040-23-000010:notes:128]
[same as prior period, unchanged from 0000106040-22-000065:notes:119]

[0000106040-23-000010:notes:129]
[same as prior period, unchanged from 0000106040-22-000065:notes:120]

[0000106040-23-000010:notes:130]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at December 30, 2022:

[0000106040-23-000010:notes:131]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at July 1, 2022 | 0.9 |  |  | $ | 66.76 |  |  | 0.54 |  |  |
| Canceled or expired | (0.5) |  |  | 83.50 |  |  |  |  |  |
| Options outstanding at December 30, 2022 | 0.4 |  |  | $ | 44.63 |  |  | 0.57 |  |  |

[0000106040-23-000010:notes:132]
[same as prior period, unchanged from 0000106040-22-000065:notes:123]

[0000106040-23-000010:notes:133]
[same as prior period, unchanged from 0000106040-22-000065:notes:124]

[0000106040-23-000010:notes:134]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | $ | 52.89 |  |  |  |
| Granted | 4.7 |  |  | 43.34 |  |  |  |
| Vested | (4.7) |  |  | 53.76 |  |  | $ | 200 |  |
| Forfeited | (0.9) |  |  | 58.54 |  |  |  |
| RSUs and PSUs outstanding at December 30, 2022 | 14.5 |  |  | $ | 49.18 |  |  |  |

[0000106040-23-000010:notes:135]
[same as prior period, unchanged from 0000106040-22-000065:notes:126]

[0000106040-23-000010:notes:136]
[same as prior period, unchanged from 0000106040-22-000065:notes:127]

[0000106040-23-000010:notes:137]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the six months ended December 30, 2022 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. Although the Company will reevaluate the repurchasing of common stock when appropriate, there can be no assurance if, when or at what level the Company may resume such activity. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of December 30, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-23-000010:notes:138]
[same as prior period, unchanged from 0000106040-22-000065:notes:129]

[0000106040-23-000010:notes:139]
[same as prior period, unchanged from 0000106040-22-000065:notes:130]

[0000106040-23-000010:notes:140]
[same as prior period, unchanged from 0000106040-22-000065:notes:131]

[0000106040-23-000010:notes:141]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | (385) |  |  | $ | 646 |  |  | $ | (301) |  |  | $ | 1,350 |  |
| Income tax expense | 61 |  |  | 82 |  |  | 118 |  |  | 176 |  |
| Effective tax rate | (16) | % |  | 13 | % |  | (39) | % |  | 13 | % |

[0000106040-23-000010:notes:142]
Beginning in fiscal year 2023, the 2017 Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and six months ended December 30, 2022 but did not have a material impact on the effective tax rate. The primary drivers of the difference between the effective tax rate for the three and six months ended December 30, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031.

[0000106040-23-000010:notes:143]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 31, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and six months ended December 31, 2021 included the discrete effect of an increase to unrecognized tax benefits of $8 million and $25 million, respectively, as a result of ongoing discussions with various taxing authorities.

[0000106040-23-000010:notes:144]
[same as prior period, unchanged from 0000106040-22-000065:notes:135]

[0000106040-23-000010:notes:145]
[same as prior period, unchanged from 0000106040-22-000065:notes:136]

[0000106040-23-000010:notes:146]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended December 30, 2022 (in millions):

[0000106040-23-000010:notes:147]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 11 |  |
| Gross decreases related to prior year tax positions | (12) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at December 30, 2022 | $ | 1,042 |  |

[0000106040-23-000010:notes:148]
As of December 30, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.04 billion. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of December 30, 2022 was $279 million. Of these amounts, approximately $1.18 billion could result in potential cash payments.

[0000106040-23-000010:notes:149]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for years 2008 through 2015. In September 2018 and March 2019, the Company filed petitions with the U.S. Tax Court covering years 2008 through 2012, for which it had received statutory notices of deficiency, while years 2013 through 2015 remain in the jurisdiction of the IRS’s Examination function. The IRS has filed various Amendments to Answer with the U.S. Tax Court which, together with the notices of proposed adjustments, would result in additional federal income tax liabilities totaling approximately $1.6 billion and penalties totaling $449 million with respect to years 2008 through 2015. In May 2022, the Company and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. Based on the tentative settlement for resolution, the Company expects to pay tax and interest totaling approximately $720 million to $760 million, which the Company expects to be partially offset by future reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million. While the Company continues to work with the IRS to come to a final agreement on the federal tax and interest calculations, the Company is uncertain as to when a final agreement will be reached and the exact timing of when any payments will be made. However, the Company believes it is reasonably likely that these payments may be made within the next twelve months and has classified that portion of these unrecognized tax benefits, including interest in Income taxes payable on its Condensed Consolidated Balance Sheets as of December 30, 2022. This classification and amount may be subject to change in the next twelve months depending on when the Company is able to reach a final agreement with the IRS.

[0000106040-23-000010:notes:150]
[same as prior period, unchanged from 0000106040-22-000065:notes:141]


## us-gaap:EarningsPerShareTextBlock

[0000106040-23-000010:notes:151]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-23-000010:notes:152]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (446) |  |  |  | $ | 564 |  |  | $ | (419) |  |  | $ | 1,174 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 318 |  |  |  | 312 |  |  | 317 |  |  | 311 |  |
| Employee stock options, RSUs, PSUs, and ESPP | — |  |  |  | 3 |  |  | — |  |  | 4 |  |
| Basic and diluted | 318 |  |  |  | 315 |  |  | 317 |  |  | 315 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic | $ | (1.40) |  |  |  | $ | 1.81 |  |  | $ | (1.32) |  |  | $ | 3.77 |  |
| Diluted | $ | (1.40) |  |  |  | $ | 1.79 |  |  | $ | (1.32) |  |  | $ | 3.73 |  |
| Anti-dilutive potential common shares excluded | 15 |  |  |  | 5 |  |  | 15 |  |  | 3 |  |

[0000106040-23-000010:notes:153]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three and six months ended and December 31, 2021, the Company excluded common shares subject to certain outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For the three and six months ended December 30, 2022, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-23-000010:notes:154]
[same as prior period, unchanged from 0000106040-22-000065:notes:145]

[0000106040-23-000010:notes:155]
[same as prior period, unchanged from 0000106040-22-000065:notes:146]

[0000106040-23-000010:notes:156]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 61 |  |  | $ | 3 |  |  | $ | 85 |  |  | $ | 18 |  |  |  |
| Asset impairments and losses on disposal of assets | 15 |  |  | (1) |  |  | 15 |  |  | 2 |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 76 |  |  | $ | 2 |  |  | $ | 100 |  |  | $ | 20 |  |  |  |

[0000106040-23-000010:notes:157]
The following table presents an analysis of the components of these activities against the reserve during the six months ended December 30, 2022:

[0000106040-23-000010:notes:158]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 1, 2022 | $ | 17 |  |  |  |  |  |
| Charges | 85 |  |  |  |  |  |
| Cash payments | (69) |  |  |  |  |  |
| Accrual balance at December 30, 2022 | $ | 33 |  |  |  |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-23-000010:notes:159]
Legal Proceedings
Tax

[0000106040-23-000010:notes:160]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-23-000010:notes:161]
Other Matters

[0000106040-23-000010:notes:162]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:SubsequentEventsTextBlock

[0000106040-23-000010:notes:163]
Subsequent EventsOn January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”) from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million. The Preferred Shares will have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. The Preferred Shares will be convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate of the stated value plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the holder beginning on January 31, 2024, or on the date a specified spin-off transaction is completed, if earlier. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days. After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares at an amount equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares. The Preferred Shares will vote on an as-converted equivalent basis along with holders of the Company’s common stock, except to the extent that shares issuable upon conversion of the Preferred Stock would exceed 19.9% of common stock outstanding immediately prior to the original issuance date of the Preferred Stock. In the event of liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock.
