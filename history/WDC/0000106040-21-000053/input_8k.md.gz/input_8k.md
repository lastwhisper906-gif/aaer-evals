# WDC 8-K — 0000106040-21-000046 filed 2021-10-28

## item codes, every 8-K on or before 2021-11-04

- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2021-11-04

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-21-000046:8k_2_02:1]
EX-99.1
2
ex991-pressreleaseq122.htm
EX-99.1

[0000106040-21-000046:8k_2_02:2]
Document

[0000106040-21-000046:8k_2_02:3]
Exhibit 99.1

[0000106040-21-000046:8k_2_02:4]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:5]
News Summary

[0000106040-21-000046:8k_2_02:6]
•First quarter revenue was $5.1 billion, up 29% year-over-year (YoY). Cloud revenue increased 72%, Client revenue increased 6%, and Consumer revenue increased 10% YoY.

[0000106040-21-000046:8k_2_02:7]
•First quarter GAAP earnings per share (EPS) was $1.93 and non-GAAP EPS was $2.49. Non-GAAP EPS included $56 million in COVID-related expenses.

[0000106040-21-000046:8k_2_02:8]
•Generated operating cash flow of $521 million and free cash flow of $224 million.

[0000106040-21-000046:8k_2_02:9]
•On October 22, 2021, repaid remaining Term-Loan B balance of $943 million.

[0000106040-21-000046:8k_2_02:10]
•Expecting fiscal second quarter 2022 revenue to be in the range of $4.70 billion to $4.90 billion with non-GAAP EPS in the range of $1.95 to $2.25.

[0000106040-21-000046:8k_2_02:11]
SAN JOSE, Calif., — October 28, 2021 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal first quarter 2022 financial results.

[0000106040-21-000046:8k_2_02:12]
“Strong demand across diverse end markets, particularly for our cloud products, combined with Western Digital’s strong innovation engine, broad routes to market and sharpened execution, enabled us to deliver solid results within our guidance range, even in the face of significant COVID impacts and supply chain disruptions,” said David Goeckeler, Western Digital CEO. “While these disruptions are transitory, the long-term opportunities for Western Digital remain unchanged as the world’s digital transformation continues to accelerate. We believe that the migration to the cloud and demand for storage solutions throughout the client and consumer markets will continue to drive a huge opportunity for Western Digital and our customers.”

[0000106040-21-000046:8k_2_02:13]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:14]
Q1 2022 Financial Highlights

[0000106040-21-000046:8k_2_02:15]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q1 2022 | Q4 2021 | Q/Q |  | Q1 2022 | Q4 2021 | Q/Q |
| Revenue ($M) |  | $5,051 | $4,920 | up 3% |  | $5,051 | $4,920 | up 3% |
| Gross Margin |  | 33.0% | 31.8% | up 1.2 ppt |  | 33.9% | 32.9% | up 1.0 ppt |
| Operating Expenses ($M) |  | $887 | $891 | - |  | $761 | $790 | down 4% |
| Operating Income ($M) |  | $778 | $675 | up 15% |  | $952 | $828 | up 15% |
| Net Income ($M) |  | $610 | $622 | down 2% |  | $787 | $680 | up 16% |
| Earnings Per Share |  | $1.93 | $1.97 | down 2% |  | $2.49 | $2.16 | up 15% |

[0000106040-21-000046:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q1 2022 | Q1 2021 | Y/Y |  | Q1 2022 | Q1 2021 | Y/Y |
| Revenue ($M) |  | $5,051 | $3,922 | up 29% |  | $5,051 | $3,922 | up 29% |
| Gross Margin |  | 33.0% | 23.0% | up 10.0 ppt |  | 33.9% | 26.3% | up 7.6 ppt |
| Operating Expenses ($M) |  | $887 | $834 | up 6% |  | $761 | $708 | up 7% |
| Operating Income ($M) |  | $778 | $70 | up 1,011% |  | $952 | $323 | up 195% |
| Net Income ($M) |  | $610 | ($60) | * |  | $787 | $196 | up 302% |
| Earnings Per Share |  | $1.93 | ($0.20) | * |  | $2.49 | $0.65 | up 283% |
| *not a meaningful figure |  |  |  |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:17]
The company generated $521 million in cash flow from operations, made a total debt repayment of $213 million, and ended the quarter with $3.3 billion of total cash and cash equivalents. Average shares outstanding were 316 million for the quarter. In addition, as a result of strong financial results and free cash flow generation, on October 22, 2021, the company fully repaid the remaining balance of Term Loan B in an amount of $943 million, bringing total gross debt outstanding to $7.7 billion.

[0000106040-21-000046:8k_2_02:18]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-21-000046:8k_2_02:19]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:20]
New End Market Summary

[0000106040-21-000046:8k_2_02:21]
| Revenue ($M) | Q1 2022 | Q4 2021 | Q/Q |  |  | Q1 2021 | Y/Y |  |  |  |  |  |  |
| Cloud | $2,225 | $1,995 | up 12% |  |  | $1,291 | up 72% |  |  |  |  |  |  |
| Client | $1,853 | $1,895 | down 2% |  |  | $1,750 | up 6% |  |  |  |  |  |  |
| Consumer | $973 | $1,030 | down 6% |  |  | $881 | up 10% |  |  |  |  |  |  |
| Total Revenue | $5,051 | $4,920 | up 3% |  |  | $3,922 | up 29% |  |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:22]
In the fiscal first quarter of 2022, Western Digital refined the end-markets we report to be Cloud (primarily products for public or private cloud environments), Client (primarily products sold directly to OEMs or via distribution), and Consumer (primarily retail and other end-user products).

[0000106040-21-000046:8k_2_02:23]
Cloud represented a record 44% of total revenue, led by record capacity enterprise hard drive revenue and nearly 30% sequential growth in enterprise SSD revenue. During the quarter, Western Digital announced OptiNAND, a revolutionary technology that utilizes flash in the HDD control plane to further increase areal density with industry proven PMR technology. Next month, the company will begin volume shipments of its 20 terabyte CMR hard drives utilizing OptiNAND technology. Within enterprise SSDs, the company experienced continued success in the cloud with another successful quarter of qualifications.

[0000106040-21-000046:8k_2_02:24]
In Client, the flash business unit experienced growth– specifically in mobile, gaming, automotive, IOT and industrial applications. Western Digital’s strength in this end market was more than offset by pressure in desktop and notebook hard drives due to supply disruptions at our customers and within the company’s own operations.

[0000106040-21-000046:8k_2_02:25]
In Consumer, revenue from both the flash and hard drive business units declined on a sequential basis due to supply disruptions, in addition to uneven geographic demand due to COVID lockdowns.

[0000106040-21-000046:8k_2_02:26]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:27]
Business Outlook for Fiscal Second Quarter of 2022

[0000106040-21-000046:8k_2_02:28]
|  | Three Months EndingDecember 31, 2021 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) | $4.70 - $4.90 |  | $4.70 - $4.90 |
| Gross margin | 31.0% - 33.0% |  | 32.0% - 34.0% |
| Operating expenses ($M) | $870 - $890 |  | $760 - $780 |
| Interest and other expense, net ($M) | ~$80 |  | ~$70 |
| Tax rate | N/A |  | ~11% (2) |
| Diluted earnings per share | N/A |  | $1.95 - $2.25 |
| Diluted shares outstanding (in millions) | ~316 |  | ~316 |

[0000106040-21-000046:8k_2_02:29]
(1) Non-GAAP gross margin guidance excludes amortization of acquired intangible assets and stock-based compensation expense, totaling approximately $30 million to $50 million. The company’s non-GAAP operating expenses guidance excludes amortization of acquired intangible assets; stock-based compensation expense; and employee termination, asset impairment and other charges, totaling approximately $100 million to $120 million. The company's non-GAAP interest and other expense guidance excludes approximately $10 million of convertible debt activity. In the aggregate, non-GAAP diluted earnings per share guidance excludes these items totaling $140 million to $180 million. The timing and amount of these charges excluded from non-GAAP gross margin, non-GAAP operating expenses, non-GAAP interest and other expense, net and non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the company excludes from its non-GAAP tax rate and non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of non-GAAP gross margin, non-GAAP operating expenses, non-GAAP interest and other expense, non-GAAP tax rate and non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, interest and other expense, tax rate and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-21-000046:8k_2_02:30]
(2) The non-GAAP tax rate provided is based on a percentage of non-GAAP pre-tax income. Due to differences in the tax treatment of items excluded from our non-GAAP net income and because our tax rate is based on an estimated forecasted annual GAAP tax rate, our estimated non-GAAP tax rate may differ from our GAAP tax rate and from our actual tax rates.

[0000106040-21-000046:8k_2_02:31]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:32]
Investor Communications

[0000106040-21-000046:8k_2_02:33]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal second quarter of 2022 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-21-000046:8k_2_02:34]
About Western Digital

[0000106040-21-000046:8k_2_02:35]
Western Digital, a leader in data infrastructure, creates environments for data to thrive. The company is driving the innovation needed to help customers capture, preserve, access, analyze, and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the company's industry-leading solutions deliver the possibilities of data. Western Digital data-centric solutions are comprised of the Western Digital®, G-Technology™, SanDisk® and WD® brands. Financial and investor information is available on the company's Investor Relations website at investor.wdc.com.

[0000106040-21-000046:8k_2_02:36]
Forward-Looking Statements

[0000106040-21-000046:8k_2_02:37]
Western Digital Reports Fiscal First Quarter 2022 Financial Results

[0000106040-21-000046:8k_2_02:38]
associated with compliance with changing legal and regulatory requirements and the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-K filed with the SEC on August 27, 2021, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update these forward-looking statements to reflect new information or events.

[0000106040-21-000046:8k_2_02:39]
###

[0000106040-21-000046:8k_2_02:40]
Western Digital, the Western Digital logo, G-Technology, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-21-000046:8k_2_02:41]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:42]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-21-000046:8k_2_02:43]
(in millions; unaudited; on a US GAAP basis)

[0000106040-21-000046:8k_2_02:44]
|  | October 1,2021 |  | July 2,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,290 |  |  | $ | 3,370 |  |
| Accounts receivable, net | 2,446 |  |  | 2,257 |  |
| Inventories | 3,544 |  |  | 3,616 |  |
| Other current assets | 576 |  |  | 514 |  |
| Total current assets | 9,856 |  |  | 9,757 |  |
| Property, plant and equipment, net | 3,260 |  |  | 3,188 |  |
| Notes receivable and investments in Flash Ventures | 1,646 |  |  | 1,586 |  |
| Goodwill | 10,066 |  |  | 10,066 |  |
| Other intangible assets, net | 364 |  |  | 442 |  |
| Other non-current assets | 1,199 |  |  | 1,093 |  |
| Total assets | $ | 26,391 |  |  | $ | 26,132 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,896 |  |  | $ | 1,934 |  |
| Accounts payable to related parties | 378 |  |  | 398 |  |
| Accrued expenses | 1,617 |  |  | 1,653 |  |
| Accrued compensation | 567 |  |  | 634 |  |
| Current portion of long-term debt | 251 |  |  | 251 |  |
| Total current liabilities | 4,709 |  |  | 4,870 |  |
| Long-term debt | 8,270 |  |  | 8,474 |  |
| Other liabilities | 2,051 |  |  | 2,067 |  |
| Total liabilities | 15,030 |  |  | 15,411 |  |
| Total shareholders’ equity | 11,361 |  |  | 10,721 |  |
| Total liabilities and shareholders’ equity | $ | 26,391 |  |  | $ | 26,132 |  |

[0000106040-21-000046:8k_2_02:45]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:46]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-21-000046:8k_2_02:47]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-21-000046:8k_2_02:48]
|  | Three Months Ended |  |  |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |  |  |  |  |
| Revenue, net | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,386 |  |  | 3,018 |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,665 |  |  | 904 |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 578 |  |  | 555 |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 291 |  |  | 256 |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment and other charges | 18 |  |  | 23 |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 887 |  |  | 834 |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 778 |  |  | 70 |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense, net | (74) |  |  | (73) |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 704 |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 94 |  |  | 57 |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 610 |  |  | $ | (60) |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.97 |  |  | $ | (0.20) |  |  |  |  |  |  |  |  |  |  |  |
| Diluted | $ | 1.93 |  |  | $ | (0.20) |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 310 |  |  | 303 |  |  |  |  |  |  |  |  |  |  |  |
| Diluted | 316 |  |  | 303 |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:49]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:50]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-21-000046:8k_2_02:51]
(in millions; unaudited; on a US GAAP basis)

[0000106040-21-000046:8k_2_02:52]
|  | Three Months Ended |  |  |  |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |  |  |  |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 610 |  |  | $ | (60) |  |  |  |  |  |  |  |  |  |  |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization | 250 |  |  | 374 |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 76 |  |  | 76 |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes | 27 |  |  | 11 |  |  |  |  |  |  |  |  |  |  |
| Loss on disposal of assets | — |  |  | 1 |  |  |  |  |  |  |  |  |  |  |
| Amortization of debt issuance costs and discounts | 10 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |
| Other non-cash operating activities, net | (12) |  |  | (6) |  |  |  |  |  |  |  |  |  |  |
| Changes in: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net | (188) |  |  | 282 |  |  |  |  |  |  |  |  |  |  |
| Inventories | 73 |  |  | (285) |  |  |  |  |  |  |  |  |  |  |
| Accounts payable | (41) |  |  | 99 |  |  |  |  |  |  |  |  |  |  |
| Accounts payable to related parties | (20) |  |  | (3) |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses | (36) |  |  | (23) |  |  |  |  |  |  |  |  |  |  |
| Accrued compensation | (67) |  |  | 26 |  |  |  |  |  |  |  |  |  |  |
| Other assets and liabilities, net | (161) |  |  | (139) |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | 521 |  |  | 363 |  |  |  |  |  |  |  |  |  |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (245) |  |  | (330) |  |  |  |  |  |  |  |  |  |  |
| Activity related to Flash Ventures, net | (52) |  |  | 163 |  |  |  |  |  |  |  |  |  |  |
| Strategic Investments and Other, net | (15) |  |  | 1 |  |  |  |  |  |  |  |  |  |  |
| Net cash used in investing activities | (312) |  |  | (166) |  |  |  |  |  |  |  |  |  |  |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee stock plans, net | (76) |  |  | (40) |  |  |  |  |  |  |  |  |  |  |
| Repayment of debt | (213) |  |  | (213) |  |  |  |  |  |  |  |  |  |  |
| Net cash used in financing activities | (289) |  |  | (253) |  |  |  |  |  |  |  |  |  |  |
| Effect of exchange rate changes on cash | — |  |  | 3 |  |  |  |  |  |  |  |  |  |  |
| Net decrease in cash and cash equivalents | (80) |  |  | (53) |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents, beginning of period | 3,370 |  |  | 3,048 |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents, end of period | $ | 3,290 |  |  | $ | 2,995 |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:53]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:54]
Supplemental Operating Segment Results

[0000106040-21-000046:8k_2_02:55]
(in millions; except percentages; unaudited)

[0000106040-21-000046:8k_2_02:56]
|  | Three Months Ended |
|  | October 1,2021 |  | October 2,2020 |
| Net revenue: |  |  |  |
| HDD | $ | 2,561 |  |  | $ | 1,844 |  |
| Flash | 2,490 |  |  | 2,078 |  |
| Total net revenue | 5,051 |  |  | 3,922 |  |
| Gross profit |  |  |  |
| HDD | $ | 792 |  |  | $ | 483 |  |
| Flash | 921 |  |  | 548 |  |
| Total gross profit by segment | 1,713 |  |  | 1,031 |  |
| Unallocated corporate items: |  |  |  |
| Amortization of acquired intangible assets | 39 |  |  | 145 |  |
| Stock-based compensation expense | 9 |  |  | 12 |  |
| Charges related to a power outage incident and related recovery | — |  |  | (30) |  |
| Total unallocated corporate items | (48) |  |  | (127) |  |
| Total gross profit | $ | 1,665 |  |  | $ | 904 |  |
| Gross margin: |  |  |  |
| HDD | 30.9 | % |  | 26.2 | % |
| Flash | 37.0 | % |  | 26.4 | % |
| Total gross margin by segment | 33.9 | % |  | 26.3 | % |
| Consolidated Total | 33.0 | % |  | 23.0 | % |

[0000106040-21-000046:8k_2_02:57]
Historically, the Company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Company announced a decision to reorganize its business by forming two separate product business units: hard disk drives (“HDD”) and flash-based products (“Flash”). To align with the new operating model and business structure, the Company made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of its operating segments and now reports two segments: HDD and Flash. In the table above, total gross profit by segment and total gross margin by segment are non-GAAP financial measures, which are also referred to herein as Non-GAAP gross profit and Non-GAAP gross margin, respectively.

[0000106040-21-000046:8k_2_02:58]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:59]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-21-000046:8k_2_02:60]
(in millions; unaudited)

[0000106040-21-000046:8k_2_02:61]
|  | Three Months Ended |  |  |  |  |
|  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |  |  |
| GAAP cost of revenue | $ | 3,386 |  |  | $ | 3,354 |  |  | $ | 3,018 |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | (39) |  |  | (38) |  |  | (145) |  |  |  |  |  |  |  |
| Stock-based compensation expense | (9) |  |  | (14) |  |  | (12) |  |  |  |  |  |  |  |
| Charges related to a power outage incident and related recovery | — |  |  | — |  |  | 30 |  |  |  |  |  |  |  |
| Non-GAAP cost of revenue | $ | 3,338 |  |  | $ | 3,302 |  |  | $ | 2,891 |  |  |  |  |  |  |  |
| GAAP gross profit | $ | 1,665 |  |  | $ | 1,566 |  |  | $ | 904 |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | 39 |  |  | 38 |  |  | 145 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 9 |  |  | 14 |  |  | 12 |  |  |  |  |  |  |  |
| Charges related to a power outage incident and related recovery | — |  |  | — |  |  | (30) |  |  |  |  |  |  |  |
| Non-GAAP gross profit | $ | 1,713 |  |  | $ | 1,618 |  |  | $ | 1,031 |  |  |  |  |  |  |  |
| GAAP operating expenses | $ | 887 |  |  | $ | 891 |  |  | $ | 834 |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | (39) |  |  | (38) |  |  | (39) |  |  |  |  |  |  |  |
| Stock-based compensation expense | (67) |  |  | (65) |  |  | (64) |  |  |  |  |  |  |  |
| Employee termination, asset impairment and other charges | (18) |  |  | 4 |  |  | (23) |  |  |  |  |  |  |  |
| Other | (2) |  |  | (2) |  |  | — |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 761 |  |  | $ | 790 |  |  | $ | 708 |  |  |  |  |  |  |  |
| GAAP operating income (loss) | $ | 778 |  |  | $ | 675 |  |  | $ | 70 |  |  |  |  |  |  |  |
| Cost of revenue adjustments | 48 |  |  | 52 |  |  | 127 |  |  |  |  |  |  |  |
| Operating expense adjustments | 126 |  |  | 101 |  |  | 126 |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 952 |  |  | $ | 828 |  |  | $ | 323 |  |  |  |  |  |  |  |
| GAAP interest and other expense, net | $ | (74) |  |  | $ | (79) |  |  | $ | (73) |  |  |  |  |  |  |  |
| Convertible debt activity and other | 6 |  |  | — |  |  | 5 |  |  |  |  |  |  |  |
| Non-GAAP interest and other expense, net | $ | (68) |  |  | $ | (79) |  |  | $ | (68) |  |  |  |  |  |  |  |
| GAAP income tax expense | $ | 94 |  |  | $ | (26) |  |  | $ | 57 |  |  |  |  |  |  |  |
| Income tax adjustments | 3 |  |  | 95 |  |  | 2 |  |  |  |  |  |  |  |
| Non-GAAP income tax expense | $ | 97 |  |  | $ | 69 |  |  | $ | 59 |  |  |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:62]
WESTERN DIGITAL CORPORATION

[0000106040-21-000046:8k_2_02:63]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-21-000046:8k_2_02:64]
(in millions, except per share amounts; unaudited)

[0000106040-21-000046:8k_2_02:65]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |
| GAAP net income (loss) | $ | 610 |  |  | $ | 622 |  |  | $ | (60) |  |  |  |  |  |
| Amortization of acquired intangible assets | 78 |  |  | 76 |  |  | 184 |  |  |  |  |  |
| Stock-based compensation expense | 76 |  |  | 79 |  |  | 76 |  |  |  |  |  |
| Employee termination, asset impairment and other charges | 18 |  |  | (4) |  |  | 23 |  |  |  |  |  |
| Charges related to a power outage incident and related recovery | — |  |  | — |  |  | (30) |  |  |  |  |  |
| Convertible debt activity and other | 8 |  |  | 2 |  |  | 5 |  |  |  |  |  |
| Income tax adjustments | (3) |  |  | (95) |  |  | (2) |  |  |  |  |  |
| Non-GAAP net income | $ | 787 |  |  | $ | 680 |  |  | $ | 196 |  |  |  |  |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 1.93 |  |  | $ | 1.97 |  |  | $ | (0.20) |  |  |  |  |  |
| Non-GAAP | $ | 2.49 |  |  | $ | 2.16 |  |  | $ | 0.65 |  |  |  |  |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 316 |  |  | 315 |  |  | 303 |  |  |  |  |  |
| Non-GAAP | 316 |  |  | 315 |  |  | 303 |  |  |  |  |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by operating activities | $ | 521 |  |  | $ | 994 |  |  | $ | 363 |  |  |  |  |  |
| Purchase of property, plant and equipment, net | (245) |  |  | (304) |  |  | (330) |  |  |  |  |  |
| Activity related to flash ventures, net | (52) |  |  | 102 |  |  | 163 |  |  |  |  |  |
| Free cash flow | $ | 224 |  |  | $ | 792 |  |  | $ | 196 |  |  |  |  |  |

[0000106040-21-000046:8k_2_02:66]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth non-GAAP cost of revenue; non-GAAP gross profit; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP interest and other expense, net; non-GAAP income tax expense; non-GAAP net income; non-GAAP diluted income per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, the amortization of acquired intangible assets, stock-based compensation expense, employee termination, asset impairment and other charges, charges related to a power outage incident and related recovery, convertible debt activity, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company's results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company's performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-21-000046:8k_2_02:67]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-21-000046:8k_2_02:68]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company's acquisitions and any related impairment charges.

[0000106040-21-000046:8k_2_02:69]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company's control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company's peers, a majority of whom also exclude stock-based compensation expense from their non-GAAP results.

[0000106040-21-000046:8k_2_02:70]
Employee termination, asset impairment and other charges. From time-to-time, in order to realign the company's operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-21-000046:8k_2_02:71]
Charges related to a power outage incident and related recovery. In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated through the company's joint venture with Kioxia Corporation in Yokkaichi, Japan. The power outage incident resulted in costs associated with the repair of damaged tools and the write-off of damaged inventory and unabsorbed manufacturing overhead costs which are expensed as incurred. During fiscal year 2021, the company received recoveries of these losses from its insurance carriers. These charges and recoveries are inconsistent in amount and frequency, and the company believes these charges or recoveries are not part of the ongoing production operation of its business.

[0000106040-21-000046:8k_2_02:72]
Convertible debt activity. The company excludes non-cash economic interest expense associated with its convertible notes. These charges do not reflect the company's operating results, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-21-000046:8k_2_02:73]
Other adjustments. From time-to-time, the company incurs charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-21-000046:8k_2_02:74]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments to estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-21-000046:8k_2_02:75]
Additionally, free cash flow is defined as cash flows provided by operating activities less purchases of property, plant and equipment, net of proceeds from sales of property, plant and equipment, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company's business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-21-000046:8k_2_02:76]
___________________

[0000106040-21-000046:8k_2_02:77]
Contacts:

[0000106040-21-000046:8k_2_02:78]
Western Digital Corp.

[0000106040-21-000046:8k_2_02:79]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Lisa Neitzel |
| 949.672.9655 |  | 408.717.7607 |
| peter.andrew@wdc.com |  | lisa.neitzel@wdc.com |
| investor@wdc.com |  |  |
