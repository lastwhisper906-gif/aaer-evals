# WDC MD&A — 0000106040-21-000053


## mdna

[0000106040-21-000053:mdna:1]
[same as prior period, unchanged from 0000106040-21-000024:mdna:1]

[0000106040-21-000053:mdna:2]
[same as prior period, unchanged from 0000106040-21-000024:mdna:2]

[0000106040-21-000053:mdna:3]
[same as prior period, unchanged from 0000106040-21-000024:mdna:3]

[0000106040-21-000053:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of information technology (“IT”) and the infrastructure that enables the proliferation of data in virtually every industry. We create environments for data to thrive. We are driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, our industry-leading solutions deliver the possibilities of data.

[0000106040-21-000053:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2022, which ends on July 1, 2022, and 2021, which ended on July 2, 2021, are each comprised of 52 weeks, with all quarters presented consisting of  13 weeks.

[0000106040-21-000053:mdna:6]
[same as prior period, unchanged from 0000106040-21-000024:mdna:7]

[0000106040-21-000053:mdna:7]
[same as prior period, unchanged from 0000106040-21-000024:mdna:8]

[0000106040-21-000053:mdna:8]
Historically, our company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is our Chief Operating Decision Maker (“CODM”), announced a decision to reorganize our business by forming two separate product business units: hard disk drives (“HDD”) and flash-based products (“Flash”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. To align with the new operating model and business structure, we made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of our operating segments and concluded that we now have two reportable segments: HDD and Flash.

[0000106040-21-000053:mdna:9]
Our broad portfolio of technology and products address multiple end markets.  In the fiscal first quarter of 2022, we refined the end markets we report to be Cloud, Client and Consumer. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which we believe we are uniquely positioned to address as the only provider of both hard drive and flash products. Through the Client end market, we provide our OEM and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-21-000053:mdna:10]
The discussion and analysis included under Results of Operations below reflects our new business unit structure and end markets discussed above.

[0000106040-21-000053:mdna:11]
[same as prior period, unchanged from 0000106040-21-000024:mdna:10]

[0000106040-21-000053:mdna:12]
As the ongoing COVID-19 pandemic has evolved, we have implemented and maintained more thorough sanitation practices as outlined by health organizations and supported vaccination efforts. As we begin to phase in a return to site for more employees, we are monitoring and adopting practices recommended by health organizations to ensure the continued safety of our employees and business partners. In addition, the responses to COVID-19 taken by others in the supply chain have increased the costs of their services which have in turn impacted our operations. We incurred incremental charges primarily

[0000106040-21-000053:mdna:13]
related to logistics, absorption and other factory-related costs of approximately $56 million and $28 million during the three months ended October 1, 2021 and October 2, 2020, respectively, which were recorded in Cost of revenue.

[0000106040-21-000053:mdna:14]
The technology hardware and semiconductor industries faced supply chain disruptions during the quarter that negatively impacted both our and our customers’ ability to manufacture products, which collectively reduced revenues across all of our end markets. While these supply disruptions may continue for the near term, we ultimately expect that they will be transitory as demand for our products has remained solid during the pandemic, with work-from-home, distance learning, and at home entertainment driving demand for cloud environments, new devices, and retail products.

[0000106040-21-000053:mdna:15]
The COVID-19 environment remains dynamic and we will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “The COVID-19 pandemic could negatively affect our business” and “We are dependent on a limited number of qualified suppliers who provide critical services, materials or components, and a disruption in our supply chain could negatively affect our business” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021 for more information regarding the risks we face as a result of the COVID-19 pandemic and supply chain disruptions.

[0000106040-21-000053:mdna:16]
[same as prior period, unchanged from 0000106040-21-000024:mdna:16]

[0000106040-21-000053:mdna:17]
In October 2020, Kioxia announced the start of construction of the shell for a new fabrication facility in Yokkaichi, Japan, referred to as “Y7”. We expect to continue Flash Ventures investments into Y7 in due course, following the completion of agreements with Kioxia governing the construction and operation of the new facility and according to the then-prevailing market trends.

[0000106040-21-000053:mdna:18]
[same as prior period, unchanged from 0000106040-21-000024:mdna:21]

[0000106040-21-000053:mdna:19]
First Quarter Overview

[0000106040-21-000053:mdna:20]
[same as prior period, unchanged from 0000106040-21-000024:mdna:23]

[0000106040-21-000053:mdna:21]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 5,051 |  |  | 100.0 | % |  | $ | 3,922 |  |  | 100.0 | % |  | $ | 1,129 |  |  | 29 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,386 |  |  | 67.0 |  |  | 3,018 |  |  | 77.0 |  |  | 368 |  |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,665 |  |  | 33.0 |  |  | 904 |  |  | 23.0 |  |  | 761 |  |  | 84 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 578 |  |  | 11.4 |  |  | 555 |  |  | 14.2 |  |  | 23 |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 291 |  |  | 5.8 |  |  | 256 |  |  | 6.5 |  |  | 35 |  |  | 14 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 18 |  |  | 0.4 |  |  | 23 |  |  | 0.6 |  |  | (5) |  |  | (22) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 887 |  |  | 17.6 |  |  | 834 |  |  | 21.3 |  |  | 53 |  |  | 6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 778 |  |  | 15.4 |  |  | 70 |  |  | 1.8 |  |  | 708 |  |  | 1,011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | — |  |  | 2 |  |  | 0.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (78) |  |  | (1.5) |  |  | (84) |  |  | (2.1) |  |  | 6 |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 2 |  |  | — |  |  | 9 |  |  | 0.2 |  |  | (7) |  |  | (78) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (74) |  |  | (1.5) |  |  | (73) |  |  | (1.9) |  |  | (1) |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 704 |  |  | 13.9 |  |  | (3) |  |  | (0.1) |  |  | 707 |  |  | (23,567) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 94 |  |  | 1.9 |  |  | 57 |  |  | 1.5 |  |  | 37 |  |  | 65 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 610 |  |  | 12.1 |  |  | $ | (60) |  |  | (1.5) |  |  | 670 |  |  | (1,117) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000053:mdna:22]
[same as prior period, unchanged from 0000106040-21-000024:mdna:25]

[0000106040-21-000053:mdna:23]
37

[0000106040-21-000053:mdna:24]
The following table sets forth, for the periods presented, a summary of our segment information:

[0000106040-21-000053:mdna:25]
|  | Three Months Ended |
|  | October 1,2021 |  | October 2,2020 |
|  | (in millions) |
| Net revenue: |  |  |  |
| HDD | $ | 2,561 |  |  | $ | 1,844 |  |
| Flash | 2,490 |  |  | 2,078 |  |
| Total net revenue | $ | 5,051 |  |  | $ | 3,922 |  |
| Gross profit |  |  |  |
| HDD | $ | 792 |  |  | $ | 483 |  |
| Flash | 921 |  |  | 548 |  |
| Unallocated corporate items: |  |  |  |
| Amortization of acquired intangible assets | 39 |  |  | 145 |  |
| Stock-based compensation expense | 9 |  |  | 12 |  |
| Charges related to a power outage incident and related recovery | — |  |  | (30) |  |
| Total unallocated corporate items | (48) |  |  | (127) |  |
| Consolidated gross profit | $ | 1,665 |  |  | $ | 904 |  |
| Gross margin: |  |  |  |
| HDD | 30.9 | % |  | 26.2 | % |
| Flash | 37.0 | % |  | 26.4 | % |
| Consolidated gross margin | 33.0 | % |  | 23.0 | % |

[0000106040-21-000053:mdna:26]
The Company’s disaggregated revenue information is as follows:

[0000106040-21-000053:mdna:27]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 2,225 |  |  | $ | 1,291 |  |  |  |  |  |  |  |
| Client | 1,853 |  |  | 1,750 |  |  |  |  |  |  |  |
| Consumer | 973 |  |  | 881 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,614 |  |  | $ | 1,079 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 762 |  |  | 629 |  |  |  |  |  |  |  |
| Asia | 2,675 |  |  | 2,214 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |

[0000106040-21-000053:mdna:28]
[same as prior period, unchanged from 0000106040-21-000024:mdna:26]

[0000106040-21-000053:mdna:29]
[same as prior period, unchanged from 0000106040-21-000024:mdna:31]

[0000106040-21-000053:mdna:30]
Comparison of Three Months Ended October 1, 2021 to Three Months Ended October 2, 2020

[0000106040-21-000053:mdna:31]
Consolidated net revenue increased 29% for the three months ended October 1, 2021 compared to the three months ended October 2, 2020, which reflects an increase in exabytes of HDD and flash sold as discussed below. The revenue increase driven by exabytes was partially offset by a decline in the average price per gigabyte of storage for both HDD and Flash as product mix shifted.

[0000106040-21-000053:mdna:32]
HDD revenue increased 39% year over year, primarily driven by a 52% increase in exabytes sold. Higher volume was due to continued demand for our latest generation energy assisted drives among our public and private cloud customers. The strong demand in Cloud was partly offset by a decline in HDD exabytes sold in our Client and Consumer end markets due to pressure in the commercial channel related to component issues impacting our customers’ ability to ship product, greater component sourcing constraints within our own operations and uneven geographic demand due to COVID lockdowns. The revenue increase driven by exabytes was partially offset by a decline in the average price per gigabyte as noted above.

[0000106040-21-000053:mdna:33]
Flash revenue increased 20% year over year, primarily driven by a 30% increase in exabytes sold. The growth in volume was due to strong demand in Cloud for our latest generation of enterprise SSD products and the ramp of new 5G-based mobile phones incorporating our latest BiCS5 flash solutions. Higher volume was also driven by strong demand in gaming along with a growing brand recognition of WD_Black based products. The revenue increase driven by exabytes was partially offset by a decline in the average price per gigabyte as noted above.

[0000106040-21-000053:mdna:34]
The increase in Cloud revenue compared to the prior year was led by growth in both capacity enterprise hard drives and enterprise SSDs as we ramped sales of latest generation products after another successful quarter of qualifications with customers. In Client, we experienced growth–specifically in mobile, gaming, automotive, IOT and industrial applications. Our strength in this end market was partially offset by pressure in desktop and notebook hard drives due to supply disruptions at our customers and within our own operations. In Consumer, revenue growth was driven by strong demand in gaming along with a growing brand recognition of WD_Black.  In the current year quarter, we experienced some supply disruptions, in addition to uneven geographic demand due to COVID lockdowns, which tempered revenue growth in each of our end-markets. However, we expect these impacts to be transitory.

[0000106040-21-000053:mdna:35]
[same as prior period, unchanged from 0000106040-21-000024:mdna:30]

[0000106040-21-000053:mdna:36]
The changes in net revenue by geography reflect an increase in the Americas driven by higher sales of HDD capacity enterprise products to cloud customers in the region and an increase in Asia primarily driven by our increased sales of Flash mobility products to manufacturers in the region.

[0000106040-21-000053:mdna:37]
Our top 10 customers accounted for 43% and 44% of our net revenue for the three months ended October 1, 2021 and October 2, 2020, respectively. For the three months ended October 1, 2021 and October 2, 2020, no single customer accounted for 10% or more of our net revenue.

[0000106040-21-000053:mdna:38]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For both the three months ended October 1, 2021 and October 2, 2020, the programs represented 18% of gross revenues, and adjustments due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-21-000053:mdna:39]
We believe future revenues will be supported by the introduction of our new 20TB HDD, which we are moving forward in qualifications with public and private cloud customers.  Within Cloud, our enterprise SSDs are now qualified with three cloud titans and we have made progress on the qualification process with public and private cloud customers and distribution channels.  We expect these qualifications to drive accelerated growth in 2022 as customers begin to deploy these products into their networks. We also expect the migration to 5G, combined with a continued increase in the amount of storage per phone, to drive revenue growth in our Client end market in the near term. In Consumer, we also expect to see near term revenue growth due to continued growth in the brand recognition of our WD_Black-based products in the channel and retail.

[0000106040-21-000053:mdna:40]
[same as prior period, unchanged from 0000106040-21-000024:mdna:43]

[0000106040-21-000053:mdna:41]
Consolidated gross profit increased by $761 million for the three months ended October 1, 2021 from the comparable period in the prior year, which reflects the increase in revenue in both HDD and Flash, as well as a $106 million decrease in charges in the current period related to amortization expense on acquired intangible assets, some of which became fully amortized.

[0000106040-21-000053:mdna:42]
Consolidated gross margin increased 10.0 percentage points for the three months ended October 1, 2021 from the comparable period in the prior year, which reflects higher gross margin in both HDD and Flash and the lower charges for amortization of acquired intangible assets noted above. HDD and Flash gross margin increased by 4.7 and 10.6 percentage points year over year, respectively, reflecting cost reductions as we ramped production on higher capacity drives.

[0000106040-21-000053:mdna:43]
[same as prior period, unchanged from 0000106040-21-000024:mdna:48]

[0000106040-21-000053:mdna:44]
Research and development (“R&D”) expense increased $23 million for the three months ended October 1, 2021 from the comparable period in the prior year. The increase was driven by higher compensation costs due to merit increases and increased headcount, as well as higher variable compensation cost due to improved earnings.

[0000106040-21-000053:mdna:45]
Selling, general and administrative (“SG&A”) expense increased $35 million for the three months ended October 1, 2021 from the comparable period in the prior year. The increase was driven by approximately $20 million for professional services and approximately $10 million of higher compensation costs due to merit increases and increased headcount, as well as higher variable compensation cost due to improved earnings.

[0000106040-21-000053:mdna:46]
Employee termination, asset impairment and other charges decreased from the comparable period in the prior year as some of the actions initiated in the prior year have been substantially completed. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000053:mdna:47]
[same as prior period, unchanged from 0000106040-21-000024:mdna:52]

[0000106040-21-000053:mdna:48]
Total interest and other expense, net for the three months ended October 1, 2021 was relatively flat with the prior year, reflecting lower interest expense resulting from the pay-down of principal on our debt, partially offset by a lower impact from foreign exchange rates and other gains.

[0000106040-21-000053:mdna:49]
[same as prior period, unchanged from 0000106040-21-000024:mdna:54]

[0000106040-21-000053:mdna:50]
[same as prior period, unchanged from 0000106040-21-000024:mdna:55]

[0000106040-21-000053:mdna:51]
[same as prior period, unchanged from 0000106040-21-000024:mdna:56]

[0000106040-21-000053:mdna:52]
|  | Three Months Ended |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |
|  | ($ in millions) |  |
| Income (loss) before taxes | $ | 704 |  |  | $ | (3) |  |  |  |  |  |  |
| Income tax expense | 94 |  |  | 57 |  |  |  |  |  |  |
| Effective tax rate | 13 | % |  | (1,900) | % |  |  |  |  |  |

[0000106040-21-000053:mdna:53]
The primary drivers of the difference between the effective tax rate for the three months ended October 1, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three months ended October 1, 2021 includes the discrete effect of an increase to unrecognized tax benefits of $16 million as a result of ongoing discussions with various taxing authorities.

[0000106040-21-000053:mdna:54]
The primary drivers of the difference between the effective tax rate for the three months ended October 2, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the three months ended October 2, 2020 includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of purchase accounting deferred tax liabilities due to restructuring activities. The discrete items had no impact on the amount of income taxes paid.

[0000106040-21-000053:mdna:55]
[same as prior period, unchanged from 0000106040-21-000024:mdna:60]

[0000106040-21-000053:mdna:56]
For additional information regarding Income tax expense (benefit), see Part I, Item 1, Note 13, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000053:mdna:57]
[same as prior period, unchanged from 0000106040-21-000024:mdna:63]

[0000106040-21-000053:mdna:58]
[same as prior period, unchanged from 0000106040-21-000024:mdna:64]

[0000106040-21-000053:mdna:59]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 521 |  |  | $ | 363 |  |  |  |
| Investing activities | (312) |  |  | (166) |  |  |  |
| Financing activities | (289) |  |  | (253) |  |  |  |
| Effect of exchange rate changes on cash | — |  |  | 3 |  |  |  |
| Net decrease in cash and cash equivalents | $ | (80) |  |  | $ | (53) |  |  |  |

[0000106040-21-000053:mdna:60]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-21-000053:mdna:61]
We have also filed a shelf registration statement (the “Shelf Registration Statement”) with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-21-000053:mdna:62]
During fiscal 2022, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $3.1 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $2.0 billion during fiscal 2022. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-21-000053:mdna:63]
A total of $2.41 billion and $1.97 billion of our Cash and cash equivalents was held outside of the U.S. as of October 1, 2021 and October 2, 2020, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-21-000053:mdna:64]
[same as prior period, unchanged from 0000106040-21-000024:mdna:70]

[0000106040-21-000053:mdna:65]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $440 million for the three months ended October 1, 2021, as compared to $43 million of net cash used for changes in operating assets and liabilities for the three months ended October 2, 2020. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-21-000053:mdna:66]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |
|  | (in days) |
| Days sales outstanding | 44 |  |  | 49 |  |  |  |  |  |
| Days in inventory | 95 |  |  | 101 |  |  |  |  |  |
| Days payables outstanding | (61) |  |  | (71) |  |  |  |  |  |
| Cash conversion cycle | 78 |  |  | 79 |  |  |  |  |  |

[0000106040-21-000053:mdna:67]
[same as prior period, unchanged from 0000106040-21-000024:mdna:74]

[0000106040-21-000053:mdna:68]
For the three months ended October 1, 2021, DSO decreased by 5 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO and DPO decreased by 6 days and 10 days, respectively, from the comparable period in the prior year primarily reflecting improved supply chain management in the HDD business, as well as routine variations in the timing of purchases and payments during the period.

[0000106040-21-000053:mdna:69]
[same as prior period, unchanged from 0000106040-21-000024:mdna:76]

[0000106040-21-000053:mdna:70]
Net cash used in investing activities for the three months ended October 1, 2021 primarily consisted of $245 million in capital expenditures and a $52 million net increase in notes receivable issuances to Flash Ventures. Net cash used in investing activities for the three months ended October 2, 2020 primarily consisted of $337 million in capital expenditures partially offset by a $163 million net decrease in notes receivable issuances to Flash Ventures to fund its capital expansion.

[0000106040-21-000053:mdna:71]
[same as prior period, unchanged from 0000106040-21-000024:mdna:78]

[0000106040-21-000053:mdna:72]
[same as prior period, unchanged from 0000106040-21-000024:mdna:79]

[0000106040-21-000053:mdna:73]
During the three months ended October 1, 2021, net cash used in financing activities primarily consisted of $213 million for repayment of debt, which included a $150 million voluntary prepayment on our Term Loan B-4, and $78 million for taxes paid on vested stock awards under employee stock plans. Net cash used in financing activities for the three months ended October 2, 2020 primarily consisted of $213 million for the repayment of our debt, which included a $150 million voluntary prepayment on our Term Loan B-4, and $41 million for taxes paid on vested stock awards under employee stock plans.

[0000106040-21-000053:mdna:74]
On October 22, 2021, we voluntarily prepaid the remaining principal balance of $943 million on our Term Loan B-4.

[0000106040-21-000053:mdna:75]
[same as prior period, unchanged from 0000106040-21-000024:mdna:82]

[0000106040-21-000053:mdna:76]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000053:mdna:77]
44

[0000106040-21-000053:mdna:78]
[same as prior period, unchanged from 0000106040-21-000024:mdna:85]

[0000106040-21-000053:mdna:79]
[same as prior period, unchanged from 0000106040-21-000024:mdna:86]

[0000106040-21-000053:mdna:80]
The following is a summary of our known contractual cash obligations and commercial commitments as of October 1, 2021:

[0000106040-21-000053:mdna:81]
|  | Total |  | Remaining nine months of 2022 |  | 2023-2024 |  | 2025-2026 |  | Beyond 2026 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 8,612 |  |  | $ | 251 |  |  | $ | 6,061 |  |  | $ | 2,300 |  |  | $ | — |  |
| Interest on debt | 733 |  |  | 169 |  |  | 345 |  |  | 219 |  |  | — |  |
| Flash Ventures related commitments(2) | 6,122 |  |  | 2,553 |  |  | 2,379 |  |  | 1,024 |  |  | 166 |  |
| Operating leases | 389 |  |  | 33 |  |  | 86 |  |  | 83 |  |  | 187 |  |
| Purchase obligations and other commitments | 3,703 |  |  | 2,368 |  |  | 997 |  |  | 168 |  |  | 170 |  |
| Mandatory Deemed Repatriation Tax | 819 |  |  | — |  |  | 284 |  |  | 535 |  |  | — |  |
| Total | $ | 20,378 |  |  | $ | 5,374 |  |  | $ | 10,152 |  |  | $ | 4,329 |  |  | $ | 523 |  |

[0000106040-21-000053:mdna:82]
(1)Principal portion of debt, excluding discounts and issuance costs. On October 22, 2021, we voluntarily prepaid the remaining principal balance of $943 million on our Term Loan B-4, which was scheduled to mature in 2023.

[0000106040-21-000053:mdna:83]
[same as prior period, unchanged from 0000106040-21-000024:mdna:90]

[0000106040-21-000053:mdna:84]
[same as prior period, unchanged from 0000106040-21-000024:mdna:91]

[0000106040-21-000053:mdna:85]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021. The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 1, 2021, we were in compliance with these financial covenants.

[0000106040-21-000053:mdna:86]
We may issue additional debt securities in the future that may also be guaranteed by our 100% owned domestic subsidiary, Western Digital Technologies, Inc. (“Guarantor” and, together with Western Digital Corporation, the “Obligor Group”). Such guarantees may be full and unconditional, joint and several, on a secured or unsecured, subordinated or unsubordinated basis, and may be subject to certain customary guarantor release conditions. We conduct operations almost entirely through our subsidiaries. Accordingly, the Obligor Group’s cash flow and ability to service any guaranteed registered debt securities will depend on the earnings of our subsidiaries and the distribution of those earnings to the Obligor Group, including the earnings of the non-guarantor subsidiaries, whether by dividends, loans or otherwise. Holders of such guaranteed registered debt securities would have a direct claim only against the Obligor Group.

[0000106040-21-000053:mdna:87]
The following tables include summarized financial information for the Obligor Group. The information for the Obligor Group is presented on combined basis, excluding intercompany balances and transactions between the Company and the Guarantor and excluding investments in and equity in the earnings of non-guarantor subsidiaries. The Obligor Group’s amounts due from, amounts due to, and transactions with non-guarantor subsidiaries have been presented in separate line items in the tables below.

[0000106040-21-000053:mdna:88]
The assets and liabilities of the Obligor Group include the following:

[0000106040-21-000053:mdna:89]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Current assets (excluding net intercompany receivable from non-guarantor subsidiaries) | $ | 2,458 |  |  | $ | 2,898 |  |
| Non-current assets | 1,855 |  |  | 1,903 |  |
| Net intercompany payable to non-guarantor subsidiaries | (275) |  |  | (463) |  |
| Current liabilities | 2,217 |  |  | 2,325 |  |
| Non-current liabilities | 9,409 |  |  | 9,726 |  |

[0000106040-21-000053:mdna:90]
The operating results and transactions with non-guarantor subsidiaries of the Obligor Group include the following:

[0000106040-21-000053:mdna:91]
|  | Three Months Ended |  | Year Ended |
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Net sales | $ | 2,220 |  |  | $ | 12,378 |  |
| Gross profit | 572 |  |  | 1,861 |  |
| Operating income | 39 |  |  | 142 |  |
| Net income | 27 |  |  | 377 |  |
| Intercompany revenue | 626 |  |  | 5,190 |  |
| Net intercompany interest expense | 22 |  |  | 23 |  |
| Intercompany dividends | 76 |  |  | 528 |  |

[0000106040-21-000053:mdna:92]
[same as prior period, unchanged from 0000106040-21-000024:mdna:93]

[0000106040-21-000053:mdna:93]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of October 1, 2021, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-21-000053:mdna:94]
[same as prior period, unchanged from 0000106040-21-000024:mdna:95]

[0000106040-21-000053:mdna:95]
[same as prior period, unchanged from 0000106040-21-000024:mdna:96]

[0000106040-21-000053:mdna:96]
[same as prior period, unchanged from 0000106040-21-000024:mdna:98]

[0000106040-21-000053:mdna:97]
[same as prior period, unchanged from 0000106040-21-000024:mdna:99]

[0000106040-21-000053:mdna:98]
|  |  | October 1,2021 |
| 2023 |  | $ | 106 |  |
| 2024 |  | 178 |  |
| 2025 |  | 238 |  |
| 2026 |  | 297 |  |
| Total |  | $ | 819 |  |

[0000106040-21-000053:mdna:99]
For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part II, Item 8, Note 14, Income Tax Expense, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-21-000053:mdna:100]
[same as prior period, unchanged from 0000106040-21-000024:mdna:102]

[0000106040-21-000053:mdna:101]
As of October 1, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $762 million. Accrued interest and penalties related to unrecognized tax benefits as of October 1, 2021 was approximately $132 million. Of these amounts, approximately $758 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-21-000053:mdna:102]
[same as prior period, unchanged from 0000106040-21-000024:mdna:104]

[0000106040-21-000053:mdna:103]
We have generally held a balance of fixed and variable rate debt. At October 1, 2021, we had $5.21 billion of variable rate debt, comprising 61% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $3.21 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual interest expense by $32 million.

[0000106040-21-000053:mdna:104]
[same as prior period, unchanged from 0000106040-21-000024:mdna:106]

[0000106040-21-000053:mdna:105]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 1, Note 7, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000053:mdna:106]
[same as prior period, unchanged from 0000106040-21-000024:mdna:108]

[0000106040-21-000053:mdna:107]
[same as prior period, unchanged from 0000106040-21-000024:mdna:109]

[0000106040-21-000053:mdna:108]
[same as prior period, unchanged from 0000106040-21-000024:mdna:110]

[0000106040-21-000053:mdna:109]
[same as prior period, unchanged from 0000106040-21-000024:mdna:111]

[0000106040-21-000053:mdna:110]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the three months ended October 1, 2021 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of October 1, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-21-000053:mdna:111]
[same as prior period, unchanged from 0000106040-21-000024:mdna:115]

[0000106040-21-000053:mdna:112]
[same as prior period, unchanged from 0000106040-21-000024:mdna:116]

[0000106040-21-000053:mdna:113]
[same as prior period, unchanged from 0000106040-21-000024:mdna:117]

[0000106040-21-000053:mdna:114]
[same as prior period, unchanged from 0000106040-21-000024:mdna:118]

[0000106040-21-000053:mdna:115]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the fiscal year ended July 2, 2021. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the fiscal year ended July 2, 2021 for a discussion of our critical accounting policies and estimates.
