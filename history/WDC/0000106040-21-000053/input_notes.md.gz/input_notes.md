# WDC notes — 0000106040-21-000053


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-21-000053:notes:1]
[same as prior period, unchanged from 0000106040-21-000024:notes:1]

[0000106040-21-000053:notes:2]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 2, 2021. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 2, 2021. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-21-000053:notes:3]
[same as prior period, unchanged from 0000106040-21-000024:notes:4]

[0000106040-21-000053:notes:4]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2022, which ends on July 1, 2022, and 2021, which ended on July 2, 2021, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-21-000053:notes:5]
[same as prior period, unchanged from 0000106040-21-000024:notes:6]

[0000106040-21-000053:notes:6]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, any possible resurgence of COVID-19, including the emergence of more contagious or vaccine-resistant variants and how quickly and to what extent normal economic and operating activity can resume.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-21-000053:notes:7]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-21-000053:notes:8]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted this ASU on July 3, 2021, which is the beginning of fiscal 2022, and its adoption did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-21-000053:notes:9]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-21-000053:notes:10]
In August 2020, the FASB issued ASU No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. For instruments that do not have a component mandatorily settled in cash, the change will likely result in a higher amount of share dilution in the calculation of earnings per share. The Company expects to adopt this ASU in the first quarter of fiscal 2023, and is currently assessing the impact of adoption.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-21-000053:notes:11]
Segment Information
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: hard disk drives (“HDD”) and flash-based products (“Flash”). To align with the new operating model and business structure, the Company made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, the Company’s management finalized its assessment of the Company’s operating segments and concluded that the Company now has two reportable segments: HDD and Flash.

[0000106040-21-000053:notes:12]
The CODM evaluates performance of the Company and makes decisions regarding allocation of resources based on each operating segment’s net revenue and gross margin, which are summarized below.  Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are not available or reviewed by the CODM  to evaluate the performance of or to allocate resources to the segments.

[0000106040-21-000053:notes:13]
The following table summarizes the operating performance of the Company’s reportable segments:

[0000106040-21-000053:notes:14]
|  | Three Months Ended |
|  | October 1,2021 |  | October 2,2020 |
|  | (in millions) |
| Net revenue: |  |  |  |
| HDD | $ | 2,561 |  |  | $ | 1,844 |  |
| Flash | 2,490 |  |  | 2,078 |  |
| Total net revenue | $ | 5,051 |  |  | $ | 3,922 |  |
| Gross profit |  |  |  |
| HDD | $ | 792 |  |  | $ | 483 |  |
| Flash | 921 |  |  | 548 |  |
| Total gross profit for segments | 1,713 |  |  | 1,031 |  |
| Unallocated corporate items: |  |  |  |
| Amortization of acquired intangible assets | 39 |  |  | 145 |  |
| Stock-based compensation expense | 9 |  |  | 12 |  |
| Charges related to a power outage incident and related recovery | — |  |  | (30) |  |
| Total unallocated corporate items | (48) |  |  | (127) |  |
| Consolidated gross profit | $ | 1,665 |  |  | $ | 904 |  |
| Gross margin: |  |  |  |
| HDD | 30.9 | % |  | 26.2 | % |
| Flash | 37.0 | % |  | 26.4 | % |
| Consolidated gross margin | 33.0 | % |  | 23.0 | % |

[0000106040-21-000053:notes:15]
Disaggregated Revenue

[0000106040-21-000053:notes:16]
The Company’s broad portfolio of technology and products address multiple end markets.  In the fiscal first quarter of 2022, the Company refined the end markets it reports to be Cloud, Client and Consumer. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both hard drive and flash products. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-21-000053:notes:17]
The Company’s disaggregated revenue information is as follows:

[0000106040-21-000053:notes:18]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 2,225 |  |  | $ | 1,291 |  |  |  |  |  |  |  |
| Client | 1,853 |  |  | 1,750 |  |  |  |  |  |  |  |
| Consumer | 973 |  |  | 881 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,614 |  |  | $ | 1,079 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 762 |  |  | 629 |  |  |  |  |  |  |  |
| Asia | 2,675 |  |  | 2,214 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:19]
The Company’s top 10 customers accounted for 43% of its net revenue for the three months ended October 1, 2021, and 44% of its net revenue for the three months ended October 2, 2020. For the three months ended October 1, 2021 and October 2, 2020, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-21-000053:notes:20]
Goodwill

[0000106040-21-000053:notes:21]
In connection with the Company’s determination of its reportable segments, effective July 3, 2021, the Company allocated its goodwill between its segments based on the estimated relative fair values of the business units.  In addition, management performed a goodwill impairment assessment for each segment and concluded no impairment indicators as of both the beginning and end of the three months ended October 1, 2021.  The following table provides a summary of goodwill activity for the period.

[0000106040-21-000053:notes:22]
|  | HDD |  | Flash |  | Total |
|  | (in millions) |
| Balance at July 3, 2021 | $ | 4,328 |  |  | $ | 5,738 |  |  | $ | 10,066 |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |
| Balance at October 1, 2021 | $ | 4,328 |  |  | $ | 5,738 |  |  | $ | 10,066 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-21-000053:notes:23]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 1, 2021 or July 2, 2021.

[0000106040-21-000053:notes:24]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 1, 2021 and July 2, 2021 as well as the related amortization for the three months ended October 1, 2021 and October 2, 2020 were not material.

[0000106040-21-000053:notes:25]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 1, 2021 and July 2, 2021, contract liabilities were not material.

[0000106040-21-000053:notes:26]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 1, 2021 was $61 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $30 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-21-000053:notes:27]
[same as prior period, unchanged from 0000106040-21-000024:notes:23]

[0000106040-21-000053:notes:28]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. The Company did not sell any trade accounts receivable during the three months ended October 1, 2021. During the three months ended October 2, 2020, the Company sold trade accounts receivable for cash proceeds of $128 million. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. There were no factored receivables outstanding as of October 1, 2021 and July 2, 2021.

[0000106040-21-000053:notes:29]
[same as prior period, unchanged from 0000106040-21-000024:notes:25]

[0000106040-21-000053:notes:30]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,720 |  |  | $ | 1,623 |  |
| Work-in-process | 1,036 |  |  | 1,088 |  |
| Finished goods | 788 |  |  | 905 |  |
| Total inventories | $ | 3,544 |  |  | $ | 3,616 |  |

[0000106040-21-000053:notes:31]
[same as prior period, unchanged from 0000106040-21-000024:notes:27]

[0000106040-21-000053:notes:32]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 278 |  |  | $ | 278 |  |
| Buildings and improvements | 1,875 |  |  | 1,854 |  |
| Machinery and equipment | 8,102 |  |  | 7,860 |  |
| Computer equipment and software | 455 |  |  | 440 |  |
| Furniture and fixtures | 52 |  |  | 51 |  |
| Construction-in-process | 419 |  |  | 476 |  |
| Property, plant and equipment, gross | 11,181 |  |  | 10,959 |  |
| Accumulated depreciation | (7,921) |  |  | (7,771) |  |
| Property, plant and equipment, net | $ | 3,260 |  |  | $ | 3,188 |  |

[0000106040-21-000053:notes:33]
[same as prior period, unchanged from 0000106040-21-000024:notes:31]

[0000106040-21-000053:notes:34]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,508 |  |  | $ | 5,508 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,224) |  |  | (5,146) |  |
| Intangible assets, net | $ | 364 |  |  | $ | 442 |  |

[0000106040-21-000053:notes:35]
[same as prior period, unchanged from 0000106040-21-000024:notes:33]

[0000106040-21-000053:notes:36]
[same as prior period, unchanged from 0000106040-21-000024:notes:34]

[0000106040-21-000053:notes:37]
[same as prior period, unchanged from 0000106040-21-000024:notes:35]

[0000106040-21-000053:notes:38]
|  | Three Months Ended |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 363 |  |  | $ | 408 |  |  |  |  |  |  |  |
| Charges to operations | 40 |  |  | 35 |  |  |  |  |  |  |  |
| Utilization | (23) |  |  | (31) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | (10) |  |  | (21) |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 370 |  |  | $ | 391 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:39]
[same as prior period, unchanged from 0000106040-21-000024:notes:37]

[0000106040-21-000053:notes:40]
|  | October 1,2021 |  | July 2,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 175 |  |  | $ | 175 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 195 |  |  | 188 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 370 |  |  | $ | 363 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:41]
[same as prior period, unchanged from 0000106040-21-000024:notes:39]

[0000106040-21-000053:notes:42]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 575 |  |  | $ | 684 |  |
| Payables related to unrecognized tax benefits | 758 |  |  | 750 |  |
| Other non-current liabilities | 718 |  |  | 633 |  |
| Total other liabilities | $ | 2,051 |  |  | $ | 2,067 |  |

[0000106040-21-000053:notes:43]
[same as prior period, unchanged from 0000106040-21-000024:notes:41]

[0000106040-21-000053:notes:44]
[same as prior period, unchanged from 0000106040-21-000024:notes:42]

[0000106040-21-000053:notes:45]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 2, 2021 | $ | (35) |  |  | $ | (38) |  |  |  |  |  |  | $ | (124) |  |  | $ | (197) |  |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | 4 |  |  |  |  |  |  | (17) |  |  | (12) |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  |  |  |  |  | 50 |  |  | 50 |  |
| Income tax benefit related to items of other comprehensive income | — |  |  | — |  |  |  |  |  |  | (8) |  |  | (8) |  |
| Net current-period other comprehensive income | 1 |  |  | 4 |  |  |  |  |  |  | 25 |  |  | 30 |  |
| Balance at October 1, 2021 | $ | (34) |  |  | $ | (34) |  |  |  |  |  |  | $ | (99) |  |  | $ | (167) |  |

[0000106040-21-000053:notes:46]
During the three months ended October 1, 2021, the amounts reclassified out of AOCI were losses related to foreign exchange contracts of $37 million that were substantially all charged to Cost of revenue and losses related to interest rate swap contracts of $12 million that were charged to Interest expense in the Condensed Consolidated Statements of Operations. During the three months ended October 2, 2020, the amounts reclassified out of AOCI primarily related to foreign exchange contracts and were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations.
As of October 1, 2021, the amount of existing net losses related to cash flow hedges recorded in AOCI included $19 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of October 1, 2021, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-21-000053:notes:47]
[same as prior period, unchanged from 0000106040-21-000024:notes:45]

[0000106040-21-000053:notes:48]
[same as prior period, unchanged from 0000106040-21-000024:notes:46]

[0000106040-21-000053:notes:49]
[same as prior period, unchanged from 0000106040-21-000024:notes:47]

[0000106040-21-000053:notes:50]
[same as prior period, unchanged from 0000106040-21-000024:notes:48]

[0000106040-21-000053:notes:51]
[same as prior period, unchanged from 0000106040-21-000024:notes:49]

[0000106040-21-000053:notes:52]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of October 1, 2021 and July 2, 2021, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-21-000053:notes:53]
|  | October 1, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 388 |  |  | $ | — |  |  | $ | — |  |  | $ | 388 |  |
| Foreign exchange contracts | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total assets at fair value | $ | 388 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 402 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 47 |  |  | $ | — |  |  | $ | 47 |  |
| Interest rate swap contract | — |  |  | 69 |  |  | — |  |  | 69 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 116 |  |

[0000106040-21-000053:notes:54]
|  | July 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,283 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,283 |  |
| Foreign exchange contracts | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total assets at fair value | $ | 1,283 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 1,297 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Interest rate swap contract | — |  |  | 80 |  |  | — |  |  | 80 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 145 |  |  | $ | — |  |  | $ | 145 |  |

[0000106040-21-000053:notes:55]
During the three months ended October 1, 2021 and October 2, 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-21-000053:notes:56]
[same as prior period, unchanged from 0000106040-21-000024:notes:54]

[0000106040-21-000053:notes:57]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of fiscal 2022 and the fourth quarter of fiscal 2021, respectively.

[0000106040-21-000053:notes:58]
|  | October 1, 2021 |  | July 2, 2021 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,264 |  |  | $ | 4,282 |  |  | $ | 4,327 |  |  | $ | 4,346 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 944 |  |  | 1,093 |  |  | 1,094 |  |
| 1.50% convertible notes due 2024 | 1,025 |  |  | 1,112 |  |  | 1,017 |  |  | 1,173 |  |
| 4.75% senior unsecured notes due 2026 | 2,289 |  |  | 2,550 |  |  | 2,288 |  |  | 2,556 |  |
| Total | $ | 8,521 |  |  | $ | 8,888 |  |  | $ | 8,725 |  |  | $ | 9,169 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-21-000053:notes:59]
Derivative Instruments and Hedging Activities
As of October 1, 2021, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-21-000053:notes:60]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three months ended October 1, 2021 and October 2, 2020, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-21-000053:notes:61]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCI. For more information regarding cash flow hedges, see Part I, Item1, Note 5. Supplemental Information - Accumulated other comprehensive income (losses), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000053:notes:62]
[same as prior period, unchanged from 0000106040-21-000024:notes:60]

[0000106040-21-000053:notes:63]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of October 1, 2021 and July 2, 2021, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-21-000053:notes:64]
Debt
Debt consisted of the following as of October 1, 2021 and July 2, 2021:

[0000106040-21-000053:notes:65]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,269 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,612 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (91) |  |  | (100) |  |
| Subtotal | 8,521 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 8,270 |  |  | $ | 8,474 |  |

[0000106040-21-000053:notes:66]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 1, 2021, the Company was in compliance with these financial covenants.

[0000106040-21-000053:notes:67]
During the three months ended October 1, 2021, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. On October 22, 2021, the Company voluntarily prepaid the remaining principal balance of $943 million on its Term Loan B-4.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-21-000053:notes:68]
[same as prior period, unchanged from 0000106040-21-000024:notes:66]

[0000106040-21-000053:notes:69]
[same as prior period, unchanged from 0000106040-21-000024:notes:67]

[0000106040-21-000053:notes:70]
[same as prior period, unchanged from 0000106040-21-000024:notes:68]

[0000106040-21-000053:notes:71]
|  | October 1,2021 |  | July 2,2021 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 359 |  |  | $ | 359 |  |  |  |
| Fair value of plan assets at end of period | 229 |  |  | 227 |  |  |  |
| Unfunded status | $ | 130 |  |  | $ | 132 |  |  |  |

[0000106040-21-000053:notes:72]
[same as prior period, unchanged from 0000106040-21-000024:notes:70]

[0000106040-21-000053:notes:73]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 129 |  |  | 131 |  |
| Net amount recognized | $ | 130 |  |  | $ | 132 |  |

[0000106040-21-000053:notes:74]
Net periodic benefit costs were not material for the three months ended October 1, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-21-000053:notes:75]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-21-000053:notes:76]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-21-000053:notes:77]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 1, 2021 and July 2, 2021:

[0000106040-21-000053:notes:78]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 194 |  |  | 213 |  |
| Notes receivable, Flash Forward | 681 |  |  | 561 |  |
| Investment in Flash Partners | 201 |  |  | 199 |  |
| Investment in Flash Alliance | 294 |  |  | 293 |  |
| Investment in Flash Forward | 131 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,646 |  |  | $ | 1,586 |  |

[0000106040-21-000053:notes:79]
During the three months ended October 1, 2021 and October 2, 2020, the Company made net payments to Flash Ventures of $1.19 billion and $981 million, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-21-000053:notes:80]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-21-000053:notes:81]
As of October 1, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $378 million and $398 million, respectively.

[0000106040-21-000053:notes:82]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 1, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-21-000053:notes:83]
|  | October 1,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,020 |  |
| Equity investments | 626 |  |
| Operating lease guarantees | 1,985 |  |
| Inventory and prepayments | 790 |  |
| Maximum estimable loss exposure | $ | 4,421 |  |

[0000106040-21-000053:notes:84]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-21-000053:notes:85]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three months ended October 2, 2020, the Company recovered $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000053:notes:86]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-21-000053:notes:87]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-21-000053:notes:88]
Off-Balance Sheet Liabilities

[0000106040-21-000053:notes:89]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-21-000053:notes:90]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021.

[0000106040-21-000053:notes:91]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 220 |  |  | $ | 1,985 |  |

[0000106040-21-000053:notes:92]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 1, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021:

[0000106040-21-000053:notes:93]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2022 |  | $ | 443 |  |  | $ | 22 |  |  | $ | 465 |  |
| 2023 |  | 481 |  |  | 65 |  |  | 546 |  |
| 2024 |  | 325 |  |  | 117 |  |  | 442 |  |
| 2025 |  | 138 |  |  | 107 |  |  | 245 |  |
| 2026 |  | 91 |  |  | 162 |  |  | 253 |  |
| Thereafter |  | 4 |  |  | 30 |  |  | 34 |  |
| Total guarantee obligations |  | $ | 1,482 |  |  | $ | 503 |  |  | $ | 1,985 |  |

[0000106040-21-000053:notes:94]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 1, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-21-000053:notes:95]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 1, 2021 and October 2, 2020, the Company recognized approximately 5% and 2%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 7% and 6% of Accounts receivable, net as of October 1, 2021 and July 2, 2021, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-21-000053:notes:96]
[same as prior period, unchanged from 0000106040-21-000024:notes:95]

[0000106040-21-000053:notes:97]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of October 1, 2021:

[0000106040-21-000053:notes:98]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | ($ in millions) |  |  |  |  |  |  |  |  |
| Remaining nine months of 2022 | $ | 33 |  |  |  |  |  |  |  |  |  |
| 2023 | 43 |  |  |  |  |  |  |  |  |  |
| 2024 | 43 |  |  |  |  |  |  |  |  |  |
| 2025 | 41 |  |  |  |  |  |  |  |  |  |
| 2026 | 42 |  |  |  |  |  |  |  |  |  |
| Thereafter | 187 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 389 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | 60 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 329 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 35 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 294 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 316 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.9 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.4 | % |  |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:99]
[same as prior period, unchanged from 0000106040-21-000024:notes:98]

[0000106040-21-000053:notes:100]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |
|  | (in millions) |
| Cost of operating leases | $ | 13 |  |  | $ | 13 |  |  |  |  |  |
| Cash paid for operating leases | 12 |  |  | 12 |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 112 |  |  | 7 |  |  |  |  |  |

[0000106040-21-000053:notes:101]
[same as prior period, unchanged from 0000106040-21-000024:notes:100]

[0000106040-21-000053:notes:102]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of October 1, 2021, the Company had the following minimum long-term commitments:

[0000106040-21-000053:notes:103]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining nine months of 2022 |  | $ | 423 |  |
| 2023 |  | 534 |  |
| 2024 |  | 306 |  |
| 2025 |  | 148 |  |
| 2026 |  | 20 |  |
| Thereafter |  | 170 |  |
| Total |  | $ | 1,601 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-21-000053:notes:104]
[same as prior period, unchanged from 0000106040-21-000024:notes:103]

[0000106040-21-000053:notes:105]
[same as prior period, unchanged from 0000106040-21-000024:notes:104]

[0000106040-21-000053:notes:106]
|  | Three Months Ended |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 67 |  |  | $ | 67 |  |  |  |  |  |  |  |
| ESPP | 9 |  |  | 9 |  |  |  |  |  |  |  |
| Total | $ | 76 |  |  | $ | 76 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:107]
|  | Three Months Ended |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Cost of revenue | $ | 9 |  |  | $ | 12 |  |  |  |  |  |  |  |
| Research and development | 40 |  |  | 39 |  |  |  |  |  |  |  |
| Selling, general and administrative | 27 |  |  | 25 |  |  |  |  |  |  |  |
| Subtotal | 76 |  |  | 76 |  |  |  |  |  |  |  |
| Tax benefit | (15) |  |  | (11) |  |  |  |  |  |  |  |
| Total | $ | 61 |  |  | $ | 65 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:108]
[same as prior period, unchanged from 0000106040-21-000024:notes:107]

[0000106040-21-000053:notes:109]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of October 1, 2021:

[0000106040-21-000053:notes:110]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 755 |  |  | 2.8 |
| ESPP | 56 |  |  | 1.6 |
| Total unamortized compensation cost | $ | 811 |  |  |  |

[0000106040-21-000053:notes:111]
[same as prior period, unchanged from 0000106040-21-000024:notes:110]

[0000106040-21-000053:notes:112]
[same as prior period, unchanged from 0000106040-21-000024:notes:111]

[0000106040-21-000053:notes:113]
[same as prior period, unchanged from 0000106040-21-000024:notes:112]

[0000106040-21-000053:notes:114]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at October 1, 2021:

[0000106040-21-000053:notes:115]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 2, 2021 | 1.5 |  |  | $ | 72.84 |  |  | 1.2 |  | $ | 15 |  |
| Exercised | — |  |  | 44.78 |  |  |  |  | $ | 1 |  |
| Canceled or expired | (0.4) |  |  | 99.71 |  |  |  |  |  |
| Options outstanding at October 1, 2021 | 1.1 |  |  | $ | 64.61 |  |  | 1.2 |  | $ | 7 |  |

[0000106040-21-000053:notes:116]
[same as prior period, unchanged from 0000106040-21-000024:notes:115]

[0000106040-21-000053:notes:117]
[same as prior period, unchanged from 0000106040-21-000024:notes:116]

[0000106040-21-000053:notes:118]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | $ | 50.12 |  |  |  |
| Granted | 4.9 |  |  | 63.68 |  |  |  |
| Vested | (4.5) |  |  | 53.99 |  |  | $ | 277 |  |
| Forfeited | (0.6) |  |  | 52.62 |  |  |  |
| RSUs and PSUs outstanding at October 1, 2021 | 15.9 |  |  | $ | 53.17 |  |  |  |

[0000106040-21-000053:notes:119]
[same as prior period, unchanged from 0000106040-21-000024:notes:118]

[0000106040-21-000053:notes:120]
Stock Repurchase Program
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the three months ended October 1, 2021 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of October 1, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-21-000053:notes:121]
[same as prior period, unchanged from 0000106040-21-000024:notes:123]

[0000106040-21-000053:notes:122]
[same as prior period, unchanged from 0000106040-21-000024:notes:127]

[0000106040-21-000053:notes:123]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 704 |  |  | $ | (3) |  |  |  |  |  |
| Income tax expense | 94 |  |  | 57 |  |  |  |  |  |
| Effective tax rate | 13 | % |  | (1,900) | % |  |  |  |  |

[0000106040-21-000053:notes:124]
The primary drivers of the difference between the effective tax rate for the three months ended October 1, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three months ended October 1, 2021 includes the discrete effect of an increase to unrecognized tax benefits of $16 million as a result of ongoing discussions with various taxing authorities.

[0000106040-21-000053:notes:125]
The primary drivers of the difference between the effective tax rate for the three months ended October 2, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the three months ended October 2, 2020 includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of purchase accounting deferred tax liabilities due to restructuring activities. The discrete items had no impact on the amount of income taxes paid by the Company.

[0000106040-21-000053:notes:126]
As previously disclosed, the IRS issued statutory notices of deficiency with respect to adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The Company filed petitions with the U.S. Tax Court with respect to the statutory notices of deficiency for fiscal years 2008 through 2009 and the fiscal years 2010 through 2012. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. In May 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2012. In June 2021, the IRS filed with the U.S. Tax Court Second Amendments to Answer to assert additional adjustments relating to transfer pricing with the Company’s foreign subsidiaries for fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The Second Amendments to Answer replace the amounts asserted in the statutory notices of deficiency. With its Second Amendments to Answer, the IRS seeks to increase the Company’s U.S. taxable income by amounts that would result in additional federal income tax liabilities totaling approximately $335 million for fiscal years 2008 through 2009 and approximately $922 million for fiscal years 2010 through 2012, subject to interest and the IRS’s claim for penalties. In September 2020 and December 2020, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2013 through 2015 that, if sustained, would result in additional federal income tax liabilities totaling approximately $343 million for those fiscal years. In March 2021, the IRS asserted penalties totaling $109 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2013 through 2015. The Company disagrees with the proposed adjustments relating to transfer pricing and related penalties, and continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS. Also in March 2021, the Company and the IRS tentatively reached a basis for resolving the

[0000106040-21-000053:notes:127]
intercompany payable balances matter for all fiscal years at issue and the impact was not material to the Consolidated Financial Statements.

[0000106040-21-000053:notes:128]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of October 1, 2021, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-21-000053:notes:129]
As of October 1, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $762 million. Accrued interest and penalties related to unrecognized tax benefits as of October 1, 2021 was approximately $132 million. Of these amounts, approximately $758 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-21-000053:notes:130]
[same as prior period, unchanged from 0000106040-21-000024:notes:134]

[0000106040-21-000053:notes:131]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 610 |  |  | $ | (60) |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 310 |  |  | 303 |  |  |  |  |  |
| Employee stock options, RSUs, PSUs and ESPP | 6 |  |  | — |  |  |  |  |  |
| Basic and diluted | 316 |  |  | 303 |  |  |  |  |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | 1.97 |  |  | $ | (0.20) |  |  |  |  |  |
| Diluted | $ | 1.93 |  |  | $ | (0.20) |  |  |  |  |  |
| Anti-dilutive potential common shares excluded | 1 |  |  | 16 |  |  |  |  |  |

[0000106040-21-000053:notes:132]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended October 2, 2020, the Company recorded net loss, and all shares subject to outstanding equity awards have been excluded for this period because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-21-000053:notes:133]
[same as prior period, unchanged from 0000106040-21-000024:notes:137]

[0000106040-21-000053:notes:134]
|  | Three Months Ended |  |  |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Business Realignment | $ | 15 |  |  | $ | 23 |  |  |  |  |  |  |  |
| Total employee termination and other charges | 15 |  |  | 23 |  |  |  |  |  |  |  |
| Asset impairment: |  |  |  |  |  |  |  |  |  |
| Business Realignment | 3 |  |  | — |  |  |  |  |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 18 |  |  | $ | 23 |  |  |  |  |  |  |  |

[0000106040-21-000053:notes:135]
[same as prior period, unchanged from 0000106040-21-000024:notes:139]

[0000106040-21-000053:notes:136]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources.

[0000106040-21-000053:notes:137]
The following table presents an analysis of the components of these activities against the reserve during the three months ended October 1, 2021:

[0000106040-21-000053:notes:138]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 2, 2021 | $ | 2 |  |  |  |  |  |
| Charges | 15 |  |  |  |  |  |
| Cash payments | (4) |  |  |  |  |  |
| Accrual balance at October 1, 2021 | $ | 13 |  |  |  |  |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-21-000053:notes:139]
[same as prior period, unchanged from 0000106040-21-000024:notes:143]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-21-000053:notes:140]
Legal Proceedings
Tax

[0000106040-21-000053:notes:141]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-21-000053:notes:142]
Other Matters

[0000106040-21-000053:notes:143]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
