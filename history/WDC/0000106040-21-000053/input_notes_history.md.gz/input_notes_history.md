# WDC note change history — 0000106040-21-000024 → 0000106040-21-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 1, 2021 and July 2, 2021:
  (was, 2021-05-06, similarity 0.9609):
[0000106040-21-000024:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 2, 2021 and July 3, 2020:

- changed (2021-11-04):
[0000106040-21-000053:note_history:2]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 194 |  |  | 213 |  |
| Notes receivable, Flash Forward | 681 |  |  | 561 |  |
| Investment in Flash Partners | 201 |  |  | 199 |  |
| Investment in Flash Alliance | 294 |  |  | 293 |  |
| Investment in Flash Forward | 131 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,646 |  |  | $ | 1,586 |  |
  (was, 2021-05-06, similarity 0.986):
[0000106040-21-000024:note_history:2]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 289 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 228 |  |  | 301 |  |
| Notes receivable, Flash Forward | 554 |  |  | 670 |  |
| Investment in Flash Partners | 200 |  |  | 203 |  |
| Investment in Flash Alliance | 294 |  |  | 300 |  |
| Investment in Flash Forward | 129 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,694 |  |  | $ | 1,875 |  |

- added (2021-11-04):
[0000106040-21-000053:note_history:3]
During the three months ended October 1, 2021 and October 2, 2020, the Company made net payments to Flash Ventures of $1.19 billion and $981 million, respectively, for purchased flash-based memory wafers and net loans.

- changed (2021-11-04):
[0000106040-21-000053:note_history:4]
As of October 1, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $378 million and $398 million, respectively.
  (was, 2021-05-06, similarity 0.9635):
[0000106040-21-000024:note_history:4]
As of April 2, 2021 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $397 million and $407 million, respectively.

- added (2021-11-04):
[0000106040-21-000053:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 1, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2021-11-04):
[0000106040-21-000053:note_history:6]
|  | October 1,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,020 |  |
| Equity investments | 626 |  |
| Operating lease guarantees | 1,985 |  |
| Inventory and prepayments | 790 |  |
| Maximum estimable loss exposure | $ | 4,421 |  |

- changed (2021-11-04):
[0000106040-21-000053:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three months ended October 2, 2020, the Company recovered $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.
  (was, 2021-05-06, similarity 0.7142):
[0000106040-21-000024:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the nine months ended April 3, 2020, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the nine months ended April 2, 2021, the Company recovered $75 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

- changed (2021-11-04):
[0000106040-21-000053:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021.
  (was, 2021-05-06, similarity 0.9765):
[0000106040-21-000024:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 2, 2021.

- changed (2021-11-04):
[0000106040-21-000053:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 1, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021:
  (was, 2021-05-06, similarity 0.9666):
[0000106040-21-000024:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 2, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 2, 2021:

- changed (2021-11-04):
[0000106040-21-000053:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2022 |  | $ | 443 |  |  | $ | 22 |  |  | $ | 465 |  |
| 2023 |  | 481 |  |  | 65 |  |  | 546 |  |
| 2024 |  | 325 |  |  | 117 |  |  | 442 |  |
| 2025 |  | 138 |  |  | 107 |  |  | 245 |  |
| 2026 |  | 91 |  |  | 162 |  |  | 253 |  |
| Thereafter |  | 4 |  |  | 30 |  |  | 34 |  |
| Total guarantee obligations |  | $ | 1,482 |  |  | $ | 503 |  |  | $ | 1,985 |  |
  (was, 2021-05-06, similarity 0.9923):
[0000106040-21-000024:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2021 |  | $ | 146 |  |  | $ | 22 |  |  | $ | 168 |  |
| 2022 |  | 531 |  |  | 48 |  |  | 579 |  |
| 2023 |  | 419 |  |  | 65 |  |  | 484 |  |
| 2024 |  | 260 |  |  | 117 |  |  | 377 |  |
| 2025 |  | 96 |  |  | 108 |  |  | 204 |  |
| Thereafter |  | 45 |  |  | 136 |  |  | 181 |  |
| Total guarantee obligations |  | $ | 1,497 |  |  | $ | 496 |  |  | $ | 1,993 |  |

- changed (2021-11-04):
[0000106040-21-000053:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 1, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2021-05-06, similarity 0.9473):
[0000106040-21-000024:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 2, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2021-11-04):
[0000106040-21-000053:note_history:12]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 1, 2021 and October 2, 2020, the Company recognized approximately 5% and 2%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 7% and 6% of Accounts receivable, net as of October 1, 2021 and July 2, 2021, respectively.
  (was, 2021-05-06, similarity 0.6255):
[0000106040-21-000024:note_history:12]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 2, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 3, 2020, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 6% and 4% of Accounts receivable, net as of April 2, 2021 and July 3, 2020, respectively.

- removed (2021-11-04):
[0000106040-21-000024:note_history:13]
During the three and nine months ended April 2, 2021 and during the three and nine months ended April 3, 2020, the Company made net payments to Flash Ventures of $1.14 billion and $3.33 billion, and $842 million and $2.36 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- removed (2021-11-04):
[0000106040-21-000024:note_history:14]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 2, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2021-11-04):
[0000106040-21-000024:note_history:15]
|  | April 2,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,071 |  |
| Equity investments | 623 |  |
| Operating lease guarantees | 1,993 |  |
| Inventory and prepayments | 656 |  |
| Maximum estimable loss exposure | $ | 4,343 |  |

- removed (2021-11-04):
[0000106040-21-000024:note_history:16]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 2, 2021, remaining committed prepayments totaled $108 million.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:17]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2022, which ends on July 1, 2022, and 2021, which ended on July 2, 2021, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2021-05-06, similarity 0.7438):
[0000106040-21-000024:note_history:17]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2021, which ends on July 2, 2021, will be comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

- changed (2021-11-04):
[0000106040-21-000053:note_history:18]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, any possible resurgence of COVID-19, including the emergence of more contagious or vaccine-resistant variants and how quickly and to what extent normal economic and operating activity can resume.
  (was, 2021-05-06, similarity 0.6813):
[0000106040-21-000024:note_history:18]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, including the effects of ongoing vaccination efforts, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.

- removed (2021-11-04):
[0000106040-21-000024:note_history:19]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.

- removed (2021-11-04):
[0000106040-21-000024:note_history:20]
Segment Information

- removed (2021-11-04):
[0000106040-21-000024:note_history:21]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker, announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). To align with the new operating model and business structure, the Company is making management organizational changes and implementing new reporting modules and processes to provide discrete information to manage the business.  Management expects to finalize its assessment of its operating segments when the implementations and transitions are completed, which is expected to be in the first quarter of fiscal 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:22]
Debt
Debt consisted of the following as of October 1, 2021 and July 2, 2021:
  (was, 2021-05-06, similarity 0.9254):
[0000106040-21-000024:note_history:22]
Debt
Debt consisted of the following as of April 2, 2021 and July 3, 2020:

- changed (2021-11-04):
[0000106040-21-000053:note_history:23]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,269 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,612 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (91) |  |  | (100) |  |
| Subtotal | 8,521 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 8,270 |  |  | $ | 8,474 |  |
  (was, 2021-05-06, similarity 0.9135):
[0000106040-21-000024:note_history:23]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,394 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,243 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,037 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (108) |  |  | (136) |  |
| Subtotal | 8,929 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,678 |  |  | $ | 9,289 |  |

- changed (2021-11-04):
[0000106040-21-000053:note_history:24]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 1, 2021, the Company was in compliance with these financial covenants.
  (was, 2021-05-06, similarity 0.9789):
[0000106040-21-000024:note_history:24]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 2, 2021, the Company was in compliance with these financial covenants.

- added (2021-11-04):
[0000106040-21-000053:note_history:25]
During the three months ended October 1, 2021, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. On October 22, 2021, the Company voluntarily prepaid the remaining principal balance of $943 million on its Term Loan B-4.

- removed (2021-11-04):
[0000106040-21-000024:note_history:26]
During the three and nine months ended April 2, 2021, the Company made voluntary prepayments totaling $150 million and $450 million, respectively, on its Term Loan B-4. In October 2020, the 0.50% convertible senior notes due 2020 were settled in full in accordance with their terms. On April 30, 2021, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:27]
Debt consisted of the following as of October 1, 2021 and July 2, 2021:
  (was, 2021-05-06, similarity 0.9194):
[0000106040-21-000024:note_history:27]
Debt consisted of the following as of April 2, 2021 and July 3, 2020:

- changed (2021-11-04):
[0000106040-21-000053:note_history:28]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,269 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,612 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (91) |  |  | (100) |  |
| Subtotal | 8,521 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 8,270 |  |  | $ | 8,474 |  |
  (was, 2021-05-06, similarity 0.9135):
[0000106040-21-000024:note_history:28]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,394 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,243 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,037 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (108) |  |  | (136) |  |
| Subtotal | 8,929 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,678 |  |  | $ | 9,289 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:29]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 1, 2021 and July 2, 2021:
  (was, 2021-05-06, similarity 0.9609):
[0000106040-21-000024:note_history:29]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 2, 2021 and July 3, 2020:

- changed (2021-11-04):
[0000106040-21-000053:note_history:30]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 194 |  |  | 213 |  |
| Notes receivable, Flash Forward | 681 |  |  | 561 |  |
| Investment in Flash Partners | 201 |  |  | 199 |  |
| Investment in Flash Alliance | 294 |  |  | 293 |  |
| Investment in Flash Forward | 131 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,646 |  |  | $ | 1,586 |  |
  (was, 2021-05-06, similarity 0.986):
[0000106040-21-000024:note_history:30]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 289 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 228 |  |  | 301 |  |
| Notes receivable, Flash Forward | 554 |  |  | 670 |  |
| Investment in Flash Partners | 200 |  |  | 203 |  |
| Investment in Flash Alliance | 294 |  |  | 300 |  |
| Investment in Flash Forward | 129 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,694 |  |  | $ | 1,875 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0000106040-21-000053:note_history:31]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 2,225 |  |  | $ | 1,291 |  |  |  |  |  |  |  |
| Client | 1,853 |  |  | 1,750 |  |  |  |  |  |  |  |
| Consumer | 973 |  |  | 881 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,614 |  |  | $ | 1,079 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 762 |  |  | 629 |  |  |  |  |  |  |  |
| Asia | 2,675 |  |  | 2,214 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |

- removed (2021-11-04):
[0000106040-21-000024:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,962 |  |  | $ | 2,114 |  |  | $ | 5,715 |  |  | $ | 6,918 |  |  |  |
| Flash-based | 2,175 |  |  | 2,061 |  |  | 6,287 |  |  | 5,531 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,012 |  |  | $ | 1,831 |  |  | $ | 6,089 |  |  | $ | 5,244 |  |  |  |
| Data Center Devices & Solutions | 1,237 |  |  | 1,523 |  |  | 3,173 |  |  | 4,544 |  |  |  |
| Client Solutions | 888 |  |  | 821 |  |  | 2,740 |  |  | 2,661 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,009 |  |  | $ | 1,325 |  |  | $ | 3,033 |  |  | $ | 3,934 |  |  |  |
| Europe, Middle East and Africa | 913 |  |  | 770 |  |  | 2,267 |  |  | 2,360 |  |  |  |
| Asia | 2,215 |  |  | 2,080 |  |  | 6,702 |  |  | 6,155 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0000106040-21-000053:note_history:33]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 1, 2021 or July 2, 2021.
  (was, 2021-05-06, similarity 0.979):
[0000106040-21-000024:note_history:33]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 2, 2021 or July 3, 2020.

- changed (2021-11-04):
[0000106040-21-000053:note_history:34]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 1, 2021 and July 2, 2021 as well as the related amortization for the three months ended October 1, 2021 and October 2, 2020 were not material.
  (was, 2021-05-06, similarity 0.9576):
[0000106040-21-000024:note_history:34]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 2, 2021 and July 3, 2020 as well as the related amortization for the three and nine months ended April 2, 2021 and April 3, 2020 were not material.

- changed (2021-11-04):
[0000106040-21-000053:note_history:35]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 1, 2021 and July 2, 2021, contract liabilities were not material.
  (was, 2021-05-06, similarity 0.8636):
[0000106040-21-000024:note_history:35]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 2, 2021 and July 3, 2020, contract liabilities were not material.

- changed (2021-11-04):
[0000106040-21-000053:note_history:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 1, 2021 was $61 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $30 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.
  (was, 2021-05-06, similarity 0.994):
[0000106040-21-000024:note_history:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 2, 2021 was $81 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $10 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.

- removed (2021-11-04):
[0000106040-21-000024:note_history:37]
The Company’s disaggregated revenue information is as follows:

- removed (2021-11-04):
[0000106040-21-000024:note_history:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,962 |  |  | $ | 2,114 |  |  | $ | 5,715 |  |  | $ | 6,918 |  |  |  |
| Flash-based | 2,175 |  |  | 2,061 |  |  | 6,287 |  |  | 5,531 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,012 |  |  | $ | 1,831 |  |  | $ | 6,089 |  |  | $ | 5,244 |  |  |  |
| Data Center Devices & Solutions | 1,237 |  |  | 1,523 |  |  | 3,173 |  |  | 4,544 |  |  |  |
| Client Solutions | 888 |  |  | 821 |  |  | 2,740 |  |  | 2,661 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,009 |  |  | $ | 1,325 |  |  | $ | 3,033 |  |  | $ | 3,934 |  |  |  |
| Europe, Middle East and Africa | 913 |  |  | 770 |  |  | 2,267 |  |  | 2,360 |  |  |  |
| Asia | 2,215 |  |  | 2,080 |  |  | 6,702 |  |  | 6,155 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |

- removed (2021-11-04):
[0000106040-21-000024:note_history:39]
The Company’s top 10 customers accounted for 42% and 40% of its net revenue for the three and nine months ended April 2, 2021, respectively, and 44% of its net revenue for both the three and nine months ended April 3, 2020. For the three and nine months ended April 2, 2021 and April 3, 2020, no single customer accounted for 10% or more of the Company’s net revenue.
