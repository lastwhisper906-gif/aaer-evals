# WDC MD&A — 0000106040-19-000009


## mdna

[0000106040-19-000009:mdna:1]
[same as prior period, unchanged from 0000106040-18-000034:mdna:1]

[0000106040-19-000009:mdna:2]
[same as prior period, unchanged from 0000106040-18-000034:mdna:2]

[0000106040-19-000009:mdna:3]
[same as prior period, unchanged from 0000106040-18-000034:mdna:3]

[0000106040-19-000009:mdna:4]
[same as prior period, unchanged from 0000106040-18-000034:mdna:4]

[0000106040-19-000009:mdna:5]
[same as prior period, unchanged from 0000106040-18-000034:mdna:5]

[0000106040-19-000009:mdna:6]
[same as prior period, unchanged from 0000106040-18-000034:mdna:6]

[0000106040-19-000009:mdna:7]
[same as prior period, unchanged from 0000106040-18-000034:mdna:7]

[0000106040-19-000009:mdna:8]
Through our strategic partnership with Toshiba Memory Corporation (“TMC”) referred to as “Flash Ventures”, we and TMC operate flash-based memory wafer manufacturing facilities in Yokkaichi, Japan. We are obligated to purchase half of Flash Ventures’ flash-based memory wafer supply or pay for half of Flash Ventures’ fixed costs regardless of the output we choose to purchase. We are also obligated to fund 49.9% to 50% of Flash Ventures’ capital investments to the extent that Flash Ventures’ operating cash flow is insufficient to fund these investments.

[0000106040-19-000009:mdna:9]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of the reduced demand for flash-based products, we have temporarily reduced our utilization of our share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align our flash-based wafer supply with the projected demand. We do not expect this action to result in any incremental cash payments; however, as a result of this temporary reduction to abnormally low production levels, we incurred costs of $49 million associated with the reduction in utilization, which was recorded as a charge to cost of revenue in the three months ended December 28, 2018. Including the $49 million recorded through December 28, 2018, we expect total underutilization charges to be recorded in cost of revenue in the range of $250 million to $300 million with the substantial majority expected to be recognized by the end of the fiscal year. We may adjust our plans based on market conditions, which could impact the timing and amount of any charges.

[0000106040-19-000009:mdna:10]
Cost and Expense Reduction Actions

[0000106040-19-000009:mdna:11]
We are taking actions to better align our cost and expense structure to near-term business conditions, including accelerating the closure of our HDD manufacturing facility in Kuala Lumpur, Malaysia, rationalizing other HDD manufacturing costs and other measures to reduce our cost of revenue and operating expenses.

[0000106040-19-000009:mdna:12]
[same as prior period, unchanged from 0000106040-18-000034:mdna:11]

[0000106040-19-000009:mdna:13]
Second Quarter and First Half Overview

[0000106040-19-000009:mdna:14]
[same as prior period, unchanged from 0000106040-18-000034:mdna:13]

[0000106040-19-000009:mdna:15]
|  | Three Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 4,233 |  |  | 100.0 | % |  | $ | 5,336 |  |  | 100.0 | % |  | $ | (1,103 | ) |  | (20.7 | )% |
| Cost of revenue | 3,189 |  |  | 75.3 |  |  | 3,323 |  |  | 62.3 |  |  | (134 | ) |  | (4.0 | ) |
| Gross profit | 1,044 |  |  | 24.7 |  |  | 2,013 |  |  | 37.7 |  |  | (969 | ) |  | (48.1 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 539 |  |  | 12.7 |  |  | 629 |  |  | 11.8 |  |  | (90 | ) |  | (14.3 | ) |
| Selling, general and administrative | 309 |  |  | 7.3 |  |  | 381 |  |  | 7.1 |  |  | (72 | ) |  | (18.9 | ) |
| Employee termination, asset impairment, and other charges | 20 |  |  | 0.5 |  |  | 48 |  |  | 0.9 |  |  | (28 | ) |  | (58.3 | ) |
| Total operating expenses | 868 |  |  | 20.5 |  |  | 1,058 |  |  | 19.8 |  |  | (190 | ) |  | (18.0 | ) |
| Operating income | 176 |  |  | 4.2 |  |  | 955 |  |  | 17.9 |  |  | (779 | ) |  | (81.6 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 15 |  |  | 0.4 |  |  | 14 |  |  | 0.3 |  |  | 1 |  |  | 7.1 |  |
| Interest expense | (118 | ) |  | (2.8 | ) |  | (197 | ) |  | (3.7 | ) |  | 79 |  |  | (40.1 | ) |
| Other income, net | 8 |  |  | 0.2 |  |  | 2 |  |  | — |  |  | 6 |  |  | 300.0 |  |
| Total interest and other expense, net | (95 | ) |  | (2.2 | ) |  | (181 | ) |  | (3.4 | ) |  | 86 |  |  | (47.5 | ) |
| Income before taxes | 81 |  |  | 1.9 |  |  | 774 |  |  | 14.5 |  |  | (693 | ) |  | (89.5 | ) |
| Income tax expense | 568 |  |  | 13.4 |  |  | 1,597 |  |  | 29.9 |  |  | (1,029 | ) |  | (64.4 | ) |
| Net loss | $ | (487 | ) |  | (11.5 | ) |  | $ | (823 | ) |  | (15.4 | ) |  | $ | 336 |  |  | (40.8 | ) |

[0000106040-19-000009:mdna:16]
[same as prior period, unchanged from 0000106040-18-000034:mdna:15]

[0000106040-19-000009:mdna:17]
[same as prior period, unchanged from 0000106040-18-000034:mdna:70]

[0000106040-19-000009:mdna:18]
|  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 9,261 |  |  | 100.0 | % |  | $ | 10,517 |  |  | 100.0 | % |  | $ | (1,256 | ) |  | (11.9 | )% |
| Cost of revenue | 6,553 |  |  | 70.8 |  |  | 6,591 |  |  | 62.7 |  |  | (38 | ) |  | (0.6 | ) |
| Gross profit | 2,708 |  |  | 29.2 |  |  | 3,926 |  |  | 37.3 |  |  | (1,218 | ) |  | (31.0 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,115 |  |  | 12.0 |  |  | 1,221 |  |  | 11.6 |  |  | (106 | ) |  | (8.7 | ) |
| Selling, general and administrative | 665 |  |  | 7.2 |  |  | 745 |  |  | 7.1 |  |  | (80 | ) |  | (10.7 | ) |
| Employee termination, asset impairment, and other charges | 66 |  |  | 0.7 |  |  | 100 |  |  | 1.0 |  |  | (34 | ) |  | (34.0 | ) |
| Total operating expenses | 1,846 |  |  | 19.9 |  |  | 2,066 |  |  | 19.6 |  |  | (220 | ) |  | (10.6 | ) |
| Operating income | 862 |  |  | 9.3 |  |  | 1,860 |  |  | 17.7 |  |  | (998 | ) |  | (53.7 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 30 |  |  | 0.3 |  |  | 30 |  |  | 0.3 |  |  | — |  |  | — |  |
| Interest expense | (234 | ) |  | (2.5 | ) |  | (402 | ) |  | (3.8 | ) |  | 168 |  |  | (41.8 | ) |
| Other income (expense), net | 6 |  |  | 0.1 |  |  | (4 | ) |  | — |  |  | 10 |  |  | (250.0 | ) |
| Total interest and other expense, net | (198 | ) |  | (2.1 | ) |  | (376 | ) |  | (3.6 | ) |  | 178 |  |  | (47.3 | ) |
| Income before taxes | 664 |  |  | 7.2 |  |  | 1,484 |  |  | 14.1 |  |  | (820 | ) |  | (55.3 | ) |
| Income tax expense | 640 |  |  | 6.9 |  |  | 1,626 |  |  | 15.5 |  |  | (986 | ) |  | (60.6 | ) |
| Net income (loss) | $ | 24 |  |  | 0.3 |  |  | $ | (142 | ) |  | (1.4 | ) |  | $ | 166 |  |  | (116.9 | ) |

[0000106040-19-000009:mdna:19]
| (1) | Percentages may not total due to rounding. |

[0000106040-19-000009:mdna:20]
[same as prior period, unchanged from 0000106040-18-000034:mdna:16]

[0000106040-19-000009:mdna:21]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |

[0000106040-19-000009:mdna:22]
[same as prior period, unchanged from 0000106040-18-000034:mdna:18]

[0000106040-19-000009:mdna:23]
[same as prior period, unchanged from 0000106040-18-000034:mdna:20]

[0000106040-19-000009:mdna:24]
Net Revenue. The decrease in net revenue in the three months ended December 28, 2018 from the comparable period of the prior year was primarily driven by lower average selling prices per gigabyte for flash-based products and lower sales of client compute HDD, capacity enterprise HDD and performance enterprise HDD products. Client Devices revenue decreased 16.4% year over year, primarily driven by a reduction in client compute HDD and flash-based mobile products, partially offset by higher revenue in client SSD. Our revenue for Data Center Devices and Solutions decreased 25.1% year over year, primarily driven by lower sales of enterprise SSD, capacity enterprise HDD and performance enterprise HDD products. Client Solutions revenue decreased 24.7% year over year, primarily driven by lower sales of retail HDD and lower average selling prices per gigabyte of flash-based products.

[0000106040-19-000009:mdna:25]
The decrease in net revenue for the six months ended December 28, 2018, compared to the same period in the prior year, is primarily due to lower average selling prices per gigabyte for flash-based products and lower sales of client compute HDD, enterprise SSD and performance enterprise HDD products, partially offset by higher sales of capacity enterprise HDD, flash-based mobile products and client SSD. Client Devices revenue for the six months ended December 28, 2018 decreased 8.6% year over year, primarily driven by lower sales of client compute HDD products, partially offset by stronger sales in the first quarter of flash-based mobile products and client SSD. Our revenue for Data Center Devices and Solutions for the six months ended December 28, 2018 decreased 10.1% year over year, driven primarily by lower sales of our enterprise SSDs and performance enterprise HDDs, partially offset by higher sales of capacity enterprise HDDs. Client Solutions revenue for the six months ended December 28, 2018 decreased 21.5% year over year, primarily driven by lower sales of retail HDD and lower average selling prices per gigabyte of flash-based products.

[0000106040-19-000009:mdna:26]
Our top 10 customers accounted for 47% of our net revenue for the three and six months ended December 28, 2018, respectively, and 42% and 41% of our net revenue for the three and six months ended December 29, 2017, respectively. For the three and six months ended December 28, 2018 and December 29, 2017, no single customer accounted for 10% or more of our net revenue.

[0000106040-19-000009:mdna:27]
[same as prior period, unchanged from 0000106040-18-000034:mdna:22]

[0000106040-19-000009:mdna:28]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and six months ended December 28, 2018, these programs represented 16% and 14% of gross revenues, respectively. For the three and six months ended December 29, 2017, these programs represented 12% and 13% of gross revenues, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-19-000009:mdna:29]
Gross Profit and Gross Margin. The decreases in gross profit for the three and six months ended December 28, 2018 from the comparable periods in the prior year were primarily due to the lower average selling prices per gigabyte for flash-based products and the flash manufacturing underutilization charge recorded in the three months ended December 28, 2018. Gross profit and gross margin include amortization expense on acquired intangible assets, stock-based compensation, a flash manufacturing underutilization charge, and charges related to the implementation of cost-saving initiatives and other charges, which aggregated $283 million, or 6.7%, of revenue, compared to $293 million, or 5.5%, of revenue, for the three months ended December 28, 2018 and December 29, 2017, respectively, and $530 million, or 5.7%, of revenue, compared to $572 million, or 5.4%, of revenue, for the six months ended December 28, 2018 and December 29, 2017, respectively. Including the $49 million recognized through December 28, 2018, we expect gross margins to be negatively impacted by flash manufacturing underutilization charges to be recorded in cost of revenue in the range of $250 million to $300 million with the substantial majority expected to be recognized by the end of the fiscal year.

[0000106040-19-000009:mdna:30]
[same as prior period, unchanged from 0000106040-18-000034:mdna:26]

[0000106040-19-000009:mdna:31]
The decreases in research and development (“R&D”) expense for both the three and six months ended December 28, 2018 from the same periods in the prior year are primarily due to lower variable compensation expense and lower stock-based compensation expenses.

[0000106040-19-000009:mdna:32]
The decreases in selling, general and administrative (“SG&A”) expense for both the three and six months ended December 28, 2018 from the same periods in the prior year are primarily due to lower variable compensation expense. In addition, we had lower charges related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges which aggregated to $68 million for the three months ended December 28, 2018 compared to $97 million for the three months ended December 29, 2017 and aggregated to $141 million for the six months ended December 28, 2018 compared to $187 million in the six months ended December 29, 2017.

[0000106040-19-000009:mdna:33]
Employee termination, asset impairment and other charges primarily related to actions associated with the realignment of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 13, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000009:mdna:34]
[same as prior period, unchanged from 0000106040-18-000034:mdna:30]

[0000106040-19-000009:mdna:35]
The decreases in total interest and other expense, net for both the three and six months ended December 28, 2018 are primarily due to lower interest expense resulting from reductions in the principal amount of debt and lower interest rates as a result of changes to our debt facilities in the third and fourth quarters of fiscal 2018, partially offset by increases in the LIBOR interest rate.

[0000106040-19-000009:mdna:36]
[same as prior period, unchanged from 0000106040-18-000034:mdna:32]

[0000106040-19-000009:mdna:37]
[same as prior period, unchanged from 0000106040-18-000034:mdna:33]

[0000106040-19-000009:mdna:38]
|  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Income before taxes | $ | 81 |  |  | $ | 774 |  |
| Income tax expense | 568 |  |  | 1,597 |  |
| Effective tax rate | 701 | % |  | 206 | % |

[0000106040-19-000009:mdna:39]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21%, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign earnings.

[0000106040-19-000009:mdna:40]
When initially accounting for the tax effects of the enactment of the 2017 Act, we applied the applicable Securities and Exchange Commission (“SEC”) guidance and made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. As we finalized the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, we reflected adjustments to the recorded provisional amounts. As of December 28, 2018, we completed our accounting for the tax effects of the enactment of the 2017 Act. Although the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, we anticipate the issuance of future additional regulatory and interpretive guidance, even though the one-year measurement period has ended. Although we were able to apply a reasonable interpretation of the law along with any available guidance in finalizing our accounting for the tax effects of the 2017 Act, such future additional regulatory or interpretive guidance would constitute new information which may require further refinements to our estimates in future periods.

[0000106040-19-000009:mdna:41]
The primary driver of the difference between the effective tax rate for the three and six months ended December 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended December 28, 2018, these discrete effects consist of $230 million related to the mandatory deemed repatriation tax and $134 million related to the decision to change our indefinite reinvestment assertion. For the six months ended December 28, 2018, these discrete effects consist of $178 million related to the mandatory deemed repatriation tax and $144 million related to the decision to change our indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to the changes in the relative mix of our U.S. earnings compared to foreign earnings.

[0000106040-19-000009:mdna:42]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act. Excluding these items, the effective tax rate for the three and six months ended December 29, 2017 would be approximately 4%. The primary drivers for the remaining difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are the current year generation of tax credits, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires us to now recognize $5 million and $27 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of our income tax expense for the three and six months ended December 29, 2017, respectively.

[0000106040-19-000009:mdna:43]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. Our total tax expense in future fiscal years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-19-000009:mdna:44]
[same as prior period, unchanged from 0000106040-18-000034:mdna:40]

[0000106040-19-000009:mdna:45]
[same as prior period, unchanged from 0000106040-18-000034:mdna:41]

[0000106040-19-000009:mdna:46]
[same as prior period, unchanged from 0000106040-18-000034:mdna:42]

[0000106040-19-000009:mdna:47]
|  | Six months ended |
|  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 1,174 |  |  | $ | 2,315 |  |
| Investing activities | (725 | ) |  | (1,007 | ) |
| Financing activities | (1,438 | ) |  | (1,391 | ) |
| Effect of exchange rate changes on cash | (3 | ) |  | 1 |  |
| Net decrease in cash and cash equivalents | $ | (992 | ) |  | $ | (82 | ) |

[0000106040-19-000009:mdna:48]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, stock repurchases, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10‑Q. See also “Debt” below for information regarding the credit agreement governing our revolving credit facility and term loans (as amended, the “Credit Agreement”).

[0000106040-19-000009:mdna:49]
[same as prior period, unchanged from 0000106040-18-000034:mdna:45]

[0000106040-19-000009:mdna:50]
A total of $2.68 billion and $4.15 billion of our cash and cash equivalents was held outside of the U.S. as of December 28, 2018 and June 29, 2018, respectively. As of December 28, 2018, we finalized the accounting for the tax effects of the mandatory deemed repatriation tax on our indefinite reinvestment assertion. After re-evaluating the existing short- and long-term capital allocation polices, we intend to repatriate all of our foreign undistributed earnings. Accordingly, during the six months ended December 28, 2018, we included a foreign income tax expense of $242 million related to foreign withholding taxes partially offset by foreign tax credits of $82 million. In addition, a state income tax expense of $54 million was recorded, partially offset by a decrease to our valuation allowance of $45 million. Amounts related to federal taxes other than the repatriation tax were not material. Our decision to change our indefinite reinvestment assertion is based on interpretative guidance issued by the IRS to date related to the ordering and the taxation of a repatriation of our foreign undistributed earnings. For additional information regarding our indefinite reinvestment assertion, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000009:mdna:51]
56

[0000106040-19-000009:mdna:52]
[same as prior period, unchanged from 0000106040-18-000034:mdna:48]

[0000106040-19-000009:mdna:53]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in other operating assets and liabilities was $298 million for the six months ended December 28, 2018, as compared to net cash provided of $1.27 billion for the six months ended December 29, 2017. The net cash provided by changes in other operating assets and liabilities in the six months ended December 29, 2017 primarily reflects the payable recorded for the mandatory deemed repatriation tax as described in Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q. Changes in our other operating assets and liabilities are also largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-19-000009:mdna:54]
|  | Quarter to Date |
|  | December 28, 2018 |  | December 29, 2017 |
|  | (in days) |
| Days sales outstanding | 37 |  |  | 35 |  |
| Days in inventory | 98 |  |  | 62 |  |
| Days payables outstanding | (64 | ) |  | (59 | ) |
| Cash conversion cycle | 71 |  |  | 38 |  |

[0000106040-19-000009:mdna:55]
[same as prior period, unchanged from 0000106040-18-000034:mdna:51]

[0000106040-19-000009:mdna:56]
For the three months ended December 28, 2018, DSO increased by 2 days over the prior year, primarily reflecting the timing of shipments and customer collections. DIO increased by 36 days over the prior year, primarily reflecting increases in hard drive inventory in preparation for the planned plant closures in Kuala Lumpur, Malaysia and increases in flash inventory. DPO increased by 5 days over the prior year, primarily reflecting routine variations in timing of purchases and payments during the period.

[0000106040-19-000009:mdna:57]
[same as prior period, unchanged from 0000106040-18-000034:mdna:53]

[0000106040-19-000009:mdna:58]
During the six months ended December 28, 2018, net cash used in investing activities primarily consisted of $500 million of capital expenditures and a net $196 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion. Net cash used in investing activities for the six months ended December 29, 2017 primarily consisted of $416 million of capital expenditures, a $509 million net increase in notes receivable issuances to and investments in Flash Ventures and $99 million for acquisitions.

[0000106040-19-000009:mdna:59]
[same as prior period, unchanged from 0000106040-18-000034:mdna:55]

[0000106040-19-000009:mdna:60]
[same as prior period, unchanged from 0000106040-18-000034:mdna:56]

[0000106040-19-000009:mdna:61]
During the six months ended December 28, 2018, net cash used in financing activities primarily consisted of $575 million for the repayment of our revolving credit facility and debt, $563 million of share repurchases and $292 million to pay dividends on our common stock. Net cash used in financing activities for the six months ended December 29, 2017 primarily consisted of a net $1.15 billion reduction in debt and $295 million to pay dividends on our common stock.

[0000106040-19-000009:mdna:62]
57

[0000106040-19-000009:mdna:63]
[same as prior period, unchanged from 0000106040-18-000034:mdna:58]

[0000106040-19-000009:mdna:64]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000009:mdna:65]
[same as prior period, unchanged from 0000106040-18-000034:mdna:60]

[0000106040-19-000009:mdna:66]
[same as prior period, unchanged from 0000106040-18-000034:mdna:61]

[0000106040-19-000009:mdna:67]
The following is a summary of our known contractual cash obligations and commercial commitments as of December 28, 2018:

[0000106040-19-000009:mdna:68]
|  | Total |  | 1 Year (Remaining 6 months of 2019) |  | 2-3 Years (2020-2021) |  | 4-5 Years (2022-2023) |  | More than 5 Years (Beyond 2023) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 10,800 |  |  | $ | 107 |  |  | $ | 517 |  |  | $ | 6,776 |  |  | $ | 3,400 |  |
| Interest on debt | 2,137 |  |  | 215 |  |  | 847 |  |  | 731 |  |  | 344 |  |
| Flash Ventures and other related commitments(2) | 6,769 |  |  | 1,968 |  |  | 2,772 |  |  | 1,582 |  |  | 447 |  |
| Operating leases | 170 |  |  | 28 |  |  | 84 |  |  | 39 |  |  | 19 |  |
| Purchase obligations | 2,816 |  |  | 1,777 |  |  | 561 |  |  | 478 |  |  | — |  |
| Mandatory Deemed Repatriation Tax | 1,208 |  |  | — |  |  | 186 |  |  | 215 |  |  | 807 |  |
| Total | $ | 23,900 |  |  | $ | 4,095 |  |  | $ | 4,967 |  |  | $ | 9,821 |  |  | $ | 5,017 |  |

[0000106040-19-000009:mdna:69]
[same as prior period, unchanged from 0000106040-18-000034:mdna:64]

[0000106040-19-000009:mdna:70]
[same as prior period, unchanged from 0000106040-18-000034:mdna:65]

[0000106040-19-000009:mdna:71]
[same as prior period, unchanged from 0000106040-18-000034:mdna:66]

[0000106040-19-000009:mdna:72]
We had $10.80 billion of debt outstanding as of December 28, 2018, including $7.37 billion of term loans under our Credit Agreement, $2.30 billion of senior unsecured notes due 2024 and $1.10 billion of convertible notes due 2024.

[0000106040-19-000009:mdna:73]
Under the Credit Agreement, we are required to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, which consist of a leverage ratio and an interest coverage ratio. As of December 28, 2018, we were in compliance with all financial covenants under the Credit Agreement.

[0000106040-19-000009:mdna:74]
The financial covenants are based upon a trailing twelve-month Adjusted EBITDA as defined in the Credit Agreement.  Our Adjusted EBITDA declined significantly during the three months ended December 28, 2018, and such decline may continue. Sustained deterioration in our operating results could cause our trailing twelve-month Adjusted EBITDA to drop below the threshold required for compliance with our leverage ratio, which could result in an event of default under the Credit Agreement. If an event of default under the Credit Agreement were to occur and if we were not able to obtain a waiver from the required lenders (or if we were not able to obtain such waiver on terms acceptable to us), there could be significant negative consequences for the Company. See Part II, Item 1A, “Risk Factors—Our high level of debt may have an adverse impact on our liquidity, restrict our current and future operations, particularly our ability to respond to business opportunities, and increase our vulnerability to adverse economic and industry conditions” for a discussion of risks related to our level of debt, including the consequences of an event of default thereunder.

[0000106040-19-000009:mdna:75]
Additional information regarding our indebtedness, including information about new borrowings and repayments, increased availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q and Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10‑K for the year ended June 29, 2018.

[0000106040-19-000009:mdna:76]
[same as prior period, unchanged from 0000106040-18-000034:mdna:68]

[0000106040-19-000009:mdna:77]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of December 28, 2018, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding Flash Ventures.

[0000106040-19-000009:mdna:78]
[same as prior period, unchanged from 0000106040-18-000034:mdna:71]

[0000106040-19-000009:mdna:79]
[same as prior period, unchanged from 0000106040-18-000034:mdna:72]

[0000106040-19-000009:mdna:80]
Mandatory Deemed Repatriation Tax

[0000106040-19-000009:mdna:81]
The following is a summary of our estimated mandatory deemed repatriation tax obligations that are payable in the following fiscal years (in millions):

[0000106040-19-000009:mdna:82]
| Remaining six months of 2019 |  | $ | — |  |
| 2020 |  | 78 |  |
| 2021 |  | 108 |  |
| 2022 |  | 108 |  |
| 2023 |  | 108 |  |
| 2024 |  | 202 |  |
| 2025 |  | 268 |  |
| 2026 |  | 336 |  |
| Total |  | $ | 1,208 |  |

[0000106040-19-000009:mdna:83]
The 2017 Act allows for the mandatory deemed repatriation tax of $1.36 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. As of December 28, 2018, total payments of $150 million have been made towards the mandatory deemed repatriation tax of $1.36 billion for a remaining net tax liability owed of $1.21 billion. For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000009:mdna:84]
[same as prior period, unchanged from 0000106040-18-000034:mdna:77]

[0000106040-19-000009:mdna:85]
As of December 28, 2018, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $690 million. Accrued interest and penalties related to unrecognized tax benefits as of December 28, 2018 was approximately $116 million. Of these amounts, approximately $688 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000009:mdna:86]
[same as prior period, unchanged from 0000106040-18-000034:mdna:79]

[0000106040-19-000009:mdna:87]
[same as prior period, unchanged from 0000106040-18-000034:mdna:80]

[0000106040-19-000009:mdna:88]
[same as prior period, unchanged from 0000106040-18-000034:mdna:81]

[0000106040-19-000009:mdna:89]
[same as prior period, unchanged from 0000106040-18-000034:mdna:82]

[0000106040-19-000009:mdna:90]
[same as prior period, unchanged from 0000106040-18-000034:mdna:83]

[0000106040-19-000009:mdna:91]
[same as prior period, unchanged from 0000106040-18-000034:mdna:84]

[0000106040-19-000009:mdna:92]
[same as prior period, unchanged from 0000106040-18-000034:mdna:85]

[0000106040-19-000009:mdna:93]
[same as prior period, unchanged from 0000106040-18-000034:mdna:86]

[0000106040-19-000009:mdna:94]
Our Board of Directors previously authorized $5.00 billion for the repurchase of our common stock. On July 25, 2018, our Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. For the three months ended December 28, 2018, we did not make any stock repurchases. For the six months ended December 28, 2018, we repurchased 0.8 million shares for a total cost of $61 million under the previous authorization and 7.6 million shares for a total cost of $502 million under the new authorization. Therefore, our stock repurchases under all stock repurchase authorizations in effect for the six months ended December 28, 2018 totaled $563 million. The remaining amount available to be repurchased under our current stock repurchase program as of December 28, 2018 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000009:mdna:95]
[same as prior period, unchanged from 0000106040-18-000034:mdna:88]

[0000106040-19-000009:mdna:96]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On July 16, 2018, we paid $148 million for a dividend declared in the fourth quarter of fiscal 2018. During the six months ended December 28, 2018, we declared aggregate cash dividends of $1.00 per share on our outstanding common stock totaling $290 million, of which $146 million was paid on January 14, 2019. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-19-000009:mdna:97]
[same as prior period, unchanged from 0000106040-18-000034:mdna:90]

[0000106040-19-000009:mdna:98]
[same as prior period, unchanged from 0000106040-18-000034:mdna:91]

[0000106040-19-000009:mdna:99]
[same as prior period, unchanged from 0000106040-18-000034:mdna:92]

[0000106040-19-000009:mdna:100]
[same as prior period, unchanged from 0000106040-18-000034:mdna:93]

[0000106040-19-000009:mdna:101]
See Part I, Item 1, Note 2, Recent Accounting Pronouncements, and Note 3, Revenues, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for a discussion of a recently adopted accounting pronouncement that affects our recognition of revenue.  There have been no other material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 29, 2018.  Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 29, 2018 for a discussion of our critical accounting policies and estimates.
