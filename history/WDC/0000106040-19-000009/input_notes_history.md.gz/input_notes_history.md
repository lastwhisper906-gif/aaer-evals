# WDC note change history — 0000106040-18-000034 → 0000106040-19-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 28, 2018 and June 29, 2018:
  (was, 2018-11-06, similarity 0.9808):
[0000106040-18-000034:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 28, 2018 and June 29, 2018:

- changed (2019-02-05):
[0000106040-19-000009:note_history:2]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 695 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 418 |  |  | 48 |  |
| Notes receivable, Flash Forward | 607 |  |  | 700 |  |
| Investment in Flash Partners | 193 |  |  | 191 |  |
| Investment in Flash Alliance | 286 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,318 |  |  | $ | 2,105 |  |
  (was, 2018-11-06, similarity 0.9919):
[0000106040-18-000034:note_history:2]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 94 |  |  | 48 |  |
| Notes receivable, Flash Forward | 619 |  |  | 700 |  |
| Investment in Flash Partners | 187 |  |  | 191 |  |
| Investment in Flash Alliance | 277 |  |  | 283 |  |
| Investment in Flash Forward | 114 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,028 |  |  | $ | 2,105 |  |

- changed (2019-02-05):
[0000106040-19-000009:note_history:3]
During the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $1.12 billion and $1.86 billion, respectively, for purchased flash-based memory wafers and net loans and investments.
  (was, 2018-11-06, similarity 0.8843):
[0000106040-18-000034:note_history:3]
During the three months ended September 28, 2018, the Company made net payments to Flash Ventures of $744 million for purchased flash-based memory wafers and net loans and investments.

- changed (2019-02-05):
[0000106040-19-000009:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and six months ended December 28, 2018 or December 29, 2017.
  (was, 2018-11-06, similarity 0.9271):
[0000106040-18-000034:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three months ended September 28, 2018 or September 29, 2017.

- changed (2019-02-05):
[0000106040-19-000009:note_history:5]
As of December 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $310 million and $259 million, respectively.
  (was, 2018-11-06, similarity 0.9821):
[0000106040-18-000034:note_history:5]
As of September 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $286 million and $259 million, respectively.

- added (2019-02-05):
[0000106040-19-000009:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2019-02-05):
[0000106040-19-000009:note_history:7]
|  | December 28, 2018 |
| Notes receivable | $ | 1,720 |  |
| Equity investments | 598 |  |
| Operating lease guarantees | 1,313 |  |
| Inventory and prepayments | 243 |  |
| Maximum estimable loss exposure | $ | 3,874 |  |
  (was, 2018-11-06, similarity 0.9873):
[0000106040-18-000034:note_history:7]
|  | September 28, 2018 |
| Notes receivable | $ | 1,450 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 1,236 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 3,623 |  |

- changed (2019-02-05):
[0000106040-19-000009:note_history:8]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.
  (was, 2018-11-06, similarity 0.6512):
[0000106040-18-000034:note_history:8]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. The Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- added (2019-02-05):
[0000106040-19-000009:note_history:9]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of reduced demand for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $49 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three months ended December 28, 2018.

- changed (2019-02-05):
[0000106040-19-000009:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018.
  (was, 2018-11-06, similarity 0.9864):
[0000106040-18-000034:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018.

- changed (2019-02-05):
[0000106040-19-000009:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018:
  (was, 2018-11-06, similarity 0.9808):
[0000106040-18-000034:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018:

- changed (2019-02-05):
[0000106040-19-000009:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2019 |  | $ | 294 |  |  | $ | 34 |  |  | $ | 328 |  |
| 2020 |  | 294 |  |  | 67 |  |  | 361 |  |
| 2021 |  | 207 |  |  | 121 |  |  | 328 |  |
| 2022 |  | 112 |  |  | 22 |  |  | 134 |  |
| 2023 |  | 49 |  |  | 88 |  |  | 137 |  |
| Thereafter |  | 4 |  |  | 21 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 960 |  |  | $ | 353 |  |  | $ | 1,313 |  |
  (was, 2018-11-06, similarity 0.9923):
[0000106040-18-000034:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2019 |  | $ | 280 |  |  | $ | 33 |  |  | $ | 313 |  |
| 2020 |  | 282 |  |  | 61 |  |  | 343 |  |
| 2021 |  | 197 |  |  | 95 |  |  | 292 |  |
| 2022 |  | 110 |  |  | 47 |  |  | 157 |  |
| 2023 |  | 42 |  |  | 64 |  |  | 106 |  |
| Thereafter |  | 3 |  |  | 22 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 914 |  |  | $ | 322 |  |  | $ | 1,236 |  |

- changed (2019-02-05):
[0000106040-19-000009:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2018-11-06, similarity 0.9932):
[0000106040-18-000034:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2019-02-05):
[0000106040-19-000009:note_history:14]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 28, 2018 and December 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of December 28, 2018 or June 29, 2018.
  (was, 2018-11-06, similarity 0.9497):
[0000106040-18-000034:note_history:14]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis “) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture are recognized upon sell through to third-party customers. For the three-month periods ended September 28, 2018 and September 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of September 28, 2018 or June 29, 2018.

- changed (2019-02-05):
[0000106040-19-000009:note_history:15]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of December 28, 2018, the Company had the following minimum long-term purchase commitments:
  (was, 2018-11-06, similarity 0.9956):
[0000106040-18-000034:note_history:15]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of September 28, 2018, the Company had the following minimum long-term purchase commitments:

- changed (2019-02-05):
[0000106040-19-000009:note_history:16]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining six months of 2019 |  | $ | 34 |  |
| 2020 |  | 193 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 912 |  |
  (was, 2018-11-06, similarity 0.9838):
[0000106040-18-000034:note_history:16]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining nine months of 2019 |  | $ | 14 |  |
| 2020 |  | 144 |  |
| 2021 |  | 141 |  |
| 2022 |  | 150 |  |
| 2023 and thereafter |  | 170 |  |
| Total |  | $ | 619 |  |

- removed (2019-02-05):
[0000106040-18-000034:note_history:17]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:18]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. In December 2018, the remaining three plaintiffs stipulated to dismiss their claims against the defendants.
  (was, 2018-11-06, similarity 0.8782):
[0000106040-18-000034:note_history:18]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. Counsel for the remaining named plaintiffs are engaged in settlement discussions with counsel for the defendants. The case has been stayed pending these settlement discussions. The Company intends to defend itself vigorously in this matter.

- changed (2019-02-05):
[0000106040-19-000009:note_history:19]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, all court proceedings have been terminated. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.
  (was, 2018-11-06, similarity 0.6019):
[0000106040-18-000034:note_history:19]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, the Company and ZPÜ intend to dismiss the actions against each other following an accounting and payment of past liabilities. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.

- changed (2019-02-05):
[0000106040-19-000009:note_history:20]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.
  (was, 2018-11-06, similarity 0.9505):
[0000106040-18-000034:note_history:20]
For disclosures regarding a statutory notice of deficiency issued by the IRS on June 28, 2018 and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:21]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.
  (was, 2018-11-06, similarity 0.7474):
[0000106040-18-000034:note_history:21]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:22]
Debt consisted of the following as of December 28, 2018 and June 29, 2018:
  (was, 2018-11-06, similarity 0.9612):
[0000106040-18-000034:note_history:22]
Debt consisted of the following as of September 28, 2018 and June 29, 2018:

- changed (2019-02-05):
[0000106040-19-000009:note_history:23]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,928 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,437 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,800 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (186 | ) |  | (203 | ) |
| Subtotal | 10,614 |  |  | 11,172 |  |
| Less current portion of long-term debt | (244 | ) |  | (179 | ) |
| Long-term debt | $ | 10,370 |  |  | $ | 10,993 |  |
  (was, 2018-11-06, similarity 0.9927):
[0000106040-18-000034:note_history:23]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,959 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,443 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 11,337 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (194 | ) |  | (203 | ) |
| Subtotal | 11,143 |  |  | 11,172 |  |
| Less current portion of long-term debt | (213 | ) |  | (179 | ) |
| Long-term debt | $ | 10,930 |  |  | $ | 10,993 |  |

- added (2019-02-05):
[0000106040-19-000009:note_history:24]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At December 28, 2018, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

- added (2019-02-05):
[0000106040-19-000009:note_history:25]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement.

- added (2019-02-05):
[0000106040-19-000009:note_history:26]
Pursuant to the Credit Agreement, the Company is required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 4, 2019, 4.00 to 1.00 through the quarter ending October 2, 2020, and 3.75 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00. As of December 28, 2018, the Company was in compliance with all financial covenants under the Credit Agreement.

- added (2019-02-05):
[0000106040-19-000009:note_history:27]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.

- removed (2019-02-05):
[0000106040-18-000034:note_history:28]
The Company is required to comply with certain financial covenants underlying its debt facilities, such as a leverage ratio and an interest coverage ratio. As of September 28, 2018, the Company was in compliance with all financial covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:29]
Debt consisted of the following as of December 28, 2018 and June 29, 2018:
  (was, 2018-11-06, similarity 0.9612):
[0000106040-18-000034:note_history:29]
Debt consisted of the following as of September 28, 2018 and June 29, 2018:

- changed (2019-02-05):
[0000106040-19-000009:note_history:30]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,928 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,437 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,800 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (186 | ) |  | (203 | ) |
| Subtotal | 10,614 |  |  | 11,172 |  |
| Less current portion of long-term debt | (244 | ) |  | (179 | ) |
| Long-term debt | $ | 10,370 |  |  | $ | 10,993 |  |
  (was, 2018-11-06, similarity 0.9927):
[0000106040-18-000034:note_history:30]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,959 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,443 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 11,337 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (194 | ) |  | (203 | ) |
| Subtotal | 11,143 |  |  | 11,172 |  |
| Less current portion of long-term debt | (213 | ) |  | (179 | ) |
| Long-term debt | $ | 10,930 |  |  | $ | 10,993 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:31]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 28, 2018 and June 29, 2018:
  (was, 2018-11-06, similarity 0.9808):
[0000106040-18-000034:note_history:31]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 28, 2018 and June 29, 2018:

- changed (2019-02-05):
[0000106040-19-000009:note_history:32]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 695 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 418 |  |  | 48 |  |
| Notes receivable, Flash Forward | 607 |  |  | 700 |  |
| Investment in Flash Partners | 193 |  |  | 191 |  |
| Investment in Flash Alliance | 286 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,318 |  |  | $ | 2,105 |  |
  (was, 2018-11-06, similarity 0.9919):
[0000106040-18-000034:note_history:32]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 94 |  |  | 48 |  |
| Notes receivable, Flash Forward | 619 |  |  | 700 |  |
| Investment in Flash Partners | 187 |  |  | 191 |  |
| Investment in Flash Alliance | 277 |  |  | 283 |  |
| Investment in Flash Forward | 114 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,028 |  |  | $ | 2,105 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:33]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,060 |  |  | $ | 2,694 |  |  | $ | 4,554 |  |  | $ | 5,304 |  |
| Flash-based | 2,173 |  |  | 2,642 |  |  | 4,707 |  |  | 5,213 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |
  (was, 2018-11-06, similarity 0.6596):
[0000106040-18-000034:note_history:33]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | 5,028 |  |  | 5,181 |  |
| Revenue by Form Factor |  |  |  |
| HDD | $ | 2,494 |  |  | $ | 2,610 |  |
| Flash-based | 2,534 |  |  | 2,571 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0000106040-19-000009:note_history:34]
An immaterial amount of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.
  (was, 2018-11-06, similarity 0.9902):
[0000106040-18-000034:note_history:34]
Some of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

- changed (2019-02-05):
[0000106040-19-000009:note_history:35]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 28, 2018 or the date of adoption of Topic 606.
  (was, 2018-11-06, similarity 0.9884):
[0000106040-18-000034:note_history:35]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 28, 2018 or the date of adoption of Topic 606.

- changed (2019-02-05):
[0000106040-19-000009:note_history:36]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and six months ended December 28, 2018 were not material.
  (was, 2018-11-06, similarity 0.9779):
[0000106040-18-000034:note_history:36]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three months ended September 28, 2018 were not material.

- changed (2019-02-05):
[0000106040-19-000009:note_history:37]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 28, 2018 and the date of adoption of Topic 606, contract liabilities were $53 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the six months ended December 28, 2018 include $80 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.
  (was, 2018-11-06, similarity 0.8507):
[0000106040-18-000034:note_history:37]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of September 28, 2018 and the date of adoption of Topic 606, contract liabilities were $86 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the three months ended September 28, 2018 were primarily the result of $41 million of revenue recognized during the period that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

- changed (2019-02-05):
[0000106040-19-000009:note_history:38]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 28, 2018 was $220 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $40 million during the remainder of fiscal 2019, $60 million in fiscal 2020, $46 million in fiscal 2021 and $74 million thereafter.
  (was, 2018-11-06, similarity 0.79):
[0000106040-18-000034:note_history:38]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to unearned revenue and multi-year contracts with future installment payments at the end of any given period. The transaction price allocated to the other remaining performance obligations as of September 28, 2018 was $263 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $87 million during the remainder of fiscal 2019, $58 million in fiscal 2020, $45 million in fiscal 2021 and $73 million thereafter.

- changed (2019-02-05):
[0000106040-19-000009:note_history:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,060 |  |  | $ | 2,694 |  |  | $ | 4,554 |  |  | $ | 5,304 |  |
| Flash-based | 2,173 |  |  | 2,642 |  |  | 4,707 |  |  | 5,213 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |
  (was, 2018-11-06, similarity 0.6596):
[0000106040-18-000034:note_history:39]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | 5,028 |  |  | 5,181 |  |
| Revenue by Form Factor |  |  |  |
| HDD | $ | 2,494 |  |  | $ | 2,610 |  |
| Flash-based | 2,534 |  |  | 2,571 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |

- added (2019-02-05):
[0000106040-19-000009:note_history:40]
The Company’s top 10 customers accounted for 47% of its net revenue for both the three and six months ended December 28, 2018, and 42% and 41% of its net revenue for the three and six months ended December 29, 2017, respectively. For the three and six months ended December 28, 2018 and December 29, 2017, no single customer accounted for 10% or more of the Company’s net revenue.

- removed (2019-02-05):
[0000106040-18-000034:note_history:41]
For the three months ended September 28, 2018 and September 29, 2017, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended September 28, 2018 and September 29, 2017, the Company’s top 10 customers accounted for 48% and 42% of the Company’s net revenue, respectively.
