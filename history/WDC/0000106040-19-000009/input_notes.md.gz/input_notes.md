# WDC notes — 0000106040-19-000009


## srt:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-19-000009:notes:1]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | 24 |  |  | $ | 43 |  |  | $ | 212 |  |  | $ | (255 | ) |  | $ | 24 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | (6 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (6 | ) |
| Net unrealized gain, on derivative contracts and available-for-sale securities | 6 |  |  | 22 |  |  | 20 |  |  | (42 | ) |  | 6 |  |
| Total other comprehensive income, before tax | 1 |  |  | 21 |  |  | 19 |  |  | (40 | ) |  | 1 |  |
| Income tax benefit (expense) related to items of other comprehensive income | 4 |  |  | (2 | ) |  | (1 | ) |  | 2 |  |  | 3 |  |
| Other comprehensive income, net of tax | 5 |  |  | 19 |  |  | 18 |  |  | (38 | ) |  | 4 |  |
| Total comprehensive income | $ | 29 |  |  | $ | 62 |  |  | $ | 230 |  |  | $ | (293 | ) |  | $ | 28 |  |

[0000106040-19-000009:notes:2]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (823 | ) |  | $ | (762 | ) |  | $ | 595 |  |  | $ | 167 |  |  | $ | (823 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | 6 |  |  | 5 |  |  | 5 |  |  | (10 | ) |  | 6 |  |
| Net unrealized gain on derivative contracts and available-for-sale securities | 10 |  |  | 3 |  |  | 3 |  |  | (6 | ) |  | 10 |  |
| Total other comprehensive income, before tax | 16 |  |  | 8 |  |  | 8 |  |  | (16 | ) |  | 16 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (3 | ) |  | — |  |  | 1 |  |  | (1 | ) |  | (3 | ) |
| Other comprehensive income, net of tax | 13 |  |  | 8 |  |  | 9 |  |  | (17 | ) |  | 13 |  |
| Total comprehensive income (loss) | $ | (810 | ) |  | $ | (754 | ) |  | $ | 604 |  |  | $ | 150 |  |  | $ | (810 | ) |

[0000106040-19-000009:notes:3]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (142 | ) |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | (1,213 | ) |  | $ | (142 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustment | 2 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 2 |  |
| Net unrealized gain on derivative contracts and available-for-sale securities | 13 |  |  | 5 |  |  | 5 |  |  | (10 | ) |  | 13 |  |
| Total other comprehensive income, before tax | 15 |  |  | 6 |  |  | 6 |  |  | (12 | ) |  | 15 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (3 | ) |  | — |  |  | (1 | ) |  | 1 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 12 |  |  | 6 |  |  | 5 |  |  | (11 | ) |  | 12 |  |
| Total comprehensive income (loss) | $ | (130 | ) |  | $ | 49 |  |  | $ | 1,175 |  |  | $ | (1,224 | ) |  | $ | (130 | ) |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-19-000009:notes:4]
| Condensed Consolidating Balance Sheet |
| As of December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 17 |  |  | $ | 1,163 |  |  | $ | 2,833 |  |  | $ | — |  |  | $ | 4,013 |  |
| Accounts receivable, net | — |  |  | 873 |  |  | 842 |  |  | — |  |  | 1,715 |  |
| Intercompany receivables | 2,474 |  |  | 4,971 |  |  | 2,215 |  |  | (9,660 | ) |  | — |  |
| Inventories | — |  |  | 1,165 |  |  | 2,495 |  |  | (233 | ) |  | 3,427 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 40 |  |  | (40 | ) |  | — |  |
| Other current assets | 15 |  |  | 248 |  |  | 324 |  |  | — |  |  | 587 |  |
| Total current assets | 2,506 |  |  | 8,420 |  |  | 8,749 |  |  | (9,933 | ) |  | 9,742 |  |
| Property, plant and equipment, net | — |  |  | 1,056 |  |  | 2,021 |  |  | — |  |  | 3,077 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,318 |  |  | — |  |  | 2,318 |  |
| Goodwill | — |  |  | 388 |  |  | 9,686 |  |  | — |  |  | 10,074 |  |
| Other intangible assets, net | — |  |  | 33 |  |  | 2,115 |  |  | — |  |  | 2,148 |  |
| Investments in consolidated subsidiaries | 21,070 |  |  | 17,984 |  |  | — |  |  | (39,054 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 386 |  |  | — |  |  | (386 | ) |  | — |  |
| Other non-current assets | 57 |  |  | 49 |  |  | 484 |  |  | (10 | ) |  | 580 |  |
| Total assets | $ | 23,633 |  |  | $ | 28,316 |  |  | $ | 25,373 |  |  | $ | (49,383 | ) |  | $ | 27,939 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 217 |  |  | $ | 1,708 |  |  | $ | — |  |  | $ | 1,925 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 310 |  |  | — |  |  | 310 |  |
| Intercompany payables | 1,548 |  |  | 4,161 |  |  | 3,951 |  |  | (9,660 | ) |  | — |  |
| Accrued expenses | 206 |  |  | 640 |  |  | 680 |  |  | — |  |  | 1,526 |  |
| Accrued compensation | — |  |  | 208 |  |  | 137 |  |  | — |  |  | 345 |  |
| Loans due to consolidated affiliates | — |  |  | 40 |  |  | — |  |  | (40 | ) |  | — |  |
| Current portion of long-term debt | 244 |  |  | — |  |  | — |  |  | — |  |  | 244 |  |
| Total current liabilities | 1,998 |  |  | 5,266 |  |  | 6,786 |  |  | (9,700 | ) |  | 4,350 |  |
| Long-term debt | 10,338 |  |  | — |  |  | 32 |  |  | — |  |  | 10,370 |  |
| Loans due to consolidated affiliates | 370 |  |  | — |  |  | 16 |  |  | (386 | ) |  | — |  |
| Other liabilities | 15 |  |  | 1,777 |  |  | 525 |  |  | (10 | ) |  | 2,307 |  |
| Total liabilities | 12,721 |  |  | 7,043 |  |  | 7,359 |  |  | (10,096 | ) |  | 17,027 |  |
| Total shareholders’ equity | 10,912 |  |  | 21,273 |  |  | 18,014 |  |  | (39,287 | ) |  | 10,912 |  |
| Total liabilities and shareholders’ equity | $ | 23,633 |  |  | $ | 28,316 |  |  | $ | 25,373 |  |  | $ | (49,383 | ) |  | $ | 27,939 |  |

[0000106040-19-000009:notes:5]
| Condensed Consolidating Balance Sheet |
| As of June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |
| Accounts receivable, net | — |  |  | 1,358 |  |  | 839 |  |  | — |  |  | 2,197 |  |
| Intercompany receivables | 1,903 |  |  | 4,256 |  |  | 2,674 |  |  | (8,833 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,159 |  |  | (205 | ) |  | 2,944 |  |
| Other current assets | 20 |  |  | 195 |  |  | 277 |  |  | — |  |  | 492 |  |
| Total current assets | 1,963 |  |  | 7,467 |  |  | 10,246 |  |  | (9,038 | ) |  | 10,638 |  |
| Property, plant and equipment, net | — |  |  | 1,092 |  |  | 2,003 |  |  | — |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,105 |  |  | — |  |  | 2,105 |  |
| Goodwill | — |  |  | 387 |  |  | 9,688 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 38 |  |  | 2,642 |  |  | — |  |  | 2,680 |  |
| Investments in consolidated subsidiaries | 20,847 |  |  | 19,893 |  |  | — |  |  | (40,740 | ) |  | — |  |
| Loans due from consolidated affiliates | 943 |  |  | 16 |  |  | — |  |  | (959 | ) |  | — |  |
| Other non-current assets | 182 |  |  | 29 |  |  | 431 |  |  | — |  |  | 642 |  |
| Total assets | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 279 |  |  | $ | 1,986 |  |  | $ | — |  |  | $ | 2,265 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Intercompany payables | 1,066 |  |  | 4,648 |  |  | 3,119 |  |  | (8,833 | ) |  | — |  |
| Accrued expenses | 198 |  |  | 505 |  |  | 571 |  |  | — |  |  | 1,274 |  |
| Accrued compensation | — |  |  | 297 |  |  | 182 |  |  | — |  |  | 479 |  |
| Current portion of long-term debt | 179 |  |  | — |  |  | — |  |  | — |  |  | 179 |  |
| Total current liabilities | 1,443 |  |  | 5,729 |  |  | 6,117 |  |  | (8,833 | ) |  | 4,456 |  |
| Long-term debt | 10,962 |  |  | — |  |  | 31 |  |  | — |  |  | 10,993 |  |
| Loans due to consolidated affiliates | — |  |  | 427 |  |  | 532 |  |  | (959 | ) |  | — |  |
| Other liabilities | (1 | ) |  | 1,768 |  |  | 488 |  |  | — |  |  | 2,255 |  |
| Total liabilities | 12,404 |  |  | 7,924 |  |  | 7,168 |  |  | (9,792 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,531 |  |  | 20,998 |  |  | 19,947 |  |  | (40,945 | ) |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |


## srt:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-19-000009:notes:6]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 103 |  |  | $ | (819 | ) |  | $ | 1,934 |  |  | $ | (44 | ) |  | $ | 1,174 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (129 | ) |  | (371 | ) |  | — |  |  | (500 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Purchases of investments | — |  |  | (11 | ) |  | (22 | ) |  | — |  |  | (33 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (508 | ) |  | — |  |  | (508 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 312 |  |  | — |  |  | 312 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | (18 | ) |  | — |  |  | (19 | ) |
| Intercompany loan from (to) consolidated affiliates | 943 |  |  | (370 | ) |  | — |  |  | (573 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (215 | ) |  | 215 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 728 |  |  | (296 | ) |  | (584 | ) |  | (573 | ) |  | (725 | ) |
| Cash flows from financing activities |  |  |  |  |  |  | — |  |  |  |
| Issuance of stock under employee stock plans | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |
| Taxes paid on vested stock awards under employee stock plans | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Repayment of revolving credit facility | (500 | ) |  | — |  |  | — |  |  | — |  |  | (500 | ) |
| Dividends paid to shareholders | (292 | ) |  | — |  |  | — |  |  | — |  |  | (292 | ) |
| Repayment of debt | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Intercompany loan from (to) consolidated affiliates | 370 |  |  | (387 | ) |  | (556 | ) |  | 573 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 214 |  |  | 1,997 |  |  | (2,255 | ) |  | 44 |  |  | — |  |
| Net cash provided by (used in) financing activities | (854 | ) |  | 1,610 |  |  | (2,811 | ) |  | 617 |  |  | (1,438 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | (23 | ) |  | 495 |  |  | (1,464 | ) |  | — |  |  | (992 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | $ | 17 |  |  | $ | 1,163 |  |  | $ | 2,833 |  |  | $ | — |  |  | $ | 4,013 |  |

[0000106040-19-000009:notes:7]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (279 | ) |  | $ | 108 |  |  | $ | 2,560 |  |  | $ | (74 | ) |  | $ | 2,315 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (113 | ) |  | (303 | ) |  | — |  |  | (416 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | (6 | ) |  | — |  |  | (99 | ) |
| Purchases of investments | — |  |  | (11 | ) |  | (46 | ) |  | — |  |  | (57 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 29 |  |  | — |  |  | 29 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (621 | ) |  | — |  |  | (621 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 112 |  |  | — |  |  | 112 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | 20 |  |  | — |  |  | 19 |  |
| Intercompany loan from consolidated affiliates | 1,395 |  |  | — |  |  | — |  |  | (1,395 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | 65 |  |  | (65 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 1,460 |  |  | (283 | ) |  | (789 | ) |  | (1,395 | ) |  | (1,007 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 99 |  |  | — |  |  | — |  |  | — |  |  | 99 |  |
| Taxes paid on vested stock awards under employee stock plans | (67 | ) |  | — |  |  | — |  |  | — |  |  | (67 | ) |
| Dividends paid to shareholders | (295 | ) |  | — |  |  | — |  |  | — |  |  | (295 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt | (4,114 | ) |  | — |  |  | — |  |  | — |  |  | (4,114 | ) |
| Proceeds from debt | 2,963 |  |  | — |  |  | — |  |  | — |  |  | 2,963 |  |
| Debt issuance costs | (5 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (54 | ) |  | (1,341 | ) |  | 1,395 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 214 |  |  | 204 |  |  | (492 | ) |  | 74 |  |  | — |  |
| Net cash provided by (used in) financing activities | (1,177 | ) |  | 150 |  |  | (1,833 | ) |  | 1,469 |  |  | (1,391 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 4 |  |  | (25 | ) |  | (61 | ) |  | — |  |  | (82 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 22 |  |  | $ | 1,187 |  |  | $ | 5,063 |  |  | $ | — |  |  | $ | 6,272 |  |


## srt:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-19-000009:notes:8]
Separate Financial Information of Guarantor Subsidiaries

[0000106040-19-000009:notes:9]
The Company’s senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the credit agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-19-000009:notes:10]
| Condensed Consolidating Statement of Operations |
| For the three months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,392 |  |  | $ | 4,857 |  |  | $ | (4,016 | ) |  | $ | 4,233 |  |
| Cost of revenue | — |  |  | 2,942 |  |  | 4,215 |  |  | (3,968 | ) |  | 3,189 |  |
| Gross profit | — |  |  | 450 |  |  | 642 |  |  | (48 | ) |  | 1,044 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 334 |  |  | 205 |  |  | — |  |  | 539 |  |
| Selling, general and administrative | — |  |  | 214 |  |  | 95 |  |  | — |  |  | 309 |  |
| Intercompany operating expense (income) | — |  |  | (347 | ) |  | 347 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 6 |  |  | 14 |  |  | — |  |  | 20 |  |
| Total operating expenses | — |  |  | 207 |  |  | 661 |  |  | — |  |  | 868 |  |
| Operating income (loss) | — |  |  | 243 |  |  | (19 | ) |  | (48 | ) |  | 176 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | 4 |  |  | 12 |  |  | (3 | ) |  | 15 |  |
| Interest expense | (118 | ) |  | (2 | ) |  | (1 | ) |  | 3 |  |  | (118 | ) |
| Other income (expense), net | — |  |  | (2 | ) |  | 8 |  |  | 2 |  |  | 8 |  |
| Total interest and other income (expense), net | (116 | ) |  | — |  |  | 19 |  |  | 2 |  |  | (95 | ) |
| Income (loss) before taxes | (116 | ) |  | 243 |  |  | — |  |  | (46 | ) |  | 81 |  |
| Equity in earnings from subsidiaries | (468 | ) |  | (133 | ) |  | — |  |  | 601 |  |  | — |  |
| Income tax expense (benefit) | (97 | ) |  | 532 |  |  | 133 |  |  | — |  |  | 568 |  |
| Net loss | $ | (487 | ) |  | $ | (422 | ) |  | $ | (133 | ) |  | $ | 555 |  |  | $ | (487 | ) |

[0000106040-19-000009:notes:11]
| Condensed Consolidating Statement of Operations |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 6,877 |  |  | $ | 9,853 |  |  | $ | (7,469 | ) |  | $ | 9,261 |  |
| Cost of revenue | — |  |  | 5,947 |  |  | 8,039 |  |  | (7,433 | ) |  | 6,553 |  |
| Gross profit | — |  |  | 930 |  |  | 1,814 |  |  | (36 | ) |  | 2,708 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 697 |  |  | 418 |  |  | — |  |  | 1,115 |  |
| Selling, general and administrative | 1 |  |  | 465 |  |  | 199 |  |  | — |  |  | 665 |  |
| Intercompany operating expense (income) | — |  |  | (754 | ) |  | 754 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 38 |  |  | 28 |  |  | — |  |  | 66 |  |
| Total operating expenses | 1 |  |  | 446 |  |  | 1,399 |  |  | — |  |  | 1,846 |  |
| Operating income (loss) | (1 | ) |  | 484 |  |  | 415 |  |  | (36 | ) |  | 862 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 7 |  |  | 24 |  |  | (11 | ) |  | 30 |  |
| Interest expense | (234 | ) |  | (8 | ) |  | (3 | ) |  | 11 |  |  | (234 | ) |
| Other income (expense), net | 1 |  |  | (2 | ) |  | 7 |  |  | — |  |  | 6 |  |
| Total interest and other income (expense), net | (223 | ) |  | (3 | ) |  | 28 |  |  | — |  |  | (198 | ) |
| Income (loss) before taxes | (224 | ) |  | 481 |  |  | 443 |  |  | (36 | ) |  | 664 |  |
| Equity in earnings from subsidiaries | 7 |  |  | 212 |  |  | — |  |  | (219 | ) |  | — |  |
| Income tax expense (benefit) | (241 | ) |  | 650 |  |  | 231 |  |  | — |  |  | 640 |  |
| Net income | $ | 24 |  |  | $ | 43 |  |  | $ | 212 |  |  | $ | (255 | ) |  | $ | 24 |  |

[0000106040-19-000009:notes:12]
| Condensed Consolidating Statement of Operations |
| For the three months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,764 |  |  | $ | 5,173 |  |  | $ | (3,601 | ) |  | $ | 5,336 |  |
| Cost of revenue | — |  |  | 3,256 |  |  | 3,703 |  |  | (3,636 | ) |  | 3,323 |  |
| Gross profit | — |  |  | 508 |  |  | 1,470 |  |  | 35 |  |  | 2,013 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 400 |  |  | 229 |  |  | — |  |  | 629 |  |
| Selling, general and administrative | 1 |  |  | 276 |  |  | 104 |  |  | — |  |  | 381 |  |
| Intercompany operating expense (income) | — |  |  | (430 | ) |  | 430 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 10 |  |  | 38 |  |  | — |  |  | 48 |  |
| Total operating expenses | 1 |  |  | 256 |  |  | 801 |  |  | — |  |  | 1,058 |  |
| Operating income (loss) | (1 | ) |  | 252 |  |  | 669 |  |  | 35 |  |  | 955 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 66 |  |  | 2 |  |  | 12 |  |  | (66 | ) |  | 14 |  |
| Interest expense | (197 | ) |  | (4 | ) |  | (62 | ) |  | 66 |  |  | (197 | ) |
| Other income (expense), net | — |  |  | (4 | ) |  | 6 |  |  | — |  |  | 2 |  |
| Total interest and other expense, net | (131 | ) |  | (6 | ) |  | (44 | ) |  | — |  |  | (181 | ) |
| Income (loss) before taxes | (132 | ) |  | 246 |  |  | 625 |  |  | 35 |  |  | 774 |  |
| Equity in earnings from subsidiaries | (725 | ) |  | 593 |  |  | — |  |  | 132 |  |  | — |  |
| Income tax expense (benefit) | (34 | ) |  | 1,601 |  |  | 30 |  |  | — |  |  | 1,597 |  |
| Net income (loss) | $ | (823 | ) |  | $ | (762 | ) |  | $ | 595 |  |  | $ | 167 |  |  | $ | (823 | ) |

[0000106040-19-000009:notes:13]
| Condensed Consolidating Statement of Operations |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 7,474 |  |  | $ | 10,254 |  |  | $ | (7,211 | ) |  | $ | 10,517 |  |
| Cost of revenue | — |  |  | 6,456 |  |  | 7,350 |  |  | (7,215 | ) |  | 6,591 |  |
| Gross profit | — |  |  | 1,018 |  |  | 2,904 |  |  | 4 |  |  | 3,926 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 781 |  |  | 440 |  |  | — |  |  | 1,221 |  |
| Selling, general and administrative | 3 |  |  | 534 |  |  | 208 |  |  | — |  |  | 745 |  |
| Intercompany operating expense (income) | — |  |  | (830 | ) |  | 830 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 21 |  |  | 79 |  |  | — |  |  | 100 |  |
| Total operating expenses | 3 |  |  | 506 |  |  | 1,557 |  |  | — |  |  | 2,066 |  |
| Operating income (loss) | (3 | ) |  | 512 |  |  | 1,347 |  |  | 4 |  |  | 1,860 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 147 |  |  | 4 |  |  | 26 |  |  | (147 | ) |  | 30 |  |
| Interest expense | (401 | ) |  | (10 | ) |  | (138 | ) |  | 147 |  |  | (402 | ) |
| Other income (expense), net | (8 | ) |  | 7 |  |  | (3 | ) |  | — |  |  | (4 | ) |
| Total interest and other income (expense), net | (262 | ) |  | 1 |  |  | (115 | ) |  | — |  |  | (376 | ) |
| Income (loss) before taxes | (265 | ) |  | 513 |  |  | 1,232 |  |  | 4 |  |  | 1,484 |  |
| Equity in earnings from subsidiaries | 32 |  |  | 1,185 |  |  | — |  |  | (1,217 | ) |  | — |  |
| Income tax expense (benefit) | (91 | ) |  | 1,655 |  |  | 62 |  |  | — |  |  | 1,626 |  |
| Net income (loss) | $ | (142 | ) |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | (1,213 | ) |  | $ | (142 | ) |

[0000106040-19-000009:notes:14]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (487 | ) |  | $ | (422 | ) |  | $ | (133 | ) |  | $ | 555 |  |  | $ | (487 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 31 |  |  | 32 |  |  | 32 |  |  | (64 | ) |  | 31 |  |
| Net unrealized gain, on derivative contracts and available-for-sale securities | 7 |  |  | 30 |  |  | 30 |  |  | (60 | ) |  | 7 |  |
| Total other comprehensive income, before tax | 39 |  |  | 63 |  |  | 63 |  |  | (126 | ) |  | 39 |  |
| Income tax benefit (expense) related to items of other comprehensive income | 3 |  |  | (2 | ) |  | (2 | ) |  | 3 |  |  | 2 |  |
| Other comprehensive income, net of tax | 42 |  |  | 61 |  |  | 61 |  |  | (123 | ) |  | 41 |  |
| Total comprehensive loss | $ | (445 | ) |  | $ | (361 | ) |  | $ | (72 | ) |  | $ | 432 |  |  | $ | (446 | ) |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-19-000009:notes:15]
[same as prior period, unchanged from 0000106040-18-000034:notes:1]

[0000106040-19-000009:notes:16]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 4,013 |  |  | $ | 5,005 |  |
| Short-term available-for-sale securities (included within Other current assets) | 23 |  |  | 23 |  |
| Long-term available-for-sale securities (included within Other non-current assets) | 94 |  |  | 93 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 4,130 |  |  | $ | 5,121 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-19-000009:notes:17]
[same as prior period, unchanged from 0000106040-18-000034:notes:3]

[0000106040-19-000009:notes:18]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Benefit obligations | $ | 261 |  |  | $ | 260 |  |
| Fair value of plan assets | 204 |  |  | 200 |  |
| Unfunded status | $ | 57 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-19-000009:notes:19]
Commitments, Contingencies and Related Parties

[0000106040-19-000009:notes:20]
Flash Ventures

[0000106040-19-000009:notes:21]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-19-000009:notes:22]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 28, 2018 and June 29, 2018:

[0000106040-19-000009:notes:23]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 695 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 418 |  |  | 48 |  |
| Notes receivable, Flash Forward | 607 |  |  | 700 |  |
| Investment in Flash Partners | 193 |  |  | 191 |  |
| Investment in Flash Alliance | 286 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,318 |  |  | $ | 2,105 |  |

[0000106040-19-000009:notes:24]
During the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $1.12 billion and $1.86 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-19-000009:notes:25]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-19-000009:notes:26]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and six months ended December 28, 2018 or December 29, 2017.

[0000106040-19-000009:notes:27]
As of December 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $310 million and $259 million, respectively.

[0000106040-19-000009:notes:28]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-19-000009:notes:29]
|  | December 28, 2018 |
| Notes receivable | $ | 1,720 |  |
| Equity investments | 598 |  |
| Operating lease guarantees | 1,313 |  |
| Inventory and prepayments | 243 |  |
| Maximum estimable loss exposure | $ | 3,874 |  |

[0000106040-19-000009:notes:30]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-19-000009:notes:31]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of reduced demand for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $49 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three months ended December 28, 2018.

[0000106040-19-000009:notes:32]
Off-Balance Sheet Liabilities

[0000106040-19-000009:notes:33]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-19-000009:notes:34]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018.

[0000106040-19-000009:notes:35]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 145 |  |  | $ | 1,313 |  |

[0000106040-19-000009:notes:36]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018:

[0000106040-19-000009:notes:37]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2019 |  | $ | 294 |  |  | $ | 34 |  |  | $ | 328 |  |
| 2020 |  | 294 |  |  | 67 |  |  | 361 |  |
| 2021 |  | 207 |  |  | 121 |  |  | 328 |  |
| 2022 |  | 112 |  |  | 22 |  |  | 134 |  |
| 2023 |  | 49 |  |  | 88 |  |  | 137 |  |
| Thereafter |  | 4 |  |  | 21 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 960 |  |  | $ | 353 |  |  | $ | 1,313 |  |

[0000106040-19-000009:notes:38]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-19-000009:notes:39]
Unis Venture

[0000106040-19-000009:notes:40]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 28, 2018 and December 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of December 28, 2018 or June 29, 2018.

[0000106040-19-000009:notes:41]
Purchase Agreements

[0000106040-19-000009:notes:42]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of December 28, 2018, the Company had the following minimum long-term purchase commitments:

[0000106040-19-000009:notes:43]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining six months of 2019 |  | $ | 34 |  |
| 2020 |  | 193 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 912 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-19-000009:notes:44]
Debt

[0000106040-19-000009:notes:45]
Debt consisted of the following as of December 28, 2018 and June 29, 2018:

[0000106040-19-000009:notes:46]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,928 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,437 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,800 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (186 | ) |  | (203 | ) |
| Subtotal | 10,614 |  |  | 11,172 |  |
| Less current portion of long-term debt | (244 | ) |  | (179 | ) |
| Long-term debt | $ | 10,370 |  |  | $ | 10,993 |  |

[0000106040-19-000009:notes:47]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At December 28, 2018, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

[0000106040-19-000009:notes:48]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement.

[0000106040-19-000009:notes:49]
Pursuant to the Credit Agreement, the Company is required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 4, 2019, 4.00 to 1.00 through the quarter ending October 2, 2020, and 3.75 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00. As of December 28, 2018, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-19-000009:notes:50]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-19-000009:notes:51]
[same as prior period, unchanged from 0000106040-18-000034:notes:35]

[0000106040-19-000009:notes:52]
As of December 28, 2018, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps that were designated as cash flow hedges. The Company did not have any foreign exchange forward contracts with credit-risk-related contingent features. As of December 28, 2018, the amount of existing net gains related to cash flow hedges recorded in AOCI was not material and the majority is expected to be reclassified to earnings over the next twelve months.

[0000106040-19-000009:notes:53]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and six months ended December 28, 2018 and December 29, 2017, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:54]
[same as prior period, unchanged from 0000106040-18-000034:notes:38]

[0000106040-19-000009:notes:55]
[same as prior period, unchanged from 0000106040-18-000034:notes:39]

[0000106040-19-000009:notes:56]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 28, 2018 and June 29, 2018, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000106040-19-000009:notes:57]
[same as prior period, unchanged from 0000106040-18-000034:notes:41]

[0000106040-19-000009:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,060 |  |  | $ | 2,694 |  |  | $ | 4,554 |  |  | $ | 5,304 |  |
| Flash-based | 2,173 |  |  | 2,642 |  |  | 4,707 |  |  | 5,213 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |

[0000106040-19-000009:notes:59]
[same as prior period, unchanged from 0000106040-18-000034:notes:43]


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-19-000009:notes:60]
[same as prior period, unchanged from 0000106040-18-000034:notes:44]

[0000106040-19-000009:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Options | $ | 4 |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | 13 |  |
| Restricted and performance stock units | 70 |  |  | 88 |  |  | 137 |  |  | 171 |  |
| Employee stock purchase plan | 5 |  |  | 5 |  |  | 12 |  |  | 12 |  |
| Subtotal | 79 |  |  | 99 |  |  | 158 |  |  | 196 |  |
| Tax benefit | (14 | ) |  | (10 | ) |  | (25 | ) |  | (34 | ) |
| Total | $ | 65 |  |  | $ | 89 |  |  | $ | 133 |  |  | $ | 162 |  |

[0000106040-19-000009:notes:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 26 |  |
| Research and development | 42 |  |  | 45 |  |  | 81 |  |  | 89 |  |
| Selling, general and administrative | 24 |  |  | 41 |  |  | 53 |  |  | 81 |  |
| Subtotal | 79 |  |  | 99 |  |  | 158 |  |  | 196 |  |
| Tax benefit | (14 | ) |  | (10 | ) |  | (25 | ) |  | (34 | ) |
| Total | $ | 65 |  |  | $ | 89 |  |  | $ | 133 |  |  | $ | 162 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-19-000009:notes:63]
Net Income (Loss) Per Common Share

[0000106040-19-000009:notes:64]
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-19-000009:notes:65]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (487 | ) |  | $ | (823 | ) |  | $ | 24 |  |  | $ | (142 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 290 |  |  | 296 |  |  | 291 |  |  | 295 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | — |  |  | 5 |  |  | — |  |
| Diluted | 290 |  |  | 296 |  |  | 296 |  |  | 295 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (1.68 | ) |  | $ | (2.78 | ) |  | $ | 0.08 |  |  | $ | (0.48 | ) |
| Diluted | $ | (1.68 | ) |  | $ | (2.78 | ) |  | $ | 0.08 |  |  | $ | (0.48 | ) |

[0000106040-19-000009:notes:66]
The Company computes basic income (loss) per common share using net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the six months ended December 28, 2018, the Company excluded 8 million common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For the three months ended December 28, 2018 and the three and six months ended December 29, 2017, the Company reported a net loss, and all outstanding equity awards have been excluded from such periods because including them would be anti-dilutive. See Note 10, Shareholders’ Equity.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-19-000009:notes:67]
[same as prior period, unchanged from 0000106040-18-000034:notes:52]

[0000106040-19-000009:notes:68]
[same as prior period, unchanged from 0000106040-18-000034:notes:53]

[0000106040-19-000009:notes:69]
[same as prior period, unchanged from 0000106040-18-000034:notes:54]

[0000106040-19-000009:notes:70]
[same as prior period, unchanged from 0000106040-18-000034:notes:55]

[0000106040-19-000009:notes:71]
[same as prior period, unchanged from 0000106040-18-000034:notes:56]

[0000106040-19-000009:notes:72]
[same as prior period, unchanged from 0000106040-18-000034:notes:57]

[0000106040-19-000009:notes:73]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 28, 2018 and June 29, 2018, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-19-000009:notes:74]
|  | December 28, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,744 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,744 |  |
| Certificates of deposit | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total cash equivalents | 1,744 |  |  | 3 |  |  | — |  |  | 1,747 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds |  |  |  | 4 |  |  | — |  |  | 4 |  |
| Equity securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Total short-term available-for-sale securities | 1 |  |  | 22 |  |  | — |  |  | 23 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 7 |  |  | — |  |  | — |  |  | 7 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 68 |  |  | — |  |  | 68 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term available-for-sale securities | 7 |  |  | 87 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 29 |  |  | — |  |  | 29 |  |
| Interest rate swap contracts | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Total assets at fair value | $ | 1,752 |  |  | $ | 153 |  |  | $ | — |  |  | $ | 1,905 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| Interest rate swap contract | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 38 |  |  | $ | — |  |  | $ | 38 |  |

[0000106040-19-000009:notes:75]
[same as prior period, unchanged from 0000106040-18-000034:notes:60]

[0000106040-19-000009:notes:76]
During the three and six months ended December 28, 2018, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-19-000009:notes:77]
[same as prior period, unchanged from 0000106040-18-000034:notes:62]

[0000106040-19-000009:notes:78]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of December 28, 2018 and June 29, 2018.

[0000106040-19-000009:notes:79]
[same as prior period, unchanged from 0000106040-18-000034:notes:64]

[0000106040-19-000009:notes:80]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity securities of these privately-held companies do not have a RDFV. Under ASU 2016-01, these equity securities are now measured and recorded using the measurement alternative, which is cost minus impairment, if any, plus or minus changes resulting from qualifying observable price changes. In addition, the existing impairment model has been replaced with a new one-step qualitative impairment model. Adjustments resulting from impairments and qualifying observable price changes are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. As of December 28, 2018 and June 30, 2018, these investments were not material.

[0000106040-19-000009:notes:81]
[same as prior period, unchanged from 0000106040-18-000034:notes:66]

[0000106040-19-000009:notes:82]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2019 and the fourth quarter of 2018, respectively.

[0000106040-19-000009:notes:83]
|  | December 28, 2018 |  | June 29, 2018 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 32 |  |  | $ | 34 |  |  | $ | 31 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,920 |  |  | 4,722 |  |  | 4,982 |  |  | 5,013 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,436 |  |  | 2,333 |  |  | 2,448 |  |  | 2,452 |  |
| 1.50% convertible notes due 2024 | 944 |  |  | 888 |  |  | 931 |  |  | 1,114 |  |
| 4.750% senior unsecured notes due 2026 | 2,282 |  |  | 1,994 |  |  | 2,280 |  |  | 2,238 |  |
| Total | $ | 10,614 |  |  | $ | 9,971 |  |  | $ | 10,672 |  |  | $ | 10,851 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-19-000009:notes:84]
[same as prior period, unchanged from 0000106040-18-000034:notes:69]

[0000106040-19-000009:notes:85]
[same as prior period, unchanged from 0000106040-18-000034:notes:70]

[0000106040-19-000009:notes:86]
When initially accounting for the tax effects of the enactment of the 2017 Act, the Company applied the applicable SEC guidance and made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. As the Company finalized the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, the Company reflected adjustments to the recorded provisional amounts. As of December 28, 2018, the Company completed its accounting for the tax effects of the enactment of the 2017 Act. Although the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, the Company anticipates the issuance of additional regulatory and interpretive guidance. Although the Company was able to apply a reasonable interpretation of the law along with any available guidance in finalizing its accounting for the tax effects of the 2017 Act, such additional regulatory or interpretive guidance would constitute new information which may require further refinements to its estimates in future periods.

[0000106040-19-000009:notes:87]
Additional information regarding the significant provisions of the 2017 Act that impacted the Company is provided below.

[0000106040-19-000009:notes:88]
[same as prior period, unchanged from 0000106040-18-000034:notes:73]

[0000106040-19-000009:notes:89]
The Company recorded a provisional income tax benefit of $65 million for the year ended June 29, 2018, which related to the re-measurements of the Company’s deferred tax balances and is based primarily on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. The Company has now finalized the accounting for the tax effects related to the re-measurements of the Company’s deferred tax balances with no material change for the six months ended December 28, 2018. The Company has not yet finalized the filing of its U.S. federal income tax return for the year ended June 29, 2018, which may affect the re-measurement of the Company’s deferred tax balances.

[0000106040-19-000009:notes:90]
[same as prior period, unchanged from 0000106040-18-000034:notes:75]

[0000106040-19-000009:notes:91]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. For the year ended June 29, 2018, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.57 billion for foreign subsidiaries. The calculation of the mandatory deemed repatriation tax liability is based upon post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on the amount of foreign earnings held in cash and other specified assets, which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period.

[0000106040-19-000009:notes:92]
As of December 28, 2018, the Company has finalized the accounting for the tax effects of the mandatory deemed repatriation tax during the one-year measurement period permitted by applicable SEC guidance. During the three months ended September 28, 2018, the Company reduced its mandatory deemed repatriation tax liability by $302 million, of which $250 million was for the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets is a reclassification that did not have an impact on the Company’s income tax provision for the three months ended September 28, 2018. The remaining $52 million reduction to the mandatory deemed repatriation tax primarily relates to the Company’s decision to no longer carry forward its 2018 operating loss and, instead, apply it against the mandatory deemed repatriation tax. The $52 million benefit results from utilizing the existing fiscal year 2018 operating losses at a 28% tax rate on the Company’s 2018 tax return as compared to the carryforward tax rate of 21%.

[0000106040-19-000009:notes:93]
During the three months ended December 28, 2018, the Company also finalized its post-1986 earnings and profits along with the amount of earnings held in cash and other specified assets and increased its mandatory deemed repatriation tax liability by $95 million. The Company’s estimate of the mandatory deemed repatriation tax liability after these refinements is $1.36 billion, excluding a $135 million increase in its liability for unrecognized tax benefits.

[0000106040-19-000009:notes:94]
On January 15, 2019, the IRS issued final regulations with respect to the mandatory deemed repatriation tax liability. The Company believes this guidance constitutes a subsequent event and will account for the impact of these regulations in the period in which they were issued. These regulations may impact certain positions previously taken with respect to amounts recorded in the Company’s Consolidated Financial Statements. The Company may adjust such amounts to reflect the final regulations in its Condensed Consolidated Financial Statements for the period ending March 28, 2019.

[0000106040-19-000009:notes:95]
During the one-year measurement period, the Company evaluated the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This required the Company to re-evaluate its existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax of repatriating cash to the U.S. The provisional tax expense recorded by the Company as of June 28, 2018 was based upon an assumption that all of its foreign undistributed earnings are indefinitely reinvested.

[0000106040-19-000009:notes:96]
As of December 28, 2018, the Company finalized the accounting for the tax effects of the mandatory deemed repatriation tax on its indefinite reinvestment assertion. The Company now intends to repatriate all of its foreign undistributed earnings. Accordingly, during the six months ended December 28, 2018, the Company recorded a foreign income tax expense of $242 million related to foreign withholding taxes partially offset by foreign tax credits of $82 million. In addition, a state income tax expense of $54 million was recorded, partially offset by a decrease to the Company’s valuation allowance of $45 million. Amounts related to federal taxes other than the repatriation tax were not material. The Company’s decision to change its indefinite reinvestment assertion is based on interpretative guidance issued by the IRS to date related to the ordering and the taxation of a repatriation of the Company’s foreign undistributed earnings.

[0000106040-19-000009:notes:97]
[same as prior period, unchanged from 0000106040-18-000034:notes:78]

[0000106040-19-000009:notes:98]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision is effective for tax years beginning on or after January 1, 2018, which for the Company is the fiscal year that began on June 30, 2018 (fiscal year 2019). During the one-year measurement period permitted by applicable SEC guidance, the Company evaluated its accounting policy regarding whether to make an election to account for the effects of this provision either as a component of future income tax expense in the period in which the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities were established for timing differences between foreign U.S. GAAP income and U.S. taxable income that would be expected to reverse under the new minimum tax in future years for the year ended June 28, 2018.

[0000106040-19-000009:notes:99]
After further consideration during the six months ended December 28, 2018, the Company has made the election to account for the effects of the global intangible low-tax income provision as a component of future income tax expense in the period in which the tax arises. As the Company had previously accounted for the tax as a period cost in its income tax provision for the three months ended September 28, 2018, there was no change in the Company’s accounting as a result of this election.

[0000106040-19-000009:notes:100]
The following table presents the Company’s income tax expense and the effective tax rate, which includes the discrete effects of the finalization of the accounting for the tax effects of the enactment of the 2017 Act as discussed above:

[0000106040-19-000009:notes:101]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Income before taxes | $ | 81 |  |  | $ | 774 |  |  | $ | 664 |  |  | $ | 1,484 |  |
| Income tax expense | $ | 568 |  |  | $ | 1,597 |  |  | $ | 640 |  |  | $ | 1,626 |  |
| Effective tax rate | 701 | % |  | 206 | % |  | 96 | % |  | 110 | % |

[0000106040-19-000009:notes:102]
The primary driver of the difference between the effective tax rate for the three and six months ended December 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended December 28, 2018, these discrete effects consist of $230 million related to the mandatory deemed repatriation tax and $134 million related to the Company’s decision to change its indefinite reinvestment assertion. For the six months ended December 28, 2018, these discrete effects consist of $178 million related to the mandatory deemed repatriation tax and $144 million related to the Company’s decision to change its indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to the changes in the relative mix of our U.S. earnings compared to foreign earnings.

[0000106040-19-000009:notes:103]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act. Excluding these items, the effective tax rate for the three and six months ended December 29, 2017 would be approximately 4%. The primary drivers for the remaining difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are tax credits generated for 2017, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires the Company to now recognize $5 million and $27 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of its income tax expense for the three and six months ended December 29, 2017, respectively.

[0000106040-19-000009:notes:104]
During the six months ended December 28, 2018, the Company recorded an increase of $139 million in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of December 28, 2018, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $690 million. Accrued interest and penalties related to unrecognized tax benefits as of December 28, 2018 was $116 million.

[0000106040-19-000009:notes:105]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest. Approximately $535 million of the total additional federal tax relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes.  The Company plans to file a petition with the U.S. Tax Court by March 2019. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-19-000009:notes:106]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 28, 2018, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-19-000009:notes:107]
Legal Proceedings

[0000106040-19-000009:notes:108]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-19-000009:notes:109]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-19-000009:notes:110]
Intellectual Property Litigation

[0000106040-19-000009:notes:111]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-19-000009:notes:112]
Antitrust

[0000106040-19-000009:notes:113]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. In December 2018, the remaining three plaintiffs stipulated to dismiss their claims against the defendants.

[0000106040-19-000009:notes:114]
Securities

[0000106040-19-000009:notes:115]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015.  The Company believes the allegations to be without merit and intends to defend itself vigorously in this matter.

[0000106040-19-000009:notes:116]
Copyright

[0000106040-19-000009:notes:117]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts.

[0000106040-19-000009:notes:118]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013.

[0000106040-19-000009:notes:119]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, all court proceedings have been terminated. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.

[0000106040-19-000009:notes:120]
Tax

[0000106040-19-000009:notes:121]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.

[0000106040-19-000009:notes:122]
Other Matters

[0000106040-19-000009:notes:123]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-19-000009:notes:124]
Recent Accounting Pronouncements

[0000106040-19-000009:notes:125]
Accounting Pronouncements Recently Adopted

[0000106040-19-000009:notes:126]
On August 29, 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2018-15, “Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” (“ASU 2018-15”), to reduce diversity in practice in accounting for the costs of implementing cloud computing arrangements that are service contracts.  ASU 2018-15 allows entities to apply the guidance in the FASB Accounting Standards Codification (“ASC”) 350-40 to determine which implementation costs are eligible to be capitalized as assets in a cloud computing arrangement that is considered a service contract. The Company adopted this standard on a prospective basis effective June 30, 2018, the beginning of fiscal year 2019, as allowed by the standard. The adoption of this standard and the costs capitalized for the six months ended December 28, 2018 were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:127]
In February 2018, the FASB issued ASU No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act enacted on December 22, 2017 (the “2017 Act”). Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. Because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. For tax effects that are unrelated to the 2017 Act, the Company’s policy to release these from Accumulated other comprehensive loss on an individual item basis rather than a portfolio basis remains unchanged. The Company early adopted this standard effective June 30, 2018 and elected to reclassify stranded tax effects resulting from the 2017 Act from Accumulated other comprehensive loss to Retained earnings. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:128]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness with the entire change in fair value of designated hedge reported in the results of operations in the same line item as the hedged item. The Company early adopted this standard effective June 30, 2018, using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:129]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. The Company adopted this standard on a prospective basis effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:130]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that the Company report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are now presented in Other income (expense), net in the Condensed Consolidated Statements of Operations. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:131]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business.” This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective June 30, 2018, and will apply it prospectively to transactions occurring thereafter. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:132]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:133]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. Marketable equity securities previously classified as available-for-sale equity investments are now measured and recorded at fair value with changes in fair value recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations rather than as a component of Other comprehensive income as in prior years. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000009:notes:134]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which superseded the requirements in ASC 605 “Revenue Recognition” (Topic 605). Topic 606 outlines a comprehensive five-step revenue recognition model based on the principle that an entity should recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. Topic 606 also requires more detailed disclosures to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted Topic 606 effective June 30, 2018, using the modified retrospective method to all contracts that were not completed contracts as of the beginning of the fiscal year. Results for reporting periods beginning with fiscal year 2019 are presented under Topic 606, while prior period information presented on the financial statements or elsewhere in this Quarterly Report on Form 10-Q is reported under the Company’s historic accounting policies under Topic 605 in effect for that period and is not adjusted to reflect the retrospective effect of the adoption of Topic 606. The cumulative effect of adopting Topic 606 was a post-tax increase to the opening retained earnings of $56 million as of June 30, 2018, which was primarily related to our license and royalty revenue arrangements. These arrangements had no remaining performance obligations but were previously recognized under Topic 605 when they were reported to the Company by its licensees, which was generally one quarter in arrears from the licensees’ sales of the licensed products. Adoption of the standard did not have a material impact on the Company’s financial position, results of operations, and cash flows, as of or for the three and six months ended December 28, 2018, and the Company expects that the impact of the adoption of the new standard will not be material to its results of operations prospectively. See Note 3, Revenues, for additional disclosures related to this standard.

[0000106040-19-000009:notes:135]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-19-000009:notes:136]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. For public entities who have adopted ASU 2017-12, the amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, which for the Company is the first quarter of fiscal 2020. The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-19-000009:notes:137]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-19-000009:notes:138]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted. The Company’s cross-functional project management team continues to identify and evaluate the impact of the amended guidance on the Company's Consolidated Financial Statements and related disclosures, business processes, internal controls, and information systems. The Company has identified its leases and selected a third-party lease accounting software solution. The Company is in the process of implementing its lease accounting software solution and changes to its processes and internal controls to address the new lease standard. The Company’s implementation efforts are progressing as planned. The Company expects to adopt this standard in the first quarter of fiscal 2020 and elect the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company continues to evaluate the impact ASU 2016-02 will have on its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-19-000009:notes:139]
[same as prior period, unchanged from 0000106040-18-000034:notes:118]

[0000106040-19-000009:notes:140]
[same as prior period, unchanged from 0000106040-18-000034:notes:119]

[0000106040-19-000009:notes:141]
[same as prior period, unchanged from 0000106040-18-000034:notes:120]

[0000106040-19-000009:notes:142]
[same as prior period, unchanged from 0000106040-18-000034:notes:121]

[0000106040-19-000009:notes:143]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-19-000009:notes:144]
[same as prior period, unchanged from 0000106040-18-000034:notes:123]

[0000106040-19-000009:notes:145]
[same as prior period, unchanged from 0000106040-18-000034:notes:124]


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-19-000009:notes:146]
[same as prior period, unchanged from 0000106040-18-000034:notes:125]

[0000106040-19-000009:notes:147]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 1,018 |  |  | $ | 1,315 |  |
| Other non-current liabilities | 1,289 |  |  | 940 |  |
| Total other non-current liabilities | $ | 2,307 |  |  | $ | 2,255 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-19-000009:notes:148]
[same as prior period, unchanged from 0000106040-18-000034:notes:127]

[0000106040-19-000009:notes:149]
[same as prior period, unchanged from 0000106040-18-000034:notes:128]

[0000106040-19-000009:notes:150]
[same as prior period, unchanged from 0000106040-18-000034:notes:129]

[0000106040-19-000009:notes:151]
[same as prior period, unchanged from 0000106040-18-000034:notes:130]

[0000106040-19-000009:notes:152]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 56 |  |  | 59 |  |
| Net amount recognized | $ | 57 |  |  | $ | 60 |  |

[0000106040-19-000009:notes:153]
Net periodic benefit costs were not material for the three and six months ended December 28, 2018.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-19-000009:notes:154]
[same as prior period, unchanged from 0000106040-18-000034:notes:132]

[0000106040-19-000009:notes:155]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land | $ | 307 |  |  | $ | 306 |  |
| Buildings and improvements | 1,975 |  |  | 1,949 |  |
| Machinery and equipment | 7,493 |  |  | 7,209 |  |
| Computer equipment and software | 450 |  |  | 440 |  |
| Furniture and fixtures | 54 |  |  | 48 |  |
| Construction-in-process | 238 |  |  | 234 |  |
| Property, plant and equipment, gross | 10,517 |  |  | 10,186 |  |
| Accumulated depreciation | (7,440 | ) |  | (7,091 | ) |
| Property, plant, and equipment, net | $ | 3,077 |  |  | $ | 3,095 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-19-000009:notes:156]
reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Condensed Consolidated Statements of Operations


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-19-000009:notes:157]
[same as prior period, unchanged from 0000106040-18-000034:notes:135]

[0000106040-19-000009:notes:158]
[same as prior period, unchanged from 0000106040-18-000034:notes:136]

[0000106040-19-000009:notes:159]
[same as prior period, unchanged from 0000106040-18-000034:notes:137]

[0000106040-19-000009:notes:160]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-19-000009:notes:161]
[same as prior period, unchanged from 0000106040-18-000034:notes:139]

[0000106040-19-000009:notes:162]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company believes the estimate of variable consideration is not constrained and that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics. The Company’s methodology for the estimates is based on several factors, including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are typically recorded as a reduction of the transaction price and, therefore, of revenue.

[0000106040-19-000009:notes:163]
An immaterial amount of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

[0000106040-19-000009:notes:164]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 28, 2018 or the date of adoption of Topic 606.

[0000106040-19-000009:notes:165]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and six months ended December 28, 2018 were not material.

[0000106040-19-000009:notes:166]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 28, 2018 and the date of adoption of Topic 606, contract liabilities were $53 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the six months ended December 28, 2018 include $80 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

[0000106040-19-000009:notes:167]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 28, 2018 was $220 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $40 million during the remainder of fiscal 2019, $60 million in fiscal 2020, $46 million in fiscal 2021 and $74 million thereafter.

[0000106040-19-000009:notes:168]
The Company’s top 10 customers accounted for 47% of its net revenue for both the three and six months ended December 28, 2018, and 42% and 41% of its net revenue for the three and six months ended December 29, 2017, respectively. For the three and six months ended December 28, 2018 and December 29, 2017, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-19-000009:notes:169]
[same as prior period, unchanged from 0000106040-18-000034:notes:147]

[0000106040-19-000009:notes:170]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 29, 2018 | $ | (19 | ) |  | $ | (21 | ) |  | $ | 1 |  |  | $ | (39 | ) |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | (6 | ) |  | (5 | ) |  | (10 | ) |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | 11 |  |  | 11 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | (1 | ) |  | 4 |  |  | 3 |  |
| Net current-period other comprehensive loss | 1 |  |  | (7 | ) |  | 10 |  |  | 4 |  |
| Balance at December 28, 2018 | $ | (18 | ) |  | $ | (28 | ) |  | $ | 11 |  |  | $ | (35 | ) |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-19-000009:notes:171]
[same as prior period, unchanged from 0000106040-18-000034:notes:157]

[0000106040-19-000009:notes:172]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,816 |  |  | $ | 5,818 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (3,748 | ) |  | (3,218 | ) |
| Intangible assets, net | $ | 2,148 |  |  | $ | 2,680 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-19-000009:notes:173]
[same as prior period, unchanged from 0000106040-18-000034:notes:159]

[0000106040-19-000009:notes:174]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 29, 2018 | $ | 10,075 |  |
| Foreign currency translation adjustment | (1 | ) |
| Balance at December 28, 2018 | $ | 10,074 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-19-000009:notes:175]
[same as prior period, unchanged from 0000106040-18-000034:notes:161]

[0000106040-19-000009:notes:176]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,191 |  |  | $ | 1,048 |  |
| Work-in-process | 864 |  |  | 878 |  |
| Finished goods | 1,372 |  |  | 1,018 |  |
| Total inventories | $ | 3,427 |  |  | $ | 2,944 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-19-000009:notes:177]
[same as prior period, unchanged from 0000106040-18-000034:notes:163]

[0000106040-19-000009:notes:178]
[same as prior period, unchanged from 0000106040-18-000034:notes:164]

[0000106040-19-000009:notes:179]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 323 |  |  | $ | 302 |  |  | $ | 318 |  |  | $ | 311 |  |
| Charges to operations | 47 |  |  | 46 |  |  | 81 |  |  | 90 |  |
| Utilization | (42 | ) |  | (43 | ) |  | (68 | ) |  | (81 | ) |
| Changes in estimate related to pre-existing warranties | 9 |  |  | (1 | ) |  | 6 |  |  | (16 | ) |
| Warranty accrual, end of period | $ | 337 |  |  | $ | 304 |  |  | $ | 337 |  |  | $ | 304 |  |

[0000106040-19-000009:notes:180]
[same as prior period, unchanged from 0000106040-18-000034:notes:166]

[0000106040-19-000009:notes:181]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion | $ | 183 |  |  | $ | 168 |  |
| Long-term portion | 154 |  |  | 150 |  |
| Total warranty accrual | $ | 337 |  |  | $ | 318 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-19-000009:notes:182]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the six months ended December 28, 2018:

[0000106040-19-000009:notes:183]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 56 |  |  | $ | — |  |  | $ | 56 |  |
| Charges | 3 |  |  | 8 |  |  | 11 |  |
| Cash payments | — |  |  | (5 | ) |  | (5 | ) |
| Accrual balance at December 28, 2018 | $ | 59 |  |  | $ | 3 |  |  | $ | 62 |  |

[0000106040-19-000009:notes:184]
The following table presents an analysis of the components of the activity against the reserve during the six months ended December 28, 2018:

[0000106040-19-000009:notes:185]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 36 |  |  | $ | 7 |  |  | $ | 43 |  |
| Charges | 46 |  |  | 9 |  |  | 55 |  |
| Cash payments | (35 | ) |  | (5 | ) |  | (40 | ) |
| Accrual balance at December 28, 2018 | $ | 47 |  |  | $ | 11 |  |  | $ | 58 |  |

[0000106040-19-000009:notes:186]
[same as prior period, unchanged from 0000106040-18-000034:notes:168]

[0000106040-19-000009:notes:187]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | — |  |  | $ | 32 |  |  | $ | — |  |  | $ | 77 |  |
| Closure of Foreign Manufacturing Facilities | 7 |  |  | — |  |  | 11 |  |  | — |  |
| Business Realignment | 13 |  |  | 16 |  |  | 55 |  |  | 23 |  |
| Total employee termination and other charges | $ | 20 |  |  | $ | 48 |  |  | $ | 66 |  |  | $ | 100 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-19-000009:notes:188]
[same as prior period, unchanged from 0000106040-18-000034:notes:174]

[0000106040-19-000009:notes:189]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 29, 2018 | 4.8 |  |  | $ | 64.23 |  |  |  |  |  |
| Exercised | (0.2 | ) |  | 37.64 |  |  |  |  | $ | — |  |
| Canceled or expired | (0.3 | ) |  | 79.73 |  |  |  |  |  |
| Options outstanding at December 28, 2018 | 4.3 |  |  | $ | 64.73 |  |  | 3.3 |  | $ | 1 |  |
| Exercisable at December 28, 2018 | 3.1 |  |  | $ | 69.86 |  |  | 2.9 |  | $ | 1 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-19-000009:notes:190]
[same as prior period, unchanged from 0000106040-18-000034:notes:176]

[0000106040-19-000009:notes:191]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | $ | 58.31 |  |  |  |
| Granted | 6.6 |  |  | 59.42 |  |  |  |
| Vested | (3.1 | ) |  | 61.96 |  |  | $ | 211 |  |
| Forfeited | (0.7 | ) |  | 56.05 |  |  |  |
| RSUs and PSUs outstanding at December 28, 2018 | 15.4 |  |  | $ | 59.51 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-19-000009:notes:192]
[same as prior period, unchanged from 0000106040-18-000034:notes:178]

[0000106040-19-000009:notes:193]
[same as prior period, unchanged from 0000106040-18-000034:notes:179]

[0000106040-19-000009:notes:194]
Compensation cost related to unvested stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 28, 2018:

[0000106040-19-000009:notes:195]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 15 |  |  | 1.4 |
| RSUs and PSUs (1) | 657 |  |  | 2.5 |
| ESPP | 71 |  |  | 1.9 |
| Total unamortized compensation cost | $ | 743 |  |  |  |

[0000106040-19-000009:notes:196]
[same as prior period, unchanged from 0000106040-18-000034:notes:182]

[0000106040-19-000009:notes:197]
[same as prior period, unchanged from 0000106040-18-000034:notes:183]

[0000106040-19-000009:notes:198]
[same as prior period, unchanged from 0000106040-18-000034:notes:184]

[0000106040-19-000009:notes:199]
[same as prior period, unchanged from 0000106040-18-000034:notes:185]

[0000106040-19-000009:notes:200]
[same as prior period, unchanged from 0000106040-18-000034:notes:186]

[0000106040-19-000009:notes:201]
[same as prior period, unchanged from 0000106040-18-000034:notes:187]

[0000106040-19-000009:notes:202]
The Company’s Board of Directors previously authorized $5.00 billion for the repurchase of the Company’s common stock. On July 25, 2018, the Company’s Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. For the three months ended December 28, 2018, the Company did not make any stock repurchases. For the six months ended December 28, 2018, the Company repurchased 0.8 million shares for a total cost of $61 million under the previous authorization and 7.6 million shares for a total cost of $502 million under the new authorization. Therefore, the Company’s stock repurchases under all stock repurchase authorizations in effect for the six months ended December 28, 2018 totaled $563 million. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of December 28, 2018 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000009:notes:203]
[same as prior period, unchanged from 0000106040-18-000034:notes:189]

[0000106040-19-000009:notes:204]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the six months ended December 28, 2018, the Company declared aggregate cash dividends of $1.00 per share on its outstanding common stock totaling $290 million, of which $146 million was paid on January 14, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-19-000009:notes:205]
[same as prior period, unchanged from 0000106040-18-000034:notes:191]

[0000106040-19-000009:notes:206]
[same as prior period, unchanged from 0000106040-18-000034:notes:192]

[0000106040-19-000009:notes:207]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the six months ended December 28, 2018, the Company sold trade accounts receivable and received cash proceeds of $370 million. The discounts on the trade accounts receivable sold during the period were not material and were recorded within Other income (expense), net in the Condensed Consolidated Financial Statements. During the six months ended December 29, 2017, the Company did not sell any trade accounts receivable.

[0000106040-19-000009:notes:208]
The Company tests for impairment, at a minimum, on an annual basis or earlier where certain events or changes in circumstances indicate that goodwill may more-likely-than-not be impaired. The Company has experienced declines in the market price of its stock, resulting in the Company’s market capitalization decreasing below book value for the last seven trading days of the second quarter of fiscal 2019. The Company’s market capitalization based upon its stock price has fluctuated above and below book value subsequent to the end of the quarter. The fair value of the Company using a market capitalization approach based on the Company’s share price would include a control premium based on recent transactions that have occurred in the technology industry. This indicative fair value exceeded the Company’s book value; therefore, management does not believe it is more likely than not that goodwill was impaired as of December 28, 2018.

[0000106040-19-000009:notes:209]
If there are further decreases in the Company’s stock price for a sustained period or other unfavorable factors, the Company may be required to perform a goodwill impairment assessment, which may result in a recognition of goodwill impairment that could be material to the Consolidated Financial Statements.

[0000106040-19-000009:notes:210]
[same as prior period, unchanged from 0000106040-18-000034:notes:194]

[0000106040-19-000009:notes:211]
[same as prior period, unchanged from 0000106040-18-000034:notes:195]

[0000106040-19-000009:notes:212]
[same as prior period, unchanged from 0000106040-18-000034:notes:196]

[0000106040-19-000009:notes:213]
During the three and six months ended December 28, 2018 and December 29, 2017, the amounts reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-19-000009:notes:214]
[same as prior period, unchanged from 0000106040-18-000034:notes:198]

[0000106040-19-000009:notes:215]
[same as prior period, unchanged from 0000106040-18-000034:notes:199]

[0000106040-19-000009:notes:216]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company now currently expects the closure to be substantially completed by the fourth quarter of fiscal 2019 and to result in total pre-tax charges of approximately $110 million. These charges are expected to consist of approximately $70 million in employee termination benefits and $40 million in asset-related, contract termination and other charges, of which $56 million were recognized in the year ended June 29, 2018. During the six months ended December 28, 2018, the Company recognized an additional $3 million in employee termination benefits and $8 million in asset-related, contract termination and other charges.

[0000106040-19-000009:notes:217]
[same as prior period, unchanged from 0000106040-18-000034:notes:201]

[0000106040-19-000009:notes:218]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the six months ended December 28, 2018:
