# WDC MD&A — 0001628280-15-004065


## mdna

[0001628280-15-004065:mdna:1]
[same as prior period, unchanged from 0000106040-15-000003:mdna:1]

[0001628280-15-004065:mdna:2]
[same as prior period, unchanged from 0000106040-15-000003:mdna:2]

[0001628280-15-004065:mdna:3]
[same as prior period, unchanged from 0000106040-15-000003:mdna:3]

[0001628280-15-004065:mdna:4]
[same as prior period, unchanged from 0000106040-15-000003:mdna:4]

[0001628280-15-004065:mdna:5]
| • | expectations regarding industry demand and shipments in the quarter ending July 3, 2015 and the expected impact on our revenue; |

[0001628280-15-004065:mdna:6]
[same as prior period, unchanged from 0000106040-15-000003:mdna:6]

[0001628280-15-004065:mdna:7]
[same as prior period, unchanged from 0000106040-15-000003:mdna:7]

[0001628280-15-004065:mdna:8]
[same as prior period, unchanged from 0000106040-15-000003:mdna:8]

[0001628280-15-004065:mdna:9]
[same as prior period, unchanged from 0000106040-15-000003:mdna:9]

[0001628280-15-004065:mdna:10]
[same as prior period, unchanged from 0000106040-15-000003:mdna:10]

[0001628280-15-004065:mdna:11]
22

[0001628280-15-004065:mdna:12]
[same as prior period, unchanged from 0000106040-15-000003:mdna:11]

[0001628280-15-004065:mdna:13]
[same as prior period, unchanged from 0000106040-15-000003:mdna:12]

[0001628280-15-004065:mdna:14]
[same as prior period, unchanged from 0000106040-15-000003:mdna:13]

[0001628280-15-004065:mdna:15]
[same as prior period, unchanged from 0000106040-15-000003:mdna:14]

[0001628280-15-004065:mdna:16]
[same as prior period, unchanged from 0000106040-15-000003:mdna:15]

[0001628280-15-004065:mdna:17]
[same as prior period, unchanged from 0000106040-15-000003:mdna:16]

[0001628280-15-004065:mdna:18]
[same as prior period, unchanged from 0000106040-15-000003:mdna:17]

[0001628280-15-004065:mdna:19]
[same as prior period, unchanged from 0000106040-15-000003:mdna:18]

[0001628280-15-004065:mdna:20]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0001628280-15-004065:mdna:21]
[same as prior period, unchanged from 0000106040-15-000003:mdna:20]

[0001628280-15-004065:mdna:22]
[same as prior period, unchanged from 0000106040-15-000003:mdna:21]

[0001628280-15-004065:mdna:23]
[same as prior period, unchanged from 0000106040-15-000003:mdna:22]

[0001628280-15-004065:mdna:24]
[same as prior period, unchanged from 0000106040-15-000003:mdna:24]

[0001628280-15-004065:mdna:25]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes hard disk drives (“HDDs”) and SSDs, direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.  We currently operate our global business through two independent subsidiaries due to regulatory requirements - HGST and WD.

[0001628280-15-004065:mdna:26]
Third Quarter Overview

[0001628280-15-004065:mdna:27]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), we include the operating results for acquired companies commencing after their respective acquisition dates. Accordingly, Amplidata, Virident and sTec have been included in our results of operations since their acquisition dates of March 9, 2015, October 17, 2013, and September 12, 2013, respectively.

[0001628280-15-004065:mdna:28]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal third quarters ended April 3, 2015 and March 28, 2014 both consisted of 13 weeks. Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0001628280-15-004065:mdna:29]
For the quarter ended April 3, 2015, we believe that overall hard drive industry shipments totaled approximately 125 million units, down 9% from the prior-year period and down 11% from the second fiscal quarter. These decreases are the result of a softer demand environment largely driven by weak macroeconomic conditions.

[0001628280-15-004065:mdna:30]
[same as prior period, unchanged from 0000106040-15-000003:mdna:39]

[0001628280-15-004065:mdna:31]
[same as prior period, unchanged from 0000106040-15-000003:mdna:30]

[0001628280-15-004065:mdna:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |
| Net revenue | $ | 3,550 |  |  | 100.0 | % |  | $ | 3,703 |  |  | 100.0 | % |  | $ | 11,381 |  |  | 100.0 | % |  | $ | 11,479 |  |  | 100.0 | % |
| Gross profit | 1,032 |  |  | 29.1 |  |  | 1,076 |  |  | 29.1 |  |  | 3,291 |  |  | 28.9 |  |  | 3,331 |  |  | 29.0 |  |
| Total operating expenses | 611 |  |  | 17.2 |  |  | 657 |  |  | 17.7 |  |  | 1,935 |  |  | 17.0 |  |  | 1,892 |  |  | 16.5 |  |
| Operating income | 421 |  |  | 11.9 |  |  | 419 |  |  | 11.3 |  |  | 1,356 |  |  | 11.9 |  |  | 1,439 |  |  | 12.5 |  |
| Net income | 384 |  |  | 10.8 |  |  | 375 |  |  | 10.1 |  |  | 1,245 |  |  | 10.9 |  |  | 1,300 |  |  | 11.3 |  |

[0001628280-15-004065:mdna:33]
The following is a summary of our financial performance for the third quarter of fiscal 2015:

[0001628280-15-004065:mdna:34]
| • | Consolidated net revenue totaled $3.5 billion. |

[0001628280-15-004065:mdna:35]
| • | Net revenue derived from enterprise SSDs was $224 million as compared to $134 million in the prior-year period. |

[0001628280-15-004065:mdna:36]
| • | Hard drive unit shipments decreased 10% from the prior-year period to 54.5 million units. |

[0001628280-15-004065:mdna:37]
| • | Gross margin remained flat at 29.1% compared to the prior-year period. |

[0001628280-15-004065:mdna:38]
| • | Operating income was $421 million, an increase of $2 million from the prior-year period. |

[0001628280-15-004065:mdna:39]
| • | We generated $684 million in cash flow from operations and we ended the quarter with $4.8 billion in cash and cash equivalents. |

[0001628280-15-004065:mdna:40]
[same as prior period, unchanged from 0000106040-15-000003:mdna:40]

[0001628280-15-004065:mdna:41]
[same as prior period, unchanged from 0000106040-15-000003:mdna:41]

[0001628280-15-004065:mdna:42]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages andaverage selling price) | April 3, 2015 |  | March 28, 2014 |  | Percentage Change |  | April 3, 2015 |  | March 28, 2014 |  | PercentageChange |
| Net revenue | $ | 3,550 |  |  | $ | 3,703 |  |  | (4 | )% |  | $ | 11,381 |  |  | $ | 11,479 |  |  | (1 | )% |
| Average selling price (per unit)* | $ | 61 |  |  | $ | 58 |  |  | 5 | % |  | $ | 60 |  |  | $ | 59 |  |  | 2 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 25 | % |  |  |  | 27 | % |  | 26 | % |  |  |
| Europe, Middle East and Africa | 21 |  |  | 21 |  |  |  |  | 22 |  |  | 21 |  |  |  |
| Asia | 50 |  |  | 54 |  |  |  |  | 51 |  |  | 53 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEM | 64 | % |  | 62 | % |  |  |  | 64 | % |  | 63 | % |  |  |
| Distributors | 23 |  |  | 25 |  |  |  |  | 23 |  |  | 24 |  |  |  |
| Retailers | 13 |  |  | 13 |  |  |  |  | 13 |  |  | 13 |  |  |  |
| Unit Shipments* |  |  |  |  |  |  |  |  |  |  |  |
| PC | 32.3 |  |  | 38.4 |  |  |  |  | 108.6 |  |  | 118.2 |  |  |  |
| Non-PC | 22.2 |  |  | 22.0 |  |  |  |  | 71.7 |  |  | 68.0 |  |  |  |
| Total units shipped | 54.5 |  |  | 60.4 |  |  | (10 | )% |  | 180.3 |  |  | 186.2 |  |  | (3 | )% |

[0001628280-15-004065:mdna:43]
[same as prior period, unchanged from 0000106040-15-000003:mdna:43]

[0001628280-15-004065:mdna:44]
For the quarter ended April 3, 2015, net revenue was $3.5 billion, a decrease of 4% from the prior-year period. This decrease in revenue was primarily the result of client demand challenges largely driven by weak macroeconomic conditions. Total hard drive shipments decreased to 54.5 million units for the quarter ended April 3, 2015 as compared to 60.4 million units in the prior-year period. For the nine months ended April 3, 2015, net revenue was $11.4 billion, a decrease of 1% from the prior year period. Total hard drive shipments decreased to 180.3 million units for the nine months ended April 3, 2015 as compared to 186.2 million units in the prior-year period. For the quarter ended April 3, 2015, average selling price ("ASP") increased to $61 when

[0001628280-15-004065:mdna:45]
[same as prior period, unchanged from 0000106040-15-000003:mdna:49]

[0001628280-15-004065:mdna:46]
compared with the prior-year period at $58. For the nine months ended April 3, 2015, ASP increased by $1 from the prior-year period, from $59 to $60.

[0001628280-15-004065:mdna:47]
Changes in revenue by geography and channel generally reflect fluctuations in market demand and competitive dynamics. For the three and nine months ended April 3, 2015, Hewlett-Packard Company accounted for approximately 10% and 11% of our net revenue, respectively. For both the three and nine months ended March 28, 2014, Hewlett-Packard Company accounted for approximately 11% of our net revenue.

[0001628280-15-004065:mdna:48]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Generally, total sales incentive and marketing programs range from 7% to 10% of gross revenues per quarter. For both the three and nine months ended April 3, 2015, these programs represented 10% of gross revenues, as compared to 8% in both respective prior-year periods. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.7% of quarterly gross revenue since the first quarter of fiscal 2013.

[0001628280-15-004065:mdna:49]
[same as prior period, unchanged from 0000106040-15-000003:mdna:47]

[0001628280-15-004065:mdna:50]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages) | April 3, 2015 |  | March 28, 2014 |  | Percentage Change |  | April 3, 2015 |  | March 28, 2014 |  | PercentageChange |
| Net revenue | $ | 3,550 |  |  | $ | 3,703 |  |  | (4 | )% |  | $ | 11,381 |  |  | $ | 11,479 |  |  | (1 | )% |
| Gross profit | 1,032 |  |  | 1,076 |  |  | (4 | )% |  | 3,291 |  |  | 3,331 |  |  | (1 | )% |
| Gross margin | 29.1 | % |  | 29.1 | % |  |  |  | 28.9 | % |  | 29.0 | % |  |  |

[0001628280-15-004065:mdna:51]
For the three months ended April 3, 2015, gross margin remained flat with the prior-year period at 29.1%. For the nine months ended April 3, 2015, gross margin decreased to 28.9% as compared to 29.0% for the prior-year period.

[0001628280-15-004065:mdna:52]
[same as prior period, unchanged from 0000106040-15-000003:mdna:51]

[0001628280-15-004065:mdna:53]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages) | April 3, 2015 |  | March 28, 2014 |  | Percentage Change |  | April 3, 2015 |  | March 28, 2014 |  | PercentageChange |
| R&D expense | $ | 402 |  |  | $ | 418 |  |  | (4 | )% |  | $ | 1,265 |  |  | $ | 1,235 |  |  | 2 | % |
| SG&A expense | 199 |  |  | 201 |  |  | (1 | )% |  | 583 |  |  | 559 |  |  | 4 | % |
| Charges related to arbitration award | — |  |  | 13 |  |  | (100 | )% |  | 15 |  |  | 39 |  |  | (62 | )% |
| Employee termination, asset impairment and other charges | 10 |  |  | 25 |  |  | (60 | )% |  | 72 |  |  | 59 |  |  | 22 | % |
| Total operating expenses | $ | 611 |  |  | $ | 657 |  |  |  |  | $ | 1,935 |  |  | $ | 1,892 |  |  |  |

[0001628280-15-004065:mdna:54]
Research and development (“R&D”) expense was $402 million for the three months ended April 3, 2015, a decrease of $16 million from the prior-year period. This decrease was the result of lower incentive compensation and a realignment of our cost structure due to a softer demand environment. For the nine months ended April 3, 2015, R&D expense was $1.3 billion, an increase of $30 million from the prior-year period. This increase was primarily due to additional investment in our enterprise SSD business and the inclusion of a full six month period of Virident and sTec's R&D expenses, as opposed to a partial six month period of such expenses in the comparative prior-year period, and an additional week of operating expenses due to a 14-week quarter in our first fiscal quarter in the current period. As a percentage of net revenue, R&D expense remained flat at 11.3% and increased to 11.1% in the three and nine months ended April 3, 2015, respectively, as compared to 11.3% and 10.8% in the respective prior-year periods.

[0001628280-15-004065:mdna:55]
Selling, general and administrative (“SG&A”) expense was $199 million for the three months ended April 3, 2015, a decrease of $2 million from the prior-year period. This decrease was primarily the result of lower incentive compensation and a realignment of our cost structure due to a softer demand environment. For the nine months ended April 3, 2015, SG&A expense was $583 million, an increase of $24 million from the prior-year period. This increase was primarily due to the inclusion of a full six month period of Virident and sTec's SG&A expenses, as opposed to a partial six month period of such expenses in the comparative prior-year period, and an additional week of operating expenses due to a 14-week quarter in our first fiscal quarter in

[0001628280-15-004065:mdna:56]
[same as prior period, unchanged from 0000106040-15-000003:mdna:61]

[0001628280-15-004065:mdna:57]
the current period. Additionally, this increase is a result of a $37 million flood-related insurance recovery in the current period compared to a $65 million flood-related insurance recovery in the prior-year period. SG&A expense as a percentage of net revenue was 5.6% and 5.1% in the three and nine months ended April 3, 2015, respectively, as compared to 5.4% and 4.9% in the respective prior-year periods.

[0001628280-15-004065:mdna:58]
During the nine months ended April 3, 2015, we recorded $15 million of interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC ("Seagate") as compared to $13 million and $39 million in the three and nine months ended March 28, 2014, respectively. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:59]
During the three and nine months ended April 3, 2015, we recorded employee termination, asset impairment and other charges of $10 million and $72 million, respectively, in order to realign our operations with anticipated market demand, as compared to $25 million and $59 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:60]
[same as prior period, unchanged from 0000106040-15-000003:mdna:57]

[0001628280-15-004065:mdna:61]
Interest income for the three and nine months ended April 3, 2015 decreased $1 million and increased $1 million, respectively, as compared to the prior-year periods primarily due to different average daily invested cash balances for the respective periods. Interest and other expense for the three and nine months ended April 3, 2015 decreased $5 million and $7 million, respectively, when compared to the respective prior-year periods primarily due to interest on a lower debt balance.

[0001628280-15-004065:mdna:62]
[same as prior period, unchanged from 0000106040-15-000003:mdna:59]

[0001628280-15-004065:mdna:63]
Our income tax provision for the three months ended April 3, 2015 was $28 million, as compared to $31 million in the prior-year period. Our income tax provision for the nine months ended April 3, 2015 was $85 million, as compared to $105 million in the prior-year period. Our tax provision for the nine months ended April 3, 2015 reflects a tax benefit of $16 million resulting from the retroactive extension of the U.S. Federal R&D tax credit that was signed into law on December 19, 2014. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:64]
[same as prior period, unchanged from 0000106040-15-000003:mdna:65]

[0001628280-15-004065:mdna:65]
We ended the third quarter of fiscal 2015 with total cash and cash equivalents of $4.8 billion. The following table summarizes our statements of cash flows (in millions):

[0001628280-15-004065:mdna:66]
|  | Nine Months Ended |
|  | April 3, 2015 |  | March 28, 2014 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 1,754 |  |  | $ | 2,104 |  |
| Investing activities | (712 | ) |  | (1,756 | ) |
| Financing activities | (1,034 | ) |  | (88 | ) |
| Net increase in cash and cash equivalents | $ | 8 |  |  | $ | 260 |  |

[0001628280-15-004065:mdna:67]
[same as prior period, unchanged from 0000106040-15-000003:mdna:68]

[0001628280-15-004065:mdna:68]
A total of $3.9 billion and $3.5 billion of our cash and cash equivalents was held outside of the United States as of April 3, 2015 and June 27, 2014, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. As described in Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q, the final arbitration award plus interest accrued of $773.4 million was paid on October 14, 2014 from one of our foreign subsidiaries using cash held outside the United States. On September 13, 2012, our Board of Directors approved a capital allocation plan which includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign

[0001628280-15-004065:mdna:69]
[same as prior period, unchanged from 0000106040-15-000003:mdna:72]

[0001628280-15-004065:mdna:70]
operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0001628280-15-004065:mdna:71]
[same as prior period, unchanged from 0000106040-15-000003:mdna:70]

[0001628280-15-004065:mdna:72]
Net cash provided by operating activities was $1.8 billion during the nine months ended April 3, 2015. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used by working capital changes was $470 million for the nine months ended April 3, 2015 as compared to $189 million used by working capital changes in the prior-year period. The increase in net cash used by operations for the nine months ended April 3, 2015 was primarily due to payment of the final arbitration award plus interest accrued as previously discussed in Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:73]
[same as prior period, unchanged from 0000106040-15-000003:mdna:73]

[0001628280-15-004065:mdna:74]
|  | Three Months Ended |
|  | April 3, 2015 |  | March 28, 2014 |
| Days sales outstanding | 44 |  |  | 44 |  |
| Days in inventory | 48 |  |  | 44 |  |
| Days payables outstanding | (73 | ) |  | (65 | ) |
| Cash conversion cycle | 19 |  |  | 23 |  |

[0001628280-15-004065:mdna:75]
For the three months ended April 3, 2015, our average days sales outstanding (“DSOs”) remained flat, days in inventory (“DIOs”) increased by 4 days, and days payable outstanding (“DPOs”) increased by 8 days compared to the prior year period. Changes in average DSOs and DIOs are generally related to linearity of shipments and the timing of inventory builds, respectively. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0001628280-15-004065:mdna:76]
[same as prior period, unchanged from 0000106040-15-000003:mdna:76]

[0001628280-15-004065:mdna:77]
Cash used in investing activities for the nine months ended April 3, 2015 was $712 million and consisted primarily of $687 million related to the purchase of investments, $456 million of capital expenditures and $247 million related to acquisitions, net of cash acquired, partially offset by $665 million of proceeds from sales and maturities of investments. Cash used in investing activities for the nine months ended March 28, 2014 was $1.8 billion and consisted primarily of $823 million related to acquisitions, net of cash acquired, $470 million of investments in available-for-sale securities, and $467 million of capital expenditures.

[0001628280-15-004065:mdna:78]
[same as prior period, unchanged from 0000106040-15-000003:mdna:78]

[0001628280-15-004065:mdna:79]
Net cash used in financing activities for the nine months ended April 3, 2015 was $1 billion as compared to $88 million used in financing activities in the prior-year period. Net cash used in financing activities for the nine months ended April 3, 2015 consisted primarily of $772 million used to repurchase shares of our common stock, $280 million used to pay dividends on our common stock and $94 million used to make principal payments on the Credit Agreement (as defined below), partially offset by a net $112 million provided by employee stock plans. Net cash used in financing activities for the nine months ended March 28, 2014 consisted of $2.5 billion used to make principal payments and repay the outstanding balance to terminate our previous credit agreement and to make principal payments on the Credit Agreement, $544 million used to repurchase shares of our common stock and $189 million used to pay dividends on our common stock, offset by $2.5 billion of debt proceeds related to the term loan facility under the Credit Agreement, net of issuance costs, $500 million of debt proceeds related to the revolving credit facility under our previous credit agreement and a net $139 million provided by employee stock plans.

[0001628280-15-004065:mdna:80]
[same as prior period, unchanged from 0000106040-15-000003:mdna:80]

[0001628280-15-004065:mdna:81]
[same as prior period, unchanged from 0000106040-15-000003:mdna:81]

[0001628280-15-004065:mdna:82]
[same as prior period, unchanged from 0000106040-15-000003:mdna:85]

[0001628280-15-004065:mdna:83]
[same as prior period, unchanged from 0000106040-15-000003:mdna:82]

[0001628280-15-004065:mdna:84]
Long-Term Debt — On January 9, 2014, Western Digital Ireland, Ltd. (“WDI”) used existing cash to repay the outstanding term loan balance of $1.8 billion under our previous credit agreement dated March 8, 2012. Also, on January 9, 2014, the Company, Western Digital Technologies, Inc. (“WDT”) and WDI entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto, which was subsequently amended on February 25, 2015 (as amended, the "Credit Agreement") to add Western Digital International, Ltd. (”WD International”) as an additional borrower. The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT, WDI and WD International (each, a “Borrower” and collectively, the “Borrowers”).

[0001628280-15-004065:mdna:85]
As of April 3, 2015, no amounts were outstanding under the revolving credit facility of the Credit Agreement and the term loan facility had an outstanding balance of $2.3 billion with a variable interest rate of 1.68%. We are required to make quarterly principal payments on the term loan facility totaling $31 million for the remainder of fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. As of April 3, 2015, we were in compliance all covenants under the Credit Agreement. For additional information, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:86]
[same as prior period, unchanged from 0000106040-15-000003:mdna:86]

[0001628280-15-004065:mdna:87]
[same as prior period, unchanged from 0000106040-15-000003:mdna:87]

[0001628280-15-004065:mdna:88]
[same as prior period, unchanged from 0000106040-15-000003:mdna:88]

[0001628280-15-004065:mdna:89]
Refer to Part II, Item 7 of our Annual Report on Form 10-K for the year ended June 27, 2014, for further discussion of our purchase orders and purchase agreements and the associated dollar amounts. See Part II, Item 1A of this Quarterly Report on Form 10-Q for a discussion of the risks associated with these commitments.

[0001628280-15-004065:mdna:90]
[same as prior period, unchanged from 0000106040-15-000003:mdna:90]

[0001628280-15-004065:mdna:91]
[same as prior period, unchanged from 0000106040-15-000003:mdna:91]

[0001628280-15-004065:mdna:92]
[same as prior period, unchanged from 0000106040-15-000003:mdna:92]

[0001628280-15-004065:mdna:93]
Unrecognized Tax Benefits — As of April 3, 2015, the cash portion of our total recorded liability for unrecognized tax benefits was $273 million. We estimate the timing of the future payments of these liabilities to be within the next one to eight

[0001628280-15-004065:mdna:94]
years. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:95]
Stock Repurchase Program — Our Board of Directors previously authorized $3.0 billion for the repurchase of our common stock. On February 3, 2015, our Board of Directors authorized an additional $2.0 billion for the repurchase of our common stock and approved the extension of our stock repurchase program to February 3, 2020. During the three and nine months ended April 3, 2015, we repurchased 2.2 million and 7.6 million shares, respectively, for a total cost of $240 million and $772 million, respectively. Subsequent to April 3, 2015 and through May 6, 2015, we repurchased an additional 2.0 million shares of our common stock for a total cost of $198 million. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:96]
Cash Dividend Policy — During the three months ended April 3, 2015, we declared a cash dividend of $0.50 per share of our common stock as of April 3, 2015, totaling $116 million, which we paid on April 16, 2015. During the nine months ended April 3, 2015, we declared cash dividends of $1.30 per share of our common stock for a total of $280 million. On May 5, 2015, we declared a cash dividend of $0.50 per share as of July 3, 2015, which will be paid on July 15, 2015. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001628280-15-004065:mdna:97]
[same as prior period, unchanged from 0000106040-15-000003:mdna:97]

[0001628280-15-004065:mdna:98]
[same as prior period, unchanged from 0000106040-15-000003:mdna:98]

[0001628280-15-004065:mdna:99]
[same as prior period, unchanged from 0000106040-15-000003:mdna:99]

[0001628280-15-004065:mdna:100]
[same as prior period, unchanged from 0000106040-15-000003:mdna:100]
