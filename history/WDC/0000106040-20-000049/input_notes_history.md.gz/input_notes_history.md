# WDC note change history — 0000106040-20-000011 → 0000106040-20-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:1]
Related Parties and Related Commitments and Contingencies 
Flash Ventures
  (was, 2020-02-11, similarity 0.8837):
[0000106040-20-000011:note_history:1]
Related Parties and Related Commitments and Contingencies

- changed (2020-05-08):
[0000106040-20-000024:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 3, 2020 and June 28, 2019:
  (was, 2020-02-11, similarity 0.9688):
[0000106040-20-000011:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 3, 2020 and June 28, 2019:

- changed (2020-05-08):
[0000106040-20-000024:note_history:3]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Notes receivable, Flash Partners | $ | 335 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 423 |  |  | 878 |  |
| Notes receivable, Flash Forward | 777 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 125 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,157 |  |  | $ | 2,791 |  |
  (was, 2020-02-11, similarity 0.9769):
[0000106040-20-000011:note_history:3]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 412 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 625 |  |  | 878 |  |
| Notes receivable, Flash Forward | 663 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,321 |  |  | $ | 2,791 |  |

- added (2020-05-08):
[0000106040-20-000024:note_history:4]
During the three and nine months ended April 3, 2020 and during the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $842 million and $2.36 billion, and $1.04 billion and $2.90 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2020-05-08):
[0000106040-20-000024:note_history:5]
As of April 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $397 million and $331 million, respectively.
  (was, 2020-02-11, similarity 0.9708):
[0000106040-20-000011:note_history:5]
As of January 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $364 million and $331 million, respectively.

- changed (2020-05-08):
[0000106040-20-000024:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2020-02-11, similarity 0.9862):
[0000106040-20-000011:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2020-05-08):
[0000106040-20-000024:note_history:7]
|  | April 3,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,535 |  |
| Equity investments | 622 |  |
| Operating lease guarantees | 1,827 |  |
| Inventory and prepayments | 468 |  |
| Maximum estimable loss exposure | $ | 4,452 |  |
  (was, 2020-02-11, similarity 0.9314):
[0000106040-20-000011:note_history:7]
|  | January 3, 2020 |
| Notes receivable | $ | 1,700 |  |
| Equity investments | 621 |  |
| Operating lease guarantees | 1,746 |  |
| Inventory and prepayments | 462 |  |
| Maximum estimable loss exposure | $ | 4,529 |  |

- changed (2020-05-08):
[0000106040-20-000024:note_history:8]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.
  (was, 2020-02-11, similarity 0.9605):
[0000106040-20-000011:note_history:8]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

- added (2020-05-08):
[0000106040-20-000024:note_history:9]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the end of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 3, 2020, remaining committed prepayments totaled $205 million.

- changed (2020-05-08):
[0000106040-20-000024:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020.
  (was, 2020-02-11, similarity 0.9765):
[0000106040-20-000011:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020.

- changed (2020-05-08):
[0000106040-20-000024:note_history:11]
|  | Lease Amounts |  |  |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 198 |  |  | $ | 1,827 |  |
  (was, 2020-02-11, similarity 0.9857):
[0000106040-20-000011:note_history:11]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 189 |  |  | $ | 1,746 |  |

- changed (2020-05-08):
[0000106040-20-000024:note_history:12]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020:
  (was, 2020-02-11, similarity 0.9666):
[0000106040-20-000011:note_history:12]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of January 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020:

- changed (2020-05-08):
[0000106040-20-000024:note_history:13]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |  |  |  |  |
| Remaining three months of 2020 |  | $ | 128 |  |  | $ | 20 |  |  | $ | 148 |  |
| 2021 |  | 450 |  |  | 108 |  |  | 558 |  |
| 2022 |  | 370 |  |  | 49 |  |  | 419 |  |
| 2023 |  | 259 |  |  | 67 |  |  | 326 |  |
| 2024 |  | 123 |  |  | 120 |  |  | 243 |  |
| Thereafter |  | 23 |  |  | 110 |  |  | 133 |  |
| Total guarantee obligations |  | $ | 1,353 |  |  | $ | 474 |  |  | $ | 1,827 |  |
  (was, 2020-02-11, similarity 0.9825):
[0000106040-20-000011:note_history:13]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2020 |  | $ | 239 |  |  | $ | 35 |  |  | $ | 274 |  |
| 2021 |  | 406 |  |  | 108 |  |  | 514 |  |
| 2022 |  | 323 |  |  | 49 |  |  | 372 |  |
| 2023 |  | 215 |  |  | 67 |  |  | 282 |  |
| 2024 |  | 98 |  |  | 120 |  |  | 218 |  |
| Thereafter |  | 12 |  |  | 74 |  |  | 86 |  |
| Total guarantee obligations |  | $ | 1,293 |  |  | $ | 453 |  |  | $ | 1,746 |  |

- changed (2020-05-08):
[0000106040-20-000024:note_history:14]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2020-02-11, similarity 0.8066):
[0000106040-20-000011:note_history:14]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of January 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2020-05-08):
[0000106040-20-000024:note_history:15]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 3, 2020 and March 29, 2019, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of April 3, 2020 or June 28, 2019.
  (was, 2020-02-11, similarity 0.8891):
[0000106040-20-000011:note_history:15]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended January 3, 2020 and December 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of January 3, 2020 or June 28, 2019.

- removed (2020-05-08):
[0000106040-20-000011:note_history:16]
Flash Ventures

- removed (2020-05-08):
[0000106040-20-000011:note_history:17]
During the three and six months ended January 3, 2020 and during the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $648 million and $1.33 billion, and $1.12 billion and $1.86 billion respectively, for purchased flash-based memory wafers and net loans and investments.

- removed (2020-05-08):
[0000106040-20-000011:note_history:18]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the second half of fiscal year 2020, although meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the second half of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 3, 2020, remaining committed prepayments totaled $265 million.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:19]
Legal Proceedings
Tax
  (was, 2020-02-11, similarity 0.8947):
[0000106040-20-000011:note_history:19]
Legal Proceedings

- removed (2020-05-08):
[0000106040-20-000011:note_history:20]
Tax


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:21]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.
  (was, 2020-02-11, similarity 0.9724):
[0000106040-20-000011:note_history:21]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

- changed (2020-05-08):
[0000106040-20-000024:note_history:22]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.
  (was, 2020-02-11, similarity 0.6158):
[0000106040-20-000011:note_history:22]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

- removed (2020-05-08):
[0000106040-20-000011:note_history:23]
Organization and Basis of Presentation


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:24]
Debt
Debt consisted of the following as of April 3, 2020 and June 28, 2019:
  (was, 2020-02-11, similarity 0.8992):
[0000106040-20-000011:note_history:24]
Debt consisted of the following as of January 3, 2020 and June 28, 2019:

- changed (2020-05-08):
[0000106040-20-000024:note_history:25]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,645 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,694 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,774 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (145) |  |  | (172) |  |
| Subtotal | 9,629 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286) |  |  | (276) |  |
| Long-term debt | $ | 9,343 |  |  | $ | 10,246 |  |
  (was, 2020-02-11, similarity 0.9461):
[0000106040-20-000011:note_history:25]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,708 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,986 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (153 | ) |  | (172 | ) |
| Subtotal | 9,833 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286 | ) |  | (276 | ) |
| Long-term debt | $ | 9,547 |  |  | $ | 10,246 |  |

- added (2020-05-08):
[0000106040-20-000024:note_history:26]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 3, 2020, the Company was in compliance with these financial covenants.
During the nine months ended April 3, 2020, the Company made aggregate voluntary prepayments of $725 million on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of April 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.

- removed (2020-05-08):
[0000106040-20-000011:note_history:27]
Debt

- removed (2020-05-08):
[0000106040-20-000011:note_history:28]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 3, 2020, the Company was in compliance with these financial covenants.

- removed (2020-05-08):
[0000106040-20-000011:note_history:29]
On October 4, 2019 and January 3, 2020, the Company made voluntary prepayments of $250 million and $325 million, respectively, on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of January 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023. On January 31, 2020, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:30]
Debt consisted of the following as of April 3, 2020 and June 28, 2019:
  (was, 2020-02-11, similarity 0.9355):
[0000106040-20-000011:note_history:30]
Debt consisted of the following as of January 3, 2020 and June 28, 2019:

- changed (2020-05-08):
[0000106040-20-000024:note_history:31]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,645 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,694 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,774 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (145) |  |  | (172) |  |
| Subtotal | 9,629 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286) |  |  | (276) |  |
| Long-term debt | $ | 9,343 |  |  | $ | 10,246 |  |
  (was, 2020-02-11, similarity 0.9461):
[0000106040-20-000011:note_history:31]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,708 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,986 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (153 | ) |  | (172 | ) |
| Subtotal | 9,833 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286 | ) |  | (276 | ) |
| Long-term debt | $ | 9,547 |  |  | $ | 10,246 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:32]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 3, 2020 and June 28, 2019:
  (was, 2020-02-11, similarity 0.9688):
[0000106040-20-000011:note_history:32]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 3, 2020 and June 28, 2019:

- changed (2020-05-08):
[0000106040-20-000024:note_history:33]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Notes receivable, Flash Partners | $ | 335 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 423 |  |  | 878 |  |
| Notes receivable, Flash Forward | 777 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 125 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,157 |  |  | $ | 2,791 |  |
  (was, 2020-02-11, similarity 0.9769):
[0000106040-20-000011:note_history:33]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 412 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 625 |  |  | 878 |  |
| Notes receivable, Flash Forward | 663 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,321 |  |  | $ | 2,791 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0000106040-20-000024:note_history:34]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
  (was, 2020-02-11, similarity 0.8637):
[0000106040-20-000011:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-05-08):
[0000106040-20-000024:note_history:35]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 3, 2020 or June 28, 2019.

- changed (2020-05-08):
[0000106040-20-000024:note_history:36]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 3, 2020 and June 28, 2019 as well as the related amortization for the three and nine months ended April 3, 2020 and March 29, 2019 were not material.
  (was, 2020-02-11, similarity 0.9569):
[0000106040-20-000011:note_history:36]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of January 3, 2020 and June 28, 2019 as well as the related amortization for the three and six months ended January 3, 2020 and December 28, 2018 were not material.

- changed (2020-05-08):
[0000106040-20-000024:note_history:37]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 3, 2020 and June 28, 2019, contract liabilities were not material.
  (was, 2020-02-11, similarity 0.9432):
[0000106040-20-000011:note_history:37]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of January 3, 2020 and June 28, 2019, contract liabilities were not material.

- changed (2020-05-08):
[0000106040-20-000024:note_history:38]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 3, 2020 was $122 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $11 million during the remainder of fiscal 2020, $41 million in fiscal 2021, $39 million in fiscal 2022 and $31 million thereafter.
  (was, 2020-02-11, similarity 0.9941):
[0000106040-20-000011:note_history:38]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of January 3, 2020 was $140 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $24 million during the remainder of fiscal 2020, $43 million in fiscal 2021, $40 million in fiscal 2022 and $33 million thereafter.

- changed (2020-05-08):
[0000106040-20-000024:note_history:39]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
  (was, 2020-02-11, similarity 0.8637):
[0000106040-20-000011:note_history:39]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |

- added (2020-05-08):
[0000106040-20-000024:note_history:40]
The Company’s top 10 customers accounted for 44% of its net revenue for both the three and nine months ended April 3, 2020, and 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively. For the three and nine months ended April 3, 2020 and March 29, 2019, no single customer accounted for 10% or more of the Company’s net revenue.

- removed (2020-05-08):
[0000106040-20-000011:note_history:41]
Revenues

- removed (2020-05-08):
[0000106040-20-000011:note_history:42]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either January 3, 2020 or June 28, 2019.

- removed (2020-05-08):
[0000106040-20-000011:note_history:43]
The Company’s top 10 customers accounted for 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively, and 47% of its net revenue for both the three and six months ended December 28, 2018.  For the three and six months ended January 3, 2020 and December 28, 2018, no single customer accounted for 10% or more of the Company’s net revenue.
