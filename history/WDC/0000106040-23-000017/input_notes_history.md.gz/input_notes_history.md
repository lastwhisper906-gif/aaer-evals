# WDC note change history — 0000106040-23-000010 → 0000106040-23-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:1]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 47 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 727 |  |  | 793 |  |
| Investment in Flash Partners | 173 |  |  | 166 |  |
| Investment in Flash Alliance | 253 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,379 |  |  | $ | 1,396 |  |
  (was, 2023-02-03, similarity 0.9848):
[0000106040-23-000010:note_history:1]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 12 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 66 |  |  | 55 |  |
| Notes receivable, Flash Forward | 737 |  |  | 793 |  |
| Investment in Flash Partners | 174 |  |  | 166 |  |
| Investment in Flash Alliance | 251 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,357 |  |  | $ | 1,396 |  |

- changed (2023-05-10):
[0000106040-23-000017:note_history:2]
During the three and nine months ended March 31, 2023 and April 1, 2022, the Company made net payments to Flash Ventures of $1.2 billion and $3.2 billion, and $1.1 billion and $3.4 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2023-02-03, similarity 0.8371):
[0000106040-23-000010:note_history:2]
During the three and six months ended December 30, 2022 and December 31, 2021, the Company made net payments to Flash Ventures of $1.0 billion and $2.0 billion, and $1.1 billion and $2.3 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2023-05-10):
[0000106040-23-000017:note_history:3]
As of March 31, 2023 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $265 million and $320 million, respectively.
  (was, 2023-02-03, similarity 0.9673):
[0000106040-23-000010:note_history:3]
As of December 30, 2022 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $368 million and $320 million, respectively.

- changed (2023-05-10):
[0000106040-23-000017:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2023-02-03, similarity 0.9851):
[0000106040-23-000010:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2023-05-10):
[0000106040-23-000017:note_history:5]
|  | March 31,2023 |
|  | (in millions) |
| Notes receivable | $ | 836 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,876 |  |
| Inventory and prepayments | 1,073 |  |
| Maximum estimable loss exposure | $ | 4,328 |  |
  (was, 2023-02-03, similarity 0.9742):
[0000106040-23-000010:note_history:5]
|  | December 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 815 |  |
| Equity investments | 542 |  |
| Operating lease guarantees | 1,895 |  |
| Inventory and prepayments | 1,128 |  |
| Maximum estimable loss exposure | $ | 4,380 |  |

- changed (2023-05-10):
[0000106040-23-000017:note_history:6]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $70 million as follows: $47 million for the remaining three months of 2023 and $23 million in 2024, to be credited against future wafer charges.
  (was, 2023-02-03, similarity 0.9935):
[0000106040-23-000010:note_history:6]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $147 million as follows: $124 million for the remaining six months of 2023 and $23 million in 2024, to be credited against future wafer charges.

- changed (2023-05-10):
[0000106040-23-000017:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023.
  (was, 2023-02-03, similarity 0.9785):
[0000106040-23-000010:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022.

- changed (2023-05-10):
[0000106040-23-000017:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023:
  (was, 2023-02-03, similarity 0.9639):
[0000106040-23-000010:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2022:

- changed (2023-05-10):
[0000106040-23-000017:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2023 |  | $ | 144 |  |  | $ | 31 |  |  | $ | 175 |  |
| 2024 |  | 480 |  |  | 98 |  |  | 578 |  |
| 2025 |  | 271 |  |  | 90 |  |  | 361 |  |
| 2026 |  | 297 |  |  | 135 |  |  | 432 |  |
| 2027 |  | 104 |  |  | 115 |  |  | 219 |  |
| 2028 and thereafter |  | 24 |  |  | 87 |  |  | 111 |  |
| Total guarantee obligations |  | $ | 1,320 |  |  | $ | 556 |  |  | $ | 1,876 |  |
  (was, 2023-02-03, similarity 0.9913):
[0000106040-23-000010:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2023 |  | $ | 285 |  |  | $ | 55 |  |  | $ | 340 |  |
| 2024 |  | 450 |  |  | 99 |  |  | 549 |  |
| 2025 |  | 250 |  |  | 90 |  |  | 340 |  |
| 2026 |  | 261 |  |  | 136 |  |  | 397 |  |
| 2027 |  | 81 |  |  | 116 |  |  | 197 |  |
| 2028 and thereafter |  | 12 |  |  | 60 |  |  | 72 |  |
| Total guarantee obligations |  | $ | 1,339 |  |  | $ | 556 |  |  | $ | 1,895 |  |

- changed (2023-05-10):
[0000106040-23-000017:note_history:10]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2023, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2023-02-03, similarity 0.9873):
[0000106040-23-000010:note_history:10]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2023-05-10):
[0000106040-23-000017:note_history:11]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of March 31, 2023 and July 1, 2022, respectively.
  (was, 2023-02-03, similarity 0.947):
[0000106040-23-000010:note_history:11]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of December 30, 2022 and July 1, 2022, respectively.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:12]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and the status of resolution with respect to certain matters, see Note 13, Income Tax Expense.
  (was, 2023-02-03, similarity 0.9704):
[0000106040-23-000010:note_history:12]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:13]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended March 31, 2023 (in millions):
  (was, 2023-02-03, similarity 0.9757):
[0000106040-23-000010:note_history:13]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended December 30, 2022 (in millions):

- changed (2023-05-10):
[0000106040-23-000017:note_history:14]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 6 |  |
| Gross increases related to prior year tax positions | 3 |  |
| Gross decreases related to prior year tax positions | (25) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at March 31, 2023 | $ | 1,023 |  |
  (was, 2023-02-03, similarity 0.984):
[0000106040-23-000010:note_history:14]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 11 |  |
| Gross decreases related to prior year tax positions | (12) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at December 30, 2022 | $ | 1,042 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:15]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in storage technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.
  (was, 2023-02-03, similarity 0.9874):
[0000106040-23-000010:note_history:15]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in memory technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

- changed (2023-05-10):
[0000106040-23-000017:note_history:16]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.
  (was, 2023-02-03, similarity 0.9577):
[0000106040-23-000010:note_history:16]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.

- added (2023-05-10):
[0000106040-23-000017:note_history:17]
Income (Loss) per Common Share
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:18]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (27) |  |  | (78) |  |
| Subtotal | 7,073 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,175) |  |  | — |  |
| Long-term debt | $ | 5,898 |  |  | $ | 7,022 |  |
  (was, 2023-02-03, similarity 0.9896):
[0000106040-23-000010:note_history:18]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Subtotal | 7,071 |  |  | 7,022 |  |
| Less current portion of long-term debt | (38) |  |  | — |  |
| Long-term debt | $ | 7,033 |  |  | $ | 7,022 |  |

- changed (2023-05-10):
[0000106040-23-000017:note_history:19]
During the nine months ended March 31, 2023, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).
  (was, 2023-02-03, similarity 0.8856):
[0000106040-23-000010:note_history:19]
During the six months ended December 30, 2022, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- changed (2023-05-10):
[0000106040-23-000017:note_history:20]
| Quarter ending: | Leverage ratio |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |
  (was, 2023-02-03, similarity 0.95):
[0000106040-23-000010:note_history:20]
| Quarter ending: | Leverage ratio |
| December 30, 2022 | 3.25 to 1.00 |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |

- changed (2023-05-10):
[0000106040-23-000017:note_history:21]
As of March 31, 2023, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.
  (was, 2023-02-03, similarity 0.9933):
[0000106040-23-000010:note_history:21]
As of December 30, 2022, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have Cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.

- changed (2023-05-10):
[0000106040-23-000017:note_history:22]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions. As of March 31, 2023, the Company had not drawn on the Delayed Draw Term Loan.
  (was, 2023-02-03, similarity 0.9124):
[0000106040-23-000010:note_history:22]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions.

- changed (2023-05-10):
[0000106040-23-000017:note_history:23]
The key covenants, limitations and requirements provided under the Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.
  (was, 2023-02-03, similarity 0.9871):
[0000106040-23-000010:note_history:23]
The key covenants, limitations and requirements provided under Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:24]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (27) |  |  | (78) |  |
| Subtotal | 7,073 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,175) |  |  | — |  |
| Long-term debt | $ | 5,898 |  |  | $ | 7,022 |  |
  (was, 2023-02-03, similarity 0.9896):
[0000106040-23-000010:note_history:24]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Subtotal | 7,071 |  |  | 7,022 |  |
| Less current portion of long-term debt | (38) |  |  | — |  |
| Long-term debt | $ | 7,033 |  |  | $ | 7,022 |  |


## wdc:DebtInstrumentScheduleOfLeverageRatioTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:25]
| Quarter ending: | Leverage ratio |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |
  (was, 2023-02-03, similarity 0.95):
[0000106040-23-000010:note_history:25]
| Quarter ending: | Leverage ratio |
| December 30, 2022 | 3.25 to 1.00 |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:26]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 47 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 727 |  |  | 793 |  |
| Investment in Flash Partners | 173 |  |  | 166 |  |
| Investment in Flash Alliance | 253 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,379 |  |  | $ | 1,396 |  |
  (was, 2023-02-03, similarity 0.9848):
[0000106040-23-000010:note_history:26]
|  | December 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 12 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 66 |  |  | 55 |  |
| Notes receivable, Flash Forward | 737 |  |  | 793 |  |
| Investment in Flash Partners | 174 |  |  | 166 |  |
| Investment in Flash Alliance | 251 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,357 |  |  | $ | 1,396 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,205 |  |  | $ | 1,774 |  |  | $ | 4,258 |  |  | $ | 5,919 |  |
| Client | 975 |  |  | 1,732 |  |  | 3,293 |  |  | 5,439 |  |
| Consumer | 623 |  |  | 875 |  |  | 2,095 |  |  | 2,907 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,353 |  |  | $ | 2,400 |  |  | $ | 4,533 |  |  | $ | 7,685 |  |
| Americas | 935 |  |  | 1,377 |  |  | 3,448 |  |  | 4,398 |  |
| Europe, Middle East and Africa | 515 |  |  | 604 |  |  | 1,665 |  |  | 2,182 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
  (was, 2023-02-03, similarity 0.92):
[0000106040-23-000010:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,224 |  |  | $ | 1,920 |  |  | $ | 3,053 |  |  | $ | 4,145 |  |
| Client | 1,089 |  |  | 1,854 |  |  | 2,318 |  |  | 3,707 |  |
| Consumer | 794 |  |  | 1,059 |  |  | 1,472 |  |  | 2,032 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,494 |  |  | $ | 2,610 |  |  | $ | 3,180 |  |  | $ | 5,285 |  |
| Americas | 1,090 |  |  | 1,407 |  |  | 2,513 |  |  | 3,021 |  |
| Europe, Middle East and Africa | 523 |  |  | 816 |  |  | 1,150 |  |  | 1,578 |  |
| Total Revenue | $ | 3,107 |  |  | $ | 4,833 |  |  | $ | 6,843 |  |  | $ | 9,884 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000106040-23-000017:note_history:28]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 31, 2023 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of March 31, 2023 and July 1, 2022 and changes in contract liabilities for the nine months ended March 31, 2023 and April 1, 2022 were not material.
  (was, 2023-02-03, similarity 0.9211):
[0000106040-23-000010:note_history:28]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of December 30, 2022 and July 1, 2022 and changes in contract liabilities for the six months ended December 30, 2022 and December 31, 2021 were not material.

- changed (2023-05-10):
[0000106040-23-000017:note_history:29]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 31, 2023 was not material.
  (was, 2023-02-03, similarity 0.8372):
[0000106040-23-000010:note_history:29]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically have a duration of longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 30, 2022 was $17 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize this amount as revenue as follows: $14 million during the remainder of 2023, and $3 million in 2024 and thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-05-10):
[0000106040-23-000010:note_history:30]
Subsequent EventsOn January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”) from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million. The Preferred Shares will have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. The Preferred Shares will be convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate of the stated value plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the holder beginning on January 31, 2024, or on the date a specified spin-off transaction is completed, if earlier. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days. After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares at an amount equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares. The Preferred Shares will vote on an as-converted equivalent basis along with holders of the Company’s common stock, except to the extent that shares issuable upon conversion of the Preferred Stock would exceed 19.9% of common stock outstanding immediately prior to the original issuance date of the Preferred Stock. In the event of liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock.
