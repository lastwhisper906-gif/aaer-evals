# WDC notes — 0000106040-23-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-23-000017:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in storage technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-23-000017:notes:2]
[same as prior period, unchanged from 0000106040-23-000010:notes:2]

[0000106040-23-000017:notes:3]
[same as prior period, unchanged from 0000106040-23-000010:notes:3]

[0000106040-23-000017:notes:4]
[same as prior period, unchanged from 0000106040-23-000010:notes:4]

[0000106040-23-000017:notes:5]
[same as prior period, unchanged from 0000106040-23-000010:notes:5]

[0000106040-23-000017:notes:6]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.

[0000106040-23-000017:notes:7]
[same as prior period, unchanged from 0000106040-23-000010:notes:7]

[0000106040-23-000017:notes:8]
[same as prior period, unchanged from 0000106040-23-000010:notes:8]

[0000106040-23-000017:notes:9]
[same as prior period, unchanged from 0000106040-23-000010:notes:9]

[0000106040-23-000017:notes:10]
Income (Loss) per Common Share
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-23-000017:notes:11]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-23-000017:notes:12]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with prior standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. The Company adopted the new standard effective July 2, 2022, the first day of the year ending June 30, 2023, using the modified retrospective method. On the date of adoption, the Company recorded a reduction in Additional Paid-In Capital of $128 million, a reduction of unamortized debt discount of $48 million, a reduction of deferred income tax liabilities of $11 million, and an increase to retained earnings of $91 million for the after-tax impact of previously recognized amortization of the debt discount associated with the Company’s convertible senior notes.

[0000106040-23-000017:notes:13]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of 2023. The Company adopted this ASU on July 2, 2022, the first day of the year ending June 30, 2023, and the adoption did not have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-23-000017:notes:14]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-23-000017:notes:15]
In September 2022, the FASB issued ASU No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”. This guidance requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU is effective for fiscal years beginning after December 15, 2022, which for the Company is the first quarter of 2024, with early adoption permitted, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023. The Company is currently evaluating the extent of the impact of this ASU on its Condensed Consolidated Financial Statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-23-000017:notes:16]
[same as prior period, unchanged from 0000106040-23-000010:notes:15]

[0000106040-23-000017:notes:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,307 |  |  | $ | 2,243 |  |  | $ | 4,686 |  |  | $ | 7,353 |  |
| HDD | 1,496 |  |  | 2,138 |  |  | 4,960 |  |  | 6,912 |  |
| Total net revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | (65) |  |  | $ | 798 |  |  | $ | 597 |  |  | $ | 2,665 |  |
| HDD | 363 |  |  | 592 |  |  | 1,237 |  |  | 2,061 |  |
| Total gross profit for segments | 298 |  |  | 1,390 |  |  | 1,834 |  |  | 4,726 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (38) |  |  | (36) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (1) |  |  | (65) |  |
| Contamination related charges | — |  |  | (203) |  |  | — |  |  | (203) |  |
| Recoveries from a power outage incident | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total unallocated corporate items | (12) |  |  | (209) |  |  | (39) |  |  | (297) |  |
| Consolidated gross profit | $ | 286 |  |  | $ | 1,181 |  |  | $ | 1,795 |  |  | $ | 4,429 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | (5.0) | % |  | 35.6 | % |  | 12.7 | % |  | 36.2 | % |
| HDD | 24.3 | % |  | 27.7 | % |  | 24.9 | % |  | 29.8 | % |
| Consolidated gross margin | 10.2 | % |  | 27.0 | % |  | 18.6 | % |  | 31.0 | % |

[0000106040-23-000017:notes:18]
[same as prior period, unchanged from 0000106040-23-000010:notes:17]

[0000106040-23-000017:notes:19]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-23-000017:notes:20]
[same as prior period, unchanged from 0000106040-23-000010:notes:19]

[0000106040-23-000017:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,205 |  |  | $ | 1,774 |  |  | $ | 4,258 |  |  | $ | 5,919 |  |
| Client | 975 |  |  | 1,732 |  |  | 3,293 |  |  | 5,439 |  |
| Consumer | 623 |  |  | 875 |  |  | 2,095 |  |  | 2,907 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,353 |  |  | $ | 2,400 |  |  | $ | 4,533 |  |  | $ | 7,685 |  |
| Americas | 935 |  |  | 1,377 |  |  | 3,448 |  |  | 4,398 |  |
| Europe, Middle East and Africa | 515 |  |  | 604 |  |  | 1,665 |  |  | 2,182 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |

[0000106040-23-000017:notes:22]
The Company’s top 10 customers accounted for 49% and 45% of its net revenue for the three and nine months ended March 31, 2023, respectively, and 44% and 43% of its net revenue for the three and nine months ended April 1, 2022, respectively. For the three and nine months ended March 31, 2023 and April 1, 2022, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-23-000017:notes:23]
[same as prior period, unchanged from 0000106040-23-000010:notes:22]

[0000106040-23-000017:notes:24]
[same as prior period, unchanged from 0000106040-23-000010:notes:23]

[0000106040-23-000017:notes:25]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at July 1, 2022 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |
| Balance at March 31, 2023 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |

[0000106040-23-000017:notes:26]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more-likely-than-not-impaired, the Company is required to perform a quantitative approach to determine the amount of impairment.

[0000106040-23-000017:notes:27]
As of December 30, 2022, management identified several continuing factors, including changes in macroeconomic conditions and recent declines of the Company’s market stock price, that warranted quantitative analyses of impairments for both the Flash and HDD reporting units as of such date. The fair value of each operating segment was based on a weighting of two valuation methodologies: an income approach and a market approach.

[0000106040-23-000017:notes:28]
[same as prior period, unchanged from 0000106040-23-000010:notes:27]

[0000106040-23-000017:notes:29]
[same as prior period, unchanged from 0000106040-23-000010:notes:28]

[0000106040-23-000017:notes:30]
[same as prior period, unchanged from 0000106040-23-000010:notes:29]

[0000106040-23-000017:notes:31]
As of December 30, 2022, the fair value derived from those valuation methodologies exceeded the carrying value by 9% and 28% for Flash and HDD, respectively.

[0000106040-23-000017:notes:32]
Management performed a goodwill impairment assessment for both reporting units as of the third quarter ended March 31, 2023. The assessment considered the continuing macroeconomic environment, industry conditions, reporting unit performance and revised forecasts, and determined there were no events or circumstances from prior quarter’s quantitative assessment that rise to a level that would more-likely-than-not reduce the fair value of the reporting units below their carrying value; therefore, no quantitative goodwill impairment analysis was performed. There were no impairment charges recorded for the three and nine months ended March 31, 2023.

[0000106040-23-000017:notes:33]
The Company is required to use judgment when assessing goodwill for impairment, including evaluating the impact of industry and macroeconomic conditions, the determination of the fair value of each reporting unit and the assignment of assets and liabilities to reporting units. In addition, the estimates used to determine the fair value of reporting units as well as their actual carrying value may change based on future changes in the Company’s results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen or the Company’s stock price decreases for a sustained period of time, goodwill could become impaired, which could result in an impairment charge and materially adversely affect the Company’s financial condition and results of operations.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-23-000017:notes:34]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 31, 2023 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of March 31, 2023 and July 1, 2022 and changes in contract liabilities for the nine months ended March 31, 2023 and April 1, 2022 were not material.

[0000106040-23-000017:notes:35]
[same as prior period, unchanged from 0000106040-23-000010:notes:33]

[0000106040-23-000017:notes:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 31, 2023 was not material.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-23-000017:notes:37]
[same as prior period, unchanged from 0000106040-23-000010:notes:35]

[0000106040-23-000017:notes:38]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the nine months ended March 31, 2023 and April 1, 2022, the Company sold trade accounts receivable aggregating $626 million and $100 million, respectively. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of March 31, 2023 and July 1, 2022, the amount of factored receivables that remained outstanding was $235 million and $300 million, respectively.

[0000106040-23-000017:notes:39]
[same as prior period, unchanged from 0000106040-23-000010:notes:37]

[0000106040-23-000017:notes:40]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 2,204 |  |  | $ | 1,603 |  |
| Work-in-process | 1,025 |  |  | 1,162 |  |
| Finished goods | 750 |  |  | 873 |  |
| Total inventories | $ | 3,979 |  |  | $ | 3,638 |  |

[0000106040-23-000017:notes:41]
[same as prior period, unchanged from 0000106040-23-000010:notes:39]

[0000106040-23-000017:notes:42]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 269 |  |  | $ | 269 |  |
| Buildings and improvements | 1,957 |  |  | 1,920 |  |
| Machinery and equipment | 8,716 |  |  | 8,642 |  |
| Computer equipment and software | 510 |  |  | 494 |  |
| Furniture and fixtures | 55 |  |  | 54 |  |
| Construction-in-process | 756 |  |  | 591 |  |
| Property, plant and equipment, gross | 12,263 |  |  | 11,970 |  |
| Accumulated depreciation | (8,595) |  |  | (8,300) |  |
| Property, plant and equipment, net | $ | 3,668 |  |  | $ | 3,670 |  |

[0000106040-23-000017:notes:43]
[same as prior period, unchanged from 0000106040-23-000010:notes:41]

[0000106040-23-000017:notes:44]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Other Intangible assets: |  |  |  |
| Finite-lived intangible assets | $ | 5,493 |  |  | $ | 5,493 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,476) |  |  | (5,360) |  |
| Other Intangible assets, net | $ | 97 |  |  | $ | 213 |  |

[0000106040-23-000017:notes:45]
[same as prior period, unchanged from 0000106040-23-000010:notes:43]

[0000106040-23-000017:notes:46]
[same as prior period, unchanged from 0000106040-23-000010:notes:44]

[0000106040-23-000017:notes:47]
[same as prior period, unchanged from 0000106040-23-000010:notes:45]

[0000106040-23-000017:notes:48]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 289 |  |  | $ | 351 |  |  | $ | 345 |  |  | $ | 363 |  |  |  |
| Charges to operations | 26 |  |  | 35 |  |  | 83 |  |  | 111 |  |  |  |
| Utilization | (43) |  |  | (20) |  |  | (137) |  |  | (71) |  |  |  |
| Changes in estimate related to pre-existing warranties | — |  |  | (11) |  |  | (19) |  |  | (48) |  |  |  |
| Warranty accrual, end of period | $ | 272 |  |  | $ | 355 |  |  | $ | 272 |  |  | $ | 355 |  |  |  |

[0000106040-23-000017:notes:49]
[same as prior period, unchanged from 0000106040-23-000010:notes:47]

[0000106040-23-000017:notes:50]
|  | March 31,2023 |  | July 1,2022 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 117 |  |  | $ | 162 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 155 |  |  | 183 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 272 |  |  | $ | 345 |  |  |  |  |  |  |  |

[0000106040-23-000017:notes:51]
[same as prior period, unchanged from 0000106040-23-000010:notes:49]

[0000106040-23-000017:notes:52]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 462 |  |  | $ | 659 |  |
| Non-current portion of unrecognized tax benefits | 439 |  |  | 477 |  |
| Other non-current liabilities | 604 |  |  | 643 |  |
| Total other liabilities | $ | 1,505 |  |  | $ | 1,779 |  |

[0000106040-23-000017:notes:53]
[same as prior period, unchanged from 0000106040-23-000010:notes:51]

[0000106040-23-000017:notes:54]
[same as prior period, unchanged from 0000106040-23-000010:notes:52]

[0000106040-23-000017:notes:55]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at July 1, 2022 | $ | (11) |  |  | $ | (277) |  |  |  |  |  |  | $ | (266) |  |  | $ | (554) |  |
| Other comprehensive income before reclassifications | (1) |  |  | 8 |  |  |  |  |  |  | (17) |  |  | (10) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 250 |  |  | 250 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | 1 |  |  |  |  |  |  | (49) |  |  | (48) |  |
| Net current-period other comprehensive income | (1) |  |  | 9 |  |  |  |  |  |  | 184 |  |  | 192 |  |
| Balance at March 31, 2023 | $ | (12) |  |  | $ | (268) |  |  |  |  |  |  | $ | (82) |  |  | $ | (362) |  |

[0000106040-23-000017:notes:56]
During the three and nine months ended March 31, 2023, the amounts reclassified out of AOCI were losses related to foreign exchange contracts and gains related to interest rate swap contracts. Losses reclassified out of AOCI related to foreign exchange contracts were $79 million and $260 million for the three and nine months ended March 31, 2023, respectively, that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. Gains reclassified out of AOCI related to interest rate swap contracts were $6 million and $10 million for the three and nine months ended March 31, 2023, respectively, that were charged to Interest expense in the Condensed Consolidated Statements of Operations.
As of March 31, 2023, substantially all existing net losses related to cash flow hedges recorded in AOCI are expected to be reclassified to earnings within the next twelve months. In addition, as of March 31, 2023, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-23-000017:notes:57]
[same as prior period, unchanged from 0000106040-23-000010:notes:55]

[0000106040-23-000017:notes:58]
[same as prior period, unchanged from 0000106040-23-000010:notes:56]

[0000106040-23-000017:notes:59]
[same as prior period, unchanged from 0000106040-23-000010:notes:57]

[0000106040-23-000017:notes:60]
[same as prior period, unchanged from 0000106040-23-000010:notes:58]

[0000106040-23-000017:notes:61]
[same as prior period, unchanged from 0000106040-23-000010:notes:59]

[0000106040-23-000017:notes:62]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 31, 2023 and July 1, 2022, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-23-000017:notes:63]
|  | March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | 146 |  |
| Foreign exchange contracts | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Total assets at fair value | $ | 146 |  |  | $ | 72 |  |  | $ | — |  |  | $ | 218 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 46 |  |  | $ | — |  |  | $ | 46 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 46 |  |  | $ | — |  |  | $ | 46 |  |

[0000106040-23-000017:notes:64]
[same as prior period, unchanged from 0000106040-23-000010:notes:62]

[0000106040-23-000017:notes:65]
[same as prior period, unchanged from 0000106040-23-000010:notes:63]

[0000106040-23-000017:notes:66]
[same as prior period, unchanged from 0000106040-23-000010:notes:64]

[0000106040-23-000017:notes:67]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2023 and the fourth quarter of 2022, respectively.

[0000106040-23-000017:notes:68]
|  | March 31, 2023 |  | July 1, 2022 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,098 |  |  | $ | 1,063 |  |  | $ | 1,048 |  |  | $ | 1,040 |  |
| 4.75% senior unsecured notes due 2026 | 2,292 |  |  | 2,219 |  |  | 2,291 |  |  | 2,205 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,692 |  |  | 2,651 |  |  | 2,693 |  |  | 2,621 |  |
| 2.85% senior unsecured notes due 2029 | 496 |  |  | 408 |  |  | 495 |  |  | 412 |  |
| 3.10% senior unsecured notes due 2032 | 495 |  |  | 378 |  |  | 495 |  |  | 389 |  |
| Total | $ | 7,073 |  |  | $ | 6,719 |  |  | $ | 7,022 |  |  | $ | 6,667 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-23-000017:notes:69]
Derivative Instruments and Hedging Activities
As of March 31, 2023, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months.

[0000106040-23-000017:notes:70]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and nine months ended March 31, 2023 and April 1, 2022, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-23-000017:notes:71]
[same as prior period, unchanged from 0000106040-23-000010:notes:69]

[0000106040-23-000017:notes:72]
[same as prior period, unchanged from 0000106040-23-000010:notes:70]

[0000106040-23-000017:notes:73]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 31, 2023 and July 1, 2022, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-23-000017:notes:74]
Debt
Debt consisted of the following:

[0000106040-23-000017:notes:75]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (27) |  |  | (78) |  |
| Subtotal | 7,073 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,175) |  |  | — |  |
| Long-term debt | $ | 5,898 |  |  | $ | 7,022 |  |

[0000106040-23-000017:notes:76]
During the nine months ended March 31, 2023, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

[0000106040-23-000017:notes:77]
In December 2022, the Company amended the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 for the purposes of providing flexibility by adjusting the leverage ratio requirements of the financial covenant thereunder through the Company’s quarter ending September 27, 2024 (such period, the “Covenant Relief Period”). As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

[0000106040-23-000017:notes:78]
| Quarter ending: | Leverage ratio |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |

[0000106040-23-000017:notes:79]
As of March 31, 2023, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.

[0000106040-23-000017:notes:80]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions. As of March 31, 2023, the Company had not drawn on the Delayed Draw Term Loan.

[0000106040-23-000017:notes:81]
Any amount drawn under the Delayed Draw Term Loan Agreement will mature 364 days following the date of the initial draw. However, the due date will be accelerated to November 2, 2023 if conditions for acceleration of amounts due under the Credit Agreement have been triggered as described above.

[0000106040-23-000017:notes:82]
The Delayed Draw Term Loan will bear interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies. The Company will also pay an unused commitment fee on the Delayed Draw Term Loan Agreement of 0.200%.

[0000106040-23-000017:notes:83]
The key covenants, limitations and requirements provided under the Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.

[0000106040-23-000017:notes:84]
As described in Note 2, Recent Accounting Pronouncements, the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-23-000017:notes:85]
[same as prior period, unchanged from 0000106040-23-000010:notes:83]

[0000106040-23-000017:notes:86]
[same as prior period, unchanged from 0000106040-23-000010:notes:84]

[0000106040-23-000017:notes:87]
[same as prior period, unchanged from 0000106040-23-000010:notes:85]

[0000106040-23-000017:notes:88]
|  | March 31,2023 |  | July 1,2022 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 305 |  |  | $ | 294 |  |  |  |
| Fair value of plan assets at end of period | 194 |  |  | 189 |  |  |  |
| Unfunded status | $ | 111 |  |  | $ | 105 |  |  |  |

[0000106040-23-000017:notes:89]
[same as prior period, unchanged from 0000106040-23-000010:notes:87]

[0000106040-23-000017:notes:90]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 110 |  |  | 104 |  |
| Net amount recognized | $ | 111 |  |  | $ | 105 |  |

[0000106040-23-000017:notes:91]
Net periodic benefit costs were not material for the three and nine months ended March 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-23-000017:notes:92]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-23-000017:notes:93]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-23-000017:notes:94]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-23-000017:notes:95]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 47 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 727 |  |  | 793 |  |
| Investment in Flash Partners | 173 |  |  | 166 |  |
| Investment in Flash Alliance | 253 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,379 |  |  | $ | 1,396 |  |

[0000106040-23-000017:notes:96]
During the three and nine months ended March 31, 2023 and April 1, 2022, the Company made net payments to Flash Ventures of $1.2 billion and $3.2 billion, and $1.1 billion and $3.4 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-23-000017:notes:97]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-23-000017:notes:98]
As of March 31, 2023 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $265 million and $320 million, respectively.

[0000106040-23-000017:notes:99]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-23-000017:notes:100]
|  | March 31,2023 |
|  | (in millions) |
| Notes receivable | $ | 836 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,876 |  |
| Inventory and prepayments | 1,073 |  |
| Maximum estimable loss exposure | $ | 4,328 |  |

[0000106040-23-000017:notes:101]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-23-000017:notes:102]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $70 million as follows: $47 million for the remaining three months of 2023 and $23 million in 2024, to be credited against future wafer charges.

[0000106040-23-000017:notes:103]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-23-000017:notes:104]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-23-000017:notes:105]
Off-Balance Sheet Liabilities

[0000106040-23-000017:notes:106]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-23-000017:notes:107]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023.

[0000106040-23-000017:notes:108]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 250 |  |  | $ | 1,876 |  |

[0000106040-23-000017:notes:109]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023:

[0000106040-23-000017:notes:110]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2023 |  | $ | 144 |  |  | $ | 31 |  |  | $ | 175 |  |
| 2024 |  | 480 |  |  | 98 |  |  | 578 |  |
| 2025 |  | 271 |  |  | 90 |  |  | 361 |  |
| 2026 |  | 297 |  |  | 135 |  |  | 432 |  |
| 2027 |  | 104 |  |  | 115 |  |  | 219 |  |
| 2028 and thereafter |  | 24 |  |  | 87 |  |  | 111 |  |
| Total guarantee obligations |  | $ | 1,320 |  |  | $ | 556 |  |  | $ | 1,876 |  |

[0000106040-23-000017:notes:111]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2023, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-23-000017:notes:112]
Unis Venture

[0000106040-23-000017:notes:113]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of March 31, 2023 and July 1, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-23-000017:notes:114]
[same as prior period, unchanged from 0000106040-23-000010:notes:112]

[0000106040-23-000017:notes:115]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of March 31, 2023:

[0000106040-23-000017:notes:116]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining three months of 2023 | $ | 13 |  |  |  |  |  |  |  |  |  |
| 2024 | 48 |  |  |  |  |  |  |  |  |  |
| 2025 | 46 |  |  |  |  |  |  |  |  |  |
| 2026 | 46 |  |  |  |  |  |  |  |  |  |
| 2027 | 42 |  |  |  |  |  |  |  |  |  |
| Thereafter | 149 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 344 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 52 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 292 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 41 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 251 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 268 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 7.8 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.2 | % |  |  |  |  |  |  |  |  |

[0000106040-23-000017:notes:117]
[same as prior period, unchanged from 0000106040-23-000010:notes:115]

[0000106040-23-000017:notes:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | (in millions) |
| Cost of operating leases | $ | 15 |  |  | $ | 15 |  |  | $ | 43 |  |  | $ | 42 |  |
| Cash paid for operating leases | 12 |  |  | 13 |  |  | 38 |  |  | 37 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 10 |  |  | 9 |  |  | 14 |  |  | 132 |  |

[0000106040-23-000017:notes:119]
[same as prior period, unchanged from 0000106040-23-000010:notes:117]

[0000106040-23-000017:notes:120]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of March 31, 2023, the Company had the following minimum long-term commitments:

[0000106040-23-000017:notes:121]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining three months of 2023 |  | $ | 62 |  |
| 2024 |  | 206 |  |
| 2025 |  | 182 |  |
| 2026 |  | 54 |  |
| 2027 |  | 46 |  |
| Thereafter |  | 159 |  |
| Total |  | $ | 709 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-23-000017:notes:122]
Shareholders’ Equity and Convertible Preferred Stock
Stock-based Compensation Expense

[0000106040-23-000017:notes:123]
The following tables present the Company’s stock-based compensation for equity-settled awards by type (i.e. restricted stock units (“RSUs”), restricted stock unit awards with performance conditions or market conditions (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”)) and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-23-000017:notes:124]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 63 |  |  | $ | 75 |  |  | $ | 217 |  |  | $ | 220 |  |  |  |
| ESPP | 11 |  |  | 11 |  |  | 29 |  |  | 29 |  |  |  |
| Total | $ | 74 |  |  | $ | 86 |  |  | $ | 246 |  |  | $ | 249 |  |  |  |

[0000106040-23-000017:notes:125]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 12 |  |  | $ | 13 |  |  | $ | 38 |  |  | $ | 36 |  |  |  |
| Research and development | 37 |  |  | 43 |  |  | 116 |  |  | 126 |  |  |  |
| Selling, general and administrative | 25 |  |  | 30 |  |  | 92 |  |  | 87 |  |  |  |
| Subtotal | 74 |  |  | 86 |  |  | 246 |  |  | 249 |  |  |  |
| Tax benefit | (11) |  |  | (9) |  |  | (35) |  |  | (37) |  |  |  |
| Total | $ | 63 |  |  | $ | 77 |  |  | $ | 211 |  |  | $ | 212 |  |  |  |

[0000106040-23-000017:notes:126]
[same as prior period, unchanged from 0000106040-23-000010:notes:124]

[0000106040-23-000017:notes:127]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of March 31, 2023:

[0000106040-23-000017:notes:128]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |  |  |  |  |  |  |
|  | (in millions) |  | (years) |  |  |  |  |  |  |
| RSUs and PSUs (1) | $ | 521 |  |  | 2.4 |  |  |  |  |  |  |
| ESPP | 77 |  |  | 1.7 |  |  |  |  |  |  |
| Total unamortized compensation cost | $ | 598 |  |  |  |  |  |  |  |  |  |

[0000106040-23-000017:notes:129]
[same as prior period, unchanged from 0000106040-23-000010:notes:127]

[0000106040-23-000017:notes:130]
[same as prior period, unchanged from 0000106040-23-000010:notes:128]

[0000106040-23-000017:notes:131]
[same as prior period, unchanged from 0000106040-23-000010:notes:129]

[0000106040-23-000017:notes:132]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at March 31, 2023:

[0000106040-23-000017:notes:133]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at July 1, 2022 | 0.9 |  |  | $ | 66.76 |  |  | 0.54 |  |  |
| Canceled or expired | (0.5) |  |  | 83.10 |  |  |  |  |  |
| Options outstanding at March 31, 2023 | 0.4 |  |  | $ | 44.76 |  |  | 0.33 |  |  |

[0000106040-23-000017:notes:134]
[same as prior period, unchanged from 0000106040-23-000010:notes:132]

[0000106040-23-000017:notes:135]
[same as prior period, unchanged from 0000106040-23-000010:notes:133]

[0000106040-23-000017:notes:136]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | $ | 52.89 |  |  |  |
| Granted | 6.1 |  |  | 41.52 |  |  |  |
| Vested | (5.7) |  |  | 53.78 |  |  | $ | 237 |  |
| Forfeited | (1.3) |  |  | 55.61 |  |  |  |
| RSUs and PSUs outstanding at March 31, 2023 | 14.5 |  |  | $ | 47.50 |  |  |  |

[0000106040-23-000017:notes:137]
[same as prior period, unchanged from 0000106040-23-000010:notes:135]

[0000106040-23-000017:notes:138]
Convertible Preferred Stock

[0000106040-23-000017:notes:139]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million.

[0000106040-23-000017:notes:140]
Dividend provisions

[0000106040-23-000017:notes:141]
The Preferred Shares will have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. As of March 31, 2023, (i) no dividends have been declared or paid since the issuance of the Preferred Shares, and (ii) unpaid and cumulative dividends payable with respect to the Preferred Shares were $9 million.

[0000106040-23-000017:notes:142]
Conversion rights

[0000106040-23-000017:notes:143]
The Preferred Shares will be convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate sum of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the holder upon the earlier of on January 31, 2024, and the date a specified spin-off transaction is completed, unless the Company enters into a definitive agreement with respect to a sale, merger or combination of the spun-off entity, in which case the twelve (12) month period will be extended until the earlier of the consummation of such transaction or the termination of the definitive agreement. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately prior to the Company’s conversion notice. As of March 31, 2023, the Preferred Shares outstanding would have been convertible, if otherwise permitted, into 19 million shares of common stock.

[0000106040-23-000017:notes:144]
Redemption

[0000106040-23-000017:notes:145]
After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares for an amount in cash equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares.

[0000106040-23-000017:notes:146]
The Preferred Shares has been classified as mezzanine equity in the Company’s Condensed Consolidated Balance Sheets because, in the event of certain fundamental change in the business that are not solely within the control of the Company, the Preferred Shares would become redeemable at the option of the holders. The Company did not adjust the carrying values of the Preferred Shares to the current redemption value of such shares since a liquidation event was not probable at any of the balance sheet dates. Subsequent adjustments to increase or decrease the carrying values to the ultimate redemption value will be made only if and when it becomes probable that such a fundamental change in the business will occur.

[0000106040-23-000017:notes:147]
Voting right

[0000106040-23-000017:notes:148]
The Preferred Shares will vote, to the extent permitted under the Nasdaq listing rules, on an as-converted equivalent basis along with holders of the Company’s common stock.

[0000106040-23-000017:notes:149]
Liquidation preference

[0000106040-23-000017:notes:150]
In the event of any voluntary or involuntary liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock and the liquidation preference is the greater of (i) the sum of amount in cash equal to 110% of the Accumulated Stated Value plus accrued and unpaid dividends and (ii) the payment that the holders of Preferred Shares would have received had all Preferred Shares been converted into common stock immediately prior to such liquidation, before any distributions are made to common shareholders and all other classes of junior capital stock of the Company. As of March 31, 2023, the total aggregate liquidation preference was $909 million.

[0000106040-23-000017:notes:151]
[same as prior period, unchanged from 0000106040-23-000010:notes:136]

[0000106040-23-000017:notes:152]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the nine months ended March 31, 2023 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. Although the Company will reevaluate the repurchasing of common stock when appropriate, there can be no assurance if, when or at what level the Company may resume such activity. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of March 31, 2023 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-23-000017:notes:153]
[same as prior period, unchanged from 0000106040-23-000010:notes:138]

[0000106040-23-000017:notes:154]
[same as prior period, unchanged from 0000106040-23-000010:notes:139]

[0000106040-23-000017:notes:155]
[same as prior period, unchanged from 0000106040-23-000010:notes:140]

[0000106040-23-000017:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | (529) |  |  | $ | 262 |  |  | $ | (830) |  |  | $ | 1,612 |  |
| Income tax expense | 43 |  |  | 237 |  |  | 161 |  |  | 413 |  |
| Effective tax rate | (8) | % |  | 90 | % |  | (19) | % |  | 26 | % |

[0000106040-23-000017:notes:157]
Beginning in fiscal year 2023, the 2017 Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and nine months ended March 31, 2023 but did not have a material impact on the effective tax rate. The primary drivers of the difference between the effective tax rate for the three and nine months ended March 31, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031.

[0000106040-23-000017:notes:158]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 1, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand. In addition, the effective tax rate for the three and nine months ended April 1, 2022 includes the discrete effect of an increase to unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of settlement discussions with various taxing authorities of $194 million and $219 million, respectively.

[0000106040-23-000017:notes:159]
[same as prior period, unchanged from 0000106040-23-000010:notes:144]

[0000106040-23-000017:notes:160]
[same as prior period, unchanged from 0000106040-23-000010:notes:145]

[0000106040-23-000017:notes:161]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended March 31, 2023 (in millions):

[0000106040-23-000017:notes:162]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 6 |  |
| Gross increases related to prior year tax positions | 3 |  |
| Gross decreases related to prior year tax positions | (25) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at March 31, 2023 | $ | 1,023 |  |

[0000106040-23-000017:notes:163]
As of March 31, 2023, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.02 billion. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of March 31, 2023 was $280 million. Of these amounts, approximately $1.16 billion could result in potential cash payments.

[0000106040-23-000017:notes:164]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for years 2008 through 2015. The Company and the IRS reached an agreement on the federal tax and interest calculations with respect to years 2008 through 2012 for which the Company expects to pay tax and interest totaling approximately $620 million to $650 million within the next twelve months. The Company and the IRS have also reached a tentative settlement for the years 2013 through 2015 for which the Company expects to pay tax and interest totaling approximately $100 million to $110 million. The Company is uncertain as to when a final agreement for years 2013 through 2015 will be reached and the exact timing of when these payments will be made. However, the Company believes it is reasonably likely that these payments may be made within the next twelve months and has classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on its Condensed Consolidated Balance Sheets as of March 31, 2023. This classification and amount may be subject to change in the next twelve months depending on when the Company is able to reach a final agreement with the IRS. In connection with these settlements, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million in future years.

[0000106040-23-000017:notes:165]
[same as prior period, unchanged from 0000106040-23-000010:notes:150]


## us-gaap:EarningsPerShareTextBlock

[0000106040-23-000017:notes:166]
[same as prior period, unchanged from 0000106040-23-000010:notes:151]

[0000106040-23-000017:notes:167]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (572) |  |  |  | $ | 25 |  |  | $ | (991) |  |  | $ | 1,199 |  |
| Less: cumulative dividends on Preferred Stock | 9 |  |  |  | — |  |  | 9 |  |  | — |  |
| Net income (loss) attributable to common shareholders | $ | (581) |  |  |  | $ | 25 |  |  | $ | (1,000) |  |  | $ | 1,199 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 319 |  |  |  | 313 |  |  | 318 |  |  | 312 |  |
| Employee stock options, RSUs, PSUs, and ESPP | — |  |  |  | 3 |  |  | — |  |  | 4 |  |
| Diluted | 319 |  |  |  | 316 |  |  | 318 |  |  | 316 |  |
| Income (loss) per common shares |  |  |  |  |  |  |  |  |
| Basic | $ | (1.82) |  |  |  | $ | 0.08 |  |  | $ | (3.14) |  |  | $ | 3.84 |  |
| Diluted | $ | (1.82) |  |  |  | $ | 0.08 |  |  | $ | (3.14) |  |  | $ | 3.79 |  |
| Anti-dilutive potential common shares excluded | 15 |  |  |  | 5 |  |  | 15 |  |  | 4 |  |

[0000106040-23-000017:notes:168]
The Company computes basic income (loss) per common share by dividing net income attributable to common shareholders and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed by using diluted net income attributable to common shareholders, the weighted average number of common shares and potentially dilutive securities outstanding during the period using the treasury stock method or the “if-converted” method based on the nature of the securities.

[0000106040-23-000017:notes:169]
Basic income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the Company's convertible Preferred Stock and the treasury stock method is used to determine the dilutive impact of unvested restricted stock.
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the 1.50% convertible notes due 2024, and the Preferred Shares. For the three and nine months ended March 31, 2023, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive. For the three and nine months ended and April 1, 2022, the Company excluded common shares subject to certain outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-23-000017:notes:170]
[same as prior period, unchanged from 0000106040-23-000010:notes:154]

[0000106040-23-000017:notes:171]
[same as prior period, unchanged from 0000106040-23-000010:notes:155]

[0000106040-23-000017:notes:172]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 40 |  |  | $ | 4 |  |  | $ | 125 |  |  | $ | 22 |  |  |  |
| Asset impairments and other charges | — |  |  | — |  |  | 15 |  |  | 2 |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 40 |  |  | $ | 4 |  |  | $ | 140 |  |  | $ | 24 |  |  |  |

[0000106040-23-000017:notes:173]
The following table presents an analysis of the components of these activities against the reserve during the nine months ended March 31, 2023:

[0000106040-23-000017:notes:174]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 1, 2022 | $ | 17 |  |  |  |  |  |
| Charges | 125 |  |  |  |  |  |
| Cash payments | (126) |  |  |  |  |  |
| Accrual balance at March 31, 2023 | $ | 16 |  |  |  |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-23-000017:notes:175]
Legal Proceedings
Tax

[0000106040-23-000017:notes:176]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and the status of resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-23-000017:notes:177]
Other Matters

[0000106040-23-000017:notes:178]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
