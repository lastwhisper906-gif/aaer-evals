# WDC 8-K — 0000106040-23-000014 filed 2023-05-08

## item codes, every 8-K on or before 2023-05-10

- 2023-05-08 0000106040-23-000014 — 2.02, 9.01
- 2023-05-05 0001193125-23-137241 — 8.01, 9.01
- 2023-04-03 0001193125-23-088802 — 8.01, 9.01
- 2023-02-07 0001193125-23-026907 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01 — amendment of 0001193125-23-020502
- 2023-02-01 0001193125-23-020502 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01
- 2023-01-31 0000106040-23-000006 — 1.01, 2.02, 2.03, 9.01
- 2022-12-23 0001193125-22-311796 — 1.01, 9.01
- 2022-11-18 0001193125-22-288992 — 5.02, 5.07, 9.01
- 2022-10-27 0000106040-22-000061 — 2.02, 9.01
- 2022-08-05 0000106040-22-000049 — 2.02, 9.01
- 2022-07-01 0001193125-22-187239 — 1.01, 9.01
- 2022-06-17 0001193125-22-176478 — 5.02, 9.01
- 2022-06-08 0001193125-22-169552 — 1.01, 7.01, 8.01, 9.01
- 2022-04-28 0000106040-22-000030 — 2.02, 9.01
- 2022-01-27 0001193125-22-019801 — 5.02, 7.01, 9.01
- 2022-01-27 0000106040-22-000010 — 2.02, 9.01
- 2022-01-07 0001193125-22-004434 — 1.01, 2.03, 7.01
- 2021-12-10 0001193125-21-353971 — 1.01, 2.03, 7.01, 8.01, 9.01
- 2021-12-06 0001193125-21-348304 — 7.01
- 2021-11-19 0001193125-21-335120 — 5.04, 9.01
- 2021-11-18 0001193125-21-332703 — 5.02
- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2023-05-10

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-23-000014:8k_2_02:1]
EX-99.1
2
ex991-pressreleaseq323.htm
EX-99.1

[0000106040-23-000014:8k_2_02:2]
Document

[0000106040-23-000014:8k_2_02:3]
Exhibit 99.1

[0000106040-23-000014:8k_2_02:4]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:5]
News Summary

[0000106040-23-000014:8k_2_02:6]
•Third quarter revenue was $2.8 billion, at the high end of the guidance range.

[0000106040-23-000014:8k_2_02:7]
•Third quarter GAAP earnings per share (EPS) was $(1.82) and Non-GAAP EPS was $(1.37), which includes $200 million of underutilization related charges in Flash and HDD.

[0000106040-23-000014:8k_2_02:8]
•Third quarter GAAP operating loss was $472 million and Non-GAAP operating loss was $304 million.

[0000106040-23-000014:8k_2_02:9]
•Expect fiscal fourth quarter 2023 revenue to be in the range of $2.40 billion to $2.60 billion.

[0000106040-23-000014:8k_2_02:10]
•Expect Non-GAAP EPS in the range of $(2.20) to $(1.90) which includes $220 to $240 million of  underutilization charges in Flash and HDD.

[0000106040-23-000014:8k_2_02:11]
SAN JOSE, Calif., — May 8, 2023 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal third quarter 2023 financial results.

[0000106040-23-000014:8k_2_02:12]
“Over the last several years, our team has focused on enhancing business agility and delivering a range of innovative, industry-leading products that address the increasing data storage demands of our customers,” said David Goeckeler, Western Digital CEO. “The groundwork we laid, combined with the actions we have taken since the beginning of this fiscal year to right-size and refocus our businesses, have enabled us to navigate a dynamic environment. I am pleased that we delivered non-GAAP gross margin at the higher end of our guidance range due to strong execution across both our HDD and Flash businesses.”

[0000106040-23-000014:8k_2_02:13]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:14]
Q3 2023 Financial Highlights

[0000106040-23-000014:8k_2_02:15]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2023 | Q2 2023 | Q/Q |  | Q3 2023 | Q2 2023 | Q/Q |
| Revenue ($M) |  | $2,803 | $3,107 | down 10% |  | $2,803 | $3,107 | down 10% |
| Gross Margin |  | 10.2% | 17.0% | down 6.8 ppt |  | 10.6% | 17.4% | down 6.8 ppt |
| Operating Expenses ($M) |  | $758 | $849 | down 11% |  | $602 | $659 | down 9% |
| Operating Loss ($M) |  | $(472) | $(321) | up 47% |  | $(304) | $(119) | * |
| Net Loss ($M) |  | $(572) | $(446) | up 28% |  | $(427) | $(135) | * |
| Earnings Per Share |  | $(1.82) | $(1.40) | up 30% |  | $(1.37) | $(0.42) | * |

[0000106040-23-000014:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2023 | Q3 2022 | Y/Y |  | Q3 2023 | Q3 2022 | Y/Y |
| Revenue ($M) |  | $2,803 | $4,381 | down 36% |  | $2,803 | $4,381 | down 36% |
| Gross Margin |  | 10.2% | 27.0% | down 16.8 ppt |  | 10.6% | 31.7% | down 21.1 ppt |
| Operating Expenses ($M) |  | $758 | $857 | down 12% |  | $602 | $740 | down 19% |
| Operating Income (Loss) ($M) |  | $(472) | $324 | * |  | $(304) | $650 | * |
| Net Income (Loss) ($M) |  | $(572) | $25 | * |  | $(427) | $521 | * |
| Earnings Per Share |  | $(1.82) | $0.08 | * |  | $(1.37) | $1.65 | * |

[0000106040-23-000014:8k_2_02:17]
* not a meaningful figure

[0000106040-23-000014:8k_2_02:18]
The company had an operating cash outflow of $381 million and ended the quarter with $2.22 billion of total cash and cash equivalents.

[0000106040-23-000014:8k_2_02:19]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-23-000014:8k_2_02:20]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:21]
End Market Summary

[0000106040-23-000014:8k_2_02:22]
| Revenue ($M) | Q3 2023 | Q2 2023 | Q/Q |  |  | Q3 2022 | Y/Y |  |  |  |  |  |  |  |  |  |
| Cloud | $1,205 | $1,224 | down 2% |  |  | $1,774 | down 32% |  |  |  |  |  |  |  |  |  |
| Client | 975 | 1,089 | down 10% |  |  | 1,732 | down 44% |  |  |  |  |  |  |  |  |  |
| Consumer | 623 | 794 | down 22% |  |  | 875 | down 29% |  |  |  |  |  |  |  |  |  |
| Total Revenue | $2,803 | $3,107 | down 10% |  |  | $4,381 | down 36% |  |  |  |  |  |  |  |  |  |

[0000106040-23-000014:8k_2_02:23]
In the fiscal third quarter:

[0000106040-23-000014:8k_2_02:24]
•Cloud represented 43% of total revenue. Sequentially, an increase in capacity enterprise drive shipments was offset by a decrease in flash shipments. The year-over-year decline was primarily due to a decline in shipments of both hard drive and flash products, as well as price decreases in Flash.

[0000106040-23-000014:8k_2_02:25]
•Client represented 35% of total revenue. On both a sequential and year-over-year basis, the decrease was driven by price declines across our flash products and a lower client SSD and hard drive shipments for PC applications.

[0000106040-23-000014:8k_2_02:26]
•Consumer represented 22% of total revenue. Sequentially, the decrease was due to a seasonal decline in shipments of both retail hard drive and flash products, as well as price declines in retail Flash. The year-over-year decrease was driven by lower retail hard drive shipments and price declines in Flash.

[0000106040-23-000014:8k_2_02:27]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:28]
Business Outlook for Fiscal Fourth Quarter of 2023

[0000106040-23-000014:8k_2_02:29]
|  | Three Months Ending |
|  | June 30, 2023 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) | $2.40 - $2.60 |  | $2.40 - $2.60 |
| Gross margin | 2.4% - 4.4% |  | 3.0% - 5.0% |
| Operating expenses ($M) | $730 - $750 |  | $580 - $600 |
| Interest and other expense, net ($M) | ~$90 |  | ~$90 |
| Income tax expense ($M)(2) | N/A |  | $60 - $70 |
| Diluted earnings per share | N/A |  | $(2.20) - $(1.90) |
| Diluted shares outstanding (in millions) | ~321 |  | ~321 |

[0000106040-23-000014:8k_2_02:30]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense of approximately $10 million to $15 million. The company’s Non-GAAP operating expenses guidance excludes amortization of acquired intangible assets, stock-based compensation expense, employee termination, asset impairment and other charges, and expenses related to strategic review, totaling approximately $140 million to $160 million. In the aggregate, Non-GAAP diluted earnings per share guidance excludes these items totaling $150 million to $175 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, and Non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the company excludes from its Non-GAAP income tax expense and Non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP income tax expense and Non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (GAAP gross profit, GAAP operating expenses, income tax expense and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-23-000014:8k_2_02:31]
(2) The Non-GAAP income tax expense is determined based on a percentage of Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax dollars may differ from our GAAP tax dollars (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income; (ii) the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax rate for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0000106040-23-000014:8k_2_02:32]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:33]
Investor Communications

[0000106040-23-000014:8k_2_02:34]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal fourth quarter of 2023 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-23-000014:8k_2_02:35]
About Western Digital

[0000106040-23-000014:8k_2_02:36]
Western Digital is on a mission to unlock the potential of data by harnessing the possibility to use it. With Flash and HDD franchises, underpinned by advancements in storage technologies, we create breakthrough innovations and powerful data storage solutions that enable the world to actualize its aspirations. Core to our values, we recognize the urgency to combat climate change and have committed to ambitious carbon reduction goals approved by the Science Based Targets initiative. Learn more about Western Digital and the Western Digital®, SanDisk® and WD® brands at www.westerndigital.com.

[0000106040-23-000014:8k_2_02:37]
Forward-Looking Statements

[0000106040-23-000014:8k_2_02:38]
Western Digital Reports Fiscal Third Quarter 2023 Financial Results

[0000106040-23-000014:8k_2_02:39]
hiring and retention of key employees; our level of debt and other financial obligations; changes to our relationships with key customers; compromise, damage or interruption from cybersecurity incidents or other data system security risks; actions by competitors; risks associated with compliance with changing legal and regulatory requirements and the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-K filed with the SEC on August 25, 2022, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update or revise these forward-looking statements to reflect new information or events, except as required by law.

[0000106040-23-000014:8k_2_02:40]
###

[0000106040-23-000014:8k_2_02:41]
Western Digital, the Western Digital logo, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-23-000014:8k_2_02:42]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:43]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-23-000014:8k_2_02:44]
(in millions; unaudited; on a US GAAP basis)

[0000106040-23-000014:8k_2_02:45]
|  | March 31,2023 |  | July 1,2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,220 |  |  | $ | 2,327 |  |
| Accounts receivable, net | 1,591 |  |  | 2,804 |  |
| Inventories | 3,979 |  |  | 3,638 |  |
| Other current assets | 693 |  |  | 684 |  |
| Total current assets | 8,483 |  |  | 9,453 |  |
| Property, plant and equipment, net | 3,668 |  |  | 3,670 |  |
| Notes receivable and investments in Flash Ventures | 1,379 |  |  | 1,396 |  |
| Goodwill | 10,041 |  |  | 10,041 |  |
| Other intangible assets, net | 97 |  |  | 213 |  |
| Other non-current assets | 1,483 |  |  | 1,486 |  |
| Total assets | $ | 25,151 |  |  | $ | 26,259 |  |
| LIABILITIES, CONVERTIBLE PREFERRED STOCK AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,307 |  |  | $ | 1,902 |  |
| Accounts payable to related parties | 265 |  |  | 320 |  |
| Accrued expenses | 1,158 |  |  | 1,636 |  |
| Income taxes payable | 1,013 |  |  | 869 |  |
| Accrued compensation | 343 |  |  | 510 |  |
| Current portion of long-term debt | 1,175 |  |  | — |  |
| Total current liabilities | 5,261 |  |  | 5,237 |  |
| Long-term debt | 5,898 |  |  | 7,022 |  |
| Other liabilities | 1,505 |  |  | 1,779 |  |
| Total liabilities | 12,664 |  |  | 14,038 |  |
| Convertible preferred stock | 876 |  |  | — |  |
| Total shareholders’ equity | 11,611 |  |  | 12,221 |  |
| Total liabilities, convertible preferred stock and shareholders’ equity | $ | 25,151 |  |  | $ | 26,259 |  |

[0000106040-23-000014:8k_2_02:46]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:47]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-23-000014:8k_2_02:48]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-23-000014:8k_2_02:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenue, net | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Cost of revenue | 2,517 |  |  | 3,200 |  |  | 7,851 |  |  | 9,836 |  |
| Gross profit | 286 |  |  | 1,181 |  |  | 1,795 |  |  | 4,429 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 476 |  |  | 572 |  |  | 1,551 |  |  | 1,725 |  |
| Selling, general and administrative | 242 |  |  | 281 |  |  | 739 |  |  | 851 |  |
| Employee termination, asset impairment, and other charges | 40 |  |  | 4 |  |  | 140 |  |  | 24 |  |
| Total operating expenses | 758 |  |  | 857 |  |  | 2,430 |  |  | 2,600 |  |
| Operating income (loss) | (472) |  |  | 324 |  |  | (635) |  |  | 1,829 |  |
| Interest and other expense, net | (57) |  |  | (62) |  |  | (195) |  |  | (217) |  |
| Income (loss) before taxes | (529) |  |  | 262 |  |  | (830) |  |  | 1,612 |  |
| Income tax expense | 43 |  |  | 237 |  |  | 161 |  |  | 413 |  |
| Net income (loss) | $ | (572) |  |  | $ | 25 |  |  | $ | (991) |  |  | $ | 1,199 |  |
| Less: cumulative dividends allocated to preferred shareholders | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Net income (loss) attributable to common shareholders | $ | (581) |  |  | $ | 25 |  |  | $ | (1,000) |  |  | $ | 1,199 |  |
| Income (loss) per common share: |  |  |  |  |  |  |  |
| Basic | $ | (1.82) |  |  | $ | 0.08 |  |  | $ | (3.14) |  |  | $ | 3.84 |  |
| Diluted | $ | (1.82) |  |  | $ | 0.08 |  |  | $ | (3.14) |  |  | $ | 3.79 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 319 |  |  | 313 |  |  | 318 |  |  | 312 |  |
| Diluted | 319 |  |  | 316 |  |  | 318 |  |  | 316 |  |

[0000106040-23-000014:8k_2_02:50]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:51]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-23-000014:8k_2_02:52]
(in millions; unaudited; on a US GAAP basis)

[0000106040-23-000014:8k_2_02:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | (572) |  |  | $ | 25 |  |  | $ | (991) |  |  | $ | 1,199 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 213 |  |  | 216 |  |  | 643 |  |  | 708 |  |
| Stock-based compensation | 74 |  |  | 86 |  |  | 246 |  |  | 249 |  |
| Deferred income taxes | 9 |  |  | 3 |  |  | 34 |  |  | 41 |  |
| Gain on disposal of assets | (8) |  |  | (15) |  |  | (7) |  |  | (14) |  |
| Non-cash portion of asset impairment | 3 |  |  | — |  |  | 18 |  |  | — |  |
| Amortization of debt issuance costs and discounts | 4 |  |  | 13 |  |  | 9 |  |  | 34 |  |
| Other non-cash operating activities, net | (63) |  |  | 29 |  |  | 6 |  |  | 42 |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | 314 |  |  | 390 |  |  | 1,213 |  |  | (96) |  |
| Inventories | (206) |  |  | (15) |  |  | (341) |  |  | (45) |  |
| Accounts payable | 79 |  |  | (196) |  |  | (442) |  |  | (100) |  |
| Accounts payable to related parties | (103) |  |  | 7 |  |  | (54) |  |  | (2) |  |
| Accrued expenses | (258) |  |  | (79) |  |  | (484) |  |  | 2 |  |
| Income taxes payable | (12) |  |  | (16) |  |  | 144 |  |  | (50) |  |
| Accrued compensation | (7) |  |  | (83) |  |  | (169) |  |  | (149) |  |
| Other assets and liabilities, net | 152 |  |  | 33 |  |  | (165) |  |  | (234) |  |
| Net cash provided by (used in) operating activities | (381) |  |  | 398 |  |  | (340) |  |  | 1,585 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (110) |  |  | (290) |  |  | (688) |  |  | (829) |  |
| Activity related to Flash Ventures, net | (36) |  |  | 40 |  |  | 46 |  |  | 23 |  |
| Strategic investments and other, net | 8 |  |  | (3) |  |  | 22 |  |  | (16) |  |
| Net cash used in investing activities | (138) |  |  | (253) |  |  | (620) |  |  | (822) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | (13) |  |  | (3) |  |  | (20) |  |  | (23) |  |
| Net proceeds from convertible preferred stock | 882 |  |  | — |  |  | 882 |  |  | — |  |
| Repayments of debt | — |  |  | (1,046) |  |  | (1,180) |  |  | (3,471) |  |
| Proceeds from debt | — |  |  | 896 |  |  | 1,180 |  |  | 1,894 |  |
| Debt issuance costs | (1) |  |  | (14) |  |  | (6) |  |  | (23) |  |
| Net cash provided by (used in) financing activities | 868 |  |  | (167) |  |  | 856 |  |  | (1,623) |  |
| Effect of exchange rate changes on cash | — |  |  | (4) |  |  | (3) |  |  | (5) |  |
| Net increase (decrease) in cash and cash equivalents | 349 |  |  | (26) |  |  | (107) |  |  | (865) |  |
| Cash and cash equivalents, beginning of period | 1,871 |  |  | 2,531 |  |  | 2,327 |  |  | 3,370 |  |
| Cash and cash equivalents, end of period | $ | 2,220 |  |  | $ | 2,505 |  |  | $ | 2,220 |  |  | $ | 2,505 |  |

[0000106040-23-000014:8k_2_02:54]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:55]
Supplemental Operating Segment Results

[0000106040-23-000014:8k_2_02:56]
(in millions; except percentages; unaudited)

[0000106040-23-000014:8k_2_02:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,307 |  |  | $ | 2,243 |  |  | $ | 4,686 |  |  | $ | 7,353 |  |
| HDD | 1,496 |  |  | 2,138 |  |  | 4,960 |  |  | 6,912 |  |
| Total net revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | (65) |  |  | $ | 798 |  |  | $ | 597 |  |  | $ | 2,665 |  |
| HDD | 363 |  |  | 592 |  |  | 1,237 |  |  | 2,061 |  |
| Total gross profit for segments | 298 |  |  | 1,390 |  |  | 1,834 |  |  | 4,726 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (38) |  |  | (36) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (1) |  |  | (65) |  |
| Contamination related charges | — |  |  | (203) |  |  | — |  |  | (203) |  |
| Recoveries from a power outage incident | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total unallocated corporate items | (12) |  |  | (209) |  |  | (39) |  |  | (297) |  |
| Consolidated gross profit | $ | 286 |  |  | $ | 1,181 |  |  | $ | 1,795 |  |  | $ | 4,429 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | (5.0) | % |  | 35.6 | % |  | 12.7 | % |  | 36.2 | % |
| HDD | 24.3 | % |  | 27.7 | % |  | 24.9 | % |  | 29.8 | % |
| Total gross margin for segments | 10.6 | % |  | 31.7 | % |  | 19.0 | % |  | 33.1 | % |
| Consolidated gross margin | 10.2 | % |  | 27.0 | % |  | 18.6 | % |  | 31.0 | % |

[0000106040-23-000014:8k_2_02:58]
The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”). In the table above, total gross profit for segments and total gross margin for segments are Non-GAAP financial measures, which are also referred to herein as Non-GAAP gross profit and Non-GAAP gross margin, respectively.

[0000106040-23-000014:8k_2_02:59]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:60]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-23-000014:8k_2_02:61]
(in millions; unaudited)

[0000106040-23-000014:8k_2_02:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| GAAP cost of revenue | $ | 2,517 |  |  | $ | 2,579 |  |  | $ | 3,200 |  |  | $ | 7,851 |  |  | $ | 9,836 |  |
| Stock-based compensation expense | (12) |  |  | (12) |  |  | (13) |  |  | (38) |  |  | (36) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | (1) |  |  | (65) |  |
| Contamination related charges | — |  |  | — |  |  | (203) |  |  | — |  |  | (203) |  |
| Recoveries from a power outage incident | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Non-GAAP cost of revenue | $ | 2,505 |  |  | $ | 2,567 |  |  | $ | 2,991 |  |  | $ | 7,812 |  |  | $ | 9,539 |  |
| GAAP gross profit | $ | 286 |  |  | $ | 528 |  |  | $ | 1,181 |  |  | $ | 1,795 |  |  | $ | 4,429 |  |
| Stock-based compensation expense | 12 |  |  | 12 |  |  | 13 |  |  | 38 |  |  | 36 |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | 1 |  |  | 65 |  |
| Contamination related charges | — |  |  | — |  |  | 203 |  |  | — |  |  | 203 |  |
| Recoveries from a power outage incident | — |  |  | — |  |  | (7) |  |  | — |  |  | (7) |  |
| Non-GAAP gross profit | $ | 298 |  |  | $ | 540 |  |  | $ | 1,390 |  |  | $ | 1,834 |  |  | $ | 4,726 |  |
| GAAP operating expenses | $ | 758 |  |  | $ | 849 |  |  | $ | 857 |  |  | $ | 2,430 |  |  | $ | 2,600 |  |
| Stock-based compensation expense | (62) |  |  | (74) |  |  | (73) |  |  | (208) |  |  | (213) |  |
| Amortization of acquired intangible assets | (39) |  |  | (39) |  |  | (39) |  |  | (116) |  |  | (116) |  |
| Employee termination, asset impairment and other charges | (40) |  |  | (76) |  |  | (4) |  |  | (140) |  |  | (24) |  |
| Strategic review | (15) |  |  | — |  |  | — |  |  | (15) |  |  | — |  |
| Other | — |  |  | (1) |  |  | (1) |  |  | (1) |  |  | (5) |  |
| Non-GAAP operating expenses | $ | 602 |  |  | $ | 659 |  |  | $ | 740 |  |  | $ | 1,950 |  |  | $ | 2,242 |  |
| GAAP operating income (loss) | $ | (472) |  |  | $ | (321) |  |  | $ | 324 |  |  | $ | (635) |  |  | $ | 1,829 |  |
| Cost of revenue adjustments | 12 |  |  | 12 |  |  | 209 |  |  | 39 |  |  | 297 |  |
| Operating expense adjustments | 156 |  |  | 190 |  |  | 117 |  |  | 480 |  |  | 358 |  |
| Non-GAAP operating income (loss) | $ | (304) |  |  | $ | (119) |  |  | $ | 650 |  |  | $ | (116) |  |  | $ | 2,484 |  |
| GAAP interest and other expense, net | $ | (57) |  |  | $ | (64) |  |  | $ | (62) |  |  | $ | (195) |  |  | $ | (217) |  |
| Non-cash economic interest and Other | (6) |  |  | — |  |  | (2) |  |  | (7) |  |  | 17 |  |
| Non-GAAP interest and other expense, net | $ | (63) |  |  | $ | (64) |  |  | $ | (64) |  |  | $ | (202) |  |  | $ | (200) |  |
| GAAP income tax expense | $ | 43 |  |  | $ | 61 |  |  | $ | 237 |  |  | $ | 161 |  |  | $ | 413 |  |
| Income tax adjustments | 17 |  |  | (109) |  |  | (172) |  |  | 19 |  |  | (161) |  |
| Non-GAAP income tax expense | $ | 60 |  |  | $ | (48) |  |  | $ | 65 |  |  | $ | 180 |  |  | $ | 252 |  |

[0000106040-23-000014:8k_2_02:63]
WESTERN DIGITAL CORPORATION

[0000106040-23-000014:8k_2_02:64]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-23-000014:8k_2_02:65]
(in millions, except per share amounts; unaudited)

[0000106040-23-000014:8k_2_02:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| GAAP net income (loss) | $ | (572) |  |  | $ | (446) |  |  | $ | 25 |  |  | $ | (991) |  |  | $ | 1,199 |  |
| Stock-based compensation expense | 74 |  |  | 86 |  |  | 86 |  |  | 246 |  |  | 249 |  |
| Amortization of acquired intangible assets | 39 |  |  | 39 |  |  | 39 |  |  | 117 |  |  | 181 |  |
| Contamination related charges | — |  |  | — |  |  | 203 |  |  | — |  |  | 203 |  |
| Recoveries from a power outage incident | — |  |  | — |  |  | (7) |  |  | — |  |  | (7) |  |
| Employee termination, asset impairment and other charges | 40 |  |  | 76 |  |  | 4 |  |  | 140 |  |  | 24 |  |
| Strategic review | 15 |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Non-cash economic interest and Other | (6) |  |  | 1 |  |  | (1) |  |  | (6) |  |  | 22 |  |
| Income tax adjustments | (17) |  |  | 109 |  |  | 172 |  |  | (19) |  |  | 161 |  |
| Non-GAAP net income (loss) | (427) |  |  | (135) |  |  | 521 |  |  | (498) |  |  | 2,032 |  |
| Less: cumulative dividends allocated to preferred shareholders | 9 |  |  | — |  |  | — |  |  | 9 |  |  | — |  |
| Non-GAAP net income (loss) attributable to common shareholders | $ | (436) |  |  | $ | (135) |  |  | $ | 521 |  |  | $ | (507) |  |  | $ | 2,032 |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | (1.82) |  |  | $ | (1.40) |  |  | $ | 0.08 |  |  | $ | (3.14) |  |  | $ | 3.79 |  |
| Non-GAAP | $ | (1.37) |  |  | $ | (0.42) |  |  | $ | 1.65 |  |  | $ | (1.59) |  |  | $ | 6.43 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 319 |  |  | 318 |  |  | 316 |  |  | 318 |  |  | 316 |  |
| Non-GAAP | 319 |  |  | 318 |  |  | 316 |  |  | 318 |  |  | 316 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by operating activities | $ | (381) |  |  | $ | 35 |  |  | $ | 398 |  |  | $ | (340) |  |  | $ | 1,585 |  |
| Purchases of property, plant and equipment, net | (110) |  |  | (258) |  |  | (290) |  |  | (688) |  |  | (829) |  |
| Activity related to Flash Ventures, net | (36) |  |  | (17) |  |  | 40 |  |  | 46 |  |  | 23 |  |
| Free cash flow | $ | (527) |  |  | $ | (240) |  |  | $ | 148 |  |  | $ | (982) |  |  | $ | 779 |  |

[0000106040-23-000014:8k_2_02:67]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth Non-GAAP cost of revenue; Non-GAAP gross profit; Non-GAAP gross margin; Non-GAAP operating expenses; Non-GAAP operating income and loss; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income and loss; Non-GAAP diluted income and loss per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense, amortization of acquired intangible assets, contamination related charges, recoveries from a power outage incident, employee termination, asset impairment and other charges, expenses related to our strategic review, non-cash economic interest, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-23-000014:8k_2_02:68]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-23-000014:8k_2_02:69]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company’s control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0000106040-23-000014:8k_2_02:70]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company’s acquisitions and any related impairment charges.

[0000106040-23-000014:8k_2_02:71]
Contamination related charges. In February 2022, a contamination of certain materials used in the company’s manufacturing process occurred and affected production operation at the flash-based memory manufacturing facilities in Yokkaichi and Kitakami, Japan, which are operated through the company’s joint business ventures with Kioxia Corporation (collectively, "Flash Ventures"). The contamination resulted in scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs, which are expensed as incurred. These charges are inconsistent in amount and frequency, and the company believes these charges are not part of the ongoing production operation of its business.

[0000106040-23-000014:8k_2_02:72]
Recoveries from a power outage incident. In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated through the company’s joint venture with Kioxia Corporation in Yokkaichi, Japan. The power outage incident resulted in costs associated with the repair of damaged tools and the write-off of damaged inventory and unabsorbed manufacturing overhead costs which are expensed as incurred. During fiscal years 2021 and 2022, the company received recoveries for these losses from other parties. The recoveries are inconsistent in amount and frequency, and the company believes they are not part of the ongoing production operation of its business.

[0000106040-23-000014:8k_2_02:73]
Employee termination, asset impairment and other charges. From time-to-time, in order to realign the company’s operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-23-000014:8k_2_02:74]
Strategic review. The company incurred expenses associated with its ongoing review of potential strategic alternatives aimed at further optimizing the long-term value for stockholders. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-23-000014:8k_2_02:75]
Non-cash economic interest. The company has excluded non-cash economic interest expense associated with its convertible notes recognized in periods prior to the company’s adoption of the Financial Accounting Standards Board Accounting Standards Update No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity”, which the company adopted at the beginning of its fiscal year ending June 30, 2023. The exclusion of such amounts from prior periods facilitates a comparison of the company's prior period results to the current period presentation.

[0000106040-23-000014:8k_2_02:76]
Other adjustments. From time-to-time, the company incurs charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-23-000014:8k_2_02:77]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments to estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act and the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-23-000014:8k_2_02:78]
Additionally, free cash flow is defined as cash flows provided by operating activities less purchases of property, plant and equipment, net, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company’s business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-23-000014:8k_2_02:79]
___________________

[0000106040-23-000014:8k_2_02:80]
Contacts:

[0000106040-23-000014:8k_2_02:81]
Western Digital Corp.

[0000106040-23-000014:8k_2_02:82]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Robin Schultz |
| 949.672.9655 |  | 408.573.5043 |
| peter.andrew@wdc.com |  | robin.schultz@wdc.com |
| investor@wdc.com |  |  |
