# WDC MD&A — 0000106040-23-000017


## mdna

[0000106040-23-000017:mdna:1]
[same as prior period, unchanged from 0000106040-23-000010:mdna:1]

[0000106040-23-000017:mdna:2]
[same as prior period, unchanged from 0000106040-23-000010:mdna:2]

[0000106040-23-000017:mdna:3]
[same as prior period, unchanged from 0000106040-23-000010:mdna:3]

[0000106040-23-000017:mdna:4]
[same as prior period, unchanged from 0000106040-23-000010:mdna:4]

[0000106040-23-000017:mdna:5]
[same as prior period, unchanged from 0000106040-23-000010:mdna:5]

[0000106040-23-000017:mdna:6]
[same as prior period, unchanged from 0000106040-23-000010:mdna:6]

[0000106040-23-000017:mdna:7]
Network Security Incident

[0000106040-23-000017:mdna:8]
As previously disclosed, on March 26, 2023, we identified a network security incident in which an unauthorized third party gained access to a number of our systems. Upon discovery of the incident, we implemented incident response efforts, which included taking various systems and services offline as a proactive measure to secure our business operations and initiating an investigation with the assistance of leading outside security and forensic experts. Our forensic investigation is ongoing, as we work to understand the nature and scope of the systems accessed and data accessed or obtained by the unauthorized party, and we are coordinating with law enforcement authorities in connection with our investigation. To date, in collaboration with outside forensic experts, we have confirmed that an unauthorized party obtained a copy of a Western Digital database used for our online store that contained some personal information of our online store customers. This information included customer names, billing and shipping addresses, email addresses and telephone numbers. In addition, the database contained, in encrypted format, hashed and salted passwords and partial credit card numbers. We have provided notifications to impacted customers and relevant governmental authorities.

[0000106040-23-000017:mdna:9]
The incident, together with the incident response efforts discussed above, resulted in some disruptions to our business operations, including manufacturing, sales, fulfillment and general corporate activities. We were able to stabilize core operations after a short period of time, and the incident did not have a material impact on the financial results for the three months ended March 31, 2023. We have continued to bring network systems back online in order of operational priority, and the majority of our impacted systems and services are now operational. The impact on revenues from these disruptions cannot be quantified at this time, but is not currently expected to be material or to have a material impact on our future financial results.

[0000106040-23-000017:mdna:10]
We have incurred and expect to continue to incur investigation, recovery, and remediation expenses, including costs for forensics activities, third party consulting and service providers, outside legal advisors, and other IT professionals, as a result of the network security incident. These costs were nominal in the third quarter and will be primarily incurred in subsequent periods.

[0000106040-23-000017:mdna:11]
We maintain cyber insurance, subject to certain deductibles and policy limitations, typical for our size and industry.

[0000106040-23-000017:mdna:12]
[same as prior period, unchanged from 0000106040-23-000010:mdna:7]

[0000106040-23-000017:mdna:13]
In June 2022, we announced that we are reviewing potential strategic alternatives aimed at further optimizing long-term value for stockholders. The Executive Committee of our Board of Directors is overseeing the assessment process and evaluating a range of alternatives, including options for separating our Flash and HDD business units. As of March 31, 2023, we are still actively working with our financial advisors and our legal counsel in this strategic review process.

[0000106040-23-000017:mdna:14]
Operational Update

[0000106040-23-000017:mdna:15]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry are experiencing a supply-demand imbalance, which has resulted in reduced shipments and negatively impacted pricing, particularly in Flash. Since the beginning of fiscal 2023, we have scaled back on capital expenditures, consolidated production lines and reduced bit growth to align with market demand and implemented measures to reduce operating expenses. This has resulted in incremental charges for Employee termination, asset impairment and other charges and manufacturing underutilization charges in HDD and Flash in the second and third quarters of 2023, and is expected to impact near-term results. However, we believe digital transformation will continue to drive long-term growth for data storage in both Flash and HDD and believe that the actions we are taking will position us for profitable growth as supply and demand levels begin to balance.

[0000106040-23-000017:mdna:16]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. Our hard drive products utilizing OptiNAND and shingled magnetic recording (“SMR”) technologies have commenced commercial shipments and our latest 26-terabyte SMR drives are on track to complete the qualifications at multiple cloud and OEM customers. During the third quarter of 2023, our BiCS6 based products have achieved cost crossover. We have announced the next generation, BiCS8 node, the newest 3D-flash memory technology, that builds upon the success of BiCS5 and BiCS6 to deliver improved performance, capacity, and reliability.

[0000106040-23-000017:mdna:17]
We will continue to actively monitor recent developments impacting our business and may take additional responsive actions that we determine to be in the best interests of our business and stakeholders. See “Adverse global or regional conditions could harm our business” and “We are dependent on a limited number of qualified suppliers who provide critical services, materials or components, and a disruption in our supply chain could negatively affect our business” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended July 1, 2022 for more information regarding the risks we face as a result of macroeconomic conditions, and supply chain disruptions.

[0000106040-23-000017:mdna:18]
[same as prior period, unchanged from 0000106040-23-000010:mdna:14]

[0000106040-23-000017:mdna:19]
In December 2022, we amended the loan agreement governing our revolving credit facility and Term Loan A-2 to modify the leverage ratio requirements of our financial covenant through our quarter ending September 27, 2024 to provide additional financial flexibility as we navigate through the current dynamic economic environment. The amendment also accelerates the due date for amounts outstanding under the loan agreement from January 7, 2027 to November 2, 2023 if, as of that date, our cash and cash equivalents plus available unused capacity under our credit facilities does not exceed by $1 billion the sum of the outstanding balance of our 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. As of March 31, 2023, our cash and cash equivalents plus available unused capacity under our credit facilities exceeded this requirement. Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2022.

[0000106040-23-000017:mdna:20]
On January 25, 2023, we entered into a new delayed draw term loan agreement, which allows us to draw a single unsecured loan of up to $875 million any time through June 30, 2023. Any amount drawn will be due 364 days after funding or such earlier date that conditions for acceleration of amounts due under the loan agreement have been triggered as described above.

[0000106040-23-000017:mdna:21]
On January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. Additional information regarding the terms of our Series A Preferred Stock is included in Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000017:mdna:22]
We believe these transactions will provide us with greater financial flexibility to manage our business.

[0000106040-23-000017:mdna:23]
40

[0000106040-23-000017:mdna:24]
[same as prior period, unchanged from 0000106040-23-000010:mdna:17]

[0000106040-23-000017:mdna:25]
As previously disclosed, we have received statutory notices of deficiency and notices of proposed adjustments from the Internal Revenue Service (“IRS”) with respect to 2008 through 2015. During the third quarter of 2023, we and the IRS reached an agreement on the federal tax and interest calculations with respect to the years 2008 through 2012 and a tentative settlement for the years 2013 through 2015. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 13, Income Tax Expense, of the Notes to the Condensed Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity-Unrecognized Tax Benefits” section below.

[0000106040-23-000017:mdna:26]
[same as prior period, unchanged from 0000106040-23-000010:mdna:19]

[0000106040-23-000017:mdna:27]
[same as prior period, unchanged from 0000106040-23-000010:mdna:20]

[0000106040-23-000017:mdna:28]
[same as prior period, unchanged from 0000106040-23-000010:mdna:21]

[0000106040-23-000017:mdna:29]
Third Quarter and Nine Month Overview

[0000106040-23-000017:mdna:30]
[same as prior period, unchanged from 0000106040-23-000010:mdna:23]

[0000106040-23-000017:mdna:31]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 2,803 |  |  | 100.0 | % |  | $ | 4,381 |  |  | 100.0 | % |  | $ | (1,578) |  |  | (36) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,517 |  |  | 89.8 |  |  | 3,200 |  |  | 73.0 |  |  | (683) |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 286 |  |  | 10.2 |  |  | 1,181 |  |  | 27.0 |  |  | (895) |  |  | (76) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 476 |  |  | 17.0 |  |  | 572 |  |  | 13.1 |  |  | (96) |  |  | (17) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 242 |  |  | 8.6 |  |  | 281 |  |  | 6.4 |  |  | (39) |  |  | (14) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 40 |  |  | 1.4 |  |  | 4 |  |  | 0.1 |  |  | 36 |  |  | 900 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 758 |  |  | 27.0 |  |  | 857 |  |  | 19.6 |  |  | (99) |  |  | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | (472) |  |  | (16.8) |  |  | 324 |  |  | 7.4 |  |  | (796) |  |  | (246) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 0.4 |  |  | 1 |  |  | — |  |  | 9 |  |  | 900 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (80) |  |  | (2.9) |  |  | (75) |  |  | (1.7) |  |  | (5) |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 13 |  |  | 0.5 |  |  | 12 |  |  | 0.3 |  |  | 1 |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (57) |  |  | (2.0) |  |  | (62) |  |  | (1.4) |  |  | 5 |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | (529) |  |  | (18.9) |  |  | 262 |  |  | 6.0 |  |  | (791) |  |  | (302) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 43 |  |  | 1.5 |  |  | 237 |  |  | 5.4 |  |  | (194) |  |  | (82) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | (572) |  |  | (0.2) |  |  | 25 |  |  | — |  |  | (597) |  |  | (24) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 9 |  |  | — |  |  | — |  |  | — |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | (581) |  |  | (20.7) | % |  | $ | 25 |  |  | 0.6 | % |  | $ | (606) |  |  | (2,424) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-23-000017:mdna:32]
[same as prior period, unchanged from 0000106040-23-000010:mdna:25]

[0000106040-23-000017:mdna:33]
|  |  |  | Nine Months Ended |
|  |  |  |  |  |  |  |  |  | March 31,2023 |  | April 1,2022 |  | $ Change |  | % Change |  |  |
|  |  |  | $ in millions |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 9,646 |  |  | 100.0 | % |  | $ | 14,265 |  |  | 100.0 | % |  | $ | (4,619) |  |  | (32) | % |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 7,851 |  |  | 81.4 |  |  | 9,836 |  |  | 69.0 |  |  | (1,985) |  |  | (20) |  |  |  |  |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 1,795 |  |  | 18.6 |  |  | 4,429 |  |  | 31.0 |  |  | (2,634) |  |  | (59) |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 1,551 |  |  | 16.1 |  |  | 1,725 |  |  | 12.1 |  |  | (174) |  |  | (10) |  |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 739 |  |  | 7.7 |  |  | 851 |  |  | 6.0 |  |  | (112) |  |  | (13) |  |  |  |  |  |
| Employee termination, asset impairment, and other charges |  |  |  |  |  |  |  |  |  |  |  |  | 140 |  |  | 1.5 |  |  | 24 |  |  | 0.2 |  |  | 116 |  |  | 483 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 2,430 |  |  | 25.2 |  |  | 2,600 |  |  | 18.2 |  |  | (170) |  |  | (7) |  |  |  |  |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (635) |  |  | (6.6) |  |  | 1,829 |  |  | 12.8 |  |  | (2,464) |  |  | (135) |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 15 |  |  | 0.2 |  |  | 4 |  |  | — |  |  | 11 |  |  | 275 |  |  |  |  |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (223) |  |  | (2.3) |  |  | (229) |  |  | (1.6) |  |  | 6 |  |  | (3) |  |  |  |  |  |
| Other income, net |  |  |  |  |  |  |  |  |  |  |  |  | 13 |  |  | 0.1 |  |  | 8 |  |  | 0.1 |  |  | 5 |  |  | 63 |  |  |  |  |  |
| Total interest and other expense, net |  |  |  |  |  |  |  |  |  |  |  |  | (195) |  |  | (2.0) |  |  | (217) |  |  | (1.5) |  |  | 22 |  |  | (10) |  |  |  |  |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (8.6) |  |  | 1,612 |  |  | 11.3 |  |  | (2,442) |  |  | (151) |  |  |  |  |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 161 |  |  | 1.7 |  |  | 413 |  |  | 2.9 |  |  | (252) |  |  | (61) |  |  |  |  |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (991) |  |  | (10.3) |  |  | 1,199 |  |  | 8.4 |  |  | (2,190) |  |  | (2) |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  |  | — |  |  | — |  |  | — |  |  | 9 |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders |  |  |  |  |  |  |  |  |  |  |  |  | $ | (1,000) |  |  | (10.4) | % |  | $ | 1,199 |  |  | 8.4 | % |  | $ | (2,199) |  |  | (183) | % |  |  |  |  |

[0000106040-23-000017:mdna:34]
[same as prior period, unchanged from 0000106040-23-000010:mdna:28]

[0000106040-23-000017:mdna:35]
42

[0000106040-23-000017:mdna:36]
[same as prior period, unchanged from 0000106040-23-000010:mdna:29]

[0000106040-23-000017:mdna:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,307 |  |  | $ | 2,243 |  |  | $ | 4,686 |  |  | $ | 7,353 |  |
| HDD | 1,496 |  |  | 2,138 |  |  | 4,960 |  |  | 6,912 |  |
| Total net revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | (65) |  |  | $ | 798 |  |  | $ | 597 |  |  | $ | 2,665 |  |
| HDD | 363 |  |  | 592 |  |  | 1,237 |  |  | 2,061 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (38) |  |  | (36) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (1) |  |  | (65) |  |
| Contamination related charges | — |  |  | (203) |  |  | — |  |  | (203) |  |
| Recoveries from a power outage incident | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total unallocated corporate items | (12) |  |  | (209) |  |  | (39) |  |  | (297) |  |
| Consolidated gross profit | $ | 286 |  |  | $ | 1,181 |  |  | $ | 1,795 |  |  | $ | 4,429 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | (5.0) | % |  | 35.6 | % |  | 12.7 | % |  | 36.2 | % |
| HDD | 24.3 | % |  | 27.7 | % |  | 24.9 | % |  | 29.8 | % |
| Consolidated gross margin | 10.2 | % |  | 27.0 | % |  | 18.6 | % |  | 31.0 | % |

[0000106040-23-000017:mdna:38]
[same as prior period, unchanged from 0000106040-23-000010:mdna:31]

[0000106040-23-000017:mdna:39]
[same as prior period, unchanged from 0000106040-23-000010:mdna:32]

[0000106040-23-000017:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | ($ in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,205 |  |  | $ | 1,774 |  |  | $ | 4,258 |  |  | $ | 5,919 |  |
| Client | 975 |  |  | 1,732 |  |  | 3,293 |  |  | 5,439 |  |
| Consumer | 623 |  |  | 875 |  |  | 2,095 |  |  | 2,907 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,353 |  |  | $ | 2,400 |  |  | $ | 4,533 |  |  | $ | 7,685 |  |
| Americas | 935 |  |  | 1,377 |  |  | 3,448 |  |  | 4,398 |  |
| Europe, Middle East and Africa | 515 |  |  | 604 |  |  | 1,665 |  |  | 2,182 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |

[0000106040-23-000017:mdna:41]
Comparison of Three and Nine Months Ended March 31, 2023 to Three and Nine Months Ended April 1, 2022

[0000106040-23-000017:mdna:42]
[same as prior period, unchanged from 0000106040-23-000010:mdna:35]

[0000106040-23-000017:mdna:43]
The decrease in consolidated net revenue for the three and nine months ended March 31, 2023 from the comparable periods in the prior year reflected the current supply-demand imbalance and macroeconomic pressures described in “Operational Update” above.

[0000106040-23-000017:mdna:44]
Flash revenue decreased 42% and 36% for the three and nine months ended March 31, 2023, respectively, from the comparable periods in the prior year. Substantially all of the decline was driven by a decline in average selling prices per gigabyte caused by the macroeconomic pressures noted previously.

[0000106040-23-000017:mdna:45]
HDD revenue decreased 30% and 28% for the three and nine months ended March 31, 2023, respectively from the comparable periods in the prior year primarily as a result of a decline in exabytes shipped of 23% and 22% respectively, primarily driven by lower exabyte shipments to customers in our Cloud end market and to a lesser extent in Client and Consumer end markets.

[0000106040-23-000017:mdna:46]
The decrease in Cloud revenue for the three months ended March 31, 2023 from the comparable period in the prior year reflected a decline in capacity enterprise revenues as customers reduced purchases to right-size their inventories, and to a lesser extent, a decline in bits and pricing for our flash based products. In Client, the decrease in revenue for the three months ended March 31, 2023 from the comparable period in the prior year was driven by pricing pressure across Flash, and a decline in client SSD and HDD shipments for PC applications. In Consumer, the decrease in revenue for the three months ended March 31, 2023 from the comparable period in the prior year primarily reflected the decrease in average selling price per gigabyte in Flash, and to the same extent, a decline in retail HDD shipments.

[0000106040-23-000017:mdna:47]
The decreases in Cloud, Client, and Consumer revenue for the nine months ended March 31, 2023 from the comparable period in the prior year primarily reflected the same drivers noted above for the three-month period.

[0000106040-23-000017:mdna:48]
The changes in net revenue by geography for the three and nine months ended March 31, 2023 from the comparable periods in the prior year reflected a larger decline in Asia from lower Client revenue from OEMs in this region as they reduced purchases to align with current market demand, as well as routine variations in the mix of business.

[0000106040-23-000017:mdna:49]
Our top 10 customers accounted for 49% of our net revenue for the three months ended March 31, 2023, compared to 44% of our net revenue for the three months ended April 1, 2022. Our top 10 customers accounted for 45% of our net revenue for the nine months ended March 31, 2023, compared to 43% of our net revenue for the nine months ended April 1, 2022. For each of the three and nine months ended March 31, 2023 and April 1, 2022, no single customer accounted for 10% or more of our net revenue.

[0000106040-23-000017:mdna:50]
44

[0000106040-23-000017:mdna:51]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 22% and 20% of gross revenue for the three and nine months ended March 31, 2023, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-23-000017:mdna:52]
[same as prior period, unchanged from 0000106040-23-000010:mdna:44]

[0000106040-23-000017:mdna:53]
Consolidated gross profit decreased by $895 million for the three months ended March 31, 2023 from the comparable period in the prior year, which reflected the decrease in revenue described above as well as approximately $275 million for manufacturing underutilization and related charges and a write down of certain Flash inventory to the lower of cost or market value ($213 million in Flash and $62 million in HDD) during the three months ended March 31, 2023, partially offset by $203 million of charges related to a contamination event in the Flash Ventures’ fabrication facilities in the prior year. Consolidated gross margin decreased 16.8 percentage points for the three months ended March 31, 2023 from the comparable period in the prior year, with approximately 5 percentage points of the decline due to the net charges noted above and the remainder primarily driven by the lower average selling prices per gigabyte in Flash. Flash gross margin decreased by 40.6 percentage points year over year, with approximately 7 percentage points of the decline due to the net charges noted above and the remainder driven by the lower average selling prices per gigabyte. HDD gross margin decreased by 3.4 percentage points year over year, substantially all of which related to the charges noted above.

[0000106040-23-000017:mdna:54]
Consolidated gross profit decreased by $2.63 billion for the nine months ended March 31, 2023 from the comparable period in the prior year, which reflected the decrease in revenue described above as well as approximately $375 million for manufacturing underutilization and related charges and a write down of certain Flash inventory to the lower of cost or market value ($213 million in Flash and $162 million in HDD), partially offset by  $203 million of charges related to a contamination event in the Flash Ventures’ fabrication facilities in the prior year, and a $65 million decrease during the nine months ended March 31, 2023 in charges related to amortization expense on acquired intangible assets, some of which became fully amortized. Consolidated gross margin decreased 12.4 percentage points for the nine months ended March 31, 2023 from the comparable period in the prior year, with approximately 2 percentage points of the decline due to the net charges noted above and the remainder driven by the lower average selling prices per gigabyte in Flash. Flash gross margin decreased by 23.5 percentage points year over year, substantially driven by lower average selling prices per gigabyte in Flash. HDD gross margin decreased by 4.9 percentage points year over year, with approximately 3 percentage points of the decline due to the underutilization charge noted above and the remainder primarily reflecting lower average selling prices per gigabyte and variation in the mix of products.

[0000106040-23-000017:mdna:55]
[same as prior period, unchanged from 0000106040-23-000010:mdna:47]

[0000106040-23-000017:mdna:56]
Research and development (“R&D”) expense decreased $96 million for the three months ended March 31, 2023, from the comparable period in the prior year. The declines were primarily driven by reductions in variable compensation expenses, headcount, and material use as we took actions to reduce expenses in the current environment. R&D expense decreased $174 million for nine months ended March 31, 2023 from the comparable period in the prior year. The declines were primarily driven by reductions in variable compensation expenses and material use as we took actions to reduce expenses in the current environment.

[0000106040-23-000017:mdna:57]
Selling, general and administrative (“SG&A”) expense decreased $39 million and $112 million for the three and nine months ended March 31, 2023, respectively, from the comparable periods in the prior year. The declines were primarily driven by reductions in headcount, variable compensation expenses, and material use as we took actions to reduce expenses in the current environment.

[0000106040-23-000017:mdna:58]
Employee termination, asset impairment and other charges increased $36 million and $116 million for the three and nine months ended March 31, 2023, respectively, from the comparable periods in the prior year. The increases were due to restructuring actions taken to adjust our cost structure to align with the current demand environment. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment, and Other Charges of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000017:mdna:59]
[same as prior period, unchanged from 0000106040-23-000010:mdna:51]

[0000106040-23-000017:mdna:60]
Total interest and other expense, net decreased $5 million for the three months ended March 31, 2023 from the comparable period in the prior year, reflecting higher interest income resulting from increases in interest rates as well as available cash from our issuance of the Series A Preferred Stock as discussed in “Key Developments - Financing Activities”. Total interest and other expense, net decreased $22 million for the nine months ended March 31, 2023 from the comparable period in the prior year, reflecting higher interest income noted above as well as lower interest expense as a result of the reduction in debt made late in the prior year, partially offset by higher interest rates.

[0000106040-23-000017:mdna:61]
[same as prior period, unchanged from 0000106040-23-000010:mdna:53]

[0000106040-23-000017:mdna:62]
The Tax Cuts and Jobs Act (the “2017 Act”) includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-23-000017:mdna:63]
[same as prior period, unchanged from 0000106040-23-000010:mdna:55]

[0000106040-23-000017:mdna:64]
[same as prior period, unchanged from 0000106040-23-000010:mdna:56]

[0000106040-23-000017:mdna:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | $ in millions |
| Income (loss) before taxes | $ | (529) |  |  | $ | 262 |  |  | $ | (830) |  |  | $ | 1,612 |  |
| Income tax expense | 43 |  |  | 237 |  |  | 161 |  |  | 413 |  |
| Effective tax rate | (8) | % |  | 90 | % |  | (19) | % |  | 26 | % |

[0000106040-23-000017:mdna:66]
Beginning in fiscal year 2023, the 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and nine months ended March 31, 2023, but did not have a material impact on our effective tax rate. The primary drivers of the difference between the effective tax rate for the three and nine months ended March 31, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031.

[0000106040-23-000017:mdna:67]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 1, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and nine months ended April 1, 2022 includes the discrete effect of a net increase to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of settlement discussions with various tax authorities of $194 million and $219 million, respectively.

[0000106040-23-000017:mdna:68]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for the three and nine months ended March 31, 2023, but did not have a material impact on the effective tax rate in those periods due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-23-000017:mdna:69]
[same as prior period, unchanged from 0000106040-23-000010:mdna:61]

[0000106040-23-000017:mdna:70]
[same as prior period, unchanged from 0000106040-23-000010:mdna:62]

[0000106040-23-000017:mdna:71]
[same as prior period, unchanged from 0000106040-23-000010:mdna:63]

[0000106040-23-000017:mdna:72]
|  | Nine Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (340) |  |  | $ | 1,585 |  |  |  |
| Investing activities | (620) |  |  | (822) |  |  |  |
| Financing activities | 856 |  |  | (1,623) |  |  |  |
| Effect of exchange rate changes on cash | (3) |  |  | (5) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (107) |  |  | $ | (865) |  |  |  |

[0000106040-23-000017:mdna:73]
We and the IRS reached a final agreement resolving the statutory notices of deficiency with respect to fiscal years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to fiscal years 2013 through 2015. We currently expect to pay tax and interest totaling approximately $720 million to $760 million, within the next twelve months, which we expect to be partially offset by reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million in future years. See Part I, Item 1, Note 13, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-23-000017:mdna:74]
[same as prior period, unchanged from 0000106040-23-000010:mdna:66]

[0000106040-23-000017:mdna:75]
As noted previously, we are scaling back on capital expenditures and consolidating production lines and reducing bit growth to align with market demand. We have reduced our expected expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to $2.2 billion for 2023. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we have reduced the expected net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to $800 million during 2023. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-23-000017:mdna:76]
We believe our cash, and cash equivalents including the proceeds from the issuance of our Series A Preferred Stock as discussed in “Key Developments - Financing Activities,” as well as our available credit facilities, including the availability under our new delayed term loan agreement, will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter, as we navigate the current market downturn before returning to profitable operations and positive cash flows when the market normalizes. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended July 1, 2022.

[0000106040-23-000017:mdna:77]
A total of $1.86 billion and $1.82 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of March 31, 2023 and July 1, 2022, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-23-000017:mdna:78]
[same as prior period, unchanged from 0000106040-23-000010:mdna:70]

[0000106040-23-000017:mdna:79]
[same as prior period, unchanged from 0000106040-23-000010:mdna:71]

[0000106040-23-000017:mdna:80]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $298 million for the nine months ended March 31, 2023, as compared to $674 million for the nine months ended April 1, 2022, which largely reflects the reduction in volume of our business. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-23-000017:mdna:81]
|  | Three Months Ended |  |  |
|  | March 31,2023 |  | April 1,2022 |  |  |  |  |
| Days sales outstanding | 52 |  |  | 49 |  |  |  |  |  |
| Days in inventory | 144 |  |  | 104 |  |  |  |  |  |
| Days payables outstanding | (57) |  |  | (63) |  |  |  |  |  |
| Cash conversion cycle | 139 |  |  | 90 |  |  |  |  |  |

[0000106040-23-000017:mdna:82]
[same as prior period, unchanged from 0000106040-23-000010:mdna:74]

[0000106040-23-000017:mdna:83]
For the three months ended March 31, 2023, DSO increased by 3 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO increased by 40 days from the comparable period in the prior year primarily reflecting a decline in products shipped in light of the current market environment. DPO decreased by 6 days from the comparable period in the prior year primarily due to reductions in capital expenditures and routine variations in the timing of purchases and payments during the period.

[0000106040-23-000017:mdna:84]
[same as prior period, unchanged from 0000106040-23-000010:mdna:76]

[0000106040-23-000017:mdna:85]
Net cash used in investing activities for the nine months ended March 31, 2023 primarily consisted of $688 million in capital expenditures, net of disposals, partially offset by a $46 million net decrease in notes receivable issuances to Flash Ventures. Net cash used in investing activities for the nine months ended April 1, 2022 primarily consisted of $829 million in capital expenditures, net of disposals, partially offset by a $23 million net decrease in notes receivable issuances to Flash Ventures.

[0000106040-23-000017:mdna:86]
[same as prior period, unchanged from 0000106040-23-000010:mdna:78]

[0000106040-23-000017:mdna:87]
During the nine months ended March 31, 2023, net cash provided by financing activities primarily consisted of $882 million from issuance of the Series A Preferred Stock and $49 million from the issuance of stock under employee stock plans, partially offset by $69 million used for taxes paid on vested stock awards under employee stock plans. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the period. Cash used in financing activities for the nine months ended April 1, 2022 primarily consisted of $3.47 billion for repayment of debt, as well as $85 million for taxes paid on vested stock awards under employee stock plans offset by net proceeds of $1.89 billion from the issuance of new debt, and $62 million from the issuance of stock under employee stock plans.

[0000106040-23-000017:mdna:88]
[same as prior period, unchanged from 0000106040-23-000010:mdna:80]

[0000106040-23-000017:mdna:89]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000017:mdna:90]
[same as prior period, unchanged from 0000106040-23-000010:mdna:82]

[0000106040-23-000017:mdna:91]
[same as prior period, unchanged from 0000106040-23-000010:mdna:83]

[0000106040-23-000017:mdna:92]
[same as prior period, unchanged from 0000106040-23-000010:mdna:84]

[0000106040-23-000017:mdna:93]
In addition to cash requirements for unrecognized tax benefits and dividend rights with respect to the Series A Preferred Stock discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of March 31, 2023:

[0000106040-23-000017:mdna:94]
|  | Total |  | 1 Year (Remaining Three Months of 2023) |  | 2-3 Years (2024-2025) |  | 4-5 Years (2026-2027) |  | More than 5 Years (Beyond 2027) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,100 |  |  | $ | — |  |  | $ | 1,363 |  |  | $ | 4,738 |  |  | $ | 999 |  |
| Interest on debt | 1,180 |  |  | 44 |  |  | 629 |  |  | 401 |  |  | 106 |  |
| Flash Ventures related commitments(2) | 4,616 |  |  | 1,144 |  |  | 2,480 |  |  | 1,041 |  |  | (49) |  |
| Operating leases | 344 |  |  | 13 |  |  | 94 |  |  | 88 |  |  | 149 |  |
| Purchase obligations and other commitments | 3,115 |  |  | 2,284 |  |  | 571 |  |  | 101 |  |  | 159 |  |
| Mandatory Deemed Repatriation Tax | 661 |  |  | — |  |  | 404 |  |  | 257 |  |  | — |  |
| Total | $ | 17,016 |  |  | $ | 3,485 |  |  | $ | 5,541 |  |  | $ | 6,626 |  |  | $ | 1,364 |  |

[0000106040-23-000017:mdna:95]
[same as prior period, unchanged from 0000106040-23-000010:mdna:87]

[0000106040-23-000017:mdna:96]
[same as prior period, unchanged from 0000106040-23-000010:mdna:88]

[0000106040-23-000017:mdna:97]
Dividend rights

[0000106040-23-000017:mdna:98]
On January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. These shares are entitled to cumulative preferred dividends. See Part I, Item 1, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0000106040-23-000017:mdna:99]
[same as prior period, unchanged from 0000106040-23-000010:mdna:89]

[0000106040-23-000017:mdna:100]
In addition to our existing debt, as of March 31, 2023, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Furthermore, we entered into a delayed draw term loan agreement as noted in “Key Developments - Financing Activities” which provides us with an additional $875 million unsecured term loan available to borrow through June 30, 2023, subject to customary conditions and certain financial covenants under the loan agreement. The agreements governing these credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require certain of our subsidiaries to provide guarantees to the extent the conditions providing for such guarantees are met. Additional information regarding our indebtedness, including information about principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended July 1, 2022. Our delayed draw term loan agreement and the loan agreement governing our revolving credit facility and our Term Loan A-2 due 2027 require us to comply with a leverage ratio financial covenant. As of March 31, 2023, we were in compliance with the applicable financial covenant.

[0000106040-23-000017:mdna:101]
[same as prior period, unchanged from 0000106040-23-000010:mdna:91]

[0000106040-23-000017:mdna:102]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of March 31, 2023, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-23-000017:mdna:103]
[same as prior period, unchanged from 0000106040-23-000010:mdna:93]

[0000106040-23-000017:mdna:104]
[same as prior period, unchanged from 0000106040-23-000010:mdna:94]

[0000106040-23-000017:mdna:105]
[same as prior period, unchanged from 0000106040-23-000010:mdna:95]

[0000106040-23-000017:mdna:106]
[same as prior period, unchanged from 0000106040-23-000010:mdna:96]

[0000106040-23-000017:mdna:107]
|  |  | March 31,2023 |
|  |  | (in millions) |
| 2024 |  | $ | 199 |  |
| 2025 |  | 205 |  |
| 2026 |  | 257 |  |
| Total |  | $ | 661 |  |

[0000106040-23-000017:mdna:108]
[same as prior period, unchanged from 0000106040-23-000010:mdna:98]

[0000106040-23-000017:mdna:109]
[same as prior period, unchanged from 0000106040-23-000010:mdna:99]

[0000106040-23-000017:mdna:110]
As of March 31, 2023, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.02 billion. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of March 31, 2023 was $280 million. Of these amounts, approximately $1.16 billion could result in potential cash payments.

[0000106040-23-000017:mdna:111]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with our foreign subsidiaries and intercompany payable balances for years 2008 through 2015. We and the IRS reached an agreement on the federal tax and interest calculations with respect to years 2008 through 2012 for which we expect to pay tax and interest totaling approximately $620 million to $650 million within the next twelve months. We and the IRS have also reached a tentative settlement for the years 2013 through 2015 for which we expect to pay tax and interest totaling approximately $100 million to $110 million. We are uncertain as to when a final agreement for years 2013 through 2015 will be reached and the exact timing of when these payments will be made. However, we believe it is reasonably likely that these payments may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on our Condensed Consolidated Balance Sheets as of March 31, 2023. This classification and amount may be subject to change in the next twelve months depending on when we are able to reach a final agreement with the IRS. In connection with these settlements, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million in future years.

[0000106040-23-000017:mdna:112]
[same as prior period, unchanged from 0000106040-23-000010:mdna:102]

[0000106040-23-000017:mdna:113]
[same as prior period, unchanged from 0000106040-23-000010:mdna:103]

[0000106040-23-000017:mdna:114]
[same as prior period, unchanged from 0000106040-23-000010:mdna:106]

[0000106040-23-000017:mdna:115]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. See Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk included in this Quarterly Report on Form 10-Q for additional information.

[0000106040-23-000017:mdna:116]
[same as prior period, unchanged from 0000106040-23-000010:mdna:108]

[0000106040-23-000017:mdna:117]
[same as prior period, unchanged from 0000106040-23-000010:mdna:109]

[0000106040-23-000017:mdna:118]
[same as prior period, unchanged from 0000106040-23-000010:mdna:110]

[0000106040-23-000017:mdna:119]
[same as prior period, unchanged from 0000106040-23-000010:mdna:111]

[0000106040-23-000017:mdna:120]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the nine months ended March 31, 2023 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of March 31, 2023 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-23-000017:mdna:121]
[same as prior period, unchanged from 0000106040-23-000010:mdna:113]

[0000106040-23-000017:mdna:122]
[same as prior period, unchanged from 0000106040-23-000010:mdna:114]

[0000106040-23-000017:mdna:123]
[same as prior period, unchanged from 0000106040-23-000010:mdna:115]

[0000106040-23-000017:mdna:124]
[same as prior period, unchanged from 0000106040-23-000010:mdna:116]

[0000106040-23-000017:mdna:125]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the year ended July 1, 2022. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the year ended July 1, 2022 for a discussion of our critical accounting policies and estimates. In addition, as disclosed in Part I, Item 1, Note 3, Business Segments, Geographic Information, and Concentrations of Risk, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, as of March 31, 2023, our management has performed assessments of goodwill for impairment for both the Flash and HDD reporting units. Please refer to that disclosure for additional information on the judgments and estimates included in our assessments.

[0000106040-23-000017:mdna:126]
[same as prior period, unchanged from 0000106040-23-000010:mdna:117]
