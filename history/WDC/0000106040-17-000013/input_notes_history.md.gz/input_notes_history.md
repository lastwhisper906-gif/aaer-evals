# WDC note change history — 0000106040-17-000007 → 0000106040-17-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0000106040-17-000013:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 31, 2017 and July 1, 2016:
  (was, 2017-02-07, similarity 0.965):
[0000106040-17-000007:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 30, 2016 and July 1, 2016:

- changed (2017-05-08):
[0000106040-17-000013:note_history:2]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 232 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 126 |  |  | 235 |  |
| Notes receivable, Flash Forward | 354 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 280 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,291 |  |  | $ | 1,171 |  |
  (was, 2017-02-07, similarity 0.985):
[0000106040-17-000007:note_history:2]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 138 |  |  | 235 |  |
| Notes receivable, Flash Forward | 248 |  |  | 263 |  |
| Investment in Flash Partners | 178 |  |  | 202 |  |
| Investment in Flash Alliance | 267 |  |  | 306 |  |
| Investment in Flash Forward | 106 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,082 |  |  | $ | 1,171 |  |

- changed (2017-05-08):
[0000106040-17-000013:note_history:3]
During the three and nine months ended March 31, 2017, the Company made net payments to Flash Ventures of $727 million and $2.0 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.
  (was, 2017-02-07, similarity 0.8863):
[0000106040-17-000007:note_history:3]
During the three and six months ended December 30, 2016, the Company made net payments to Flash Ventures of $766 million and $1.5 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.

- changed (2017-05-08):
[0000106040-17-000013:note_history:4]
As of March 31, 2017 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $194 million and $168 million, respectively.
  (was, 2017-02-07, similarity 0.9673):
[0000106040-17-000007:note_history:4]
As of December 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $175 million and $168 million, respectively.

- changed (2017-05-08):
[0000106040-17-000013:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2017-02-07, similarity 0.985):
[0000106040-17-000007:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2016, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2017-05-08):
[0000106040-17-000013:note_history:6]
|  | March 31, 2017 |
|  | (in millions) |
| Notes receivable | $ | 712 |  |
| Equity investments | 579 |  |
| Operating lease guarantees | 1,048 |  |
| Prepayments | 23 |  |
| Maximum estimable loss exposure | $ | 2,362 |  |
  (was, 2017-02-07, similarity 0.9727):
[0000106040-17-000007:note_history:6]
|  | December 30, 2016 |
|  | (in millions) |
| Notes receivable | $ | 531 |  |
| Equity investments | 551 |  |
| Operating lease guarantees | 1,102 |  |
| Prepayments | 26 |  |
| Maximum estimable loss exposure | $ | 2,210 |  |

- changed (2017-05-08):
[0000106040-17-000013:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017.
  (was, 2017-02-07, similarity 0.9784):
[0000106040-17-000007:note_history:7]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016.

- changed (2017-05-08):
[0000106040-17-000013:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2017 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017:
  (was, 2017-02-07, similarity 0.9638):
[0000106040-17-000007:note_history:8]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016:

- changed (2017-05-08):
[0000106040-17-000013:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 268 |  |  | $ | 22 |  |  | $ | 290 |  |
| Year 2 |  | 231 |  |  | 15 |  |  | 246 |  |
| Year 3 |  | 173 |  |  | 59 |  |  | 232 |  |
| Year 4 |  | 93 |  |  | 97 |  |  | 190 |  |
| Year 5 |  | 20 |  |  | 70 |  |  | 90 |  |
| Total guarantee obligations |  | $ | 785 |  |  | $ | 263 |  |  | $ | 1,048 |  |
  (was, 2017-02-07, similarity 0.9976):
[0000106040-17-000007:note_history:9]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 269 |  |  | $ | 47 |  |  | $ | 316 |  |
| Year 2 |  | 230 |  |  | — |  |  | 230 |  |
| Year 3 |  | 184 |  |  | 71 |  |  | 255 |  |
| Year 4 |  | 108 |  |  | 58 |  |  | 166 |  |
| Year 5 |  | 33 |  |  | 102 |  |  | 135 |  |
| Total guarantee obligations |  | $ | 824 |  |  | $ | 278 |  |  | $ | 1,102 |  |

- changed (2017-05-08):
[0000106040-17-000013:note_history:10]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2017, no amounts have been accrued in the condensed consolidated financial statements with respect to these indemnification guarantees.
  (was, 2017-02-07, similarity 0.9774):
[0000106040-17-000007:note_history:10]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0000106040-17-000013:note_history:11]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.
  (was, 2017-02-07, similarity 0.9825):
[0000106040-17-000007:note_history:11]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

- changed (2017-05-08):
[0000106040-17-000013:note_history:12]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints - one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California - against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,542; RE45,486; 7,565,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The District Court action has been stayed pending resolution of the ITC proceeding. The Company intends to defend itself vigorously in these matters.
  (was, 2017-02-07, similarity 0.9076):
[0000106040-17-000007:note_history:12]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints – one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California – against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,452; RE45,486; 7,464,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The Company intends to defend itself vigorously in these matters.

- changed (2017-05-08):
[0000106040-17-000013:note_history:13]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue.  In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.
  (was, 2017-02-07, similarity 0.8489):
[0000106040-17-000007:note_history:13]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue.  In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-05-08):
[0000106040-17-000013:note_history:14]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company also generates license and royalty revenue related to its intellectual property.

- changed (2017-05-08):
[0000106040-17-000013:note_history:15]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2017, which ends on June 30, 2017, and 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2017-02-07, similarity 0.9743):
[0000106040-17-000007:note_history:15]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal year 2017, which ends on June 30, 2017, and fiscal year 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- removed (2017-05-08):
[0000106040-17-000007:note_history:16]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the needs of the information technology industry and the infrastructure that enables the storage of data. The Company also generates license and royalty revenue related to its intellectual property.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0000106040-17-000013:note_history:17]
Debt consisted of the following as of March 31, 2017 and July 1, 2016:
  (was, 2017-02-07, similarity 0.928):
[0000106040-17-000007:note_history:17]
Debt consisted of the following as of December 30, 2016 and July 1, 2016:

- changed (2017-05-08):
[0000106040-17-000013:note_history:18]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,978 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 938 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,301 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (213 | ) |  | (532 | ) |
| Subtotal | 13,088 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (181 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,907 |  |  | $ | 13,660 |  |
  (was, 2017-02-07, similarity 0.9932):
[0000106040-17-000007:note_history:18]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,985 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 929 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,299 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (226 | ) |  | (532 | ) |
| Subtotal | 13,073 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (129 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,944 |  |  | $ | 13,660 |  |

- changed (2017-05-08):
[0000106040-17-000013:note_history:19]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of March 31, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2017-02-07, similarity 0.9767):
[0000106040-17-000007:note_history:19]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of December 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

- added (2017-05-08):
[0000106040-17-000013:note_history:20]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

- changed (2017-05-08):
[0000106040-17-000013:note_history:21]
On March 14, 2017, the Company borrowed $2.985 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-1 previously outstanding under the Credit Agreement. The U.S. Term Loan B-2 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 2.75% or a base rate plus 1.75% (3.73% as of March 31, 2017). Principal payments on U.S. Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-2 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $2 million remain unamortized.
  (was, 2017-02-07, similarity 0.9508):
[0000106040-17-000007:note_history:21]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.52% as of December 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $6 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $5 million remain unamortized.

- changed (2017-05-08):
[0000106040-17-000013:note_history:22]
On March 23, 2017, the Company borrowed €881 million under a new Euro-denominated term loan (“Euro Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B-1 previously outstanding under the Credit Agreement. The Euro Term Loan B-2 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 2.00% (2.75% as of March 31, 2017). Principal payments on Euro Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The Euro Term Loan B-2 issuance costs of $1 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $1 million remain unamortized.
  (was, 2017-02-07, similarity 0.8575):
[0000106040-17-000007:note_history:22]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% as of December 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $2 million remain unamortized.

- added (2017-05-08):
[0000106040-17-000013:note_history:23]
In connection with the settlement of the U.S. Term Loan B-1 and Euro Term Loan B-1, the Company recognized a loss of $7 million consisting of unamortized issuance costs and debt discount fees.

- changed (2017-05-08):
[0000106040-17-000013:note_history:24]
As of March 31, 2017, the revolving credit facility was not drawn upon, and there was no outstanding balance.
  (was, 2017-02-07, similarity 0.9569):
[0000106040-17-000007:note_history:24]
As of December 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance.

- changed (2017-05-08):
[0000106040-17-000013:note_history:25]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of March 31, 2017, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.98%.
  (was, 2017-02-07, similarity 0.9793):
[0000106040-17-000007:note_history:25]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of December 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.775%.

- changed (2017-05-08):
[0000106040-17-000013:note_history:26]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-2 and the Euro Term Loan B-2 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before September 14, 2017, with respect to U.S. Term Loan B-2, and September 23, 2017, with respect to Euro Term Loan B-2.
  (was, 2017-02-07, similarity 0.9681):
[0000106040-17-000007:note_history:26]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

- changed (2017-05-08):
[0000106040-17-000013:note_history:27]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. On February 6, 2017, the exchange offer expired and substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.
  (was, 2017-02-07, similarity 0.8472):
[0000106040-17-000007:note_history:27]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. On February 6, 2017, substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.

- changed (2017-05-08):
[0000106040-17-000013:note_history:28]
During the three months ended March 31, 2017, the Company repurchased an immaterial amount of the 2017 Notes. During the nine months ended March 31, 2017, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $494 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.
  (was, 2017-02-07, similarity 0.8006):
[0000106040-17-000007:note_history:28]
During the three months ended December 30, 2016, the Company repurchased Convertible Notes for $3 million of cash. During the six months ended December 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $493 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

- changed (2017-05-08):
[0000106040-17-000013:note_history:29]
As of March 31, 2017, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.
  (was, 2017-02-07, similarity 0.9854):
[0000106040-17-000007:note_history:29]
As of December 30, 2016, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

- changed (2017-05-08):
[0000106040-17-000013:note_history:30]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and nine months ended March 31, 2017, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial loss.
  (was, 2017-02-07, similarity 0.9875):
[0000106040-17-000007:note_history:30]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and six months ended December 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.

- changed (2017-05-08):
[0000106040-17-000013:note_history:31]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the nine months ended March 31, 2017, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and nine months ended March 31, 2017, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of March 31, 2017 was immaterial.
  (was, 2017-02-07, similarity 0.9503):
[0000106040-17-000007:note_history:31]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the six months ended December 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and six months ended December 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of December 30, 2016 was immaterial.

- changed (2017-05-08):
[0000106040-17-000013:note_history:32]
The conversion and repurchase of the Convertible Notes and related settlement of the call options during the three and nine months ended March 31, 2017 resulted in an immaterial net loss.
  (was, 2017-02-07, similarity 0.9286):
[0000106040-17-000007:note_history:32]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three and six months ended December 30, 2016 resulted in an immaterial net loss.

- removed (2017-05-08):
[0000106040-17-000007:note_history:33]
In the first quarter ended September 30, 2016, the Company settled in full the principal amounts of the $3.75 billion U.S. Term Loan B and the €885 million Euro Term Loan B, plus accrued interest. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0000106040-17-000013:note_history:34]
Debt consisted of the following as of March 31, 2017 and July 1, 2016:
  (was, 2017-02-07, similarity 0.928):
[0000106040-17-000007:note_history:34]
Debt consisted of the following as of December 30, 2016 and July 1, 2016:

- changed (2017-05-08):
[0000106040-17-000013:note_history:35]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,978 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 938 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,301 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (213 | ) |  | (532 | ) |
| Subtotal | 13,088 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (181 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,907 |  |  | $ | 13,660 |  |
  (was, 2017-02-07, similarity 0.9932):
[0000106040-17-000007:note_history:35]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,985 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 929 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,299 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (226 | ) |  | (532 | ) |
| Subtotal | 13,073 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (129 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,944 |  |  | $ | 13,660 |  |

- changed (2017-05-08):
[0000106040-17-000013:note_history:36]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of March 31, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2017-02-07, similarity 0.9767):
[0000106040-17-000007:note_history:36]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of December 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0000106040-17-000013:note_history:37]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 31, 2017 and July 1, 2016:
  (was, 2017-02-07, similarity 0.965):
[0000106040-17-000007:note_history:37]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 30, 2016 and July 1, 2016:

- changed (2017-05-08):
[0000106040-17-000013:note_history:38]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 232 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 126 |  |  | 235 |  |
| Notes receivable, Flash Forward | 354 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 280 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,291 |  |  | $ | 1,171 |  |
  (was, 2017-02-07, similarity 0.985):
[0000106040-17-000007:note_history:38]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 138 |  |  | 235 |  |
| Notes receivable, Flash Forward | 248 |  |  | 263 |  |
| Investment in Flash Partners | 178 |  |  | 202 |  |
| Investment in Flash Alliance | 267 |  |  | 306 |  |
| Investment in Flash Forward | 106 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,082 |  |  | $ | 1,171 |  |
