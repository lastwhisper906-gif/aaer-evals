# WDC MD&A — 0000106040-17-000013


## mdna

[0000106040-17-000013:mdna:1]
[same as prior period, unchanged from 0000106040-17-000007:mdna:1]

[0000106040-17-000013:mdna:2]
[same as prior period, unchanged from 0000106040-17-000007:mdna:2]

[0000106040-17-000013:mdna:3]
[same as prior period, unchanged from 0000106040-17-000007:mdna:3]

[0000106040-17-000013:mdna:4]
[same as prior period, unchanged from 0000106040-17-000007:mdna:4]

[0000106040-17-000013:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2017, which ends on June 30, 2017, and 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-17-000013:mdna:6]
[same as prior period, unchanged from 0000106040-17-000007:mdna:6]

[0000106040-17-000013:mdna:7]
[same as prior period, unchanged from 0000106040-17-000007:mdna:7]

[0000106040-17-000013:mdna:8]
During the first nine months of 2017, we settled certain debt facilities and entered into new debt facilities at lower rates. The financing arrangement activities during the first nine months of 2017 were:

[0000106040-17-000013:mdna:9]
[same as prior period, unchanged from 0000106040-17-000007:mdna:9]

[0000106040-17-000013:mdna:10]
| • | We settled our $3.750 billion U.S. Term Loan B tranche with a new issuance of a $3.0 billion seven-year U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) at an interest rate lower than our U.S. Term Loan B tranche in the first quarter of 2017. Proceeds from this new loan and a voluntary cash prepayment of $750 million were used to settle our U.S. Term Loan B tranche. In the third quarter of 2017, we settled the outstanding balance of $2.985 billion of our U.S. Term Loan B-1 tranche for a new issuance of a $2.985 billion six-year U.S. dollar-denominated term loan (“U.S. Term Loan B-2”) at an interest rate lower than our U.S. Term Loan B-1 tranche. |

[0000106040-17-000013:mdna:11]
| • | We settled our €885 million Euro Term Loan B tranche with a new issuance of a €885 million seven-year Euro-denominated term loan (“Euro Term Loan B-1”) at an interest rate lower than our Euro Term Loan B tranche in the first quarter of 2017. In the third quarter of 2017, we settled the outstanding balance of €881 million of our Euro Term Loan B-1 tranche for a new issuance of a €881 million six-year Euro-denominated term loan (“Euro Term Loan B-2”) at an interest rate lower than our Euro Term Loan B-1 tranche. |

[0000106040-17-000013:mdna:12]
| • | We paid to the holders of our Convertible Notes (as defined below), for conversion and repurchase, $494 million of cash and 0.3 million shares of our common stock with an aggregate value of $16 million. In conjunction with the settlements, we received from the exercise of the related call options, $61 million of cash and 0.1 million shares of our common stock which had an aggregate value of $11 million. |

[0000106040-17-000013:mdna:13]
[same as prior period, unchanged from 0000106040-17-000007:mdna:13]

[0000106040-17-000013:mdna:14]
[same as prior period, unchanged from 0000106040-17-000007:mdna:21]

[0000106040-17-000013:mdna:15]
[same as prior period, unchanged from 0000106040-17-000007:mdna:15]

[0000106040-17-000013:mdna:16]
Third Quarter and First Nine Months Overview

[0000106040-17-000013:mdna:17]
[same as prior period, unchanged from 0000106040-17-000007:mdna:17]

[0000106040-17-000013:mdna:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | % Change |  | March 31, 2017 |  | April 1, 2016 |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 4,649 |  |  | 100.0 | % |  | $ | 2,822 |  |  | 100.0 | % |  | 65 | % |  | $ | 14,251 |  |  | 100.0 | % |  | $ | 9,499 |  |  | 100.0 | % |  | 50 | % |
| Gross profit | 1,523 |  |  | 32.8 |  |  | 753 |  |  | 26.7 |  |  | 102 |  |  | 4,391 |  |  | 30.8 |  |  | 2,614 |  |  | 27.5 |  |  | 68 |  |
| Total operating expenses | 998 |  |  | 21.5 |  |  | 665 |  |  | 23.6 |  |  | 50 |  |  | 3,089 |  |  | 21.7 |  |  | 1,953 |  |  | 20.6 |  |  | 58 |  |
| Operating income | 525 |  |  | 11.3 |  |  | 88 |  |  | 3.1 |  |  | 497 |  |  | 1,302 |  |  | 9.1 |  |  | 661 |  |  | 7.0 |  |  | 97 |  |
| Net income | 248 |  |  | 5.3 |  |  | 74 |  |  | 2.6 |  |  | 235 |  |  | 117 |  |  | 0.8 |  |  | 608 |  |  | 6.4 |  |  | (81 | ) |

[0000106040-17-000013:mdna:19]
The following table sets forth, for the periods presented, summary information regarding net revenues by geography and end market:

[0000106040-17-000013:mdna:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 4,649 |  |  | $ | 2,822 |  |  | $ | 14,251 |  |  | $ | 9,499 |  |
| Revenues by Geography (%) |  |  |  |  |  |  |  |
| Americas | 38 | % |  | 30 | % |  | 39 | % |  | 30 | % |
| Europe, Middle East and Africa | 18 |  |  | 23 |  |  | 17 |  |  | 22 |  |
| Asia | 44 |  |  | 47 |  |  | 44 |  |  | 48 |  |
| Revenues by End Market (%) |  |  |  |  |  |  |  |
| Client Devices | 50 | % |  | 49 | % |  | 50 | % |  | 48 | % |
| Client Solutions | 22 |  |  | 12 |  |  | 21 |  |  | 13 |  |
| Data Center Devices & Solutions | 28 |  |  | 39 |  |  | 29 |  |  | 39 |  |
| Exabytes Shipped | 74 |  |  | 63 |  |  | 232 |  |  | 196 |  |

[0000106040-17-000013:mdna:21]
[same as prior period, unchanged from 0000106040-17-000007:mdna:33]

[0000106040-17-000013:mdna:22]
[same as prior period, unchanged from 0000106040-17-000007:mdna:22]

[0000106040-17-000013:mdna:23]
Net revenue for the three months ended March 31, 2017 increased $1.8 billion, or 65%, as compared to the same period in 2016, which reflects an increase from NAND-flash products from our acquisition of SanDisk, partially offset by lower revenues related to lower personal computer (“PC”) and enterprise HDD shipments.

[0000106040-17-000013:mdna:24]
Net revenue for the nine months ended March 31, 2017 increased $4.8 billion, or 50%, as compared to the same period in 2016, which reflects an increase from NAND-flash products from our acquisition of SanDisk, partially offset by lower revenues related to lower PC and enterprise HDD shipments.

[0000106040-17-000013:mdna:25]
For the three and nine months ended March 31, 2017 and for the nine months ended April 1, 2016, no customer accounted for 10% or more of our net revenue. For the three months ended April 1, 2016, one customer, Hewlett Packard Enterprise Development LP, accounted for 10% of our net revenue. For each of the three and nine months ended March 31, 2017, our top 10 customers accounted for 41% of our net revenue. For the three and nine months ended April 1, 2016, our top 10 customers accounted for 45% and 44%, respectively, of our net revenue.

[0000106040-17-000013:mdna:26]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended March 31, 2017, these programs represented 11% and 13%, respectively, of gross revenues. For the three and nine months ended April 1, 2016, these programs represented 14% and 13%, respectively, of gross revenues. The decrease in sales incentive and marketing programs year-over-year reflects lower incentive programs offered on NAND-flash products as a result of our acquisition of SanDisk. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-17-000013:mdna:27]
[same as prior period, unchanged from 0000106040-17-000007:mdna:27]

[0000106040-17-000013:mdna:28]
Changes in the mix of net revenue by geography for the three and nine months ended March 31, 2017, as compared to the same periods in 2016, reflect the additional revenues from our acquisition of SanDisk which has comparatively higher revenue in the Americas than our pre-acquisition business.

[0000106040-17-000013:mdna:29]
[same as prior period, unchanged from 0000106040-17-000007:mdna:29]

[0000106040-17-000013:mdna:30]
Changes in the mix of net revenue by end market for the three and nine months ended March 31, 2017, as compared to the same periods in 2016, reflect the increase in revenues from our acquisition of SanDisk which has comparatively higher revenue in Client Devices and Client Solutions than our pre-acquisition business.

[0000106040-17-000013:mdna:31]
[same as prior period, unchanged from 0000106040-17-000007:mdna:31]

[0000106040-17-000013:mdna:32]
Gross profit for the three months ended March 31, 2017 was $1.5 billion, an increase of $770 million as compared to the same period in 2016. Gross margin was 32.8% for the three months ended March 31, 2017, as compared to 26.7% for the same period in 2016. The increase in gross margin was due primarily to higher margins on NAND-flash products from our acquisition of SanDisk and cost improvements resulting from integration activities. Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives, and other charges, which aggregated $303 million, or 6.5% of revenue, for the three months ended March 31, 2017, and $43 million, or 1.5% of revenue, for the three months ended April 1, 2016.

[0000106040-17-000013:mdna:33]
Gross profit for the nine months ended March 31, 2017 was $4.4 billion, an increase of $1.8 billion as compared to the same period in 2016. Gross margin was 30.8% for the nine months ended March 31, 2017, as compared to 27.5% for the same period in 2016. The increase in gross margin was due primarily to higher margins on NAND-flash products from our acquisition of SanDisk and cost improvements resulting from integration activities. Gross profit for the nine months ended March 31, 2017 was negatively impacted by amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, stock-based compensation and acquisition related charges, which aggregated $826 million, or 5.8% of revenue, for the nine months ended March 31, 2017, and $104 million, or 1.1% of revenue, for the nine months ended April 1, 2016.

[0000106040-17-000013:mdna:34]
[same as prior period, unchanged from 0000106040-17-000007:mdna:35]

[0000106040-17-000013:mdna:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  |  |  | March 31, 2017 |  | April 1, 2016 |  |  |
|  | Amount |  | % of Rev (1) |  | Amount |  | % of Rev (1) |  | % Change |  | Amount |  | % of Rev (1) |  | Amount |  | % of Rev (1) |  | % Change |
|  | (in millions, except percentages) |
| Research and development | $ | 613 |  |  | 13.2 | % |  | $ | 359 |  |  | 12.7 | % |  | 71 | % |  | $ | 1,837 |  |  | 12.9 | % |  | $ | 1,133 |  |  | 11.9 | % |  | 62 | % |
| Selling, general, and administrative | 346 |  |  | 7.4 |  |  | 166 |  |  | 5.9 |  |  | 108 |  |  | 1,100 |  |  | 7.7 |  |  | 597 |  |  | 6.3 |  |  | 84 |  |
| Employee termination, asset impairment, and other charges | 39 |  |  | 0.8 |  |  | 140 |  |  | 5.0 |  |  | (72 | ) |  | 152 |  |  | 1.1 |  |  | 223 |  |  | 2.3 |  |  | (32 | ) |
| Total operating expenses | $ | 998 |  |  | 21.5 |  |  | $ | 665 |  |  | 23.6 |  |  | 50 |  |  | $ | 3,089 |  |  | 21.7 |  |  | $ | 1,953 |  |  | 20.6 |  |  | 58 |  |

[0000106040-17-000013:mdna:36]
| (1) | Percentages may not total due to rounding. |

[0000106040-17-000013:mdna:37]
The increase in research and development (“R&D”) expense in the three and nine months ended March 31, 2017, as compared to the same periods in 2016, was primarily related to our acquisition of SanDisk and continued development of NAND technology. The three and nine months ended March 31, 2017 also included aggregate charges of $47 million and $149 million, respectively, related to share-based compensation expenses, charges related to the implementation of cost-saving initiatives and acquisition-related charges. These costs were partially offset by cost reductions from our integration activities. The three and nine months ended April 1, 2016 also included aggregate charges of $30 million and $65 million, respectively, related to share-based compensation expenses, charges related to the implementation of cost-saving initiatives and other charges.

[0000106040-17-000013:mdna:38]
The increase in selling, general, and administrative (“SG&A”) expense in the three and nine months ended March 31, 2017, as compared to the same periods in 2016, was primarily related to our acquisition of SanDisk. The three and nine months ended March 31, 2017 also included aggregate charges of $101 million and $317 million, respectively, related to share-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives and acquisition-related charges. These costs were partially offset by cost reductions from our integration activities. The three and nine months ended April 1, 2016 also included aggregate charges of $40 million and $158 million, respectively, related to share-based compensation expenses, acquisition-related charges, charges related to an arbitration award, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives and other charges.

[0000106040-17-000013:mdna:39]
Employee termination and other charges were $39 million and $152 million in the three and nine months ended March 31, 2017, respectively, a decrease of $101 million and $71 million from the three and nine months ended April 1, 2016, respectively. The charges relate to our 2016 restructuring plan associated with the integration and business realignment of substantial portions of our business and closing of our head component front end wafer manufacturing facility in Odawara, Japan. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 13 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000013:mdna:40]
[same as prior period, unchanged from 0000106040-17-000007:mdna:41]

[0000106040-17-000013:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  |  |  | March 31, 2017 |  | April 1, 2016 |  |  |
|  | Amount |  | % of Rev (1) |  | Amount |  | % of Rev (1) |  | % Change |  | Amount |  | % of Rev (1) |  | Amount |  | % of Rev (1) |  | % Change |
|  | (in millions, except percentages) |
| Interest income | $ | 7 |  |  | 0.2 | % |  | $ | 6 |  |  | 0.2 | % |  | 17 | % |  | $ | 17 |  |  | 0.1 | % |  | $ | 15 |  |  | 0.2 | % |  | 13 | % |
| Interest expense | (205 | ) |  | (4.4 | ) |  | (14 | ) |  | (0.5 | ) |  | ** |  | (646 | ) |  | (4.5 | ) |  | (40 | ) |  | (0.4 | ) |  | ** |
| Other income (expense), net | (23 | ) |  | (0.5 | ) |  | — |  |  | — |  |  | ** |  | (319 | ) |  | (2.2 | ) |  | 2 |  |  | — |  |  | ** |
| Total interest and other expense, net | $ | (221 | ) |  | (4.8 | ) |  | $ | (8 | ) |  | (0.3 | ) |  | ** |  | $ | (948 | ) |  | (6.7 | ) |  | $ | (23 | ) |  | (0.2 | ) |  | ** |

[0000106040-17-000013:mdna:42]
| (1) | Percentages may not total due to rounding. |

[0000106040-17-000013:mdna:43]
[same as prior period, unchanged from 0000106040-17-000007:mdna:43]

[0000106040-17-000013:mdna:44]
Interest expense increased for the three and nine months ended March 31, 2017, as compared to the same period in 2016, primarily due to the additional debt issued in connection with the acquisition of SanDisk.

[0000106040-17-000013:mdna:45]
Other income (expense), net for the three months ended March 31, 2017 was primarily comprised of foreign exchange losses, write-off of debt issuance costs on the settlements of U.S. Term Loan B-1 and Euro Term Loan B-1, and impairment charges related to our private-equity investments. Other income (expense), net for the nine months ended March 31, 2017 was primarily comprised of the write-off of debt issuance costs on the settlements of U.S. Term Loan B, U.S. Term Loan B-1, Euro Term Loan B, and Euro Term Loan B-1, loss on the settlement of our convertible debt instruments, foreign exchange losses, and impairment charges related to our private-equity investments.

[0000106040-17-000013:mdna:46]
53

[0000106040-17-000013:mdna:47]
Income Tax Expense

[0000106040-17-000013:mdna:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  |  |  | March 31, 2017 |  | April 1, 2016 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Income tax expense | $ | 56 |  |  | 1.2 | % |  | $ | 6 |  |  | 0.2 | % |  | ** |  | $ | 237 |  |  | 1.7 | % |  | $ | 30 |  |  | 0.3 | % |  | ** |
| Effective tax rate | 18 | % |  |  |  | 8 | % |  |  |  |  |  | 67 | % |  |  |  | 5 | % |  |  |  |  |

[0000106040-17-000013:mdna:49]
[same as prior period, unchanged from 0000106040-17-000007:mdna:48]

[0000106040-17-000013:mdna:50]
Income tax expense of $237 million for the nine months ended March 31, 2017 is attributable primarily to discrete effects consisting of income tax expense from the integration of SanDisk of $91 million and a valuation allowance on acquired tax attributes of $111 million. Income tax expense related to the SanDisk integration is partially offset by an income tax benefit of $98 million from deductible debt issuance costs, debt discounts and prepayment fees from debt refinancing.

[0000106040-17-000013:mdna:51]
The primary drivers for the difference between the effective tax rate for the three and nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% are the current year generation of tax credits, tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2017 through 2029, for both periods, and the discrete items described above for the nine months ended March 31, 2017. For the three and nine months ended April 1, 2016, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to current year generation of tax credits and tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2017 through 2029.

[0000106040-17-000013:mdna:52]
[same as prior period, unchanged from 0000106040-17-000007:mdna:51]

[0000106040-17-000013:mdna:53]
[same as prior period, unchanged from 0000106040-17-000007:mdna:52]

[0000106040-17-000013:mdna:54]
The following table summarizes our statements of cash flows for the nine months ended March 31, 2017 and April 1, 2016:

[0000106040-17-000013:mdna:55]
|  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 2,498 |  |  | $ | 1,628 |  |
| Investing activities | (446 | ) |  | (11 | ) |
| Financing activities | (4,546 | ) |  | (754 | ) |
| Effect of exchange rate changes on cash | (5 | ) |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | (2,499 | ) |  | $ | 863 |  |

[0000106040-17-000013:mdna:56]
[same as prior period, unchanged from 0000106040-17-000007:mdna:55]

[0000106040-17-000013:mdna:57]
The indebtedness used to finance our acquisition of SanDisk could cause us to place more reliance on cash generated from operations to pay principal and interest on our debt, thereby reducing the availability of our cash flow for working capital, capital expenditure needs, dividends, or to pursue other potential strategic plans.

[0000106040-17-000013:mdna:58]
During 2017, we expect cash used for purchases of property, plant and equipment, and net activity in notes receivable and equity investments relating to our business ventures with Toshiba Corporation (“Flash Ventures”) to be approximately $0.5 billion to $0.9 billion of our cash. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-17-000013:mdna:59]
A total of $4.3 billion and $6.9 billion of our cash and cash equivalents was held outside of the U.S. as of March 31, 2017 and July 1, 2016, respectively. Our current plans anticipate we can meet our U.S. cash needs while continuing to permanently reinvest the undistributed earnings of our foreign subsidiaries. In the event the reinvested earnings of our foreign subsidiaries are distributed to the U.S., such a distribution could result in the accrual and payment of additional taxes.

[0000106040-17-000013:mdna:60]
[same as prior period, unchanged from 0000106040-17-000007:mdna:59]

[0000106040-17-000013:mdna:61]
Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by changes in working capital was $71 million for the nine months ended March 31, 2017, as compared to $130 million for the nine months ended April 1, 2016.

[0000106040-17-000013:mdna:62]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles for the nine months ended March 31, 2017 and April 1, 2016 were as follows:

[0000106040-17-000013:mdna:63]
|  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |
|  | (in days) |
| Days sales outstanding | 37 |  |  | 36 |  |
| Days in inventory | 62 |  |  | 49 |  |
| Days payables outstanding | (67 | ) |  | (63 | ) |
| Cash conversion cycle | 32 |  |  | 22 |  |

[0000106040-17-000013:mdna:64]
For the nine months ended March 31, 2017, our days sales outstanding (“DSOs”) increased by 1 day, days in inventory (“DIOs”) increased by 13 days and days payables outstanding (“DPOs”) increased by 4 days, as compared to the prior year. Changes in DSOs are generally due to the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-17-000013:mdna:65]
[same as prior period, unchanged from 0000106040-17-000007:mdna:64]

[0000106040-17-000013:mdna:66]
Net cash used in investing activities in the nine months ended March 31, 2017 was $446 million, as compared to $11 million net cash used in investing activities in the nine months ended April 1, 2016. During the nine months ended March 31, 2017, net cash used in investing activities primarily consisted of $453 million of capital expenditures and a net $224 million increase in notes receivable to and investments in Flash Ventures, partially offset by a net $231 million decrease in our investments in marketable securities. During the nine months ended April 1, 2016, net cash used in investing activities primarily consisted of $433 million of capital expenditures and a net $445 million increase in investments in marketable securities.

[0000106040-17-000013:mdna:67]
Our cash equivalents are primarily invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds.

[0000106040-17-000013:mdna:68]
[same as prior period, unchanged from 0000106040-17-000007:mdna:67]

[0000106040-17-000013:mdna:69]
Net cash used in financing activities was $4.5 billion in the nine months ended March 31, 2017, as compared to net cash used in financing activities of $754 million in the nine months ended April 1, 2016. During the nine months ended March 31, 2017, net cash used in financing activities consisted of $12.2 billion to repay debt and $428 million to pay dividends on our common stock, partially offset by $7.9 billion of proceeds from debt, net of issuance costs, $61 million of proceeds from call options and a net $102 million provided by employee stock plans. During the nine months ended April 1, 2016, net cash used in financing activities primarily consisted of $347 million to pay dividends on our common stock, $60 million to repurchase shares of our common stock and $364 million to repay debt.

[0000106040-17-000013:mdna:70]
[same as prior period, unchanged from 0000106040-17-000007:mdna:69]

[0000106040-17-000013:mdna:71]
[same as prior period, unchanged from 0000106040-17-000007:mdna:70]

[0000106040-17-000013:mdna:72]
[same as prior period, unchanged from 0000106040-17-000007:mdna:95]

[0000106040-17-000013:mdna:73]
[same as prior period, unchanged from 0000106040-17-000007:mdna:72]

[0000106040-17-000013:mdna:74]
[same as prior period, unchanged from 0000106040-17-000007:mdna:73]

[0000106040-17-000013:mdna:75]
The following is a summary of our known contractual cash obligations and commercial commitments as of March 31, 2017:

[0000106040-17-000013:mdna:76]
|  | Total |  | 1 Year (Remaining 3 months of 2017) |  | 2-3 Years (2018-2019) |  | 4-5 Years (2020-2021) |  | More than 5 Years (Beyond 2021) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 13,301 |  |  | $ | 10 |  |  | $ | 595 |  |  | $ | 3,724 |  |  | $ | 8,972 |  |
| Interest on debt | 4,865 |  |  | 189 |  |  | 1,576 |  |  | 1,571 |  |  | 1,529 |  |
| Flash Ventures and other related commitments(1) | 7,312 |  |  | 371 |  |  | 4,208 |  |  | 1,826 |  |  | 907 |  |
| Operating leases | 177 |  |  | 27 |  |  | 80 |  |  | 47 |  |  | 23 |  |
| Purchase obligations | 895 |  |  | 859 |  |  | 35 |  |  | 1 |  |  | — |  |
| Total | $ | 26,550 |  |  | $ | 1,456 |  |  | $ | 6,494 |  |  | $ | 7,169 |  |  | $ | 11,431 |  |

[0000106040-17-000013:mdna:77]
[same as prior period, unchanged from 0000106040-17-000007:mdna:76]

[0000106040-17-000013:mdna:78]
[same as prior period, unchanged from 0000106040-17-000007:mdna:77]

[0000106040-17-000013:mdna:79]
The Credit Agreement (as defined in Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q) requires us to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require us to comply with customary covenants that limit or restrict us and our subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. As of March 31, 2017, we were in compliance with these covenants.

[0000106040-17-000013:mdna:80]
[same as prior period, unchanged from 0000106040-17-000007:mdna:79]

[0000106040-17-000013:mdna:81]
[same as prior period, unchanged from 0000106040-17-000007:mdna:80]

[0000106040-17-000013:mdna:82]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of March 31, 2017, we were in compliance with all covenants under these Japanese lease facilities.

[0000106040-17-000013:mdna:83]
[same as prior period, unchanged from 0000106040-17-000007:mdna:82]

[0000106040-17-000013:mdna:84]
[same as prior period, unchanged from 0000106040-17-000007:mdna:83]

[0000106040-17-000013:mdna:85]
[same as prior period, unchanged from 0000106040-17-000007:mdna:84]

[0000106040-17-000013:mdna:86]
[same as prior period, unchanged from 0000106040-17-000007:mdna:85]

[0000106040-17-000013:mdna:87]
[same as prior period, unchanged from 0000106040-17-000007:mdna:86]

[0000106040-17-000013:mdna:88]
[same as prior period, unchanged from 0000106040-17-000007:mdna:87]

[0000106040-17-000013:mdna:89]
[same as prior period, unchanged from 0000106040-17-000007:mdna:88]

[0000106040-17-000013:mdna:90]
As of March 31, 2017, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $597 million, of which $467 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 10 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000013:mdna:91]
[same as prior period, unchanged from 0000106040-17-000007:mdna:90]

[0000106040-17-000013:mdna:92]
Since the first quarter of 2014, we have issued a quarterly cash dividend. On February 1, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of March 31, 2017. The cash dividend of $145 million was paid on April 17, 2017. On May 3, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of June 30, 2017. The cash dividend will be paid on July 17, 2017. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-17-000013:mdna:93]
[same as prior period, unchanged from 0000106040-17-000007:mdna:92]

[0000106040-17-000013:mdna:94]
We have prepared the accompanying unaudited condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material.

[0000106040-17-000013:mdna:95]
[same as prior period, unchanged from 0000106040-17-000007:mdna:94]

[0000106040-17-000013:mdna:96]
[same as prior period, unchanged from 0000106040-17-000007:mdna:110]

[0000106040-17-000013:mdna:97]
Recently Issued Accounting Pronouncements

[0000106040-17-000013:mdna:98]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). The new standard requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. We are currently evaluating the impact ASU 2017-07 will have on our consolidated financial statements.

[0000106040-17-000013:mdna:99]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). The new standard simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. The new standard is effective for goodwill impairment tests in fiscal years beginning after December 15, 2019, which for us is the first quarter of 2021. Early adoption is permitted for goodwill impairment tests performed after January 1, 2017. The adoption of this standard is not expected to have a material impact on our consolidated financial statements.

[0000106040-17-000013:mdna:100]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). The new standard removes the prohibition in the FASB Accounting Standards Codification (“ASC”) Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact ASU 2016-16 will have on our consolidated financial statements.

[0000106040-17-000013:mdna:101]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). The new standard addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which, among others, includes our disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2018. The adoption of this standard is not expected to have a material impact on our consolidated financial statements.

[0000106040-17-000013:mdna:102]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within those years, which for us is the first quarter of 2018. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2018. As a result of adoption, our income tax expense and associated effective tax rate will be impacted by fluctuations in stock price between the grant dates and vesting dates of equity awards.

[0000106040-17-000013:mdna:103]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for us is the first quarter of 2020. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2020. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements and related disclosures.

[0000106040-17-000013:mdna:104]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”), which provides guidance related to accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. We are currently evaluating the impact ASU 2016-01 will have on our consolidated financial statements.

[0000106040-17-000013:mdna:105]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)”, which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued and amended, the standard is effective for public business entities applying U.S. GAAP, for annual periods commencing or after December 16, 2017 (with early adoption permitted for annual periods beginning on or after December 16, 2016). We intend to apply the new standard starting from the first quarter of fiscal 2019. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our preliminary plan, we intend to adopt the new standard using the modified retrospective method. However, we continue to assess this in connection with our entire project plan.

[0000106040-17-000013:mdna:106]
[same as prior period, unchanged from 0000106040-17-000007:mdna:103]

[0000106040-17-000013:mdna:107]
[same as prior period, unchanged from 0000106040-17-000007:mdna:104]

[0000106040-17-000013:mdna:108]
[same as prior period, unchanged from 0000106040-17-000007:mdna:105]

[0000106040-17-000013:mdna:109]
[same as prior period, unchanged from 0000106040-17-000007:mdna:106]

[0000106040-17-000013:mdna:110]
[same as prior period, unchanged from 0000106040-17-000007:mdna:107]

[0000106040-17-000013:mdna:111]
[same as prior period, unchanged from 0000106040-17-000007:mdna:108]

[0000106040-17-000013:mdna:112]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part I, Item 1, Note 2 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, which is incorporated by reference in response to this item.

[0000106040-17-000013:mdna:113]
60
