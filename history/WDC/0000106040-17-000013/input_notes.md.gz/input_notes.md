# WDC notes — 0000106040-17-000013


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-17-000013:notes:1]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of March 31, 2017, by remaining contractual maturity, were as follows:

[0000106040-17-000013:notes:2]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 25 |  |  | $ | 25 |  |
| Due in one to five years (included in other non-current assets) | 89 |  |  | 89 |  |
| Total | $ | 114 |  |  | $ | 114 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000106040-17-000013:notes:3]
[same as prior period, unchanged from 0000106040-17-000007:notes:3]

[0000106040-17-000013:notes:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 1, 2016 |
|  | (in millions, except per share amounts) |
| Revenue, net | $ | 4,188 |  |  | $ | 13,860 |  |
| Net income | 180 |  |  | 468 |  |
| Basic income per common share | $ | 0.64 |  |  | $ | 1.67 |  |
| Diluted income per common share | $ | 0.63 |  |  | $ | 1.64 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-17-000013:notes:5]
[same as prior period, unchanged from 0000106040-17-000007:notes:5]

[0000106040-17-000013:notes:6]
[same as prior period, unchanged from 0000106040-17-000007:notes:6]

[0000106040-17-000013:notes:7]
In May 2016, the Company acquired SanDisk, a global leader in NAND flash storage solutions, primarily to deepen the Company’s expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid-state technology at a lower cost.

[0000106040-17-000013:notes:8]
[same as prior period, unchanged from 0000106040-17-000007:notes:8]

[0000106040-17-000013:notes:9]
During the nine months ended March 31, 2017, the Company increased goodwill by $64 million due to adjustments to the assessment of fair value for certain acquired intangible assets, inventory, property, plant and equipment, contingent liabilities, and deferred tax liability. Management is continuing to assess the values assigned to the remaining assets acquired and liabilities assumed and may make further adjustments during the measurement period (through May 11, 2017) as further information becomes available. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in adjustments to goodwill.

[0000106040-17-000013:notes:10]
[same as prior period, unchanged from 0000106040-17-000007:notes:10]

[0000106040-17-000013:notes:11]
[same as prior period, unchanged from 0000106040-17-000007:notes:11]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-17-000013:notes:12]
The Company’s total cash, cash equivalents and marketable securities was as follows:

[0000106040-17-000013:notes:13]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Cash and cash equivalents | $ | 5,652 |  |  | $ | 8,151 |  |
| Short-term marketable securities | 25 |  |  | 227 |  |
| Long-term marketable securities | 89 |  |  | 119 |  |
| Total cash, cash equivalents and marketable securities | $ | 5,766 |  |  | $ | 8,497 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-17-000013:notes:14]
[same as prior period, unchanged from 0000106040-17-000007:notes:12]

[0000106040-17-000013:notes:15]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Benefit obligations | $ | 273 |  |  | $ | 326 |  |
| Fair value of plan assets | 179 |  |  | 212 |  |
| Unfunded status | $ | 94 |  |  | $ | 114 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-17-000013:notes:16]
Commitments, Contingencies and Related Parties

[0000106040-17-000013:notes:17]
Flash Ventures

[0000106040-17-000013:notes:18]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, referred to as “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

[0000106040-17-000013:notes:19]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-17-000013:notes:20]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 31, 2017 and July 1, 2016:

[0000106040-17-000013:notes:21]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 232 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 126 |  |  | 235 |  |
| Notes receivable, Flash Forward | 354 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 280 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,291 |  |  | $ | 1,171 |  |

[0000106040-17-000013:notes:22]
During the three and nine months ended March 31, 2017, the Company made net payments to Flash Ventures of $727 million and $2.0 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.

[0000106040-17-000013:notes:23]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-17-000013:notes:24]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-17-000013:notes:25]
As of March 31, 2017 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $194 million and $168 million, respectively.

[0000106040-17-000013:notes:26]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-17-000013:notes:27]
|  | March 31, 2017 |
|  | (in millions) |
| Notes receivable | $ | 712 |  |
| Equity investments | 579 |  |
| Operating lease guarantees | 1,048 |  |
| Prepayments | 23 |  |
| Maximum estimable loss exposure | $ | 2,362 |  |

[0000106040-17-000013:notes:28]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-17-000013:notes:29]
Off-Balance Sheet Liabilities

[0000106040-17-000013:notes:30]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-17-000013:notes:31]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017.

[0000106040-17-000013:notes:32]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 117 |  |  | $ | 1,048 |  |

[0000106040-17-000013:notes:33]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2017 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017:

[0000106040-17-000013:notes:34]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 268 |  |  | $ | 22 |  |  | $ | 290 |  |
| Year 2 |  | 231 |  |  | 15 |  |  | 246 |  |
| Year 3 |  | 173 |  |  | 59 |  |  | 232 |  |
| Year 4 |  | 93 |  |  | 97 |  |  | 190 |  |
| Year 5 |  | 20 |  |  | 70 |  |  | 90 |  |
| Total guarantee obligations |  | $ | 785 |  |  | $ | 263 |  |  | $ | 1,048 |  |

[0000106040-17-000013:notes:35]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2017, no amounts have been accrued in the condensed consolidated financial statements with respect to these indemnification guarantees.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-17-000013:notes:36]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 248 |  |  | $ | 389 |  |  | $ | 217 |  |  | $ | (606 | ) |  | $ | 248 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 58 |  |  | 58 |  |  | 58 |  |  | (116 | ) |  | 58 |  |
| Net unrealized gain on foreign exchange contracts | 45 |  |  | 42 |  |  | 41 |  |  | (83 | ) |  | 45 |  |
| Total other comprehensive income, before tax | 104 |  |  | 101 |  |  | 100 |  |  | (201 | ) |  | 104 |  |
| Income tax expense related to items of other comprehensive income | (3 | ) |  | (3 | ) |  | (2 | ) |  | 5 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 101 |  |  | 98 |  |  | 98 |  |  | (196 | ) |  | 101 |  |
| Total comprehensive income | $ | 349 |  |  | $ | 487 |  |  | $ | 315 |  |  | $ | (802 | ) |  | $ | 349 |  |

[0000106040-17-000013:notes:37]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 117 |  |  | $ | 558 |  |  | $ | 13 |  |  | $ | (571 | ) |  | $ | 117 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 7 |  |  | 7 |  |  | 7 |  |  | (14 | ) |  | 7 |  |
| Foreign currency translation adjustment | (111 | ) |  | (111 | ) |  | (134 | ) |  | 245 |  |  | (111 | ) |
| Net unrealized loss on foreign exchange contracts | (95 | ) |  | (98 | ) |  | (95 | ) |  | 193 |  |  | (95 | ) |
| Total other comprehensive loss, before tax | (199 | ) |  | (202 | ) |  | (222 | ) |  | 424 |  |  | (199 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | — |  |
| Other comprehensive loss, net of tax | (199 | ) |  | (202 | ) |  | (223 | ) |  | 425 |  |  | (199 | ) |
| Total comprehensive income (loss) | $ | (82 | ) |  | $ | 356 |  |  | $ | (210 | ) |  | $ | (146 | ) |  | $ | (82 | ) |

[0000106040-17-000013:notes:38]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended April 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 74 |  |  | $ | 82 |  |  | $ | 63 |  |  | $ | (145 | ) |  | $ | 74 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Net unrealized gain on foreign exchange contracts | 40 |  |  | 40 |  |  | 34 |  |  | (75 | ) |  | 39 |  |
| Net unrealized gain on available-for-sale securities | — |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | — |  |
| Total other comprehensive income, before tax | 40 |  |  | 41 |  |  | 35 |  |  | (77 | ) |  | 39 |  |
| Income tax benefit related to items of other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income, net of tax | 40 |  |  | 41 |  |  | 35 |  |  | (77 | ) |  | 39 |  |
| Total comprehensive income | $ | 114 |  |  | $ | 123 |  |  | $ | 98 |  |  | $ | (222 | ) |  | $ | 113 |  |

[0000106040-17-000013:notes:39]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended April 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 608 |  |  | $ | 630 |  |  | $ | 625 |  |  | $ | (1,255 | ) |  | $ | 608 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Net unrealized gain on foreign exchange contracts | 53 |  |  | 53 |  |  | 46 |  |  | (100 | ) |  | 52 |  |
| Net unrealized gain (loss) on available-for-sale securities | (1 | ) |  | (1 | ) |  | (1 | ) |  | 3 |  |  | — |  |
| Total other comprehensive income, before tax | 52 |  |  | 52 |  |  | 45 |  |  | (97 | ) |  | 52 |  |
| Income tax benefit related to items of other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income, net of tax | 52 |  |  | 52 |  |  | 45 |  |  | (97 | ) |  | 52 |  |
| Total comprehensive income | $ | 660 |  |  | $ | 682 |  |  | $ | 670 |  |  | $ | (1,352 | ) |  | $ | 660 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-17-000013:notes:40]
Debt

[0000106040-17-000013:notes:41]
Debt consisted of the following as of March 31, 2017 and July 1, 2016:

[0000106040-17-000013:notes:42]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,978 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 938 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,301 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (213 | ) |  | (532 | ) |
| Subtotal | 13,088 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (181 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,907 |  |  | $ | 13,660 |  |

[0000106040-17-000013:notes:43]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of March 31, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

[0000106040-17-000013:notes:44]
Credit Agreement – Term Loans and Revolving Credit Facility

[0000106040-17-000013:notes:45]
On April 29, 2016, the Company entered into a credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. The revolving credit facility includes a $200 million sublimit for letters of credit.

[0000106040-17-000013:notes:46]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

[0000106040-17-000013:notes:47]
On March 14, 2017, the Company borrowed $2.985 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-1 previously outstanding under the Credit Agreement. The U.S. Term Loan B-2 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 2.75% or a base rate plus 1.75% (3.73% as of March 31, 2017). Principal payments on U.S. Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-2 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $2 million remain unamortized.

[0000106040-17-000013:notes:48]
On March 23, 2017, the Company borrowed €881 million under a new Euro-denominated term loan (“Euro Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B-1 previously outstanding under the Credit Agreement. The Euro Term Loan B-2 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 2.00% (2.75% as of March 31, 2017). Principal payments on Euro Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The Euro Term Loan B-2 issuance costs of $1 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $1 million remain unamortized.

[0000106040-17-000013:notes:49]
In connection with the settlement of the U.S. Term Loan B-1 and Euro Term Loan B-1, the Company recognized a loss of $7 million consisting of unamortized issuance costs and debt discount fees.

[0000106040-17-000013:notes:50]
As of March 31, 2017, the revolving credit facility was not drawn upon, and there was no outstanding balance.

[0000106040-17-000013:notes:51]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of March 31, 2017, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.98%.

[0000106040-17-000013:notes:52]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-17-000013:notes:53]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-2 and the Euro Term Loan B-2 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before September 14, 2017, with respect to U.S. Term Loan B-2, and September 23, 2017, with respect to Euro Term Loan B-2.

[0000106040-17-000013:notes:54]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

[0000106040-17-000013:notes:55]
Additional Bridge Facility

[0000106040-17-000013:notes:56]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.0 billion aggregate principal amount outstanding, together with accrued interest.

[0000106040-17-000013:notes:57]
Senior Notes

[0000106040-17-000013:notes:58]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. On February 6, 2017, the exchange offer expired and substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.

[0000106040-17-000013:notes:59]
The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

[0000106040-17-000013:notes:60]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

[0000106040-17-000013:notes:61]
Convertible Notes, Exchange Options and Call Options

[0000106040-17-000013:notes:62]
As of July 1, 2016, the Company had outstanding, through the acquisition of SanDisk, $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

[0000106040-17-000013:notes:63]
During the three months ended March 31, 2017, the Company repurchased an immaterial amount of the 2017 Notes. During the nine months ended March 31, 2017, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $494 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

[0000106040-17-000013:notes:64]
As of March 31, 2017, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

[0000106040-17-000013:notes:65]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and nine months ended March 31, 2017, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial loss.

[0000106040-17-000013:notes:66]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the nine months ended March 31, 2017, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and nine months ended March 31, 2017, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of March 31, 2017 was immaterial.

[0000106040-17-000013:notes:67]
The conversion and repurchase of the Convertible Notes and related settlement of the call options during the three and nine months ended March 31, 2017 resulted in an immaterial net loss.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-17-000013:notes:68]
[same as prior period, unchanged from 0000106040-17-000007:notes:65]

[0000106040-17-000013:notes:69]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange forward contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange forward contracts are for risk management purposes only. The Company does not purchase foreign exchange forward contracts for speculative or trading purposes. As of March 31, 2017, the Company had outstanding foreign exchange forward contracts with commercial banks for British pound sterling, Euro, Japanese yen, Malaysian ringgit, Philippine peso, Singapore dollar and Thai baht, which were designated as either cash flow hedges or non-designated hedges.

[0000106040-17-000013:notes:70]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in AOCI, net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange forward contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and nine months ended March 31, 2017 and April 1, 2016.

[0000106040-17-000013:notes:71]
A change in the fair value of non-designated hedges is recognized in earnings in the period incurred and is reported as a component of Other income (expense), net. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and nine months ended March 31, 2017 and April 1, 2016.

[0000106040-17-000013:notes:72]
As of March 31, 2017, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive income (loss) that are expected to be reclassified into earnings over the next twelve months was $21 million. In addition, as of March 31, 2017, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-17-000013:notes:73]
[same as prior period, unchanged from 0000106040-17-000007:notes:70]

[0000106040-17-000013:notes:74]
[same as prior period, unchanged from 0000106040-17-000007:notes:71]

[0000106040-17-000013:notes:75]
[same as prior period, unchanged from 0000106040-17-000007:notes:72]

[0000106040-17-000013:notes:76]
|  | Derivative Assets Reported in |
|  | Other Current Assets |  | Other Non-current Assets |
|  | March 31, 2017 |  | July 1, 2016 |  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 4 |  |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 12 |  |  | 12 |  |  | — |  |  | — |  |
| Call options | 1 |  |  | 70 |  |  | — |  |  | 1 |  |
| Total derivatives | $ | 17 |  |  | $ | 196 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-17-000013:notes:77]
|  | Derivative Liabilities Reported in |
|  | Accrued Expenses |  | Other Liabilities |
|  | March 31, 2017 |  | July 1, 2016 |  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 100 |  |  | — |  |  | — |  |  | — |  |
| Exchange option | 1 |  |  | 141 |  |  | 1 |  |  | 14 |  |
| Total derivatives | $ | 101 |  |  | $ | 164 |  |  | $ | 1 |  |  | $ | 14 |  |

[0000106040-17-000013:notes:78]
[same as prior period, unchanged from 0000106040-17-000007:notes:75]

[0000106040-17-000013:notes:79]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of set-off associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 31, 2017, the Company did not offset or net the fair value amounts of derivative instruments in its condensed consolidated balance sheets and separately disclosed the gross fair value amounts of the derivative instruments as either assets or liabilities. As of March 31, 2017, the potential effect of rights of set-off associated with the Company’s foreign exchange forward contracts would result in a net derivative asset balance of $4 million and a net derivative liability balance of $88 million. As of July 1, 2016, the effect of rights of set-off was not material.

[0000106040-17-000013:notes:80]
[same as prior period, unchanged from 0000106040-17-000007:notes:79]

[0000106040-17-000013:notes:81]
The impact of foreign exchange forward contracts on the condensed consolidated financial statements was as follows:

[0000106040-17-000013:notes:82]
|  |  | Three Months Ended |
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in AOCI on Derivatives |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  |  | (in millions) |
| Foreign exchange forward contracts |  | $ | 50 |  |  | $ | 31 |  |  | $ | 5 |  |  | $ | (8 | ) |

[0000106040-17-000013:notes:83]
|  |  | Nine Months Ended |
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in AOCI on Derivatives |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  |  | (in millions) |
| Foreign exchange forward contracts |  | $ | (48 | ) |  | $ | (9 | ) |  | $ | 47 |  |  | $ | (61 | ) |

[0000106040-17-000013:notes:84]
The total net realized transaction and foreign exchange forward contract currency gains and losses were not material to the condensed consolidated financial statements for the three and nine months ended March 31, 2017 and April 1, 2016.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-17-000013:notes:85]
[same as prior period, unchanged from 0000106040-17-000007:notes:84]

[0000106040-17-000013:notes:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Options | $ | 10 |  |  | $ | 16 |  |  | $ | 33 |  |  | $ | 42 |  |
| Employee stock purchase plan | 7 |  |  | 3 |  |  | 16 |  |  | 9 |  |
| Restricted and performance stock units | 85 |  |  | 23 |  |  | 254 |  |  | 70 |  |
| Subtotal | 102 |  |  | 42 |  |  | 303 |  |  | 121 |  |
| Tax benefit | (26 | ) |  | (11 | ) |  | (80 | ) |  | (31 | ) |
| Total | $ | 76 |  |  | $ | 31 |  |  | $ | 223 |  |  | $ | 90 |  |

[0000106040-17-000013:notes:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 4 |  |  | $ | 37 |  |  | $ | 13 |  |
| Research and development | 45 |  |  | 17 |  |  | 132 |  |  | 46 |  |
| Selling, general, and administrative | 40 |  |  | 15 |  |  | 125 |  |  | 53 |  |
| Employee termination, asset impairment, and other charges | 4 |  |  | 6 |  |  | 9 |  |  | 9 |  |
| Subtotal | 102 |  |  | 42 |  |  | 303 |  |  | 121 |  |
| Tax benefit | (26 | ) |  | (11 | ) |  | (80 | ) |  | (31 | ) |
| Total | $ | 76 |  |  | $ | 31 |  |  | $ | 223 |  |  | $ | 90 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-17-000013:notes:88]
Net Income Per Common Share

[0000106040-17-000013:notes:89]
The following table presents the computation of basic and diluted income per common share:

[0000106040-17-000013:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions, except per share data) |
| Net income | $ | 248 |  |  | $ | 74 |  |  | $ | 117 |  |  | $ | 608 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 289 |  |  | 233 |  |  | 287 |  |  | 232 |  |
| Employee stock options, RSUs, PSUs, ESPP | 10 |  |  | 1 |  |  | 8 |  |  | 2 |  |
| Diluted | 299 |  |  | 234 |  |  | 295 |  |  | 234 |  |
| Income per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.86 |  |  | $ | 0.32 |  |  | $ | 0.41 |  |  | $ | 2.62 |  |
| Diluted | $ | 0.83 |  |  | $ | 0.32 |  |  | $ | 0.40 |  |  | $ | 2.60 |  |
| Anti-dilutive potential common shares excluded(1) | 2 |  |  | 6 |  |  | 4 |  |  | 5 |  |

[0000106040-17-000013:notes:91]
[same as prior period, unchanged from 0000106040-17-000007:notes:91]

[0000106040-17-000013:notes:92]
[same as prior period, unchanged from 0000106040-17-000007:notes:92]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000106040-17-000013:notes:93]
call options reported in Other current assets and Other non-current assets in the Company’s condensed consolidated balance sheets:

[0000106040-17-000013:notes:94]
|  | 2017 Call Options |  | 2020 Call Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 70 |  |  | $ | 1 |  |  | $ | 71 |  |
| Net realized gain (loss) | 2 |  |  | (1 | ) |  | 1 |  |
| Redemptions | (72 | ) |  | — |  |  | (72 | ) |
| Net unrealized gain | — |  |  | 1 |  |  | 1 |  |
| Fair value at March 31, 2017 | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-17-000013:notes:95]
[same as prior period, unchanged from 0000106040-17-000007:notes:95]

[0000106040-17-000013:notes:96]
[same as prior period, unchanged from 0000106040-17-000007:notes:96]

[0000106040-17-000013:notes:97]
[same as prior period, unchanged from 0000106040-17-000007:notes:97]

[0000106040-17-000013:notes:98]
[same as prior period, unchanged from 0000106040-17-000007:notes:98]

[0000106040-17-000013:notes:99]
[same as prior period, unchanged from 0000106040-17-000007:notes:99]

[0000106040-17-000013:notes:100]
[same as prior period, unchanged from 0000106040-17-000007:notes:100]

[0000106040-17-000013:notes:101]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 31, 2017 and July 1, 2016, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-17-000013:notes:102]
|  | March 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,776 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,776 |  |
| Certificates of deposit | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total cash equivalents | 1,776 |  |  | 9 |  |  | — |  |  | 1,785 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Asset-backed securities | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Municipal notes and bonds | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Equity securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Total short-term investments | 1 |  |  | 24 |  |  | — |  |  | 25 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 4 |  |  | — |  |  | — |  |  | 4 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 63 |  |  | — |  |  | 63 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term investments | 4 |  |  | 85 |  |  | — |  |  | 89 |  |
| Foreign exchange contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Call options | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total assets at fair value | $ | 1,781 |  |  | $ | 134 |  |  | $ | 1 |  |  | $ | 1,916 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | 100 |  |
| Exchange option | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 100 |  |  | $ | 2 |  |  | $ | 102 |  |

[0000106040-17-000013:notes:103]
[same as prior period, unchanged from 0000106040-17-000007:notes:103]

[0000106040-17-000013:notes:104]
During the three and nine months ended March 31, 2017 and April 1, 2016, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-17-000013:notes:105]
[same as prior period, unchanged from 0000106040-17-000007:notes:105]

[0000106040-17-000013:notes:106]
The fair value measurement of the call options and exchange options arising from the Company’s Convertible Notes (as defined in Note 6 to the condensed consolidated financial statements), which are not actively traded, is determined using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) the economic incentive for holders to exercise their exchange option. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-17-000013:notes:107]
There were no transfers of call options or exchange options out of Level 3 for the three and nine months ended March 31, 2017.

[0000106040-17-000013:notes:108]
The following table illustrates the changes in the balances of the call options reported in Other current assets and Other non-current assets in the Company’s condensed consolidated balance sheets:

[0000106040-17-000013:notes:109]
The following table illustrates the changes in the balances of the exchange options reported in Accrued expenses and Other liabilities in the Company’s condensed consolidated balance sheets:

[0000106040-17-000013:notes:110]
|  | 2017 Exchange Options |  | 2020 Exchange Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 87 |  |  | $ | 68 |  |  | $ | 155 |  |
| Net realized gain | (3 | ) |  | (31 | ) |  | (34 | ) |
| Redemptions | (83 | ) |  | (46 | ) |  | (129 | ) |
| Net unrealized loss | — |  |  | 10 |  |  | 10 |  |
| Fair value at March 31, 2017 | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000106040-17-000013:notes:111]
[same as prior period, unchanged from 0000106040-17-000007:notes:110]

[0000106040-17-000013:notes:112]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2017 and the fourth quarter of 2016, respectively.

[0000106040-17-000013:notes:113]
|  | March 31, 2017 |  | July 1, 2016 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Secured Notes | $ | 1,833 |  |  | $ | 2,059 |  |  | $ | 1,828 |  |  | $ | 2,044 |  |
| Unsecured Notes | 3,241 |  |  | 3,951 |  |  | 3,229 |  |  | 3,575 |  |
| Term Loan A | 4,071 |  |  | 4,140 |  |  | 4,061 |  |  | 4,161 |  |
| U.S. Term Loan B | — |  |  | — |  |  | 3,546 |  |  | 3,773 |  |
| U.S. Term Loan B-2 | 2,976 |  |  | 2,998 |  |  | — |  |  | — |  |
| Euro Term Loan B(1) | — |  |  | — |  |  | 960 |  |  | 981 |  |
| Euro Term Loan B-2(1) | 937 |  |  | 942 |  |  | — |  |  | — |  |
| Bridge Loan | — |  |  | — |  |  | 2,995 |  |  | 3,000 |  |
| Convertible Debt 2017 | — |  |  | — |  |  | 124 |  |  | 125 |  |
| Convertible Debt 2020 | 30 |  |  | 33 |  |  | 251 |  |  | 264 |  |
| Total | $ | 13,088 |  |  | $ | 14,123 |  |  | $ | 16,994 |  |  | $ | 17,923 |  |

[0000106040-17-000013:notes:114]
[same as prior period, unchanged from 0000106040-17-000007:notes:113]

[0000106040-17-000013:notes:115]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. As of March 31, 2017 and July 1, 2016, the Company had aggregate net investments under the cost method of accounting of $141 million and $135 million, respectively, and these investments consisted of privately-held equity securities without a readily determinable fair value. The Company has determined that it is not practicable to estimate the fair value of these investments. These cost method investments are reported under Other non-current assets in the condensed consolidated balance sheets.

[0000106040-17-000013:notes:116]
During the three and nine months ended March 31, 2017, the Company recorded impairment charges of $7 million and $11 million, respectively, to Other income (expense), net in the condensed consolidated statements of operations related to its cost method investments.

[0000106040-17-000013:notes:117]
[same as prior period, unchanged from 0000106040-17-000007:notes:115]

[0000106040-17-000013:notes:118]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of March 31, 2017 and July 1, 2016.

[0000106040-17-000013:notes:119]
The Company determined available-for-sale securities had no material other-than-temporary impairments in the three and nine months ended March 31, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-17-000013:notes:120]
Income Tax Expense

[0000106040-17-000013:notes:121]
The following table presents the income tax expense and the effective tax rate:

[0000106040-17-000013:notes:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Income tax expense | $ | 56 |  |  | $ | 6 |  |  | $ | 237 |  |  | $ | 30 |  |
| Effective tax rate | 18 | % |  | 8 | % |  | 67 | % |  | 5 | % |

[0000106040-17-000013:notes:123]
Income tax expense of $237 million for the nine months ended March 31, 2017 includes discrete effects consisting of income tax expense from the integration of SanDisk of $91 million and a valuation allowance on acquired tax attributes of $111 million. Income tax expense related to the SanDisk integration is partially offset by an income tax benefit of $98 million from deductible debt issuance costs, debt discounts and prepayment fees from debt refinancing.

[0000106040-17-000013:notes:124]
The primary drivers for the difference between the effective tax rate for the three and nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% are the current year generation of tax credits, tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2017 through 2029, for both periods, and the discrete items described above for the nine months ended March 31, 2017. For the three and nine months ended April 1, 2016, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to current year generation of tax credits and tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2017 through 2029.

[0000106040-17-000013:notes:125]
During the nine months ended March 31, 2017, the Company recorded a net increase of $14 million in its liability for unrecognized tax benefits. As of March 31, 2017, the Company’s liability for unrecognized tax benefits was approximately $505 million. Accrued interest and penalties related to unrecognized tax benefits as of March 31, 2017 was $92 million.

[0000106040-17-000013:notes:126]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. Meetings with the IRS Appeals Office began in March 2017. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-17-000013:notes:127]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 31, 2017, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-17-000013:notes:128]
Legal Proceedings

[0000106040-17-000013:notes:129]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-17-000013:notes:130]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-17-000013:notes:131]
Intellectual Property Litigation

[0000106040-17-000013:notes:132]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the District Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-17-000013:notes:133]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

[0000106040-17-000013:notes:134]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints - one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California - against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,542; RE45,486; 7,565,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The District Court action has been stayed pending resolution of the ITC proceeding. The Company intends to defend itself vigorously in these matters.

[0000106040-17-000013:notes:135]
Antitrust

[0000106040-17-000013:notes:136]
In June 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint with the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. In February 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. In May 2015, the District Court granted in part plaintiffs’ motion for class certification. In April 2016, the District Court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk’s favor as to all of the plaintiffs’ claims. In May 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

[0000106040-17-000013:notes:137]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In August 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint in September 2011. In January 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. In April 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint in January 2015. In September 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. In October 2015, Samsung filed a fourth amended complaint. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

[0000106040-17-000013:notes:138]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In May 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. In May 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. In February 2015, the plaintiffs filed a second amended complaint in the District Court. In September 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. In November 2015, the plaintiffs filed a third amended complaint. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000013:notes:139]
Securities

[0000106040-17-000013:notes:140]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss in April 2016. In June 2016, the District Court granted the motion and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. The defendants filed a motion to dismiss in August 2016. In January 2017, the District Court denied the motion to dismiss without prejudice to the defendants filing a renewed motion to dismiss, which the defendants filed soon thereafter. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000013:notes:141]
Other Matters

[0000106040-17-000013:notes:142]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue.  In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000013:notes:143]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000013:notes:144]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows. It is reasonably possible that the Company may incur losses totaling up to $141 million, including the amounts accrued.

[0000106040-17-000013:notes:145]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-17-000013:notes:146]
Recently Adopted Accounting Pronouncements

[0000106040-17-000013:notes:147]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015-05 at the beginning of the current year did not have a material impact on its condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-17-000013:notes:148]
[same as prior period, unchanged from 0000106040-17-000007:notes:147]

[0000106040-17-000013:notes:149]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company also generates license and royalty revenue related to its intellectual property.

[0000106040-17-000013:notes:150]
[same as prior period, unchanged from 0000106040-17-000007:notes:149]

[0000106040-17-000013:notes:151]
[same as prior period, unchanged from 0000106040-17-000007:notes:150]

[0000106040-17-000013:notes:152]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2017, which ends on June 30, 2017, and 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-17-000013:notes:153]
[same as prior period, unchanged from 0000106040-17-000007:notes:152]

[0000106040-17-000013:notes:154]
[same as prior period, unchanged from 0000106040-17-000007:notes:153]

[0000106040-17-000013:notes:155]
[same as prior period, unchanged from 0000106040-17-000007:notes:154]

[0000106040-17-000013:notes:156]
[same as prior period, unchanged from 0000106040-17-000007:notes:155]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-17-000013:notes:157]
[same as prior period, unchanged from 0000106040-17-000007:notes:156]

[0000106040-17-000013:notes:158]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Company’s condensed consolidated financial statements. The expected long-term rate of return on the Japanese Plan assets is 2.5%.

[0000106040-17-000013:notes:159]
[same as prior period, unchanged from 0000106040-17-000007:notes:158]

[0000106040-17-000013:notes:160]
[same as prior period, unchanged from 0000106040-17-000007:notes:159]

[0000106040-17-000013:notes:161]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Non-current liabilities | $ | 94 |  |  | $ | 114 |  |
| Net amount recognized | $ | 94 |  |  | $ | 114 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-17-000013:notes:162]
Property, plant, and equipment, net

[0000106040-17-000013:notes:163]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,883 |  |  | $ | 1,900 |  |
| Machinery and equipment | 7,008 |  |  | 6,915 |  |
| Software | 181 |  |  | 155 |  |
| Furniture and fixtures | 52 |  |  | 110 |  |
| Leasehold improvements | 305 |  |  | 307 |  |
| Construction-in-process | 115 |  |  | 245 |  |
| Property, plant, and equipment, gross | 9,544 |  |  | 9,632 |  |
| Accumulated depreciation | (6,445 | ) |  | (6,129 | ) |
| Property, plant, and equipment, net | $ | 3,099 |  |  | $ | 3,503 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-17-000013:notes:164]
[same as prior period, unchanged from 0000106040-17-000007:notes:163]

[0000106040-17-000013:notes:165]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
| AOCI Component |  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on cash flow hedging activities: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 9 |  |  | $ | (8 | ) |  | $ | 42 |  |  | $ | (61 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | (1 | ) |  | — |  |  | 1 |  |  | — |  |  | Research and development |
| Foreign exchange contracts |  | (3 | ) |  | — |  |  | 4 |  |  | — |  |  | Selling, general, and administrative |
| Unrealized holding gain (loss) on cash flow hedging activities |  | 5 |  |  | (8 | ) |  | 47 |  |  | (61 | ) |  |  |
| Total reclassifications for the period |  | $ | 5 |  |  | $ | (8 | ) |  | $ | 47 |  |  | $ | (61 | ) |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-17-000013:notes:166]
The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-17-000013:notes:167]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Foreign Exchange Contracts |  | Total AOCI |
|  | (in millions) |
| Balance at July 1, 2016 | $ | (45 | ) |  | $ | 74 |  |  | $ | 74 |  |  | $ | 103 |  |
| OCI before reclassifications | 7 |  |  | (111 | ) |  | (48 | ) |  | (152 | ) |
| Amounts reclassified from AOCI | — |  |  | — |  |  | (47 | ) |  | (47 | ) |
| Income tax benefit (expense) related to items of OCI | (2 | ) |  | 2 |  |  | — |  |  | — |  |
| Net current-period OCI | 5 |  |  | (109 | ) |  | (95 | ) |  | (199 | ) |
| Balance at March 31, 2017 | $ | (40 | ) |  | $ | (35 | ) |  | $ | (21 | ) |  | $ | (96 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-17-000013:notes:168]
| Condensed Consolidating Balance Sheet |
| As of March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 270 |  |  | $ | 856 |  |  | $ | 4,526 |  |  | $ | — |  |  | $ | 5,652 |  |
| Short-term investments | — |  |  | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Accounts receivable, net | — |  |  | 1,212 |  |  | 736 |  |  | — |  |  | 1,948 |  |
| Intercompany receivable | 1,143 |  |  | 1,997 |  |  | 2,923 |  |  | (6,063 | ) |  | — |  |
| Inventories | — |  |  | 1,067 |  |  | 1,458 |  |  | (271 | ) |  | 2,254 |  |
| Other current assets | 5 |  |  | 216 |  |  | 223 |  |  | (10 | ) |  | 434 |  |
| Total current assets | 1,418 |  |  | 5,348 |  |  | 9,891 |  |  | (6,344 | ) |  | 10,313 |  |
| Property, plant and equipment, net | — |  |  | 1,170 |  |  | 1,929 |  |  | — |  |  | 3,099 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,291 |  |  | — |  |  | 1,291 |  |
| Goodwill | — |  |  | 325 |  |  | 9,687 |  |  | — |  |  | 10,012 |  |
| Other intangible assets, net | — |  |  | 15 |  |  | 4,129 |  |  | — |  |  | 4,144 |  |
| Investments in consolidated subsidiaries | 18,344 |  |  | 18,199 |  |  | — |  |  | (36,543 | ) |  | — |  |
| Loans due from consolidated affiliates | 5,005 |  |  | 313 |  |  | — |  |  | (5,318 | ) |  | — |  |
| Other non-current assets | 46 |  |  | 89 |  |  | 478 |  |  | (24 | ) |  | 589 |  |
| Total assets | $ | 24,813 |  |  | $ | 25,459 |  |  | $ | 27,405 |  |  | $ | (48,229 | ) |  | $ | 29,448 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 264 |  |  | $ | 1,921 |  |  | $ | — |  |  | $ | 2,185 |  |
| Intercompany payable | 171 |  |  | 5,233 |  |  | 659 |  |  | (6,063 | ) |  | — |  |
| Accounts payable to related parties | — |  |  | — |  |  | 194 |  |  | — |  |  | 194 |  |
| Accrued expenses | 254 |  |  | 473 |  |  | 353 |  |  | (7 | ) |  | 1,073 |  |
| Accrued compensation | — |  |  | 291 |  |  | 189 |  |  | — |  |  | 480 |  |
| Accrued warranty | — |  |  | 4 |  |  | 192 |  |  | — |  |  | 196 |  |
| Current portion of long-term debt | 181 |  |  | — |  |  | — |  |  | — |  |  | 181 |  |
| Total current liabilities | 606 |  |  | 6,265 |  |  | 3,508 |  |  | (6,070 | ) |  | 4,309 |  |
| Long-term debt | 12,878 |  |  | — |  |  | 29 |  |  | — |  |  | 12,907 |  |
| Loans due to consolidated affiliates | 298 |  |  | 34 |  |  | 4,986 |  |  | (5,318 | ) |  | — |  |
| Other liabilities | — |  |  | 619 |  |  | 609 |  |  | (27 | ) |  | 1,201 |  |
| Total liabilities | 13,782 |  |  | 6,918 |  |  | 9,132 |  |  | (11,415 | ) |  | 18,417 |  |
| Shareholders’ equity | 11,031 |  |  | 18,541 |  |  | 18,273 |  |  | (36,814 | ) |  | 11,031 |  |
| Total liabilities and shareholders’ equity | $ | 24,813 |  |  | $ | 25,459 |  |  | $ | 27,405 |  |  | $ | (48,229 | ) |  | $ | 29,448 |  |

[0000106040-17-000013:notes:169]
| Condensed Consolidating Balance Sheet |
| As of July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 1,206 |  |  | $ | 6,945 |  |  | $ | — |  |  | $ | 8,151 |  |
| Short-term investments | — |  |  | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Accounts receivable, net | — |  |  | 985 |  |  | 476 |  |  | — |  |  | 1,461 |  |
| Intercompany receivable | 934 |  |  | 886 |  |  | 2,546 |  |  | (4,366 | ) |  | — |  |
| Inventories | — |  |  | 896 |  |  | 1,450 |  |  | (217 | ) |  | 2,129 |  |
| Other current assets | 4 |  |  | 276 |  |  | 379 |  |  | (43 | ) |  | 616 |  |
| Total current assets | 938 |  |  | 4,249 |  |  | 12,023 |  |  | (4,626 | ) |  | 12,584 |  |
| Property, plant and equipment, net | — |  |  | 1,265 |  |  | 2,238 |  |  | — |  |  | 3,503 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,171 |  |  | — |  |  | 1,171 |  |
| Goodwill | — |  |  | 324 |  |  | 9,627 |  |  | — |  |  | 9,951 |  |
| Other intangible assets, net | — |  |  | 28 |  |  | 5,006 |  |  | — |  |  | 5,034 |  |
| Investments in consolidated subsidiaries | 18,009 |  |  | 27,020 |  |  | — |  |  | (45,029 | ) |  | — |  |
| Loans due from consolidated affiliates | 6,000 |  |  | 55 |  |  | — |  |  | (6,055 | ) |  | — |  |
| Other non-current assets | 50 |  |  | 33 |  |  | 702 |  |  | (166 | ) |  | 619 |  |
| Total assets | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 239 |  |  | $ | 1,649 |  |  | $ | — |  |  | $ | 1,888 |  |
| Intercompany payable | 119 |  |  | 4,043 |  |  | 204 |  |  | (4,366 | ) |  | — |  |
| Accounts payable to related parties | — |  |  | — |  |  | 168 |  |  | — |  |  | 168 |  |
| Accrued expenses | 109 |  |  | 462 |  |  | 404 |  |  | 20 |  |  | 995 |  |
| Accrued compensation | — |  |  | 222 |  |  | 170 |  |  | — |  |  | 392 |  |
| Accrued warranty | — |  |  | 4 |  |  | 168 |  |  | — |  |  | 172 |  |
| Bridge loan | — |  |  | 2,995 |  |  | — |  |  | — |  |  | 2,995 |  |
| Current portion of long-term debt | 14 |  |  | — |  |  | 325 |  |  | — |  |  | 339 |  |
| Total current liabilities | 242 |  |  | 7,965 |  |  | 3,088 |  |  | (4,346 | ) |  | 6,949 |  |
| Long-term debt | 13,610 |  |  | — |  |  | 50 |  |  | — |  |  | 13,660 |  |
| Loans due to consolidated affiliates | — |  |  | 6,000 |  |  | 55 |  |  | (6,055 | ) |  | — |  |
| Other liabilities | — |  |  | 862 |  |  | 475 |  |  | (229 | ) |  | 1,108 |  |
| Total liabilities | 13,852 |  |  | 14,827 |  |  | 3,668 |  |  | (10,630 | ) |  | 21,717 |  |
| Shareholders’ equity | 11,145 |  |  | 18,147 |  |  | 27,099 |  |  | (45,246 | ) |  | 11,145 |  |
| Total liabilities and shareholders’ equity | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-17-000013:notes:170]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (443 | ) |  | $ | 617 |  |  | $ | 2,177 |  |  | $ | 147 |  |  | $ | 2,498 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (185 | ) |  | (268 | ) |  | — |  |  | (453 | ) |
| Proceeds from the sale of equipment | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Purchases of investments | — |  |  | — |  |  | (274 | ) |  | — |  |  | (274 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 75 |  |  | — |  |  | 75 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 430 |  |  | — |  |  | 430 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (480 | ) |  | — |  |  | (480 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 276 |  |  | — |  |  | 276 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Intercompany loans from (to) consolidated affiliates | 995 |  |  | (258 | ) |  | — |  |  | (737 | ) |  | — |  |
| Advances from (to) consolidated affiliates | 244 |  |  | (236 | ) |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,239 |  |  | (679 | ) |  | (261 | ) |  | (745 | ) |  | (446 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 123 |  |  | — |  |  | — |  |  | — |  |  | 123 |  |
| Taxes paid on vested stock awards under employee stock plans | (111 | ) |  | — |  |  | — |  |  | — |  |  | (111 | ) |
| Excess tax benefits from employee stock plans | 90 |  |  | — |  |  | — |  |  | — |  |  | 90 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Dividends paid to shareholders | (428 | ) |  | — |  |  | — |  |  | — |  |  | (428 | ) |
| Repayment of debt | (8,692 | ) |  | (2,995 | ) |  | (492 | ) |  | — |  |  | (12,179 | ) |
| Proceeds from debt | 7,908 |  |  | — |  |  | — |  |  | — |  |  | 7,908 |  |
| Debt issuance costs | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Intercompany loans from (to) consolidated affiliates | 298 |  |  | (5,966 | ) |  | 4,931 |  |  | 737 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 296 |  |  | 8,673 |  |  | (8,830 | ) |  | (139 | ) |  | — |  |
| Net cash used in financing activities | (526 | ) |  | (288 | ) |  | (4,330 | ) |  | 598 |  |  | (4,546 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Net increase (decrease) in cash and cash equivalents | 270 |  |  | (350 | ) |  | (2,419 | ) |  | — |  |  | (2,499 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of period | $ | 270 |  |  | $ | 856 |  |  | $ | 4,526 |  |  | $ | — |  |  | $ | 5,652 |  |

[0000106040-17-000013:notes:171]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended April 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 21 |  |  | $ | 322 |  |  | $ | 1,289 |  |  | $ | (4 | ) |  | $ | 1,628 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (168 | ) |  | (265 | ) |  | — |  |  | (433 | ) |
| Purchases of investments | — |  |  | — |  |  | (462 | ) |  | — |  |  | (462 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 604 |  |  | — |  |  | 604 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 303 |  |  | — |  |  | 303 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Advances from (to) consolidated affiliates | 269 |  |  | (269 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 269 |  |  | (437 | ) |  | 157 |  |  | — |  |  | (11 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 64 |  |  | — |  |  | — |  |  | — |  |  | 64 |  |
| Taxes paid on vested stock awards under employee stock plans | (45 | ) |  | — |  |  | — |  |  | — |  |  | (45 | ) |
| Excess tax benefits from employee stock plans | (2 | ) |  | — |  |  | — |  |  | — |  |  | (2 | ) |
| Repurchases of common stock | (60 | ) |  | — |  |  | — |  |  | — |  |  | (60 | ) |
| Dividends paid to shareholders | (347 | ) |  | — |  |  | — |  |  | — |  |  | (347 | ) |
| Repayment of debt | — |  |  | (109 | ) |  | (255 | ) |  | — |  |  | (364 | ) |
| Change in investment in consolidated subsidiaries | 100 |  |  | (65 | ) |  | (39 | ) |  | 4 |  |  | — |  |
| Net cash used in financing activities | (290 | ) |  | (174 | ) |  | (294 | ) |  | 4 |  |  | (754 | ) |
| Net increase (decrease) in cash and cash equivalents | — |  |  | (289 | ) |  | 1,152 |  |  | — |  |  | 863 |  |
| Cash and cash equivalents, beginning of year | — |  |  | 661 |  |  | 4,363 |  |  | — |  |  | 5,024 |  |
| Cash and cash equivalents, end of period | $ | — |  |  | $ | 372 |  |  | $ | 5,515 |  |  | $ | — |  |  | $ | 5,887 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-17-000013:notes:172]
[same as prior period, unchanged from 0000106040-17-000007:notes:171]

[0000106040-17-000013:notes:173]
The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The New Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by the WD Guarantors (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the designation of a Guarantor Subsidiary as an unrestricted subsidiary under the indenture governing the New Unsecured Notes, (ii) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the New Unsecured Notes, (iii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the New Unsecured Notes, (iv) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (v) the Company’s exercise of its defeasance options under the indenture governing the New Unsecured Notes, (vi) the dissolution or liquidation of a Guarantor Subsidiary or (vii) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the New Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-17-000013:notes:174]
[same as prior period, unchanged from 0000106040-17-000007:notes:173]

[0000106040-17-000013:notes:175]
| Condensed Consolidating Statement of Operations |
| For the three months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,406 |  |  | $ | 4,333 |  |  | $ | (3,090 | ) |  | $ | 4,649 |  |
| Cost of revenue | — |  |  | 2,791 |  |  | 3,403 |  |  | (3,068 | ) |  | 3,126 |  |
| Gross profit | — |  |  | 615 |  |  | 930 |  |  | (22 | ) |  | 1,523 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 413 |  |  | 200 |  |  | — |  |  | 613 |  |
| Selling, general, and administrative | 1 |  |  | 240 |  |  | 105 |  |  | — |  |  | 346 |  |
| Intercompany operating expense (income) | — |  |  | (282 | ) |  | 282 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 30 |  |  | 9 |  |  | — |  |  | 39 |  |
| Total operating expenses | 1 |  |  | 401 |  |  | 596 |  |  | — |  |  | 998 |  |
| Operating income (loss) | (1 | ) |  | 214 |  |  | 334 |  |  | (22 | ) |  | 525 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 88 |  |  | 8 |  |  | 6 |  |  | (95 | ) |  | 7 |  |
| Interest expense | (211 | ) |  | — |  |  | (89 | ) |  | 95 |  |  | (205 | ) |
| Other expense, net | (9 | ) |  | (6 | ) |  | (8 | ) |  | — |  |  | (23 | ) |
| Total interest and other income (expense), net | (132 | ) |  | 2 |  |  | (91 | ) |  | — |  |  | (221 | ) |
| Income (loss) before taxes | (133 | ) |  | 216 |  |  | 243 |  |  | (22 | ) |  | 304 |  |
| Income tax expense (benefit) | (26 | ) |  | 56 |  |  | 26 |  |  | — |  |  | 56 |  |
| Equity in earnings from subsidiaries | 355 |  |  | 229 |  |  | — |  |  | (584 | ) |  | — |  |
| Net income | $ | 248 |  |  | $ | 389 |  |  | $ | 217 |  |  | $ | (606 | ) |  | $ | 248 |  |

[0000106040-17-000013:notes:176]
| Condensed Consolidating Statement of Operations |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 10,890 |  |  | $ | 12,871 |  |  | $ | (9,510 | ) |  | $ | 14,251 |  |
| Cost of revenue | — |  |  | 8,941 |  |  | 10,451 |  |  | (9,532 | ) |  | 9,860 |  |
| Gross profit | — |  |  | 1,949 |  |  | 2,420 |  |  | 22 |  |  | 4,391 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,226 |  |  | 611 |  |  | — |  |  | 1,837 |  |
| Selling, general, and administrative | 5 |  |  | 766 |  |  | 329 |  |  | — |  |  | 1,100 |  |
| Intercompany operating expense (income) | — |  |  | (851 | ) |  | 851 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 88 |  |  | 64 |  |  | — |  |  | 152 |  |
| Total operating expenses | 5 |  |  | 1,229 |  |  | 1,855 |  |  | — |  |  | 3,089 |  |
| Operating income (loss) | (5 | ) |  | 720 |  |  | 565 |  |  | 22 |  |  | 1,302 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 268 |  |  | 9 |  |  | 15 |  |  | (275 | ) |  | 17 |  |
| Interest expense | (642 | ) |  | (5 | ) |  | (274 | ) |  | 275 |  |  | (646 | ) |
| Other expense, net | (283 | ) |  | (10 | ) |  | (26 | ) |  | — |  |  | (319 | ) |
| Total interest and other expense, net | (657 | ) |  | (6 | ) |  | (285 | ) |  | — |  |  | (948 | ) |
| Income (loss) before taxes | (662 | ) |  | 714 |  |  | 280 |  |  | 22 |  |  | 354 |  |
| Income tax expense (benefit) | (207 | ) |  | 177 |  |  | 267 |  |  | — |  |  | 237 |  |
| Equity in earnings from subsidiaries | 572 |  |  | 21 |  |  | — |  |  | (593 | ) |  | — |  |
| Net income | $ | 117 |  |  | $ | 558 |  |  | $ | 13 |  |  | $ | (571 | ) |  | $ | 117 |  |

[0000106040-17-000013:notes:177]
| Condensed Consolidating Statement of Operations |
| For the three months ended April 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 2,959 |  |  | $ | 2,895 |  |  | $ | (3,032 | ) |  | $ | 2,822 |  |
| Cost of revenue | — |  |  | 2,780 |  |  | 2,310 |  |  | (3,021 | ) |  | 2,069 |  |
| Gross profit | — |  |  | 179 |  |  | 585 |  |  | (11 | ) |  | 753 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 252 |  |  | 107 |  |  | — |  |  | 359 |  |
| Selling, general, and administrative | 1 |  |  | 134 |  |  | 31 |  |  | — |  |  | 166 |  |
| Intercompany operating expense (income) | — |  |  | (255 | ) |  | 255 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 9 |  |  | 131 |  |  | — |  |  | 140 |  |
| Total operating expenses | 1 |  |  | 140 |  |  | 524 |  |  | — |  |  | 665 |  |
| Operating income (loss) | (1 | ) |  | 39 |  |  | 61 |  |  | (11 | ) |  | 88 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Interest expense | — |  |  | (13 | ) |  | (1 | ) |  | — |  |  | (14 | ) |
| Total interest and other income (expense), net | — |  |  | (13 | ) |  | 5 |  |  | — |  |  | (8 | ) |
| Income (loss) before taxes | (1 | ) |  | 26 |  |  | 66 |  |  | (11 | ) |  | 80 |  |
| Income tax expense (benefit) | (1 | ) |  | 4 |  |  | 3 |  |  | — |  |  | 6 |  |
| Equity in earnings from subsidiaries | 74 |  |  | 60 |  |  | — |  |  | (134 | ) |  | — |  |
| Net income | $ | 74 |  |  | $ | 82 |  |  | $ | 63 |  |  | $ | (145 | ) |  | $ | 74 |  |

[0000106040-17-000013:notes:178]
| Condensed Consolidating Statement of Operations |
| For the nine months ended April 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 9,796 |  |  | $ | 9,919 |  |  | $ | (10,216 | ) |  | $ | 9,499 |  |
| Cost of revenue | — |  |  | 9,190 |  |  | 7,888 |  |  | (10,193 | ) |  | 6,885 |  |
| Gross profit | — |  |  | 606 |  |  | 2,031 |  |  | (23 | ) |  | 2,614 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 831 |  |  | 302 |  |  | — |  |  | 1,133 |  |
| Selling, general, and administrative | 3 |  |  | 443 |  |  | 151 |  |  | — |  |  | 597 |  |
| Intercompany operating expense (income) | — |  |  | (845 | ) |  | 845 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 79 |  |  | 144 |  |  | — |  |  | 223 |  |
| Total operating expenses | 3 |  |  | 508 |  |  | 1,442 |  |  | — |  |  | 1,953 |  |
| Operating income (loss) | (3 | ) |  | 98 |  |  | 589 |  |  | (23 | ) |  | 661 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 1 |  |  | 14 |  |  | — |  |  | 15 |  |
| Interest expense | — |  |  | (35 | ) |  | (5 | ) |  | — |  |  | (40 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total interest and other income (expense), net | — |  |  | (34 | ) |  | 11 |  |  | — |  |  | (23 | ) |
| Income (loss) before taxes | (3 | ) |  | 64 |  |  | 600 |  |  | (23 | ) |  | 638 |  |
| Income tax expense (benefit) | (1 | ) |  | 56 |  |  | (25 | ) |  | — |  |  | 30 |  |
| Equity in earnings from subsidiaries | 610 |  |  | 622 |  |  | — |  |  | (1,232 | ) |  | — |  |
| Net income | $ | 608 |  |  | $ | 630 |  |  | $ | 625 |  |  | $ | (1,255 | ) |  | $ | 608 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-17-000013:notes:179]
[same as prior period, unchanged from 0000106040-17-000007:notes:178]

[0000106040-17-000013:notes:180]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 1, 2016 | $ | 9,951 |  |
| Purchase price adjustments to goodwill | 64 |  |
| Foreign currency translation adjustment | (3 | ) |
| Balance at March 31, 2017 | $ | 10,012 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0000106040-17-000013:notes:181]
Intangible assets

[0000106040-17-000013:notes:182]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,203 |  |  | $ | 3,539 |  |
| In-process research and development | 695 |  |  | 2,435 |  |
| Accumulated amortization | (1,754 | ) |  | (940 | ) |
| Intangible assets, net | $ | 4,144 |  |  | $ | 5,034 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-17-000013:notes:183]
[same as prior period, unchanged from 0000106040-17-000007:notes:182]

[0000106040-17-000013:notes:184]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 581 |  |  | $ | 569 |  |
| Work-in-process | 627 |  |  | 589 |  |
| Finished goods | 1,046 |  |  | 971 |  |
| Total inventories | $ | 2,254 |  |  | $ | 2,129 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-17-000013:notes:185]
Product warranty liability

[0000106040-17-000013:notes:186]
[same as prior period, unchanged from 0000106040-17-000007:notes:185]

[0000106040-17-000013:notes:187]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 313 |  |  | $ | 225 |  |  | $ | 279 |  |  | $ | 221 |  |
| Charges to operations | 43 |  |  | 36 |  |  | 134 |  |  | 124 |  |
| Utilization | (36 | ) |  | (43 | ) |  | (116 | ) |  | (137 | ) |
| Changes in estimate related to pre-existing warranties | 3 |  |  | 3 |  |  | 26 |  |  | 13 |  |
| Warranty accrual, end of period | $ | 323 |  |  | $ | 221 |  |  | $ | 323 |  |  | $ | 221 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-17-000013:notes:188]
The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 31, 2017:

[0000106040-17-000013:notes:189]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 11 |  |  | $ | 3 |  |  | $ | 14 |  |
| Charges | 65 |  |  | 4 |  |  | 69 |  |
| Cash payments | (62 | ) |  | (2 | ) |  | (64 | ) |
| Non-cash items and other | 6 |  |  | — |  |  | 6 |  |
| Accrual balance at March 31, 2017 | $ | 20 |  |  | $ | 5 |  |  | $ | 25 |  |

[0000106040-17-000013:notes:190]
[same as prior period, unchanged from 0000106040-17-000007:notes:191]

[0000106040-17-000013:notes:191]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 6 |  |  | $ | 64 |  |  | $ | 52 |  |  | $ | 64 |  |
| Closure of Foreign Manufacturing Facility | 3 |  |  | 24 |  |  | 9 |  |  | 24 |  |
| Business Realignment | 26 |  |  | 22 |  |  | 69 |  |  | 94 |  |
| Total employee termination and other charges | 35 |  |  | 110 |  |  | 130 |  |  | 182 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | — |  |  | (1 | ) |  | — |  |
| Business Realignment | 4 |  |  | 6 |  |  | 10 |  |  | 9 |  |
| Total stock-based compensation accelerations and adjustments | 4 |  |  | 6 |  |  | 9 |  |  | 9 |  |
| Asset impairment: |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 24 |  |  | 13 |  |  | 24 |  |
| Business Realignment | — |  |  | — |  |  | — |  |  | 8 |  |
| Total asset impairment | — |  |  | 24 |  |  | 13 |  |  | 32 |  |
| Total employee termination and other charges, stock-based compensation adjustments and asset impairments | $ | 39 |  |  | $ | 140 |  |  | $ | 152 |  |  | $ | 223 |  |

[0000106040-17-000013:notes:192]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Charges | 2 |  |  | 7 |  |  | 9 |  |
| Cash payments | (15 | ) |  | (10 | ) |  | (25 | ) |
| Non-cash items and other | (1 | ) |  | 3 |  |  | 2 |  |
| Accrual balance at March 31, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000106040-17-000013:notes:193]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| Charges | 12 |  |  | 40 |  |  | 52 |  |
| Cash payments | (31 | ) |  | (37 | ) |  | (68 | ) |
| Non-cash items and other | — |  |  | (1 | ) |  | (1 | ) |
| Accrual balance at March 31, 2017 | $ | 7 |  |  | $ | 2 |  |  | $ | 9 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-17-000013:notes:194]
[same as prior period, unchanged from 0000106040-17-000007:notes:193]

[0000106040-17-000013:notes:195]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 1, 2016 | 9.0 |  |  | $ | 55.74 |  |  | 3.9 |  |  | $ | 60 |  |
| Granted | 2.8 |  |  | 44.83 |  |  |  |  |  |
| Exercised | (2.4 | ) |  | 34.27 |  |  |  |  |  |
| Canceled or expired | (0.8 | ) |  | 73.01 |  |  |  |  |  |
| Options outstanding at March 31, 2017 | 8.6 |  |  | 56.66 |  |  | 4.4 |  |  | 245 |  |
| Exercisable at March 31, 2017 | 4.0 |  |  | 57.96 |  |  | 3.0 |  |  | 115 |  |
| Vested and expected to vest after March 31, 2017 | 8.3 |  |  | 56.88 |  |  | 4.4 |  |  | 235 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-17-000013:notes:196]
[same as prior period, unchanged from 0000106040-17-000007:notes:195]

[0000106040-17-000013:notes:197]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
|  | (in millions) |  |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | $ | 41.92 |  |
| Granted | 5.7 |  |  | 45.94 |  |
| Vested | (5.5 | ) |  | 47.44 |  |
| Forfeited | (1.7 | ) |  | 44.08 |  |
| RSUs and PSUs outstanding at March 31, 2017 | 14.2 |  |  | 44.43 |  |
| Expected to vest after March 31, 2017 | 13.3 |  |  | 44.55 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-17-000013:notes:198]
[same as prior period, unchanged from 0000106040-17-000007:notes:197]

[0000106040-17-000013:notes:199]
[same as prior period, unchanged from 0000106040-17-000007:notes:198]

[0000106040-17-000013:notes:200]
As of March 31, 2017, compensation cost related to unvested stock options was $71 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.7 years. As of March 31, 2017, compensation cost related to the Company’s Employee Stock Purchase Plan (“ESPP”) rights issued to employees but not yet recognized was $34 million and will be amortized on a straight-line basis over a weighted average service period of approximately 1.2 years.

[0000106040-17-000013:notes:201]
As of March 31, 2017, the aggregate unamortized fair value of all unvested restricted stock units (“RSUs”) and performance stock units (“PSUs”) was $537 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 2.5 years, assuming the performance metrics are met for the PSUs.

[0000106040-17-000013:notes:202]
[same as prior period, unchanged from 0000106040-17-000007:notes:201]

[0000106040-17-000013:notes:203]
As of March 31, 2017, the Company had options outstanding to purchase an aggregate of 6.4 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $245 million at that date.

[0000106040-17-000013:notes:204]
[same as prior period, unchanged from 0000106040-17-000007:notes:203]

[0000106040-17-000013:notes:205]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The aggregate value of RSUs and PSUs that became fully-vested during the nine months ended March 31, 2017 was $363 million, determined as of the vest date.

[0000106040-17-000013:notes:206]
[same as prior period, unchanged from 0000106040-17-000007:notes:205]

[0000106040-17-000013:notes:207]
As of March 31, 2017, all outstanding stock appreciation rights (“SARs”) issued to employees were fully vested and will be settled in cash upon exercise. The fair value of SARs is solely subject to market price fluctuations. The following table presents the adjustments to the fair market value of SARs for the three and nine months ended March 31, 2017 and April 1, 2016:

[0000106040-17-000013:notes:208]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
|  | (in millions) |
| SAR expense (benefit) | $ | (1 | ) |  | $ | (7 | ) |  | $ | 7 |  |  | $ | (18 | ) |
| Tax expense (benefit) | 1 |  |  | 1 |  |  | (1 | ) |  | 2 |  |
| Total SAR expense (benefit) | $ | — |  |  | $ | (6 | ) |  | $ | 6 |  |  | $ | (16 | ) |

[0000106040-17-000013:notes:209]
The Company had a total liability of $6 million and $20 million related to SARs included in Accrued expenses in the Company’s condensed consolidated balance sheet as of March 31, 2017 and July 1, 2016, respectively. As of March 31, 2017, an immaterial number of SARs were outstanding with a weighted average exercise price of $24.10.

[0000106040-17-000013:notes:210]
[same as prior period, unchanged from 0000106040-17-000007:notes:209]

[0000106040-17-000013:notes:211]
The Company’s Board of Directors (the “Board”) has authorized $5.0 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares of common stock during the three and nine months ended March 31, 2017. The remaining amount available to be purchased under the Company’s stock repurchase program as of March 31, 2017 was $2.1 billion.

[0000106040-17-000013:notes:212]
[same as prior period, unchanged from 0000106040-17-000007:notes:211]

[0000106040-17-000013:notes:213]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. During the three and nine months ended March 31, 2017, the Company paid dividends of $144 million and $428 million, respectively.

[0000106040-17-000013:notes:214]
On February 1, 2017, the Board declared a cash dividend for the quarter ended March 31, 2017 of $0.50 per share of the Company’s common stock. The cash dividend of $145 million was paid on April 17, 2017 to the Company’s shareholders of record as of March 31, 2017.

[0000106040-17-000013:notes:215]
On May 3, 2017, the Board declared a cash dividend for the quarter ending June 30, 2017 of $0.50 per share of the Company’s common stock. The cash dividend will be paid on July 17, 2017 to shareholders of record as of June 30, 2017.

[0000106040-17-000013:notes:216]
[same as prior period, unchanged from 0000106040-17-000007:notes:215]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-17-000013:notes:217]
[same as prior period, unchanged from 0000106040-17-000007:notes:216]

[0000106040-17-000013:notes:218]
Accounts receivable, net

[0000106040-17-000013:notes:219]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three and nine months ended March 31, 2017, the Company did not sell any trade accounts receivable. During the three and nine months ended April 1, 2016, the Company sold trade accounts receivable and received cash proceeds of $35 million and $235 million, respectively. The discounts on the trade accounts receivable sold during the three and nine months ended April 1, 2016 were not material and were recorded within Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-17-000013:notes:220]
The purchase price adjustments resulted from adjustments to the assessment of fair value for certain acquired intangible assets; inventory; property, plant and equipment; contingent liabilities; and deferred tax liability related to the acquisition of SanDisk Corporation (“SanDisk”).

[0000106040-17-000013:notes:221]
Acquired in-process research and development (“IPR&D”) is accounted for as an indefinite-lived intangible asset. Upon completion of development, IPR&D is considered to be an amortizable finite-lived intangible asset. During the three months ended December 30, 2016, the Company reclassified $1.7 billion of acquired IPR&D to existing technology and commenced amortization over an estimated useful life of 4 years.

[0000106040-17-000013:notes:222]
The long-term portion of the warranty accrual classified in Other liabilities was $127 million and $107 million as of March 31, 2017 and July 1, 2016, respectively.

[0000106040-17-000013:notes:223]
Accumulated other comprehensive income (loss)

[0000106040-17-000013:notes:224]
Other comprehensive income (loss) (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-17-000013:notes:225]
[same as prior period, unchanged from 0000106040-17-000007:notes:224]

[0000106040-17-000013:notes:226]
[same as prior period, unchanged from 0000106040-17-000007:notes:225]

[0000106040-17-000013:notes:227]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 for employee termination, asset impairments and other charges, as presented above, the Company recognized $7 million and $37 million during the three and nine months ended March 31, 2017, respectively, of accelerated depreciation on facility assets in cost of revenue and operating expense.

[0000106040-17-000013:notes:228]
[same as prior period, unchanged from 0000106040-17-000007:notes:227]

[0000106040-17-000013:notes:229]
In January 2016, the Company announced the closing of its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. As of December 30, 2016, the Company substantially completed all activities related to the closure of the facility. The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 31, 2017:

[0000106040-17-000013:notes:230]
[same as prior period, unchanged from 0000106040-17-000007:notes:229]

[0000106040-17-000013:notes:231]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 31, 2017:
