# WDC notes — 0000106040-18-000010


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-18-000010:notes:1]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of December 29, 2017, by remaining contractual maturity, were as follows:

[0000106040-18-000010:notes:2]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 24 |  |  | $ | 23 |  |
| Due in one to five years (included in other non-current assets) | 94 |  |  | 94 |  |
| Total | $ | 118 |  |  | $ | 117 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-18-000010:notes:3]
[same as prior period, unchanged from 0000106040-17-000036:notes:3]

[0000106040-18-000010:notes:4]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 6,272 |  |  | $ | 6,354 |  |
| Short-term marketable securities | 23 |  |  | 24 |  |
| Long-term marketable securities (included within other non-current assets) | 94 |  |  | 94 |  |
| Total cash, cash equivalents and marketable securities | $ | 6,389 |  |  | $ | 6,472 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-18-000010:notes:5]
[same as prior period, unchanged from 0000106040-17-000036:notes:5]

[0000106040-18-000010:notes:6]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Benefit obligations | $ | 249 |  |  | $ | 249 |  |
| Fair value of plan assets | 192 |  |  | 189 |  |
| Unfunded status | $ | 57 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-18-000010:notes:7]
Commitments, Contingencies and Related Parties

[0000106040-18-000010:notes:8]
Flash Ventures

[0000106040-18-000010:notes:9]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-18-000010:notes:10]
In connection with a settlement agreement with Toshiba, in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6. See also Note 13, Legal Proceedings.

[0000106040-18-000010:notes:11]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 29, 2017 and June 30, 2017:

[0000106040-18-000010:notes:12]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 101 |  |  | 119 |  |
| Notes receivable, Flash Forward | 429 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 279 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,845 |  |  | $ | 1,340 |  |

[0000106040-18-000010:notes:13]
During the three and six months ended December 29, 2017, the Company made net payments to Flash Ventures of $1.2 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-18-000010:notes:14]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-18-000010:notes:15]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no such impairments in the three and six months ended December 29, 2017 and December 30, 2016.

[0000106040-18-000010:notes:16]
As of December 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $250 million and $206 million, respectively.

[0000106040-18-000010:notes:17]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-18-000010:notes:18]
|  | December 29, 2017 |
| Notes receivable | $ | 1,267 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 941 |  |
| Inventory and prepayments | 268 |  |
| Maximum estimable loss exposure | $ | 3,054 |  |

[0000106040-18-000010:notes:19]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-18-000010:notes:20]
Off-Balance Sheet Liabilities

[0000106040-18-000010:notes:21]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-18-000010:notes:22]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017.

[0000106040-18-000010:notes:23]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 106 |  |  | $ | 941 |  |

[0000106040-18-000010:notes:24]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017:

[0000106040-18-000010:notes:25]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 267 |  |  | $ | — |  |  | $ | 267 |  |
| Year 2 |  | 178 |  |  | 34 |  |  | 212 |  |
| Year 3 |  | 163 |  |  | 85 |  |  | 248 |  |
| Year 4 |  | 80 |  |  | 98 |  |  | 178 |  |
| Year 5 |  | 15 |  |  | 21 |  |  | 36 |  |
| Total guarantee obligations |  | $ | 703 |  |  | $ | 238 |  |  | $ | 941 |  |

[0000106040-18-000010:notes:26]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-18-000010:notes:27]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (823 | ) |  | $ | (762 | ) |  | $ | 595 |  |  | $ | 167 |  |  | $ | (823 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | 6 |  |  | 5 |  |  | 5 |  |  | (10 | ) |  | 6 |  |
| Net unrealized gain on derivative contracts | 10 |  |  | 3 |  |  | 3 |  |  | (6 | ) |  | 10 |  |
| Net unrealized gain on available-for-sale securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total other comprehensive income, before tax | 16 |  |  | 8 |  |  | 8 |  |  | (16 | ) |  | 16 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (3 | ) |  | — |  |  | 1 |  |  | (1 | ) |  | (3 | ) |
| Other comprehensive income, net of tax | 13 |  |  | 8 |  |  | 9 |  |  | (17 | ) |  | 13 |  |
| Total comprehensive income (loss) | $ | (810 | ) |  | $ | (754 | ) |  | $ | 604 |  |  | $ | 150 |  |  | $ | (810 | ) |

[0000106040-18-000010:notes:28]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (142 | ) |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | (1,213 | ) |  | $ | (142 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustment | 2 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 2 |  |
| Net unrealized gain on derivative contracts | 14 |  |  | 6 |  |  | 6 |  |  | (12 | ) |  | 14 |  |
| Net unrealized loss on available-for-sale securities | (1 | ) |  | (1 | ) |  | (1 | ) |  | 2 |  |  | (1 | ) |
| Total other comprehensive income, before tax | 15 |  |  | 6 |  |  | 6 |  |  | (12 | ) |  | 15 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (3 | ) |  | — |  |  | (1 | ) |  | 1 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 12 |  |  | 6 |  |  | 5 |  |  | (11 | ) |  | 12 |  |
| Total comprehensive income (loss) | $ | (130 | ) |  | $ | 49 |  |  | $ | 1,175 |  |  | $ | (1,224 | ) |  | $ | (130 | ) |

[0000106040-18-000010:notes:29]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 235 |  |  | $ | 184 |  |  | $ | 23 |  |  | $ | (207 | ) |  | $ | 235 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | (186 | ) |  | (186 | ) |  | (210 | ) |  | 396 |  |  | (186 | ) |
| Net unrealized loss on derivative contracts | (136 | ) |  | (136 | ) |  | (132 | ) |  | 268 |  |  | (136 | ) |
| Total other comprehensive loss, before tax | (321 | ) |  | (321 | ) |  | (341 | ) |  | 662 |  |  | (321 | ) |
| Income tax benefit related to items of other comprehensive loss | 9 |  |  | 10 |  |  | 9 |  |  | (19 | ) |  | 9 |  |
| Other comprehensive loss, net of tax | (312 | ) |  | (311 | ) |  | (332 | ) |  | 643 |  |  | (312 | ) |
| Total comprehensive loss | $ | (77 | ) |  | $ | (127 | ) |  | $ | (309 | ) |  | $ | 436 |  |  | $ | (77 | ) |

[0000106040-18-000010:notes:30]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (131 | ) |  | $ | 169 |  |  | $ | (204 | ) |  | $ | 35 |  |  | $ | (131 | ) |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 6 |  |  | 6 |  |  | 6 |  |  | (12 | ) |  | 6 |  |
| Foreign currency translation adjustment | (169 | ) |  | (169 | ) |  | (192 | ) |  | 361 |  |  | (169 | ) |
| Net unrealized loss on derivative contracts | (140 | ) |  | (140 | ) |  | (136 | ) |  | 276 |  |  | (140 | ) |
| Total other comprehensive loss, before tax | (303 | ) |  | (303 | ) |  | (322 | ) |  | 625 |  |  | (303 | ) |
| Income tax benefit related to items of other comprehensive loss | 3 |  |  | 3 |  |  | 1 |  |  | (4 | ) |  | 3 |  |
| Other comprehensive loss, net of tax | (300 | ) |  | (300 | ) |  | (321 | ) |  | 621 |  |  | (300 | ) |
| Total comprehensive loss | $ | (431 | ) |  | $ | (131 | ) |  | $ | (525 | ) |  | $ | 656 |  |  | $ | (431 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000106040-18-000010:notes:31]
Debt

[0000106040-18-000010:notes:32]
Debt consisted of the following as of December 29, 2017 and June 30, 2017:

[0000106040-18-000010:notes:33]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,022 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,955 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 12,237 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (186 | ) |  | (205 | ) |
| Subtotal | 12,051 |  |  | 13,151 |  |
| Less current portion of long-term debt | (274 | ) |  | (233 | ) |
| Long-term debt | $ | 11,777 |  |  | $ | 12,918 |  |

[0000106040-18-000010:notes:34]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |

[0000106040-18-000010:notes:35]
On November 29, 2017, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to increase the size of its existing $1.0 billion revolving credit facility by $500 million to $1.5 billion. The term of the revolving credit facility remained unchanged and will mature on April 29, 2021. As of December 29, 2017, there were no borrowings under the revolving credit facility.

[0000106040-18-000010:notes:36]
On November 17, 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. On November 8, 2017, the Company borrowed $2.96 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00% (3.57% as of December 29, 2017). Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of December 29, 2017, issuance costs of $3 million remain unamortized. In connection with the settlements of the U.S. Term Loan B-2 and Euro Term Loan B-2, the Company recognized an aggregate loss on debt extinguishment of $2 million consisting of unamortized issuance costs.

[0000106040-18-000010:notes:37]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of December 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-18-000010:notes:38]
[same as prior period, unchanged from 0000106040-17-000036:notes:33]

[0000106040-18-000010:notes:39]
As of December 29, 2017, the Company had outstanding foreign exchange forward contracts which were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps which were designated as cash flow hedges. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Condensed Consolidated Financial Statements for the three and six months ended December 29, 2017 and December 30, 2016.

[0000106040-18-000010:notes:40]
As of December 29, 2017, the amount of existing net gains related to cash flow hedges recorded in AOCI that are expected to be reclassified into earnings over the next twelve months was $8 million. In addition, as of December 29, 2017, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-18-000010:notes:41]
A change in the fair value of non-designated hedges is recognized in earnings in the period incurred and is reported as a component of Other income (expense), net. The changes in fair value on these contracts were immaterial to the Condensed Consolidated Financial Statements for the three and six months ended December 29, 2017 and December 30, 2016.

[0000106040-18-000010:notes:42]
Derivative Instruments

[0000106040-18-000010:notes:43]
The fair value and balance sheet location of the Company’s derivative instruments were as follows:

[0000106040-18-000010:notes:44]
|  | Derivative Assets |
|  | Other current assets |
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 6 |  |  | $ | 6 |  |
| Foreign exchange forward contracts, not designated | 5 |  |  | 10 |  |
| Interest rate swaps, designated | 8 |  |  | — |  |
| Total derivatives | $ | 19 |  |  | $ | 16 |  |

[0000106040-18-000010:notes:45]
|  | Derivative Liabilities |
|  | Accrued expenses |
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 4 |  |  | $ | 2 |  |
| Foreign exchange forward contracts, not designated | 3 |  |  | 6 |  |
| Interest rate swaps, designated | — |  |  | 1 |  |
| Total derivatives | $ | 7 |  |  | $ | 9 |  |

[0000106040-18-000010:notes:46]
[same as prior period, unchanged from 0000106040-17-000036:notes:38]

[0000106040-18-000010:notes:47]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 29, 2017 and June 30, 2017, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.

[0000106040-18-000010:notes:48]
[same as prior period, unchanged from 0000106040-17-000036:notes:40]

[0000106040-18-000010:notes:49]
The impact of derivative contracts designated as hedging instruments on the Condensed Consolidated Financial Statements was as follows:

[0000106040-18-000010:notes:50]
|  | Amount of Gain (Loss) Recognized in AOCI |  | Amount of Gain (Loss) Recognized in AOCI |
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts | $ | 7 |  |  | $ | (119 | ) |  | $ | 7 |  |  | $ | (97 | ) |
| Interest rate swaps | 7 |  |  | — |  |  | 8 |  |  | — |  |
| Total | $ | 14 |  |  | $ | (119 | ) |  | $ | 15 |  |  | $ | (97 | ) |

[0000106040-18-000010:notes:51]
|  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts | $ | 4 |  |  | $ | 16 |  |  | $ | 1 |  |  | $ | 42 |  |
| Total | $ | 4 |  |  | $ | 16 |  |  | $ | 1 |  |  | $ | 42 |  |

[0000106040-18-000010:notes:52]
The total net realized transaction and foreign exchange forward contract currency gains and losses were not material to the Condensed Consolidated Financial Statements for the three and six months ended December 29, 2017 and December 30, 2016.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-18-000010:notes:53]
[same as prior period, unchanged from 0000106040-17-000036:notes:42]

[0000106040-18-000010:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Options | $ | 6 |  |  | $ | 11 |  |  | $ | 13 |  |  | $ | 23 |  |
| Restricted and performance stock units | 88 |  |  | 90 |  |  | 171 |  |  | 169 |  |
| Employee stock purchase plan | 5 |  |  | 1 |  |  | 12 |  |  | 9 |  |
| Subtotal | 99 |  |  | 102 |  |  | 196 |  |  | 201 |  |
| Tax benefit | (10 | ) |  | (29 | ) |  | (34 | ) |  | (54 | ) |
| Total | $ | 89 |  |  | $ | 73 |  |  | $ | 162 |  |  | $ | 147 |  |

[0000106040-18-000010:notes:55]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 11 |  |  | $ | 26 |  |  | $ | 24 |  |
| Research and development | 45 |  |  | 43 |  |  | 89 |  |  | 87 |  |
| Selling, general and administrative | 41 |  |  | 43 |  |  | 81 |  |  | 85 |  |
| Employee termination, asset impairment, and other charges | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Subtotal | 99 |  |  | 102 |  |  | 196 |  |  | 201 |  |
| Tax benefit | (10 | ) |  | (29 | ) |  | (34 | ) |  | (54 | ) |
| Total | $ | 89 |  |  | $ | 73 |  |  | $ | 162 |  |  | $ | 147 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-18-000010:notes:56]
[same as prior period, unchanged from 0000106040-17-000036:notes:45]

[0000106040-18-000010:notes:57]
[same as prior period, unchanged from 0000106040-17-000036:notes:46]

[0000106040-18-000010:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (823 | ) |  | $ | 235 |  |  | $ | (142 | ) |  | $ | (131 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 296 |  |  | 286 |  |  | 295 |  |  | 285 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | 8 |  |  | — |  |  | — |  |
| Diluted | 296 |  |  | 294 |  |  | 295 |  |  | 285 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (2.78 | ) |  | $ | 0.82 |  |  | $ | (0.48 | ) |  | $ | (0.46 | ) |
| Diluted | $ | (2.78 | ) |  | $ | 0.80 |  |  | $ | (0.48 | ) |  | $ | (0.46 | ) |
| Anti-dilutive potential common shares excluded(1) | 12 |  |  | 5 |  |  | 12 |  |  | 13 |  |

[0000106040-18-000010:notes:59]
[same as prior period, unchanged from 0000106040-17-000036:notes:48]

[0000106040-18-000010:notes:60]
[same as prior period, unchanged from 0000106040-17-000036:notes:49]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-18-000010:notes:61]
[same as prior period, unchanged from 0000106040-17-000036:notes:50]

[0000106040-18-000010:notes:62]
[same as prior period, unchanged from 0000106040-17-000036:notes:51]

[0000106040-18-000010:notes:63]
[same as prior period, unchanged from 0000106040-17-000036:notes:52]

[0000106040-18-000010:notes:64]
[same as prior period, unchanged from 0000106040-17-000036:notes:53]

[0000106040-18-000010:notes:65]
[same as prior period, unchanged from 0000106040-17-000036:notes:54]

[0000106040-18-000010:notes:66]
[same as prior period, unchanged from 0000106040-17-000036:notes:55]

[0000106040-18-000010:notes:67]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 29, 2017 and June 30, 2017, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-18-000010:notes:68]
|  | December 29, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 3,016 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,016 |  |
| Certificates of deposit | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total cash equivalents | 3,016 |  |  | 7 |  |  | — |  |  | 3,023 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Equity securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Total short-term investments | 3 |  |  | 20 |  |  | — |  |  | 23 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Asset-backed securities | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Municipal notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total long-term investments | 5 |  |  | 89 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Interest rate swap contract | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total assets at fair value | $ | 3,024 |  |  | $ | 135 |  |  | $ | — |  |  | $ | 3,159 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0000106040-18-000010:notes:69]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,836 |  |
| Certificates of deposit | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total cash equivalents | 2,836 |  |  | 10 |  |  | — |  |  | 2,846 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 4 |  |  | 20 |  |  | — |  |  | 24 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term investments | 5 |  |  | 89 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,845 |  |  | $ | 135 |  |  | $ | — |  |  | $ | 2,980 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swap contract | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Exchange options | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 10 |  |

[0000106040-18-000010:notes:70]
During the three and six months ended December 29, 2017, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-18-000010:notes:71]
[same as prior period, unchanged from 0000106040-17-000036:notes:60]

[0000106040-18-000010:notes:72]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of December 29, 2017 and June 30, 2017. The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of December 29, 2017, by remaining contractual maturity, were as follows:

[0000106040-18-000010:notes:73]
The Company determined available-for-sale securities had no material other-than-temporary impairments in the three and six months ended December 29, 2017 or December 30, 2016.

[0000106040-18-000010:notes:74]
[same as prior period, unchanged from 0000106040-17-000036:notes:63]

[0000106040-18-000010:notes:75]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2018 and the fourth quarter of 2017, respectively.

[0000106040-18-000010:notes:76]
|  | December 29, 2017 |  | June 30, 2017 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Secured Notes | $ | 1,838 |  |  | $ | 2,026 |  |  | $ | 1,835 |  |  | $ | 2,062 |  |
| Unsecured Notes | 3,252 |  |  | 3,892 |  |  | 3,244 |  |  | 3,956 |  |
| Term Loan A | 3,978 |  |  | 4,040 |  |  | 4,074 |  |  | 4,130 |  |
| U.S. Term Loan B-2 | — |  |  | — |  |  | 2,968 |  |  | 2,989 |  |
| U.S Term Loan B-3 | 2,952 |  |  | 2,966 |  |  | — |  |  | — |  |
| Euro Term Loan B-2(1) | — |  |  | — |  |  | 1,000 |  |  | 1,010 |  |
| Convertible Debt 2020 | 31 |  |  | 33 |  |  | 30 |  |  | 34 |  |
| Total | $ | 12,051 |  |  | $ | 12,957 |  |  | $ | 13,151 |  |  | $ | 14,181 |  |

[0000106040-18-000010:notes:77]
[same as prior period, unchanged from 0000106040-17-000036:notes:66]

[0000106040-18-000010:notes:78]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company reports these investments under the cost method of accounting as it does not have a significant influence over the operations of these investees. These investments consist of debt and equity securities of privately-held companies which do not have a readily determinable fair value and are carried at historical cost. The Company assesses these securities for indications of other-than-temporary impairments. There were no impairment charges during the three months ended December 29, 2017 and $6 million of impairment charges for the six months ended December 29, 2017, which were included in Other income (expense), net in the Condensed Consolidated Statements of Operations. As of December 29, 2017 and June 30, 2017, these investments aggregated $57 million and $91 million, respectively, and are reported under Other non-current assets in the Condensed Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-18-000010:notes:79]
[same as prior period, unchanged from 0000106040-17-000036:notes:68]

[0000106040-18-000010:notes:80]
The Tax Cuts and Jobs Act (“2017 Act”) was enacted on December 22, 2017. The 2017 Act includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21%, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred and creates new taxes on certain foreign earnings.

[0000106040-18-000010:notes:81]
For the three and six months ended December 29, 2017, the Company has not finalized the accounting for the tax effects of the enactment of the 2017 Act. However, consistent with applicable SEC guidance, the Company has made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and has recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $88 million related to the re-measurement of deferred tax assets and liabilities for the three and six months ended December 29, 2017. For other elements of tax expense noted below, or where the Company has not made an election, the Company has not been able to make a reasonable estimate and continues to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As the Company finalizes the accounting for the tax effects of the enactment of the 2017 Act during a one-year measurement period permitted by applicable SEC guidance, the Company expects to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000010:notes:82]
Additional information regarding the significant provisions of the 2017 Act that are expected to impact the Company is provided below.

[0000106040-18-000010:notes:83]
Re-measurement of deferred taxes

[0000106040-18-000010:notes:84]
The provisional income tax benefit of $88 million recorded for the three and six months ended December 29, 2017 related to the re-measurement of the Company’s deferred tax balance is based on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. However, the Company is still analyzing certain aspects of the 2017 Act and refining the calculations, which could potentially affect the measurement of these balances or potentially give rise to new deferred tax amounts. The Company is also analyzing the impact of the 2017 Act to the existing valuation allowance assessments from both a federal and state tax perspective, which could potentially affect the realizability of the existing deferred tax assets. In calculating the provisional amount, the Company utilized an estimate of the expected reversals of certain tax assets and liabilities, which will be revised in future quarters during the one-year measurement period as additional information becomes available.

[0000106040-18-000010:notes:85]
Mandatory deemed repatriation tax

[0000106040-18-000010:notes:86]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. The tax is to be computed using the Company’s total foreign post-1986 earnings and profits that were previously deferred from U.S. income taxes. This tax is based on the amount of foreign earnings held in cash and other specified assets which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period. For the three and six months ended December 29, 2017, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.66 billion for foreign subsidiaries and $132 million of this amount is classified as a current tax liability. The calculation of the mandatory deemed repatriation tax liability is provisional and based upon preliminary estimates of post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on a provisional amount of foreign earnings held in cash and other specified assets, which the Company expects will require additional clarifying guidance from U.S. Treasury. As such, the provisional amount may change during the one-year measurement period when the Company finalizes the calculation of post-1986 foreign earnings and profits and the amount of foreign earnings held in cash or other specified assets.

[0000106040-18-000010:notes:87]
Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., the Company continues to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires the Company to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax, (e.g. foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the provisional tax expense for the three and six months ended December 29, 2017 is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, the Company’s plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings.  In the event the Company determines not to continue to assert the permanent reinvestment of part or all of foreign undistributed earnings, such a determination could result in the accrual and payment of additional foreign, state and local taxes.

[0000106040-18-000010:notes:88]
Deferred taxes on foreign earnings

[0000106040-18-000010:notes:89]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision is effective for tax years beginning on or after January 1, 2018 which for the Company would be the fiscal year beginning on June 30, 2018 (fiscal year 2019). The Company has not progressed sufficiently in the analysis of this provision to make an election either to account for the effects of this provision either as a component of future income tax expense in the period the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities have been established for timing differences between foreign U.S. GAAP income and foreign earnings and profits which would be expected to reverse under the new minimum tax in future years. Additionally, the Company has not yet completed the calculation of post-1986 foreign earnings and profits for the mandatory repatriation tax, which would be the starting point for the measurement of deferred tax assets and liabilities in order to record any provisional amounts.

[0000106040-18-000010:notes:90]
The following table presents the Company’s income tax expense and the effective tax rate, which reflect provisional amounts related to the mandatory deemed repatriation tax and re-measurement of deferred tax assets and liabilities pursuant to the 2017 Act as discussed above:

[0000106040-18-000010:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Income before taxes | $ | 774 |  |  | $ | 321 |  |  | $ | 1,484 |  |  | $ | 50 |  |
| Income tax expense | $ | 1,597 |  |  | $ | 86 |  |  | $ | 1,626 |  |  | $ | 181 |  |
| Effective tax rate | 206 | % |  | 27 | % |  | 110 | % |  | 362 | % |

[0000106040-18-000010:notes:92]
Under the 2017 Act, the reduction of the U.S. federal corporate tax rate from 35% to 21% is effective January 1, 2018 requiring companies to use a blended rate for its fiscal 2018 tax year by applying a pro-rated percentage of the number of days before and after the January 1, 2018 effective date. This results in the use of an estimated annual effective rate of approximately 28% for the Company’s U.S. federal corporate tax rate for fiscal year 2018. The reduction in the U.S. federal corporate tax rate from 35% to the blended tax rate of 28% for fiscal year 2018 is estimated to have reduced the Company’s income tax expense by $7 million for the three and six months ended December 29, 2017. For fiscal year 2019 and beyond, the Company will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000010:notes:93]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act. Excluding these items, the effective tax rate for the three and six months ended December 29, 2017 would be approximately 4%. The primary drivers for the remaining difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are the current year generation of tax credits, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires the Company to now recognize $5 million and $27 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of its income tax expense for the three and six months ended December 29, 2017, respectively. The windfall tax benefits for the three and six months ended December 30, 2016 were recorded within stockholders’ equity.

[0000106040-18-000010:notes:94]
Income tax expense for the six months ended December 30, 2016 was attributable to discrete effects consisting of income tax expense from the integration of SanDisk Corporation (“SanDisk”) of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $96 million. The primary drivers for the difference between the effective tax rate for the six months ended December 30, 2016 and the U.S. Federal statutory rate of 35% are these discrete items, the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-18-000010:notes:95]
During the six months ended December 29, 2017, the Company recorded a net increase of $7 million in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of December 29, 2017, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $529 million. Accrued interest and penalties related to unrecognized tax benefits as of December 29, 2017 was approximately $94 million.

[0000106040-18-000010:notes:96]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. Meetings with the IRS Appeals Office began in March 2017. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-18-000010:notes:97]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 29, 2017, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-18-000010:notes:98]
Legal Proceedings

[0000106040-18-000010:notes:99]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-18-000010:notes:100]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-18-000010:notes:101]
Intellectual Property Litigation

[0000106040-18-000010:notes:102]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. In December 2017, WD and HGST filed an amended notice of appeal with the Federal Circuit with respect to validity. In January 2018, WD, HGST and Convolve entered into a settlement agreement resolving the litigation and agreeing to seek dismissal of all claims and actions between the parties.

[0000106040-18-000010:notes:103]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000010:notes:104]
Antitrust

[0000106040-18-000010:notes:105]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.

[0000106040-18-000010:notes:106]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000010:notes:107]
Securities

[0000106040-18-000010:notes:108]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000010:notes:109]
Toshiba Matters

[0000106040-18-000010:notes:110]
In December 2017, the Company entered into a Confidential Settlement and Mutual Release Agreement (the “Toshiba Settlement Agreement”) with Toshiba and TMC. Under the Toshiba Settlement Agreement, the parties agreed to withdraw and seek dismissal of the litigation and arbitration proceedings discussed below.  Further information about the Toshiba Settlement Agreement is set forth below under “Settlement Agreement.”

[0000106040-18-000010:notes:111]
Proceedings

[0000106040-18-000010:notes:112]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and TMC in the Tokyo District Court. The petition alleged that the Company engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requested injunctive relief.

[0000106040-18-000010:notes:113]
In August 2017, the Company received a complaint filed by Toshiba and TMC in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint was based on the same allegations as the petition for provisional disposition.

[0000106040-18-000010:notes:114]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, TMC, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer.

[0000106040-18-000010:notes:115]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture (the “Access Restrictions”). SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order, in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. In July 2017, SanDisk LLC amended its request for arbitration to, among other things, add TMC as a defendant.

[0000106040-18-000010:notes:116]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan. The SanDisk Subsidiaries sought, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.

[0000106040-18-000010:notes:117]
Settlement Agreement

[0000106040-18-000010:notes:118]
In December 2017, the Company, the SanDisk Subsidiaries, Toshiba and TMC entered into the Toshiba Settlement Agreement pursuant to which the parties agreed to withdraw and seek dismissal of the proceedings above and mutually release each other from all claims relating to, among other things, (i) the transfer of Toshiba’s equity interests in Flash Ventures to TMC, (ii) the Access Restrictions, (iii) TMC’s decision to invest unilaterally in Phase I of Fab 6 and (iv) the sale of TMC to K.K. Pangea (“Pangea”), which will be owned, as of the closing of the sale, by certain members of a consortium of investors led by Bain Capital (as defined below). In addition, the Company agreed to consent to the transfer of Toshiba’s interests in Flash Ventures to TMC, the assignment of all agreements relating to Flash Ventures by Toshiba to TMC and the sale of TMC to Pangea. Toshiba and TMC have also agreed to end the Access Restrictions. For a period of three years following the closing of the sale of TMC to Pangea, the Company’s consent shall be required for any issuance or transfer of equity securities, voting rights or control in TMC by TMC, Toshiba, Bain Capital or their respective affiliates to certain restricted parties, subject to certain limited exceptions.  Pursuant to the Toshiba Settlement Agreement, the Company and the SanDisk Subsidiaries also entered into certain other agreements with TMC related to the operation of Flash Ventures, including an agreement regarding the construction and operation of Fab 6 and the extension of the term of Flash Alliance.

[0000106040-18-000010:notes:119]
In December 2017, the Company and the SanDisk Subsidiaries also entered into a Confidential Settlement Agreement and Mutual Release with Bain Capital Private Equity, L.P., BCPE Pangea Cayman, L.P., BCPE Pangea Cayman2, Ltd., Bain Capital Fund XII, L.P., Bain Capital Asia Fund III, L.P. and Pangea (together, “Bain Capital”) on terms substantially similar to the terms of the Toshiba Settlement Agreement, subject to certain transfer restrictions on Bain Capital.

[0000106040-18-000010:notes:120]
Copyright

[0000106040-18-000010:notes:121]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000010:notes:122]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000010:notes:123]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $177 million, inclusive of amounts accrued, if it does not prevail in this matter.

[0000106040-18-000010:notes:124]
Other Matters

[0000106040-18-000010:notes:125]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-18-000010:notes:126]
Recently Adopted Accounting Pronouncements

[0000106040-18-000010:notes:127]
In August 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-15, “Statement of Cash Flows (Topic 230), Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). ASU 2016-15 provides amendments that address eight specific cash flow classification issues for which there exists diversity in practice: Debt prepayment or debt extinguishment costs; settlement of zero-coupon debt instruments or other debt instruments with coupon interest rates that are insignificant in relation to the effective interest rate of the borrowing; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies, including bank-owned life insurance policies; distributions received from equity method investees; beneficial interests in securitization transactions; and separately identifiable cash flows and application of the predominance principle. The Company adopted ASU 2016-15 in the second quarter of 2018 on a modified retrospective basis as required by the standard. The Company’s adoption of ASU 2016-15 did not have a material effect on the Consolidated Financial Statements.

[0000106040-18-000010:notes:128]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). ASU 2016-09 simplifies several aspects of the accounting for stock-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The Company adopted this standard in the first quarter of 2018 using the modified retrospective approach. This adoption resulted in a one-time net increase to beginning retained earnings of $70 million, consisting of a $58 million cumulative adjustment for the previously unrecognized windfall tax benefits related to previous vesting and exercises of stock-based awards, and a $19 million cumulative adjustment related to the change in accounting policy for estimated forfeitures and share cancellations, partially offset by a decrease of $7 million for the related tax impacts of change in forfeiture policy. In addition, under the new standard, the Company will prospectively reflect the tax deficiencies and benefits as an operating activity, rather than as a financing activity under the previous standard, in the Company’s Consolidated Statements of Cash Flows. For the three and six months ended December 29, 2017, the Company recognized excess tax benefits of $5 million and $27 million, respectively, as a component of its income tax expense.

[0000106040-18-000010:notes:129]
In March 2016, the FASB issued ASU No. 2016-07, “Investments- Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting” (“ASU 2016-07”). ASU 2016-07 eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. The Company adopted this standard in the second quarter of 2018. The Company’s adoption of ASU 2016-07 did not have a material impact on its Consolidated Financial Statements.

[0000106040-18-000010:notes:130]
In July 2015, the FASB issued ASU No. 2015‑11, “Inventory (Topic 330) - Simplifying the Measurement of Inventory” (“ASU 2015‑11”), which dictates that an entity should measure inventory within the scope of this update at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this standard in the first quarter of 2018. The Company’s adoption of ASU 2015‑11 did not have a material impact on its Consolidated Financial Statements.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-18-000010:notes:131]
Other liabilities

[0000106040-18-000010:notes:132]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Non-current income taxes payable | $ | 1,425 |  |  | $ | — |  |
| Other non-current liabilities | 1,013 |  |  | 1,180 |  |
| Total other non-current liabilities | $ | 2,438 |  |  | $ | 1,180 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-18-000010:notes:133]
[same as prior period, unchanged from 0000106040-17-000036:notes:104]

[0000106040-18-000010:notes:134]
[same as prior period, unchanged from 0000106040-17-000036:notes:105]

[0000106040-18-000010:notes:135]
[same as prior period, unchanged from 0000106040-17-000036:notes:106]

[0000106040-18-000010:notes:136]
[same as prior period, unchanged from 0000106040-17-000036:notes:107]

[0000106040-18-000010:notes:137]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 56 |  |  | 59 |  |
| Net amount recognized | $ | 57 |  |  | $ | 60 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-18-000010:notes:138]
Property, plant and equipment, net

[0000106040-18-000010:notes:139]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,913 |  |  | $ | 1,855 |  |
| Machinery and equipment | 7,011 |  |  | 6,815 |  |
| Computer equipment and software | 433 |  |  | 404 |  |
| Furniture and fixtures | 50 |  |  | 49 |  |
| Leasehold improvements | 253 |  |  | 259 |  |
| Construction-in-process | 175 |  |  | 144 |  |
| Property, plant and equipment, gross | 9,835 |  |  | 9,526 |  |
| Accumulated depreciation | (6,781 | ) |  | (6,493 | ) |
| Property, plant, and equipment, net | $ | 3,054 |  |  | $ | 3,033 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-18-000010:notes:140]
[same as prior period, unchanged from 0000106040-17-000036:notes:111]

[0000106040-18-000010:notes:141]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
| AOCI Component |  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on designated hedging activities: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 4 |  |  | $ | 16 |  |  | $ | 1 |  |  | $ | 40 |  |  | Cost of revenue |
| Foreign exchange contracts |  | — |  |  | — |  |  | — |  |  | 2 |  |  | Research and development |
| Unrealized holding gain on designated hedging activities |  | 4 |  |  | 16 |  |  | 1 |  |  | 42 |  |  |  |
| Total reclassifications for the period |  | $ | 4 |  |  | $ | 16 |  |  | $ | 1 |  |  | $ | 42 |  |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-18-000010:notes:142]
[same as prior period, unchanged from 0000106040-17-000036:notes:113]

[0000106040-18-000010:notes:143]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Available for Sale Securities |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 30, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | 2 |  |  | $ | (3 | ) |  | $ | (58 | ) |
| Other comprehensive income (loss) before reclassifications | — |  |  | 2 |  |  | (1 | ) |  | 15 |  |  | 16 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Income tax expense related to items of other comprehensive income | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net current-period other comprehensive income | — |  |  | 2 |  |  | (1 | ) |  | 11 |  |  | 12 |  |
| Balance at December 29, 2017 | $ | (18 | ) |  | $ | (37 | ) |  | $ | 1 |  |  | $ | 8 |  |  | $ | (46 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-18-000010:notes:144]
| Condensed Consolidating Balance Sheet |
| As of December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 22 |  |  | $ | 1,187 |  |  | $ | 5,063 |  |  | $ | — |  |  | $ | 6,272 |  |
| Short-term investments | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Accounts receivable, net | — |  |  | 1,207 |  |  | 845 |  |  | — |  |  | 2,052 |  |
| Intercompany receivables | 1,760 |  |  | 3,670 |  |  | 1,997 |  |  | (7,427 | ) |  | — |  |
| Inventories | — |  |  | 1,076 |  |  | 1,481 |  |  | (276 | ) |  | 2,281 |  |
| Other current assets | 5 |  |  | 181 |  |  | 264 |  |  | 35 |  |  | 485 |  |
| Total current assets | 1,787 |  |  | 7,321 |  |  | 9,673 |  |  | (7,668 | ) |  | 11,113 |  |
| Property, plant and equipment, net | — |  |  | 1,100 |  |  | 1,954 |  |  | — |  |  | 3,054 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,845 |  |  | — |  |  | 1,845 |  |
| Goodwill | — |  |  | 387 |  |  | 9,689 |  |  | — |  |  | 10,076 |  |
| Other intangible assets, net | — |  |  | 44 |  |  | 3,186 |  |  | — |  |  | 3,230 |  |
| Investments in consolidated subsidiaries | 19,030 |  |  | 18,314 |  |  | — |  |  | (37,344 | ) |  | — |  |
| Loans due from consolidated affiliates | 3,306 |  |  | 16 |  |  | — |  |  | (3,322 | ) |  | — |  |
| Other non-current assets | 51 |  |  | 612 |  |  | 461 |  |  | (602 | ) |  | 522 |  |
| Total assets | $ | 24,174 |  |  | $ | 27,794 |  |  | $ | 26,808 |  |  | $ | (48,936 | ) |  | $ | 29,840 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 227 |  |  | $ | 1,694 |  |  | $ | — |  |  | $ | 1,921 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Intercompany payables | 609 |  |  | 4,500 |  |  | 2,318 |  |  | (7,427 | ) |  | — |  |
| Accrued expenses | 273 |  |  | 457 |  |  | 426 |  |  | 35 |  |  | 1,191 |  |
| Accrued compensation | — |  |  | 340 |  |  | 183 |  |  | — |  |  | 523 |  |
| Accrued warranty | — |  |  | 5 |  |  | 189 |  |  | — |  |  | 194 |  |
| Current portion of long-term debt | 274 |  |  | — |  |  | — |  |  | — |  |  | 274 |  |
| Total current liabilities | 1,156 |  |  | 5,529 |  |  | 5,060 |  |  | (7,392 | ) |  | 4,353 |  |
| Long-term debt | 11,746 |  |  | — |  |  | 31 |  |  | — |  |  | 11,777 |  |
| Loans due to consolidated affiliates | — |  |  | 492 |  |  | 2,830 |  |  | (3,322 | ) |  | — |  |
| Other liabilities | — |  |  | 2,523 |  |  | 517 |  |  | (602 | ) |  | 2,438 |  |
| Total liabilities | 12,902 |  |  | 8,544 |  |  | 8,438 |  |  | (11,316 | ) |  | 18,568 |  |
| Total shareholders’ equity | 11,272 |  |  | 19,250 |  |  | 18,370 |  |  | (37,620 | ) |  | 11,272 |  |
| Total liabilities and shareholders’ equity | $ | 24,174 |  |  | $ | 27,794 |  |  | $ | 26,808 |  |  | $ | (48,936 | ) |  | $ | 29,840 |  |

[0000106040-18-000010:notes:145]
[same as prior period, unchanged from 0000106040-17-000036:notes:116]


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-18-000010:notes:146]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (279 | ) |  | $ | 108 |  |  | $ | 2,560 |  |  | $ | (74 | ) |  | $ | 2,315 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (113 | ) |  | (303 | ) |  | — |  |  | (416 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | (6 | ) |  | — |  |  | (99 | ) |
| Purchases of investments | — |  |  | (11 | ) |  | (46 | ) |  | — |  |  | (57 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 29 |  |  | — |  |  | 29 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (621 | ) |  | — |  |  | (621 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 112 |  |  | — |  |  | 112 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | 20 |  |  | — |  |  | 19 |  |
| Intercompany loan from consolidated affiliates | 1,395 |  |  | — |  |  | — |  |  | (1,395 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | 65 |  |  | (65 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 1,460 |  |  | (283 | ) |  | (789 | ) |  | (1,395 | ) |  | (1,007 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 99 |  |  | — |  |  | — |  |  | — |  |  | 99 |  |
| Taxes paid on vested stock awards under employee stock plans | (67 | ) |  | — |  |  | — |  |  | — |  |  | (67 | ) |
| Dividends paid to shareholders | (295 | ) |  | — |  |  | — |  |  | — |  |  | (295 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt | (4,114 | ) |  | — |  |  | — |  |  | — |  |  | (4,114 | ) |
| Proceeds from debt | 2,963 |  |  | — |  |  | — |  |  | — |  |  | 2,963 |  |
| Debt issuance costs | (5 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (54 | ) |  | (1,341 | ) |  | 1,395 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 214 |  |  | 204 |  |  | (492 | ) |  | 74 |  |  | — |  |
| Net cash provided by (used in) financing activities | (1,177 | ) |  | 150 |  |  | (1,833 | ) |  | 1,469 |  |  | (1,391 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 4 |  |  | (25 | ) |  | (61 | ) |  | — |  |  | (82 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 22 |  |  | $ | 1,187 |  |  | $ | 5,063 |  |  | $ | — |  |  | $ | 6,272 |  |

[0000106040-18-000010:notes:147]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (256 | ) |  | $ | 211 |  |  | $ | 1,443 |  |  | $ | 102 |  |  | $ | 1,500 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (136 | ) |  | (194 | ) |  | — |  |  | (330 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Purchases of investments | — |  |  | — |  |  | (239 | ) |  | — |  |  | (239 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 279 |  |  | — |  |  | 279 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (309 | ) |  | — |  |  | (309 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Intercompany loans from consolidated affiliates | 770 |  |  | 40 |  |  | — |  |  | (810 | ) |  | — |  |
| Advances from (to) consolidated affiliates | 293 |  |  | (285 | ) |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,063 |  |  | (381 | ) |  | (180 | ) |  | (818 | ) |  | (316 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 90 |  |  | — |  |  | — |  |  | — |  |  | 90 |  |
| Taxes paid on vested stock awards under employee stock plans | (40 | ) |  | — |  |  | — |  |  | — |  |  | (40 | ) |
| Excess tax benefits from employee stock plans | 56 |  |  | — |  |  | — |  |  | — |  |  | 56 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Dividends paid to shareholders | (284 | ) |  | — |  |  | — |  |  | — |  |  | (284 | ) |
| Repayment of debt | (4,767 | ) |  | (2,995 | ) |  | (492 | ) |  | — |  |  | (8,254 | ) |
| Proceeds from debt | 3,992 |  |  | — |  |  | — |  |  | — |  |  | 3,992 |  |
| Debt issuance costs | (7 | ) |  | — |  |  | — |  |  | — |  |  | (7 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (5,966 | ) |  | 5,156 |  |  | 810 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 199 |  |  | 8,808 |  |  | (8,913 | ) |  | (94 | ) |  | — |  |
| Net cash used in financing activities | (761 | ) |  | (153 | ) |  | (4,188 | ) |  | 716 |  |  | (4,386 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net increase (decrease) in cash and cash equivalents | 46 |  |  | (323 | ) |  | (2,934 | ) |  | — |  |  | (3,211 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of period | $ | 46 |  |  | $ | 883 |  |  | $ | 4,011 |  |  | $ | — |  |  | $ | 4,940 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-18-000010:notes:148]
[same as prior period, unchanged from 0000106040-17-000036:notes:119]

[0000106040-18-000010:notes:149]
The Company’s 10.500% senior unsecured notes due 2024 (“Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by the WD Guarantors (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the designation of a Guarantor Subsidiary as an unrestricted subsidiary under the indenture governing the Unsecured Notes, (ii) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the Unsecured Notes, (iii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the Unsecured Notes, (iv) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (v) the Company’s exercise of its defeasance options under the indenture governing the Unsecured Notes, (vi) the dissolution or liquidation of a Guarantor Subsidiary or (vii) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-18-000010:notes:150]
| Condensed Consolidating Statement of Operations |
| For the three months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,764 |  |  | $ | 5,173 |  |  | $ | (3,601 | ) |  | $ | 5,336 |  |
| Cost of revenue | — |  |  | 3,256 |  |  | 3,703 |  |  | (3,636 | ) |  | 3,323 |  |
| Gross profit | — |  |  | 508 |  |  | 1,470 |  |  | 35 |  |  | 2,013 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 400 |  |  | 229 |  |  | — |  |  | 629 |  |
| Selling, general and administrative | 1 |  |  | 276 |  |  | 104 |  |  | — |  |  | 381 |  |
| Intercompany operating expense (income) | — |  |  | (430 | ) |  | 430 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 10 |  |  | 38 |  |  | — |  |  | 48 |  |
| Total operating expenses | 1 |  |  | 256 |  |  | 801 |  |  | — |  |  | 1,058 |  |
| Operating income (loss) | (1 | ) |  | 252 |  |  | 669 |  |  | 35 |  |  | 955 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 66 |  |  | 2 |  |  | 12 |  |  | (66 | ) |  | 14 |  |
| Interest expense | (197 | ) |  | (4 | ) |  | (62 | ) |  | 66 |  |  | (197 | ) |
| Other income (expense), net | — |  |  | (4 | ) |  | 6 |  |  | — |  |  | 2 |  |
| Total interest and other expense, net | (131 | ) |  | (6 | ) |  | (44 | ) |  | — |  |  | (181 | ) |
| Income (loss) before taxes | (132 | ) |  | 246 |  |  | 625 |  |  | 35 |  |  | 774 |  |
| Equity in earnings from subsidiaries | (725 | ) |  | 593 |  |  | — |  |  | 132 |  |  | — |  |
| Income tax expense (benefit) | (34 | ) |  | 1,601 |  |  | 30 |  |  | — |  |  | 1,597 |  |
| Net income (loss) | $ | (823 | ) |  | $ | (762 | ) |  | $ | 595 |  |  | $ | 167 |  |  | $ | (823 | ) |

[0000106040-18-000010:notes:151]
| Condensed Consolidating Statement of Operations |
| For the six months ended December 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 7,474 |  |  | $ | 10,254 |  |  | $ | (7,211 | ) |  | $ | 10,517 |  |
| Cost of revenue | — |  |  | 6,456 |  |  | 7,350 |  |  | (7,215 | ) |  | 6,591 |  |
| Gross profit | — |  |  | 1,018 |  |  | 2,904 |  |  | 4 |  |  | 3,926 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 781 |  |  | 440 |  |  | — |  |  | 1,221 |  |
| Selling, general and administrative | 3 |  |  | 534 |  |  | 208 |  |  | — |  |  | 745 |  |
| Intercompany operating expense (income) | — |  |  | (830 | ) |  | 830 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 21 |  |  | 79 |  |  | — |  |  | 100 |  |
| Total operating expenses | 3 |  |  | 506 |  |  | 1,557 |  |  | — |  |  | 2,066 |  |
| Operating income (loss) | (3 | ) |  | 512 |  |  | 1,347 |  |  | 4 |  |  | 1,860 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 147 |  |  | 4 |  |  | 26 |  |  | (147 | ) |  | 30 |  |
| Interest expense | (401 | ) |  | (10 | ) |  | (138 | ) |  | 147 |  |  | (402 | ) |
| Other income (expense), net | (8 | ) |  | 7 |  |  | (3 | ) |  | — |  |  | (4 | ) |
| Total interest and other income (expense), net | (262 | ) |  | 1 |  |  | (115 | ) |  | — |  |  | (376 | ) |
| Income (loss) before taxes | (265 | ) |  | 513 |  |  | 1,232 |  |  | 4 |  |  | 1,484 |  |
| Equity in earnings from subsidiaries | 32 |  |  | 1,185 |  |  | — |  |  | (1,217 | ) |  | — |  |
| Income tax expense (benefit) | (91 | ) |  | 1,655 |  |  | 62 |  |  | — |  |  | 1,626 |  |
| Net income (loss) | $ | (142 | ) |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | (1,213 | ) |  | $ | (142 | ) |

[0000106040-18-000010:notes:152]
| Condensed Consolidating Statement of Operations |
| For the three months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,786 |  |  | $ | 4,245 |  |  | $ | (3,143 | ) |  | $ | 4,888 |  |
| Cost of revenue | — |  |  | 3,085 |  |  | 3,495 |  |  | (3,225 | ) |  | 3,355 |  |
| Gross profit | — |  |  | 701 |  |  | 750 |  |  | 82 |  |  | 1,533 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 372 |  |  | 213 |  |  | — |  |  | 585 |  |
| Selling, general and administrative | 3 |  |  | 252 |  |  | 103 |  |  | — |  |  | 358 |  |
| Intercompany operating expense (income) | — |  |  | (218 | ) |  | 218 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 9 |  |  | 36 |  |  | — |  |  | 45 |  |
| Total operating expenses | 3 |  |  | 415 |  |  | 570 |  |  | — |  |  | 988 |  |
| Operating income (loss) | (3 | ) |  | 286 |  |  | 180 |  |  | 82 |  |  | 545 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 86 |  |  | — |  |  | 2 |  |  | (83 | ) |  | 5 |  |
| Interest expense | (203 | ) |  | — |  |  | (85 | ) |  | 83 |  |  | (205 | ) |
| Other expense, net | (2 | ) |  | (5 | ) |  | (17 | ) |  | — |  |  | (24 | ) |
| Total interest and other expense, net | (119 | ) |  | (5 | ) |  | (100 | ) |  | — |  |  | (224 | ) |
| Income (loss) before taxes | (122 | ) |  | 281 |  |  | 80 |  |  | 82 |  |  | 321 |  |
| Equity in earnings from subsidiaries | 270 |  |  | 19 |  |  | — |  |  | (289 | ) |  | — |  |
| Income tax expense (benefit) | (87 | ) |  | 116 |  |  | 57 |  |  | — |  |  | 86 |  |
| Net income | $ | 235 |  |  | $ | 184 |  |  | $ | 23 |  |  | $ | (207 | ) |  | $ | 235 |  |

[0000106040-18-000010:notes:153]
| Condensed Consolidating Statement of Operations |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 7,484 |  |  | $ | 8,538 |  |  | $ | (6,420 | ) |  | $ | 9,602 |  |
| Cost of revenue | — |  |  | 6,150 |  |  | 7,048 |  |  | (6,464 | ) |  | 6,734 |  |
| Gross profit | — |  |  | 1,334 |  |  | 1,490 |  |  | 44 |  |  | 2,868 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 813 |  |  | 411 |  |  | — |  |  | 1,224 |  |
| Selling, general and administrative | 4 |  |  | 526 |  |  | 224 |  |  | — |  |  | 754 |  |
| Intercompany operating expense (income) | — |  |  | (569 | ) |  | 569 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 58 |  |  | 55 |  |  | — |  |  | 113 |  |
| Total operating expenses | 4 |  |  | 828 |  |  | 1,259 |  |  | — |  |  | 2,091 |  |
| Operating income (loss) | (4 | ) |  | 506 |  |  | 231 |  |  | 44 |  |  | 777 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 180 |  |  | 1 |  |  | 9 |  |  | (180 | ) |  | 10 |  |
| Interest expense | (431 | ) |  | (5 | ) |  | (185 | ) |  | 180 |  |  | (441 | ) |
| Other expense, net | (274 | ) |  | (4 | ) |  | (18 | ) |  | — |  |  | (296 | ) |
| Total interest and other expense, net | (525 | ) |  | (8 | ) |  | (194 | ) |  | — |  |  | (727 | ) |
| Income (loss) before taxes | (529 | ) |  | 498 |  |  | 37 |  |  | 44 |  |  | 50 |  |
| Equity in earnings from subsidiaries | 217 |  |  | (208 | ) |  | — |  |  | (9 | ) |  | — |  |
| Income tax expense (benefit) | (181 | ) |  | 121 |  |  | 241 |  |  | — |  |  | 181 |  |
| Net income (loss) | $ | (131 | ) |  | $ | 169 |  |  | $ | (204 | ) |  | $ | 35 |  |  | $ | (131 | ) |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-18-000010:notes:154]
[same as prior period, unchanged from 0000106040-17-000036:notes:124]

[0000106040-18-000010:notes:155]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,814 |  |  | $ | 5,160 |  |
| In-process research and development | 80 |  |  | 696 |  |
| Accumulated amortization | (2,664 | ) |  | (2,033 | ) |
| Intangible assets, net | $ | 3,230 |  |  | $ | 3,823 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-18-000010:notes:156]
[same as prior period, unchanged from 0000106040-17-000036:notes:126]

[0000106040-18-000010:notes:157]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 30, 2017 | $ | 10,014 |  |
| Goodwill recorded in connection with acquisitions | 61 |  |
| Foreign currency translation adjustment | 1 |  |
| Balance at December 29, 2017 | $ | 10,076 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-18-000010:notes:158]
[same as prior period, unchanged from 0000106040-17-000036:notes:128]

[0000106040-18-000010:notes:159]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 634 |  |  | $ | 646 |  |
| Work-in-process | 667 |  |  | 632 |  |
| Finished goods | 980 |  |  | 1,063 |  |
| Total inventories | $ | 2,281 |  |  | $ | 2,341 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-18-000010:notes:160]
[same as prior period, unchanged from 0000106040-17-000036:notes:130]

[0000106040-18-000010:notes:161]
[same as prior period, unchanged from 0000106040-17-000036:notes:131]

[0000106040-18-000010:notes:162]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 302 |  |  | $ | 277 |  |  | $ | 311 |  |  | $ | 279 |  |
| Charges to operations | 46 |  |  | 44 |  |  | 90 |  |  | 91 |  |
| Utilization | (43 | ) |  | (35 | ) |  | (81 | ) |  | (80 | ) |
| Changes in estimate related to pre-existing warranties | (1 | ) |  | 27 |  |  | (16 | ) |  | 23 |  |
| Warranty accrual, end of period | $ | 304 |  |  | $ | 313 |  |  | $ | 304 |  |  | $ | 313 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-18-000010:notes:163]
The following table presents an analysis of the components of the activity against the reserve during the six months ended December 29, 2017:

[0000106040-18-000010:notes:164]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 11 |  |  | $ | 2 |  |  | $ | 13 |  |
| Charges | 58 |  |  | 19 |  |  | 77 |  |
| Cash payments | (49 | ) |  | (10 | ) |  | (59 | ) |
| Accrual balance at December 29, 2017 | $ | 20 |  |  | $ | 11 |  |  | $ | 31 |  |

[0000106040-18-000010:notes:165]
[same as prior period, unchanged from 0000106040-17-000036:notes:135]

[0000106040-18-000010:notes:166]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 18 |  |  | $ | 5 |  |  | $ | 23 |  |
| Charges | 17 |  |  | 6 |  |  | 23 |  |
| Cash payments | (14 | ) |  | (4 | ) |  | (18 | ) |
| Accrual balance at December 29, 2017 | $ | 21 |  |  | $ | 7 |  |  | $ | 28 |  |

[0000106040-18-000010:notes:167]
[same as prior period, unchanged from 0000106040-17-000036:notes:133]

[0000106040-18-000010:notes:168]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 32 |  |  | $ | 19 |  |  | $ | 77 |  |  | $ | 46 |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 2 |  |  | — |  |  | 6 |  |
| Business Realignment | 16 |  |  | 7 |  |  | 23 |  |  | 44 |  |
| Total employee termination and other charges | 48 |  |  | 28 |  |  | $ | 100 |  |  | $ | 96 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |  |  |
| Business Realignment | — |  |  | 3 |  |  | — |  |  | 4 |  |
| Total stock-based compensation accelerations and adjustments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Asset impairment: |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total asset impairment | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total employee termination and other charges, and stock-based compensation accelerations and adjustments | $ | 48 |  |  | $ | 45 |  |  | $ | 100 |  |  | $ | 113 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-18-000010:notes:169]
[same as prior period, unchanged from 0000106040-17-000036:notes:139]

[0000106040-18-000010:notes:170]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 30, 2017 | 7.4 |  |  | $ | 58.14 |  |  |  |  |  |
| Exercised | (1.0 | ) |  | 43.16 |  |  |  |  | $ | 46 |  |
| Canceled or expired | (0.2 | ) |  | 63.44 |  |  |  |  |  |
| Options outstanding at December 29, 2017 | 6.2 |  |  | $ | 60.39 |  |  | 4.1 |  | $ | 145 |  |
| Exercisable at December 29, 2017 | 3.6 |  |  | $ | 64.14 |  |  | 3.4 |  | $ | 77 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-18-000010:notes:171]
[same as prior period, unchanged from 0000106040-17-000036:notes:141]

[0000106040-18-000010:notes:172]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | $ | 45.01 |  |  |  |
| Granted | 4.0 |  |  | 84.95 |  |  |  |
| Vested | (2.4 | ) |  | 53.31 |  |  | $ | 206 |  |
| Forfeited | (0.7 | ) |  | 47.75 |  |  |  |
| RSUs and PSUs outstanding at December 29, 2017 | 14.6 |  |  | $ | 53.41 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-18-000010:notes:173]
[same as prior period, unchanged from 0000106040-17-000036:notes:143]

[0000106040-18-000010:notes:174]
[same as prior period, unchanged from 0000106040-17-000036:notes:144]

[0000106040-18-000010:notes:175]
Compensation cost related to unvested stock options, restricted stock unit awards (“RSU”), performance-based restricted stock unit awards (“PSU”) and the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 29, 2017.

[0000106040-18-000010:notes:176]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 38 |  |  | 2.1 |
| RSUs and PSUs (1) | 600 |  |  | 2.2 |
| ESPP | 15 |  |  | 0.6 |
| Total unamortized compensation cost | $ | 653 |  |  |  |

[0000106040-18-000010:notes:177]
| (1) | Weighted average service period assumes the performance metrics are met for the PSUs. |

[0000106040-18-000010:notes:178]
[same as prior period, unchanged from 0000106040-17-000036:notes:148]

[0000106040-18-000010:notes:179]
[same as prior period, unchanged from 0000106040-17-000036:notes:149]

[0000106040-18-000010:notes:180]
[same as prior period, unchanged from 0000106040-17-000036:notes:150]

[0000106040-18-000010:notes:181]
[same as prior period, unchanged from 0000106040-17-000036:notes:151]

[0000106040-18-000010:notes:182]
[same as prior period, unchanged from 0000106040-17-000036:notes:152]

[0000106040-18-000010:notes:183]
The Company’s Board of Directors (the “Board”) has authorized $5.00 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares of common stock during the three months ended December 29, 2017. The remaining amount available to be purchased under the Company’s stock repurchase program as of December 29, 2017 was $2.10 billion.

[0000106040-18-000010:notes:184]
[same as prior period, unchanged from 0000106040-17-000036:notes:154]

[0000106040-18-000010:notes:185]
[same as prior period, unchanged from 0000106040-17-000036:notes:155]

[0000106040-18-000010:notes:186]
On November 1, 2017, the Board declared a cash dividend of $0.50 per share of the Company’s common stock. The cash dividend aggregating $149 million was paid on January 16, 2018 to the Company’s shareholders of record as of December 29, 2017. On January 27, 2018, the Board declared a cash dividend of $0.50 per share to shareholders of record as of March 30, 2018, which will be paid on April 16, 2018. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SubsequentEventsTextBlock

[0000106040-18-000010:notes:187]
Subsequent Events

[0000106040-18-000010:notes:188]
In January 2018, the Company announced its planned issuance of $2.30 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Notes”) and $1.00 billion aggregate principal amount of 1.5% convertible senior notes due 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes will be convertible into cash, shares of the Company’s common stock or a combination thereof, at an initial conversion price of approximately $121.91 per share. The issuance of the 2026 Notes and 2024 Convertible Notes is subject to customary closing conditions.

[0000106040-18-000010:notes:189]
On January 29, 2018, the Company commenced a cash tender offer with respect to any and all of its outstanding $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “2024 Unsecured Notes”).  The consideration offered for the 2024 Unsecured Notes is a total consideration of $1,167.25 per $1,000 principal amount, which includes the tender offer consideration of $1,137.25 and an early tender premium of $30.00. On January 30, 2018, the Company delivered a notice of conditional redemption with respect to the 2024 Unsecured Notes, with a March 1, 2018 redemption date.  The redemption of the 2024 Unsecured Notes is conditioned upon the issuance of the 2026 Notes. On January 30, 2018, the Company also delivered a notice of conditional redemption with respect to its outstanding $1.88 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “2023 Secured Notes”), with a March 1, 2018 redemption date. The redemption of the 2023 Secured Notes is conditioned upon the issuance of the 2024 Convertible Notes and/or an increase in the Company’s Term Loan A credit facility that collectively generates proceeds in excess of $2 billion.

[0000106040-18-000010:notes:190]
Since December 29, 2017, the Company also resumed its stock repurchase program and has repurchased approximately $151 million of its common stock in privately negotiated transactions, at a purchase price per share equal to $87.08 per share, with available cash on hand.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-18-000010:notes:191]
[same as prior period, unchanged from 0000106040-17-000036:notes:157]

[0000106040-18-000010:notes:192]
[same as prior period, unchanged from 0000106040-17-000036:notes:158]

[0000106040-18-000010:notes:193]
The aggregate purchase price of acquisitions during the six months ended December 29, 2017 was $99 million in cash, with net assets acquired primarily consisting of developed technology and other intangibles assets, of which $61 million was allocated to goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings to its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. Goodwill is expected to be deductible for tax purposes because the acquisitions were structured as asset acquisitions but accounted for as business combinations. Concurrent with these acquisitions, the Company received $36 million in proceeds on previously outstanding notes receivable due from these acquired entities.

[0000106040-18-000010:notes:194]
During the six months ended December 29, 2017, the Company incurred $6 million of transaction expenses related to these acquisitions, which are primarily included within Selling, General and Administrative expenses in the Condensed Consolidated Statements of Operations. Revenues and earnings related to these acquisitions was not material.

[0000106040-18-000010:notes:195]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During the three months ended December 29, 2017, two IPR&D projects reached technological feasibility totaling $616 million and commenced amortization over an estimated useful life of 4 years.

[0000106040-18-000010:notes:196]
The long-term portion of the warranty accrual classified in Other liabilities was $110 million and $125 million as of December 29, 2017 and June 30, 2017, respectively.

[0000106040-18-000010:notes:197]
[same as prior period, unchanged from 0000106040-17-000036:notes:162]

[0000106040-18-000010:notes:198]
Other comprehensive loss (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-18-000010:notes:199]
During the three and six months ended December 29, 2017, there were no material reclassifications out of AOCI. The following table illustrates the significant amounts of each component reclassified out of AOCI to the Condensed Consolidated Statements of Operations:


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-18-000010:notes:200]
[same as prior period, unchanged from 0000106040-17-000036:notes:165]

[0000106040-18-000010:notes:201]
[same as prior period, unchanged from 0000106040-17-000036:notes:166]

[0000106040-18-000010:notes:202]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 as presented above, the Company recognized $8 million and $30 million of accelerated depreciation on facility assets in cost of revenue during the six months ended December 29, 2017 and December 30, 2016, respectively.

[0000106040-18-000010:notes:203]
[same as prior period, unchanged from 0000106040-17-000036:notes:168]

[0000106040-18-000010:notes:204]
[same as prior period, unchanged from 0000106040-17-000036:notes:169]


## wdc:OrganizationandBasisofPresentationTextBlock

[0000106040-18-000010:notes:205]
[same as prior period, unchanged from 0000106040-17-000036:notes:170]

[0000106040-18-000010:notes:206]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.

[0000106040-18-000010:notes:207]
[same as prior period, unchanged from 0000106040-17-000036:notes:172]

[0000106040-18-000010:notes:208]
[same as prior period, unchanged from 0000106040-17-000036:notes:173]

[0000106040-18-000010:notes:209]
[same as prior period, unchanged from 0000106040-17-000036:notes:174]

[0000106040-18-000010:notes:210]
[same as prior period, unchanged from 0000106040-17-000036:notes:175]

[0000106040-18-000010:notes:211]
[same as prior period, unchanged from 0000106040-17-000036:notes:176]
