# WDC MD&A — 0000106040-18-000010


## mdna

[0000106040-18-000010:mdna:1]
[same as prior period, unchanged from 0000106040-17-000036:mdna:1]

[0000106040-18-000010:mdna:2]
[same as prior period, unchanged from 0000106040-17-000036:mdna:2]

[0000106040-18-000010:mdna:3]
[same as prior period, unchanged from 0000106040-17-000036:mdna:3]

[0000106040-18-000010:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. Our broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. We also generate license and royalty revenue related to our intellectual property (“IP”), which is included in each of these three categories.

[0000106040-18-000010:mdna:5]
[same as prior period, unchanged from 0000106040-17-000036:mdna:5]

[0000106040-18-000010:mdna:6]
[same as prior period, unchanged from 0000106040-17-000036:mdna:6]

[0000106040-18-000010:mdna:7]
Refinancing Transactions

[0000106040-18-000010:mdna:8]
In January 2018, we announced our planned issuance of $2.30 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Notes”) and $1.00 billion aggregate principal amount of 1.5% convertible senior notes due 2024 (the “2024 Convertible Notes”). We intend to use the net proceeds of these offerings, together with available cash on hand and, with respect to the 2024 Convertible Notes, approximately $1 billion of proceeds from an anticipated increase in the size of our existing Term Loan A (the “TLA Increase”), to fund a cash tender offer and/or redemption of all of our currently outstanding 10.500% senior unsecured notes due 2024 (the “2024 unsecured notes”) and the redemption of all of our currently outstanding 7.375% senior secured notes due 2023 (the “2023 secured notes”). The offering of the 2026 Notes and 2024 Convertible Notes, the TLA Increase, the tender offer and/or redemption of the 2024 unsecured notes and the redemption of the 2023 secured notes are collectively referred to as the “Refinancing Transactions”.

[0000106040-18-000010:mdna:9]
The Refinancing Transactions are expected to be completed in the third quarter of fiscal year 2018, subject to customary closing conditions.

[0000106040-18-000010:mdna:10]
In connection with the Refinancing Transactions, we have announced that we intend to repurchase up to $500 million of our common stock in privately negotiated or open market transactions. Since December 29, 2017, we have repurchased approximately $151 million of our common stock in privately negotiated transactions, at a purchase price per share equal to $87.08 per share, with available cash on hand.

[0000106040-18-000010:mdna:11]
48

[0000106040-18-000010:mdna:12]
Tax Reform

[0000106040-18-000010:mdna:13]
On December 22, 2017, the President of the United States of America signed the Tax Cuts and Jobs Act (the “2017 Act”), which includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21%, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred, and new taxes on certain foreign earnings. As a result of the 2017 Act, we have made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $88 million related to the re-measurement of deferred tax assets and liabilities for the three and six months ended December 29, 2017. For additional information regarding the 2017 Act, see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q. See also the discussion in “Results of Operations-Income Tax Expense” and “Liquidity and Capital Resources” below for information regarding the impact of the 2017 Act on the Company’s financial condition, results of operations and cash flows.

[0000106040-18-000010:mdna:14]
Ventures with TMC

[0000106040-18-000010:mdna:15]
Through our strategic partnership with Toshiba Memory Corporation (“TMC”), which consists of three separate legal entities: Flash Partners Ltd., Flash Alliance Ltd. and Flash Forward Ltd., collectively referred to as “Flash Ventures”, we and TMC currently operate three business ventures in 300-millimeter NAND-flash manufacturing facilities in Yokkaichi, Japan, which provide us leading-edge, cost-competitive NAND wafers for our end products.

[0000106040-18-000010:mdna:16]
In September 2017, Toshiba Corporation (“Toshiba”), of which TMC is a wholly owned subsidiary, announced it had entered into a definitive agreement to sell TMC, including its interest in Flash Ventures, to a consortium led by SK Hynix Inc. and Bain Capital Private Equity, L.P., BCPE Pangea Cayman, L.P., BCPE Pangea Cayman2, Ltd., Bain Capital Fund XII, L.P., Bain Capital Asia Fund III, L.P. and Pangea (together, “Bain Capital”), that includes other competitors, as well as key customers. We previously asserted our consent rights under the terms of the Flash Ventures agreements with respect to the transactions involving, among other things, the transfer by Toshiba of its interests in Flash Ventures to TMC, and the proposed sale of TMC to a consortium of investors led by Bain Capital. In December 2017, we entered into a Confidential Settlement and Mutual Release Agreement (the “Toshiba Settlement Agreement”) with Toshiba and TMC pursuant to which the parties agreed to withdraw and seek dismissal of the litigation and arbitration proceedings related to the transfer of Toshiba’s interests in Flash Ventures and related matters. In addition to the settlement with Toshiba and TMC, we also entered into a settlement agreement with Bain Capital and certain other agreements with TMC related to the operation of Flash Ventures. See Part I, Item 1, Note 13, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for a further discussion of the litigation and arbitration proceedings between the parties and the Toshiba Settlement Agreement.

[0000106040-18-000010:mdna:17]
See Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for additional information on Flash Ventures.

[0000106040-18-000010:mdna:18]
Y6 Facility Agreement

[0000106040-18-000010:mdna:19]
In connection with the Toshiba Settlement Agreement, in December 2017, we entered into a facility agreement (the “Y6 Facility Agreement”) with TMC regarding the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”. The primary purpose of Fab 6, which is located adjacent to the fabrication facilities in Yokkaichi currently utilized by Flash Ventures, is to provide cleanroom space to continue the transition of the parties’ existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. The Y6 Facility Agreement establishes terms for the manufacture of NAND in Fab 6 and amends the existing agreements governing Flash Ventures to provide for their use of Fab 6. We have agreed to fund 50% of Fab 6’s start-up costs, as well as 50% of Flash Ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6. The Company’s share of the initial commitment is expected to be approximately $950 million, mostly for equipment investments and some start-up costs to be incurred primarily through calendar 2018.

[0000106040-18-000010:mdna:20]
Extension of Joint Venture Agreements

[0000106040-18-000010:mdna:21]
In connection with the Toshiba Settlement Agreement, in December 2017, we also entered into agreements with TMC to extend the term of Flash Alliance Ltd. to December 31, 2029 and the term of Flash Forward Ltd. to December 31, 2027. The term of Flash Partners Ltd. was previously extended to December 31, 2029.

[0000106040-18-000010:mdna:22]
49

[0000106040-18-000010:mdna:23]
Debt Facilities

[0000106040-18-000010:mdna:24]
During the second quarter ended December 29, 2017, we settled certain debt facilities, entered into new debt facilities at lower rates and increased our revolving credit facility. The financing arrangement activities were as follows:

[0000106040-18-000010:mdna:25]
| • | We settled our existing U.S dollar-denominated term B-2 loans (“U.S. Term Loan B-2”) with the proceeds of a new issuance of a $2.96 billion U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) at an interest rate lower than our U.S. Term Loan B-2 tranche. |

[0000106040-18-000010:mdna:26]
| • | We made a voluntary prepayment of the full principal amounts of our Euro-denominated term B-2 loans (“Euro Term Loan B-2”) using cash on hand. |

[0000106040-18-000010:mdna:27]
| • | We increased the size of our existing $1 billion revolving credit facility by $500 million to $1.5 billion. The terms of our revolving credit facility remained unchanged. |

[0000106040-18-000010:mdna:28]
For additional information regarding our debt facilities, see Part I, Item 1, Note 6, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:29]
50

[0000106040-18-000010:mdna:30]
[same as prior period, unchanged from 0000106040-17-000036:mdna:11]

[0000106040-18-000010:mdna:31]
Second Quarter and First Half Overview

[0000106040-18-000010:mdna:32]
[same as prior period, unchanged from 0000106040-17-000036:mdna:13]

[0000106040-18-000010:mdna:33]
|  | Three Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 5,336 |  |  | 100.0 | % |  | $ | 4,888 |  |  | 100.0 | % |  | $ | 448 |  |  | 9.2 | % |
| Cost of revenue | 3,323 |  |  | 62.3 |  |  | 3,355 |  |  | 68.6 |  |  | (32 | ) |  | (1.0 | ) |
| Gross profit | 2,013 |  |  | 37.7 |  |  | 1,533 |  |  | 31.4 |  |  | 480 |  |  | 31.3 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 629 |  |  | 11.8 |  |  | 585 |  |  | 12.0 |  |  | 44 |  |  | 7.5 |  |
| Selling, general and administrative | 381 |  |  | 7.1 |  |  | 358 |  |  | 7.3 |  |  | 23 |  |  | 6.4 |  |
| Employee termination, asset impairment, and other charges | 48 |  |  | 0.9 |  |  | 45 |  |  | 0.9 |  |  | 3 |  |  | 6.7 |  |
| Total operating expenses | 1,058 |  |  | 19.8 |  |  | 988 |  |  | 20.2 |  |  | 70 |  |  | 7.1 |  |
| Operating income | 955 |  |  | 17.9 |  |  | 545 |  |  | 11.1 |  |  | 410 |  |  | 75.2 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 14 |  |  | 0.3 |  |  | 5 |  |  | 0.1 |  |  | 9 |  |  | 180.0 |  |
| Interest expense | (197 | ) |  | (3.7 | ) |  | (205 | ) |  | (4.2 | ) |  | 8 |  |  | (3.9 | ) |
| Other income (expense), net | 2 |  |  | — |  |  | (24 | ) |  | (0.5 | ) |  | 26 |  |  | (108.3 | ) |
| Total interest and other expense, net | (181 | ) |  | (3.4 | ) |  | (224 | ) |  | (4.6 | ) |  | 43 |  |  | (19.2 | ) |
| Income before taxes | 774 |  |  | 14.5 |  |  | 321 |  |  | 6.6 |  |  | 453 |  |  | 141.1 |  |
| Income tax expense | 1,597 |  |  | 29.9 |  |  | 86 |  |  | 1.8 |  |  | 1,511 |  |  | 1,757.0 |  |
| Net income (loss) | $ | (823 | ) |  | (15.4 | ) |  | $ | 235 |  |  | 4.8 |  |  | (1,058 | ) |  | (450.2 | ) |

[0000106040-18-000010:mdna:34]
[same as prior period, unchanged from 0000106040-17-000036:mdna:15]

[0000106040-18-000010:mdna:35]
51

[0000106040-18-000010:mdna:36]
|  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 10,517 |  |  | 100.0 | % |  | $ | 9,602 |  |  | 100.0 | % |  | $ | 915 |  |  | 9.5 | % |
| Cost of revenue | 6,591 |  |  | 62.7 |  |  | 6,734 |  |  | 70.1 |  |  | (143 | ) |  | (2.1 | ) |
| Gross profit | 3,926 |  |  | 37.3 |  |  | 2,868 |  |  | 29.9 |  |  | 1,058 |  |  | 36.9 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,221 |  |  | 11.6 |  |  | 1,224 |  |  | 12.7 |  |  | (3 | ) |  | (0.2 | ) |
| Selling, general and administrative | 745 |  |  | 7.1 |  |  | 754 |  |  | 7.9 |  |  | (9 | ) |  | (1.2 | ) |
| Employee termination, asset impairment, and other charges | 100 |  |  | 1.0 |  |  | 113 |  |  | 1.2 |  |  | (13 | ) |  | (11.5 | ) |
| Total operating expenses | 2,066 |  |  | 19.6 |  |  | 2,091 |  |  | 21.8 |  |  | (25 | ) |  | (1.2 | ) |
| Operating income | 1,860 |  |  | 17.7 |  |  | 777 |  |  | 8.1 |  |  | 1,083 |  |  | 139.4 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 30 |  |  | 0.3 |  |  | 10 |  |  | 0.1 |  |  | 20 |  |  | 200.0 |  |
| Interest expense | (402 | ) |  | (3.8 | ) |  | (441 | ) |  | (4.6 | ) |  | 39 |  |  | (8.8 | ) |
| Other income (expense), net | (4 | ) |  | — |  |  | (296 | ) |  | (3.1 | ) |  | 292 |  |  | (98.6 | ) |
| Total interest and other expense, net | (376 | ) |  | (3.6 | ) |  | (727 | ) |  | (7.6 | ) |  | 351 |  |  | (48.3 | ) |
| Income before taxes | 1,484 |  |  | 14.1 |  |  | 50 |  |  | 0.5 |  |  | 1,434 |  |  | 2,868.0 |  |
| Income tax expense | 1,626 |  |  | 15.5 |  |  | 181 |  |  | 1.9 |  |  | 1,445 |  |  | 798.3 |  |
| Net income (loss) | $ | (142 | ) |  | (1.4 | ) |  | $ | (131 | ) |  | (1.4 | ) |  | $ | (11 | ) |  | 8.4 |  |

[0000106040-18-000010:mdna:37]
| (1) | Percentages may not total due to rounding. |

[0000106040-18-000010:mdna:38]
[same as prior period, unchanged from 0000106040-17-000036:mdna:17]

[0000106040-18-000010:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 5,336 |  |  | $ | 4,888 |  |  | $ | 10,517 |  |  | $ | 9,602 |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |
| Americas | 25 | % |  | 26 | % |  | 26 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 56 |  |  | 55 |  |  | 56 |  |  | 56 |  |
| Revenues by End Market (%) (2) |  |  |  |  |  |  |  |
| Client Devices | 50 | % |  | 49 | % |  | 51 | % |  | 50 | % |
| Data Center Devices & Solutions | 27 |  |  | 29 |  |  | 27 |  |  | 29 |  |
| Client Solutions | 24 |  |  | 22 |  |  | 23 |  |  | 21 |  |
| Exabytes Shipped | 95 |  |  | 78 |  |  | 182 |  |  | 158 |  |

[0000106040-18-000010:mdna:40]
[same as prior period, unchanged from 0000106040-17-000036:mdna:19]

[0000106040-18-000010:mdna:41]
| (2) | Percentages may not total due to rounding. |

[0000106040-18-000010:mdna:42]
52

[0000106040-18-000010:mdna:43]
Net Revenue

[0000106040-18-000010:mdna:44]
Net revenue for the three and six months ended December 29, 2017 increased $448 million, or 9.2%, and $915 million, or 9.5%, respectively, as compared to the same periods in prior year. The increase in net revenue for the three and six months ended December 29, 2017, compared to the same periods in the prior year, primarily reflects a favorable flash memory demand environment and growth of our diversified product portfolio. For the three and six months ended December 29, 2017, Client Devices revenue increased 9.5% and 11.1%, respectively, year-over-year, primarily driven by growth in mobility, client solid state drives (“SSD”) and surveillance products. Our revenue for Data Center Devices and Solutions for the three and six months ended December 29, 2017 increased 2.9% and 1.6%, respectively, year-over-year, driven primarily by a significant increase in sales from our capacity enterprise hard disk drives (“HDD”), partially offset by an expected decline in sales from our performance enterprise HDDs. Client Solutions revenue for the three and six months ended December 29, 2017 increased 16.6% and 16.5%, respectively, year-over-year, primarily as a result of the strength and reach of our valuable global retail brands.

[0000106040-18-000010:mdna:45]
Our top 10 customers accounted for 42% and 41% of our net revenue for the three and six months ended December 29, 2017, respectively, and 43% and 42% of our net revenue for the three and six months ended December 30, 2016, respectively. For the three and six months ended December 29, 2017 and December 30, 2016, no single customer accounted for 10% or more of our net revenue.

[0000106040-18-000010:mdna:46]
[same as prior period, unchanged from 0000106040-17-000036:mdna:23]

[0000106040-18-000010:mdna:47]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and six months ended December 29, 2017, these programs represented 12% and 13% of gross revenues, respectively. For each of the three and six months ended December 30, 2016, these programs represented 13% of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-18-000010:mdna:48]
Gross Profit and Gross Margin

[0000106040-18-000010:mdna:49]
Gross profit for the three and six months ended December 29, 2017 increased $480 million, or 31.3%, and $1.058 billion, or 36.9%, respectively, as compared to the same period in the prior year. The increase in gross profit for the three and six months ended December 29, 2017 reflects the increase in revenue discussed above and improvements in our gross margin. The increase in gross margin for the three and six months ended December 29, 2017 was primarily due to a favorable demand environment for flash-based products, improvements in our production costs from technology transitions and a higher mix of flash-based product revenue. Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $293 million, or 5.5%, of revenue, for the three months ended December 29, 2017, and $259 million, or 5.3%, of revenue, for the three months ended December 30, 2016.

[0000106040-18-000010:mdna:50]
Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $572 million, or 5.4%, of revenue, for the six months ended December 29, 2017, and $523 million, or 5.4%, of revenue, for the six months ended December 30, 2016.

[0000106040-18-000010:mdna:51]
[same as prior period, unchanged from 0000106040-17-000036:mdna:27]

[0000106040-18-000010:mdna:52]
The increase in research and development (“R&D”) expense for the three months ended December 29, 2017 of $44 million, or 7.5%, from the same period in the prior year, was primarily due to on-going investments in future capabilities and operating expenses of recent acquisitions. The three months ended December 29, 2017 also included aggregate charges of $48 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges, compared to $49 million for the three months ended December 30, 2016 related to such charges.

[0000106040-18-000010:mdna:53]
R&D expense for the six months ended December 29, 2017 remained relatively consistent with the same period in the prior year. This was primarily due to an increase in on-going investments in future capabilities and operating expenses of recent acquisitions, offset by variable compensation. The six months ended December 29, 2017 also included aggregate charges of $95 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges, compared to $102 million for the six months ended December 30, 2016 related to such charges.

[0000106040-18-000010:mdna:54]
Selling, general and administrative (“SG&A”) expense for the three months ended December 29, 2017 increased $23 million, or 6.4%, from the same period in the prior year, primarily due to operating expenses of recent acquisitions and an increase in legal expenses. Both the three months ended December 29, 2017 and December 30, 2016 also included aggregate charges of $97 million related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges.

[0000106040-18-000010:mdna:55]
SG&A expense for the six months ended December 29, 2017 remained relatively consistent from the same period in the prior year. This was primarily due to an increase in operating expenses of recent acquisitions and legal expenses, offset by lower variable compensation. The six months ended December 29, 2017 also included aggregate charges of $187 million related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges, compared to $216 million for the six months ended December 30, 2016 related to such charges.

[0000106040-18-000010:mdna:56]
Employee termination and other charges for the three and six months ended December 29, 2017 primarily related to further actions associated with the integration and business realignment of substantial portions of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 12, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:57]
[same as prior period, unchanged from 0000106040-17-000036:mdna:31]

[0000106040-18-000010:mdna:58]
Total interest and other income (expense), net for the three months ended December 29, 2017 decreased $43 million from the same period in the prior year, primarily due to higher foreign exchange losses and other charges of $26 million in the prior year, lower interest expense of $8 million resulting from reductions in the principal amount of debt and higher interest income of $9 million related to increased investments.

[0000106040-18-000010:mdna:59]
Total interest and other income (expense), net for the six months ended December 29, 2017 decreased $351 million from the same period in the prior year, primarily due to the loss on extinguishment of debt of $292 million recognized in the prior year, lower interest expense of $39 million resulting from reductions in the principal amount of debt and higher interest income of $20 million related to increased investments.

[0000106040-18-000010:mdna:60]
[same as prior period, unchanged from 0000106040-17-000036:mdna:33]

[0000106040-18-000010:mdna:61]
[same as prior period, unchanged from 0000106040-17-000036:mdna:34]

[0000106040-18-000010:mdna:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions, except percentages) |
| Income before taxes | $ | 774 |  |  | $ | 321 |  |  | $ | 1,484 |  |  | $ | 50 |  |
| Income tax expense | 1,597 |  |  | 86 |  |  | $ | 1,626 |  |  | $ | 181 |  |
| Effective tax rate | 206 | % |  | 27 | % |  | 110 | % |  | 362 | % |

[0000106040-18-000010:mdna:63]
Under the 2017 Act, the U.S. federal corporate tax rate is reduced from 35% to 21% and is effective January 1, 2018 resulting in the use of an estimated annual effective rate of approximately 28% for our U.S. federal corporate tax rate for fiscal year 2018. The reduction in the U.S. federal corporate tax rate from 35% to the blended tax rate of 28% for fiscal year 2018 is estimated to have reduced our income tax expense by $7 million for the three and six months ended December 29, 2017. For fiscal year 2019 and beyond, we will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000010:mdna:64]
Consistent with applicable Securities and Exchange Commission (“SEC”) guidance, we made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $88 million related to the re-measurement of deferred tax assets and liabilities for the three and six months ended December 29, 2017. Both items are included as a component of income tax expense from continuing operations in the Condensed Consolidated Statements of Operations. For other elements of tax expense noted in Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q, or where we have not made an election, we have not been able to make a reasonable estimate and continue to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As we finalize the accounting for the tax effects of the enactment of the 2017 Act during a one-year measurement period permitted by applicable SEC guidance, we expect to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000010:mdna:65]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act. Excluding these items, the effective tax rate for the three and six months ended December 29, 2017 would be approximately 4%. The primary drivers for the remaining difference between the effective tax rate for the three and six months ended December 29, 2017 and the U.S. Federal statutory rate of 28% are the current year generation of tax credits, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires us to now recognize $5 million and $27 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of our income tax expense for the three and six months ended December 29, 2017, respectively. The windfall tax benefits for the three and six months ended December 30, 2016 were recorded within stockholders’ equity.

[0000106040-18-000010:mdna:66]
Income tax expense for the six months ended December 30, 2016 was attributable to discrete effects consisting of income tax expense from the integration of SanDisk Corporation (“SanDisk”) of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $96 million. The primary drivers for the difference between the effective tax rate for the six months ended December 30, 2016 and the U.S. Federal statutory rate of 35% are these discrete items, the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-18-000010:mdna:67]
The 2017 Act is expected to have an unfavorable impact on our effective tax rate for fiscal year 2018 due to the mandatory deemed repatriation tax offset in part by the re-measurement of deferred taxes and the reduction in the corporate tax rate.  In future years, certain additional provisions of the 2017 Act, such as a minimum tax on foreign earnings, will also apply to us and, as a result, we generally expect our effective tax rate to increase from the rate expected for fiscal year 2018 (excluding the mandatory deemed repatriation tax and the re-measurement of deferred taxes). Our estimate of the effective tax rate increase is subject to our assertion as to whether foreign undistributed earnings are indefinitely reinvested and to other calculations and elections during the measurement period.  Our total tax expense in future fiscal years will also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-18-000010:mdna:68]
[same as prior period, unchanged from 0000106040-17-000036:mdna:39]

[0000106040-18-000010:mdna:69]
55

[0000106040-18-000010:mdna:70]
[same as prior period, unchanged from 0000106040-17-000036:mdna:41]

[0000106040-18-000010:mdna:71]
[same as prior period, unchanged from 0000106040-17-000036:mdna:42]

[0000106040-18-000010:mdna:72]
|  | Six Months Ended |
|  | December 29, 2017 |  | December 30, 2016 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 2,315 |  |  | $ | 1,500 |  |
| Investing activities | (1,007 | ) |  | (316 | ) |
| Financing activities | (1,391 | ) |  | (4,386 | ) |
| Effect of exchange rate changes on cash | 1 |  |  | (9 | ) |
| Net decrease in cash and cash equivalents | $ | (82 | ) |  | $ | (3,211 | ) |

[0000106040-18-000010:mdna:73]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, stock repurchases, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:74]
During 2018, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to Flash Ventures to be approximately $1.50 billion to $1.90 billion. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing. As described above, we also expect that if the Refinancing Transactions and share repurchase are completed, our total debt outstanding will decrease by approximately $1.00 billion and our available cash on hand will decrease by approximately $2.40 billion compared to December 29, 2017. See above in “Key Developments - Refinancing Transactions” for additional information

[0000106040-18-000010:mdna:75]
Pursuant to the 2017 Act, we are required to pay a one-time deemed repatriation tax related to the undistributed earnings of our foreign subsidiaries.  For the three and six months ended December 29, 2017, we recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.66 billion, which is payable over an 8-year period as further discussed below under “Short and Long-term Liquidity-Contractual Obligations and Commitments.” The provisional amount included in the Condensed Consolidated Financial Statements of Operations may change when we finalize the calculation of our post-1986 foreign earnings and profits that were previously deferred from U.S. income taxes and the amount of foreign earnings held in cash or other specified assets.  For additional information regarding our total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:76]
A total of $4.90 billion and $4.99 billion of our cash and cash equivalents was held outside of the U.S. as of December 29, 2017 and June 30, 2017, respectively. Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., we continue to evaluate the expected manner of recovery to determine whether or not to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires us to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost, that is incremental to the U.S. deemed repatriation tax, (e.g. foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the current tax expense is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, our plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings.  In the event we determine not to continue to assert the permanent reinvestment of part or all of our foreign undistributed earnings such a determination could result in the accrual and payment of additional foreign, state and local taxes.

[0000106040-18-000010:mdna:77]
[same as prior period, unchanged from 0000106040-17-000036:mdna:47]

[0000106040-18-000010:mdna:78]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash provided by changes in other operating assets and liabilities was $1.27 billion for the six months ended December 29, 2017, as compared to net cash used for changes in other operating assets and liabilities of $37 million for the six months ended December 30, 2016.

[0000106040-18-000010:mdna:79]
56

[0000106040-18-000010:mdna:80]
[same as prior period, unchanged from 0000106040-17-000036:mdna:49]

[0000106040-18-000010:mdna:81]
|  | December 29, 2017 |  | December 30, 2016 |
|  | (in days) |
| Days sales outstanding | 35 |  |  | 38 |  |
| Days in inventory | 62 |  |  | 56 |  |
| Days payables outstanding | (59 | ) |  | (59 | ) |
| Cash conversion cycle | 38 |  |  | 35 |  |

[0000106040-18-000010:mdna:82]
[same as prior period, unchanged from 0000106040-17-000036:mdna:51]

[0000106040-18-000010:mdna:83]
For the six months ended December 29, 2017, DSO decreased by 3 days over the prior year, primarily reflecting routine variations in the timing of customer receipts. DIO increased by 6 days over the prior year, primarily reflecting short-term build-up of inventory to support expected demand. DPO primarily reflects routine variations in timing of purchases and payments and remained consistent over the prior year.

[0000106040-18-000010:mdna:84]
[same as prior period, unchanged from 0000106040-17-000036:mdna:53]

[0000106040-18-000010:mdna:85]
Net cash used in investing activities for the six months ended December 29, 2017 primarily consisted of $416 million of capital expenditures, a net $509 million increase in notes receivable issuances to Flash Ventures, and $99 million for acquisitions. Net cash used in investing activities for the six months ended December 30, 2016 primarily consisted of $330 million of capital expenditures and a $70 million net increase in notes receivable issuances to and investments in Flash Ventures.

[0000106040-18-000010:mdna:86]
[same as prior period, unchanged from 0000106040-17-000036:mdna:55]

[0000106040-18-000010:mdna:87]
[same as prior period, unchanged from 0000106040-17-000036:mdna:56]

[0000106040-18-000010:mdna:88]
Net cash used in financing activities for the six months ended December 29, 2017 primarily consisted of $4.11 billion in debt repayments and $295 million to pay dividends on our common stock, partially offset by proceeds of $2.96 billion from debt issuances, a net $32 million in employee stock plans, and $28 million from the settlement of debt hedge contracts.  Net cash used in financing activities for the six months ended December 30, 2016 consisted of $8.25 billion to repay debt, and $284 million to pay dividends on our common stock, partially offset by $3.99 billion of proceeds from debt, net of issuance costs, $61 million of proceeds from call options, and a net $106 million provided by employee stock plans.

[0000106040-18-000010:mdna:89]
[same as prior period, unchanged from 0000106040-17-000036:mdna:58]

[0000106040-18-000010:mdna:90]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:91]
[same as prior period, unchanged from 0000106040-17-000036:mdna:60]

[0000106040-18-000010:mdna:92]
[same as prior period, unchanged from 0000106040-17-000036:mdna:61]

[0000106040-18-000010:mdna:93]
The following is a summary of our known contractual cash obligations and commercial commitments as of December 29, 2017:

[0000106040-18-000010:mdna:94]
|  | Total |  | 1 Year (Remaining 6 months of 2018) |  | 2-3 Years (2019-2020) |  | 4-5 Years (2021-2022) |  | More than 5 Years (Beyond 2022) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 12,237 |  |  | $ | 118 |  |  | $ | 816 |  |  | $ | 3,256 |  |  | $ | 8,047 |  |
| Interest on debt | 3,879 |  |  | 365 |  |  | 1,441 |  |  | 1,268 |  |  | 805 |  |
| Flash Ventures and other related commitments(1) | 7,698 |  |  | 1,755 |  |  | 3,796 |  |  | 1,766 |  |  | 381 |  |
| Operating leases | 158 |  |  | 23 |  |  | 77 |  |  | 39 |  |  | 19 |  |
| Purchase obligations | 1,184 |  |  | 1,161 |  |  | 23 |  |  | — |  |  |  |  |
| Mandatory Repatriation Tax | 1,657 |  |  | — |  |  | 265 |  |  | 265 |  |  | 1,127 |  |
| Total | $ | 26,813 |  |  | $ | 3,422 |  |  | $ | 6,418 |  |  | $ | 6,594 |  |  | $ | 10,379 |  |

[0000106040-18-000010:mdna:95]
[same as prior period, unchanged from 0000106040-17-000036:mdna:64]

[0000106040-18-000010:mdna:96]
[same as prior period, unchanged from 0000106040-17-000036:mdna:65]

[0000106040-18-000010:mdna:97]
See Part I, Item 1, Note 6, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding our indebtedness, including information about new borrowings and repayments, increased availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness.

[0000106040-18-000010:mdna:98]
[same as prior period, unchanged from 0000106040-17-000036:mdna:67]

[0000106040-18-000010:mdna:99]
[same as prior period, unchanged from 0000106040-17-000036:mdna:68]

[0000106040-18-000010:mdna:100]
[same as prior period, unchanged from 0000106040-17-000036:mdna:69]

[0000106040-18-000010:mdna:101]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of December 29, 2017, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding Flash Ventures.

[0000106040-18-000010:mdna:102]
[same as prior period, unchanged from 0000106040-17-000036:mdna:71]

[0000106040-18-000010:mdna:103]
[same as prior period, unchanged from 0000106040-17-000036:mdna:72]

[0000106040-18-000010:mdna:104]
[same as prior period, unchanged from 0000106040-17-000036:mdna:73]

[0000106040-18-000010:mdna:105]
[same as prior period, unchanged from 0000106040-17-000036:mdna:74]

[0000106040-18-000010:mdna:106]
[same as prior period, unchanged from 0000106040-17-000036:mdna:75]

[0000106040-18-000010:mdna:107]
Mandatory Repatriation Tax

[0000106040-18-000010:mdna:108]
The following is a summary of our estimated provisional mandatory deemed repatriation tax obligations which are payable in the following fiscal years ending (in millions):

[0000106040-18-000010:mdna:109]
| June 28, 2019 |  | $ | 132 |  |
| July 3, 2020 |  | 133 |  |
| July 2, 2021 |  | 132 |  |
| July 1, 2022 |  | 133 |  |
| June 30, 2023 |  | 132 |  |
| June 28, 2024 |  | 249 |  |
| June 27, 2025 |  | 332 |  |
| July 3, 2026 |  | 414 |  |
| Total |  | $ | 1,657 |  |

[0000106040-18-000010:mdna:110]
The 2017 Act allows for the provisional mandatory deemed repatriation tax of $1.66 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. For additional information regarding our provisional estimate of the total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:111]
[same as prior period, unchanged from 0000106040-17-000036:mdna:76]

[0000106040-18-000010:mdna:112]
As of December 29, 2017, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $529 million. Accrued interest and penalties related to unrecognized tax benefits as of December 29, 2017 was approximately $94 million. Of these amounts, approximately $502 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:113]
[same as prior period, unchanged from 0000106040-17-000036:mdna:78]

[0000106040-18-000010:mdna:114]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On November 1, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of December 29, 2017. The cash dividend of $149 million was paid on January 16, 2018.

[0000106040-18-000010:mdna:115]
On January 27, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of March 30, 2018, which will be paid on April 16, 2018. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-18-000010:mdna:116]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-18-000010:mdna:117]
In August 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness, resulting in better alignment between the presentation of the effects of the hedging instrument and the hedged item in the financial statements. ASU 2017-12 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted in any interim period after issuance of the update. We are currently evaluating the impact this update will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:118]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. This ASU is effective prospectively for annual periods beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:119]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. We are currently evaluating the impact ASU 2017-07 will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:120]
In February 2017, the FASB issued ASU No. 2017-05, “Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets (Subtopic 610-20): Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets” (“ASU 2017-05”). ASU 2017-05 clarifies the scope and application of Accounting Standards Codification (“ASC”) 610-20 on the sale or transfer of nonfinancial assets, including real estate, and in substance nonfinancial assets to noncustomers, including partial sales. An entity should identify each distinct nonfinancial asset or in substance nonfinancial asset promised to a counterparty and derecognize each asset when a counterparty obtains control of the related asset. The ASU also clarifies that an in substance nonfinancial asset is an asset or group of assets for which substantially all of the fair value consists of nonfinancial assets and the group or subsidiary is not a business. In addition, the amendment requires an entity to derecognize a distinct nonfinancial asset or in substance nonfinancial asset in a partial sale transaction when the entity does not retain a controlling financial interest in the legal entity that holds the asset and an entity transfers control of the asset. Once control is transferred, any non-controlling interest received is required to be measured at fair value. The effective date of the new standard is aligned with the requirements in the new revenue standard ASU No. 2014-09, which for us is the first quarter of 2019. The Company is in the process of evaluating the impact that adoption of this guidance may have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:121]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). ASU 2017-04 simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. The new standard is effective for goodwill impairment tests in fiscal years beginning after December 15, 2019, which for us is the first quarter of 2021. Early adoption is permitted for goodwill impairment tests performed after January 1, 2017. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:122]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business”. This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. The new standard must be applied prospectively to transactions occurring within the period of adoption. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:123]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB Accounting Standards Codification (“ASC”) Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of accounting principles generally accepted in the United States (“U.S. GAAP”) and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact ASU 2016-16 will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:124]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for us is the first quarter of 2021.  We are currently evaluating the impact this update will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:125]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or control the use of, a specified asset for the lease term. Currently, lessees and lessors must apply a modified retrospective transition approach for leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements. However, the FASB issued a proposal pending resolution that would allow entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The amendments are effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted. We are also in the process of identifying changes to our processes, internal controls and systems configurations that would result from the new lease standard. Our implementation efforts are progressing as planned. We expect to adopt this standard in the first quarter of 2020. We continue to evaluate the impact ASU 2016-02 will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:126]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. We are currently evaluating the impact ASU 2016-01 will have on our Consolidated Financial Statements.

[0000106040-18-000010:mdna:127]
61

[0000106040-18-000010:mdna:128]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)” (“ASC Topic 606”), which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The standard is effective beginning the first quarter of fiscal 2019, with early adoption permitted. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our preliminary plan, we intend to adopt the new standard beginning with the first quarter of 2019 using the modified retrospective method; however, we continue to assess this in connection with our entire project plan.

[0000106040-18-000010:mdna:129]
[same as prior period, unchanged from 0000106040-17-000036:mdna:89]

[0000106040-18-000010:mdna:130]
[same as prior period, unchanged from 0000106040-17-000036:mdna:90]

[0000106040-18-000010:mdna:131]
[same as prior period, unchanged from 0000106040-17-000036:mdna:91]

[0000106040-18-000010:mdna:132]
[same as prior period, unchanged from 0000106040-17-000036:mdna:92]

[0000106040-18-000010:mdna:133]
[same as prior period, unchanged from 0000106040-17-000036:mdna:93]

[0000106040-18-000010:mdna:134]
[same as prior period, unchanged from 0000106040-17-000036:mdna:94]

[0000106040-18-000010:mdna:135]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recently Adopted Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000010:mdna:136]
[same as prior period, unchanged from 0000106040-17-000036:mdna:96]

[0000106040-18-000010:mdna:137]
[same as prior period, unchanged from 0000106040-17-000036:mdna:97]

[0000106040-18-000010:mdna:138]
[same as prior period, unchanged from 0000106040-17-000036:mdna:98]

[0000106040-18-000010:mdna:139]
62
