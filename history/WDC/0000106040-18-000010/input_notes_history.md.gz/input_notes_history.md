# WDC note change history — 0000106040-17-000036 → 0000106040-18-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-02-06):
[0000106040-18-000010:note_history:1]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- added (2018-02-06):
[0000106040-18-000010:note_history:2]
In connection with a settlement agreement with Toshiba, in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6. See also Note 13, Legal Proceedings.

- changed (2018-02-06):
[0000106040-18-000010:note_history:3]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 29, 2017 and June 30, 2017:
  (was, 2017-11-07, similarity 0.9808):
[0000106040-17-000036:note_history:3]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 29, 2017 and June 30, 2017:

- changed (2018-02-06):
[0000106040-18-000010:note_history:4]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 101 |  |  | 119 |  |
| Notes receivable, Flash Forward | 429 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 279 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,845 |  |  | $ | 1,340 |  |
  (was, 2017-11-07, similarity 0.9919):
[0000106040-17-000036:note_history:4]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 365 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 114 |  |  | 119 |  |
| Notes receivable, Flash Forward | 406 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 278 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,462 |  |  | $ | 1,340 |  |

- changed (2018-02-06):
[0000106040-18-000010:note_history:5]
During the three and six months ended December 29, 2017, the Company made net payments to Flash Ventures of $1.2 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2017-11-07, similarity 0.8365):
[0000106040-17-000036:note_history:5]
During the three months ended September 29, 2017, the Company made net payments to Flash Ventures of $792 million for purchased flash-based memory wafers and net loans and investments.

- changed (2018-02-06):
[0000106040-18-000010:note_history:6]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no such impairments in the three and six months ended December 29, 2017 and December 30, 2016.
  (was, 2017-11-07, similarity 0.9057):
[0000106040-17-000036:note_history:6]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other expense, net in the Condensed Consolidated Statements of Operations. There were no such impairments in each of the three-month periods ended September 29, 2017 and September 30, 2016.

- changed (2018-02-06):
[0000106040-18-000010:note_history:7]
As of December 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $250 million and $206 million, respectively.
  (was, 2017-11-07, similarity 0.9821):
[0000106040-17-000036:note_history:7]
As of September 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $226 million and $206 million, respectively.

- added (2018-02-06):
[0000106040-18-000010:note_history:8]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2018-02-06):
[0000106040-18-000010:note_history:9]
|  | December 29, 2017 |
| Notes receivable | $ | 1,267 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 941 |  |
| Inventory and prepayments | 268 |  |
| Maximum estimable loss exposure | $ | 3,054 |  |
  (was, 2017-11-07, similarity 0.9446):
[0000106040-17-000036:note_history:9]
|  | September 29, 2017 |
| Notes receivable | $ | 885 |  |
| Equity investments | 577 |  |
| Operating lease guarantees | 1,022 |  |
| Inventory | 202 |  |
| Maximum estimable loss exposure | $ | 2,686 |  |

- changed (2018-02-06):
[0000106040-18-000010:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017.
  (was, 2017-11-07, similarity 0.9864):
[0000106040-17-000036:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017.

- changed (2018-02-06):
[0000106040-18-000010:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017:
  (was, 2017-11-07, similarity 0.9808):
[0000106040-17-000036:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017:

- changed (2018-02-06):
[0000106040-18-000010:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 267 |  |  | $ | — |  |  | $ | 267 |  |
| Year 2 |  | 178 |  |  | 34 |  |  | 212 |  |
| Year 3 |  | 163 |  |  | 85 |  |  | 248 |  |
| Year 4 |  | 80 |  |  | 98 |  |  | 178 |  |
| Year 5 |  | 15 |  |  | 21 |  |  | 36 |  |
| Total guarantee obligations |  | $ | 703 |  |  | $ | 238 |  |  | $ | 941 |  |
  (was, 2017-11-07, similarity 0.9976):
[0000106040-17-000036:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 275 |  |  | $ | 10 |  |  | $ | 285 |  |
| Year 2 |  | 190 |  |  | 34 |  |  | 224 |  |
| Year 3 |  | 184 |  |  | 82 |  |  | 266 |  |
| Year 4 |  | 96 |  |  | 76 |  |  | 172 |  |
| Year 5 |  | 29 |  |  | 46 |  |  | 75 |  |
| Total guarantee obligations |  | $ | 774 |  |  | $ | 248 |  |  | $ | 1,022 |  |

- changed (2018-02-06):
[0000106040-18-000010:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2017-11-07, similarity 0.9854):
[0000106040-17-000036:note_history:13]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- removed (2018-02-06):
[0000106040-17-000036:note_history:14]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- removed (2018-02-06):
[0000106040-17-000036:note_history:15]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0000106040-18-000010:note_history:16]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. In December 2017, WD and HGST filed an amended notice of appeal with the Federal Circuit with respect to validity. In January 2018, WD, HGST and Convolve entered into a settlement agreement resolving the litigation and agreeing to seek dismissal of all claims and actions between the parties.
  (was, 2017-11-07, similarity 0.8605):
[0000106040-17-000036:note_history:16]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

- changed (2018-02-06):
[0000106040-18-000010:note_history:17]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.
  (was, 2017-11-07, similarity 0.9912):
[0000106040-17-000036:note_history:17]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.

- added (2018-02-06):
[0000106040-18-000010:note_history:18]
In December 2017, the Company entered into a Confidential Settlement and Mutual Release Agreement (the “Toshiba Settlement Agreement”) with Toshiba and TMC. Under the Toshiba Settlement Agreement, the parties agreed to withdraw and seek dismissal of the litigation and arbitration proceedings discussed below.  Further information about the Toshiba Settlement Agreement is set forth below under “Settlement Agreement.”

- added (2018-02-06):
[0000106040-18-000010:note_history:19]
Proceedings

- changed (2018-02-06):
[0000106040-18-000010:note_history:20]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and TMC in the Tokyo District Court. The petition alleged that the Company engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requested injunctive relief.
  (was, 2017-11-07, similarity 0.9028):
[0000106040-17-000036:note_history:20]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court. The petition alleges that the Company has engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requests injunctive relief.

- changed (2018-02-06):
[0000106040-18-000010:note_history:21]
In August 2017, the Company received a complaint filed by Toshiba and TMC in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint was based on the same allegations as the petition for provisional disposition.
  (was, 2017-11-07, similarity 0.8421):
[0000106040-17-000036:note_history:21]
In August 2017, the Company received a complaint filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint is based on the same allegations as the petition for provisional disposition. The Company intends to defend itself vigorously in these matters.

- changed (2018-02-06):
[0000106040-18-000010:note_history:22]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, TMC, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer.
  (was, 2017-11-07, similarity 0.7881):
[0000106040-17-000036:note_history:22]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, Toshiba Memory Corporation, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer. In July 2017, the Superior Court entered a stipulated order requiring Toshiba to give the SanDisk Subsidiaries at least 14 days’ advance notice of any transfer to a third party involving Toshiba’s interests in Flash Ventures, in order to ensure that the issue is preserved for arbitration. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.

- added (2018-02-06):
[0000106040-18-000010:note_history:23]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture (the “Access Restrictions”). SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order, in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. In July 2017, SanDisk LLC amended its request for arbitration to, among other things, add TMC as a defendant.

- changed (2018-02-06):
[0000106040-18-000010:note_history:24]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan. The SanDisk Subsidiaries sought, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.
  (was, 2017-11-07, similarity 0.9948):
[0000106040-17-000036:note_history:24]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan.  The SanDisk Subsidiaries seek, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.

- added (2018-02-06):
[0000106040-18-000010:note_history:25]
Settlement Agreement

- added (2018-02-06):
[0000106040-18-000010:note_history:26]
In December 2017, the Company, the SanDisk Subsidiaries, Toshiba and TMC entered into the Toshiba Settlement Agreement pursuant to which the parties agreed to withdraw and seek dismissal of the proceedings above and mutually release each other from all claims relating to, among other things, (i) the transfer of Toshiba’s equity interests in Flash Ventures to TMC, (ii) the Access Restrictions, (iii) TMC’s decision to invest unilaterally in Phase I of Fab 6 and (iv) the sale of TMC to K.K. Pangea (“Pangea”), which will be owned, as of the closing of the sale, by certain members of a consortium of investors led by Bain Capital (as defined below). In addition, the Company agreed to consent to the transfer of Toshiba’s interests in Flash Ventures to TMC, the assignment of all agreements relating to Flash Ventures by Toshiba to TMC and the sale of TMC to Pangea. Toshiba and TMC have also agreed to end the Access Restrictions. For a period of three years following the closing of the sale of TMC to Pangea, the Company’s consent shall be required for any issuance or transfer of equity securities, voting rights or control in TMC by TMC, Toshiba, Bain Capital or their respective affiliates to certain restricted parties, subject to certain limited exceptions.  Pursuant to the Toshiba Settlement Agreement, the Company and the SanDisk Subsidiaries also entered into certain other agreements with TMC related to the operation of Flash Ventures, including an agreement regarding the construction and operation of Fab 6 and the extension of the term of Flash Alliance.

- added (2018-02-06):
[0000106040-18-000010:note_history:27]
In December 2017, the Company and the SanDisk Subsidiaries also entered into a Confidential Settlement Agreement and Mutual Release with Bain Capital Private Equity, L.P., BCPE Pangea Cayman, L.P., BCPE Pangea Cayman2, Ltd., Bain Capital Fund XII, L.P., Bain Capital Asia Fund III, L.P. and Pangea (together, “Bain Capital”) on terms substantially similar to the terms of the Toshiba Settlement Agreement, subject to certain transfer restrictions on Bain Capital.

- removed (2018-02-06):
[0000106040-17-000036:note_history:28]
Toshiba litigation against the Company

- removed (2018-02-06):
[0000106040-17-000036:note_history:29]
SanDisk litigation against Toshiba

- removed (2018-02-06):
[0000106040-17-000036:note_history:30]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture. SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order (“TRO”), in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. On July 11, 2017, the Superior Court granted a TRO in favor of SanDisk. Toshiba filed a notice of appeal, and on July 18, 2017, the California Court of Appeal, First Appellate District, issued a temporary stay of the TRO while it reviewed Toshiba’s petition for a permanent stay of the TRO pending appeal. On July 24, 2017, SanDisk LLC amended its request for arbitration to, among other things, add Toshiba Memory Corporation as a defendant. On August 2, 2017, the Court of Appeal denied Toshiba’s petition for a permanent stay of the TRO and dissolved the temporary stay. On August 14, 2017, the Superior Court granted SanDisk’s request for a preliminary injunction. On August 18, 2017, Toshiba withdrew its appeal of the TRO, and filed a notice of appeal of the preliminary injunction. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.


## wdc:OrganizationandBasisofPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0000106040-18-000010:note_history:31]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.
  (was, 2017-11-07, similarity 0.9992):
[0000106040-17-000036:note_history:31]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”) which is included in each of these three categories.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0000106040-18-000010:note_history:32]
Debt consisted of the following as of December 29, 2017 and June 30, 2017:
  (was, 2017-11-07, similarity 0.9612):
[0000106040-17-000036:note_history:32]
Debt consisted of the following as of September 29, 2017 and June 30, 2017:

- changed (2018-02-06):
[0000106040-18-000010:note_history:33]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,022 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,955 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 12,237 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (186 | ) |  | (205 | ) |
| Subtotal | 12,051 |  |  | 13,151 |  |
| Less current portion of long-term debt | (274 | ) |  | (233 | ) |
| Long-term debt | $ | 11,777 |  |  | $ | 12,918 |  |
  (was, 2017-11-07, similarity 0.9321):
[0000106040-17-000036:note_history:33]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,073 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,963 |  |  | 2,970 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,031 |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 13,327 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (196 | ) |  | (205 | ) |
| Subtotal | 13,131 |  |  | 13,151 |  |
| Less current portion of long-term debt | (258 | ) |  | (233 | ) |
| Long-term debt | $ | 12,873 |  |  | $ | 12,918 |  |

- changed (2018-02-06):
[0000106040-18-000010:note_history:34]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |
  (was, 2017-11-07, similarity 0.9085):
[0000106040-17-000036:note_history:34]
| (1) | Euro Term Loan B-2 outstanding principal amounts as of September 29, 2017 and June 30, 2017 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

- added (2018-02-06):
[0000106040-18-000010:note_history:35]
On November 29, 2017, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to increase the size of its existing $1.0 billion revolving credit facility by $500 million to $1.5 billion. The term of the revolving credit facility remained unchanged and will mature on April 29, 2021. As of December 29, 2017, there were no borrowings under the revolving credit facility.

- added (2018-02-06):
[0000106040-18-000010:note_history:36]
On November 17, 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. On November 8, 2017, the Company borrowed $2.96 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00% (3.57% as of December 29, 2017). Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of December 29, 2017, issuance costs of $3 million remain unamortized. In connection with the settlements of the U.S. Term Loan B-2 and Euro Term Loan B-2, the Company recognized an aggregate loss on debt extinguishment of $2 million consisting of unamortized issuance costs.

- changed (2018-02-06):
[0000106040-18-000010:note_history:37]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of December 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.
  (was, 2017-11-07, similarity 0.9947):
[0000106040-17-000036:note_history:37]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of September 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0000106040-18-000010:note_history:38]
Debt consisted of the following as of December 29, 2017 and June 30, 2017:
  (was, 2017-11-07, similarity 0.9612):
[0000106040-17-000036:note_history:38]
Debt consisted of the following as of September 29, 2017 and June 30, 2017:

- changed (2018-02-06):
[0000106040-18-000010:note_history:39]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,022 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,955 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 12,237 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (186 | ) |  | (205 | ) |
| Subtotal | 12,051 |  |  | 13,151 |  |
| Less current portion of long-term debt | (274 | ) |  | (233 | ) |
| Long-term debt | $ | 11,777 |  |  | $ | 12,918 |  |
  (was, 2017-11-07, similarity 0.9321):
[0000106040-17-000036:note_history:39]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,073 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,963 |  |  | 2,970 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,031 |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 13,327 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (196 | ) |  | (205 | ) |
| Subtotal | 13,131 |  |  | 13,151 |  |
| Less current portion of long-term debt | (258 | ) |  | (233 | ) |
| Long-term debt | $ | 12,873 |  |  | $ | 12,918 |  |

- changed (2018-02-06):
[0000106040-18-000010:note_history:40]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |
  (was, 2017-11-07, similarity 0.9085):
[0000106040-17-000036:note_history:40]
| (1) | Euro Term Loan B-2 outstanding principal amounts as of September 29, 2017 and June 30, 2017 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0000106040-18-000010:note_history:41]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 29, 2017 and June 30, 2017:
  (was, 2017-11-07, similarity 0.9808):
[0000106040-17-000036:note_history:41]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 29, 2017 and June 30, 2017:

- changed (2018-02-06):
[0000106040-18-000010:note_history:42]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 101 |  |  | 119 |  |
| Notes receivable, Flash Forward | 429 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 279 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,845 |  |  | $ | 1,340 |  |
  (was, 2017-11-07, similarity 0.9919):
[0000106040-17-000036:note_history:42]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 365 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 114 |  |  | 119 |  |
| Notes receivable, Flash Forward | 406 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 278 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,462 |  |  | $ | 1,340 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-02-06):
[0000106040-18-000010:note_history:43]
Subsequent Events

- added (2018-02-06):
[0000106040-18-000010:note_history:44]
In January 2018, the Company announced its planned issuance of $2.30 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Notes”) and $1.00 billion aggregate principal amount of 1.5% convertible senior notes due 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes will be convertible into cash, shares of the Company’s common stock or a combination thereof, at an initial conversion price of approximately $121.91 per share. The issuance of the 2026 Notes and 2024 Convertible Notes is subject to customary closing conditions.

- added (2018-02-06):
[0000106040-18-000010:note_history:45]
On January 29, 2018, the Company commenced a cash tender offer with respect to any and all of its outstanding $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “2024 Unsecured Notes”).  The consideration offered for the 2024 Unsecured Notes is a total consideration of $1,167.25 per $1,000 principal amount, which includes the tender offer consideration of $1,137.25 and an early tender premium of $30.00. On January 30, 2018, the Company delivered a notice of conditional redemption with respect to the 2024 Unsecured Notes, with a March 1, 2018 redemption date.  The redemption of the 2024 Unsecured Notes is conditioned upon the issuance of the 2026 Notes. On January 30, 2018, the Company also delivered a notice of conditional redemption with respect to its outstanding $1.88 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “2023 Secured Notes”), with a March 1, 2018 redemption date. The redemption of the 2023 Secured Notes is conditioned upon the issuance of the 2024 Convertible Notes and/or an increase in the Company’s Term Loan A credit facility that collectively generates proceeds in excess of $2 billion.

- added (2018-02-06):
[0000106040-18-000010:note_history:46]
Since December 29, 2017, the Company also resumed its stock repurchase program and has repurchased approximately $151 million of its common stock in privately negotiated transactions, at a purchase price per share equal to $87.08 per share, with available cash on hand.
