# WDC note change history — 0000106040-23-000034 → 0000106040-24-000014


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-12):
[0000106040-24-000014:note_history:1]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the six months ended December 29, 2023 (in millions):
  (was, 2023-11-07, similarity 0.9651):
[0000106040-23-000034:note_history:1]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 29, 2023 (in millions):

- changed (2024-02-12):
[0000106040-24-000014:note_history:2]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 19 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at December 29, 2023 | $ | 677 |  |
  (was, 2023-11-07, similarity 0.9899):
[0000106040-23-000034:note_history:2]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross increases related to prior year tax positions | 17 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (2) |  |
| Accrual balance at September 29, 2023 | $ | 672 |  |


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-12):
[0000106040-24-000014:note_history:3]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 9 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 28 |  |  | 48 |  |
| Notes receivable, Flash Forward | 689 |  |  | 709 |  |
| Investment in Flash Partners | 168 |  |  | 161 |  |
| Investment in Flash Alliance | 279 |  |  | 276 |  |
| Investment in Flash Forward | 171 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,344 |  |  | $ | 1,410 |  |
  (was, 2023-11-07, similarity 0.9919):
[0000106040-23-000034:note_history:3]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 21 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 48 |  |
| Notes receivable, Flash Forward | 699 |  |  | 709 |  |
| Investment in Flash Partners | 155 |  |  | 160 |  |
| Investment in Flash Alliance | 227 |  |  | 234 |  |
| Investment in Flash Forward | 108 |  |  | 109 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,245 |  |  | $ | 1,297 |  |

- added (2024-02-12):
[0000106040-24-000014:note_history:4]
During the three and six months ended December 29, 2023 and December 30, 2022, the Company made net payments to Flash Ventures of $0.8 billion and $1.8 billion, and $1.0 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2024-02-12):
[0000106040-24-000014:note_history:5]
As of December 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $251 million and $292 million, respectively.
  (was, 2023-11-07, similarity 0.9821):
[0000106040-23-000034:note_history:5]
As of September 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $277 million and $292 million, respectively.

- added (2024-02-12):
[0000106040-24-000014:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2024-02-12):
[0000106040-24-000014:note_history:7]
|  | December 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 618 |  |
| Operating lease guarantees | 1,609 |  |
| Inventory and prepayments | 1,058 |  |
| Maximum estimable loss exposure | $ | 4,011 |  |

- changed (2024-02-12):
[0000106040-24-000014:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 30, 2022.
  (was, 2023-11-07, similarity 0.6314):
[0000106040-23-000034:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2023 and the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 30, 2022.

- added (2024-02-12):
[0000106040-24-000014:note_history:9]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, as well as charges for under absorption of overhead costs. During the three months ended December 29, 2023, the Company received a recovery of $36 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its remaining losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

- changed (2024-02-12):
[0000106040-24-000014:note_history:10]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of December 29, 2023, such prepayments aggregated $549 million and will be credited against future wafer charges.
  (was, 2023-11-07, similarity 0.9926):
[0000106040-23-000034:note_history:10]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of September 29, 2023, such prepayments aggregated $539 million and will be credited against future wafer charges.

- changed (2024-02-12):
[0000106040-24-000014:note_history:11]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023.
  (was, 2023-11-07, similarity 0.9864):
[0000106040-23-000034:note_history:11]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023.

- changed (2024-02-12):
[0000106040-24-000014:note_history:12]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023:
  (was, 2023-11-07, similarity 0.9808):
[0000106040-23-000034:note_history:12]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023:

- changed (2024-02-12):
[0000106040-24-000014:note_history:13]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2024 |  | $ | 237 |  |  | $ | 57 |  |  | $ | 294 |  |
| 2025 |  | 300 |  |  | 84 |  |  | 384 |  |
| 2026 |  | 362 |  |  | 127 |  |  | 489 |  |
| 2027 |  | 150 |  |  | 108 |  |  | 258 |  |
| 2028 |  | 47 |  |  | 104 |  |  | 151 |  |
| 2029 |  | 3 |  |  | 30 |  |  | 33 |  |
| Total guarantee obligations |  | $ | 1,099 |  |  | $ | 510 |  |  | $ | 1,609 |  |
  (was, 2023-11-07, similarity 0.9853):
[0000106040-23-000034:note_history:13]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2024 |  | $ | 340 |  |  | $ | 70 |  |  | $ | 410 |  |
| 2025 |  | 273 |  |  | 80 |  |  | 353 |  |
| 2026 |  | 324 |  |  | 121 |  |  | 445 |  |
| 2027 |  | 128 |  |  | 102 |  |  | 230 |  |
| 2028 |  | 37 |  |  | 99 |  |  | 136 |  |
| 2029 |  | 1 |  | 15 |  | 16 |  |
| Total guarantee obligations |  | $ | 1,103 |  |  | $ | 487 |  |  | $ | 1,590 |  |

- changed (2024-02-12):
[0000106040-24-000014:note_history:14]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2023-11-07, similarity 0.9932):
[0000106040-23-000034:note_history:14]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2024-02-12):
[0000106040-24-000014:note_history:15]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 8% of Accounts receivable, net as of both December 29, 2023 and June 30, 2023.
  (was, 2023-11-07, similarity 0.6061):
[0000106040-23-000034:note_history:15]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 29, 2023 and September 30, 2022, the Company recognized approximately 6% and 3% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 7% and 8% of Accounts receivable, net as of September 29, 2023 and June 30, 2023, respectively.

- removed (2024-02-12):
[0000106040-23-000034:note_history:16]
During the three months ended September 29, 2023 and September 30, 2022, the Company made net payments to Flash Ventures of $0.9 billion and $1.0 billion, respectively, for purchased flash-based memory wafers and net loans.

- removed (2024-02-12):
[0000106040-23-000034:note_history:17]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2024-02-12):
[0000106040-23-000034:note_history:18]
|  | September 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 755 |  |
| Equity investments | 490 |  |
| Operating lease guarantees | 1,590 |  |
| Inventory and prepayments | 1,047 |  |
| Maximum estimable loss exposure | $ | 3,882 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-12):
[0000106040-24-000014:note_history:19]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature as well as the revisions discussed further below. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2023-11-07, similarity 0.9688):
[0000106040-23-000034:note_history:19]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- added (2024-02-12):
[0000106040-24-000014:note_history:20]
Business Separation Costs

- added (2024-02-12):
[0000106040-24-000014:note_history:21]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

- added (2024-02-12):
[0000106040-24-000014:note_history:22]
Revision of Previously Issued Financial Statements

- added (2024-02-12):
[0000106040-24-000014:note_history:23]
In connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, the “Flash Ventures”). The errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in the Flash Ventures.

- added (2024-02-12):
[0000106040-24-000014:note_history:24]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the current period would be material to the Company's results of operations for the three and six months ended December 29, 2023. Accordingly, the Company has revised previously reported financial information for such immaterial errors. A summary of revisions to previously reported financial information presented herein for comparative purposes is included in Note 17, Revision of Previously Issued Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-02-12):
[0000106040-24-000014:note_history:25]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,662 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 8,454 |  |  | 7,100 |  |
| Issuance costs | (61) |  |  | (30) |  |
| Subtotal | 8,393 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,042) |  |  | (1,213) |  |
| Long-term debt | $ | 7,351 |  |  | $ | 5,857 |  |

- changed (2024-02-12):
[0000106040-24-000014:note_history:26]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the quarter ended December 29, 2023.
  (was, 2023-11-07, similarity 0.799):
[0000106040-23-000034:note_history:26]
During the three months ended September 29, 2023, the Company drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024.

- changed (2024-02-12):
[0000106040-24-000014:note_history:27]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of December 29, 2023 was 7.582%.
  (was, 2023-11-07, similarity 0.9942):
[0000106040-23-000034:note_history:27]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of September 29, 2023 was 7.416%.

- changed (2024-02-12):
[0000106040-24-000014:note_history:28]
During the three months ended December 29, 2023, the Company made a $38 million scheduled repayment of the Term Loan A-2. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 29, 2023 was 6.966%.
  (was, 2023-11-07, similarity 0.9012):
[0000106040-23-000034:note_history:28]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.375%. The all-in interest rate for Term Loan A-2 as of September 29, 2023 was 6.807%.

- changed (2024-02-12):
[0000106040-24-000014:note_history:29]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of December 29, 2023, the Company was in compliance with these financial covenants.
  (was, 2023-11-07, similarity 0.9746):
[0000106040-23-000034:note_history:29]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 due 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of September 29, 2023, the Company was in compliance with these financial covenants.

- added (2024-02-12):
[0000106040-24-000014:note_history:30]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 4.75% senior unsecured notes due 2026 (currently, Western Digital Technologies, Inc.).

- added (2024-02-12):
[0000106040-24-000014:note_history:31]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- added (2024-02-12):
[0000106040-24-000014:note_history:32]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes. As of December 29, 2023, unamortized debt issuance costs were $36 million.

- added (2024-02-12):
[0000106040-24-000014:note_history:33]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.

- added (2024-02-12):
[0000106040-24-000014:note_history:34]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of December 29, 2023.

- added (2024-02-12):
[0000106040-24-000014:note_history:35]
On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

- removed (2024-02-12):
[0000106040-23-000034:note_history:36]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,700 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (28) |  |  | (30) |  |
| Subtotal | 7,672 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,850) |  |  | (1,213) |  |
| Long-term debt | $ | 5,822 |  |  | $ | 5,857 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-02-12):
[0000106040-24-000014:note_history:37]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,662 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 8,454 |  |  | 7,100 |  |
| Issuance costs | (61) |  |  | (30) |  |
| Subtotal | 8,393 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,042) |  |  | (1,213) |  |
| Long-term debt | $ | 7,351 |  |  | $ | 5,857 |  |

- removed (2024-02-12):
[0000106040-23-000034:note_history:38]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,700 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (28) |  |  | (30) |  |
| Subtotal | 7,672 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,850) |  |  | (1,213) |  |
| Long-term debt | $ | 5,822 |  |  | $ | 5,857 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-02-12):
[0000106040-24-000014:note_history:39]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 9 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 28 |  |  | 48 |  |
| Notes receivable, Flash Forward | 689 |  |  | 709 |  |
| Investment in Flash Partners | 168 |  |  | 161 |  |
| Investment in Flash Alliance | 279 |  |  | 276 |  |
| Investment in Flash Forward | 171 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,344 |  |  | $ | 1,410 |  |
  (was, 2023-11-07, similarity 0.9919):
[0000106040-23-000034:note_history:39]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 21 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 48 |  |
| Notes receivable, Flash Forward | 699 |  |  | 709 |  |
| Investment in Flash Partners | 155 |  |  | 160 |  |
| Investment in Flash Alliance | 227 |  |  | 234 |  |
| Investment in Flash Forward | 108 |  |  | 109 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,245 |  |  | $ | 1,297 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-12):
[0000106040-24-000014:note_history:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,071 |  |  | $ | 1,224 |  |  | $ | 1,943 |  |  | $ | 3,053 |  |
| Client | 1,122 |  |  | 1,089 |  |  | 2,269 |  |  | 2,318 |  |
| Consumer | 839 |  |  | 794 |  |  | 1,570 |  |  | 1,472 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,699 |  |  | $ | 1,494 |  |  | $ | 3,250 |  |  | $ | 3,180 |  |
| Americas | 804 |  |  | 1,090 |  |  | 1,466 |  |  | 2,513 |  |
| Europe, Middle East and Africa | 529 |  |  | 523 |  |  | 1,066 |  |  | 1,150 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
  (was, 2023-11-07, similarity 0.785):
[0000106040-23-000034:note_history:40]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29,2023 |  | September 30,2022 |
|  |  |  |  |  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 872 |  |  | $ | 1,829 |  |
| Client |  |  |  |  | 1,147 |  |  | 1,229 |  |
| Consumer |  |  |  |  | 731 |  |  | 678 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 1,551 |  |  | $ | 1,686 |  |
| Americas |  |  |  |  | 662 |  |  | 1,423 |  |
| Europe, Middle East and Africa |  |  |  |  | 537 |  |  | 627 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-02-12):
[0000106040-23-000034:note_history:41]
Subsequent Events
Separation of Business Units

- removed (2024-02-12):
[0000106040-23-000034:note_history:42]
On October 30, 2023, the Company announced that its Board of Directors authorized management to pursue a plan to separate its HDD and Flash business units into two independent public companies. The completion of the separation is subject to certain conditions, including final approval by its Board of Directors. The Company is targeting to complete the separation of the business units in the second half of calendar year 2024.

- removed (2024-02-12):
[0000106040-23-000034:note_history:43]
Convertible Notes and Related Capped Call Transactions

- removed (2024-02-12):
[0000106040-23-000034:note_history:44]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 2026 Notes (currently, Western Digital Technologies, Inc.).

- removed (2024-02-12):
[0000106040-23-000034:note_history:45]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- removed (2024-02-12):
[0000106040-23-000034:note_history:46]
In connection with the debt issuance, the Company used approximately $155 million of the net proceeds of the 2028 Convertible Notes offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 per share to hedge the potential dilution impact of the notes’ conversion feature.

- removed (2024-02-12):
[0000106040-23-000034:note_history:47]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.
