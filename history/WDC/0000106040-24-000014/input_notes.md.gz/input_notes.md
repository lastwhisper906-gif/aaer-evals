# WDC notes — 0000106040-24-000014


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-24-000014:notes:1]
[same as prior period, unchanged from 0000106040-23-000034:notes:1]

[0000106040-24-000014:notes:2]
[same as prior period, unchanged from 0000106040-23-000034:notes:2]

[0000106040-24-000014:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature as well as the revisions discussed further below. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-24-000014:notes:4]
[same as prior period, unchanged from 0000106040-23-000034:notes:4]

[0000106040-24-000014:notes:5]
[same as prior period, unchanged from 0000106040-23-000034:notes:5]

[0000106040-24-000014:notes:6]
[same as prior period, unchanged from 0000106040-23-000034:notes:6]

[0000106040-24-000014:notes:7]
[same as prior period, unchanged from 0000106040-23-000034:notes:7]

[0000106040-24-000014:notes:8]
[same as prior period, unchanged from 0000106040-23-000034:notes:8]

[0000106040-24-000014:notes:9]
Business Separation Costs

[0000106040-24-000014:notes:10]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

[0000106040-24-000014:notes:11]
[same as prior period, unchanged from 0000106040-23-000034:notes:9]

[0000106040-24-000014:notes:12]
[same as prior period, unchanged from 0000106040-23-000034:notes:10]

[0000106040-24-000014:notes:13]
Revision of Previously Issued Financial Statements

[0000106040-24-000014:notes:14]
In connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, the “Flash Ventures”). The errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in the Flash Ventures.

[0000106040-24-000014:notes:15]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the current period would be material to the Company's results of operations for the three and six months ended December 29, 2023. Accordingly, the Company has revised previously reported financial information for such immaterial errors. A summary of revisions to previously reported financial information presented herein for comparative purposes is included in Note 17, Revision of Previously Issued Financial Statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-24-000014:notes:16]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-24-000014:notes:17]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU requires the Company to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 and to provide certain rollforward information related to those obligations beginning in the Company’s first fiscal quarter of 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. The Company adopted the guidance on the first day of fiscal year 2024, except for the rollforward information, which the Company is compiling and intends to provide beginning in fiscal year 2025. See Note 15, Supplier Finance Program, of the Notes to Condensed Consolidated Financial Statements for information regarding the supplier finance program.

[0000106040-24-000014:notes:18]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-24-000014:notes:19]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures”, which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. The ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity's CODM, a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.

[0000106040-24-000014:notes:20]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures”. The ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The amendments are effective for the Company’s fiscal year 2026, with early adoption permitted. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-24-000014:notes:21]
[same as prior period, unchanged from 0000106040-23-000034:notes:13]

[0000106040-24-000014:notes:22]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,665 |  |  | $ | 1,657 |  |  | $ | 3,221 |  |  | $ | 3,379 |  |
| HDD | 1,367 |  |  | 1,450 |  |  | 2,561 |  |  | 3,464 |  |
| Total net revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 131 |  |  | $ | 240 |  |  | $ | (30) |  |  | $ | 662 |  |
| HDD | 339 |  |  | 300 |  |  | 612 |  |  | 874 |  |
| Total gross profit for segments | 470 |  |  | 540 |  |  | 582 |  |  | 1,536 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (13) |  |  | (12) |  |  | (26) |  |  | (26) |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (1) |  |  | (1) |  |
| Recovery from contamination incident | 36 |  |  | — |  |  | 36 |  |  | — |  |
| Total unallocated corporate items | 22 |  |  | (12) |  |  | 9 |  |  | (27) |  |
| Consolidated gross profit | $ | 492 |  |  | $ | 528 |  |  | $ | 591 |  |  | $ | 1,509 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 7.9 | % |  | 14.5 | % |  | (0.9) | % |  | 19.6 | % |
| HDD | 24.8 | % |  | 20.7 | % |  | 23.9 | % |  | 25.2 | % |
| Consolidated gross margin | 16.2 | % |  | 17.0 | % |  | 10.2 | % |  | 22.1 | % |

[0000106040-24-000014:notes:23]
[same as prior period, unchanged from 0000106040-23-000034:notes:15]

[0000106040-24-000014:notes:24]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-24-000014:notes:25]
[same as prior period, unchanged from 0000106040-23-000034:notes:17]

[0000106040-24-000014:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,071 |  |  | $ | 1,224 |  |  | $ | 1,943 |  |  | $ | 3,053 |  |
| Client | 1,122 |  |  | 1,089 |  |  | 2,269 |  |  | 2,318 |  |
| Consumer | 839 |  |  | 794 |  |  | 1,570 |  |  | 1,472 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,699 |  |  | $ | 1,494 |  |  | $ | 3,250 |  |  | $ | 3,180 |  |
| Americas | 804 |  |  | 1,090 |  |  | 1,466 |  |  | 2,513 |  |
| Europe, Middle East and Africa | 529 |  |  | 523 |  |  | 1,066 |  |  | 1,150 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |

[0000106040-24-000014:notes:27]
The Company’s top 10 customers accounted for 39% of its net revenue for each of the three and six months ended December 29, 2023 and 47% and 48% of its net revenue for the three and six months ended December 30, 2022, respectively. For the three and six months ended December 29, 2023 and December 30, 2022, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-24-000014:notes:28]
[same as prior period, unchanged from 0000106040-23-000034:notes:20]

[0000106040-24-000014:notes:29]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed goodwill impairment assessments for each segment and concluded that there were no indications of impairment for the periods presented. The following table provides a summary of goodwill activity for the period:

[0000106040-24-000014:notes:30]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at June 30, 2023 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |
| Foreign currency translation adjustment | 1 |  |  | (1) |  |  | — |  |
| Balance at December 29, 2023 | $ | 5,717 |  |  | $ | 4,320 |  |  | $ | 10,037 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-24-000014:notes:31]
[same as prior period, unchanged from 0000106040-23-000034:notes:23]

[0000106040-24-000014:notes:32]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. During the six months ended December 29, 2023 and December 30, 2022, the Company sold trade accounts receivable aggregating $392 million and $391 million, respectively. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of December 29, 2023 and June 30, 2023, the amount of factored receivables that remained outstanding was $115 million and $150 million, respectively.

[0000106040-24-000014:notes:33]
[same as prior period, unchanged from 0000106040-23-000034:notes:25]

[0000106040-24-000014:notes:34]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,692 |  |  | $ | 2,096 |  |
| Work-in-process | 966 |  |  | 979 |  |
| Finished goods | 558 |  |  | 623 |  |
| Total inventories | $ | 3,216 |  |  | $ | 3,698 |  |

[0000106040-24-000014:notes:35]
[same as prior period, unchanged from 0000106040-23-000034:notes:27]

[0000106040-24-000014:notes:36]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 235 |  |  | $ | 269 |  |
| Buildings and improvements | 1,828 |  |  | 1,955 |  |
| Machinery and equipment | 8,684 |  |  | 8,704 |  |
| Computer equipment and software | 472 |  |  | 470 |  |
| Furniture and fixtures | 55 |  |  | 54 |  |
| Construction-in-process | 771 |  |  | 798 |  |
| Property, plant and equipment, gross | 12,045 |  |  | 12,250 |  |
| Accumulated depreciation | (8,730) |  |  | (8,630) |  |
| Property, plant and equipment, net | $ | 3,315 |  |  | $ | 3,620 |  |

[0000106040-24-000014:notes:37]
[same as prior period, unchanged from 0000106040-23-000034:notes:29]

[0000106040-24-000014:notes:38]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During the three months ended December 29, 2023, one IPR&D project reached technological feasibility and $8 million was reclassified from IPR&D to Existing technology and commenced amortization over an estimated useful life of three years. As of December 29, 2023 and June 30, 2023, IPR&D included in intangible assets, net was $72 million and $80 million, respectively.

[0000106040-24-000014:notes:39]
[same as prior period, unchanged from 0000106040-23-000034:notes:31]

[0000106040-24-000014:notes:40]
[same as prior period, unchanged from 0000106040-23-000034:notes:32]

[0000106040-24-000014:notes:41]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 218 |  |  | $ | 340 |  |  | $ | 244 |  |  | $ | 345 |  |  |  |
| Charges to operations | 26 |  |  | 25 |  |  | 48 |  |  | 57 |  |  |  |
| Utilization | (40) |  |  | (60) |  |  | (83) |  |  | (94) |  |  |  |
| Changes in estimate related to pre-existing warranties | (2) |  |  | (16) |  |  | (7) |  |  | (19) |  |  |  |
| Warranty accrual, end of period | $ | 202 |  |  | $ | 289 |  |  | $ | 202 |  |  | $ | 289 |  |  |  |

[0000106040-24-000014:notes:42]
[same as prior period, unchanged from 0000106040-23-000034:notes:34]

[0000106040-24-000014:notes:43]
|  | December 29,2023 |  | June 30,2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 50 |  |  | $ | 97 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 152 |  |  | 147 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 202 |  |  | $ | 244 |  |  |  |  |  |  |  |

[0000106040-24-000014:notes:44]
[same as prior period, unchanged from 0000106040-23-000034:notes:36]

[0000106040-24-000014:notes:45]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 199 |  |  | $ | 464 |  |
| Non-current portion of unrecognized tax benefits | 501 |  |  | 408 |  |
| Other non-current liabilities | 697 |  |  | 543 |  |
| Total other liabilities | $ | 1,397 |  |  | $ | 1,415 |  |

[0000106040-24-000014:notes:46]
[same as prior period, unchanged from 0000106040-23-000034:notes:38]

[0000106040-24-000014:notes:47]
[same as prior period, unchanged from 0000106040-23-000034:notes:39]

[0000106040-24-000014:notes:48]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 30, 2023 | $ | (2) |  |  | $ | (389) |  |  |  |  |  |  | $ | (157) |  |  | $ | (548) |  |
| Other comprehensive loss before reclassifications | — |  |  | 20 |  |  |  |  |  |  | (35) |  |  | (15) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 76 |  |  | 76 |  |
| Income tax expense related to items of other comprehensive loss | — |  |  | 1 |  |  |  |  |  |  | (7) |  |  | (6) |  |
| Net current-period other comprehensive loss | — |  |  | 21 |  |  |  |  |  |  | 34 |  |  | 55 |  |
| Balance at December 29, 2023 | $ | (2) |  |  | $ | (368) |  |  |  |  |  |  | $ | (123) |  |  | $ | (493) |  |

[0000106040-24-000014:notes:49]
During the three and six months ended December 29, 2023, the amounts reclassified out of AOCL were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. 
As of December 29, 2023, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months. In addition, as of December 29, 2023, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-24-000014:notes:50]
[same as prior period, unchanged from 0000106040-23-000034:notes:42]

[0000106040-24-000014:notes:51]
[same as prior period, unchanged from 0000106040-23-000034:notes:43]

[0000106040-24-000014:notes:52]
[same as prior period, unchanged from 0000106040-23-000034:notes:44]

[0000106040-24-000014:notes:53]
[same as prior period, unchanged from 0000106040-23-000034:notes:45]

[0000106040-24-000014:notes:54]
[same as prior period, unchanged from 0000106040-23-000034:notes:46]

[0000106040-24-000014:notes:55]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 29, 2023 and June 30, 2023, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-24-000014:notes:56]
|  | December 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 568 |  |  | $ | — |  |  | $ | — |  |  | $ | 568 |  |
| Foreign exchange contracts | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Total assets at fair value | $ | 568 |  |  | $ | 39 |  |  | $ | — |  |  | $ | 607 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 87 |  |  | $ | — |  |  | $ | 87 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 87 |  |  | $ | — |  |  | $ | 87 |  |

[0000106040-24-000014:notes:57]
[same as prior period, unchanged from 0000106040-23-000034:notes:49]

[0000106040-24-000014:notes:58]
[same as prior period, unchanged from 0000106040-23-000034:notes:50]

[0000106040-24-000014:notes:59]
[same as prior period, unchanged from 0000106040-23-000034:notes:51]

[0000106040-24-000014:notes:60]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2024 and the fourth quarter of 2023, respectively.

[0000106040-24-000014:notes:61]
|  | December 29, 2023 |  | June 30, 2023 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 589 |  |  | $ | 1,099 |  |  | $ | 1,067 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | 301 |  |  | — |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,295 |  |  | 2,257 |  |  | 2,293 |  |  | 2,193 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,651 |  |  | 2,583 |  |  | 2,687 |  |  | 2,661 |  |
| 3.00% convertible notes due 2028 | 1,564 |  |  | 1,960 |  |  | — |  |  | — |  |
| 2.85% senior notes due 2029 | 496 |  |  | 430 |  |  | 496 |  |  | 400 |  |
| 3.10% senior notes due 2032 | 495 |  |  | 399 |  |  | 495 |  |  | 371 |  |
| Total | $ | 8,393 |  |  | $ | 8,519 |  |  | $ | 7,070 |  |  | $ | 6,692 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-24-000014:notes:62]
Derivative Instruments and Hedging Activities
As of December 29, 2023, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of December 29, 2023, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-24-000014:notes:63]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three and six months ended December 29, 2023 and December 30, 2022, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-24-000014:notes:64]
[same as prior period, unchanged from 0000106040-23-000034:notes:56]

[0000106040-24-000014:notes:65]
[same as prior period, unchanged from 0000106040-23-000034:notes:57]

[0000106040-24-000014:notes:66]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 29, 2023 and June 30, 2023, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-24-000014:notes:67]
Debt
Debt consisted of the following:

[0000106040-24-000014:notes:68]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,662 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 8,454 |  |  | 7,100 |  |
| Issuance costs | (61) |  |  | (30) |  |
| Subtotal | 8,393 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,042) |  |  | (1,213) |  |
| Long-term debt | $ | 7,351 |  |  | $ | 5,857 |  |

[0000106040-24-000014:notes:69]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the quarter ended December 29, 2023.

[0000106040-24-000014:notes:70]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of December 29, 2023 was 7.582%.

[0000106040-24-000014:notes:71]
During the three months ended December 29, 2023, the Company made a $38 million scheduled repayment of the Term Loan A-2. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 29, 2023 was 6.966%.

[0000106040-24-000014:notes:72]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of December 29, 2023, the Company was in compliance with these financial covenants.

[0000106040-24-000014:notes:73]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 4.75% senior unsecured notes due 2026 (currently, Western Digital Technologies, Inc.).

[0000106040-24-000014:notes:74]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000014:notes:75]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes. As of December 29, 2023, unamortized debt issuance costs were $36 million.

[0000106040-24-000014:notes:76]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.

[0000106040-24-000014:notes:77]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of December 29, 2023.

[0000106040-24-000014:notes:78]
On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-24-000014:notes:79]
[same as prior period, unchanged from 0000106040-23-000034:notes:65]

[0000106040-24-000014:notes:80]
[same as prior period, unchanged from 0000106040-23-000034:notes:66]

[0000106040-24-000014:notes:81]
[same as prior period, unchanged from 0000106040-23-000034:notes:67]

[0000106040-24-000014:notes:82]
|  | December 29,2023 |  | June 30,2023 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 273 |  |  | $ | 273 |  |  |  |
| Fair value of plan assets at end of period | 188 |  |  | 185 |  |  |  |
| Unfunded status | $ | 85 |  |  | $ | 88 |  |  |  |

[0000106040-24-000014:notes:83]
[same as prior period, unchanged from 0000106040-23-000034:notes:69]

[0000106040-24-000014:notes:84]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 84 |  |  | 87 |  |
| Net amount recognized | $ | 85 |  |  | $ | 88 |  |

[0000106040-24-000014:notes:85]
Net periodic benefit costs were not material for the three and six months ended December 29, 2023.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-24-000014:notes:86]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-24-000014:notes:87]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-24-000014:notes:88]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-24-000014:notes:89]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 9 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 28 |  |  | 48 |  |
| Notes receivable, Flash Forward | 689 |  |  | 709 |  |
| Investment in Flash Partners | 168 |  |  | 161 |  |
| Investment in Flash Alliance | 279 |  |  | 276 |  |
| Investment in Flash Forward | 171 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,344 |  |  | $ | 1,410 |  |

[0000106040-24-000014:notes:90]
During the three and six months ended December 29, 2023 and December 30, 2022, the Company made net payments to Flash Ventures of $0.8 billion and $1.8 billion, and $1.0 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-24-000014:notes:91]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-24-000014:notes:92]
As of December 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $251 million and $292 million, respectively.

[0000106040-24-000014:notes:93]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-24-000014:notes:94]
|  | December 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 618 |  |
| Operating lease guarantees | 1,609 |  |
| Inventory and prepayments | 1,058 |  |
| Maximum estimable loss exposure | $ | 4,011 |  |

[0000106040-24-000014:notes:95]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-24-000014:notes:96]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 30, 2022.

[0000106040-24-000014:notes:97]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, as well as charges for under absorption of overhead costs. During the three months ended December 29, 2023, the Company received a recovery of $36 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its remaining losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-24-000014:notes:98]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of December 29, 2023, such prepayments aggregated $549 million and will be credited against future wafer charges.

[0000106040-24-000014:notes:99]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-24-000014:notes:100]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-24-000014:notes:101]
Off-Balance Sheet Liabilities

[0000106040-24-000014:notes:102]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-24-000014:notes:103]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023.

[0000106040-24-000014:notes:104]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 228 |  |  | $ | 1,609 |  |

[0000106040-24-000014:notes:105]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023:

[0000106040-24-000014:notes:106]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2024 |  | $ | 237 |  |  | $ | 57 |  |  | $ | 294 |  |
| 2025 |  | 300 |  |  | 84 |  |  | 384 |  |
| 2026 |  | 362 |  |  | 127 |  |  | 489 |  |
| 2027 |  | 150 |  |  | 108 |  |  | 258 |  |
| 2028 |  | 47 |  |  | 104 |  |  | 151 |  |
| 2029 |  | 3 |  |  | 30 |  |  | 33 |  |
| Total guarantee obligations |  | $ | 1,099 |  |  | $ | 510 |  |  | $ | 1,609 |  |

[0000106040-24-000014:notes:107]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-24-000014:notes:108]
Unis Venture

[0000106040-24-000014:notes:109]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 8% of Accounts receivable, net as of both December 29, 2023 and June 30, 2023.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-24-000014:notes:110]
[same as prior period, unchanged from 0000106040-23-000034:notes:95]

[0000106040-24-000014:notes:111]
[same as prior period, unchanged from 0000106040-23-000034:notes:96]

[0000106040-24-000014:notes:112]
The following table summarizes supplemental balance sheet information related to operating leases as of December 29, 2023:

[0000106040-24-000014:notes:113]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining six months of 2024 | $ | 34 |  |  |  |  |  |  |  |  |  |
| 2025 | 67 |  |  |  |  |  |  |  |  |  |
| 2026 | 68 |  |  |  |  |  |  |  |  |  |
| 2027 | 60 |  |  |  |  |  |  |  |  |  |
| 2028 | 51 |  |  |  |  |  |  |  |  |  |
| Thereafter | 330 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 610 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 170 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 440 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 47 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 393 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 418 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 10.2 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 6.0 | % |  |  |  |  |  |  |  |  |

[0000106040-24-000014:notes:114]
[same as prior period, unchanged from 0000106040-23-000034:notes:99]

[0000106040-24-000014:notes:115]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions) |
| Cost of operating leases | $ | 17 |  |  | $ | 14 |  |  | $ | 31 |  |  | $ | 28 |  |
| Cash paid for operating leases | 17 |  |  | 12 |  |  | 32 |  |  | 26 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 9 |  |  | — |  |  | 177 |  |  | 4 |  |

[0000106040-24-000014:notes:116]
[same as prior period, unchanged from 0000106040-23-000034:notes:101]

[0000106040-24-000014:notes:117]
[same as prior period, unchanged from 0000106040-23-000034:notes:102]

[0000106040-24-000014:notes:118]
[same as prior period, unchanged from 0000106040-23-000034:notes:103]

[0000106040-24-000014:notes:119]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of December 29, 2023, the Company had the following minimum long-term commitments:

[0000106040-24-000014:notes:120]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining six months of 2024 |  | $ | 148 |  |
| 2025 |  | 267 |  |
| 2026 |  | 73 |  |
| 2027 |  | 49 |  |
| 2028 |  | 20 |  |
| Thereafter |  | 130 |  |
| Total |  | $ | 687 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-24-000014:notes:121]
[same as prior period, unchanged from 0000106040-23-000034:notes:106]

[0000106040-24-000014:notes:122]
[same as prior period, unchanged from 0000106040-23-000034:notes:107]

[0000106040-24-000014:notes:123]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |  |
|  | (in millions) |
| RSUs and PSUs | $ | 68 |  |  | $ | 79 |  |  | $ | 133 |  |  | $ | 154 |  |  |
| ESPP | 4 |  |  | 7 |  |  | 16 |  |  | 18 |  |  |
| Total | $ | 72 |  |  | $ | 86 |  |  | $ | 149 |  |  | $ | 172 |  |  |

[0000106040-24-000014:notes:124]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |  |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 12 |  |  | $ | 26 |  |  | $ | 26 |  |  |
| Research and development | 32 |  |  | 40 |  |  | 66 |  |  | 79 |  |  |
| Selling, general and administrative | 27 |  |  | 34 |  |  | 57 |  |  | 67 |  |  |
| Subtotal | 72 |  |  | 86 |  |  | 149 |  |  | 172 |  |  |
| Tax benefit | (10) |  |  | (11) |  |  | (20) |  |  | (24) |  |  |
| Total | $ | 62 |  |  | $ | 75 |  |  | $ | 129 |  |  | $ | 148 |  |  |

[0000106040-24-000014:notes:125]
[same as prior period, unchanged from 0000106040-23-000034:notes:110]

[0000106040-24-000014:notes:126]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 29, 2023:

[0000106040-24-000014:notes:127]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 516 |  |  | 2.6 |
| ESPP | 45 |  |  | 1.0 |
| Total unamortized compensation cost | $ | 561 |  |  |  |

[0000106040-24-000014:notes:128]
[same as prior period, unchanged from 0000106040-23-000034:notes:113]

[0000106040-24-000014:notes:129]
[same as prior period, unchanged from 0000106040-23-000034:notes:114]

[0000106040-24-000014:notes:130]
[same as prior period, unchanged from 0000106040-23-000034:notes:115]

[0000106040-24-000014:notes:131]
The following table summarizes stock option activity under the Company’s incentive plans. As of December 29, 2023, there were no remaining outstanding options.

[0000106040-24-000014:notes:132]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at June 30, 2023 | 0.3 |  |  | $ | 44.95 |  |  | 0.10 |  |  |
| Canceled or expired | (0.3) |  |  | 44.95 |  |  |  |  |  |
| Options outstanding at December 29, 2023 | — |  |  | $ | — |  |  |  |  |  |

[0000106040-24-000014:notes:133]
[same as prior period, unchanged from 0000106040-23-000034:notes:118]

[0000106040-24-000014:notes:134]
[same as prior period, unchanged from 0000106040-23-000034:notes:119]

[0000106040-24-000014:notes:135]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | $ | 46.56 |  |  |  |
| Granted | 5.6 |  |  | 38.04 |  |  |  |
| Vested | (4.0) |  |  | 47.65 |  |  | $ | 173 |  |
| Forfeited | (1.0) |  |  | 46.58 |  |  |  |
| RSUs and PSUs outstanding at December 29, 2023 | 14.4 |  |  | $ | 43.56 |  |  |  |

[0000106040-24-000014:notes:136]
[same as prior period, unchanged from 0000106040-23-000034:notes:121]

[0000106040-24-000014:notes:137]
[same as prior period, unchanged from 0000106040-23-000034:notes:122]

[0000106040-24-000014:notes:138]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million. The Preferred Shares accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of December 29, 2023 and June 30, 2023, unpaid and cumulative dividends payable with respect to the Preferred Shares were $53 million and $24 million, respectively.

[0000106040-24-000014:notes:139]
As of December 29, 2023 and June 30, 2023, the Preferred Shares outstanding had an aggregate liquidation preference of $953 million and $924 million, respectively, and would have been convertible, if otherwise permitted, into approximately 20 million shares of common stock on each such date.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-24-000014:notes:140]
[same as prior period, unchanged from 0000106040-23-000034:notes:125]

[0000106040-24-000014:notes:141]
[same as prior period, unchanged from 0000106040-23-000034:notes:126]

[0000106040-24-000014:notes:142]
[same as prior period, unchanged from 0000106040-23-000034:notes:127]

[0000106040-24-000014:notes:143]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | ($ in millions) |
| Loss before taxes | $ | (259) |  |  | $ | (381) |  |  | $ | (941) |  |  | $ | (288) |  |
| Income tax expense | 28 |  |  | 70 |  |  | 31 |  |  | 116 |  |
| Effective tax rate | (11) | % |  | (18 | %) |  | (3) | % |  | (40 | %) |

[0000106040-24-000014:notes:144]
Beginning in 2023, the 2017 Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and six months ended December 29, 2023, but did not have a material impact on the Company’s effective tax rate.

[0000106040-24-000014:notes:145]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during years 2024 through 2031. On November 1, 2023, one of the Company’s tax holidays in Malaysia expired. The Company has applied for an extension and anticipates this extension, if granted, will be applied retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, the Company is applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, the Company will make an adjustment to its effective tax rate in that period. The effective tax rate for the six months ended December 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000014:notes:146]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 30, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-24-000014:notes:147]
[same as prior period, unchanged from 0000106040-23-000034:notes:132]

[0000106040-24-000014:notes:148]
[same as prior period, unchanged from 0000106040-23-000034:notes:133]

[0000106040-24-000014:notes:149]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the six months ended December 29, 2023 (in millions):

[0000106040-24-000014:notes:150]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 19 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at December 29, 2023 | $ | 677 |  |

[0000106040-24-000014:notes:151]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of December 29, 2023 were $161 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of December 29, 2023, approximately $671 million could result in potential cash payments and the Company believes it is reasonably likely that payments of approximately $187 million may be made within the next twelve months and has classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on the Condensed Consolidated Balance Sheets as of December 29, 2023. The remaining payables related to unrecognized tax benefits are included in Other liabilities on the Condensed Consolidated Balance Sheets as of December 29, 2023.

[0000106040-24-000014:notes:152]
The Company reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 29, 2023, the Company made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $187 million as of December 29, 2023 related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000014:notes:153]
[same as prior period, unchanged from 0000106040-23-000034:notes:138]

[0000106040-24-000014:notes:154]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 29, 2023, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-24-000014:notes:155]
Net Loss Per Common Share 
The following table presents the computation of basic and diluted loss per common share:

[0000106040-24-000014:notes:156]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions, except per share data) |
| Net loss | $ | (287) |  |  |  | $ | (451) |  |  | $ | (972) |  |  | $ | (404) |  |
| Less: cumulative dividends on Preferred Stock | 14 |  |  |  | — |  |  | 29 |  |  | — |  |
| Net loss attributable to common shareholders | $ | (301) |  |  |  | $ | (451) |  |  | $ | (1,001) |  |  | $ | (404) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 325 |  |  |  | 318 |  |  | 324 |  |  | 317 |  |
| Diluted | 325 |  |  |  | 318 |  |  | 324 |  |  | 317 |  |
| Net loss per common share |  |  |  |  |  |  |  |  |
| Basic | $ | (0.93) |  |  |  | $ | (1.42) |  |  | $ | (3.09) |  |  | $ | (1.27) |  |
| Diluted | $ | (0.93) |  |  |  | $ | (1.42) |  |  | $ | (3.09) |  |  | $ | (1.27) |  |
| Anti-dilutive potential common shares excluded | 14 |  |  |  | 15 |  |  | 14 |  |  | 15 |  |

[0000106040-24-000014:notes:157]
Basic net loss per share attributable to common shareholders is computed using (i) net loss less (ii) dividends paid to holders of Preferred Shares less (iii) net loss attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net loss attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the convertible notes and the Preferred Shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-24-000014:notes:158]
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and the Preferred Shares. For the three and six months ended December 29, 2023 and December 30, 2022, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-24-000014:notes:159]
[same as prior period, unchanged from 0000106040-23-000034:notes:143]

[0000106040-24-000014:notes:160]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. In this regard, in the six months ended December 29, 2023, the Company reassessed existing capacity development plans and made a decision to cancel certain projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress and the recognition of a liability for certain contract termination costs. The Company has also taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in September 2023. The Company recorded the following net charges related to these actions for the periods noted below:

[0000106040-24-000014:notes:161]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 24 |  |  | $ | 61 |  |  | $ | 43 |  |  | $ | 85 |  |  |  |
| Contract termination and other | — |  |  | — |  |  | 29 |  |  | — |  |  |  |
| Asset impairments | — |  |  | 15 |  |  | 94 |  |  | 15 |  |  |  |
| Gain on sale-leaseback of facility | — |  |  | — |  |  | (85) |  |  | — |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 24 |  |  | $ | 76 |  |  | $ | 81 |  |  | $ | 100 |  |  |  |

[0000106040-24-000014:notes:162]
The following table presents an analysis of the components of these activities against the reserve during the six months ended December 29, 2023:

[0000106040-24-000014:notes:163]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 30, 2023 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |  |  |  |  |
| Charges | 43 |  |  | 29 |  |  | 72 |  |  |  |  |  |
| Cash payments | (57) |  |  | (3) |  |  | (60) |  |  |  |  |  |
| Accrual balance at December 29, 2023 | $ | 17 |  |  | $ | 31 |  |  | $ | 48 |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-24-000014:notes:164]
[same as prior period, unchanged from 0000106040-23-000034:notes:148]

[0000106040-24-000014:notes:165]
[same as prior period, unchanged from 0000106040-23-000034:notes:149]

[0000106040-24-000014:notes:166]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $36 million and $38 million as of December 29, 2023 and June 30, 2023, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-24-000014:notes:167]
Legal Proceedings
Tax

[0000106040-24-000014:notes:168]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

[0000106040-24-000014:notes:169]
Other Matters

[0000106040-24-000014:notes:170]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:ErrorCorrectionTextBlock

[0000106040-24-000014:notes:171]
Revision of Previously Issued Financial Statements
As described in Note 1, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Ventures. These errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in the Flash Ventures.

[0000106040-24-000014:notes:172]
The following tables provide a summary of the revisions made to the Company’s Condensed Consolidated Financial Statements for the periods presented.

[0000106040-24-000014:notes:173]
|  |  | Three Months Ended December 30, 2022 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating loss |  | $ | (321) |  |  | $ | — |  |  | $ | (321) |  |
| Interest and other expense: |  |  |  |  |  |  |
| Interest income |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense |  | (73) |  |  | — |  |  | (73) |  |
| Other income, net |  | 6 |  |  | 4 |  |  | 10 |  |
| Total interest and other expense, net |  | (64) |  |  | 4 |  |  | (60) |  |
| Loss before taxes |  | (385) |  |  | 4 |  |  | (381) |  |
| Income tax expense |  | 61 |  |  | 9 |  |  | 70 |  |
| Net loss |  | $ | (446) |  |  | $ | (5) |  |  | $ | (451) |  |
| Net loss per common share: |  |  |  |  |  |  |
| Basic |  | $ | (1.40) |  |  | $ | (0.02) |  |  | $ | (1.42) |  |
| Diluted |  | $ | (1.40) |  |  | $ | (0.02) |  |  | $ | (1.42) |  |

[0000106040-24-000014:notes:174]
|  |  | Six Months Ended December 30, 2022 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating loss |  | $ | (163) |  |  | $ | — |  |  | $ | (163) |  |
| Interest and other expense: |  |  |  |  |  |  |
| Interest income |  | 5 |  |  | — |  |  | 5 |  |
| Interest expense |  | (143) |  |  | — |  |  | (143) |  |
| Other income, net |  | — |  |  | 13 |  |  | 13 |  |
| Total interest and other expense, net |  | (138) |  |  | 13 |  |  | (125) |  |
| Loss before taxes |  | (301) |  |  | 13 |  |  | (288) |  |
| Income tax expense |  | 118 |  |  | (2) |  |  | 116 |  |
| Net loss |  | $ | (419) |  |  | $ | 15 |  |  | $ | (404) |  |
| Net loss per common share: |  |  |  |  |  |  |
| Basic |  | $ | (1.32) |  |  | $ | 0.05 |  |  | $ | (1.27) |  |
| Diluted |  | $ | (1.32) |  |  | $ | 0.05 |  |  | $ | (1.27) |  |

[0000106040-24-000014:notes:175]
|  |  | Three Months Ended December 30, 2022 |
| Condensed Consolidated Statement of Comprehensive Loss |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net loss |  | $ | (446) |  |  | $ | (5) |  |  | $ | (451) |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | 95 |  |  | 11 |  |  | 106 |  |
| Net unrealized gain on derivative contracts |  | 288 |  |  | — |  |  | 288 |  |
| Total other comprehensive income, before tax |  | 383 |  |  | 11 |  |  | 394 |  |
| Income tax expense related to items of other comprehensive income, before tax |  | (58) |  |  | 9 |  |  | (49) |  |
| Other comprehensive income, net of tax |  | 325 |  |  | 20 |  |  | 345 |  |
| Total comprehensive loss |  | $ | (121) |  |  | $ | 15 |  |  | $ | (106) |  |

[0000106040-24-000014:notes:176]
|  |  | Six Months Ended December 30, 2022 |
| Condensed Consolidated Statement of Comprehensive Loss |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net loss |  | $ | (419) |  |  | $ | 15 |  |  | $ | (404) |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | 15 |  |  | 4 |  |  | 19 |  |
| Net unrealized gain on derivative contracts |  | 212 |  |  | — |  |  | 212 |  |
| Total other comprehensive income, before tax |  | 227 |  |  | 4 |  |  | 231 |  |
| Income tax expense related to items of other comprehensive income, before tax |  | (42) |  |  | 9 |  |  | (33) |  |
| Other comprehensive income, net of tax |  | 185 |  |  | 13 |  |  | 198 |  |
| Total comprehensive loss |  | $ | (234) |  |  | $ | 28 |  |  | $ | (206) |  |

[0000106040-24-000014:notes:177]
|  |  | Six Months Ended December 30, 2022 |
| Condensed Consolidated Statement of Cash Flows |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |
| Net loss |  | $ | (419) |  |  | $ | 15 |  |  | $ | (404) |  |
| Deferred income taxes |  | 25 |  |  | (4) |  |  | 21 |  |
| Other non-cash operating activities, net |  | 69 |  |  | (13) |  |  | 56 |  |
| Other assets and liabilities, net |  | (317) |  |  | 2 |  |  | (315) |  |
| Net cash provided by operating activities |  | 41 |  |  | — |  |  | 41 |  |

[0000106040-24-000014:notes:178]
| Condensed Consolidated Statement of Shareholders’ Equity |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Retained earnings as of: |  |  |  |  |  |  |
| July 1, 2022 |  | $ | 9,039 |  |  | $ | 127 |  |  | $ | 9,166 |  |
| December 30, 2022 |  | 8,711 |  |  | 142 |  |  | 8,853 |  |
| Accumulated other comprehensive loss as of: |  |  |  |  |  |  |
| July 1, 2022 |  | (554) |  |  | (25) |  |  | (579) |  |
| December 30, 2022 |  | (369) |  |  | (12) |  |  | (381) |  |
| Foreign currency translation adjustment for the three months ended: |  |  |  |  |  |  |
| September 30, 2022 |  | (80) |  |  | (7) |  |  | (87) |  |
| December 30, 2022 |  | 97 |  |  | 20 |  |  | 117 |  |

[0000106040-24-000014:notes:179]
|  |  | As of June 30, 2023 |
| Condensed Consolidated Balance Sheet |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Notes receivable and investments in Flash Ventures |  | $ | 1,297 |  |  | $ | 113 |  |  | $ | 1,410 |  |
| Other non-current assets |  | 1,509 |  |  | 4 |  |  | 1,513 |  |
| Total assets |  | 24,429 |  |  | 117 |  |  | 24,546 |  |
| Accumulated other comprehensive loss |  | (516) |  |  | (32) |  |  | (548) |  |
| Retained earnings |  | 7,424 |  |  | 149 |  |  | 7,573 |  |
| Total shareholders’ equity |  | 10,847 |  |  | 117 |  |  | 10,964 |  |
| Total liabilities, convertible preferred stock and shareholders’ equity |  | 24,429 |  |  | 117 |  |  | 24,546 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000106040-24-000014:notes:180]
Michael Ray, Executive Vice President, Chief Legal Officer and Secretary of the Company, adopted a Rule 10b5-1 Plan on November 8, 2023. Under this plan, up to an aggregate of 87,902 shares of the Company’s common stock may be sold before the plan expires on May 9, 2025.

[0000106040-24-000014:notes:181]
Kimberly E. Alexy, a director of the Company, adopted a Rule 10b5-1 Plan on November 24, 2023. Under this plan, up to an aggregate of 5,648 shares of the Company’s common stock may be sold before the plan expires on November 24, 2025.

[0000106040-24-000014:notes:182]
Gene Zamiska, Senior Vice President, Global Accounting and Chief Accounting Officer of the Company, adopted a Rule 10b5-1 Plan on December 1, 2023. Under this plan, up to an aggregate of 26,432 shares of the Company’s common stock may be sold before the plan expires on May 1, 2025.
