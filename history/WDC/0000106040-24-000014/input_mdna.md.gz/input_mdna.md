# WDC MD&A — 0000106040-24-000014


## mdna

[0000106040-24-000014:mdna:1]
[same as prior period, unchanged from 0000106040-23-000034:mdna:1]

[0000106040-24-000014:mdna:2]
[same as prior period, unchanged from 0000106040-23-000034:mdna:2]

[0000106040-24-000014:mdna:3]
[same as prior period, unchanged from 0000106040-23-000034:mdna:3]

[0000106040-24-000014:mdna:4]
[same as prior period, unchanged from 0000106040-23-000034:mdna:4]

[0000106040-24-000014:mdna:5]
Our broad portfolio of technology and products address our multiple end markets: “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-24-000014:mdna:6]
[same as prior period, unchanged from 0000106040-23-000034:mdna:6]

[0000106040-24-000014:mdna:7]
[same as prior period, unchanged from 0000106040-23-000034:mdna:7]

[0000106040-24-000014:mdna:8]
[same as prior period, unchanged from 0000106040-23-000034:mdna:8]

[0000106040-24-000014:mdna:9]
[same as prior period, unchanged from 0000106040-23-000034:mdna:9]

[0000106040-24-000014:mdna:10]
[same as prior period, unchanged from 0000106040-23-000034:mdna:20]

[0000106040-24-000014:mdna:11]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry have experienced a supply-demand imbalance, which has resulted in reduced shipments and negatively impacted pricing, particularly in Flash. To adapt to these conditions, we have implemented measures to reduce operating expenses and to proactively manage supply and inventory to align with demand and improve our capital efficiency, while continuing to deploy innovative products. These actions have enabled us to scale back on capital expenditures, consolidate production lines and reduce production bit growth since the beginning of 2023 in order to better align with market demand. These actions have resulted in incremental charges for employee termination, asset impairment and other, and manufacturing underutilization charges in Flash and HDD, and are expected to continue to negatively impact near-term results. While the supply-demand imbalance has recently started to show signs of stabilization, particularly in Client and Consumer, we continue to face a dynamic market environment. We believe digital transformation will continue to drive long-term growth for data storage in both Flash and HDD and believe that the strategy we have been executing will enable us to improve through-cycle profitability into the future.

[0000106040-24-000014:mdna:12]
[same as prior period, unchanged from 0000106040-23-000034:mdna:22]

[0000106040-24-000014:mdna:13]
See Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended June 30, 2023 and Part II, Item 1A, Risk Factors, of this Quarterly Report on Form 10-Q for more information regarding the risks we face as a result of macroeconomic conditions and supply chain disruptions.

[0000106040-24-000014:mdna:14]
[same as prior period, unchanged from 0000106040-23-000034:mdna:10]

[0000106040-24-000014:mdna:15]
In August 2023, we drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement we entered into in January 2023 and amended in June 2023, which allowed us to draw a single loan of up to $600 million through August 14, 2023. Proceeds from this loan were primarily used for payments on our tax liability to the IRS for the years 2008 through 2012. During the three months ended December 29, 2023, we repaid $300 million of the principal amount of the Delayed Draw Term Loan. The remaining outstanding borrowings on this loan will mature on June 28, 2024.

[0000106040-24-000014:mdna:16]
On November 3, 2023, we issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). We received net proceeds of approximately $1.56 billion after issuance costs. Contemporaneously with the issuance of the 2028 Convertible Notes, we entered into individually negotiated transactions with certain holders of our existing 1.50% convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”) to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount using net proceeds from the offering of the 2028 Convertible Notes. In connection with the issuance of the 2028 Convertible Notes, we also used approximately $155 million of the net proceeds from the offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 to hedge the potential dilution impact of the conversion feature. On February 1, 2024, we used a portion of the remaining net proceeds from the offering of the 2028 Convertible Notes to settle the remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-24-000014:mdna:17]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-24-000014:mdna:18]
[same as prior period, unchanged from 0000106040-23-000034:mdna:14]

[0000106040-24-000014:mdna:19]
[same as prior period, unchanged from 0000106040-23-000034:mdna:15]

[0000106040-24-000014:mdna:20]
[same as prior period, unchanged from 0000106040-23-000034:mdna:16]

[0000106040-24-000014:mdna:21]
In connection with the actions described in “Operational Update” above, we reassessed our existing capacity development plans and made a decision in the first quarter of 2024 to cancel certain projects to expand capacity in our Penang, Malaysia facility. This resulted in a $94 million impairment of existing construction in progress and recognition of $29 million for certain contract termination costs during the six months ended December 29, 2023.

[0000106040-24-000014:mdna:22]
[same as prior period, unchanged from 0000106040-23-000034:mdna:18]

[0000106040-24-000014:mdna:23]
As previously disclosed, we reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 29, 2023, we made payments aggregating $523 million for tax and interest with respect to years 2008 through 2012 and have a remaining liability of $187 million as of December 29, 2023 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our “Results of Operations” below, as well as in Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements, and in the “Short- and Long-term Liquidity - Unrecognized Tax Benefits” section below.

[0000106040-24-000014:mdna:24]
44

[0000106040-24-000014:mdna:25]
[same as prior period, unchanged from 0000106040-23-000034:mdna:25]

[0000106040-24-000014:mdna:26]
Second Quarter and First Half Overview

[0000106040-24-000014:mdna:27]
[same as prior period, unchanged from 0000106040-23-000034:mdna:27]

[0000106040-24-000014:mdna:28]
|  | Three Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 3,032 |  |  | 100.0 | % |  | $ | 3,107 |  |  | 100.0 | % |  | $ | (75) |  |  | (2) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,540 |  |  | 83.8 |  |  | 2,579 |  |  | 83.0 |  |  | (39) |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 492 |  |  | 16.2 |  |  | 528 |  |  | 17.0 |  |  | (36) |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 444 |  |  | 14.6 |  |  | 523 |  |  | 16.8 |  |  | (79) |  |  | (15) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 198 |  |  | 6.5 |  |  | 250 |  |  | 8.0 |  |  | (52) |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other | 24 |  |  | 0.8 |  |  | 76 |  |  | 2.4 |  |  | (52) |  |  | (68) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 36 |  |  | 1.2 |  |  | — |  |  | — |  |  | 36 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 702 |  |  | 23.2 |  |  | 849 |  |  | 27.3 |  |  | (147) |  |  | (17) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating loss | (210) |  |  | (6.9) |  |  | (321) |  |  | (10.3) |  |  | 111 |  |  | (35) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 12 |  |  | 0.4 |  |  | 3 |  |  | 0.1 |  |  | 9 |  |  | 300 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (108) |  |  | (3.6) |  |  | (73) |  |  | (2.3) |  |  | (35) |  |  | 48 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 47 |  |  | 1.6 |  |  | 10 |  |  | 0.3 |  |  | 37 |  |  | 370 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (49) |  |  | (1.6) |  |  | (60) |  |  | (1.9) |  |  | 11 |  |  | (18) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss before taxes | (259) |  |  | (8.5) |  |  | (381) |  |  | (12.3) |  |  | 122 |  |  | (32) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 28 |  |  | 0.9 |  |  | 70 |  |  | 2.3 |  |  | (42) |  |  | (60) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | (287) |  |  | (9.5) |  |  | (451) |  |  | (14.5) |  |  | 164 |  |  | (36) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 14 |  |  | 0.5 |  |  | — |  |  | — |  |  | 14 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to common shareholders | $ | (301) |  |  | (9.9) | % |  | $ | (451) |  |  | (14.5) | % |  | $ | 150 |  |  | (33) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-24-000014:mdna:29]
[same as prior period, unchanged from 0000106040-23-000034:mdna:29]

[0000106040-24-000014:mdna:30]
45

[0000106040-24-000014:mdna:31]
|  | Six Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 5,782 |  |  | 100.0 | % |  | $ | 6,843 |  |  | 100.0 | % |  | $ | (1,061) |  |  | (16) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 5,191 |  |  | 89.8 |  |  | 5,334 |  |  | 77.9 |  |  | (143) |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 591 |  |  | 10.2 |  |  | 1,509 |  |  | 22.1 |  |  | (918) |  |  | (61) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 875 |  |  | 15.1 |  |  | 1,075 |  |  | 15.7 |  |  | (200) |  |  | (19) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 405 |  |  | 7.0 |  |  | 497 |  |  | 7.3 |  |  | (92) |  |  | (19) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other | 81 |  |  | 1.4 |  |  | 100 |  |  | 1.5 |  |  | (19) |  |  | (19) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 36 |  |  | 0.6 |  |  | — |  |  | — |  |  | 36 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 1,397 |  |  | 24.2 |  |  | 1,672 |  |  | 24.4 |  |  | (275) |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating loss | (806) |  |  | (13.9) |  |  | (163) |  |  | (2.4) |  |  | (643) |  |  | 394 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 20 |  |  | 0.3 |  |  | 5 |  |  | 0.1 |  |  | 15 |  |  | 300 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (206) |  |  | (3.6) |  |  | (143) |  |  | (2.1) |  |  | (63) |  |  | 44 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 51 |  |  | 0.9 |  |  | 13 |  |  | 0.2 |  |  | 38 |  |  | 292 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (135) |  |  | (2.3) |  |  | (125) |  |  | (1.8) |  |  | (10) |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss before taxes | (941) |  |  | (16.3) |  |  | (288) |  |  | (4.2) |  |  | (653) |  |  | 227 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 31 |  |  | 0.5 |  |  | 116 |  |  | 1.7 |  |  | (85) |  |  | (73) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | (972) |  |  | (16.8) |  |  | (404) |  |  | (5.9) |  |  | (568) |  |  | 141 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 29 |  |  | 0.5 |  |  | — |  |  | — |  |  | 29 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to common shareholders | $ | (1,001) |  |  | (17.3) | % |  | $ | (404) |  |  | (5.9) | % |  | $ | (597) |  |  | 148 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-24-000014:mdna:32]
(1)    Percentages may not total due to rounding.

[0000106040-24-000014:mdna:33]
46

[0000106040-24-000014:mdna:34]
[same as prior period, unchanged from 0000106040-23-000034:mdna:30]

[0000106040-24-000014:mdna:35]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,665 |  |  | $ | 1,657 |  |  | $ | 3,221 |  |  | $ | 3,379 |  |
| HDD | 1,367 |  |  | 1,450 |  |  | 2,561 |  |  | 3,464 |  |
| Total net revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 131 |  |  | $ | 240 |  |  | $ | (30) |  |  | $ | 662 |  |
| HDD | 339 |  |  | 300 |  |  | 612 |  |  | 874 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (13) |  |  | (12) |  |  | (26) |  |  | (26) |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (1) |  |  | (1) |  |
| Recovery from contamination incident | 36 |  |  | — |  |  | 36 |  |  | — |  |
| Total unallocated corporate items | 22 |  |  | (12) |  |  | 9 |  |  | (27) |  |
| Consolidated gross profit | $ | 492 |  |  | $ | 528 |  |  | $ | 591 |  |  | $ | 1,509 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 7.9 | % |  | 14.5 | % |  | (0.9) | % |  | 19.6 | % |
| HDD | 24.8 | % |  | 20.7 | % |  | 23.9 | % |  | 25.2 | % |
| Consolidated gross margin | 16.2 | % |  | 17.0 | % |  | 10.2 | % |  | 22.1 | % |

[0000106040-24-000014:mdna:36]
[same as prior period, unchanged from 0000106040-23-000034:mdna:81]

[0000106040-24-000014:mdna:37]
[same as prior period, unchanged from 0000106040-23-000034:mdna:32]

[0000106040-24-000014:mdna:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,071 |  |  | $ | 1,224 |  |  | $ | 1,943 |  |  | $ | 3,053 |  |
| Client | 1,122 |  |  | 1,089 |  |  | 2,269 |  |  | 2,318 |  |
| Consumer | 839 |  |  | 794 |  |  | 1,570 |  |  | 1,472 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,699 |  |  | $ | 1,494 |  |  | $ | 3,250 |  |  | $ | 3,180 |  |
| Americas | 804 |  |  | 1,090 |  |  | 1,466 |  |  | 2,513 |  |
| Europe, Middle East and Africa | 529 |  |  | 523 |  |  | 1,066 |  |  | 1,150 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |

[0000106040-24-000014:mdna:39]
[same as prior period, unchanged from 0000106040-23-000034:mdna:34]

[0000106040-24-000014:mdna:40]
Comparison of Three and Six Months Ended December 29, 2023 to Three and Six Months Ended December 30, 2022

[0000106040-24-000014:mdna:41]
The decrease in consolidated net revenue for the three and six months ended December 29, 2023 from the comparable period in the prior year reflected the current supply-demand imbalance and macroeconomic pressures described in the “Key Developments - Operational Update” section above.

[0000106040-24-000014:mdna:42]
Flash revenue was relatively flat for the three months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 21% increase in exabytes sold, offset by a 17% decline in average selling prices per gigabyte. The increase in exabytes sold was due to improved demand from our OEM customers in our Client end market and from all products across our Consumer end market. The decline in average selling prices per gigabyte was due to the supply-demand imbalance described in the “Key Developments - Operational Update” section above as well as a shift in product mix. Flash revenue decreased 5% for the six months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 29% decline in average selling prices per gigabyte, partially offset by a 34% increase in exabytes sold. The increase in exabytes sold and the decline in average selling prices per gigabyte were attributable to the same factors described above for the three-month period.

[0000106040-24-000014:mdna:43]
HDD revenue decreased 6% for the three months ended December 29, 2023 from the comparable period in the prior year, primarily as a result of an 8% decline in average selling prices per gigabyte, partially offset by a 2% increase in exabytes sold. The decline in average selling prices per gigabyte was due to a shift in the product mix to larger capacity drives. HDD revenue decreased 26% for the six months ended December 29, 2023 from the comparable period in the prior year primarily as a result of a 24% decrease in exabytes sold, which was driven by lower shipments to customers in our Cloud end market as they adjusted their production levels and right-sized their inventories and a 2% decline in average selling prices per gigabyte primarily attributable to a shift in product mix.

[0000106040-24-000014:mdna:44]
Cloud revenue decreased 13% for the three months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 17% decline in average selling prices per gigabyte, partially offset by a 5% increase in exabytes sold. The decline in average selling prices per gigabyte was primarily due to the decline in Flash pricing caused by the supply-demand imbalance described in the “Key Developments - Operational Update” section above. The increase in exabytes sold was driven by higher shipments of our HDD products, partially offset by lower Flash bit shipments. Cloud revenue decreased 36% for the six months ended December 29, 2023 from the comparable period in the prior year, which primarily reflected a 28% decrease in exabytes sold and an 11% decline in average selling prices per gigabyte attributable to the factors described in the “Key Developments - Operational Update” section above.

[0000106040-24-000014:mdna:45]
[same as prior period, unchanged from 0000106040-23-000034:mdna:95]

[0000106040-24-000014:mdna:46]
Client revenue increased 3% for the three months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 14% increase in exabytes sold, partially offset by a 10% decline in average selling prices per gigabyte. The increase in exabytes sold was primarily driven by SSD shipments into PC applications. The decline in average selling prices per gigabyte was primarily due to the decline in Flash pricing caused by the supply-demand imbalance described in the “Key Developments - Operational Update” section above. Client revenue decreased 2% for the six months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 28% increase in exabytes sold, partially offset by a 23% decline in average selling prices per gigabyte. The increase in exabytes sold and the decline in average selling prices per gigabyte were attributable to the same factors described above for the three-month period.

[0000106040-24-000014:mdna:47]
Consumer revenue increased 6% for the three months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 4% increase in average selling prices per gigabyte and 2% increase in exabytes sold. The increase in average selling prices per gigabyte was driven by more favorable product mix. The increase in exabytes sold was driven by improved demand across our products in Flash. Consumer revenue increased 7% for the six months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting a 13% increase in exabytes sold, partially offset by a 6% decline in average selling prices per gigabyte. The increase in exabytes sold was primarily driven by improved demand across our products in Flash. The decline in average selling prices per gigabyte was primarily due to the decline in Flash pricing caused by the supply-demand imbalance described in the “Key Developments - Operational Update” section above

[0000106040-24-000014:mdna:48]
The changes in net revenue by geography for the three and six months ended December 29, 2023 from the comparable period in the prior year reflected higher revenue in the Asia region from Cloud customers, particularly in China and a decline in the Americas as certain large customers reduced purchases to align their inventories with current market demand.

[0000106040-24-000014:mdna:49]
Our top 10 customers accounted for 39% of our net revenue for the three months ended December 29, 2023, compared to 47% of our net revenue for the three months ended December 30, 2022. Our top 10 customers accounted for 39% of our net revenue for the six months ended December 29, 2023, compared to 48% of our net revenue for the six months ended December 30, 2022. For each of the three and six months ended December 29, 2023 and December 30, 2022, no single customer accounted for 10% or more of our net revenue.

[0000106040-24-000014:mdna:50]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 18% and 19% of gross revenue for the three and six months ended December 29, 2023, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-24-000014:mdna:51]
[same as prior period, unchanged from 0000106040-23-000034:mdna:109]

[0000106040-24-000014:mdna:52]
[same as prior period, unchanged from 0000106040-23-000034:mdna:43]

[0000106040-24-000014:mdna:53]
Consolidated gross profit decreased by $36 million for the three months ended December 29, 2023 from the comparable period in the prior year, which primarily reflected charges of approximately $156 million ($107 million in Flash and $49 million in HDD) for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity, partially offset by a $36 million recovery from insurance carriers recognized in the current year period related to a contamination incident that occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan in 2022, compared to $100 million of such charges in the same period in the prior year (all in HDD). Consolidated gross margin decreased 1 percentage point for the three months ended December 29, 2023, compared to the same period in the prior year, due to the net charges noted above. Flash gross margin decreased by approximately 7 percentage points year over year, with approximately 3 percentage points of the decline due to the higher net charges in Flash in the current period as noted above and the remainder driven by the lower average selling prices per gigabyte. HDD gross margin increased by 4 percentage points year over year, which primarily reflected the higher net charges in HDD in the current period as noted above.

[0000106040-24-000014:mdna:54]
Consolidated gross profit decreased by $918 million for the six months ended December 29, 2023 from the comparable period in the prior year, which primarily reflected the decrease in revenue described above as well as charges of approximately $381 million ($249 million in Flash and $132 million in HDD) for unabsorbed manufacturing overhead costs, partially offset by the $36 million recovery from the contamination incident noted above, recognized in the current period compared to $100 million of such charges in the same period in the prior year (all in HDD). Consolidated gross margin decreased 12 percentage points for the six months ended December 29, 2023 from the comparable period in the prior year, with approximately 5 percentage points of the decline due to the higher net charges in the current period as noted above and the remainder primarily driven by the lower average selling prices per gigabyte in Flash. Flash gross margin decreased by approximately 21 percentage points year over year, with approximately 8 percentage points of the decline due to the higher net charges in Flash in the current period as noted above and the remainder driven by the lower average selling prices per gigabyte. HDD gross margin decreased by 1 percentage point year over year due to the higher net charges in HDD in the current period as noted above.

[0000106040-24-000014:mdna:55]
[same as prior period, unchanged from 0000106040-23-000034:mdna:45]

[0000106040-24-000014:mdna:56]
Research and development (“R&D”) expense decreased $79 million for the three months ended December 29, 2023 from the comparable period in the prior year. The decline was primarily driven by a $40 million decrease in compensation and benefits due to lower headcount and a $25 million decrease due to lower depreciation expenses and reductions in R&D project spending as well as other savings as we took actions to reduce expenses in the current environment. R&D expense decreased $200 million for the six months ended December 29, 2023 from the comparable period in the prior year. The decline was primarily driven by a $110 million decrease in compensation and benefits due to lower headcount, and a $73 million decrease due to lower depreciation expenses and reductions in R&D project spending as well as other savings as we took actions to reduce expenses in the current environment.

[0000106040-24-000014:mdna:57]
Selling, general and administrative (“SG&A”) expense decreased $52 million for the three months ended December 29, 2023 from the comparable period in the prior year. The decline was primarily driven by a $39 million decrease in intangible amortization expense as certain assets became fully amortized, a $17 million decrease in compensation and benefits due to lower headcount, and a $12 million decrease in professional services, partially offset by $20 million increase in strategic review costs. SG&A expense decreased $92 million for the six months ended December 29, 2023 from the comparable period in the prior year. The decline was primarily driven by a $77 million decrease in intangible amortization expense, a $36 million decrease in compensation and benefits due to lower headcount, and a $18 million decrease in professional services, partially offset by a $37 million increase in strategic review costs.

[0000106040-24-000014:mdna:58]
Employee termination, asset impairment and other decreased $52 million for the three months ended December 29, 2023 from the comparable period in the prior year, reflecting fewer restructuring actions taken in the current period. Employee termination, asset impairment and other decreased $19 million for the six months ended December 29, 2023 from the comparable period in the prior year. The decrease primarily reflected fewer restructuring actions taken and a gain on the sale-leaseback of our Milpitas, California facility, partially offset by higher contract termination charges and asset impairments caused by project cancellations. For information regarding Employee termination, asset impairment and other, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment, and Other of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000014:mdna:59]
Business separation costs were $36 million for the three and six months ended December 29, 2023, primarily reflecting $33 million of charges for stamp duty associated with establishing new legal entities to support the planned separation of our Flash and HDD businesses.

[0000106040-24-000014:mdna:60]
50

[0000106040-24-000014:mdna:61]
Interest and Other Expense

[0000106040-24-000014:mdna:62]
Total interest and other expense, net decreased $11 million for the three months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting higher other income, net, of $37 million, driven by a gain on our strategic investments, and higher interest income of $9 million due to higher interest rates, partially offset by $35 million of higher interest expense resulting from increases in interest rates and the higher outstanding debt balance. Total interest and other expense, net increased $10 million for the six months ended December 29, 2023 from the comparable period in the prior year, primarily reflecting $63 million of higher interest expense resulting from increases in interest rates and the higher outstanding debt balance, partially offset by higher other income, net, of $38 million, driven by a net gain on our strategic investments and $15 million of higher interest income due to higher interest rates.

[0000106040-24-000014:mdna:63]
[same as prior period, unchanged from 0000106040-23-000034:mdna:51]

[0000106040-24-000014:mdna:64]
[same as prior period, unchanged from 0000106040-23-000034:mdna:52]

[0000106040-24-000014:mdna:65]
[same as prior period, unchanged from 0000106040-23-000034:mdna:53]

[0000106040-24-000014:mdna:66]
[same as prior period, unchanged from 0000106040-23-000034:mdna:54]

[0000106040-24-000014:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | $ in millions |
| Loss before taxes | $ | (259) |  |  | $ | (381) |  |  | $ | (941) |  |  | $ | (288) |  |
| Income tax expense | 28 |  |  | 70 |  |  | 31 |  |  | 116 |  |
| Effective tax rate | (11) | % |  | (18 | %) |  | (3) | % |  | (40 | %) |

[0000106040-24-000014:mdna:68]
Beginning in 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and six months ended December 29, 2023, but did not have a material impact on our effective tax rate. The primary drivers of the difference between the effective tax rate for the three and six months ended December 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during fiscal years 2024 through 2031. On November 1, 2023, one of our tax holidays in Malaysia expired. We have applied for an extension and anticipate it will apply retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, we are applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, we will make an adjustment to our effective tax rate in that period. The effective tax rate for the six months ended December 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000014:mdna:69]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 30, 2022 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-24-000014:mdna:70]
51

[0000106040-24-000014:mdna:71]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for the three and six months ended December 29, 2023, but did not have a material impact on the effective tax rate in those periods due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-24-000014:mdna:72]
[same as prior period, unchanged from 0000106040-23-000034:mdna:59]

[0000106040-24-000014:mdna:73]
[same as prior period, unchanged from 0000106040-23-000034:mdna:60]

[0000106040-24-000014:mdna:74]
[same as prior period, unchanged from 0000106040-23-000034:mdna:61]

[0000106040-24-000014:mdna:75]
|  | Six Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (718) |  |  | $ | 41 |  |  |  |
| Investing activities | 24 |  |  | (482) |  |  |  |
| Financing activities | 1,151 |  |  | (12) |  |  |  |
| Effect of exchange rate changes on cash | 1 |  |  | (3) |  |  |  |
| Net increase (decrease) in cash and cash equivalents | $ | 458 |  |  | $ | (456) |  |  |  |

[0000106040-24-000014:mdna:76]
We reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 29, 2023, the Company made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $187 million as of December 29, 2023, related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000014:mdna:77]
[same as prior period, unchanged from 0000106040-23-000034:mdna:64]

[0000106040-24-000014:mdna:78]
[same as prior period, unchanged from 0000106040-23-000034:mdna:65]

[0000106040-24-000014:mdna:79]
[same as prior period, unchanged from 0000106040-23-000034:mdna:66]

[0000106040-24-000014:mdna:80]
We believe our Cash and cash equivalents and our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter, as we navigate the current market downturn before returning to profitable operations and positive cash flows when the market normalizes. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended June 30, 2023.

[0000106040-24-000014:mdna:81]
A total of $1.69 billion and $1.28 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of December 29, 2023 and June 30, 2023, respectively. There are no material tax consequences that have not been accrued for on the repatriation of this cash.

[0000106040-24-000014:mdna:82]
[same as prior period, unchanged from 0000106040-23-000034:mdna:69]

[0000106040-24-000014:mdna:83]
[same as prior period, unchanged from 0000106040-23-000034:mdna:70]

[0000106040-24-000014:mdna:84]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $102 million for the six months ended December 29, 2023, as compared to $255 million for the six months ended December 30, 2022, which largely reflects the reduction in operating assets resulting from the reduction in volume of our business, partially offset by payments made on the IRS matter, as discussed above. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as the timing of payments for taxes. During the six months ended December 29, 2023, the change in operating assets and liabilities included payments to the IRS of $523 million, including interest, as discussed in “Short- and Long-term Liquidity - Unrecognized Tax Benefits” section below. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-24-000014:mdna:85]
|  | Three Months Ended |  |  |
|  | December 29,2023 |  | December 30,2022 |  |  |  |  |
| Days sales outstanding | 46 |  |  | 56 |  |  |  |  |  |
| Days in inventory | 115 |  |  | 133 |  |  |  |  |  |
| Days payable outstanding | (63) |  |  | (55) |  |  |  |  |  |
| Cash conversion cycle | 98 |  |  | 134 |  |  |  |  |  |

[0000106040-24-000014:mdna:86]
[same as prior period, unchanged from 0000106040-23-000034:mdna:73]

[0000106040-24-000014:mdna:87]
For the three months ended December 29, 2023, DSO decreased by 10 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO decreased by 18 days from the comparable period in the prior year, primarily reflecting lower production volumes, lower inventory cycle time which reduces the inventory levels we need to maintain to meet customer orders, and an increase in products shipped. DPO decreased by 8 days from the comparable period in the prior year primarily due to routine variations in the timing of purchases and payments during the period as well as slightly more favorable payment terms.

[0000106040-24-000014:mdna:88]
[same as prior period, unchanged from 0000106040-23-000034:mdna:75]

[0000106040-24-000014:mdna:89]
Net cash provided by investing activities for the six months ended December 29, 2023 primarily consisted of $79 million in proceeds from net activity related to Flash Ventures and $26 million of proceeds from net activity related to strategic investments, partially offset by $81 million in capital expenditures, net of proceeds from disposals of assets, which includes the proceeds from the sale-leaseback of our Milpitas, California facility. Net cash used in investing activities for the six months ended December 30, 2022 primarily consisted of $578 million in capital expenditures, partially offset by $82 million in proceeds from net activity related to Flash Ventures.

[0000106040-24-000014:mdna:90]
[same as prior period, unchanged from 0000106040-23-000034:mdna:77]

[0000106040-24-000014:mdna:91]
During the six months ended December 29, 2023, net cash provided by financing activities primarily consisted of $2.20 billion in proceeds from issuance of the 2028 Convertible Notes and the drawdown of the Delayed Draw Term Loan, partially offset by $505 million used to repurchase a portion of the 2024 Convertible Notes, and $338 million in repayments of the Delayed Draw Term Loan and Term Loan A-2 maturing 2027, and $155 million for the purchase of capped calls to hedge the potential dilution impact of the conversion feature of the 2028 Convertible Notes. During the six months ended December 30, 2022 cash flows from financing activities primarily consisted of $55 million used for taxes paid on vested stock awards under employee stock plans, partially offset by $48 million from the issuance of stock under employee stock plans. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the prior year period.

[0000106040-24-000014:mdna:92]
54

[0000106040-24-000014:mdna:93]
[same as prior period, unchanged from 0000106040-23-000034:mdna:79]

[0000106040-24-000014:mdna:94]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity - Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000014:mdna:95]
[same as prior period, unchanged from 0000106040-23-000034:mdna:82]

[0000106040-24-000014:mdna:96]
[same as prior period, unchanged from 0000106040-23-000034:mdna:83]

[0000106040-24-000014:mdna:97]
In addition to cash requirements for unrecognized tax benefits and dividend rights with respect to the Series A Preferred Stock discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of December 29, 2023:

[0000106040-24-000014:mdna:98]
|  | Total |  | 1 Year (Remaining Six Months of 2024) |  | 2-3 Years (2025-2026) |  | 4-5 Years (2027-2028) |  | More than 5 Years (Beyond 2028) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 8,454 |  |  | $ | 967 |  |  | $ | 2,600 |  |  | $ | 3,887 |  |  | $ | 1,000 |  |
| Interest on debt | 1,281 |  |  | 207 |  |  | 735 |  |  | 239 |  |  | 100 |  |
| Flash Ventures related commitments(2) | 3,928 |  |  | 1,096 |  |  | 2,078 |  |  | 704 |  |  | 50 |  |
| Operating leases | 610 |  |  | 34 |  |  | 135 |  |  | 111 |  |  | 330 |  |
| Purchase obligations and other commitments | 687 |  |  | 148 |  |  | 340 |  |  | 69 |  |  | 130 |  |
| Mandatory deemed repatriation tax | 464 |  |  | — |  |  | 464 |  |  | — |  |  | — |  |
| Total | $ | 15,424 |  |  | $ | 2,452 |  |  | $ | 6,352 |  |  | $ | 5,010 |  |  | $ | 1,610 |  |

[0000106040-24-000014:mdna:99]
(1)Principal portion of debt, excluding issuance costs. Includes the 2024 Convertible Notes that remained outstanding as of December 29, 2023 but which we settled in full on February 1, 2024. See “Key Developments - Financing Activities” section above.

[0000106040-24-000014:mdna:100]
[same as prior period, unchanged from 0000106040-23-000034:mdna:87]

[0000106040-24-000014:mdna:101]
[same as prior period, unchanged from 0000106040-23-000034:mdna:88]

[0000106040-24-000014:mdna:102]
On January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. These shares are entitled to cumulative preferred dividends. See Part II, Item 8, Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended June 30, 2023 and Part I, Item 1, Note 11, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0000106040-24-000014:mdna:103]
[same as prior period, unchanged from 0000106040-23-000034:mdna:90]

[0000106040-24-000014:mdna:104]
As described in “Key Developments - Financing Activities” above, we undertook several liability-management actions during the quarter, including the issuance of the 2028 Convertible Notes, the partial repurchase of our 2024 Convertible Notes and the partial repayment of the Delayed Term Loan. In addition, on February 1, 2024, we settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-24-000014:mdna:105]
In addition to our existing debt, as of December 29, 2023, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 30, 2023 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-24-000014:mdna:106]
The loan agreements governing our revolving credit facility, our Term Loan A-2 maturing 2027, and our Delayed Draw Term Loan require us to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of December 29, 2023, we were in compliance with these financial covenants.

[0000106040-24-000014:mdna:107]
56

[0000106040-24-000014:mdna:108]
[same as prior period, unchanged from 0000106040-23-000034:mdna:93]

[0000106040-24-000014:mdna:109]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of December 29, 2023, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-24-000014:mdna:110]
[same as prior period, unchanged from 0000106040-23-000034:mdna:96]

[0000106040-24-000014:mdna:111]
[same as prior period, unchanged from 0000106040-23-000034:mdna:97]

[0000106040-24-000014:mdna:112]
[same as prior period, unchanged from 0000106040-23-000034:mdna:98]

[0000106040-24-000014:mdna:113]
[same as prior period, unchanged from 0000106040-23-000034:mdna:99]

[0000106040-24-000014:mdna:114]
|  |  | December 29,2023 |
|  |  | (in millions) |
| 2025 |  | $ | 265 |  |
| 2026 |  | 199 |  |
| Total |  | $ | 464 |  |

[0000106040-24-000014:mdna:115]
[same as prior period, unchanged from 0000106040-23-000034:mdna:101]

[0000106040-24-000014:mdna:116]
As of December 29, 2023, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $677 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of December 29, 2023 was $161 million. Of these amounts, approximately $671 million could result in potential cash payments.

[0000106040-24-000014:mdna:117]
As noted above, we reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the six months ended December 29, 2023, we made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $187 million as of December 29, 2023 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000014:mdna:118]
[same as prior period, unchanged from 0000106040-23-000034:mdna:104]

[0000106040-24-000014:mdna:119]
[same as prior period, unchanged from 0000106040-23-000034:mdna:105]

[0000106040-24-000014:mdna:120]
Since the beginning of 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments in future profitable periods, if not repealed or otherwise modified.

[0000106040-24-000014:mdna:121]
[same as prior period, unchanged from 0000106040-23-000034:mdna:107]

[0000106040-24-000014:mdna:122]
[same as prior period, unchanged from 0000106040-23-000034:mdna:108]

[0000106040-24-000014:mdna:123]
[same as prior period, unchanged from 0000106040-23-000034:mdna:110]

[0000106040-24-000014:mdna:124]
[same as prior period, unchanged from 0000106040-23-000034:mdna:111]

[0000106040-24-000014:mdna:125]
[same as prior period, unchanged from 0000106040-23-000034:mdna:112]

[0000106040-24-000014:mdna:126]
[same as prior period, unchanged from 0000106040-23-000034:mdna:113]

[0000106040-24-000014:mdna:127]
[same as prior period, unchanged from 0000106040-23-000034:mdna:114]

[0000106040-24-000014:mdna:128]
[same as prior period, unchanged from 0000106040-23-000034:mdna:115]

[0000106040-24-000014:mdna:129]
[same as prior period, unchanged from 0000106040-23-000034:mdna:116]

[0000106040-24-000014:mdna:130]
[same as prior period, unchanged from 0000106040-23-000034:mdna:117]
