# WDC MD&A — 0000106040-17-000027


## mdna

[0000106040-17-000027:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Conditions and Results of Operations |

[0000106040-17-000027:mdna:2]
Our Company

[0000106040-17-000027:mdna:3]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. Our broad portfolio of technology and products address the following key markets: Data Center Devices and Solutions; Client Devices; and Client Solutions. We also generate license and royalty revenue related to our IP, which is included in each of the three categories.

[0000106040-17-000027:mdna:4]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Fiscal years 2017 and 2016, which ended on June 30, 2017 and July 1, 2016, respectively, both comprised 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2015, which ended on July 3, 2015, comprised 53 weeks, with the first quarter consisting of 14 weeks and the second, third and fourth quarters consisting of 13 weeks each.

[0000106040-17-000027:mdna:5]
Key Developments

[0000106040-17-000027:mdna:6]
Acquisition of SanDisk

[0000106040-17-000027:mdna:7]
On May 12, 2016 (the “SanDisk Closing Date”), we completed the acquisition of SanDisk (the “Merger”), a global leader in NAND-flash storage solutions, pursuant to the terms of the Agreement and Plan of Merger, dated October 21, 2015. The Merger is primarily intended to deepen our expertise in non-volatile memory and enable us to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost. The aggregate purchase price of the Merger was $15.59 billion. This acquisition broadened our product portfolio, significantly increased our revenues in 2017 and enhanced our gross margins. Operating expenses also increased with the assumption of the SanDisk operations. For additional information on the acquisition, see Part II, Item 8, Note 15, Acquisitions, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:8]
Debt Facilities

[0000106040-17-000027:mdna:9]
In connection with the Merger, we entered into new debt facilities aggregating approximately $18.09 billion in principal to finance a portion of the purchase price related to the Merger. The proceeds were also used to refinance certain existing indebtedness of Western Digital and SanDisk, and pay certain transaction costs. This new debt significantly increased our interest expense in 2017. During 2017, we repaid a $3.00 billion short-term bridge loan, made a voluntary $750 million principal payment on one of the term loans and entered into several repricing transactions that significantly lowered the rate of interest on some of the new term loans. We also settled a substantial portion of the remaining assumed SanDisk convertible notes. The reductions in principal and the repricing transactions are expected to lower our interest expense going forward compared to 2017. For additional information, see Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:10]
Ventures with Toshiba

[0000106040-17-000027:mdna:11]
Through Flash Ventures, we and Toshiba currently operate three business ventures in 300-millimeter NAND-flash manufacturing facilities in Yokkaichi, Japan, which provide us leading-edge, cost-competitive NAND wafers for our end products. Toshiba has announced significant losses related to its U.S. nuclear business and substantial doubt about its ability to continue as a going concern. Due to Toshiba’s financial condition, Toshiba’s working capital and access to credit and capital markets are severely limited. Toshiba could become unable to, or otherwise fail to, timely fund investments in Flash Ventures or our joint development efforts or fulfill its payment obligations to suppliers, which could harm Flash Ventures’ operations, our joint technology roadmap and supplier relationships. We are committed to the success of Flash Ventures and we intend to, and have been engaged in discussions with Toshiba to, jointly invest in Fab 6 equipment with Toshiba. See Part I, Item I, Business: Ventures with Toshiba, for additional information. For a discussion of risks associated with our business ventures with Toshiba, see Part I, Item 1A, Risk Factors, of this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:12]
46

[0000106040-17-000027:mdna:13]
Results of Operations

[0000106040-17-000027:mdna:14]
Summary Comparison of 2017, 2016 and 2015

[0000106040-17-000027:mdna:15]
The following table sets forth, for the periods presented, selected summary information from our consolidated statements of operations by dollars and percentage of net revenue:

[0000106040-17-000027:mdna:16]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except percentages) |
| Revenue, net | $ | 19,093 |  |  | 100.0 | % |  | $ | 12,994 |  |  | 100.0 | % |  | $ | 14,572 |  |  | 100.0 | % |
| Cost of revenue | 13,021 |  |  | 68.2 |  |  | 9,559 |  |  | 73.6 |  |  | 10,351 |  |  | 71.0 |  |
| Gross profit | 6,072 |  |  | 31.8 |  |  | 3,435 |  |  | 26.4 |  |  | 4,221 |  |  | 29.0 |  |
| Operating expenses | 4,118 |  |  | 21.6 |  |  | 2,969 |  |  | 22.8 |  |  | 2,610 |  |  | 17.9 |  |
| Operating income | 1,954 |  |  | 10.2 |  |  | 466 |  |  | 3.6 |  |  | 1,611 |  |  | 11.1 |  |
| Total interest and other expense, net | (1,185 | ) |  | (6.2 | ) |  | (313 | ) |  | (2.4 | ) |  | (34 | ) |  | (0.2 | ) |
| Income before taxes | 769 |  |  | 4.0 |  |  | 153 |  |  | 1.2 |  |  | 1,577 |  |  | 10.8 |  |
| Income tax expense (benefit) | 372 |  |  | 1.9 |  |  | (89 | ) |  | (0.7 | ) |  | 112 |  |  | 0.8 |  |
| Net income | $ | 397 |  |  | 2.1 |  |  | $ | 242 |  |  | 1.9 |  |  | $ | 1,465 |  |  | 10.1 |  |

[0000106040-17-000027:mdna:17]
The following table sets forth, for the periods presented, summary information regarding net revenues by geography and end market:

[0000106040-17-000027:mdna:18]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 19,093 |  |  | $ | 12,994 |  |  | $ | 14,572 |  |
| Revenues by Geography (%) |  |  |  |  |  |
| Americas | 27 | % |  | 32 | % |  | 28 | % |
| Europe, Middle East and Africa | 17 |  |  | 21 |  |  | 22 |  |
| Asia | 56 |  |  | 47 |  |  | 50 |  |
| Revenues by End Market (%) |  |  |  |  |  |
| Client Devices | 50 | % |  | 48 | % |  | 53 | % |
| Data Center Devices & Solutions | 29 |  |  | 38 |  |  | 34 |  |
| Client Solutions | 21 |  |  | 14 |  |  | 13 |  |
| Exabytes Shipped | 313 |  |  | 262 |  |  | 249 |  |

[0000106040-17-000027:mdna:19]
For 2017 and 2016, no customer accounted for 10% or more of our net revenue. For 2015, one customer, Hewlett-Packard Company, accounted for 11% of our net revenue. For 2017, 2016 and 2015, our top 10 customers accounted for 36%, 43% and 44%, of our net revenue, respectively.

[0000106040-17-000027:mdna:20]
Fiscal Year 2017 Net Revenue and Gross Margin Compared to Fiscal Year 2016 Net Revenue and Gross Margin

[0000106040-17-000027:mdna:21]
Net Revenue. Net revenue was $19.09 billion for 2017, an increase of $6.10 billion, or 47%, as compared to 2016, primarily due to a full year of revenue from the sale of NAND-flash products following the SanDisk Closing Date, compared to a partial year of such revenue in the prior year. This increase was partially offset by lower revenue related to lower PC and enterprise HDD shipments.

[0000106040-17-000027:mdna:22]
47

[0000106040-17-000027:mdna:23]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2017 and 2016, these programs represented 12% and 13% of gross revenues, respectively. The decrease in sales incentive and marketing programs year-over-year reflects lower incentive programs offered on NAND-flash products as a result of the Merger. The amounts attributed to our sales incentive and marketing programs also generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-17-000027:mdna:24]
Net Revenue by Geography. Changes in the mix of net revenue by geography for 2017, as compared to 2016, reflect the additional revenues from the Merger which has comparatively higher revenue in Asia than our pre-acquisition business.

[0000106040-17-000027:mdna:25]
Net Revenue by End Market. Our end markets include Data Center Devices and Solutions (capacity and performance enterprise HDD, enterprise SSD, data center software and system solutions); Client Devices (mobile, desktop, gaming and digital video hard drives, client SSDs, embedded products and wafers); and Client Solutions (removable products, hard drive content solutions and flash content solutions).

[0000106040-17-000027:mdna:26]
Changes in the mix of net revenue by end market for 2017, as compared to 2016, reflect the full year increase in revenues from the Merger which has comparatively higher revenue in Client Devices and Client Solutions than our pre-acquisition business.

[0000106040-17-000027:mdna:27]
Gross Profit and Gross Margin. Gross profit was $6.07 billion for 2017, an increase of $2.64 billion, or 77%, as compared to 2016, largely driven by the increase in revenue mentioned above. Gross profit for 2017 was negatively impacted by amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, stock-based compensation and acquisition related charges, which aggregated $1.14 billion, or 6.0% of revenue, for 2017, and $375 million, or 2.9% of revenue, for 2016. Gross margin increased to 31.8% for 2017, as compared to 26.4% for 2016. The increase in gross margin was primarily due to sales of NAND-flash products following the SanDisk Closing Date, as such products have comparatively higher gross margins than our pre-acquisition products, cost improvements across all products driven by manufacturing integration activities and cost improvements as NAND-flash technology transitions to more cost efficient designs.

[0000106040-17-000027:mdna:28]
Fiscal Year 2016 Net Revenue and Gross Margin Compared to Fiscal Year 2015 Net Revenue and Gross Margin

[0000106040-17-000027:mdna:29]
Net Revenue. Net revenue was $12.99 billion for 2016, a decrease of $1.58 billion, or 11%, as compared to 2015, primarily due to lower HDD unit shipments partially offset by an increase in HDD ASPs and partial year revenues from SanDisk of $793 million following the SanDisk Closing Date. The decrease in HDD unit shipments was primarily due to a softer demand environment. The increase in HDD ASPs was primarily due to a change in HDD product mix.

[0000106040-17-000027:mdna:30]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2016 and 2015, these programs represented 13% and 10% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-17-000027:mdna:31]
Net Revenue by Geography. Changes in the mix of net revenue by geography for 2016, as compared to 2015, reflect a decrease in Asia primarily due to reduced demand of client HDD shipments as a result of a decline in the desktop and notebook PC market and a decrease in Europe, Middle East and Africa due to lower demand for our client and retail HDD products primarily due to the continued decline of PC-related after-market sales.

[0000106040-17-000027:mdna:32]
Net Revenue by End Market. Changes in the mix of net revenue by end market for 2016, as compared to 2015, reflected lower Client Devices revenues primarily due to reduced demand for HDDs as a result of a decline in desktop and notebook PC market, partially offset by a partial year increase in revenues from the Merger, which has comparatively higher revenue in Client Devices and Client Solutions than our pre-acquisition business.

[0000106040-17-000027:mdna:33]
48

[0000106040-17-000027:mdna:34]
Gross Profit and Gross Margin. Gross profit was $3.44 billion for 2016, a decrease of $786 million, or 19%, from 2015. Gross margin decreased to 26.4% in 2016, as compared to 29.0% in 2015. This decrease was primarily the result of lower HDD unit sales and the related absorption impact, and accelerated depreciation on assets related to both the closure of the Odawara, Japan facility and the restructuring plan (“Restructuring Plan 2016”) associated with the integration of substantial portions of our HGST and WD subsidiaries. This decrease in gross profit was partially offset by SanDisk’s gross profit following the SanDisk Closing Date.

[0000106040-17-000027:mdna:35]
Operating Expense

[0000106040-17-000027:mdna:36]
The following table sets forth operating expense information from our Consolidated Statement of Operations by dollar and percentage(1) of net revenue.

[0000106040-17-000027:mdna:37]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except percentages) |
| Research and development | $ | 2,441 |  |  | 12.8 | % |  | $ | 1,627 |  |  | 12.5 | % |  | $ | 1,646 |  |  | 11.3 | % |
| Selling, general and administrative | 1,445 |  |  | 7.6 |  |  | 997 |  |  | 7.7 |  |  | 788 |  |  | 5.4 |  |
| Employee termination, asset impairment, and other charges | 232 |  |  | 1.2 |  |  | 345 |  |  | 2.6 |  |  | 176 |  |  | 1.2 |  |
| Total operating expenses | $ | 4,118 |  |  | 21.6 |  |  | $ | 2,969 |  |  | 22.8 |  |  | $ | 2,610 |  |  | 17.9 |  |

[0000106040-17-000027:mdna:38]
| (1) | Percentages may not total due to rounding. |

[0000106040-17-000027:mdna:39]
Fiscal Year 2017 Operating Expenses Compared to Fiscal Year 2016 Operating Expenses

[0000106040-17-000027:mdna:40]
Research and development (“R&D”) expense was $2.44 billion in 2017, an increase of $814 million, or 50%, from 2016, primarily due to the Merger and continued development of NAND-flash technology. Fiscal year 2017 also included aggregate charges of $199 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $106 million in 2016 related to such charges.

[0000106040-17-000027:mdna:41]
Selling, general and administrative (“SG&A”) expense was $1.45 billion in 2017, an increase of $448 million, or 45%, from 2016, primarily due to the Merger. Fiscal year 2017 also included aggregate charges of $404 million, related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $379 million in 2016 related to such charges.

[0000106040-17-000027:mdna:42]
Employee termination and other charges were $232 million in 2017, a decrease of $113 million, or 33%, from 2016. These charges in 2017 primarily related to further actions under the Restructuring Plan 2016 associated with the integration and business realignment of substantial portions of our business. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 16, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:43]
Fiscal Year 2016 Operating Expenses Compared to Fiscal Year 2015 Operating Expenses

[0000106040-17-000027:mdna:44]
R&D expense was $1.63 billion in 2016, a decrease of $19 million, or 1%, from 2015. This slight decrease was primarily due to reductions in employee compensation expenses due to a reduction in headcount as a result of our business realignment initiatives, reduction in material spend due to the consolidation of our product roadmap in relation to the integration of our HGST and WD subsidiaries and an additional week in the prior year. These decreases were partially offset by SanDisk’s R&D expenses following the SanDisk Closing Date and expenses related to the integration of our HGST and WD subsidiaries.

[0000106040-17-000027:mdna:45]
SG&A expense was $997 million in 2016, an increase of $209 million, or 27%, from 2015. This increase was primarily due to SanDisk’s SG&A expenses following the SanDisk Closing Date, acquisition charges and expenses related to the integration of our HGST and WD subsidiaries. These charges were partially offset by a reduction in employee compensation expenses due to a reduction in headcount as a result of our business realignment initiatives and an additional week in the prior year.

[0000106040-17-000027:mdna:46]
Employee termination, asset impairment and other charges was $345 million in 2016, an increase of $169 million, or 96%, from 2015 as we implemented our Restructuring Plan 2016 and initiated the closure of our hard component front-end wafer manufacturing facility in Odawara, Japan. For additional information, see Part II, Item 8, Note 16, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:47]
49

[0000106040-17-000027:mdna:48]
.

[0000106040-17-000027:mdna:49]
Interest and Other Income (Expense)

[0000106040-17-000027:mdna:50]
The following table sets forth interest and other income (expense) information from our Consolidated Statement of Operations by dollar and percentage(1) of net revenue.

[0000106040-17-000027:mdna:51]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except percentages) |
| Interest income | $ | 26 |  |  | 0.1 | % |  | $ | 26 |  |  | 0.2 | % |  | $ | 14 |  |  | 0.1 | % |
| Interest expense | (847 | ) |  | (4.4 | ) |  | (266 | ) |  | (2.0 | ) |  | (49 | ) |  | (0.3 | ) |
| Other income (expense), net | (364 | ) |  | (1.9 | ) |  | (73 | ) |  | (0.6 | ) |  | 1 |  |  | — |  |
| Total interest and other expense, net | $ | (1,185 | ) |  | (6.2 | ) |  | $ | (313 | ) |  | (2.4 | ) |  | $ | (34 | ) |  | (0.2 | ) |

[0000106040-17-000027:mdna:52]
| (1) | Percentages may not total due to rounding. |

[0000106040-17-000027:mdna:53]
Fiscal Year 2017 Interest and Other Expense, Net Compared to Fiscal Year 2016 Interest and Other Expense, Net

[0000106040-17-000027:mdna:54]
Total interest and other expense, net increased $872 million in 2017, primarily due to a full year of interest expense in 2017 resulting from the additional debt issued in connection with the Merger compared to only a partial year of such expense in 2016, as well as losses on the settlements of certain of our term loans (see Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K) and impairment charges related to our cost-method investments.

[0000106040-17-000027:mdna:55]
Fiscal Year 2016 Interest and Other Income (Expense) Compared to Fiscal Year 2015 Interest and Other Income (Expense)

[0000106040-17-000027:mdna:56]
In 2016, Total interest and other expense, net increased $279 million over 2015, primarily due to interest expense resulting from the additional debt incurred in connection with the Merger, the loss on the settlement of convertible debt and write-off of debt issuance costs on settlement of other previously issued debt.

[0000106040-17-000027:mdna:57]
50

[0000106040-17-000027:mdna:58]
Income Tax Expense (Benefit)

[0000106040-17-000027:mdna:59]
The following table sets forth income tax information from our Consolidated Statement of Operations by dollar and effective tax rate.

[0000106040-17-000027:mdna:60]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except percentages) |
| Income tax expense (benefit) | $ | 372 |  |  | $ | (89 | ) |  | $ | 112 |  |
| Effective tax rate | 48 | % |  | (58 | )% |  | 7 | % |

[0000106040-17-000027:mdna:61]
Fiscal Year 2017 Income Tax Expense Compared to Fiscal Year 2016 Income Tax Benefit

[0000106040-17-000027:mdna:62]
Income tax expense was $372 million in 2017, as compared to an income tax benefit of $89 million in 2016. Income tax expense as a percentage of income before taxes was 48% in 2017, as compared to income tax benefit as a percentage of income before taxes of 58% in 2016. Income tax expense in 2017 reflects tax expense from the integration of SanDisk and a valuation allowance on both acquired tax attributes and net operating loss carryforwards from restructuring activities. The difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to taxes on the integration of SanDisk and an increase in the valuation allowance for both acquired tax attributes and net operating loss carryforwards from restructuring activities, which are partially offset by the current year generation of tax credits and foreign income taxed at lower tax rates due to tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates from 2018 through 2030.

[0000106040-17-000027:mdna:63]
The Internal Revenue Service (“IRS”) previously completed its field examination of our federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. We have received Revenue Agent Reports from the IRS that seek to increase our U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with our foreign subsidiaries and intercompany payable balances. We disagree with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. We believe that our tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of our fiscal years 2010 through 2012.

[0000106040-17-000027:mdna:64]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in our tax examinations are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of June 30, 2017, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-17-000027:mdna:65]
For additional information regarding income tax expense (benefit), see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:66]
Fiscal Year 2016 Income Tax Benefit Compared to Fiscal Year 2015 Income Tax Expense

[0000106040-17-000027:mdna:67]
Income tax benefit was $89 million in 2016, as compared to a $112 million expense in 2015. Tax benefit as a percentage of income before taxes was 58.2% in 2016, as compared to tax expense of 7.1% in 2015. Fiscal year 2016 income tax benefit reflects tax benefits from expenses related to the Merger and from interest expense related to new debt facilities. The difference between the effective tax rate and the U.S. Federal statutory rate is primarily due to foreign income taxed at lower tax rates due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029, the current year generation of income tax credits and the tax deductible expenses related to the Merger.

[0000106040-17-000027:mdna:68]
Liquidity and Capital Resources

[0000106040-17-000027:mdna:69]
The following table summarizes our statements of cash flows:

[0000106040-17-000027:mdna:70]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 3,437 |  |  | $ | 1,983 |  |  | $ | 2,242 |  |
| Investing activities | (636 | ) |  | (9,608 | ) |  | (953 | ) |
| Financing activities | (4,595 | ) |  | 10,751 |  |  | (1,069 | ) |
| Effect of exchange rate changes on cash | (3 | ) |  | 1 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | (1,797 | ) |  | $ | 3,127 |  |  | $ | 220 |  |

[0000106040-17-000027:mdna:71]
We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:72]
The indebtedness used to finance the Merger could cause us to place more reliance on cash generated from operations to pay principal and interest on our debt, thereby reducing the availability of our cash flow for working capital, capital expenditure needs, dividends, or to pursue other potential strategic plans.

[0000106040-17-000027:mdna:73]
During 2018, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to Flash Ventures to be approximately $1.5 billion to $1.9 billion of our cash. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-17-000027:mdna:74]
A total of $4.99 billion and $6.90 billion of our cash and cash equivalents was held outside of the U.S. as of June 30, 2017 and July 1, 2016, respectively. Our current plans anticipate we can meet our U.S. cash needs while continuing to permanently reinvest the undistributed earnings of our foreign subsidiaries. In the event the reinvested earnings of our foreign subsidiaries are distributed to the U.S., such a distribution could result in the accrual and payment of additional U.S. taxes.

[0000106040-17-000027:mdna:75]
Operating Activities

[0000106040-17-000027:mdna:76]
Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by changes in working capital was $91 million for 2017, as compared to net cash provided by changes in working capital of $374 million for 2016 and net cash used for changes in working capital of $593 million for 2015.

[0000106040-17-000027:mdna:77]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-17-000027:mdna:78]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in days) |
| Days sales outstanding | 37 |  | 41 |  | 39 |
| Days in inventory | 65 |  | 81 |  | 49 |
| Days payables outstanding | (66) |  | (78) |  | (67) |
| Cash conversion cycle | 36 |  | 44 |  | 21 |

[0000106040-17-000027:mdna:79]
Changes in days sales outstanding (“DSOs”) are generally due to the linearity of shipments. Changes in days in inventory (“DIOs”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPOs”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-17-000027:mdna:80]
The working capital metrics in 2016 were notably impacted by the inclusion of SanDisk’s accounts receivable, inventory and accounts payable balances as of July 1, 2016, but only including SanDisk’s revenue and cost of sales following the SanDisk Closing Date. The Merger inflated DSO, DIO and DPO by 12 days, 32 days and 14 days, respectively. Excluding the impact of the Merger in 2016, DSO in 2017 increased by 8 days over 2016 and was 2 days lower than 2015, primarily reflecting timing of customer receipts in the prior year. Excluding the impact of the Merger in 2016, DIO in 2017 increased by 16 days over both 2016 and 2015. The increase in DIO primarily reflects short-term build-up of inventory to maintain supply as we close certain facilities and transition production. Excluding the impact of the Merger in 2016, DPO in 2017 increased by 2 days over 2016 and decreased by 1 day from 2015, primarily reflecting routine variations in timing purchases and payments during the period.

[0000106040-17-000027:mdna:81]
Investing Activities

[0000106040-17-000027:mdna:82]
During 2017, net cash used in investing activities primarily consisted of $578 million of capital expenditures and a net $277 million increase in notes receivable to and investments in Flash Ventures, partially offset by cash provided by a net $230 million decrease in our investments in marketable securities. During 2016, net cash used in investing activities primarily consisted of $9.84 billion related to the Merger, net of cash acquired, $632 million related to the purchase of investments, $584 million of capital expenditures, $90 million net increase in notes receivable to Flash Ventures and a net $76 million of other investing activities, partially offset by $1.20 billion of proceeds from sales of investments and $405 million of proceeds from maturities of investments. During 2015, net cash used in investing activities primarily consisted of $857 million related to the purchase of investments, $612 million of capital expenditures and $257 million related to acquisitions, net of cash acquired, partially offset by $505 million of proceeds from sales of investments and $263 million of proceeds from maturities of investments.

[0000106040-17-000027:mdna:83]
Our cash equivalents are primarily invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-17-000027:mdna:84]
Financing Activities

[0000106040-17-000027:mdna:85]
During 2017, net cash used in financing activities primarily consisted of $11.70 billion to repay debt, $574 million to pay dividends on our common stock and $492 million to settle convertible debt, partially offset by $7.90 billion of proceeds from debt, net of issuance costs, a net $230 million provided by employee stock plans and $61 million of proceeds from call options. During 2016, net cash provided by financing activities consisted of $16.58 billion of proceeds from debt, net of issuance costs, $409 million of proceeds from call options, $125 million of proceeds from borrowings under our revolving credit facility and a net $74 million provided by employee stock plans, offset by a net $2.61 billion to settle convertible debt, $2.31 billion to repay debt, $613 million for payment upon settlement of warrants, $464 million to pay dividends on our common stock, $380 million to repay the revolving credit facility and $60 million to repurchase shares of our common stock. During 2015, net cash used in financing activities consisted of $970 million to repurchase shares of our common stock, $396 million to pay dividends on our common stock and $125 million to repay debt, partially offset by $255 million of proceeds from our revolving credit facility and a net $167 million provided by employee stock plans.

[0000106040-17-000027:mdna:86]
Off-Balance Sheet Arrangements

[0000106040-17-000027:mdna:87]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:88]
53

[0000106040-17-000027:mdna:89]
Short and Long-term Liquidity

[0000106040-17-000027:mdna:90]
Contractual Obligations and Commitments

[0000106040-17-000027:mdna:91]
The following is a summary of our known contractual cash obligations and commercial commitments as of June 30, 2017:

[0000106040-17-000027:mdna:92]
|  | Total |  | 1 Year (2018) |  | 2-3 Years (2019-2020) |  | 4-5 Years (2021-2022) |  | More than 5 Years (Beyond 2022) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 13,356 |  |  | $ | 246 |  |  | $ | 802 |  |  | $ | 3,312 |  |  | $ | 8,996 |  |
| Interest on debt | 4,467 |  |  | 769 |  |  | 1,513 |  |  | 1,347 |  |  | 838 |  |
| Flash Ventures and other related commitments(1) | 7,510 |  |  | 3,096 |  |  | 2,542 |  |  | 1,502 |  |  | 370 |  |
| Operating leases | 178 |  |  | 46 |  |  | 73 |  |  | 39 |  |  | 20 |  |
| Purchase obligations | 1,634 |  |  | 1,575 |  |  | 59 |  |  | — |  |  | — |  |
| Total | $ | 27,145 |  |  | $ | 5,732 |  |  | $ | 4,989 |  |  | $ | 6,200 |  |  | $ | 10,224 |  |

[0000106040-17-000027:mdna:93]
| (1) | Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and reimbursement for other committed expenses, including R&D. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments. |

[0000106040-17-000027:mdna:94]
Debt

[0000106040-17-000027:mdna:95]
See Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K for information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms.

[0000106040-17-000027:mdna:96]
Interest Rate Swap

[0000106040-17-000027:mdna:97]
We have entered into interest rate swap agreements to moderate our exposure to fluctuations in interest rates underlying our variable rate debt. For a description of our current interest rate swaps, see Part II, Item 7A, Quantitative and Qualitative Disclosures About Market Risk and Part II, Item 8, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:98]
Flash Ventures

[0000106040-17-000027:mdna:99]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of June 30, 2017, we were in compliance with all covenants under these Japanese lease facilities.

[0000106040-17-000027:mdna:100]
See Part II, Item 8, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K for information regarding Flash Ventures.

[0000106040-17-000027:mdna:101]
Foreign Exchange Contracts

[0000106040-17-000027:mdna:102]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 7A, Quantitative and Qualitative Disclosures About Market Risk and Part II, Item 8, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:103]
Indemnifications

[0000106040-17-000027:mdna:104]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-17-000027:mdna:105]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-17-000027:mdna:106]
Unrecognized Tax Benefits

[0000106040-17-000027:mdna:107]
As of June 30, 2017, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $611 million, of which $493 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:108]
Cash Dividend

[0000106040-17-000027:mdna:109]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On May 3, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of June 30, 2017. The cash dividend of $147 million was paid on July 17, 2017. On August 2, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of September 29, 2017. The cash dividend will be paid on October 16, 2017. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-17-000027:mdna:110]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-17-000027:mdna:111]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. We are currently evaluating the impact ASU 2017-07 will have on our Consolidated Financial Statements.

[0000106040-17-000027:mdna:112]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). ASU 2017-04 simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. The new standard is effective for goodwill impairment tests in fiscal years beginning after December 15, 2019, which for us is the first quarter of 2021. Early adoption is permitted for goodwill impairment tests performed after January 1, 2017. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-17-000027:mdna:113]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB Accounting Standards Codification (“ASC”) Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact ASU 2016-16 will have on our Consolidated Financial Statements.

[0000106040-17-000027:mdna:114]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). ASU 2016-15 addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which, among others, includes our disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2018. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-17-000027:mdna:115]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). ASU 2016-09 simplifies several aspects of the accounting for stock-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. We will adopt this standard in the first quarter of 2018 using the modified retrospective approach. This adoption will result in a one-time increase to beginning retained earnings for cumulative adjustments of $58 million for the unrecognized windfall tax benefits related to previous vesting and exercises of stock-based awards and $19 million related to the change in our accounting policy for estimated forfeitures and share cancellations. In addition, under the new standard, we will prospectively reflect the tax deficiencies and benefits as an operating activity, rather than as a financing activity under the previous standard, in our Consolidated Statements of Cash Flows.

[0000106040-17-000027:mdna:116]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. We expect to adopt this standard in the first quarter of 2020. We are currently evaluating the impact ASU 2016-02 will have on our Consolidated Financial Statements and related disclosures.

[0000106040-17-000027:mdna:117]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. We are currently evaluating the impact ASU 2016-01 will have on our Consolidated Financial Statements.

[0000106040-17-000027:mdna:118]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)” (“ASC Topic 606”), which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The standard is effective beginning the first quarter of fiscal 2019, with early adoption permitted. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our preliminary plan, we intend to adopt the new standard beginning with the first quarter of 2019 using the modified retrospective method. However, we continue to assess this in connection with our entire project plan.

[0000106040-17-000027:mdna:119]
We expect the implementation of the new standard to impact the recognition of our revenue as follows:

[0000106040-17-000027:mdna:120]
| • | Substantially all of our current revenue is from the sale of hardware products. We do not expect any material changes to the timing or amount of revenue for these types of sales under the new standard. |

[0000106040-17-000027:mdna:121]
56

[0000106040-17-000027:mdna:122]
| • | For sales-based royalties, we will need to estimate and recognize revenue in the period the royalty-bearing sales occur as opposed to the existing treatment of recognizing revenue in the period the royalty report is received. This change will result in the acceleration of revenue recognition by one fiscal quarter as well as fluctuations between the estimated and actual reported sales-based royalties which we do not expect to be material. |

[0000106040-17-000027:mdna:123]
| • | For software and IP licenses, we are still assessing the impact and timing to revenue from the implementation of the new standard. However, we do not currently expect the new standard to have a material impact on our revenue for these types of arrangements. |

[0000106040-17-000027:mdna:124]
| • | Our revenue disclosures are expected to expand and may require judgment in certain areas. |

[0000106040-17-000027:mdna:125]
As we are completing our assessment, we are also identifying and preparing to implement changes to our processes, internal controls and systems configurations from the implementation of the new revenue standard. We do not currently expect any significant changes to our other accounting policies from the adoption of the new revenue standard. Our implementation efforts are progressing as planned.

[0000106040-17-000027:mdna:126]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recently Adopted Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:127]
Critical Accounting Policies and Estimates

[0000106040-17-000027:mdna:128]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to Consolidated Financial Statements may be material.

[0000106040-17-000027:mdna:129]
Revenue

[0000106040-17-000027:mdna:130]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return and we provide resellers and OEMs with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection and/or returns until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for our products or market conditions differ from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Total sales incentive and marketing programs have ranged from 8% to 14% of gross revenue and adjustments to revenue due to changes in accruals for these programs related to revenue reported in prior periods have generally averaged less than 1% of gross revenue over the last three fiscal years.

[0000106040-17-000027:mdna:131]
We establish provisions against revenue and cost of revenue for sales returns in the same period that the related revenue is recognized. We base these provisions on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results

[0000106040-17-000027:mdna:132]
Inventories

[0000106040-17-000027:mdna:133]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-17-000027:mdna:134]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-17-000027:mdna:135]
Litigation and Other Contingencies

[0000106040-17-000027:mdna:136]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. For additional information, see Part II, Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-17-000027:mdna:137]
Income Taxes

[0000106040-17-000027:mdna:138]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized.

[0000106040-17-000027:mdna:139]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-17-000027:mdna:140]
Goodwill and Other Long-Lived Assets

[0000106040-17-000027:mdna:141]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We either use qualitative factors to determine whether goodwill is more likely than not impaired or we perform a two-step approach to quantify impairment. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to follow a two-step approach to quantify the impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations.

[0000106040-17-000027:mdna:142]
In-process research and development (“IPR&D”) is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated R&D effort. During the development period, we conduct an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, the impact of the economic environment on us and our customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-17-000027:mdna:143]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-17-000027:mdna:144]
59
