# WDC notes — 0000106040-17-000027


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000106040-17-000027:notes:1]
Advertising costs are expensed as incurred and amounted to $89 million, $60 million and $71 million in 2017, 2016 and 2015, respectively. These expenses are included in Selling, general and administrative (“SG&A”) in the Consolidated Statements of Operations.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-17-000027:notes:2]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of June 30, 2017, by remaining contractual maturity, were as follows:

[0000106040-17-000027:notes:3]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 22 |  |  | $ | 24 |  |
| Due in one to five years (included in other non-current assets) | 94 |  |  | 94 |  |
| Total | $ | 116 |  |  | $ | 118 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000106040-17-000027:notes:4]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000106040-17-000027:notes:5]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition and any borrowings undertaken to finance the acquisition had taken place at the beginning of the earliest period presented, nor does it intend to be a projection of future results:

[0000106040-17-000027:notes:6]
|  | 2016 |  | 2015 |
|  | (in millions, except per share amounts) |
| Revenue | $ | 17,846 |  |  | $ | 20,613 |  |
| Net income | 65 |  |  | 762 |  |
| Basic income per common share | $ | 0.23 |  |  | $ | 2.71 |  |
| Diluted income per common share | $ | 0.23 |  |  | $ | 2.65 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-17-000027:notes:7]
Acquisitions

[0000106040-17-000027:notes:8]
The Consolidated Financial Statements include the results of operations of acquired companies commencing after their respective acquisition dates.

[0000106040-17-000027:notes:9]
Acquisition of SanDisk

[0000106040-17-000027:notes:10]
On May 12, 2016, WDT, a wholly-owned subsidiary of the Company, completed the acquisition of SanDisk (the “Merger”), a global leader in NAND-flash storage solutions. The acquisition was primarily intended to deepen the Company’s expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-17-000027:notes:11]
At the SanDisk Closing Date, each issued and outstanding share of SanDisk common stock, other than shares of SanDisk common stock held in the treasury of SanDisk, shares of SanDisk common stock owned by shareholders who had validly exercised their appraisal rights under Delaware law and shares of SanDisk common stock owned by Western Digital or any subsidiary of Western Digital, was converted into the right to receive $67.50 per share in cash; and 0.2387 shares of Western Digital common stock per share of SanDisk common stock, with cash paid in lieu of fractional shares.

[0000106040-17-000027:notes:12]
The aggregate purchase price of the SanDisk acquisition was $15.59 billion, consisting of $13.77 billion in cash funded with existing cash and cash from new debt, 49 million newly issued shares of the Company’s common stock with a fair value of $1.76 billion and $58 million related to the fair value of stock options and RSUs assumed. The fair value of the newly issued shares of the Company’s common stock was determined based on the closing market price of the Company’s shares of common stock on the date of the acquisition. The fair values of stock options assumed were estimated using a binomial option-pricing model.

[0000106040-17-000027:notes:13]
|  | May 12, 2016 |
|  | (in millions) |
| Cash consideration | $ | 13,766 |  |
| Equity consideration | 1,764 |  |
| Fair value of assumed equity attributed to pre-combination service | 58 |  |
| Total purchase price | $ | 15,588 |  |

[0000106040-17-000027:notes:14]
Assets Acquired and Liabilities Assumed at Fair Value

[0000106040-17-000027:notes:15]
The assets acquired and liabilities assumed were recognized at fair value as of the date of the acquisition.

[0000106040-17-000027:notes:16]
During 2017, the Company finalized the analysis of the purchase price resulting in adjustments of $66 million to the assessed fair value of certain acquired intangible assets; inventory; property, plant and equipment; and a portion of the deferred tax liability related to the Merger. The following table summarizes the final fair values assigned to the assets acquired and liabilities assumed:

[0000106040-17-000027:notes:17]
|  | (in millions) |
| Cash and cash equivalents | $ | 3,931 |  |
| Marketable securities | 737 |  |
| Accounts receivables, net | 394 |  |
| Inventories | 1,076 |  |
| Other current assets | 770 |  |
| Property, plant and equipment | 897 |  |
| Notes receivable and investments in Flash Ventures | 1,012 |  |
| Intangible assets | 4,915 |  |
| Other non-current assets | 213 |  |
| Total assets | 13,945 |  |
| Accounts payable, accrued liabilities and other current liabilities | 1,058 |  |
| Deferred tax liabilities | 595 |  |
| Other long-term liabilities | 210 |  |
| Convertible notes and related derivatives | 3,743 |  |
| Total liabilities | 5,606 |  |
| Net assets acquired | 8,339 |  |
| Goodwill | 7,249 |  |
| Total purchase price | $ | 15,588 |  |

[0000106040-17-000027:notes:18]
Accounts Receivable, Net

[0000106040-17-000027:notes:19]
Accounts receivable are net of allowances for program-related incentives and doubtful accounts of $262 million.

[0000106040-17-000027:notes:20]
Inventories

[0000106040-17-000027:notes:21]
Finished goods were valued at estimated selling prices less costs of disposal and a reasonable profit allowance for the selling effort. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort, or at estimated replacement costs for certain components. Raw materials were valued at estimated replacement costs at the date of acquisition.

[0000106040-17-000027:notes:22]
Property, Plant, and Equipment

[0000106040-17-000027:notes:23]
The property, plant and equipment acquired were valued using either the replacement cost or market value approach, as appropriate, as of the date of acquisition. The following table summarizes the final fair value of the property, plant and equipment acquired and their estimated useful lives:

[0000106040-17-000027:notes:24]
|  | Estimated Fair Value |  | Estimated Weighted-Average Useful Life |
|  | (in millions) |  | (in years) |
| Land | $ | 73 |  |  | N/A |
| Buildings | 308 |  |  | 15 |
| Machinery and equipment | 478 |  |  | 2 |
| Furniture and fixtures | 16 |  |  | 4 |
| Leasehold improvements | 22 |  |  | 5 |
| Total property, plant and equipment | $ | 897 |  |  |  |

[0000106040-17-000027:notes:25]
Identifiable Intangible Assets Acquired

[0000106040-17-000027:notes:26]
The following table summarizes the final fair values and estimated useful lives of the intangibles acquired:

[0000106040-17-000027:notes:27]
|  | Estimated Fair Value |  | Estimated Weighted-Average Useful Life |
|  | (in millions) |  | (in years) |
| Developed technology | $ | 1,360 |  |  | 2.5 |
| Trade names and trademarks | 610 |  |  | 7.0 |
| Customer relationships | 475 |  |  | 7.0 |
| Supply agreements | 130 |  |  | 2.5 |
| Backlog | 50 |  |  | 0.1 |
| In-process research and development | 2,290 |  |  | N/A |
| Total acquired identifiable intangible assets | $ | 4,915 |  |  |  |

[0000106040-17-000027:notes:28]
The fair values of the identifiable intangible assets acquired were estimated using an income approach. The fair value of the finite-lived intangible assets will be amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received to cost of revenue and operating expenses. SanDisk had IPR&D projects associated with new generations of 3D NAND-flash technology, a next generation of controllers for retail products, and a new platform for enterprise solutions products that have not yet reached technological feasibility as of the date of the Merger. These projects are expected to enable increased layers in and achieve lower costs for memory products compared to existing 2D NAND-flash technology, improve controller performance and cost, and expand the range of enterprise solutions offerings. Accordingly, the Company recorded indefinite-lived intangible assets of $2.29 billion for the fair value of these projects, which will not begin amortization until they have reached technological feasibility. Until such time, the projects will be tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that the projects may be impaired. Once a project reaches technological feasibility, the Company will begin to amortize the intangible asset over its estimated useful life.

[0000106040-17-000027:notes:29]
During 2017, acquired IPR&D projects of $1.74 billion reached technological feasibility and was reclassified to developed technology and commenced amortization over an estimated useful life of 4 years.

[0000106040-17-000027:notes:30]
Goodwill

[0000106040-17-000027:notes:31]
Goodwill represents the excess of the preliminary estimated purchase price over the sum of the estimated fair values assigned to assets acquired less liabilities assumed. Goodwill of $7.25 billion is primarily attributable to the benefits the Company expects to derive from deepening its expertise in non-volatile memory and enabling it to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost. None of the goodwill is expected to be deductible for tax purposes.

[0000106040-17-000027:notes:32]
Convertible Notes and Related Derivatives

[0000106040-17-000027:notes:33]
On the SanDisk Closing Date, SanDisk had outstanding $997 million aggregate principal amount of the 2017 Notes and $1.50 billion aggregate principal amount of the 2020 Notes. Concurrently with the issuance of the Convertible Notes, SanDisk also purchased call options and sold warrants. The assumed liability for the Convertible Notes and related derivatives reflects the estimated fair values of the Convertible Notes and the related call options and warrants. See Note 6, Debt, for additional disclosures.

[0000106040-17-000027:notes:34]
Stock-based Awards

[0000106040-17-000027:notes:35]
In connection with the Merger, each outstanding SanDisk option and RSU that was unvested as of the SanDisk Closing Date and each outstanding underwater vested option was converted into equivalent options and RSUs, in each case with respect to shares of the Company’s common stock, using the equity award exchange ratio in accordance with the merger agreement. The value of these converted awards related to pre-combination expense was $58 million and is included in the aggregate purchase price. The remaining value of the converted awards represents post-combination expense and will be recognized by the Company over the remaining service periods. As of June 30, 2017 and July 1, 2016, the future expense for the remaining outstanding assumed SanDisk options and RSUs was $172 million and $347 million, respectively, which will be recognized over a weighted average service period of approximately 1.9 years and 2.7 years, respectively.

[0000106040-17-000027:notes:36]
Acquisition-related Expenses

[0000106040-17-000027:notes:37]
During 2016, the Company incurred $98 million of transaction expenses related to the Merger, which are included within SG&A in the Consolidated Statements of Operations. During 2016, the Company incurred merger-related charges of $30 million associated with the acceleration of certain equity awards in connection with the Merger, of which $24 million was recorded in SG&A and $6 million was recorded in R&D. The Company also incurred $35 million and $31 million of other acquisition related expenses, in 2017 and 2016, respectively, primarily consisting of retention and separation costs in connection with the Merger, which are included in SG&A.

[0000106040-17-000027:notes:38]
Pro Forma Financial Information (Unaudited)

[0000106040-17-000027:notes:39]
The unaudited financial information in the table below summarizes the combined results of operations of the Company and SanDisk, on a pro forma basis, as though the combination had occurred as of the beginning of 2015. The pro forma financial information presented includes the effects of adjustments related to the fair value of acquired inventory, amortization charges from acquired intangible assets, depreciation charges from acquired fixed assets, interest expenses from financing the acquisition, stock-based compensation expenses from the conversion of unvested equity awards and the elimination of certain expenses directly related to the transaction. The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition and any borrowings undertaken to finance the acquisition had taken place at the beginning of the earliest period presented, nor does it intend to be a projection of future results:


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000106040-17-000027:notes:40]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-17-000027:notes:41]
The Company’s total cash, cash equivalents and marketable securities was as follows:

[0000106040-17-000027:notes:42]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Cash and cash equivalents | $ | 6,354 |  |  | $ | 8,151 |  |
| Short-term marketable securities | 24 |  |  | 227 |  |
| Long-term marketable securities | 94 |  |  | 119 |  |
| Total cash, cash equivalents and marketable securities | $ | 6,472 |  |  | $ | 8,497 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-17-000027:notes:43]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan:

[0000106040-17-000027:notes:44]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Benefit obligation at beginning of period | $ | 326 |  |  | $ | 231 |  |  | $ | 255 |  |
| Service cost | 8 |  |  | 8 |  |  | 9 |  |
| Interest cost | 1 |  |  | 3 |  |  | 4 |  |
| Actuarial loss (gain) | (22 | ) |  | 52 |  |  | 16 |  |
| Benefits paid | (30 | ) |  | (16 | ) |  | (8 | ) |
| Settlement/Curtailment | (6 | ) |  | (1 | ) |  | — |  |
| Non-U.S. currency movement | (28 | ) |  | 49 |  |  | (45 | ) |
| Benefit obligation at end of period | $ | 249 |  |  | $ | 326 |  |  | $ | 231 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | $ | 212 |  |  | $ | 185 |  |  | $ | 191 |  |
| Actual return on plan assets | 15 |  |  | (14 | ) |  | 22 |  |
| Employer contributions | 10 |  |  | 20 |  |  | 14 |  |
| Benefits paid | (30 | ) |  | (16 | ) |  | (8 | ) |
| Non-U.S. currency movement | (18 | ) |  | 37 |  |  | (34 | ) |
| Fair value of plan assets at end of period | $ | 189 |  |  | $ | 212 |  |  | $ | 185 |  |
| Unfunded status | $ | 60 |  |  | $ | 114 |  |  | $ | 46 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-17-000027:notes:45]
Commitments, Contingencies and Related Parties

[0000106040-17-000027:notes:46]
Flash Ventures

[0000106040-17-000027:notes:47]
The Company’s business ventures with Toshiba consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Toshiba collaborate in the development and manufacture of NAND-flash memory wafers, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

[0000106040-17-000027:notes:48]
Flash Partners. Flash Partners was formed in 2004. NAND-flash products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 3”) located in Yokkaichi, Japan.

[0000106040-17-000027:notes:49]
Flash Alliance. Flash Alliance was formed in 2006. NAND-flash products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 4”) located in Yokkaichi, Japan.

[0000106040-17-000027:notes:50]
Flash Forward. Flash Forward was formed in 2010. NAND-flash products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 5”) located in Yokkaichi, Japan. Fab 5 was built in two phases of approximately equal size.

[0000106040-17-000027:notes:51]
New Fab 2. The Company has a facility agreement with Toshiba related to the construction and operation of Toshiba’s “New Fab 2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Fab 2 is primarily intended to provide additional cleanroom space to convert a portion of 2-dimensional (“2D”) NAND-flash wafer capacity to 3-dimensional (“3D”) NAND-flash wafer capacity. Production of NAND-flash wafers in New Fab 2 started in 2016.

[0000106040-17-000027:notes:52]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-17-000027:notes:53]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of June 30, 2017 and July 1, 2016:

[0000106040-17-000027:notes:54]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 264 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 119 |  |  | 235 |  |
| Notes receivable, Flash Forward | 379 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 279 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,340 |  |  | $ | 1,171 |  |

[0000106040-17-000027:notes:55]
During 2017 and 2016, the Company made net payments to Flash Ventures of $2.64 billion and $371 million, respectively, for purchased NAND-flash memory wafers and net loans and investments.

[0000106040-17-000027:notes:56]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-17-000027:notes:57]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the consolidated statements of operations. There were no such impairments in 2017, 2016 or 2015.

[0000106040-17-000027:notes:58]
As of June 30, 2017 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $206 million and $168 million, respectively.

[0000106040-17-000027:notes:59]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 30, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-17-000027:notes:60]
|  | June 30, 2017 |
| Notes receivable | $ | 762 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 968 |  |
| Inventory | 187 |  |
| Maximum estimable loss exposure | $ | 2,682 |  |

[0000106040-17-000027:notes:61]
As of June 30, 2017 and July 1, 2016, the Company’s retained earnings included undistributed earnings of Flash Ventures of $5 million and $2 million, respectively.

[0000106040-17-000027:notes:62]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-17-000027:notes:63]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-17-000027:notes:64]
Research and Development Activities. The Company participates in common R&D activities with Toshiba and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-17-000027:notes:65]
Off-Balance Sheet Liabilities

[0000106040-17-000027:notes:66]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-17-000027:notes:67]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 30, 2017.

[0000106040-17-000027:notes:68]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 109 |  |  | $ | 968 |  |

[0000106040-17-000027:notes:69]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of June 30, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 30, 2017:

[0000106040-17-000027:notes:70]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 257 |  |  | $ | 17 |  |  | $ | 274 |  |
| Year 2 |  | 219 |  |  | 24 |  |  | 243 |  |
| Year 3 |  | 154 |  |  | 64 |  |  | 218 |  |
| Year 4 |  | 71 |  |  | 104 |  |  | 175 |  |
| Year 5 |  | 10 |  |  | 48 |  |  | 58 |  |
| Total guarantee obligations |  | $ | 711 |  |  | $ | 257 |  |  | $ | 968 |  |

[0000106040-17-000027:notes:71]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of June 30, 2017, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification guarantees.

[0000106040-17-000027:notes:72]
Lease Commitments

[0000106040-17-000027:notes:73]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2027. Future minimum lease payments under operating leases that have initial non-cancelable lease terms in excess of one year at June 30, 2017 are as follows:

[0000106040-17-000027:notes:74]
|  |  | Lease Amounts |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2018 |  | $ | 46 |  |
| 2019 |  | 42 |  |
| 2020 |  | 31 |  |
| 2021 |  | 26 |  |
| 2022 |  | 13 |  |
| 2023 and thereafter |  | 20 |  |
| Total future minimum lease payments |  | $ | 178 |  |

[0000106040-17-000027:notes:75]
Net rent expense was as follows:

[0000106040-17-000027:notes:76]
|  | 2017 |  | 2016 |  | 2015 |
|  | (In millions) |
| Rent expense, net | $ | 56 |  |  | $ | 59 |  |  | $ | 60 |  |

[0000106040-17-000027:notes:77]
Purchase Agreements

[0000106040-17-000027:notes:78]
The Company has supply contracts that generally require the Company to provide monthly purchase order commitments. The purchase orders placed under these arrangements are generally binding and cannot be canceled. In addition, the Company’s subcontractors periodically procure production materials based on the forecast the Company provides to them. The Company’s agreements with these subcontractors require that the Company reimburse them for materials that are purchased on the Company’s behalf in accordance with such forecast. Accordingly, the Company may be committed to certain costs over and above its open noncancelable purchase orders with these subcontractors. As of June 30, 2017, the Company had no material long-term purchase agreements.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-17-000027:notes:79]
Business Segment, Geographic Information and Concentration of Risk

[0000106040-17-000027:notes:80]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company introduced a new operating model during the fourth quarter of fiscal 2016 that incorporates the HGST, WD and SanDisk businesses. Based upon the revised management structure under the new operating model, the Company determined that the Company’s Chief Operating Decision Maker, its Chief Executive Officer, evaluates performance of the Company and makes decisions regarding allocation of resources based on total Company results. As a result, the Company concluded it operates in one segment, data storage devices and solutions.

[0000106040-17-000027:notes:81]
The following table summarizes the Company’s revenues by end market product category, between Client Devices (mobile, desktop, gaming and digital video hard drives, client solid-state drives (“SSD”), embedded products and wafers); Data Center Devices and Solutions (capacity and performance enterprise hard disk drives (“HDD”), enterprise SSDs, data center software and system solutions); and Client Solutions (removable products, hard drive content solutions and flash content solutions):

[0000106040-17-000027:notes:82]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Client Devices | $ | 9,520 |  |  | $ | 6,205 |  |  | $ | 7,710 |  |
| Data Center Devices & Solutions | 5,505 |  |  | 4,919 |  |  | 5,012 |  |
| Client Solutions | 4,068 |  |  | 1,870 |  |  | 1,850 |  |
| Total revenues | $ | 19,093 |  |  | $ | 12,994 |  |  | $ | 14,572 |  |

[0000106040-17-000027:notes:83]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0000106040-17-000027:notes:84]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Net revenue(1) |  |  |  |  |  |
| United States | $ | 3,881 |  |  | $ | 3,651 |  |  | $ | 3,054 |  |
| China | 4,271 |  |  | 2,413 |  |  | 2,726 |  |
| Hong Kong | 3,257 |  |  | 1,527 |  |  | 1,989 |  |
| Asia | 3,181 |  |  | 2,462 |  |  | 2,562 |  |
| Europe, Middle East and Africa | 3,276 |  |  | 2,664 |  |  | 3,169 |  |
| Other | 1,227 |  |  | 277 |  |  | 1,072 |  |
| Total | $ | 19,093 |  |  | $ | 12,994 |  |  | $ | 14,572 |  |

[0000106040-17-000027:notes:85]
| (1) | Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee. |

[0000106040-17-000027:notes:86]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Long-lived assets(1) |  |  |  |
| United States | $ | 1,249 |  |  | $ | 1,406 |  |
| China | 443 |  |  | 463 |  |
| Asia | 1,293 |  |  | 1,628 |  |
| Europe, Middle East and Africa | 48 |  |  | 6 |  |
| Total | $ | 3,033 |  |  | $ | 3,503 |  |

[0000106040-17-000027:notes:87]
| (1) | Long-lived assets are attributed to the geographic location in which they are located. |

[0000106040-17-000027:notes:88]
Customer Concentration and Credit Risk

[0000106040-17-000027:notes:89]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. For 2017 and 2016, no customer accounted for 10% or more of the Company’s net revenue. For 2015, one company, Hewlett-Packard Company, accounted for 11% of the Company’s net revenue. For 2017, 2016, and 2015, the Company’s top 10 customers accounted for 36%, 43%, and 44%, respectively, of the Company’s net revenue.

[0000106040-17-000027:notes:90]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of June 30, 2017, one customer, Dell Inc., accounted for 11% of the Company’s net accounts receivable. As of July 1, 2016, no single customer accounted for 10% or more of the Company’s net accounts receivable. As of June 30, 2017 and July 1, 2016, the Company had reserves for potential credit losses of $10 million as of each period, and net accounts receivable of $1.95 billion and $1.46 billion, respectively.

[0000106040-17-000027:notes:91]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-17-000027:notes:92]
Supplier Concentration

[0000106040-17-000027:notes:93]
All of the Company’s flash memory system products require silicon wafers for the memory and controller components. The Company’s memory wafers are currently supplied almost entirely from Flash Ventures and the controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-17-000027:notes:94]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-17-000027:notes:95]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 39 |  |  | 39 |  |  | 39 |  |  | (78 | ) |  | 39 |  |
| Foreign currency translation adjustment | (115 | ) |  | (113 | ) |  | (136 | ) |  | 249 |  |  | (115 | ) |
| Net unrealized loss on derivative contracts | (77 | ) |  | (77 | ) |  | (75 | ) |  | 152 |  |  | (77 | ) |
| Net unrealized gain on available-for-sale securities | 2 |  |  | 2 |  |  | 2 |  |  | (4 | ) |  | 2 |  |
| Total other comprehensive loss, before tax | (151 | ) |  | (149 | ) |  | (170 | ) |  | 319 |  |  | (151 | ) |
| Income tax expense related to items of other comprehensive loss | (10 | ) |  | (10 | ) |  | (8 | ) |  | 18 |  |  | (10 | ) |
| Other comprehensive loss, net of tax | (161 | ) |  | (159 | ) |  | (178 | ) |  | 337 |  |  | (161 | ) |
| Total comprehensive income | $ | 236 |  |  | $ | 888 |  |  | $ | 83 |  |  | $ | (971 | ) |  | $ | 236 |  |

[0000106040-17-000027:notes:96]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 242 |  |  | $ | 317 |  |  | $ | 396 |  |  | $ | (713 | ) |  | $ | 242 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (73 | ) |  | (73 | ) |  | (73 | ) |  | 146 |  |  | (73 | ) |
| Foreign currency translation adjustment | 74 |  |  | 74 |  |  | 74 |  |  | (148 | ) |  | 74 |  |
| Net unrealized gain on derivative contracts | 99 |  |  | 99 |  |  | 93 |  |  | (192 | ) |  | 99 |  |
| Total other comprehensive income, before tax | 100 |  |  | 100 |  |  | 94 |  |  | (194 | ) |  | 100 |  |
| Income tax benefit related to items of other comprehensive income | 23 |  |  | 23 |  |  | 23 |  |  | (46 | ) |  | 23 |  |
| Other comprehensive income, net of tax | 123 |  |  | 123 |  |  | 117 |  |  | (240 | ) |  | 123 |  |
| Total comprehensive income | $ | 365 |  |  | $ | 440 |  |  | $ | 513 |  |  | $ | (953 | ) |  | $ | 365 |  |

[0000106040-17-000027:notes:97]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended July 3, 2015 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 1,465 |  |  | $ | 1,535 |  |  | $ | 1,370 |  |  | $ | (2,905 | ) |  | $ | 1,465 |  |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (2 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (2 | ) |
| Net unrealized gain (loss) on derivative contracts | (30 | ) |  | (30 | ) |  | (25 | ) |  | 55 |  |  | (30 | ) |
| Total other comprehensive loss, before tax | (32 | ) |  | (32 | ) |  | (27 | ) |  | 59 |  |  | (32 | ) |
| Income tax benefit related to items of other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive loss, net of tax | (32 | ) |  | (32 | ) |  | (27 | ) |  | 59 |  |  | (32 | ) |
| Total comprehensive income | $ | 1,433 |  |  | $ | 1,503 |  |  | $ | 1,343 |  |  | $ | (2,846 | ) |  | $ | 1,433 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-17-000027:notes:98]
Debt

[0000106040-17-000027:notes:99]
Debt consisted of the following as of June 30, 2017 and July 1, 2016:

[0000106040-17-000027:notes:100]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,970 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,001 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,356 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (205 | ) |  | (532 | ) |
| Subtotal | 13,151 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (233 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,918 |  |  | $ | 13,660 |  |

[0000106040-17-000027:notes:101]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of June 30, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

[0000106040-17-000027:notes:102]
Credit Agreement – Term Loans and Revolving Credit Facility

[0000106040-17-000027:notes:103]
On April 29, 2016, the Company entered into a credit agreement (the “Credit Agreement”) that provided for the following facilities:

[0000106040-17-000027:notes:104]
| • | Term Loan A. Term Loan A with interest payable monthly at a rate based on LIBOR, plus an applicable spread of 2.00% (approximately 3.23% at June 30, 2017). Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in fiscal 2018, $309 million in fiscal 2019, $413 million in fiscal 2020 and the remaining balance of $3.20 billion due in fiscal 2021. The aggregate principal amount outstanding was $4.13 billion at both June 30, 2017 and July 1, 2016. As of June 30, 2017, unamortized issuance costs were $51 million. |

[0000106040-17-000027:notes:105]
| • | U.S. Term Loan B. U.S. dollar-denominated Term Loan B (“U.S. Term Loan B”) which bore interest at a rate based on LIBOR, subject to a 0.75% floor, plus an applicable spread of 5.50% and had an aggregate principal amount outstanding of $3.75 billion at July 1, 2016. On August 17, 2016, the Company borrowed $3.00 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. After making scheduled principal payments during the year of $15 million on U.S. Term Loan B-1, on March 14, 2017, the Company borrowed $2.99 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-1 previously outstanding under the Credit Agreement. The U.S. Term Loan B-2 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 2.75% or a base rate plus 1.75% (3.98% as of June 30, 2017). Principal payments on U.S. Term Loan B-2 of approximately $7 million are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. As of June 30, 2017, the aggregate principal amount outstanding on U.S. Term Loan B-2 was $2.97 billion and unamortized issuance costs were $2 million. |

[0000106040-17-000027:notes:106]
| • | Euro Term Loan B. Euro-denominated Term Loan B (“Euro Term Loan B”) which bore interest at a rate based on EURIBOR, subject to a 0.75% floor, plus an applicable spread of 5.25% and had an aggregate principal amount outstanding of €885 million at July 1, 2016. On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. After making scheduled principal payments during the year of €4 million on Euro Term Loan B-1, on March 23, 2017, the Company borrowed €881 million under a new Euro-denominated term loan (“Euro Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B-1 previously outstanding under the Credit Agreement. The Euro Term Loan B-2 has an interest rate equal to, at the Company’s option, either an adjusted EURIBOR rate, subject to a 0.75% floor, plus 2.00% or a base rate plus 1.75% (2.75% as of June 30, 2017). Principal payments on Euro Term Loan B-2 of approximately €2 million are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. As of June 30, 2017, the aggregate principal amount outstanding on Euro Term Loan B-2 was €876 million ($1.00 billion, based upon the Euro to U.S. dollar exchange rate as of June 30, 2017) and unamortized issuance costs were $1 million. |

[0000106040-17-000027:notes:107]
| • | Revolving Credit Facility. Revolving credit facility of $1.00 billion, which includes a $200 million sublimit for letters of credit (the “Revolving Credit Facility”). Borrowings under the revolving credit facility bear interest at a rate based on LIBOR, plus an applicable spread of 2.00%. The Revolving Credit Facility has a 5-year term. As of June 30, 2017, the revolving credit facility was not drawn upon, and there was no outstanding balance. |

[0000106040-17-000027:notes:108]
In connection with the settlement of the U.S. Term Loans B and B-1 and Euro Term Loans B and B-1, the Company recognized an aggregate loss of $274 million during 2017 consisting of unamortized issuance costs, debt discount fees, and call premiums.

[0000106040-17-000027:notes:109]
In May 2017, the Company entered into an interest rate swap for $1.00 billion notional amount which it has designated as a cash flow hedge to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. Under the agreement, the Company pays interest monthly at a fixed rate of 1.66% and receives at LIBOR rate on the notional amount of the contract through May 2020.

[0000106040-17-000027:notes:110]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-17-000027:notes:111]
The term loans and the revolving credit facility under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-2 and the Euro Term Loan B-2 require the Company to pay a 1.0% prepayment fee if the loans are repaid in connection with certain “repricing” transactions on or before September 14, 2017 and September 23, 2017, respectively.

[0000106040-17-000027:notes:112]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of June 30, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

[0000106040-17-000027:notes:113]
Senior Notes

[0000106040-17-000027:notes:114]
On April 13, 2016, the Company completed an offering consisting of $1.88 billion 7.375% senior secured notes due May 2023 (the “Secured Notes”) and $3.35 billion 10.500% senior unsecured notes due May 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. On February 6, 2017, the exchange offer expired and substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”. The Company pays cash interest on the Notes semi-annually on April 1 and October 1. As of June 30, 2017, the unamortized issuance cost of the Secured Notes and New Unsecured Notes was $40 million and $106 million, respectively

[0000106040-17-000027:notes:115]
The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales.

[0000106040-17-000027:notes:116]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

[0000106040-17-000027:notes:117]
Convertible Notes, Exchange Options and Call Options

[0000106040-17-000027:notes:118]
As of July 1, 2016, the Company had outstanding $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The Company assumed the Convertible Notes in connection with its acquisition of SanDisk Corporation (“SanDisk”), pursuant to an Agreement and Plan of Merger (the “Merger”), on May 12, 2016 (the “SanDisk Closing Date”). The 2017 Notes matured on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

[0000106040-17-000027:notes:119]
During 2017, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $492 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

[0000106040-17-000027:notes:120]
As of June 30, 2017, $35 million principal amount of the 2020 Notes were outstanding, which had a conversion rate of 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property. In addition, as of June 30, 2017, the Company had an immaterial amount of 2017 Notes outstanding. The 2017 Notes were paid in full and the related call option was terminated on August 15, 2017.

[0000106040-17-000027:notes:121]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options is reported in Accrued expenses and Other liabilities in the Consolidated Balance Sheets. See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair values of the exchange options. For 2017, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial loss.

[0000106040-17-000027:notes:122]
In connection with the Merger, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options is reported in Other current assets and Other non-current assets in the Consolidated Balance Sheets. During 2017, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During 2017, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of June 30, 2017 was immaterial.

[0000106040-17-000027:notes:123]
The conversion and repurchase of the Convertible Notes and related settlement of the call options during 2017 resulted in an immaterial net loss.

[0000106040-17-000027:notes:124]
Additional Bridge Facility

[0000106040-17-000027:notes:125]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.00 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.00 billion aggregate principal amount outstanding, together with accrued interest.

[0000106040-17-000027:notes:126]
Future Debt Payments

[0000106040-17-000027:notes:127]
As of June 30, 2017, annual future debt payments were as follows:

[0000106040-17-000027:notes:128]
|  |  | Future Debt Payments |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2018 |  | $ | 246 |  |
| 2019 |  | 350 |  |
| 2020 |  | 452 |  |
| 2021 |  | 3,272 |  |
| 2022 |  | 40 |  |
| 2023 and thereafter |  | 8,996 |  |
| Total debt maturities |  | 13,356 |  |
| Issuance costs and debt discounts |  | (205 | ) |
| Net carrying value |  | $ | 13,151 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-17-000027:notes:129]
Derivative Instruments and Hedging Activities

[0000106040-17-000027:notes:130]
As of June 30, 2017, the Company had outstanding foreign exchange forward contracts which were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps which were designated as cash flow hedges. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for 2017, 2016 and 2015.

[0000106040-17-000027:notes:131]
As of June 30, 2017, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive income (loss) that are expected to be reclassified into earnings over the next twelve months was $3 million. In addition, as of June 30, 2017, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-17-000027:notes:132]
A change in the fair value of non-designated hedges is recognized in earnings in the period incurred and is reported as a component of Other income (expense), net. The changes in fair value on these contracts were immaterial to the Consolidated Financial Statements during 2017, 2016 and 2015.

[0000106040-17-000027:notes:133]
See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair value of the Company’s foreign exchange forward contracts.

[0000106040-17-000027:notes:134]
Derivative Instruments

[0000106040-17-000027:notes:135]
The fair value and balance sheet location of the Company’s derivative instruments were as follows:

[0000106040-17-000027:notes:136]
|  | Derivative Assets Reported in |
|  | Other current assets |  | Other non-current assets |
|  | June 30, 2017 |  | July 1, 2016 |  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 6 |  |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts, not designated | 10 |  |  | 12 |  |  | — |  |  | — |  |
| Call options | — |  |  | 70 |  |  | — |  |  | 1 |  |
| Total derivatives | $ | 16 |  |  | $ | 196 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-17-000027:notes:137]
|  | Derivative Liabilities Reported in |
|  | Accrued expenses |  | Other liabilities |
|  | June 30, 2017 |  | July 1, 2016 |  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 2 |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts, not designated | 6 |  |  | — |  |  | — |  |  | — |  |
| Interest rate swaps, designated | 1 |  |  | — |  |  | — |  |  | — |  |
| Exchange option | — |  |  | 141 |  |  | 1 |  |  | 14 |  |
| Total derivatives | $ | 9 |  |  | $ | 164 |  |  | $ | 1 |  |  | $ | 14 |  |

[0000106040-17-000027:notes:138]
Netting Arrangements

[0000106040-17-000027:notes:139]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of set-off associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 30, 2017, the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets and separately recorded the gross fair value amounts of the derivative instruments as either assets or liabilities. As of June 30, 2017 and July 1, 2016, the effect of rights of set-off was not material.

[0000106040-17-000027:notes:140]
Effect of Derivative Contracts on the Consolidated Statements of Operations

[0000106040-17-000027:notes:141]
The impact of derivative contracts on the Consolidated Financial Statements was as follows:

[0000106040-17-000027:notes:142]
|  | Amount of Gain (Loss) Recognized in AOCI |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange forward contracts | $ | (46 | ) |  | $ | 48 |  |  | $ | (74 | ) |
| Interest rate swaps | (1 | ) |  | — |  |  | — |  |
| Total | $ | (47 | ) |  | $ | 48 |  |  | $ | (74 | ) |

[0000106040-17-000027:notes:143]
|  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange forward contracts | $ | 30 |  |  | $ | (51 | ) |  | $ | (44 | ) |

[0000106040-17-000027:notes:144]
The total net realized transaction and foreign exchange forward contract currency gains and losses were not material to the Consolidated Financial Statements for 2017, 2016 and 2015.


## us-gaap:DerivativesPolicyTextBlock

[0000106040-17-000027:notes:145]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British Pound Sterling, European Euro, Japanese yen, Malaysian ringgit, Philippine peso, Singapore dollar and Thai baht, which had an aggregate notional amount of $2.79 billion and $3.07 billion at June 30, 2017 and July 1, 2016, respectively.

[0000106040-17-000027:notes:146]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in cost of revenue and operating expenses, and presented within cash flows from operating activities. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-17-000027:notes:147]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income (expense), net. See Note 4, Fair Value Measurements and Investments, and Note 5, Derivative Instruments and Hedging Activities, for additional disclosures related to the Company’s foreign exchange contracts.

[0000106040-17-000027:notes:148]
The Company accounts for its interest rate swap as a designated cash flow hedge to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. The Company pays interest monthly at a fixed rate and receives interest monthly at the LIBOR rate on the notional amount of the contract. The effective portion of the change in fair value of this designated cash flow hedge is deferred in other comprehensive income (loss), net of tax, with any ineffective portion recognized in Other income (expense), net. See Note 5, Derivative Instruments and Hedging Activities, and Note 6, Debt, for further discussion on interest rate swaps.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-17-000027:notes:149]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s consolidated statements of operations:

[0000106040-17-000027:notes:150]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Options | $ | 41 |  |  | $ | 55 |  |  | $ | 58 |  |
| Restricted and performance stock units | 330 |  |  | 123 |  |  | 88 |  |
| Employee stock purchase plan | 23 |  |  | 13 |  |  | 16 |  |
| Subtotal | 394 |  |  | 191 |  |  | 162 |  |
| Tax benefit | (105 | ) |  | (48 | ) |  | (43 | ) |
| Total | $ | 289 |  |  | $ | 143 |  |  | $ | 119 |  |

[0000106040-17-000027:notes:151]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Cost of revenue | $ | 49 |  |  | $ | 21 |  |  | $ | 17 |  |
| Research and development | 173 |  |  | 76 |  |  | 61 |  |
| Selling, general and administrative | 161 |  |  | 85 |  |  | 84 |  |
| Employee termination, asset impairment, and other charges | 11 |  |  | 9 |  |  | — |  |
| Subtotal | 394 |  |  | 191 |  |  | 162 |  |
| Tax benefit | (105 | ) |  | (48 | ) |  | (43 | ) |
| Total | $ | 289 |  |  | $ | 143 |  |  | $ | 119 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000106040-17-000027:notes:152]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and shares issuable in connection with convertible debt.


## us-gaap:EarningsPerShareTextBlock

[0000106040-17-000027:notes:153]
Net Income Per Common Share

[0000106040-17-000027:notes:154]
The following table presents the computation of basic and diluted income per common share:

[0000106040-17-000027:notes:155]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions, except per share data) |
| Net income | $ | 397 |  |  | $ | 242 |  |  | $ | 1,465 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 288 |  |  | 239 |  |  | 232 |  |
| Employee stock options, RSUs, PSUs and ESPP | 8 |  |  | 3 |  |  | 5 |  |
| Diluted | 296 |  |  | 242 |  |  | 237 |  |
| Income per common share |  |  |  |  |  |
| Basic | $ | 1.38 |  |  | $ | 1.01 |  |  | $ | 6.31 |  |
| Diluted | $ | 1.34 |  |  | $ | 1.00 |  |  | $ | 6.18 |  |
| Anti-dilutive potential common shares excluded(1) | 3 |  |  | 5 |  |  | 1 |  |

[0000106040-17-000027:notes:156]
| (1) | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-17-000027:notes:157]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s ESPP and awards of RSUs.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000106040-17-000027:notes:158]
The following table illustrates the changes in the balances of the call options reported in Other current assets and Other non-current assets in the Company’s Consolidated Balance Sheets:

[0000106040-17-000027:notes:159]
|  | 2017 Call Options |  | 2020 Call Options |  | Total |
|  | (in millions) |
| Initial estimate upon acquisition | $ | 501 |  |  | $ | — |  |  | $ | 501 |  |
| Redemptions | (437 | ) |  | — |  |  | (437 | ) |
| Net unrealized gain | 6 |  |  | 1 |  |  | 7 |  |
| Fair value as of July 1, 2016 | 70 |  |  | 1 |  |  | 71 |  |
| Net realized gain (loss) | 2 |  |  | (1 | ) |  | 1 |  |
| Redemptions | (72 | ) |  | — |  |  | (72 | ) |
| Fair value as of June 30, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-17-000027:notes:160]
Fair Value Measurements and Investments

[0000106040-17-000027:notes:161]
Financial Instruments Carried at Fair Value

[0000106040-17-000027:notes:162]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-17-000027:notes:163]
| Level 1. | Quoted prices in active markets for identical assets or liabilities. |

[0000106040-17-000027:notes:164]
| Level 2. | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000106040-17-000027:notes:165]
| Level 3. | Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities. |

[0000106040-17-000027:notes:166]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 30, 2017 and July 1, 2016, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-17-000027:notes:167]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,836 |  |
| Certificates of deposit | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total cash equivalents | 2,836 |  |  | 10 |  |  | — |  |  | 2,846 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 4 |  |  | 20 |  |  | — |  |  | 24 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term investments | 5 |  |  | 89 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,845 |  |  | $ | 135 |  |  | $ | — |  |  | $ | 2,980 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swap contract | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Exchange option | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 10 |  |

[0000106040-17-000027:notes:168]
|  | July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,199 |  |
| Certificates of deposit | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 2,199 |  |  | 1 |  |  | — |  |  | 2,200 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202 |  |  | — |  |  | 202 |  |
| Corporate notes and bonds | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total short-term investments | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total long-term investments | 2 |  |  | 117 |  |  | — |  |  | 119 |  |
| Foreign exchange contracts | — |  |  | 126 |  |  | — |  |  | 126 |  |
| Call options | — |  |  | — |  |  | 71 |  |  | 71 |  |
| Total assets at fair value | $ | 2,201 |  |  | $ | 471 |  |  | $ | 71 |  |  | $ | 2,743 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Exchange option | — |  |  | — |  |  | 155 |  |  | 155 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 23 |  |  | $ | 155 |  |  | $ | 178 |  |

[0000106040-17-000027:notes:169]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-17-000027:notes:170]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-17-000027:notes:171]
Asset-Backed Securities, and Corporate and Municipal Notes and Bonds. The Company’s asset-backed securities, and Corporate and Municipal notes and bonds securities are investments issued by corporations and U.S. state municipalities which are held in custody by a third party. Asset-backed securities, and Corporate and Municipal notes and bonds are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-17-000027:notes:172]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government and are held in custody by a third party. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-17-000027:notes:173]
U.S. Government Agency and International Government Securities. The Company’s U.S. Government agency and international government securities are investments in fixed income securities sponsored by the U.S. Government and international governments and are held in custody by a third party. U.S. Government agency and international government securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-17-000027:notes:174]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 5, Derivative Instruments and Hedging Activities.

[0000106040-17-000027:notes:175]
Interest Rate Swaps. The Company’s interest rate swaps are long-term contracts to hedge the Company’s variable rate debt risk. Interest rate swaps are valued based on estimated present value of future cash flows model. The market-based observable inputs for the model include interest rate curves and credit valuation adjustments.

[0000106040-17-000027:notes:176]
During 2017 and 2016, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-17-000027:notes:177]
Assets and Liabilities Measured at Fair Value on a Recurring Basis Using Significant Unobservable Inputs (Level 3)

[0000106040-17-000027:notes:178]
Call Options. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of its convertible notes.

[0000106040-17-000027:notes:179]
Exchange Options. The Company’s convertible notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as derivative liabilities because they are predominantly settled in cash.

[0000106040-17-000027:notes:180]
The fair value measurement of the call options and exchange options arising from the Company’s Convertible Notes (as defined in Note 6, Debt), which are not actively traded, is determined using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) the economic incentive for holders to exercise their exchange option. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-17-000027:notes:181]
There were no transfers of call options or exchange options out of Level 3 for 2017.

[0000106040-17-000027:notes:182]
The following table illustrates the changes in the balances of the exchange options reported in Accrued expenses and Other liabilities in the Company’s Consolidated Balance Sheets:

[0000106040-17-000027:notes:183]
|  | 2017 Exchange Options |  | 2020 Exchange Options |  | Total |
|  | (in millions) |
| Initial estimate upon acquisition | $ | 610 |  |  | $ | 357 |  |  | $ | 967 |  |
| Net realized loss | 8 |  |  | 8 |  |  | 16 |  |
| Redemptions | (531 | ) |  | (283 | ) |  | (814 | ) |
| Net unrealized gain | — |  |  | (14 | ) |  | (14 | ) |
| Fair value as of July 1, 2016 | 87 |  |  | 68 |  |  | 155 |  |
| Net realized gain | (3 | ) |  | (31 | ) |  | (34 | ) |
| Redemptions | (83 | ) |  | (46 | ) |  | (129 | ) |
| Net unrealized loss | — |  |  | 9 |  |  | 9 |  |
| Fair value as of June 30, 2017 | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-17-000027:notes:184]
Available-for-Sale Securities

[0000106040-17-000027:notes:185]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of June 30, 2017 and July 1, 2016. The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of June 30, 2017, by remaining contractual maturity, were as follows:

[0000106040-17-000027:notes:186]
The Company determined available-for-sale securities had no material other-than-temporary impairments during 2017, 2016 and 2015.

[0000106040-17-000027:notes:187]
Financial Instruments Not Carried at Fair Value

[0000106040-17-000027:notes:188]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2017 and the fourth quarter of 2016, respectively.

[0000106040-17-000027:notes:189]
|  | June 30, 2017 |  | July 1, 2016 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Secured Notes | $ | 1,835 |  |  | $ | 2,062 |  |  | $ | 1,828 |  |  | $ | 2,044 |  |
| Unsecured Notes | 3,244 |  |  | 3,956 |  |  | 3,229 |  |  | 3,575 |  |
| Term Loan A | 4,074 |  |  | 4,130 |  |  | 4,061 |  |  | 4,161 |  |
| U.S. Term Loan B | — |  |  | — |  |  | 3,546 |  |  | 3,773 |  |
| U.S. Term Loan B-2 | 2,968 |  |  | 2,989 |  |  | — |  |  | — |  |
| Euro Term Loan B(1) | — |  |  | — |  |  | 960 |  |  | 981 |  |
| Euro Term Loan B-2(1) | 1,000 |  |  | 1,010 |  |  | — |  |  | — |  |
| Bridge Loan | — |  |  | — |  |  | 2,995 |  |  | 3,000 |  |
| Convertible Debt 2017 | — |  |  | — |  |  | 124 |  |  | 125 |  |
| Convertible Debt 2020 | 30 |  |  | 34 |  |  | 251 |  |  | 264 |  |
| Total | $ | 13,151 |  |  | $ | 14,181 |  |  | $ | 16,994 |  |  | $ | 17,923 |  |

[0000106040-17-000027:notes:190]
Equity Method Investments

[0000106040-17-000027:notes:191]
In November 2015, the Company entered into an agreement to form a joint venture, referred to as the “Unis Venture”, with Unisplendour Corporation Limited (“Unis”) to market and sell the Company’s current data center storage systems in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd. The Company accounts for its investment in the Unis Venture under the equity method of accounting. The investment in Unis Venture is recorded within Other non-current assets in the Consolidated Balance Sheets and is not material to the Consolidated Financial Statements as of June 30, 2017 and July 1, 2016.

[0000106040-17-000027:notes:192]
In addition, the Company has joint venture investments with Toshiba Corporation (“Toshiba”), see Note 9, Commitments, Contingencies and Related Parties, for further discussion regarding these joint ventures.

[0000106040-17-000027:notes:193]
Cost Method Investments

[0000106040-17-000027:notes:194]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company reports these investments under the cost method of accounting as these investments consist of debt and equity securities of privately-held companies which do not have a readily determinable fair value. The Company assesses these securities for indications of other-than-temporary impairments and, in this regard, recorded impairment charges of $55 million to Other income (expense), net in the Consolidated Statements of Operations in 2017. There were no impairment charges related to cost method investments during 2016 and 2015. As of June 30, 2017 and July 1, 2016, these investments aggregated $91 million and $135 million, respectively, and are reported under Other non-current assets in the Consolidated Balance Sheets.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000106040-17-000027:notes:195]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Intangible asset amortization was as follows:

[0000106040-17-000027:notes:196]
|  | 2017 |  | 2016 |  | 2015 |
|  | (In millions) |
| Intangible asset amortization | $ | 1,169 |  |  | $ | 266 |  |  | $ | 171 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-17-000027:notes:197]
Goodwill and Other Intangible Assets

[0000106040-17-000027:notes:198]
The following table summarizes the activity related to the carrying amount of goodwill:

[0000106040-17-000027:notes:199]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 3, 2015 | $ | 2,766 |  |
| Goodwill recorded in connection with acquisitions | 7,183 |  |
| Foreign currency translation adjustment | 2 |  |
| Balance at July 1, 2016 | 9,951 |  |
| Purchase price adjustments to goodwill | 66 |  |
| Foreign currency translation adjustment | (3 | ) |
| Balance at June 30, 2017 | $ | 10,014 |  |

[0000106040-17-000027:notes:200]
The purchase price adjustments resulted from adjustments to the assessment of fair value for certain acquired intangible assets; inventory; property, plant and equipment; and a portion of the deferred tax liability related to the Merger.

[0000106040-17-000027:notes:201]
The following tables present intangible assets as of June 30, 2017 and July 1, 2016:

[0000106040-17-000027:notes:202]
|  | June 30, 2017 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 3,478 |  |  | $ | (1,373 | ) |  | $ | 2,105 |  |
| Trade names and trademarks | 7 |  | 645 |  |  | (134 | ) |  | 511 |  |
| Customer relationships | 6 |  | 627 |  |  | (227 | ) |  | 400 |  |
| Other | 2 |  | 375 |  |  | (288 | ) |  | 87 |  |
| Leasehold interests | 31 |  | 35 |  |  | (11 | ) |  | 24 |  |
| Total finite intangible assets |  |  | 5,160 |  |  | (2,033 | ) |  | 3,127 |  |
| In-process research and development |  |  | 696 |  |  | — |  |  | 696 |  |
| Total intangible assets |  |  | $ | 5,856 |  |  | $ | (2,033 | ) |  | $ | 3,823 |  |

[0000106040-17-000027:notes:203]
|  | July 1, 2016 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 2,008 |  |  | $ | (632 | ) |  | $ | 1,376 |  |
| Trade names and trademarks | 7 |  | 645 |  |  | (45 | ) |  | 600 |  |
| Customer relationships | 6 |  | 628 |  |  | (157 | ) |  | 471 |  |
| Other | 2 |  | 219 |  |  | (96 | ) |  | 123 |  |
| Leasehold interests | 31 |  | 39 |  |  | (10 | ) |  | 29 |  |
| Total finite intangible assets |  |  | 3,539 |  |  | (940 | ) |  | 2,599 |  |
| In-process research and development |  |  | 2,435 |  |  | — |  |  | 2,435 |  |
| Total intangible assets |  |  | $ | 5,974 |  |  | $ | (940 | ) |  | $ | 5,034 |  |

[0000106040-17-000027:notes:204]
Acquired in-process research and development (“IPR&D”) is accounted for as an indefinite-lived intangible asset. Upon completion of development, IPR&D is considered to be an amortizable finite-lived intangible asset. During 2017, the Company reclassified $1.74 billion of acquired IPR&D to existing technology and commenced amortization over an estimated useful life of 4 years.

[0000106040-17-000027:notes:205]
During 2017, the Company did not record any impairment charges related to intangible assets. During 2016 and 2015, the Company recorded $36 million and $39 million of impairment charges related to intangible assets, respectively, which are recorded in the employee termination, asset impairment and other charges within the Consolidated Statements of Operations. The impairment charges primarily relate to acquired IPR&D projects that were abandoned and resulted in full impairment.

[0000106040-17-000027:notes:206]
The following table presents estimated future amortization expense for intangible assets currently subject to amortization as of June 30, 2017:

[0000106040-17-000027:notes:207]
|  | Future Intangible Asset Amortization Expense |
|  | (in millions) |
| Fiscal year |  |
| 2018 | $ | 1,085 |  |
| 2019 | 796 |  |
| 2020 | 590 |  |
| 2021 | 339 |  |
| 2022 | 157 |  |
| 2023 and thereafter | 160 |  |
| Total future amortization expense | $ | 3,127 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000106040-17-000027:notes:208]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the first day of its fiscal fourth quarter. The Company either uses qualitative factors to determine whether goodwill is more likely than not impaired or performs a two-step approach to quantify impairment. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to follow a two-step approach to quantify the impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-17-000027:notes:209]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-17-000027:notes:210]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The Company recorded impairments to certain long-lived assets in 2017, 2016 and 2015. See Note 4, Fair Value Measurements and Investments, Note 7, Goodwill and Other Intangible Assets and Note 15, Acquisitions, for additional disclosures related to the Company’s other intangible assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-17-000027:notes:211]
Income Tax Expense (Benefit)

[0000106040-17-000027:notes:212]
Income Before Taxes

[0000106040-17-000027:notes:213]
The domestic and foreign components of income before taxes were as follows:

[0000106040-17-000027:notes:214]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Foreign | $ | 560 |  |  | $ | 516 |  |  | $ | 1,501 |  |
| Domestic | 209 |  |  | (363 | ) |  | 76 |  |
| Income before taxes | $ | 769 |  |  | $ | 153 |  |  | $ | 1,577 |  |

[0000106040-17-000027:notes:215]
Income Tax Provision

[0000106040-17-000027:notes:216]
The components of the provision for income taxes were as follows:

[0000106040-17-000027:notes:217]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 127 |  |  | $ | 59 |  |  | $ | 54 |  |
| Domestic - Federal | 229 |  |  | 2 |  |  | 43 |  |
| Domestic - State | 4 |  |  | (1 | ) |  | (13 | ) |
|  | 360 |  |  | 60 |  |  | 84 |  |
| Deferred: |  |  |  |  |  |
| Foreign | 56 |  |  | (39 | ) |  | 12 |  |
| Domestic - Federal | (44 | ) |  | (109 | ) |  | 11 |  |
| Domestic - State | — |  |  | (1 | ) |  | 5 |  |
|  | 12 |  |  | (149 | ) |  | 28 |  |
| Income tax provision | $ | 372 |  |  | $ | (89 | ) |  | $ | 112 |  |

[0000106040-17-000027:notes:218]
The Company’s income tax expense for 2017 reflects tax expense from the integration of SanDisk and a valuation allowance on both acquired tax attributes and net operating loss carryforwards from restructuring activities. The Company’s income tax benefit for 2016 reflects tax benefits from expenses related to the Merger and from interest expense related to debt facilities.

[0000106040-17-000027:notes:219]
Remaining net undistributed earnings from foreign subsidiaries at June 30, 2017, on which no U.S. tax has been provided, amounted to $16 billion. The net undistributed earnings are intended to finance local operating requirements and capital investments. Accordingly, an additional U.S. tax provision has not been made on these earnings. The tax liability for these earnings would be approximately $5 billion, if the Company repatriated the undistributed earnings from the foreign subsidiaries.

[0000106040-17-000027:notes:220]
Deferred Taxes

[0000106040-17-000027:notes:221]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-17-000027:notes:222]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 84 |  |  | $ | 82 |  |
| Accrued compensation and benefits not currently deductible | 252 |  |  | 207 |  |
| Net operating loss carryforward | 292 |  |  | 259 |  |
| Business credit carryforward | 283 |  |  | 264 |  |
| Long-lived assets | 236 |  |  | 256 |  |
| Other | 141 |  |  | 177 |  |
| Total deferred tax assets | 1,288 |  |  | 1,245 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (874 | ) |  | (1,030 | ) |
| Unremitted earnings of certain non-U.S. entities | (38 | ) |  | — |  |
| Other | (11 | ) |  | (9 | ) |
| Total deferred tax liabilities | (923 | ) |  | (1,039 | ) |
| Valuation allowances | (518 | ) |  | (294 | ) |
| Deferred tax liabilities, net | $ | (153 | ) |  | $ | (88 | ) |

[0000106040-17-000027:notes:223]
The increase in deferred tax liabilities, net in 2017, compared to 2016, was primarily due to the increase in deferred tax expense of $12 million, tax effects of OCI items of $10 million, purchase price adjustments to goodwill of $27 million and shortfalls related to stock-based compensation deductions included in additional paid-in capital of $15 million.

[0000106040-17-000027:notes:224]
The net deferred tax asset valuation allowance increased by $224 million and $128 million in 2017 and 2016, respectively. The valuation allowance increase in 2017 is primarily attributable to $111 million for acquired tax attributes, $46 million for net operating loss carryforwards from restructuring activities, $31 million for capital losses, and $27 million for the current year generation of state tax credits which the Company does not anticipate being able to utilize. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-17-000027:notes:225]
In addition to the deferred tax assets presented above, the Company had benefits related to net operating loss (“NOL”) benefits from stock-based compensation deductions of $20 million and $119 million as of June 30, 2017 and July 1, 2016, respectively. During 2017, the Company recorded $119 million of tax benefits related to stock-based compensation deductions to Shareholders’ equity of which $98 million related to NOL benefits for stock-based compensation deductions and $21 million was related to current year stock-based compensation deductions.

[0000106040-17-000027:notes:226]
Effective Tax Rate

[0000106040-17-000027:notes:227]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-17-000027:notes:228]
|  | 2017 |  | 2016 |  | 2015 |
| U.S. Federal statutory rate | 35 | % |  | 35 | % |  | 35 | % |
| Tax rate differential on international income | (27 | ) |  | (103 | ) |  | (29 | ) |
| Tax effect of U.S. non-deductible convertible debt costs | — |  |  | 13 |  |  | — |  |
| Tax effect of U.S. non-deductible acquisition costs | — |  |  | 10 |  |  | — |  |
| Tax effect of U.S. foreign income inclusion | 4 |  |  | 9 |  |  | — |  |
| Tax effect of U.S. non-deductible stock-based compensation | 1 |  |  | 9 |  |  | — |  |
| Tax effect of U.S. permanent differences | (1 | ) |  | 1 |  |  | 1 |  |
| State income tax, net of federal tax | 1 |  |  | (1 | ) |  | — |  |
| Change in valuation allowance | 29 |  |  | 16 |  |  | 2 |  |
| Unremitted earnings of certain non-U.S. entities | 5 |  |  | — |  |  | — |  |
| Tax related to SanDisk integration | 12 |  |  | — |  |  | — |  |
| Retroactive extension of Federal R&D credit | — |  |  | (9 | ) |  | — |  |
| Income tax credits | (12 | ) |  | (43 | ) |  | (4 | ) |
| Other | 1 |  |  | 5 |  |  | 2 |  |
| Effective tax rate | 48 | % |  | (58 | )% |  | 7 | % |

[0000106040-17-000027:notes:229]
Tax Holidays and Carryforwards

[0000106040-17-000027:notes:230]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines, Singapore and Thailand operate under various tax holidays and tax incentive programs which will expire in whole or in part at various dates from 2018 through 2030. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $467 million, or $1.58 per diluted share, $500 million, or $2.07 per diluted share, and $641 million, or $2.70 per diluted share, in 2017, 2016, and 2015, respectively.

[0000106040-17-000027:notes:231]
As of June 30, 2017, the Company had federal and state NOL carryforwards of $765 million and $552 million, respectively. The NOL carryforwards available to offset future federal taxable income expire at various dates from 2020 to 2037 and future state taxable income expire at various dates from 2018 to 2037. As of June 30, 2017, the Company had various federal and state tax credit carryforwards totaling $599 million. The available federal tax credit carryforwards of $78 million to offset future federal taxable income expire at various dates from 2018 to 2037. The remaining credit carryforward amount of $521 million relates primarily to state tax credit carryforwards which are available indefinitely.

[0000106040-17-000027:notes:232]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal NOLs ultimately realized will be reduced by $498 million and state NOLs ultimately realized will be reduced by $422 million. The Company expects the total amount of federal credits ultimately realized will be reduced by $41 million and state tax credit carryforwards ultimately realized will be reduced by $375 million.

[0000106040-17-000027:notes:233]
The Company had varying amounts of foreign NOL carryforward that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforward and the related expiration dates of these NOL carryforward tax credits are as follows:

[0000106040-17-000027:notes:234]
| Jurisdiction |  | NOL Carryforward Amount |  | Expiration |
|  |  | (in millions) |  |  |
| Japan |  | $ | 142 |  |  | 2024 to 2026 |
| Belgium |  | 61 |  |  | No expiration |
| China |  | 53 |  |  | 2023 |
| Singapore |  | 40 |  |  | No expiration |

[0000106040-17-000027:notes:235]
The Company expects the total amount of NOL carryforwards in Japan ultimately realized will be reduced by $76 million. The Company expects the NOL carryforwards in Belgium, China and Singapore will not be ultimately realized.

[0000106040-17-000027:notes:236]
Uncertain Tax Positions

[0000106040-17-000027:notes:237]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 30, 2017, July 1, 2016 and July 3, 2015 was $89 million, $75 million and $55 million, respectively.

[0000106040-17-000027:notes:238]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-17-000027:notes:239]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 491 |  |  | $ | 350 |  |  | $ | 300 |  |
| Gross increases related to current year tax positions | 35 |  |  | 46 |  |  | 44 |  |
| Gross increases related to prior year tax positions | 3 |  |  | 6 |  |  | 6 |  |
| Gross decreases related to prior year tax positions | (8 | ) |  | (15 | ) |  | — |  |
| Settlements | (8 | ) |  | (8 | ) |  | — |  |
| Lapse of statute of limitations | (19 | ) |  | (8 | ) |  | (3 | ) |
| Acquisitions | 28 |  |  | 120 |  |  | 3 |  |
| Unrecognized tax benefit, ending balance | $ | 522 |  |  | $ | 491 |  |  | $ | 350 |  |

[0000106040-17-000027:notes:240]
The Company’s unrecognized tax benefits are primarily included within long-term liabilities in the Consolidated Balance Sheets. The entire balance of unrecognized tax benefits as of June 30, 2017, July 1, 2016 and July 3, 2015, if recognized, would affect the effective tax rate.

[0000106040-17-000027:notes:241]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2008 through 2016. The Company is no longer subject to examination by the IRS for periods prior to 2008, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the major foreign jurisdictions, the Company could be subject to examination in China for calendar years 2007 through 2016, in Ireland for calendar years 2013 through 2016, and Japan in fiscal years 2011 through 2016.

[0000106040-17-000027:notes:242]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. Meetings with the IRS Appeals Office began in March 2017. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-17-000027:notes:243]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 30, 2017, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0000106040-17-000027:notes:244]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized.

[0000106040-17-000027:notes:245]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.


## us-gaap:InventoryPolicyTextBlock

[0000106040-17-000027:notes:246]
The Company values inventories at the lower of cost (first-in, first out and weighted-average methods) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories, while the weighted-average method is used to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by the Company. The Company has determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, precious metals are relieved from inventory based on the weighted-average cost of the inventory at the time the inventory is used in production. The weighted average method of valuing precious metals does not materially differ from the FIFO method. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-17-000027:notes:247]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-17-000027:notes:248]
Legal Proceedings

[0000106040-17-000027:notes:249]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-17-000027:notes:250]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the SanDisk Closing Date; “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-17-000027:notes:251]
Intellectual Property Litigation

[0000106040-17-000027:notes:252]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-17-000027:notes:253]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000027:notes:254]
In December 2016, Memory Technologies, LLC (“MTL”), a subsidiary of Pendrell Corporation, filed two complaints - one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California - against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserted that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,542; RE45,486; 7,565,469; 9,063,850; and 8,307,180. The ITC complaint sought an exclusion order barring the accused products, and components thereof, from entry into the U.S. In the other complaint, MTL asserted that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint sought unspecified monetary damages. In June 2017, the parties entered into a settlement and patent license agreement. The agreement fully resolves all pending litigation between the parties and grants the Company a license to Pendrell patents relating to memory and storage technologies. The settlement terms are not material to the Company’s financial position, results of operations or cash flows.

[0000106040-17-000027:notes:255]
Antitrust

[0000106040-17-000027:notes:256]
In June 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint with the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. In February 2011, Dr. Harari was dismissed as a defendant. Between 2013 and 2014, Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, was substituted in as named plaintiff and CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. were added as named plaintiffs. In May 2015, the District Court granted in part plaintiffs’ motion for class certification. In April 2016, the District Court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk’s favor as to all of the plaintiffs’ claims. In May 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. In July 2017, the Federal Circuit affirmed the District Court’s grant of SanDisk’s motion for summary judgment.

[0000106040-17-000027:notes:257]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017, and the District Court lifted its stay of the litigation in July 2017.

[0000106040-17-000027:notes:258]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000027:notes:259]
Securities

[0000106040-17-000027:notes:260]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000027:notes:261]
Toshiba Matters

[0000106040-17-000027:notes:262]
Toshiba litigation against the Company

[0000106040-17-000027:notes:263]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba Corporation and Toshiba Memory Corporation in the Tokyo District Court. The petition alleges that the Company has engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requests injunctive relief.

[0000106040-17-000027:notes:264]
In June 2017, Toshiba issued a press release announcing that it also brought suit for a permanent injunction, damages and payment of 120 billion Japanese yen. The Company has not received Toshiba’s announced filing or any formal notice of such lawsuit. The Company intends to defend itself vigorously in these matters.

[0000106040-17-000027:notes:265]
SanDisk litigation against Toshiba

[0000106040-17-000027:notes:266]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba Corporation to unwind the transfer of its interests in Flash Ventures to its affiliate, Toshiba Memory Corporation, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements by transferring its interests in Flash Ventures without SanDisk’s consent. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco to prevent Toshiba from transferring its interests in Flash Ventures until the request of the SanDisk Subsidiaries for injunctive relief in arbitration is decided by the arbitral tribunal. In July 2017, the Superior Court entered a stipulated order requiring Toshiba to give the SanDisk Subsidiaries at least 14 days’ advance notice of any transfer involving Toshiba’s interests in Flash Ventures, in order to ensure that the issue is preserved for arbitration.

[0000106040-17-000027:notes:267]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the JV agreements. SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order (“TRO”), in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. On July 11, 2017, the Superior Court granted a TRO in favor of SanDisk. Toshiba filed a notice of appeal, and on July 18, the California Court of Appeal, First Appellate District, issued a temporary stay of the TRO while it reviewed Toshiba’s petition for a permanent stay of the TRO pending appeal. On July 24, SanDisk LLC amended its request for arbitration to, among other things, add Toshiba Memory Corporation as a defendant. On August 2, 2017, the Court of Appeal denied Toshiba’s petition for a permanent stay of the TRO and dissolved the temporary stay. On August 14, the Superior Court granted SanDisk’s request for a preliminary injunction. On August 18, Toshiba withdrew its appeal of the TRO, and filed a notice of appeal of the preliminary injunction.

[0000106040-17-000027:notes:268]
Copyright

[0000106040-17-000027:notes:269]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000027:notes:270]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000027:notes:271]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $155 million, inclusive of amounts accrued, if it does not prevail in this matter.

[0000106040-17-000027:notes:272]
Other Matters

[0000106040-17-000027:notes:273]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-17-000027:notes:274]
Recently Adopted Accounting Pronouncements

[0000106040-17-000027:notes:275]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015‑05, “Intangibles — Goodwill and Other — Internal‑Use Software (Subtopic 350‑40)” (“ASU 2015‑05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015‑05 at the beginning of the current year did not have a material impact on its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-17-000027:notes:276]
Organization and Basis of Presentation

[0000106040-17-000027:notes:277]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”) which is included in each of the three categories.

[0000106040-17-000027:notes:278]
Basis of Presentation

[0000106040-17-000027:notes:279]
Fiscal Year

[0000106040-17-000027:notes:280]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2017 and 2016, which ended on June 30, 2017 and July 1, 2016, respectively, both comprised 52 weeks, with all quarters consisting of 13 weeks. Fiscal year 2015, which ended on July 3, 2015, comprised 53 weeks, with the first quarter consisting of 14 weeks and the second, third and fourth quarters consisting of 13 weeks each.

[0000106040-17-000027:notes:281]
Basis of Consolidation

[0000106040-17-000027:notes:282]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in accumulated other comprehensive income, a component of stockholders’ equity.

[0000106040-17-000027:notes:283]
Reclassifications

[0000106040-17-000027:notes:284]
Certain prior year amounts have been reclassified in the consolidated statements of cash flows to conform to the current year presentation.

[0000106040-17-000027:notes:285]
Use of Estimates

[0000106040-17-000027:notes:286]
Management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-17-000027:notes:287]
Cash Equivalents

[0000106040-17-000027:notes:288]
The Company invests in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds, with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within short-term investments and other non-current assets in the Consolidated Balance Sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of shareholders’ equity. Gains and losses on available-for-sale securities are recorded based on the specific identification method. The Company evaluates the available-for-sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in total other expense, net in the consolidated statements of operations. In addition, realized gains and losses are included in total other expense, net in the consolidated statements of operations.

[0000106040-17-000027:notes:289]
Equity Investments

[0000106040-17-000027:notes:290]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income (expense), net, in the Consolidated Statement of Operations.

[0000106040-17-000027:notes:291]
The Company accounts for investments in equity securities of other entities under the cost method of accounting if the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee. Investments accounted for under the cost method of accounting are recorded within Other non-current assets in the Consolidated Balance Sheets and are also periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-17-000027:notes:292]
Variable Interest Entities

[0000106040-17-000027:notes:293]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-17-000027:notes:294]
Fair Value of Financial Instruments

[0000106040-17-000027:notes:295]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-17-000027:notes:296]
Property, Plant and Equipment

[0000106040-17-000027:notes:297]
Property and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty-five years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-17-000027:notes:298]
Business Combinations

[0000106040-17-000027:notes:299]
The application of acquisition accounting to a business combination requires that the Company identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date using a combination of valuation techniques, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the excess purchase price are based upon preliminary estimates and assumptions and subject to revision when the Company receives final information, including appraisals and other analyses. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. The Company will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-17-000027:notes:300]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. The Company recognizes the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). The Company’s assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-17-000027:notes:301]
Goodwill and Other Long-Lived Assets

[0000106040-17-000027:notes:302]
Revenue and Accounts Receivable

[0000106040-17-000027:notes:303]
Revenue is recognized when the title and risk of loss have passed to the customer, there is persuasive evidence of an arrangement, delivery has occurred, or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured. The Company establishes provisions against revenue and cost of revenue for estimated sales returns in the same period that the related revenue is recognized based on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-17-000027:notes:304]
In accordance with standard industry practice, the Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return and the Company provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. At the time the Company recognizes revenue to resellers and OEMs, a reduction of revenue is recorded for estimated price protection and/or returns until the resellers sell such inventory to their customers and the Company also records a reduction of revenue for the other programs in effect. The Company bases these adjustments on several factors including anticipated price decreases during the reseller holding period, reseller’s sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for the Company’s products or market conditions differ from the Company’s expectations, the Company’s operating results could be materially affected. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue.

[0000106040-17-000027:notes:305]
Revenue from patent licensing arrangements is recognized when earned, estimable and realizable. The timing of revenue recognition is dependent on the terms of each license agreement and on the timing of sales of licensed products. The Company generally recognizes royalty revenue when it is reported to the Company by its licensees, which is generally one quarter in arrears from the licensees’ sales of licensed products. For licensing fees that are not determined by the licensees’ sales, the Company generally recognizes license fee revenue on a straight-line basis over the life of the license.

[0000106040-17-000027:notes:306]
Some of the Company’s revenue arrangements are multiple-element arrangements because they are generally comprised of product, software and support services or multiple distinct licenses. For multiple-element arrangements, the Company evaluates whether each deliverable should be accounted for as a separate unit of accounting. For multiple-element arrangements that include support or software elements, the Company analyzes whether tangible products containing software and non-software components function together and therefore should be excluded from industry-specific software revenue recognition guidance. For all multiple-element arrangements, the Company allocates revenue to each element, or the software elements as a group, based on the relative selling price determined in accordance with the Company’s normal pricing and discounting practices for the specific element when sold separately. For multiple-element license agreements that include more than one license to distinct technology that are separate units of accounting, the Company allocates revenue to each license based on the relative selling price of each deliverable. License fees related to existing technology with no continuing performance obligations are generally recognized upon license commencement and other license fees are generally recognized on a straight-line basis over the life of the license. The Company primarily uses an estimate of selling price to allocate revenue for multiple-element license agreements based upon similar licenses, historical and estimated future sales volume, duration and market conditions.

[0000106040-17-000027:notes:307]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-17-000027:notes:308]
Warranty

[0000106040-17-000027:notes:309]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected.

[0000106040-17-000027:notes:310]
Litigation and Other Contingencies

[0000106040-17-000027:notes:311]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 17, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-17-000027:notes:312]
Advertising Expense

[0000106040-17-000027:notes:313]
Research and Development Expense

[0000106040-17-000027:notes:314]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-17-000027:notes:315]
Income Taxes

[0000106040-17-000027:notes:316]
Income per Common Share

[0000106040-17-000027:notes:317]
Stock-based Compensation

[0000106040-17-000027:notes:318]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. The Company accounts for stock appreciation rights (“SARs”) as liability awards based upon management’s intention to settle such awards in cash. All SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. The Company is required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and the results of operations could be materially affected. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics. Once the performance metrics are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period.

[0000106040-17-000027:notes:319]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-17-000027:notes:320]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, available-for-sale securities, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-17-000027:notes:321]
Derivative Contracts

[0000106040-17-000027:notes:322]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-17-000027:notes:323]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. See Note 8, Pension and Other Post-Retirement Benefit Plans, for additional disclosures related to the Company’s pensions and other post-retirement benefit plans.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-17-000027:notes:324]
Pension and Other Post-Retirement Benefit Plans

[0000106040-17-000027:notes:325]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Consolidated Financial Statements.

[0000106040-17-000027:notes:326]
Obligations and Funded Status

[0000106040-17-000027:notes:327]
The following table presents the unfunded amounts related to the Japanese Plan as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-17-000027:notes:328]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | — |  |
| Non-current liabilities | 59 |  |  | 114 |  |
| Net amount recognized | $ | 60 |  |  | $ | 114 |  |

[0000106040-17-000027:notes:329]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $249 million at June 30, 2017. As of June 30, 2017, actuarial gains for the Japanese defined benefit pension plans of $16 million are included in Accumulated other comprehensive income (loss) in the Consolidated Balance Sheet. There were no prior service credits for the defined benefit pension plans recognized in Accumulated other comprehensive income (loss) in the Consolidated Balance Sheet as of June 30, 2017.

[0000106040-17-000027:notes:330]
Assumptions

[0000106040-17-000027:notes:331]
Weighted-Average Assumptions

[0000106040-17-000027:notes:332]
The weighted-average actuarial assumptions used to determine benefit obligations for the Japanese defined benefit pension plans were as follows:

[0000106040-17-000027:notes:333]
|  | 2017 |  | 2016 |  | 2015 |
| Discount rate | 0.8 | % |  | 0.4 | % |  | 1.3 | % |
| Rate of compensation increase | 0.8 | % |  | 0.8 | % |  | 0.9 | % |

[0000106040-17-000027:notes:334]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows:

[0000106040-17-000027:notes:335]
|  | 2017 |  | 2016 |  | 2015 |
| Discount rate | 0.4 | % |  | 1.3 | % |  | 1.6 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 3.5 | % |
| Rate of compensation increase | 0.8 | % |  | 0.9 | % |  | 1.0 | % |

[0000106040-17-000027:notes:336]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to bond ratings that are “AA” or higher which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-17-000027:notes:337]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-17-000027:notes:338]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-17-000027:notes:339]
Plan Assets

[0000106040-17-000027:notes:340]
Investment Policies and Strategies

[0000106040-17-000027:notes:341]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 62% in debt securities, 35% in equity securities, and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-17-000027:notes:342]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-17-000027:notes:343]
Fair Value Measurements

[0000106040-17-000027:notes:344]
The following tables present the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 30, 2017 and July 1, 2016:

[0000106040-17-000027:notes:345]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 116 |  |  | — |  |  | 116 |  |
| Cash equivalents and short-term investments | 2 |  |  | 4 |  |  | — |  |  | 6 |  |
| Fair value of plan assets | $ | 2 |  |  | $ | 187 |  |  | $ | — |  |  | $ | 189 |  |

[0000106040-17-000027:notes:346]
|  | July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 72 |  |  | $ | — |  |  | $ | 72 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 129 |  |  | — |  |  | 129 |  |
| Cash equivalents and short-term investments | 8 |  |  | 3 |  |  | — |  |  | 11 |  |
| Fair value of plan assets | $ | 8 |  |  | $ | 204 |  |  | $ | — |  |  | $ | 212 |  |

[0000106040-17-000027:notes:347]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-17-000027:notes:348]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-17-000027:notes:349]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-17-000027:notes:350]
Assets held in defined benefit plans in the Philippines, Taiwan and Thailand were less than $1 million and are not presented in the above tables.

[0000106040-17-000027:notes:351]
There were no significant movements of assets between any level categories in 2017, 2016 or 2015.

[0000106040-17-000027:notes:352]
Fair Value Valuation Techniques

[0000106040-17-000027:notes:353]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-17-000027:notes:354]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-17-000027:notes:355]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-17-000027:notes:356]
Cash Flows

[0000106040-17-000027:notes:357]
Contributions

[0000106040-17-000027:notes:358]
The Company’s expected employer contributions for 2018 are $8 million for its Japanese defined benefit pension plans.

[0000106040-17-000027:notes:359]
Estimated Future Benefits Payments

[0000106040-17-000027:notes:360]
Annual benefit payments from the Japanese defined benefit pension plans are estimated to range from $6 million to $10 million annually over the next 5 years.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-17-000027:notes:361]
Property, plant, and equipment, net

[0000106040-17-000027:notes:362]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,855 |  |  | $ | 1,900 |  |
| Machinery and equipment | 6,868 |  |  | 6,915 |  |
| Software | 284 |  |  | 155 |  |
| Furniture and fixtures | 116 |  |  | 110 |  |
| Leasehold improvements | 259 |  |  | 307 |  |
| Construction-in-process | 144 |  |  | 245 |  |
| Property, plant, and equipment, gross | 9,526 |  |  | 9,632 |  |
| Accumulated depreciation | (6,493 | ) |  | (6,129 | ) |
| Property, plant, and equipment, net | $ | 3,033 |  |  | $ | 3,503 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-17-000027:notes:363]
Quarterly Results of Operations (unaudited)

[0000106040-17-000027:notes:364]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2017 |  |  |  |  |  |  |  |
| Revenue, net | $ | 4,714 |  |  | $ | 4,888 |  |  | $ | 4,649 |  |  | $ | 4,842 |  |
| Gross profit | 1,335 |  |  | 1,533 |  |  | 1,523 |  |  | 1,681 |  |
| Operating income | 232 |  |  | 545 |  |  | 525 |  |  | 652 |  |
| Net income (loss) | (366 | ) |  | 235 |  |  | 248 |  |  | 280 |  |
| Basic income (loss) per common share | $ | (1.28 | ) |  | $ | 0.82 |  |  | $ | 0.86 |  |  | $ | 0.96 |  |
| Diluted income (loss) per common share | $ | (1.28 | ) |  | $ | 0.80 |  |  | $ | 0.83 |  |  | $ | 0.93 |  |

[0000106040-17-000027:notes:365]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2016 |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,360 |  |  | $ | 3,317 |  |  | $ | 2,822 |  |  | $ | 3,495 |  |
| Gross profit | 955 |  |  | 906 |  |  | 753 |  |  | 821 |  |
| Operating income (loss) | 322 |  |  | 251 |  |  | 88 |  |  | (195 | ) |
| Net income (loss) | 283 |  |  | 251 |  |  | 74 |  |  | (366 | ) |
| Basic income (loss) per common share | $ | 1.23 |  |  | $ | 1.08 |  |  | $ | 0.32 |  |  | $ | (1.40 | ) |
| Diluted income (loss) per common share | $ | 1.21 |  |  | $ | 1.07 |  |  | $ | 0.32 |  |  | $ | (1.40 | ) |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-17-000027:notes:366]
The following table illustrates the significant amounts of each component reclassified out of AOCI to the Consolidated Statements of Operations:

[0000106040-17-000027:notes:367]
| AOCI Component |  | 2017 |  | 2016 |  | 2015 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on cash flow hedging activities: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 33 |  |  | $ | (17 | ) |  | $ | (44 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | (3 | ) |  | (34 | ) |  | — |  |  | Research and development |
| Total reclassifications for the period |  | $ | 30 |  |  | $ | (51 | ) |  | $ | (44 | ) |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-17-000027:notes:368]
The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-17-000027:notes:369]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Available for Sale Securities |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 3, 2015 | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | (25 | ) |  | $ | (20 | ) |
| Other comprehensive income (loss) before reclassifications | (73 | ) |  | 74 |  |  | — |  |  | 48 |  |  | 49 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | 51 |  |  | 51 |  |
| Income tax benefit related to items of other comprehensive income (loss) | 23 |  |  | — |  |  | — |  |  | — |  |  | 23 |  |
| Net current-period other comprehensive income (loss) | (50 | ) |  | 74 |  |  | — |  |  | 99 |  |  | 123 |  |
| Balance at July 1, 2016 | (45 | ) |  | 74 |  |  | — |  |  | 74 |  |  | 103 |  |
| Other comprehensive income (loss) before reclassifications | 39 |  |  | (115 | ) |  | 2 |  |  | (47 | ) |  | (121 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | (30 | ) |  | (30 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (12 | ) |  | 2 |  |  | — |  |  | — |  |  | (10 | ) |
| Net current-period other comprehensive income (loss) | 27 |  |  | (113 | ) |  | 2 |  |  | (77 | ) |  | (161 | ) |
| Balance at June 30, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | 2 |  |  | $ | (3 | ) |  | $ | (58 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-17-000027:notes:370]
| Condensed Consolidating Balance Sheet |
| As of June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 18 |  |  | $ | 1,212 |  |  | $ | 5,124 |  |  | $ | — |  |  | $ | 6,354 |  |
| Short-term investments | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Accounts receivable, net | — |  |  | 1,247 |  |  | 701 |  |  | — |  |  | 1,948 |  |
| Intercompany receivable | 1,225 |  |  | 2,528 |  |  | 622 |  |  | (4,375 | ) |  | — |  |
| Inventories | — |  |  | 1,133 |  |  | 1,494 |  |  | (286 | ) |  | 2,341 |  |
| Other current assets | 4 |  |  | 158 |  |  | 221 |  |  | 6 |  |  | 389 |  |
| Total current assets | 1,247 |  |  | 6,278 |  |  | 8,186 |  |  | (4,655 | ) |  | 11,056 |  |
| Property, plant and equipment, net | — |  |  | 1,124 |  |  | 1,909 |  |  | — |  |  | 3,033 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,340 |  |  | — |  |  | 1,340 |  |
| Goodwill | — |  |  | 331 |  |  | 9,683 |  |  | — |  |  | 10,014 |  |
| Other intangible assets, net | — |  |  | 11 |  |  | 3,812 |  |  | — |  |  | 3,823 |  |
| Investments in consolidated subsidiaries | 19,082 |  |  | 17,588 |  |  | — |  |  | (36,670 | ) |  | — |  |
| Loans due from consolidated affiliates | 4,700 |  |  | 16 |  |  | — |  |  | (4,716 | ) |  | — |  |
| Other non-current assets | 51 |  |  | 723 |  |  | 419 |  |  | (599 | ) |  | 594 |  |
| Total assets | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 257 |  |  | $ | 1,887 |  |  | $ | — |  |  | $ | 2,144 |  |
| Intercompany payable | 270 |  |  | 4,039 |  |  | 66 |  |  | (4,375 | ) |  | — |  |
| Accounts payable to Flash Ventures | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Accrued expenses | 270 |  |  | 360 |  |  | 439 |  |  | — |  |  | 1,069 |  |
| Accrued compensation | — |  |  | 313 |  |  | 193 |  |  | — |  |  | 506 |  |
| Accrued warranty | — |  |  | 4 |  |  | 182 |  |  | — |  |  | 186 |  |
| Current portion of long-term debt | 233 |  |  | — |  |  | — |  |  | — |  |  | 233 |  |
| Total current liabilities | 773 |  |  | 4,973 |  |  | 2,973 |  |  | (4,375 | ) |  | 4,344 |  |
| Long-term debt | 12,889 |  |  | — |  |  | 29 |  |  | — |  |  | 12,918 |  |
| Loans due to consolidated affiliates | — |  |  | 546 |  |  | 4,170 |  |  | (4,716 | ) |  | — |  |
| Other liabilities | — |  |  | 1,243 |  |  | 530 |  |  | (593 | ) |  | 1,180 |  |
| Total liabilities | 13,662 |  |  | 6,762 |  |  | 7,702 |  |  | (9,684 | ) |  | 18,442 |  |
| Total shareholders’ equity | 11,418 |  |  | 19,309 |  |  | 17,647 |  |  | (36,956 | ) |  | 11,418 |  |
| Total liabilities and shareholders’ equity | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |

[0000106040-17-000027:notes:371]
| Condensed Consolidating Balance Sheet |
| As of July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 1,206 |  |  | $ | 6,945 |  |  | $ | — |  |  | $ | 8,151 |  |
| Short-term investments | — |  |  | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Accounts receivable, net | — |  |  | 985 |  |  | 476 |  |  | — |  |  | 1,461 |  |
| Intercompany receivable | 934 |  |  | 886 |  |  | 2,546 |  |  | (4,366 | ) |  | — |  |
| Inventories | — |  |  | 896 |  |  | 1,450 |  |  | (217 | ) |  | 2,129 |  |
| Other current assets | 4 |  |  | 276 |  |  | 379 |  |  | (43 | ) |  | 616 |  |
| Total current assets | 938 |  |  | 4,249 |  |  | 12,023 |  |  | (4,626 | ) |  | 12,584 |  |
| Property, plant and equipment, net | — |  |  | 1,265 |  |  | 2,238 |  |  | — |  |  | 3,503 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,171 |  |  | — |  |  | 1,171 |  |
| Goodwill | — |  |  | 324 |  |  | 9,627 |  |  | — |  |  | 9,951 |  |
| Other intangible assets, net | — |  |  | 28 |  |  | 5,006 |  |  | — |  |  | 5,034 |  |
| Investments in consolidated subsidiaries | 18,009 |  |  | 27,020 |  |  | — |  |  | (45,029 | ) |  | — |  |
| Loans due from consolidated affiliates | 6,000 |  |  | 55 |  |  | — |  |  | (6,055 | ) |  | — |  |
| Other non-current assets | 50 |  |  | 33 |  |  | 702 |  |  | (166 | ) |  | 619 |  |
| Total assets | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 239 |  |  | $ | 1,649 |  |  | $ | — |  |  | $ | 1,888 |  |
| Intercompany payable | 119 |  |  | 4,043 |  |  | 204 |  |  | (4,366 | ) |  | — |  |
| Accounts payable to Flash Ventures | — |  |  | — |  |  | 168 |  |  | — |  |  | 168 |  |
| Accrued expenses | 109 |  |  | 462 |  |  | 404 |  |  | 20 |  |  | 995 |  |
| Accrued compensation | — |  |  | 222 |  |  | 170 |  |  | — |  |  | 392 |  |
| Accrued warranty | — |  |  | 4 |  |  | 168 |  |  | — |  |  | 172 |  |
| Bridge loan | — |  |  | 2,995 |  |  | — |  |  | — |  |  | 2,995 |  |
| Current portion of long-term debt | 14 |  |  | — |  |  | 325 |  |  | — |  |  | 339 |  |
| Total current liabilities | 242 |  |  | 7,965 |  |  | 3,088 |  |  | (4,346 | ) |  | 6,949 |  |
| Long-term debt | 13,610 |  |  | — |  |  | 50 |  |  | — |  |  | 13,660 |  |
| Loans due to consolidated affiliates | — |  |  | 6,000 |  |  | 55 |  |  | (6,055 | ) |  | — |  |
| Other liabilities | — |  |  | 862 |  |  | 475 |  |  | (229 | ) |  | 1,108 |  |
| Total liabilities | 13,852 |  |  | 14,827 |  |  | 3,668 |  |  | (10,630 | ) |  | 21,717 |  |
| Total shareholders’ equity | 11,145 |  |  | 18,147 |  |  | 27,099 |  |  | (45,246 | ) |  | 11,145 |  |
| Total liabilities and shareholders’ equity | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-17-000027:notes:372]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (360 | ) |  | $ | (836 | ) |  | $ | 4,593 |  |  | $ | 40 |  |  | $ | 3,437 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (240 | ) |  | (338 | ) |  | — |  |  | (578 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Purchases of investments | — |  |  | — |  |  | (281 | ) |  | — |  |  | (281 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 94 |  |  | — |  |  | 94 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 417 |  |  | — |  |  | 417 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (549 | ) |  | — |  |  | (549 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 292 |  |  | — |  |  | 292 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | (31 | ) |  | — |  |  | (32 | ) |
| Intercompany loan from consolidated affiliates | 1,300 |  |  | 39 |  |  | — |  |  | (1,339 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (158 | ) |  | 166 |  |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,142 |  |  | (36 | ) |  | (395 | ) |  | (1,347 | ) |  | (636 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 235 |  |  | — |  |  | — |  |  | — |  |  | 235 |  |
| Taxes paid on vested stock awards under employee stock plans | (124 | ) |  | — |  |  | — |  |  | — |  |  | (124 | ) |
| Excess tax benefits from employee stock plans | 119 |  |  | — |  |  | — |  |  | — |  |  | 119 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Settlement of convertible debt | — |  |  | — |  |  | (492 | ) |  | — |  |  | (492 | ) |
| Dividends paid to shareholders | (574 | ) |  | — |  |  | — |  |  | — |  |  | (574 | ) |
| Settlement of debt hedge contracts | — |  |  | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Repayment of debt | (8,702 | ) |  | (2,995 | ) |  | — |  |  | — |  |  | (11,697 | ) |
| Proceeds from debt | 7,908 |  |  | — |  |  | — |  |  | — |  |  | 7,908 |  |
| Debt issuance costs | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Intercompany loan from (to) consolidated affiliates | — |  |  | (5,454 | ) |  | 4,115 |  |  | 1,339 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 384 |  |  | 9,348 |  |  | (9,700 | ) |  | (32 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (764 | ) |  | 878 |  |  | (6,016 | ) |  | 1,307 |  |  | (4,595 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | 18 |  |  | 6 |  |  | (1,821 | ) |  | — |  |  | (1,797 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of year | $ | 18 |  |  | $ | 1,212 |  |  | $ | 5,124 |  |  | $ | — |  |  | $ | 6,354 |  |

[0000106040-17-000027:notes:373]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (210 | ) |  | $ | 1,018 |  |  | $ | 1,299 |  |  | $ | (124 | ) |  | $ | 1,983 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (233 | ) |  | (351 | ) |  | — |  |  | (584 | ) |
| Acquisitions, net of cash acquired | — |  |  | (13,767 | ) |  | 3,932 |  |  | — |  |  | (9,835 | ) |
| Purchases of investments | — |  |  | — |  |  | (632 | ) |  | — |  |  | (632 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 1,204 |  |  | — |  |  | 1,204 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 405 |  |  | — |  |  | 405 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (106 | ) |  | — |  |  | (106 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Strategic investments and other, net | (34 | ) |  | (10 | ) |  | (32 | ) |  | — |  |  | (76 | ) |
| Intercompany loans from (to) consolidated affiliates | (6,000 | ) |  | 40 |  |  | — |  |  | 5,960 |  |  | — |  |
| Advances to consolidated affiliates | (8,845 | ) |  | (96 | ) |  | (229 | ) |  | 9,170 |  |  | — |  |
| Net cash provided by (used in) investing activities | (14,879 | ) |  | (14,066 | ) |  | 4,207 |  |  | 15,130 |  |  | (9,608 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 117 |  |  | — |  |  | — |  |  | — |  |  | 117 |  |
| Taxes paid on vested stock awards under employee stock plans | (50 | ) |  | — |  |  | — |  |  | — |  |  | (50 | ) |
| Excess tax benefits from employee stock plans | 7 |  |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 409 |  |  | — |  |  | 409 |  |
| Settlement of convertible debt | — |  |  | — |  |  | (2,611 | ) |  | — |  |  | (2,611 | ) |
| Repurchases of common stock | (60 | ) |  | — |  |  | — |  |  | — |  |  | (60 | ) |
| Proceeds from revolving credit facility | — |  |  | 125 |  |  | — |  |  | — |  |  | 125 |  |
| Repayment of revolving credit facility | — |  |  | (125 | ) |  | (255 | ) |  | — |  |  | (380 | ) |
| Dividends paid to shareholders | (464 | ) |  | — |  |  | — |  |  | — |  |  | (464 | ) |
| Repayment of debt | — |  |  | (2,313 | ) |  | — |  |  | — |  |  | (2,313 | ) |
| Proceeds from debt | 14,108 |  |  | 3,000 |  |  | — |  |  | — |  |  | 17,108 |  |
| Debt issuance costs | (497 | ) |  | (27 | ) |  | — |  |  | — |  |  | (524 | ) |
| Payment upon settlement of acquired warrants | — |  |  | — |  |  | (613 | ) |  | — |  |  | (613 | ) |
| Intercompany loan from (to) consolidated affiliates | — |  |  | 6,000 |  |  | (40 | ) |  | (5,960 | ) |  | — |  |
| Change in investment in consolidated subsidiaries | 1,928 |  |  | 6,933 |  |  | 185 |  |  | (9,046 | ) |  | — |  |
| Net cash provided by (used in) financing activities | 15,089 |  |  | 13,593 |  |  | (2,925 | ) |  | (15,006 | ) |  | 10,751 |  |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase in cash and cash equivalents | — |  |  | 545 |  |  | 2,582 |  |  | — |  |  | 3,127 |  |
| Cash and cash equivalents, beginning of year | — |  |  | 661 |  |  | 4,363 |  |  | — |  |  | 5,024 |  |
| Cash and cash equivalents, end of year | $ | — |  |  | $ | 1,206 |  |  | $ | 6,945 |  |  | $ | — |  |  | $ | 8,151 |  |

[0000106040-17-000027:notes:374]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended July 3, 2015 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 23 |  |  | $ | 150 |  |  | $ | 2,066 |  |  | $ | 3 |  |  | $ | 2,242 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (189 | ) |  | (423 | ) |  | — |  |  | (612 | ) |
| Acquisitions, net of cash acquired | — |  |  | (16 | ) |  | (241 | ) |  | — |  |  | (257 | ) |
| Purchases of investments | — |  |  | (130 | ) |  | (727 | ) |  | — |  |  | (857 | ) |
| Proceeds from sale of investments | — |  |  | 463 |  |  | 42 |  |  | — |  |  | 505 |  |
| Proceeds from maturities of investments | — |  |  | 167 |  |  | 96 |  |  | — |  |  | 263 |  |
| Strategic investments and other, net | — |  |  | 6 |  |  | (1 | ) |  | — |  |  | 5 |  |
| Return of capital from subsidiaries | — |  |  | 255 |  |  | — |  |  | (255 | ) |  | — |  |
| Intercompany loan to consolidated affiliates | — |  |  | (60 | ) |  | — |  |  | 60 |  |  | — |  |
| Advances to (from) parent and consolidated affiliates | 1,015 |  |  | (114 | ) |  | 2 |  |  | (903 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,015 |  |  | 382 |  |  | (1,252 | ) |  | (1,098 | ) |  | (953 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 212 |  |  | — |  |  | — |  |  | — |  |  | 212 |  |
| Taxes paid on vested stock awards under employee stock plans | (64 | ) |  | — |  |  | — |  |  | — |  |  | (64 | ) |
| Excess tax benefits from employee stock plans | 19 |  |  | — |  |  | — |  |  | — |  |  | 19 |  |
| Repurchases of common stock | (970 | ) |  | — |  |  | — |  |  | — |  |  | (970 | ) |
| Dividends paid to shareholders | (396 | ) |  | — |  |  | — |  |  | — |  |  | (396 | ) |
| Repayment of debt | — |  |  | (125 | ) |  | — |  |  | — |  |  | (125 | ) |
| Proceeds from debt | — |  |  | — |  |  | 255 |  |  | — |  |  | 255 |  |
| Return of capital to parent | — |  |  | — |  |  | (255 | ) |  | 255 |  |  | — |  |
| Intercompany loan from parent | — |  |  | — |  |  | 60 |  |  | (60 | ) |  | — |  |
| Change in investment in consolidated subsidiaries | 161 |  |  | (1,071 | ) |  | 10 |  |  | 900 |  |  | — |  |
| Net cash provided by (used in) financing activities | (1,038 | ) |  | (1,196 | ) |  | 70 |  |  | 1,095 |  |  | (1,069 | ) |
| Net increase (decrease) in cash and cash equivalents | — |  |  | (664 | ) |  | 884 |  |  | — |  |  | 220 |  |
| Cash and cash equivalents, beginning of year | — |  |  | 1,325 |  |  | 3,479 |  |  | — |  |  | 4,804 |  |
| Cash and cash equivalents, end of year | $ | — |  |  | $ | 661 |  |  | $ | 4,363 |  |  | $ | — |  |  | $ | 5,024 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-17-000027:notes:375]
Separate Financial Information of Guarantor Subsidiaries

[0000106040-17-000027:notes:376]
The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The New Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by the WD Guarantors (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the designation of a Guarantor Subsidiary as an unrestricted subsidiary under the indenture governing the New Unsecured Notes, (ii) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the New Unsecured Notes, (iii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the New Unsecured Notes, (iv) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (v) the Company’s exercise of its defeasance options under the indenture governing the New Unsecured Notes, (vi) the dissolution or liquidation of a Guarantor Subsidiary or (vii) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the New Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-17-000027:notes:377]
For more information regarding the New Unsecured Notes, refer to Note 6, Debt.

[0000106040-17-000027:notes:378]
| Condensed Consolidating Statement of Operations |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,732 |  |  | $ | 16,381 |  |  | $ | (12,020 | ) |  | $ | 19,093 |  |
| Cost of revenue | — |  |  | 12,786 |  |  | 12,203 |  |  | (11,968 | ) |  | 13,021 |  |
| Gross profit | — |  |  | 1,946 |  |  | 4,178 |  |  | (52 | ) |  | 6,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,619 |  |  | 822 |  |  | — |  |  | 2,441 |  |
| Selling, general and administrative | 6 |  |  | 1,006 |  |  | 433 |  |  | — |  |  | 1,445 |  |
| Intercompany operating expense (income) | — |  |  | (1,736 | ) |  | 1,736 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 88 |  |  | 144 |  |  | — |  |  | 232 |  |
| Total operating expenses | 6 |  |  | 977 |  |  | 3,135 |  |  | — |  |  | 4,118 |  |
| Operating income (loss) | (6 | ) |  | 969 |  |  | 1,043 |  |  | (52 | ) |  | 1,954 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 347 |  |  | 11 |  |  | 22 |  |  | (354 | ) |  | 26 |  |
| Interest expense | (843 | ) |  | (10 | ) |  | (348 | ) |  | 354 |  |  | (847 | ) |
| Other income (expense), net | (290 | ) |  | 49 |  |  | (61 | ) |  | (62 | ) |  | (364 | ) |
| Total interest and other income (expense), net | (786 | ) |  | 50 |  |  | (387 | ) |  | (62 | ) |  | (1,185 | ) |
| Income (loss) before taxes | (792 | ) |  | 1,019 |  |  | 656 |  |  | (114 | ) |  | 769 |  |
| Income tax expense (benefit) | (282 | ) |  | 259 |  |  | 395 |  |  | — |  |  | 372 |  |
| Equity in earnings from subsidiaries | 907 |  |  | 287 |  |  | — |  |  | (1,194 | ) |  | — |  |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |

[0000106040-17-000027:notes:379]
| Condensed Consolidating Statement of Operations |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 12,600 |  |  | $ | 13,285 |  |  | $ | (12,891 | ) |  | $ | 12,994 |  |
| Cost of revenue | — |  |  | 11,796 |  |  | 10,662 |  |  | (12,899 | ) |  | 9,559 |  |
| Gross profit | — |  |  | 804 |  |  | 2,623 |  |  | 8 |  |  | 3,435 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,095 |  |  | 532 |  |  | — |  |  | 1,627 |  |
| Selling, general and administrative | 4 |  |  | 645 |  |  | 348 |  |  | — |  |  | 997 |  |
| Intercompany operating expense (income) | — |  |  | (1,087 | ) |  | 1,087 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 105 |  |  | 240 |  |  | — |  |  | 345 |  |
| Total operating expenses | 4 |  |  | 758 |  |  | 2,207 |  |  | — |  |  | 2,969 |  |
| Operating income (loss) | (4 | ) |  | 46 |  |  | 416 |  |  | 8 |  |  | 466 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 54 |  |  | 2 |  |  | 24 |  |  | (54 | ) |  | 26 |  |
| Interest expense | (184 | ) |  | (128 | ) |  | (8 | ) |  | 54 |  |  | (266 | ) |
| Other income (expense), net | 11 |  |  | (30 | ) |  | (54 | ) |  | — |  |  | (73 | ) |
| Total interest and other expense, net | (119 | ) |  | (156 | ) |  | (38 | ) |  | — |  |  | (313 | ) |
| Income (loss) before taxes | (123 | ) |  | (110 | ) |  | 378 |  |  | 8 |  |  | 153 |  |
| Income tax benefit | (44 | ) |  | (27 | ) |  | (18 | ) |  | — |  |  | (89 | ) |
| Equity in earnings from subsidiaries | 321 |  |  | 400 |  |  | — |  |  | (721 | ) |  | — |  |
| Net income | $ | 242 |  |  | $ | 317 |  |  | $ | 396 |  |  | $ | (713 | ) |  | $ | 242 |  |

[0000106040-17-000027:notes:380]
| Condensed Consolidating Statement of Operations |
| For the year ended July 3, 2015 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,942 |  |  | $ | 15,356 |  |  | $ | (15,726 | ) |  | $ | 14,572 |  |
| Cost of revenue | — |  |  | 14,086 |  |  | 11,935 |  |  | (15,670 | ) |  | 10,351 |  |
| Gross profit | — |  |  | 856 |  |  | 3,421 |  |  | (56 | ) |  | 4,221 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,191 |  |  | 455 |  |  | — |  |  | 1,646 |  |
| Selling, general and administrative | 4 |  |  | 548 |  |  | 236 |  |  | — |  |  | 788 |  |
| Intercompany operating expense (income) | — |  |  | (1,237 | ) |  | 1,237 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges | — |  |  | 49 |  |  | 127 |  |  | — |  |  | 176 |  |
| Total operating expenses | 4 |  |  | 551 |  |  | 2,055 |  |  | — |  |  | 2,610 |  |
| Operating income (loss) | (4 | ) |  | 305 |  |  | 1,366 |  |  | (56 | ) |  | 1,611 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 3 |  |  | 12 |  |  | (1 | ) |  | 14 |  |
| Interest expense | — |  |  | (46 | ) |  | (4 | ) |  | 1 |  |  | (49 | ) |
| Other income (expense), net | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total other expense, net | — |  |  | (43 | ) |  | 9 |  |  | — |  |  | (34 | ) |
| Income (loss) before income taxes | (4 | ) |  | 262 |  |  | 1,375 |  |  | (56 | ) |  | 1,577 |  |
| Income tax expense (benefit) | (1 | ) |  | 108 |  |  | 5 |  |  | — |  |  | 112 |  |
| Equity in earnings from consolidated subsidiaries | 1,468 |  |  | 1,381 |  |  | — |  |  | (2,849 | ) |  | — |  |
| Net income | $ | 1,465 |  |  | $ | 1,535 |  |  | $ | 1,370 |  |  | $ | (2,905 | ) |  | $ | 1,465 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-17-000027:notes:381]
|  | June 30, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 646 |  |  | $ | 569 |  |
| Work-in-process | 632 |  |  | 589 |  |
| Finished goods | 1,063 |  |  | 971 |  |
| Total inventories | $ | 2,341 |  |  | $ | 2,129 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-17-000027:notes:382]
Product warranty liability

[0000106040-17-000027:notes:383]
Changes in the warranty accrual were as follows:

[0000106040-17-000027:notes:384]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 279 |  |  | $ | 221 |  |  | $ | 182 |  |
| Warranty liabilities assumed as a result of acquisitions | — |  |  | 45 |  |  | 1 |  |
| Charges to operations | 177 |  |  | 162 |  |  | 187 |  |
| Utilization | (151 | ) |  | (178 | ) |  | (190 | ) |
| Changes in estimate related to pre-existing warranties | 6 |  |  | 29 |  |  | 41 |  |
| Warranty accrual, end of period | $ | 311 |  |  | $ | 279 |  |  | $ | 221 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-17-000027:notes:385]
The Company recorded the following charges related to employee terminations benefits, asset impairment, and other charges:

[0000106040-17-000027:notes:386]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 128 |  |  | $ | 77 |  |  | $ | — |  |
| Closure of Foreign Manufacturing Facility | 10 |  |  | 128 |  |  | — |  |
| Business Realignment | 72 |  |  | 94 |  |  | 94 |  |
| Total employee termination and other charges | 210 |  |  | 299 |  |  | 94 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |
| Business Realignment | 11 |  |  | 9 |  |  | — |  |
| Total stock-based compensation accelerations and adjustments | 11 |  |  | 9 |  |  | — |  |
| Asset impairment: |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | 5 |  |  | — |  |
| Closure of Foreign Manufacturing Facility | 11 |  |  | 24 |  |  | — |  |
| Business Realignment | — |  |  | 8 |  |  | 82 |  |
| Total asset impairment | 11 |  |  | 37 |  |  | 82 |  |
| Total employee termination and other charges, stock-based compensation adjustments and asset impairments | $ | 232 |  |  | $ | 345 |  |  | $ | 176 |  |

[0000106040-17-000027:notes:387]
The following table presents an analysis of the components of the activity against the reserve:

[0000106040-17-000027:notes:388]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 3, 2015 | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Charges | 65 |  |  | 29 |  |  | 94 |  |
| Cash payments | (58 | ) |  | (23 | ) |  | (81 | ) |
| Non-cash items and other | (6 | ) |  | (3 | ) |  | (9 | ) |
| Accrual balance at July 1, 2016 | 11 |  |  | 3 |  |  | 14 |  |
| Charges | 68 |  |  | 4 |  |  | 72 |  |
| Cash payments | (74 | ) |  | (2 | ) |  | (76 | ) |
| Non-cash items and other | 13 |  |  | — |  |  | 13 |  |
| Accrual balance at June 30, 2017 | $ | 18 |  |  | $ | 5 |  |  | $ | 23 |  |

[0000106040-17-000027:notes:389]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Charges | $ | 58 |  |  | $ | 19 |  |  | $ | 77 |  |
| Cash payments | (32 | ) |  | (19 | ) |  | (51 | ) |
| Accrual balance at July 1, 2016 | 26 |  |  | — |  |  | 26 |  |
| Charges | 84 |  |  | 44 |  |  | 128 |  |
| Cash payments | (99 | ) |  | (41 | ) |  | (140 | ) |
| Non-cash items and other | — |  |  | (1 | ) |  | (1 | ) |
| Accrual balance at June 30, 2017 | $ | 11 |  |  | $ | 2 |  |  | $ | 13 |  |

[0000106040-17-000027:notes:390]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Charges | $ | 119 |  |  | $ | 9 |  |  | $ | 128 |  |
| Cash payments | (104 | ) |  | (10 | ) |  | (114 | ) |
| Non-cash items and other | (1 | ) |  | 1 |  |  | — |  |
| Accrual balance at July 1, 2016 | 14 |  |  | — |  |  | 14 |  |
| Charges | 1 |  |  | 9 |  |  | 10 |  |
| Cash payments | (15 | ) |  | (12 | ) |  | (27 | ) |
| Non-cash items and other | — |  |  | 3 |  |  | 3 |  |
| Accrual balance at June 30, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-17-000027:notes:391]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-17-000027:notes:392]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 27, 2014 | 10.1 |  |  | $ | 37.03 |  |  |  |  |  |
| Granted | 1.2 |  |  | 94.10 |  |  |  |  |  |
| Assumed | 0.1 |  |  | 3.49 |  |  |  |  |  |
| Exercised | (4.1 | ) |  | 31.90 |  |  |  |  | $ | 283 |  |
| Canceled or expired | (0.5 | ) |  | 56.41 |  |  |  |  |  |
| Options outstanding at July 3, 2015 | 6.8 |  |  | 50.00 |  |  |  |  |  |
| Granted | 1.7 |  |  | 82.68 |  |  |  |  |  |
| Assumed | 2.9 |  |  | 38.37 |  |  |  |  |  |
| Exercised | (1.7 | ) |  | 27.43 |  |  |  |  | 57 |  |
| Canceled or expired | (0.7 | ) |  | 66.03 |  |  |  |  |  |
| Options outstanding at July 1, 2016 | 9.0 |  |  | 55.74 |  |  |  |  |  |
| Granted | 2.8 |  |  | 44.83 |  |  |  |  |  |
| Exercised | (3.5 | ) |  | 37.72 |  |  |  |  | 120 |  |
| Canceled or expired | (0.9 | ) |  | 71.31 |  |  |  |  |  |
| Options outstanding at June 30, 2017 | 7.4 |  |  | $ | 58.14 |  |  | 4.5 |  | $ | 240 |  |
| Exercisable at June 30, 2017 | 3.3 |  |  | $ | 62.38 |  |  | 3.1 |  | $ | 99 |  |
| Vested and expected to vest after June 30, 2017 | 7.2 |  |  | $ | 58.42 |  |  | 4.4 |  | $ | 231 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-17-000027:notes:393]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-17-000027:notes:394]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 27, 2014 | 3.7 |  |  | $ | 49.77 |  |  |  |
| Granted | 1.3 |  |  | 100.13 |  |  |  |
| Vested | (1.7 | ) |  | 42.24 |  |  | $ | 170 |  |
| Forfeited | (0.3 | ) |  | 67.31 |  |  |  |
| RSUs and PSUs outstanding at July 3, 2015 | 3.0 |  |  | 73.80 |  |  |  |
| Granted | 2.7 |  |  | 61.32 |  |  |  |
| Assumed | 12.5 |  |  | 32.14 |  |  |  |
| Vested | (2.0 | ) |  | 56.11 |  |  | 144 |  |
| Forfeited | (0.5 | ) |  | 62.09 |  |  |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | 41.92 |  |  |  |
| Granted | 6.0 |  |  | 44.13 |  |  |  |
| Vested | (5.9 | ) |  | 46.98 |  |  | 399 |  |
| Forfeited | (2.1 | ) |  | 43.89 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | $ | 45.01 |  |  |  |
| Expected to vest after June 30, 2017 | 12.7 |  |  | $ | 45.13 |  |  |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000106040-17-000027:notes:395]
|  | Allowance for Doubtful Accounts |
|  | (in millions) |
| Balance at July 3, 2015 | $ | 7 |  |
| Balance assumed as a result of SanDisk acquisition | 6 |  |
| Deductions | (3 | ) |
| Balance at July 1, 2016 | 10 |  |
| Additions charged to operations | 3 |  |
| Deductions | (3 | ) |
| Balance at June 30, 2017 | $ | 10 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-17-000027:notes:396]
Shareholders’ Equity

[0000106040-17-000027:notes:397]
Stock Incentive Plans

[0000106040-17-000027:notes:398]
2004 Performance Incentive Plan

[0000106040-17-000027:notes:399]
The types of awards that may be granted under the Western Digital Corporation Amended and Restated 2004 Performance Incentive Plan (“2004 Performance Incentive Plan”) include stock options, SARs, RSUs, PSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2004 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2004 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2004 Performance Incentive Plan is ten-years after the grant date of the award. RSUs granted under the 2004 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics and completion of requisite service periods. Once the performance metrics are met, vesting of PSUs is generally subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-17-000027:notes:400]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-17-000027:notes:401]
As of June 30, 2017, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2004 Performance Incentive Plan was 65.8 million shares. Shares issued in respect of stock options and SARs granted under the 2004 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas currently, shares issued in respect of any other type of award granted count against the plan’s share limit as 1.72 shares for every one share issued in connection with such award. The 2004 Performance Incentive Plan was extended in 2013 and will terminate on August 4, 2025 unless terminated earlier by the Company’s Board of Directors (the “Board”).

[0000106040-17-000027:notes:402]
Acquired Plan

[0000106040-17-000027:notes:403]
In connection with the Merger, the Company assumed 14.4 million shares that were available to be granted to SanDisk employees under the SanDisk 2013 Incentive Plan. The Company also assumed outstanding stock options and RSUs which were converted into equivalent stock options and RSUs with respect to shares of the Company’s common stock using the equity award exchange ratio as defined in the merger agreement with SanDisk. Options eligible for exercise may be exercised for shares of the Company’s common stock at any time prior to the expiration of the seven-year option term or any earlier termination of those options in connection with the optionee’s cessation of service with the Company. Outstanding RSU awards under the SanDisk 2013 Incentive Plan have dividend equivalent rights which entitle holders of RSUs to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. Dividend equivalent rights are accumulated and paid when the underlying shares vest.

[0000106040-17-000027:notes:404]
Employee Stock Purchase Plan

[0000106040-17-000027:notes:405]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock on either the first day of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-17-000027:notes:406]
Stock-based Compensation Expense

[0000106040-17-000027:notes:407]
Compensation cost related to unvested stock options, RSU’s, PSUs and ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 30, 2017.

[0000106040-17-000027:notes:408]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 60 |  |  | 2.6 |
| RSUs and PSUs (1) | 461 |  |  | 2.3 |
| ESPP | 31 |  |  | 1.0 |

[0000106040-17-000027:notes:409]
(1) Weighted average service period assumes the performance metrics are met for the PSUs.

[0000106040-17-000027:notes:410]
Plan Activities

[0000106040-17-000027:notes:411]
Stock Options

[0000106040-17-000027:notes:412]
RSU and PSU

[0000106040-17-000027:notes:413]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-17-000027:notes:414]
Vested Options, RSUs and PSUs

[0000106040-17-000027:notes:415]
The total grant date fair value of options, RSUs and PSUs vested during the period was as follows:

[0000106040-17-000027:notes:416]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| Options | $ | 41 |  |  | $ | 61 |  |  | $ | 62 |  |
| RSUs and PSUs | 261 |  |  | 113 |  |  | 65 |  |
| Total grant date fair value of options, RSUs and PSUs vested during the period | $ | 302 |  |  | $ | 174 |  |  | $ | 127 |  |

[0000106040-17-000027:notes:417]
SARs

[0000106040-17-000027:notes:418]
As of June 30, 2017, all outstanding SARs issued to employees were fully vested and will be settled in cash upon exercise. The fair value of SARs is solely subject to market price fluctuations. The following table presents the adjustments to the fair market value of SARs:

[0000106040-17-000027:notes:419]
|  | 2017 |  | 2016 |  | 2015 |
|  | (in millions) |
| SAR expense (benefit) | $ | 7 |  |  | $ | (18 | ) |  | $ | (3 | ) |
| Tax expense (benefit) | (1 | ) |  | 2 |  |  | — |  |
| Total SAR expense (benefit) | $ | 6 |  |  | $ | (16 | ) |  | $ | (3 | ) |

[0000106040-17-000027:notes:420]
The Company had a total liability of $2 million and $20 million related to SARs included in Accrued expenses in the Consolidated Balance Sheets as of June 30, 2017 and July 1, 2016, respectively. There were no SARs granted in 2017, 2016, and 2015 and as of June 30, 2017, an immaterial number of SARs were outstanding with a weighted average exercise price of $24.45.

[0000106040-17-000027:notes:421]
Fair Value Valuation Assumptions

[0000106040-17-000027:notes:422]
Stock Option Grants — Binomial Model

[0000106040-17-000027:notes:423]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of highly subjective assumptions. The Company uses historical data to estimate exercise, employee termination and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. The fair value of stock options granted was estimated using the following weighted average assumptions:

[0000106040-17-000027:notes:424]
|  | 2017 |  | 2016 |  | 2015 |
| Suboptimal exercise factor | 2.69 |  | 2.71 |  | 2.52 |
| Range of risk-free interest rates | 0.59% to 1.42% |  | 0.25% to 2.09% |  | 0.11% to 2.16% |
| Range of expected stock price volatility | 0.35 to 0.49 |  | 0.28 to 0.49 |  | 0.23 to 0.47 |
| Weighted-average expected volatility | 0.40 |  | 0.35 |  | 0.36 |
| Post-vesting termination rate | 1.71% |  | 0.47% |  | 1.25% |
| Dividend yield | 3.42% |  | 2.61% |  | 1.69% |
| Fair value | $13.72 |  | $22.54 |  | $32.19 |
| Weighted-average expected term (in years) | 3.6 |  | 4.7 |  | 5.8 |

[0000106040-17-000027:notes:425]
RSU and PSU Grants

[0000106040-17-000027:notes:426]
The fair value of the Company’s RSU and PSU awards granted, excluding unvested RSU awards assumed through acquisitions, was based upon the closing price of the Company’s stock price on the date of grant.

[0000106040-17-000027:notes:427]
ESPP — Black-Scholes-Merton Model

[0000106040-17-000027:notes:428]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-17-000027:notes:429]
The fair values of all outstanding ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-17-000027:notes:430]
|  | 2017 |  | 2016 |  | 2015 |
| Weighted-average expected term (in years) | 1.26 |  | 1.27 |  | 1.26 |
| Risk-free interest rate | 0.81% |  | 0.82% |  | 0.45% |
| Stock price volatility | 0.42 |  | 0.38 |  | 0.26 |
| Dividend yield | 4.02% |  | 3.92% |  | 2.34% |
| Fair value | $10.06 |  | $9.91 |  | $14.50 |

[0000106040-17-000027:notes:431]
Stock Repurchase Program

[0000106040-17-000027:notes:432]
The Company’s Board has authorized $5.00 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares of common stock during 2017. The remaining amount available to be purchased under the Company’s stock repurchase program as of June 30, 2017 was $2.10 billion.

[0000106040-17-000027:notes:433]
Stock Reserved for Issuance

[0000106040-17-000027:notes:434]
The following table summarizes all common stock reserved for issuance at June 30, 2017:

[0000106040-17-000027:notes:435]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 44 |  |
| ESPP | 7 |  |
| Total | 51 |  |

[0000106040-17-000027:notes:436]
Dividends to Shareholders

[0000106040-17-000027:notes:437]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. During 2017, the Company declared aggregate cash dividends of $2.00 per share on the Company’s outstanding common stock totaling $579 million, of which $432 million was paid in 2017 and $147 million was paid on July 17, 2017. The Company also paid $142 million in 2017 related to dividends accrued in 2016.

[0000106040-17-000027:notes:438]
On August 2, 2017, the Board declared a cash dividend of $0.50 per share to shareholders of record as of September 29, 2017, which will be paid on October 16, 2017.

[0000106040-17-000027:notes:439]
The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-17-000027:notes:440]
Supplemental Financial Statement Data

[0000106040-17-000027:notes:441]
Accounts receivable, net

[0000106040-17-000027:notes:442]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During 2017, the Company did not sell any trade accounts receivable. During 2016, the Company sold trade accounts receivable and received cash proceeds of $225 million. The discounts on the trade accounts receivable sold during 2016 were not material and were recorded within Other income (expense), net in the Consolidated Financial Statements.

[0000106040-17-000027:notes:443]
Depreciation expense of property, plant, and equipment totaled $960 million, $888 million and $809 million in 2017, 2016 and 2015, respectively.

[0000106040-17-000027:notes:444]
The long-term portion of the warranty accrual classified in Other liabilities was $125 million and $107 million as of June 30, 2017 and July 1, 2016, respectively.

[0000106040-17-000027:notes:445]
Accumulated other comprehensive income

[0000106040-17-000027:notes:446]
Other comprehensive income (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):


## wdc:DefinedContributionPlanDisclosureTextBlock

[0000106040-17-000027:notes:447]
Western Digital Corporation 401(k) Plan

[0000106040-17-000027:notes:448]
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire unless the individual is covered by a collective bargaining agreement, provides services as a consultant, intern, independent contractor, leased or temporary employee, or otherwise is not treated as a common-law employee.

[0000106040-17-000027:notes:449]
Eligible employees are generally able to contribute up to 30% of their eligible compensation on a pre-tax basis or 10% of their eligible compensation on an after-tax basis subject to Internal Revenue Service (“IRS”) limitations. The Company makes a basic matching contribution equal to 50% of the each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. The Company’s employer matching contributions vest over a two-year graded period. Prior to the amendment of the Plan on May 5, 2016, the Company’s employer matching contributions vested over a five-year graded period. The Company may suspend matching contributions at any time at its discretion. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-17-000027:notes:450]
For 2017, 2016 and 2015, the Company made Plan contributions of $36 million, $20 million and $22 million, respectively.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-17-000027:notes:451]
Employee Termination, Asset Impairment and Other Charges

[0000106040-17-000027:notes:452]
Restructuring Plan 2016

[0000106040-17-000027:notes:453]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 for employee termination, asset impairments and other charges, as presented above, the Company recognized $65 million and $22 million during 2017 and 2016, respectively, of accelerated depreciation on facility assets and other charges in cost of revenue and operating expense. The Company expects Restructuring Plan 2016 to be substantially completed by the end of calendar year 2017.

[0000106040-17-000027:notes:454]
Closure of Foreign Manufacturing Facility

[0000106040-17-000027:notes:455]
In January 2016, the Company announced the closing of its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. As of June 30, 2017, the Company had completed all activities related to the closure of the facility. The following table presents an analysis of the components of the activity against the reserve:

[0000106040-17-000027:notes:456]
Business Realignment

[0000106040-17-000027:notes:457]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve:
