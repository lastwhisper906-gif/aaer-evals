# WDC 8-K — 0001193125-17-238544 filed 2017-07-27

## item codes, every 8-K on or before 2017-08-29

- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2017-08-29

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-238544:8k_2_02:1]
EX-99.1
2
d396912dex991.htm
EX-99.1

[0001193125-17-238544:8k_2_02:2]
EX-99.1

[0001193125-17-238544:8k_2_02:3]
Exhibit 99.1

[0001193125-17-238544:8k_2_02:4]
FOR IMMEDIATE RELEASE:

[0001193125-17-238544:8k_2_02:5]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0001193125-17-238544:8k_2_02:6]
FOURTH FISCAL QUARTER AND FISCAL YEAR 2017

[0001193125-17-238544:8k_2_02:7]
SAN JOSE, Calif. — July 27, 2017 — Western Digital Corp. (NASDAQ: WDC) today reported revenue of $4.8 billion, operating income of
$652 million and net income of $280 million, or $0.93 per share, for its fourth fiscal quarter ended June 30, 2017. The GAAP net income for the period includes charges associated with the company’s recent acquisitions. Excluding
these charges and after other non-GAAP adjustments, fourth quarter non-GAAP operating income was $1.2 billion and non-GAAP
net income was $881 million, or $2.93 per share.

[0001193125-17-238544:8k_2_02:8]
In the year-ago quarter, the company
reported revenue of $3.5 billion, operating loss of $195 million and net loss of $366 million, or $(1.40) per share. Non-GAAP operating income in the
year-ago quarter was $451 million and non-GAAP net income was $269 million, or $1.02 per share.

[0001193125-17-238544:8k_2_02:9]
The company generated approximately $1.0 billion in cash from operations during the fourth fiscal quarter of 2017, ending with
$6.5 billion of total cash, cash equivalents and available-for-sale securities. On May 3, 2017, the company declared a cash dividend of $0.50 per share of its
common stock, which was paid to shareholders on July 17, 2017.

[0001193125-17-238544:8k_2_02:10]
For fiscal 2017, the company achieved revenue of $19.1 billion,
operating income of $2.0 billion and net income of $397 million, or $1.34 per share, compared to fiscal 2016 revenue of $13.0 billion, operating income of $466 million and net income of $242 million, or $1.00 per share. On a
non-GAAP basis, fiscal 2017 operating income was $3.9 billion and net income was $2.7 billion, or $9.19 per share, compared to fiscal 2016 operating income of $1.7 billion and net income of
$1.4 billion, or $5.79 per share. The company generated $3.4 billion in cash from operations during the 2017 fiscal year and it returned to shareholders $574 million in dividends.

[0001193125-17-238544:8k_2_02:11]
Western Digital Announces Financial Results for Fourth Fiscal Quarter and Fiscal Year 2017

[0001193125-17-238544:8k_2_02:12]
“We reported strong financial performance in the June quarter to complete an outstanding
fiscal 2017, demonstrating the differentiated value that we can deliver as a comprehensive data solutions provider,” said Steve Milligan, chief executive officer. “Our unique platform of diverse storage technologies and value-added
products helped drive this performance as we addressed a broader set of markets following the SanDisk acquisition. We operated near the top of our revenue growth model with 7 percent year-over-year
top-line growth on a pro-forma basis, and we delivered very healthy margins.”

[0001193125-17-238544:8k_2_02:13]
The investment community conference call to discuss these results and the company’s guidance for the first fiscal quarter 2018 will be
broadcast live over the Internet today at 2:30 p.m. Pacific/5:30 p.m. Eastern. The live and archived conference call/webcast can be accessed online at investor.wdc.com. Supplemental financial information, including the company’s guidance
for the first fiscal quarter 2018, will also be posted on the same website. The telephone replay number in the U.S. is 1(855) 859-2056 or +1(404) 537-3406 for
international callers. The required passcode is 54295696.

[0001193125-17-238544:8k_2_02:14]
About Western Digital

[0001193125-17-238544:8k_2_02:15]
Western Digital is an industry-leading provider of storage technologies and solutions that enable people to create, leverage, experience and
preserve data. The company addresses ever-changing market needs by providing a full portfolio of compelling, high-quality storage solutions with customer-focused innovation, high efficiency, flexibility and speed. Our products are marketed under the
HGST, SanDisk and WD brands to OEMs, distributors, resellers, cloud infrastructure providers and consumers. Financial and investor information is available on the company’s Investor Relations website at investor.wdc.com.

[0001193125-17-238544:8k_2_02:16]
Forward-Looking Statements

[0001193125-17-238544:8k_2_02:17]
Western Digital Announces Financial Results for Fourth Fiscal Quarter and Fiscal Year 2017

[0001193125-17-238544:8k_2_02:18]
expressed or implied in the forward-looking statements. The preliminary financial results for the company’s fourth fiscal quarter ended June 30, 2017 and fiscal 2017 included in this
press release represent the most current information available to management. The company’s actual results when disclosed in its Annual Report on Form 10-K may differ from these preliminary results as a
result of the completion of the company’s financial closing procedures; final adjustments; completion of the review by the company’s independent registered accounting firm and other developments that may arise between now and the
disclosure of the final results. Other risks and uncertainties that could cause actual results to differ materially from those expressed or implied in the forward-looking statements include: uncertainties with respect to the company’s business
ventures with Toshiba; volatility in global economic conditions; business conditions and growth in the storage ecosystem; impact of competitive products and pricing; market acceptance and cost of commodity materials and specialized product
components; actions by competitors; unexpected advances in competing technologies; our development and introduction of products based on new technologies and expansion into new data storage markets; risks associated with acquisitions, mergers and
joint ventures; difficulties or delays in manufacturing; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-Q filed with the SEC on May 8, 2017, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company
undertakes no obligation to update these forward-looking statements to reflect new information or events.

[0001193125-17-238544:8k_2_02:19]
###

[0001193125-17-238544:8k_2_02:20]
Western Digital, WD and SanDisk are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the U.S. and/or other countries.
Other trademarks, registered trademarks, and/or service marks, indicated or otherwise, are the property of their respective owners. © 2017 Western Digital Corporation or its affiliates. All
rights reserved.

[0001193125-17-238544:8k_2_02:21]
Company contacts:

[0001193125-17-238544:8k_2_02:22]
Western Digital Corp.

[0001193125-17-238544:8k_2_02:23]
Investor Contact:

[0001193125-17-238544:8k_2_02:24]
Bob Blair

[0001193125-17-238544:8k_2_02:25]
949.672.7834

[0001193125-17-238544:8k_2_02:26]
robert.blair@wdc.com

[0001193125-17-238544:8k_2_02:27]
Western Digital Announces Financial Results for Fourth Fiscal Quarter and Fiscal Year 2017

[0001193125-17-238544:8k_2_02:28]
Media Contact:

[0001193125-17-238544:8k_2_02:29]
Jim Pascoe

[0001193125-17-238544:8k_2_02:30]
408.717.6999

[0001193125-17-238544:8k_2_02:31]
jim.pascoe@wdc.com

[0001193125-17-238544:8k_2_02:32]
WESTERN DIGITAL CORPORATION

[0001193125-17-238544:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-238544:8k_2_02:34]
(in millions; unaudited)

[0001193125-17-238544:8k_2_02:35]
|  |  | June 30, |  |  | July 1, |  |
|  |  | 2017 |  |  | 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,354 |  |  | $ | 8,151 |  |
| Short-term investments |  |  | 24 |  |  |  | 227 |  |
| Accounts receivable, net |  |  | 1,948 |  |  |  | 1,461 |  |
| Inventories |  |  | 2,341 |  |  |  | 2,129 |  |
| Other current assets |  |  | 389 |  |  |  | 616 |  |
| Total current assets |  |  | 11,056 |  |  |  | 12,584 |  |
| Property, plant and equipment, net |  |  | 3,033 |  |  |  | 3,503 |  |
| Notes receivable and investments in Flash Ventures |  |  | 1,340 |  |  |  | 1,171 |  |
| Goodwill |  |  | 10,014 |  |  |  | 9,951 |  |
| Other intangible assets, net |  |  | 3,823 |  |  |  | 5,034 |  |
| Other non-current assets |  |  | 594 |  |  |  | 619 |  |
| Total assets |  | $ | 29,860 |  |  | $ | 32,862 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 2,144 |  |  | $ | 1,888 |  |
| Accounts payable to related parties |  |  | 206 |  |  |  | 168 |  |
| Accrued expenses |  |  | 1,069 |  |  |  | 995 |  |
| Accrued compensation |  |  | 506 |  |  |  | 392 |  |
| Accrued warranty |  |  | 186 |  |  |  | 172 |  |
| Bridge loan |  |  | — |  |  |  | 2,995 |  |
| Current portion of long-term debt |  |  | 233 |  |  |  | 339 |  |
| Total current liabilities |  |  | 4,344 |  |  |  | 6,949 |  |
| Long-term debt |  |  | 12,918 |  |  |  | 13,660 |  |
| Other liabilities |  |  | 1,180 |  |  |  | 1,108 |  |
| Total liabilities |  |  | 18,442 |  |  |  | 21,717 |  |
| Total shareholders’ equity |  |  | 11,418 |  |  |  | 11,145 |  |
| Total liabilities and shareholders’ equity |  | $ | 29,860 |  |  | $ | 32,862 |  |

[0001193125-17-238544:8k_2_02:36]
WESTERN DIGITAL CORPORATION

[0001193125-17-238544:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-238544:8k_2_02:38]
(in millions, except per share amounts; unaudited)

[0001193125-17-238544:8k_2_02:39]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 30, |  |  | July 1, |  |  | June 30, |  |  | July 1, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Revenue, net |  | $ | 4,842 |  |  | $ | 3,495 |  |  | $ | 19,093 |  |  | $ | 12,994 |  |
| Cost of revenue |  |  | 3,161 |  |  |  | 2,674 |  |  |  | 13,021 |  |  |  | 9,559 |  |
| Gross profit |  |  | 1,681 |  |  |  | 821 |  |  |  | 6,072 |  |  |  | 3,435 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 604 |  |  |  | 494 |  |  |  | 2,441 |  |  |  | 1,627 |  |
| Selling, general and administrative |  |  | 345 |  |  |  | 400 |  |  |  | 1,445 |  |  |  | 997 |  |
| Employee termination, asset impairment and other charges |  |  | 80 |  |  |  | 122 |  |  |  | 232 |  |  |  | 345 |  |
| Total operating expenses |  |  | 1,029 |  |  |  | 1,016 |  |  |  | 4,118 |  |  |  | 2,969 |  |
| Operating income (loss) |  |  | 652 |  |  |  | (195 | ) |  |  | 1,954 |  |  |  | 466 |  |
| Interest and other expense, net |  |  | (237 | ) |  |  | (290 | ) |  |  | (1,185 | ) |  |  | (313 | ) |
| Income (loss) before taxes |  |  | 415 |  |  |  | (485 | ) |  |  | 769 |  |  |  | 153 |  |
| Income tax expense (benefit) |  |  | 135 |  |  |  | (119 | ) |  |  | 372 |  |  |  | (89 | ) |
| Net income (loss) |  | $ | 280 |  |  | $ | (366 | ) |  | $ | 397 |  |  | $ | 242 |  |
| Income (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.96 |  |  | $ | (1.40 | ) |  | $ | 1.38 |  |  | $ | 1.01 |  |
| Diluted |  | $ | 0.93 |  |  | $ | (1.40 | ) |  | $ | 1.34 |  |  | $ | 1.00 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 292 |  |  |  | 261 |  |  |  | 288 |  |  |  | 239 |  |
| Diluted |  |  | 301 |  |  |  | 261 |  |  |  | 296 |  |  |  | 242 |  |

[0001193125-17-238544:8k_2_02:40]
WESTERN DIGITAL CORPORATION

[0001193125-17-238544:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-238544:8k_2_02:42]
(in millions; unaudited)

[0001193125-17-238544:8k_2_02:43]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 30, |  |  | July 1, |  |  | June 30, |  |  | July 1, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 280 |  |  | $ | (366 | ) |  | $ | 397 |  |  | $ | 242 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 546 |  |  |  | 420 |  |  |  | 2,128 |  |  |  | 1,154 |  |
| Stock-based compensation |  |  | 91 |  |  |  | 70 |  |  |  | 394 |  |  |  | 191 |  |
| Deferred income taxes |  |  | (49 | ) |  |  | (132 | ) |  |  | 12 |  |  |  | (149 | ) |
| Loss on disposal of assets |  |  | 6 |  |  |  | 9 |  |  |  | 18 |  |  |  | 22 |  |
| Write-off of issuance costs and amortization of debt discounts |  |  | 10 |  |  |  | 36 |  |  |  | 285 |  |  |  | 39 |  |
| Loss (gain) on convertible debt and related instruments |  |  | (1 | ) |  |  | 58 |  |  |  | 5 |  |  |  | 58 |  |
| Non-cash portion of employee termination, asset impairment and other charges |  |  | — |  |  |  | 5 |  |  |  | 13 |  |  |  | 41 |  |
| Other non-cash operating activities, net |  |  | 36 |  |  |  | 11 |  |  |  | 94 |  |  |  | 11 |  |
| Changes in operating assets and liabilities, net |  |  | 20 |  |  |  | 244 |  |  |  | 91 |  |  |  | 374 |  |
| Net cash provided by operating activities |  |  | 939 |  |  |  | 355 |  |  |  | 3,437 |  |  |  | 1,983 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net |  |  | (125 | ) |  |  | (151 | ) |  |  | (557 | ) |  |  | (584 | ) |
| Activity related to Flash Ventures, net |  |  | (53 | ) |  |  | (90 | ) |  |  | (277 | ) |  |  | (90 | ) |
| Acquisitions, net of cash acquired |  |  | — |  |  |  | (9,835 | ) |  |  | — |  |  |  | (9,835 | ) |
| Investment activity, net |  |  | (1 | ) |  |  | 532 |  |  |  | 230 |  |  |  | 977 |  |
| Strategic investments and other, net |  |  | (11 | ) |  |  | (53 | ) |  |  | (32 | ) |  |  | (76 | ) |
| Net cash used in investing activities |  |  | (190 | ) |  |  | (9,597 | ) |  |  | (636 | ) |  |  | (9,608 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee stock plans, net |  |  | 128 |  |  |  | 57 |  |  |  | 230 |  |  |  | 74 |  |
| Payment upon settlement of acquired warrants |  |  | — |  |  |  | (613 | ) |  |  | — |  |  |  | (613 | ) |
| Settlement of convertible debt |  |  | — |  |  |  | (2,611 | ) |  |  | (492 | ) |  |  | (2,611 | ) |
| Proceeds from acquired call option |  |  | — |  |  |  | 409 |  |  |  | 61 |  |  |  | 409 |  |
| Repurchases of common stock |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (60 | ) |
| Dividends paid to shareholders |  |  | (146 | ) |  |  | (117 | ) |  |  | (574 | ) |  |  | (464 | ) |
| Settlement of debt hedge |  |  | (21 | ) |  |  | — |  |  |  | (21 | ) |  |  | — |  |
| Proceeds from debt, net of issuance costs |  |  | — |  |  |  | 16,709 |  |  |  | 7,898 |  |  |  | 16,709 |  |
| Repayment of debt |  |  | (10 | ) |  |  | (2,329 | ) |  |  | (11,697 | ) |  |  | (2,693 | ) |
| Net cash provided by (used in) financing activities |  |  | (49 | ) |  |  | 11,505 |  |  |  | (4,595 | ) |  |  | 10,751 |  |
| Effect of exchange rate changes on cash |  |  | 2 |  |  |  | 1 |  |  |  | (3 | ) |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 702 |  |  |  | 2,264 |  |  |  | (1,797 | ) |  |  | 3,127 |  |
| Cash and cash equivalents, beginning of period |  |  | 5,652 |  |  |  | 5,887 |  |  |  | 8,151 |  |  |  | 5,024 |  |
| Cash and cash equivalents, end of period |  | $ | 6,354 |  |  | $ | 8,151 |  |  | $ | 6,354 |  |  | $ | 8,151 |  |

[0001193125-17-238544:8k_2_02:44]
WESTERN DIGITAL CORPORATION

[0001193125-17-238544:8k_2_02:45]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001193125-17-238544:8k_2_02:46]
(in millions, except per share amounts; unaudited)

[0001193125-17-238544:8k_2_02:47]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 30, |  |  | July 1, |  |  | June 30, |  |  | July 1, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Summary Reconciliation of Net Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 280 |  |  | $ | (366 | ) |  | $ | 397 |  |  | $ | 242 |  |
| Amortization of acquired intangible assets |  |  | 319 |  |  |  | 187 |  |  |  | 1,162 |  |  |  | 258 |  |
| Stock-based compensation expense |  |  | 89 |  |  |  | 68 |  |  |  | 382 |  |  |  | 180 |  |
| Employee termination, asset impairment and other charges |  |  | 80 |  |  |  | 122 |  |  |  | 232 |  |  |  | 345 |  |
| Acquisition-related charges |  |  | — |  |  |  | 238 |  |  |  | 35 |  |  |  | 281 |  |
| Charges related to cost saving initiatives |  |  | 40 |  |  |  | 57 |  |  |  | 154 |  |  |  | 143 |  |
| Charges related to arbitration award |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Convertible debt activity, net |  |  | (1 | ) |  |  | 58 |  |  |  | 6 |  |  |  | 58 |  |
| Debt extinguishment costs |  |  | — |  |  |  | 18 |  |  |  | 274 |  |  |  | 18 |  |
| Other |  |  | 47 |  |  |  | (21 | ) |  |  | 67 |  |  |  | (29 | ) |
| Income tax adjustments |  |  | 27 |  |  |  | (92 | ) |  |  | 11 |  |  |  | (127 | ) |
| Non-GAAP net income |  | $ | 881 |  |  | $ | 269 |  |  | $ | 2,720 |  |  | $ | 1,401 |  |
| GAAP cost of revenue |  | $ | 3,161 |  |  | $ | 2,674 |  |  | $ | 13,021 |  |  | $ | 9,559 |  |
| Amortization of acquired intangible assets |  |  | (279 | ) |  |  | (114 | ) |  |  | (1,003 | ) |  |  | (163 | ) |
| Stock-based compensation expense |  |  | (12 | ) |  |  | (8 | ) |  |  | (49 | ) |  |  | (21 | ) |
| Acquisition-related charges |  |  | — |  |  |  | (122 | ) |  |  | (18 | ) |  |  | (122 | ) |
| Charges related to cost saving initiatives |  |  | (24 | ) |  |  | (27 | ) |  |  | (68 | ) |  |  | (74 | ) |
| Other |  |  | (2 | ) |  |  | — |  |  |  | (5 | ) |  |  | 5 |  |
| Non-GAAP cost of revenue |  | $ | 2,844 |  |  | $ | 2,403 |  |  | $ | 11,878 |  |  | $ | 9,184 |  |
| GAAP gross profit |  | $ | 1,681 |  |  | $ | 821 |  |  | $ | 6,072 |  |  | $ | 3,435 |  |
| Amortization of acquired intangible assets |  |  | 279 |  |  |  | 114 |  |  |  | 1,003 |  |  |  | 163 |  |
| Stock-based compensation expense |  |  | 12 |  |  |  | 8 |  |  |  | 49 |  |  |  | 21 |  |
| Acquisition-related charges |  |  | — |  |  |  | 122 |  |  |  | 18 |  |  |  | 122 |  |
| Charges related to cost saving initiatives |  |  | 24 |  |  |  | 27 |  |  |  | 68 |  |  |  | 74 |  |
| Other |  |  | 2 |  |  |  | — |  |  |  | 5 |  |  |  | (5 | ) |
| Non-GAAP gross profit |  | $ | 1,998 |  |  | $ | 1,092 |  |  | $ | 7,215 |  |  | $ | 3,810 |  |
| GAAP operating expenses |  | $ | 1,029 |  |  | $ | 1,016 |  |  | $ | 4,118 |  |  | $ | 2,969 |  |
| Amortization of acquired intangible assets |  |  | (40 | ) |  |  | (73 | ) |  |  | (159 | ) |  |  | (95 | ) |
| Stock-based compensation expense |  |  | (77 | ) |  |  | (60 | ) |  |  | (333 | ) |  |  | (159 | ) |
| Employee termination, asset impairment and other charges |  |  | (80 | ) |  |  | (122 | ) |  |  | (232 | ) |  |  | (345 | ) |
| Acquisition-related charges |  |  | — |  |  |  | (116 | ) |  |  | (17 | ) |  |  | (159 | ) |
| Charges related to arbitration award |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32 | ) |
| Charges related to cost saving initiatives |  |  | (16 | ) |  |  | (30 | ) |  |  | (86 | ) |  |  | (69 | ) |
| Other |  |  | (4 | ) |  |  | 26 |  |  |  | (8 | ) |  |  | 29 |  |
| Non-GAAP operating expenses |  | $ | 812 |  |  | $ | 641 |  |  | $ | 3,283 |  |  | $ | 2,139 |  |
| GAAP operating income (loss) |  | $ | 652 |  |  | $ | (195 | ) |  | $ | 1,954 |  |  | $ | 466 |  |
| Cost of revenue adjustments |  |  | 317 |  |  |  | 271 |  |  |  | 1,143 |  |  |  | 375 |  |
| Operating expense adjustments |  |  | 217 |  |  |  | 375 |  |  |  | 835 |  |  |  | 830 |  |
| Non-GAAP operating income |  | $ | 1,186 |  |  | $ | 451 |  |  | $ | 3,932 |  |  | $ | 1,671 |  |
| GAAP interest and other expense, net |  | $ | (237 | ) |  | $ | (290 | ) |  | $ | (1,185 | ) |  | $ | (313 | ) |
| Convertible debt activity, net |  |  | (1 | ) |  |  | 58 |  |  |  | 6 |  |  |  | 58 |  |
| Debt extinguishment costs |  |  | — |  |  |  | 18 |  |  |  | 274 |  |  |  | 18 |  |
| Other |  |  | 41 |  |  |  | 5 |  |  |  | 54 |  |  |  | 5 |  |
| Non-GAAP interest and other expense, net |  | $ | (197 | ) |  | $ | (209 | ) |  | $ | (851 | ) |  | $ | (232 | ) |
| GAAP income tax expense (benefit) |  | $ | 135 |  |  | $ | (119 | ) |  | $ | 372 |  |  | $ | (89 | ) |
| Income tax adjustments |  |  | (27 | ) |  |  | 92 |  |  |  | (11 | ) |  |  | 127 |  |
| Non-GAAP income tax expense (benefit) |  | $ | 108 |  |  | $ | (27 | ) |  | $ | 361 |  |  | $ | 38 |  |
| Diluted income (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.93 |  |  | $ | (1.40 | ) |  | $ | 1.34 |  |  | $ | 1.00 |  |
| Non-GAAP |  | $ | 2.93 |  |  | $ | 1.02 |  |  | $ | 9.19 |  |  | $ | 5.79 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  | 301 |  |  |  | 261 |  |  |  | 296 |  |  |  | 242 |  |
| Non-GAAP |  |  | 301 |  |  |  | 263 |  |  |  | 296 |  |  |  | 242 |  |

[0001193125-17-238544:8k_2_02:48]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally
accepted accounting principles (“GAAP”), the table above sets forth non-GAAP cost of revenue; non-GAAP gross profit;
non-GAAP operating expenses; non-GAAP operating income; non-GAAP interest and other expense, net;
non-GAAP income tax expense (benefit); non-GAAP net income and non-GAAP diluted income per common share (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from
Non-GAAP measures used by other companies. Western Digital Corporation believes the presentation of these Non-GAAP measures, when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods. Specifically, we believe these Non-GAAP
measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that we believe are not indicative of our core operating results or because they are consistent with the financial models and
estimates published by many analysts who follow us and our peers. As discussed further below, these Non-GAAP measures exclude the amortization of acquired intangible assets, stock-based compensation expense,
employee termination, asset impairment and other charges, acquisition-related charges, charges related to cost saving initiatives, charges related to arbitration award, convertible debt activity, debt extinguishment costs, other charges, and income
tax adjustments, and we believe these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing our results. These Non-GAAP measures are
some of the primary indicators management uses for assessing our performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a
substitute for, or superior to, GAAP results.

[0001193125-17-238544:8k_2_02:49]
As described above, we exclude the following items from our
Non-GAAP measures:

[0001193125-17-238544:8k_2_02:50]
Amortization of acquired intangible assets. We incur expenses from the amortization of
acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of our acquisitions and any related impairment charges.

[0001193125-17-238544:8k_2_02:51]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based
compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside our control, we believe excluding stock-based compensation expense enhances the
ability of management and investors to understand and assess the underlying performance of our business over time and compare it against our peers, a majority of whom also exclude stock-based compensation expense from their non-GAAP results.

[0001193125-17-238544:8k_2_02:52]
Employee termination, asset impairment and other charges. From
time-to-time, in order to realign our operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, we may terminate
employees and/or restructure our operations. From time-to-time, we may also incur charges from the impairment of intangible assets and other long-lived assets. These
charges (including any reversals of charges recorded in prior periods) are inconsistent in amount and frequency, and we believe are not indicative of the underlying performance of our business.

[0001193125-17-238544:8k_2_02:53]
Acquisition-related charges. In connection with our business combinations, we incur expenses which we would not have otherwise incurred as part of our
business operations. These expenses include third-party professional service and legal fees, third-party integration services, severance costs, non-cash adjustments to the fair value of acquired inventory,
contract termination costs, and retention bonuses. We may also experience other accounting impacts in connection with these transactions. These charges and impacts are related to acquisitions, are inconsistent in amount and frequency, and we believe
are not indicative of the underlying performance of our business.

[0001193125-17-238544:8k_2_02:54]
Charges related to arbitration award. In relation to an arbitration award for
claims brought against the Company by Seagate Technology LLC, which was satisfied in October 2014, and the related dispute over the calculation of post-award interest, we have recorded loss contingencies. The resulting expense is inconsistent in
amount and frequency.

[0001193125-17-238544:8k_2_02:55]
Charges related to cost saving initiatives. In connection with the transformation of our business, we have incurred charges
related to cost saving initiatives which do not qualify for special accounting treatment as exit or disposal activities. These charges, which we believe are not indicative of the underlying performance of our business, primarily relate to costs
associated with rationalizing our channel partners or vendors, transforming our information systems infrastructure, integrating our product roadmap, and accelerated depreciation on assets.

[0001193125-17-238544:8k_2_02:56]
Convertible debt activity, net. We exclude non-cash economic interest expense associated with the convertible
senior notes, the gains and losses on the conversion of the convertible senior notes and call option, and unrealized gains and losses related to the change in fair value of the exercise option and call option. These charges and gains and losses do
not reflect our operating results, and we believe are not indicative of the underlying performance of our business.

[0001193125-17-238544:8k_2_02:57]
Debt extinguishment costs.
From time-to-time, we replace our existing debt with new financing at more favorable interest rates or utilize available capital to settle debt early, both of which
generate interest savings in future periods. We incur debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off of any related unamortized debt issuance costs. These
gains and losses related to our debt activity occur infrequently and we believe are not indicative of the underlying performance of our business.

[0001193125-17-238544:8k_2_02:58]
Other charges. From time-to-time, we sell or impair investments or
other assets which are not considered necessary to our business operations; are a party to legal or arbitration proceedings, which could result in an expense or benefit due to settlements, final judgments, or accruals for loss contingencies; or
incur other charges or gains which we believe are not a part of the ongoing operation of our business. The resulting expense or benefit is inconsistent in amount and frequency.

[0001193125-17-238544:8k_2_02:59]
Income tax adjustments. Income tax adjustments reflect the difference between income taxes based on a forecasted annual
non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments.
