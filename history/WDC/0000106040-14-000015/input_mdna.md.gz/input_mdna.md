# WDC MD&A — 0000106040-14-000015


## mdna

[0000106040-14-000015:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-14-000015:mdna:2]
Forward-Looking Statements

[0000106040-14-000015:mdna:3]
Our Company

[0000106040-14-000015:mdna:4]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes hard disk drives (“HDDs”) and solid-state drives ("SSDs"). HDDs are our principal products and are today’s primary storage medium for digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.  We currently operate our global business through two independent subsidiaries due to regulatory requirements - HGST and WD.

[0000106040-14-000015:mdna:5]
Acquisitions

[0000106040-14-000015:mdna:6]
Acquisition of Virident Systems, Inc. (“Virident”)

[0000106040-14-000015:mdna:7]
On October 17, 2013, we acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. Virident was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash and $15 million related to the fair value of stock options assumed. The acquisition furthered HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures. The acquisition of Virident did not have a material impact on our consolidated financial statements for fiscal 2014.

[0000106040-14-000015:mdna:8]
Acquisition of sTec, Inc. (“sTec”)

[0000106040-14-000015:mdna:9]
On September 12, 2013, we completed the acquisition of sTec, a provider of enterprise SSDs. As a result of the acquisition, sTec was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The acquisition augmented HGST's existing solid-state storage capabilities. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash and $11 million related to the fair value of stock options and restricted stock units ("RSUs") assumed. The acquisition of sTec did not have a material impact on our consolidated financial statements for fiscal 2014.

[0000106040-14-000015:mdna:10]
Acquisition of VeloBit, Inc. ("VeloBit")

[0000106040-14-000015:mdna:11]
On July 9, 2013, we acquired VeloBit, a privately held provider of high-performance storage I/O optimization software. As a result of the acquisition, VeloBit was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The acquisition built on HGST's strategy to enhance the overall value of datacenter storage by integrating HGST SSDs with software. The acquisition did not have a material impact on our consolidated financial statements for fiscal 2014.

[0000106040-14-000015:mdna:12]
Hitachi Global Storage Technologies Holdings Pte. Ltd. (“HGST”) Acquisition

[0000106040-14-000015:mdna:13]
On March 8, 2012, we completed the acquisition of Viviti Technologies Ltd., known until shortly before the acquisition as HGST, from Hitachi, Ltd. (“Hitachi”). The acquisition is intended over time, and subject to compliance with the regulatory conditions discussed below under “Maintenance of Competitive Requirement,” to result in a more efficient and innovative customer-focused storage company. We do not expect to achieve significant operating expense synergies while the regulatory conditions are in effect. The aggregate purchase price of the HGST acquisition was approximately $4.7 billion, consisting of $4.6 billion funded with $3.7 billion of existing cash and cash from new debt as well as 25 million newly issued shares of our common stock with a fair value of $877 million, and $102 million related to the fair value of stock options, RSUs and cash-settled stock appreciation rights ("SARs") assumed.

[0000106040-14-000015:mdna:14]
Toshiba Transactions

[0000106040-14-000015:mdna:15]
In connection with the regulatory approval process of the HGST acquisition, we announced on May 15, 2012 that we had closed a transaction with Toshiba Corporation (“Toshiba”) to divest certain 3.5-inch hard drive assets and to purchase Toshiba Storage Device (Thailand) Company Limited (“TSDT”), a wholly owned subsidiary of Toshiba that manufactured hard drives prior to the Thailand flooding in 2011. The net impact of these two transactions was immaterial to our consolidated financial statements. In August 2013, we received a $45 million insurance recovery related to the Thailand flooding for the facilities acquired in connection with the acquisition of TSDT.

[0000106040-14-000015:mdna:16]
Maintenance of Competitive Requirement

[0000106040-14-000015:mdna:17]
In connection with the regulatory approval process of the HGST acquisition, we agreed to certain conditions required by the Ministry of Commerce of the People’s Republic of China (“MOFCOM”), including adopting measures to maintain HGST as an independent competitor until MOFCOM agrees otherwise (with the minimum period being two years from the closing date of March 8, 2012). In March 2014, we submitted an application to MOFCOM requesting that the regulatory restrictions be lifted.  At this time, we are awaiting MOFCOM’s response to our application.

[0000106040-14-000015:mdna:18]
For additional information on our acquisition, see Part II, Item 8, Note 15 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:19]
37

[0000106040-14-000015:mdna:20]
Results of Operations

[0000106040-14-000015:mdna:21]
Fiscal 2014 Overview

[0000106040-14-000015:mdna:22]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for Virident, sTec, VeloBit and HGST, which were acquired on October 17, 2013, September 12, 2013, July 9, 2013 and March 8, 2012, respectively, are included in our operating results only after the respective dates of acquisition.

[0000106040-14-000015:mdna:23]
In 2014, our net revenue decreased by 1% to $15.1 billion on hard drive shipments of 249 million units as compared to $15.4 billion on shipments of 242 million units in 2013. In 2014, 53% of our net revenue was derived from our enterprise applications, branded products and CE products, as compared to 50% in 2013. Hard drive average selling price (“ASP”) decreased to $58 in 2014 from $61 in 2013. Gross profit as a percentage of revenue increased to 28.8% in 2014 from 28.4% in 2013. Operating income increased from $1.3 billion in 2013 to $1.8 billion in 2014. Operating income in 2014 included $95 million of employee termination, asset impairment and other charges and $52 million of charges related to an arbitration award as compared to $138 million and $681 million for the same charges in 2013, respectively. As a percentage of net revenue, operating income was 11.8% in 2014 compared to 8.2% in 2013. Net income in 2014 was $1.6 billion, or $6.68 per diluted share, compared to $980 million, or $3.98 per diluted share, in 2013.

[0000106040-14-000015:mdna:24]
For the September quarter, we expect overall hard drive industry shipments to increase from the June quarter’s 138 million units primarily as a result of seasonality. We expect our revenue in the September quarter to increase slightly as a result of seasonality and an additional week in our first fiscal quarter of 2015 to realign our fiscal quarter ends.

[0000106040-14-000015:mdna:25]
Summary Comparison of 2014, 2013 and 2012

[0000106040-14-000015:mdna:26]
The following table sets forth, for the periods presented, selected summary information from our consolidated statements of income by dollars and percentage of net revenue (in millions, except percentages):

[0000106040-14-000015:mdna:27]
|  |  | Years Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| Net revenue |  | $ | 15,130 |  |  | 100.0 | % |  | $ | 15,351 |  |  | 100.0 | % |  | $ | 12,478 |  |  | 100.0 | % |
| Gross profit |  | 4,360 |  |  | 28.8 |  |  | 4,363 |  |  | 28.4 |  |  | 3,638 |  |  | 29.2 |  |
| R&D and SG&A |  | 2,422 |  |  | 16.0 |  |  | 2,278 |  |  | 14.8 |  |  | 1,573 |  |  | 12.6 |  |
| Charges related to arbitration award |  | 52 |  |  | 0.3 |  |  | 681 |  |  | 4.4 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges |  | 95 |  |  | 0.6 |  |  | 138 |  |  | 0.9 |  |  | 80 |  |  | 0.6 |  |
| Charges related to flooding, net |  | — |  |  | — |  |  | — |  |  | — |  |  | 214 |  |  | 1.7 |  |
| Operating income |  | 1,791 |  |  | 11.8 |  |  | 1,266 |  |  | 8.2 |  |  | 1,771 |  |  | 14.2 |  |
| Other expense, net |  | (39 | ) |  | (0.3 | ) |  | (44 | ) |  | (0.3 | ) |  | (14 | ) |  | (0.1 | ) |
| Income before income taxes |  | 1,752 |  |  | 11.6 |  |  | 1,222 |  |  | 8.0 |  |  | 1,757 |  |  | 14.1 |  |
| Income tax provision |  | 135 |  |  | 0.9 |  |  | 242 |  |  | 1.6 |  |  | 145 |  |  | 1.2 |  |
| Net income |  | 1,617 |  |  | 10.7 |  |  | 980 |  |  | 6.4 |  |  | 1,612 |  |  | 12.9 |  |

[0000106040-14-000015:mdna:28]
38

[0000106040-14-000015:mdna:29]
The following table sets forth, for the periods presented, summary information regarding unit shipments, ASPs and revenues by geography and channel (in millions, except percentages and ASPs):

[0000106040-14-000015:mdna:30]
|  |  | Years Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| Net revenue |  | $ | 15,130 |  |  | $ | 15,351 |  |  | $ | 12,478 |  |
| ASPs (per unit)* |  | $ | 58 |  |  | $ | 61 |  |  | $ | 62 |  |
| Revenues by Geography (%) |  |  |  |  |  |  |
| Americas |  | 25 | % |  | 26 | % |  | 23 | % |
| Europe, Middle East and Africa |  | 21 |  |  | 20 |  |  | 19 |  |
| Asia |  | 54 |  |  | 54 |  |  | 58 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |
| Original Equipment Manufacturers ("OEM") |  | 63 | % |  | 63 | % |  | 63 | % |
| Distributors |  | 24 |  |  | 24 |  |  | 25 |  |
| Retailers |  | 13 |  |  | 13 |  |  | 12 |  |
| Unit Shipments* |  |  |  |  |  |  |
| Compute |  | 157 |  |  | 162 |  |  | 150 |  |
| Non-compute |  | 92 |  |  | 80 |  |  | 52 |  |
| Total units shipped |  | 249 |  |  | 242 |  |  | 202 |  |

[0000106040-14-000015:mdna:31]
_______________

[0000106040-14-000015:mdna:32]
| * | Based on sales of hard drive units only. |

[0000106040-14-000015:mdna:33]
Fiscal Year 2014 Compared to Fiscal Year 2013

[0000106040-14-000015:mdna:34]
Net Revenue. Net revenue was $15.1 billion for 2014, a decrease of 1% from 2013. ASPs were $58 for 2014, a decrease of $3 from 2013. These decreases were primarily due to modest price declines and a change in product mix, partially offset by an increase in unit shipments. Total hard drive shipments in 2014 increased to 249 million units as compared to 242 million units for the prior year primarily due to strength in our consumer electronics solutions, including gaming consoles.

[0000106040-14-000015:mdna:35]
Changes in revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-14-000015:mdna:36]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For each of 2014 and 2013, these programs represented 8% of gross revenues. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product.

[0000106040-14-000015:mdna:37]
Gross Profit. Gross profit for 2014 was $4.4 billion, a decrease of $3 million from the prior year. Gross profit as a percentage of net revenue increased to 28.8% in 2014 as compared to 28.4% in 2013. The increase in gross profit as a percentage of net revenue was primarily driven by higher volumes in 2014 as compared to 2013 as well as a continued focus on operational excellence.

[0000106040-14-000015:mdna:38]
Operating Expenses. Total research and development (“R&D”) expense and selling, general and administrative (“SG&A”) expense increased to 16.0% of net revenue in 2014 compared to 14.8% in 2013. R&D expense was $1.7 billion in 2014, an increase of $89 million, or 6%, over the prior year. This increase was primarily due to the inclusion of Virident and sTec's R&D expenses from the dates of acquisition and the continued investment in product development. As a percentage of net revenue, R&D expense increased to 11.0% in 2014 compared to 10.2% in 2013. SG&A expense was $761 million in 2014, an increase of $55 million, or 8%, as compared to 2013. This increase in SG&A expense was primarily due to the inclusion of Virident and sTec's SG&A expenses from the dates of acquisition and the expansion of sales and marketing to support new products and growing markets, partially offset by a $65 million gain on flood-related insurance recovery. SG&A expense as a percentage of net revenue increased to 5.0% in 2014 compared to 4.6% in 2013.

[0000106040-14-000015:mdna:39]
During 2014 and 2013, we recorded $52 million and $681 million, respectively, for charges related to an arbitration award for claims brought against us and a now former employee by Seagate Technology LLC (“Seagate”), alleging misappropriation of confidential information and trade secrets. For further detail see the “Arbitration Award” section below.

[0000106040-14-000015:mdna:40]
39

[0000106040-14-000015:mdna:41]
During 2014, we recorded $95 million of employee termination, asset impairment and other charges. These charges consisted of $27 million of employee termination benefits, $62 million of asset impairment charges and $6 million of other charges. During 2013, we recorded $138 million of employee termination, asset impairment and other charges. These charges consisted of $109 million of employee termination benefits, $14 million of asset impairment charges and $15 million of other charges.

[0000106040-14-000015:mdna:42]
Other Income (Expense). Other expense, net was $39 million in 2014 compared to $44 million in 2013. Interest and other income increased from $11 million in 2013 to $17 million in 2014 primarily due to a $3 million gain on the sale of our auction-rate securities in 2014 and a higher average daily invested cash balance for the period. Interest and other expense increased from $55 million in 2013 to $56 million in 2014, primarily due to a $4 million write-off of debt issuance costs associated with lenders that extinguished or reduced their participation in our newly entered into Credit Agreement (as defined below), offset by lower variable interest rates on our average debt balance in 2014.

[0000106040-14-000015:mdna:43]
Income Tax Provision. Income tax expense was $135 million in 2014 as compared to $242 million in 2013. Tax expense as a percentage of income before taxes was 7.7% in 2014 compared to 19.8% in 2013. Our income tax provision for 2013 also reflects a tax benefit of $37 million as a result of the retroactive extension of the U.S. Federal research and experimentation tax credit (“R&D credit”) that was signed into law on January 2, 2013 as part of the American Taxpayer Relief Act of 2012. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013. In addition, we recorded an $88 million charge to reduce our previously recognized California deferred tax assets in fiscal 2013 as a result of the enactment of California Proposition 39. California Proposition 39, which was approved by California voters on November 6, 2012, affects California state income tax apportionment for most multi-state taxpayers for tax years beginning on or after January 1, 2013. This proposition reduces our future income apportioned to California, making it less likely for us to realize certain California deferred tax assets. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits.

[0000106040-14-000015:mdna:44]
As of June 27, 2014, we had a recorded liability for unrecognized tax benefits of $300 million. We recognized a net increase of $60 million in our liability for unrecognized tax benefits during 2014. Interest and penalties recognized on such amounts were not material.

[0000106040-14-000015:mdna:45]
The Internal Revenue Service (“IRS”) previously completed its field examination of our federal income tax returns for fiscal years 2006 and 2007 and issued Revenue Agent Reports that proposed adjustments to income before income taxes of approximately $970 million primarily related to transfer pricing and intercompany payable balances. We disagreed with the proposed adjustments and filed a protest with the IRS Appeals Office. In June 2013, we reached an agreement with the IRS to resolve the transfer pricing issue. This agreement resulted in a decrease in the amount of net operating loss and tax credits realized, but did not have an impact on our consolidated statements of income. The proposed adjustment relating to intercompany payable balances for fiscal years 2006 and 2007 will be addressed in conjunction with the IRS’s examination of our fiscal years 2008 and 2009, which commenced in January 2012. In addition, in January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag, Incorporated ("Komag"), which was acquired by us on September 5, 2007. In February 2013, the IRS commenced an examination of calendar years 2010 and 2011 of HGST, which was acquired by us on March 8, 2012.

[0000106040-14-000015:mdna:46]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management's expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of June 27, 2014, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-14-000015:mdna:47]
Arbitration Award

[0000106040-14-000015:mdna:48]
As disclosed below in Part II, Item 8, Note 5 in the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, on November 18, 2011, a sole arbitrator ruled against us in an arbitration in Minnesota. The arbitration involves claims brought by Seagate against us and a now former employee, alleging misappropriation of confidential information and trade secrets. The arbitrator issued an interim award against us in the amount of $525 million plus pre-award interest. On January 23, 2012, the arbitrator issued a final award adding pre-award interest in the amount of $105.4 million, for a total award of $630.4 million. On January 23, 2012, we filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated, and a hearing on the petition to vacate was held on March 1, 2012. On October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award

[0000106040-14-000015:mdna:49]
and ordered that a rehearing be held concerning certain trade secret claims before a new arbitrator. On October 30, 2012, Seagate initiated an appeal of the District Court's decision with the Minnesota Court of Appeals. On July 22, 2013, the Minnesota Court of Appeals reversed the District Court's decision and remanded for entry of an order and judgment confirming the arbitration award. We strongly disagree with the decision of the Court of Appeals and believe that the District Court’s decision was correct. On August 20, 2013, we filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, we were informed that the Minnesota Supreme Court granted our petition. The appeal before the Minnesota Supreme Court was fully briefed, and oral argument was held on February 5, 2014. We will continue to vigorously defend ourselves in this matter. In light of uncertainties with respect to this matter, we recorded an accrual of $681 million for this matter in fiscal 2013. This amount was in addition to the $25 million previously accrued in fiscal 2011. In 2014, we recorded an additional $52 million for interest related to the arbitration award. As a result, the total amount accrued of $758 million represents the amount of the final arbitration award, plus interest accrued on the initial arbitration award at the statutory rate of 10% from January 24, 2012 through June 27, 2014.

[0000106040-14-000015:mdna:50]
Fiscal Year 2013 Compared to Fiscal Year 2012

[0000106040-14-000015:mdna:51]
Net Revenue. Net revenue was $15.4 billion for 2013, an increase of 23% from 2012. Total hard drive shipments in 2013 increased to 242 million units as compared to 202 million units for the prior year. The increase in net revenue resulted primarily from the contribution of a full year of HGST operations, partially offset by continued soft industry demand as well as a $1 decrease in ASP from $62 to $61.

[0000106040-14-000015:mdna:52]
Changes in revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-14-000015:mdna:53]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2013, these programs represented 8% of gross revenues compared to 6% in 2012. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product.

[0000106040-14-000015:mdna:54]
Gross Profit. Gross profit for 2013 was $4.4 billion, an increase of $725 million, or 20%, from the prior year. Gross profit as a percentage of net revenue decreased to 28.4% in 2013 from 29.2% in 2012. This percentage decrease was primarily due to a decrease in ASP as well as $101 million of incremental amortization, reflecting a full year of amortization for intangibles related to the acquisition of HGST.

[0000106040-14-000015:mdna:55]
Operating Expenses. Total R&D expense and SG&A expense increased to 14.8% of net revenue in 2013 compared to 12.6% in 2012. R&D expense was $1.6 billion in 2013, an increase of $517 million, or 49%, over the prior year. This increase was primarily due to the inclusion of HGST’s R&D expense for the full year period as well as continued investment in product development to support new programs. As a percentage of net revenue, R&D expense increased to 10.2% in 2013 compared to 8.5% in 2012. SG&A expense was $706 million in 2013, an increase of $188 million, or 36%, as compared to 2012. This increase in SG&A expense was primarily due to the inclusion of a full year of HGST’s SG&A expense and amortization of intangibles related to the acquisition of HGST, partially offset by the inclusion of acquisition-related expenses in the prior-year period. SG&A expense as a percentage of net revenue increased to 4.6% in 2013 compared to 4.2% in 2012.

[0000106040-14-000015:mdna:56]
During 2013, we recorded a $681 million charge related to an arbitration award for claims brought against us and a now former employee by Seagate, alleging misappropriation of confidential information and trade secrets.

[0000106040-14-000015:mdna:57]
During 2013, we recorded $138 million of employee termination benefits and other charges. These charges consisted of $109 million of employee termination benefits, $14 million of asset impairment charges and $15 million of other charges. During 2012, we recorded $56 million of asset impairment charges, $16 million of contract termination and other exit costs and $8 million of employee termination benefits. In addition, during 2012, we recorded $214 million of net charges related to the flooding in Thailand, including $119 million of fixed asset impairments, $61 million of recovery charges, $28 million of write-downs of damaged inventory and $27 million in wage continuation during the shutdown period of our facilities, partially offset by $21 million of insurance recoveries and other cost reimbursements.

[0000106040-14-000015:mdna:58]
Other Income (Expense). Other expense, net was $44 million in 2013 compared to $14 million in 2012. Interest and other income decreased slightly from $12 million in 2012 to $11 million in 2013 primarily due to a lower average daily invested cash balance for the period. Interest and other expense increased from $26 million in 2012 to $55 million in 2013, primarily due to interest on a higher debt balance since the acquisition of HGST.

[0000106040-14-000015:mdna:59]
Income Tax Provision. Income tax expense was $242 million in 2013 as compared to $145 million in 2012. Tax expense as a percentage of income before taxes was 19.8% in 2013 compared to 8.3% in 2012. Our income tax provision for 2013 also reflects a tax benefit of $37 million as a result of the retroactive extension of the R&D credit that was signed into law

[0000106040-14-000015:mdna:60]
41

[0000106040-14-000015:mdna:61]
on January 2, 2013 as part of the American Taxpayer Relief Act of 2012. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013. In addition, we recorded an $88 million charge to reduce our previously recognized California deferred tax assets in fiscal 2013 as a result of the enactment of California Proposition 39. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2014 through 2025, the current year generation of income tax credits and the effect of California Proposition 39.

[0000106040-14-000015:mdna:62]
As of June 28, 2013, we had a recorded liability for unrecognized tax benefits of approximately $240 million. We recognized a net decrease of $40 million in our liability for unrecognized tax benefits during 2013. Interest and penalties recognized on such amounts were not material.

[0000106040-14-000015:mdna:63]
Liquidity and Capital Resources

[0000106040-14-000015:mdna:64]
We ended 2014 with total cash and cash equivalents of $4.8 billion, an increase of $495 million from June 28, 2013. The following table summarizes our statements of cash flows for the three years ended June 27, 2014 (in millions):

[0000106040-14-000015:mdna:65]
|  |  | Years Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| Net cash flow provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 2,816 |  |  | $ | 3,119 |  |  | $ | 3,067 |  |
| Investing activities |  | (1,936 | ) |  | (970 | ) |  | (4,167 | ) |
| Financing activities |  | (385 | ) |  | (1,048 | ) |  | 819 |  |
| Effect of exchange rate changes on cash |  | — |  |  | — |  |  | (1 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 495 |  |  | $ | 1,101 |  |  | $ | (282 | ) |

[0000106040-14-000015:mdna:66]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. On January 9, 2014, the outstanding balance on the existing credit facility entered into on March 8, 2012 (the "Prior Credit Facility") was repaid, the Prior Credit Facility was terminated, and we, along with Western Digital Technologies, Inc. ("WDT") and WDI entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"). The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT, and a $1.5 billion revolving credit facility to WDT and WDI (the "Borrowers"). Subject to certain conditions, a Borrower may also elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. For additional information on the Prior Credit Facility and the Credit Agreement, See Part II, Item 8, Note 3 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, stock repurchase and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:67]
A total of $3.5 billion and $2.8 billion of our cash and cash equivalents was held outside of the United States at June 27, 2014 and June 28, 2013, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. If we are required to pay the arbitration award described in the section “Arbitration Award” above, the award would be paid from one of our foreign subsidiaries using cash and cash equivalents held outside of the United States. On September 13, 2012, our Board of Directors approved a capital allocation plan which includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-14-000015:mdna:68]
Operating Activities

[0000106040-14-000015:mdna:69]
Net cash provided by operating activities was $2.8 billion in 2014 as compared to $3.1 billion in both 2013 and 2012. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used in working capital changes was $234 million for 2014 as compared to net cash provided by working capital changes of $715 million and $324 million for 2013 and 2012, respectively.

[0000106040-14-000015:mdna:70]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The average quarterly cash conversion cycles for the three years ended 2014 were as follows:

[0000106040-14-000015:mdna:71]
|  |  | Years Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| Days sales outstanding |  | 48 |  |  | 43 |  |  | 49 |  |
| Days in inventory |  | 41 |  |  | 39 |  |  | 37 |  |
| Days payables outstanding |  | (67 | ) |  | (66 | ) |  | (83 | ) |
| Cash conversion cycle |  | 22 |  |  | 16 |  |  | 3 |  |

[0000106040-14-000015:mdna:72]
For 2014, our average days sales outstanding (“DSOs”) increased by 5 days, days in inventory (“DIOs”) increased by 2 days, and days payables outstanding (“DPOs”) increased by 1 day. Changes in average DSOs and DIOs are generally related to linearity of shipments and the timing of inventory builds, respectively. Changes in DPOs are generally related to production volume and the timing of purchases during the period. In 2012, the higher DPOs were primarily due to the impact of including HGST’s accounts payable balances as of June 29, 2012, but only including HGST’s cost of sales from the date of acquisition. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-14-000015:mdna:73]
Investing Activities

[0000106040-14-000015:mdna:74]
Net cash used in investing activities for 2014 was $1.9 billion as compared to $970 million for 2013 and $4.2 billion for 2012. During 2014, cash used in investing activities consisted primarily of $823 million related to acquisitions, net of cash acquired, $628 million of capital expenditures, $561 million related to the purchase of investments and $4 million of other investing activities, net, offset by $72 million of proceeds from the sales and maturities of investments. During 2013, cash used in investing activities consisted primarily of $952 million of capital expenditures and $17 million related to the purchase of investments. Capital expenditures in 2014 and 2012 consisted of charges related to the normal replacement of existing assets. Capital expenditures in 2013 primarily consisted of flood recovery and increased capacity for our broadening and growing product portfolio. During 2012, cash used in investing activities consisted of $3.5 billion, net of cash acquired, used for the acquisitions, $76 million of proceeds related to the sale of equipment, and capital expenditures of $717 million.

[0000106040-14-000015:mdna:75]
Our cash equivalents are invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government Agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. Government Agency securities, commercial paper, bank acceptances and certificates of deposit. During 2014, we sold our entire $14 million portfolio of auction-rate securities, resulting in a gain of $3 million which was included in interest and other income in the consolidated statements of income.

[0000106040-14-000015:mdna:76]
Financing Activities

[0000106040-14-000015:mdna:77]
Net cash used in financing activities was $385 million for 2014 and $1.0 billion for 2013 as compared to net cash provided by financing activities of $819 million for 2012. Net cash used in financing activities for 2014 consisted of $2.5 billion of debt proceeds related to the term loan facility under the Credit Agreement, net of issuance costs, $500 million of debt proceeds related to the revolving credit facility under the Prior Credit Facility and a net $215 million provided by employee stock plans, offset by $2.5 billion used to repay the Prior Credit Facility and make principal payments on the Credit Agreement, as well as $816 million used to repurchase shares of our common stock and $259 million used to pay dividends on our common stock. Net cash used in financing activities for 2013 consisted of $842 million used to repurchase shares of our common stock, $181 million used to pay dividends on our common stock and $230 million used to repay long-term debt, partially offset by a net $205 million provided by employee stock plans. Net cash provided by financing activities for 2012 consisted of the $2.8 billion of proceeds borrowed under the Credit Facility in connection with the acquisition of HGST, net of issuance costs, and a net $141 million provided by employee stock plans, partially offset by $604 million used to repurchase stock and $1.5 billion used to repay our outstanding debt as well as debt assumed in the acquisition of HGST.

[0000106040-14-000015:mdna:78]
Off-Balance Sheet Arrangements

[0000106040-14-000015:mdna:79]
Other than facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any off-balance sheet financing

[0000106040-14-000015:mdna:80]
43

[0000106040-14-000015:mdna:81]
arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the consolidated financial statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities.

[0000106040-14-000015:mdna:82]
Contractual Obligations and Commitments

[0000106040-14-000015:mdna:83]
The following is a summary of our known contractual cash obligations and commercial commitments as of June 27, 2014 (in millions):

[0000106040-14-000015:mdna:84]
|  |  | Total |  | Less than1 Year |  | 1-3 Years |  | 3-5 Years |  | More than5 Years |
| Long-term debt, including current portion* |  | $ | 2,438 |  |  | $ | 125 |  |  | $ | 375 |  |  | $ | 1,938 |  |  | $ | — |  |
| Operating leases |  | 199 |  |  | 44 |  |  | 62 |  |  | 38 |  |  | 55 |  |
| Unrecognized tax benefits* |  | 246 |  |  | — |  |  | 80 |  |  | 92 |  |  | 74 |  |
| Purchase obligations |  | 3,288 |  |  | 3,211 |  |  | 68 |  |  | 9 |  |  | — |  |
| Total |  | $ | 6,171 |  |  | $ | 3,380 |  |  | $ | 585 |  |  | $ | 2,077 |  |  | $ | 129 |  |

[0000106040-14-000015:mdna:85]
_______________

[0000106040-14-000015:mdna:86]
| * | Included within our consolidated balance sheet |

[0000106040-14-000015:mdna:87]
Long-Term Debt

[0000106040-14-000015:mdna:88]
On March 8, 2012, we, in our capacity as the parent entity and guarantor, and the Borrowers, entered into the Prior Credit Facility. The Prior Credit Facility provided for $2.8 billion of unsecured loan facilities, consisting of a $2.3 billion term loan facility and a $500 million revolving credit facility. On January 9, 2014, the outstanding balance on the Prior Credit Facility was repaid, the Prior Credit Facility was terminated, and the new Credit Agreement was entered into.

[0000106040-14-000015:mdna:89]
As of June 27, 2014, no amounts were outstanding under the revolving credit facility of the Credit Agreement and the term loan facility had an outstanding balance of $2.4 billion and a variable interest rate of 1.7%. We are required to make quarterly principal payments on the term loan facility totaling $125 million in fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. For additional information, see Part II, Item 8, Note 3 in the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:90]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of June 27, 2014, the Company was in compliance with all covenants.

[0000106040-14-000015:mdna:91]
Purchase Orders

[0000106040-14-000015:mdna:92]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into purchase orders with suppliers for capital equipment that are recorded as a liability upon receipt of the equipment. Our ability to change or cancel a capital equipment purchase order without penalty depends on the nature of the equipment being ordered. In some cases, we may be obligated to pay for certain costs related to changes to, or cancellation of, a purchase order, such as costs incurred for raw materials or work in process of components or capital equipment.

[0000106040-14-000015:mdna:93]
We have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. The estimated related minimum purchase requirements are included in “Purchase obligations” in the table above. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future

[0000106040-14-000015:mdna:94]
44

[0000106040-14-000015:mdna:95]
purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-14-000015:mdna:96]
We enter into, from time to time, other long-term purchase agreements for components with certain vendors. Generally, future purchases under these agreements are not fixed and determinable as they depend on our overall unit volume requirements and are contingent upon the prices, technology and quality of the supplier’s products remaining competitive. These arrangements are not included under “Purchase obligations” in the table above. Please see Item 1A of this Annual Report on Form 10-K for a discussion of risks related to commitments.

[0000106040-14-000015:mdna:97]
Foreign Exchange Contracts

[0000106040-14-000015:mdna:98]
We purchase short-term, foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. See Part II, Item 7A, under the heading “Disclosure About Foreign Currency Risk,” for a description of our current foreign exchange contract commitments and Part II, Item 8, Notes 1 and 12 in the Notes to Consolidated Financial Statements, included in this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:99]
Indemnifications

[0000106040-14-000015:mdna:100]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-14-000015:mdna:101]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-14-000015:mdna:102]
Unrecognized Tax Benefits

[0000106040-14-000015:mdna:103]
As of June 27, 2014, the cash portion of our total recorded liability for unrecognized tax benefits was $246 million. We estimate the timing of the future payments of these liabilities to be within the next one to eight years. See Part II, Item 8, Note 9 in the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-14-000015:mdna:104]
Stock Repurchase Program

[0000106040-14-000015:mdna:105]
Since May 18, 2012, our Board of Directors has authorized $3.0 billion for the repurchase of our common stock and the extension of our stock repurchase program until September 13, 2017. We repurchased 10.3 million shares of our common stock for a total cost of $816 million in 2014. The remaining amount available to be purchased under our stock repurchase program as of June 27, 2014 was $1.2 billion. Subsequent to June 27, 2014 and through August 14, 2014, we repurchased an additional 2.0 million shares of our common stock for a total cost of $203 million. We may continue to repurchase our common stock as we deem appropriate and market conditions allow. Repurchases under our stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows and borrowings under our Credit Agreement.

[0000106040-14-000015:mdna:106]
Cash Dividend Policy

[0000106040-14-000015:mdna:107]
On September 13, 2012, we announced that our Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of our common stock receive dividends when and as declared by our Board of Directors. In 2014, we declared aggregate cash dividends of $1.25 per share of our common stock, totaling $295 million, of which $201 million was paid during 2014. On August 5, 2014, we announced that our Board of Directors declared a cash dividend of $0.40 per share of our common stock to shareholders of record as of October 3, 2014, which will be paid on October 15, 2014. We may modify, suspend or cancel our cash dividend policy in any manner and at any time. See Part II, Item 5 included in this Annual Report on Form 10-K for further information.

[0000106040-14-000015:mdna:108]
Critical Accounting Policies and Estimates

[0000106040-14-000015:mdna:109]
We have prepared the accompanying consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues,

[0000106040-14-000015:mdna:110]
expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to the consolidated financial statements may be material.

[0000106040-14-000015:mdna:111]
Revenue and Accounts Receivable

[0000106040-14-000015:mdna:112]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions, and we provide resellers and OEMs with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information and customer claim processing. If customer demand for hard drives or market conditions differs from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Generally, total sales incentive and marketing programs range from 7% to 11% of gross revenues per quarter. For 2014, sales incentive and marketing programs were 8% of gross revenues. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.7% of quarterly gross revenue since the first quarter of fiscal 2012. Customer sales incentive and marketing programs are recorded as a reduction of revenue.

[0000106040-14-000015:mdna:113]
We record an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, we routinely analyze the different receivable aging categories and establish reserves based on a combination of past due receivables and expected future losses based primarily on our historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if our overall loss history changes significantly, an adjustment in our allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-14-000015:mdna:114]
We establish provisions against revenue and cost of revenue for sales returns in the same period that the related revenue is recognized. We base these provisions on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-14-000015:mdna:115]
Warranty

[0000106040-14-000015:mdna:116]
We record an accrual for estimated warranty costs when revenue is recognized. We generally warrant our products for a period of one to five years. Our warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. We use a statistical warranty tracking model to help prepare our estimates and assist us in exercising judgment in determining the underlying estimates. Our statistical tracking model captures specific detail on hard drive reliability, such as factory test data, historical field return rates, and costs to repair by product type. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base our warranty estimates. We review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from our estimates, our future results of operations could be materially affected. For a summary of historical changes in estimates related to pre-existing warranty provisions, refer to Part II, Item 8, Note 4 in the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:117]
Inventories

[0000106040-14-000015:mdna:118]
We value inventories at the lower of cost (first-in, first-out and weighted average methods) or net realizable value. We use the first-in, first-out (“FIFO”) method to value the cost of the majority of our inventories, while we use the weighted-average method to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by us. We have determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, we relieve our precious metals inventory based on the weighted-average cost of the inventory at

[0000106040-14-000015:mdna:119]
the time the inventory is used in production. The weighted-average method of valuing precious metals does not materially differ from a FIFO method. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-14-000015:mdna:120]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-14-000015:mdna:121]
Litigation and Other Contingencies

[0000106040-14-000015:mdna:122]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. Refer to Part II, Item 8, Note 5 in the Notes to Consolidated Financial Statements, included in this Annual Report on Form 10-K.

[0000106040-14-000015:mdna:123]
Income Taxes

[0000106040-14-000015:mdna:124]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized.

[0000106040-14-000015:mdna:125]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-14-000015:mdna:126]
Stock-based Compensation

[0000106040-14-000015:mdna:127]
We account for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options and cash-settled stock appreciation rights (“SARs”) granted are estimated using a binomial model, and the fair values of all Employee Stock Purchase Plan purchase rights are estimated using the Black-Scholes-Merton option-pricing model. We account for SARs as liability awards based upon our intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton models require the input of highly subjective assumptions. We are required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and our results of operations could be materially affected.

[0000106040-14-000015:mdna:128]
Goodwill and Other Long-Lived Assets

[0000106040-14-000015:mdna:129]
The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with amounts exceeding the fair values being recognized as goodwill. Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We either use qualitative factors to determine whether goodwill is more likely than not impaired or we perform a two-step approach to quantify impairment. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to follow a two-step approach to quantify the impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit.

[0000106040-14-000015:mdna:130]
Other intangible assets consist primarily of technology acquired in business combinations and in-process research and development. In-process research and development is not amortized until the point at which it reaches technological feasibility. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. Acquired intangibles are amortized on a straight-line basis over their respective estimated useful lives. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-14-000015:mdna:131]
Recent Accounting Pronouncements

[0000106040-14-000015:mdna:132]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, refer to Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, which is incorporated by reference in response to this item.
