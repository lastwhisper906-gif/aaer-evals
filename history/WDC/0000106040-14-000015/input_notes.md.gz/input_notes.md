# WDC notes — 0000106040-14-000015


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000106040-14-000015:notes:1]
Advertising Expense

[0000106040-14-000015:notes:2]
Advertising costs are expensed as incurred. Selling, general and administrative expenses of the Company included advertising costs of $60 million, $61 million and $30 million in 2014, 2013 and 2012, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-14-000015:notes:3]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments classified as available-for-sale as of June 27, 2014 (in millions):

[0000106040-14-000015:notes:4]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |
| U.S. Government agency securities | 88 |  |  | — |  |  | 88 |  |
| Commercial paper | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | 66 |  |  | — |  |  | 66 |  |
| Total | $ | 499 |  |  | $ | — |  |  | $ | 499 |  |
| Included in short-term investments |  |  |  |  | $ | 284 |  |
| Included in other non-current assets |  |  |  |  | 215 |  |
| Total |  |  |  |  | $ | 499 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-14-000015:notes:5]
Note 15. Acquisitions

[0000106040-14-000015:notes:6]
Acquisition of Virident

[0000106040-14-000015:notes:7]
On October 17, 2013, the Company acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. As a result of the acquisition, Virident has been fully integrated into the Company's HGST subsidiary and become a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash, and $15 million related to the fair value of stock options assumed. The acquisition furthered HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures.

[0000106040-14-000015:notes:8]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $506 million to goodwill. The values assigned to the acquired assets and liabilities were finalized as of the date of this Annual Report on Form 10-K. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's consolidated financial statements. In addition, pro forma financial information has not been presented as the acquisition did not have a material impact on the Company’s consolidated financial statements in 2014.

[0000106040-14-000015:notes:9]
The final purchase price allocation for Virident was as follows (in millions):

[0000106040-14-000015:notes:10]
|  | October 17,2013 |
| Tangible assets acquired and liabilities assumed | $ | 58 |  |
| Intangible assets | 49 |  |
| Goodwill | 506 |  |
| Total | $ | 613 |  |

[0000106040-14-000015:notes:11]
Since the date of acquisition, the Company recorded an increase of $4 million to goodwill to reflect an adjustment to the value of deferred tax assets and an adjustment to the value of investments acquired in the acquisition of Virident. The $506 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create server-side flash storage solutions leveraging the core technology acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Virident was immaterial to the Company’s consolidated financial statements in 2014.

[0000106040-14-000015:notes:12]
Acquisition of sTec

[0000106040-14-000015:notes:13]
On September 12, 2013, the Company completed its acquisition of sTec, a provider of enterprise solid-state drives. As a result of the acquisition, sTec has been fully integrated into the Company's HGST subsidiary and become a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash, and $11 million related to the fair value of stock options and RSUs assumed. The acquisition augmented HGST's existing solid-state storage capabilities.

[0000106040-14-000015:notes:14]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $89 million to goodwill. The values assigned to the acquired assets and liabilities are based on preliminary estimates of fair value available as of the date of this Annual Report on Form 10-K, and may be adjusted as further information becomes available during the measurement period of up to 12 months from the date of the acquisition. The primary areas of the preliminary purchase price allocation that are not yet finalized due to information that may become available subsequently include contingencies and income taxes, and any changes in these fair values could potentially result in material adjustments to goodwill. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's consolidated financial statements. In addition, pro forma financial information has not been presented as the acquisition did not have a material impact on the Company’s consolidated financial statements for 2014.

[0000106040-14-000015:notes:15]
The preliminary purchase price allocation for sTec was as follows (in millions):

[0000106040-14-000015:notes:16]
|  | September 12,2013 |
| Tangible assets acquired and liabilities assumed | $ | 189 |  |
| Intangible assets | 58 |  |
| Goodwill | 89 |  |
| Total | $ | 336 |  |

[0000106040-14-000015:notes:17]
Since the date of acquisition, the Company recorded a $1 million increase to goodwill to reflect an adjustment to the value of deferred tax assets acquired in the acquisition of sTec. The $89 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from augmenting HGST's existing solid-state storage capabilities and accelerating its ability to expand its participation in the growing area of enterprise solid-state drives and is not expected to be deductible for tax purposes.  The impact to revenue and net income attributable to sTec was immaterial to the Company’s consolidated financial statements for 2014 .

[0000106040-14-000015:notes:18]
Acquisition of VeloBit

[0000106040-14-000015:notes:19]
On July 9, 2013, the Company acquired VeloBit, a privately held provider of high-performance storage I/O optimization software. As a result of the acquisition, VeloBit was fully integrated into the Company's HGST subsidiary and became a wholly owned indirect subsidiary of the Company. The acquisition built on HGST's strategy to enhance the overall value of datacenter storage by integrating HGST SSDs with software. The acquisition was not material to the Company's consolidated financial statements.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000106040-14-000015:notes:20]
Cash and Cash Equivalents

[0000106040-14-000015:notes:21]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as direct investments in bank acceptances with original maturities when purchased of three months or less. Cash equivalents are carried at cost, which approximates fair value.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-14-000015:notes:22]
The changes in the benefit obligations and plan assets for the Japanese defined benefit pension plans were as follows for 2014, 2013 and 2012 (in millions):

[0000106040-14-000015:notes:23]
|  | 2014 |  | 2013 |  | 2012 |
| Change in benefit obligation: |  |  |  |  |  |
| Benefit obligation at beginning of period | $ | 234 |  |  | $ | 286 |  |  | $ | 279 |  |
| Service cost | 10 |  |  | 11 |  |  | 4 |  |
| Interest cost | 4 |  |  | 5 |  |  | 2 |  |
| Actuarial gain | 13 |  |  | (4 | ) |  | — |  |
| Benefits paid | (7 | ) |  | (6 | ) |  | (2 | ) |
| Other(1) | 8 |  |  | — |  |  | — |  |
| Non-U.S. currency movement | (7 | ) |  | (58 | ) |  | 3 |  |
| Benefit obligation at end of period | 255 |  |  | 234 |  |  | 286 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 167 |  |  | 167 |  |  | 162 |  |
| Actual return on plan assets | 15 |  |  | 29 |  |  | (1 | ) |
| Employer contributions | 14 |  |  | 15 |  |  | 6 |  |
| Benefits paid | (7 | ) |  | (6 | ) |  | (2 | ) |
| Other(1) | 7 |  |  | — |  |  | — |  |
| Non-U.S. currency movement | (5 | ) |  | (38 | ) |  | 2 |  |
| Fair value of plan assets at end of period | 191 |  |  | 167 |  |  | 167 |  |
| Unfunded status at end of year | $ | 64 |  |  | $ | 67 |  |  | $ | 119 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-14-000015:notes:24]
Note 4. Commitments and Contingencies

[0000106040-14-000015:notes:25]
Lease Commitments

[0000106040-14-000015:notes:26]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2022. Rental expense under these operating leases, including month-to-month rentals, was $59 million, $64 million and $41 million in 2014, 2013 and 2012, respectively. Future minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year at June 27, 2014 are as follows (in millions):

[0000106040-14-000015:notes:27]
| 2015 | $ | 44 |  |
| 2016 | 38 |  |
| 2017 | 24 |  |
| 2018 | 20 |  |
| 2019 | 18 |  |
| Thereafter | 55 |  |
| Total future minimum payments | $ | 199 |  |

[0000106040-14-000015:notes:28]
Product Warranty Liability

[0000106040-14-000015:notes:29]
Changes in the warranty accrual for 2014, 2013 and 2012 were as follows (in millions):

[0000106040-14-000015:notes:30]
|  | 2014 |  | 2013 |  | 2012 |
| Warranty accrual, beginning of period | $ | 187 |  |  | $ | 260 |  |  | $ | 170 |  |
| Warranty liabilities assumed as a result of acquisitions | 4 |  |  | — |  |  | 139 |  |
| Charges to operations | 170 |  |  | 178 |  |  | 154 |  |
| Utilization | (207 | ) |  | (221 | ) |  | (196 | ) |
| Changes in estimate related to pre-existing warranties | 28 |  |  | (30 | ) |  | (7 | ) |
| Warranty accrual, end of period | $ | 182 |  |  | $ | 187 |  |  | $ | 260 |  |

[0000106040-14-000015:notes:31]
Accrued warranty also includes amounts classified in other liabilities in the consolidated balance sheets of $63 million at June 27, 2014 and $73 million at June 28, 2013.

[0000106040-14-000015:notes:32]
Long-term Purchase Agreements

[0000106040-14-000015:notes:33]
The Company has entered into long-term purchase agreements with various component suppliers. The commitments depend on specific products ordered and may be subject to minimum quality requirements and future price negotiations. The Company expects these commitments to total $174 million for 2015, $55 million for 2016, $13 million for 2017, $6 million for 2018 and $3 million for 2019.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0000106040-14-000015:notes:34]
Note 11. Investments

[0000106040-14-000015:notes:35]
The Company invests in U.S. Treasury securities, U.S. Government Agency securities, commercial paper and certificates of deposit. These investments are classified as available-for-sale securities within short-term investments and other non-current assets in our consolidated balance sheets. In addition, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the consolidated balance sheets and are periodically analyzed to determine whether or not there are indicators of impairment. For more on the Company's investments, see Note 10.

[0000106040-14-000015:notes:36]
The fair value of the Company’s investments classified as available-for-sale securities at June 27, 2014, by remaining contractual maturity were as follows (in millions):

[0000106040-14-000015:notes:37]
|  | Cost Basis |  | Fair Value |
| Due in less than one year | $ | 284 |  |  | $ | 284 |  |
| Due in one to five years | 215 |  |  | 215 |  |
| Total | $ | 499 |  |  | $ | 499 |  |

[0000106040-14-000015:notes:38]
The Company determined no available-for-sale securities were other-than-temporarily impaired in 2014.


## us-gaap:DebtDisclosureTextBlock

[0000106040-14-000015:notes:39]
Note 3. Debt

[0000106040-14-000015:notes:40]
Long-term debt consisted of the following as of June 27, 2014 and June 28, 2013 (in millions):

[0000106040-14-000015:notes:41]
|  | 2014 |  | 2013 |
| Term loan | $ | 2,438 |  |  | $ | 1,955 |  |
| Less amounts due in one year | (125 | ) |  | (230 | ) |
| Long-term debt | $ | 2,313 |  |  | $ | 1,725 |  |

[0000106040-14-000015:notes:42]
On March 8, 2012 (the “HGST Closing Date”), the Company, in its capacity as the parent entity and guarantor, Western Digital Technologies, Inc. (“WDT”), a wholly owned subsidiary of the Company, and Western Digital Ireland, Ltd. (“WDI”), an indirect wholly owned subsidiary of the Company, entered into a five-year credit agreement (the “Prior Credit Facility”) with Bank of America, N.A., as administrative agent, swing line lender and letter of credit issuer, and certain other participating lenders. The Prior Credit Facility provided for $2.8 billion of unsecured loan facilities consisting of a $2.3 billion term loan facility and a $500 million revolving credit facility. On January 9, 2014, WDI used existing cash to repay the outstanding term loan balance of $1.8 billion under the Prior Credit Facility, and the Company, WDT and WDI, entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"); WDT paid the outstanding revolving credit facility balance of $500 million under the Prior Credit Facility; and the Company terminated the Prior Credit Facility. In connection with the repayment of the Prior Credit Facility, $4 million of debt issuance costs associated with lenders that extinguished or reduced their participation in the Credit Agreement were written off in fiscal 2014, and are included within interest and other expense in the consolidated statements of income. The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT and WDI (the “Borrowers”). The revolving credit facility includes a $100 million sublimit for letters of credit and a $50 million sublimit for swing line loans. Subject to certain conditions, a Borrower may elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. The loans under the Credit Agreement have a five-year term. The obligations of the Borrowers under the Credit Agreement are guaranteed by the Company and its material domestic subsidiaries, and the obligations of WDI under the Credit Agreement are also guaranteed by WDT.

[0000106040-14-000015:notes:43]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of June 27, 2014, no amounts were outstanding under the revolving credit facility and the term loan facility had a variable interest rate of 1.7% and a remaining, outstanding balance of $2.4 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $125 million in fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-14-000015:notes:44]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of June 27, 2014, the Company was in compliance with all covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-14-000015:notes:45]
Note 12. Foreign Exchange Contracts

[0000106040-14-000015:notes:46]
As of June 27, 2014, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $5 million. In addition, as of June 27, 2014, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $4.5 billion and $4.9 billion, and closed $4.9 billion and $3.2 billion, in foreign exchange contracts for the years ended June 27, 2014 and June 28, 2013, respectively. The fair value and balance sheet location of such contracts were as follows (in millions):

[0000106040-14-000015:notes:47]
|  |  | Asset Derivatives |  | Liability Derivatives |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Derivatives Designated asHedging Instruments |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Foreign exchange contracts |  | Other currentassets |  | $ | 7 |  |  | Other currentassets |  | $ | — |  |  | Accruedexpenses |  | $ | 2 |  |  | Accruedexpenses |  | $ | 57 |  |

[0000106040-14-000015:notes:48]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the consolidated balance sheet as of June 27, 2014 (in millions):

[0000106040-14-000015:notes:49]
|  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 9 |  |  | $ | (2 | ) |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |
| Financial liabilities | (4 | ) |  | 2 |  |  | $ | (2 | ) |  | — |  |  | — |  |  | (2 | ) |
| Total derivative instruments | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |

[0000106040-14-000015:notes:50]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the consolidated balance sheet as of June 28, 2013 (in millions):

[0000106040-14-000015:notes:51]
|  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 10 |  |  | $ | (10 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Financial liabilities | (67 | ) |  | 10 |  |  | (57 | ) |  | — |  |  | — |  |  | (57 | ) |
| Total derivative instruments | $ | (57 | ) |  | $ | — |  |  | $ | (57 | ) |  | $ | — |  |  | $ | — |  |  | $ | (57 | ) |

[0000106040-14-000015:notes:52]
The impact on the consolidated financial statements was as follows (in millions):

[0000106040-14-000015:notes:53]
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain(Loss)Recognized inAccumulatedOther Comprehensive Incomeon Derivatives |  | Location of GainReclassified fromAccumulatedOther Comprehensive Income into Income |  | Amount of Gain (Loss)ReclassifiedfromAccumulatedOther Comprehensive Income intoIncome |
|  | 2014 |  | 2013 |  |  |  | 2014 |  | 2013 |
| Foreign exchange contracts |  | $ | 13 |  |  | $ | 13 |  |  | Cost of revenue |  | $ | (38 | ) |  | $ | 43 |  |

[0000106040-14-000015:notes:54]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the consolidated financial statements during 2014, 2013 and 2012, respectively. See Notes 1 and 10 for additional disclosures related to the Company’s foreign exchange contracts.


## us-gaap:DerivativesPolicyTextBlock

[0000106040-14-000015:notes:55]
Foreign Exchange Contracts

[0000106040-14-000015:notes:56]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for trading purposes. The Company had foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges and had an aggregate notional amount of $1.5 billion and $2.0 billion at June 27, 2014 and June 28, 2013, respectively.

[0000106040-14-000015:notes:57]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax and presented within cash flow from operations. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial for all years presented.

[0000106040-14-000015:notes:58]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of operating expenses. All fair value hedges were determined to be effective. The fair value and the changes in fair value on these contracts were immaterial to the consolidated financial statements for all years presented. See Notes 10 and 12 for additional disclosures related to foreign exchange contracts.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000106040-14-000015:notes:59]
Income per Common Share

[0000106040-14-000015:notes:60]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include certain dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and restricted stock unit awards (“RSUs”).

[0000106040-14-000015:notes:61]
The following table illustrates the computation of basic and diluted income per common share (in millions, except per share data):

[0000106040-14-000015:notes:62]
|  | Years Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| Net income | $ | 1,617 |  |  | $ | 980 |  |  | $ | 1,612 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 235 |  |  | 241 |  |  | 241 |  |
| Employee stock options and other | 7 |  |  | 5 |  |  | 4 |  |
| Diluted | 242 |  |  | 246 |  |  | 245 |  |
| Income per common share: |  |  |  |  |  |
| Basic | $ | 6.88 |  |  | $ | 4.07 |  |  | $ | 6.69 |  |
| Diluted | $ | 6.68 |  |  | $ | 3.98 |  |  | $ | 6.58 |  |
| Anti-dilutive potential common shares excluded* | 2 |  |  | 3 |  |  | 5 |  |

[0000106040-14-000015:notes:63]
_______________

[0000106040-14-000015:notes:64]
| * | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-14-000015:notes:65]
Note 10. Fair Value Measurements

[0000106040-14-000015:notes:66]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-14-000015:notes:67]
Level 1. Quoted prices in active markets for identical assets or liabilities.

[0000106040-14-000015:notes:68]
Level 2. Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-14-000015:notes:69]
Level 3. Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-14-000015:notes:70]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 27, 2014, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-14-000015:notes:71]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 756 |  |  | $ | — |  |  | $ | — |  |  | $ | 756 |  |
| Bank acceptances | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 756 |  |  | 1 |  |  | — |  |  | 757 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Commercial paper | — |  |  | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Total short-term investments | — |  |  | 284 |  |  | — |  |  | 284 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 180 |  |  | — |  |  | 180 |  |
| U.S. Government agency securities | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total long-term investments | — |  |  | 215 |  |  | — |  |  | 215 |  |
| Foreign exchange contracts | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total assets at fair value | $ | 756 |  |  | $ | 507 |  |  | $ | — |  |  | $ | 1,263 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0000106040-14-000015:notes:72]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 28, 2013, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-14-000015:notes:73]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 1,227 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,227 |  |
| Auction-rate securities | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Total assets at fair value | $ | 1,227 |  |  | $ | — |  |  | $ | 14 |  |  | $ | 1,241 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 57 |  |  | $ | — |  |  | $ | 57 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 57 |  |  | $ | — |  |  | $ | 57 |  |

[0000106040-14-000015:notes:74]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government Agency securities and are recorded within cash and cash equivalents in the consolidated balance sheets. Money market funds are valued based on quoted market prices.

[0000106040-14-000015:notes:75]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party and recorded within cash and cash equivalents or short-term investments in the consolidated balance sheets depending on their original maturities. Certificates of deposit are valued using fixed interest rates.

[0000106040-14-000015:notes:76]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party with original maturities of twelve months or less and are recorded within short-term investments in the consolidated balance sheets. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000015:notes:77]
U.S. Government Agency Securities. The Company’s U.S. Government agency securities are investments in fixed income securities sponsored by the U.S. Government and are held in custody by a third party and recorded within short-term investments or long term other assets in the consolidated balance sheets depending on their original maturities. U.S. Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000015:notes:78]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government, are held in custody by a third party and are recorded within cash and cash equivalents or long-term other assets in the consolidated balance sheets depending on their original maturities. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000015:notes:79]
Bank Acceptances. The Company’s bank acceptances are held in custody by a third party and recorded within cash and cash equivalents in the consolidated balance sheets. Bank acceptances are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000015:notes:80]
Auction-Rate Securities. The Company’s auction-rate securities had maturity dates through 2050, were primarily backed by insurance products and were accounted for as available-for-sale securities. These investments were classified as long-term investments and recorded within other non-current assets in the consolidated balance sheets. Auction-rate securities were valued by a third party using unobservable inputs including indicative bids on similar securities. During 2014, the Company sold its auction rate securities for total proceeds of $17 million and recorded a gain of $3 million within interest and other income in the consolidated statements of income.

[0000106040-14-000015:notes:81]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are classified within other current assets and liabilities in the consolidated balance sheets. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the consolidated balance sheets. For more information on the Company's foreign exchange contracts, see Note 12. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates.

[0000106040-14-000015:notes:82]
In 2014, there were no transfers between levels. However, in 2014 the Company sold its remaining Level 3 financial assets measured on a recurring basis. In addition, in 2012, the Company had a $1 million settlement in its Level 3 financial assets measured on a recurring basis, reducing the balance from $15 million to $14 million.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-14-000015:notes:83]
Note 13. Goodwill and Other Intangible Assets

[0000106040-14-000015:notes:84]
The following table summarizes goodwill activity over the last three fiscal years (in millions):

[0000106040-14-000015:notes:85]
|  |  | Carrying Amount |
| Balance as of June 29, 2012 |  | $ | 1,975 |  |
| Purchase price adjustments to goodwill |  | (21 | ) |
| Balance as of June 28, 2013 |  | $ | 1,954 |  |
| Goodwill recorded in connection with acquisitions |  | 605 |  |
| Balance as of June 27, 2014 |  | $ | 2,559 |  |

[0000106040-14-000015:notes:86]
Other intangible assets consist primarily of technology acquired in business combinations and are amortized on a straight-line basis over the respective estimated useful lives of the assets. Intangible assets as of June 27, 2014 were as follows:

[0000106040-14-000015:notes:87]
|  |  | Weighted AverageAmortizationPeriod |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  |  | (in years) |  | (in millions) |  | (in millions) |  | (in millions) |
| Existing technology |  | 5 |  |  | $ | 566 |  |  | $ | 368 |  |  | $ | 198 |  |
| Customer relationships |  | 4 |  |  | 148 |  |  | 97 |  |  | 51 |  |
| Other |  | 3 |  |  | 73 |  |  | 55 |  |  | 18 |  |
| Leasehold interests |  | 32 |  |  | 43 |  |  | 10 |  |  | 33 |  |
| In-process research and development |  | — |  |  | 154 |  |  | — |  |  | 154 |  |
| Total |  |  |  | $ | 984 |  |  | $ | 530 |  |  | $ | 454 |  |

[0000106040-14-000015:notes:88]
Intangible assets as of June 28, 2013 were as follows:

[0000106040-14-000015:notes:89]
|  |  | Weighted AverageAmortization Period |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  |  | (in years) |  | (in millions) |  | (in millions) |  | (in millions) |
| Existing technology |  | 5 |  |  | $ | 561 |  |  | $ | 245 |  |  | $ | 316 |  |
| Customer relationships |  | 4 |  |  | 139 |  |  | 57 |  |  | 82 |  |
| Other |  | 3 |  |  | 65 |  |  | 36 |  |  | 29 |  |
| Leasehold interests |  | 31 |  |  | 40 |  |  | 5 |  |  | 35 |  |
| In-process research and development |  | — |  |  | 143 |  |  | — |  |  | 143 |  |
| Total |  |  |  | $ | 948 |  |  | $ | 343 |  |  | $ | 605 |  |

[0000106040-14-000015:notes:90]
Other intangible assets in the table above include a joint development agreement, trade names and a non-compete agreement. Amortization expense for intangible assets was $213 million, $209 million and $79 million for 2014, 2013 and 2012, respectively. During 2014, the Company recorded $53 million of impairment charges related to intangible assets. As of June 27, 2014, estimated future amortization expense for intangible assets currently subject to amortization is $153 million for 2015, $71 million for 2016, $42 million for 2017, $6 million for 2018 and $2 million for 2019.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000106040-14-000015:notes:91]
Goodwill and Other Long-Lived Assets

[0000106040-14-000015:notes:92]
The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with amounts exceeding the fair values being recognized as goodwill. Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs its annual impairment test as of the first day of its fiscal fourth quarter. The Company either uses qualitative factors to determine whether goodwill is more likely than not impaired or performs a two-step approach to quantify impairment. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, it is required to follow a two-step approach to quantify the impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment for each reporting unit. The Company did not record any impairment of goodwill during 2014, 2013, or 2012.

[0000106040-14-000015:notes:93]
Other intangible assets consist primarily of technology acquired in business combinations and in-process research and development. In-process research and development is not amortized until the point at which it reaches technological feasibility. Instead, it is instead tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. Acquired intangibles are amortized on a straight-line basis over their respective estimated useful lives. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The Company recorded impairments to certain long-lived assets in 2014, 2013 and 2012. See Notes 13 and 17.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-14-000015:notes:94]
Note 9. Income Taxes

[0000106040-14-000015:notes:95]
Pre-tax Income

[0000106040-14-000015:notes:96]
The domestic and foreign components of income before income taxes were as follows for the three years ended June 27, 2014 (in millions):

[0000106040-14-000015:notes:97]
|  | 2014 |  | 2013 |  | 2012 |
| Foreign | $ | 1,664 |  |  | $ | 870 |  |  | $ | 1,559 |  |
| Domestic | 88 |  |  | 352 |  |  | 198 |  |
| Income before income taxes | $ | 1,752 |  |  | $ | 1,222 |  |  | $ | 1,757 |  |

[0000106040-14-000015:notes:98]
Income Tax Provision

[0000106040-14-000015:notes:99]
The components of the provision for income taxes were as follows for the three years ended June 27, 2014 (in millions):

[0000106040-14-000015:notes:100]
|  | 2014 |  | 2013 |  | 2012 |
| Current: |  |  |  |  |  |
| Foreign | $ | 47 |  |  | $ | 57 |  |  | $ | 12 |  |
| Domestic-federal | 98 |  |  | 149 |  |  | 98 |  |
| Domestic-state | 3 |  |  | 1 |  |  | 1 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (3 | ) |  | (7 | ) |  | 18 |  |
| Domestic-federal | (14 | ) |  | (46 | ) |  | 25 |  |
| Domestic-state | 4 |  |  | 88 |  |  | (9 | ) |
| Income tax provision | $ | 135 |  |  | $ | 242 |  |  | $ | 145 |  |

[0000106040-14-000015:notes:101]
The Company’s income tax provision for 2013 reflects a tax benefit of $37 million as a result of the retroactive extension of the U.S. Federal research and experimentation tax credit (“R&D credit”) that was signed into law on January 2, 2013 as part of the American Taxpayer Relief Act of 2012. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013. In addition, the Company recorded an $88 million charge to reduce its previously recognized California deferred tax assets in 2013 as a result of the enactment of California Proposition 39.

[0000106040-14-000015:notes:102]
Remaining net undistributed earnings from foreign subsidiaries at June 27, 2014 on which no U.S. tax has been provided amounted to $8.2 billion. The net undistributed earnings are intended to finance local operating requirements and capital investments. Accordingly, an additional U.S. tax provision has not been made on these earnings. The tax liability for these earnings would be $2.7 billion if the Company repatriated the $8.2 billion in undistributed earnings from the foreign subsidiaries.

[0000106040-14-000015:notes:103]
Deferred Taxes

[0000106040-14-000015:notes:104]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities as of June 27, 2014 and June 28, 2013 were as follows (in millions):

[0000106040-14-000015:notes:105]
|  | 2014 |  | 2013 |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 38 |  |  | $ | 45 |  |
| Accrued compensation and benefits not currently deductible | 190 |  |  | 182 |  |
| Domestic net operating loss carryforward | 130 |  |  | 103 |  |
| Business credit carryforward | 155 |  |  | 123 |  |
| Long-lived assets | 58 |  |  | 47 |  |
| Other | 65 |  |  | 71 |  |
| Total deferred tax assets | 636 |  |  | 571 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (152 | ) |  | (156 | ) |
| Other | (11 | ) |  | — |  |
| Total deferred tax liabilities | (163 | ) |  | (156 | ) |
| Valuation allowances | (128 | ) |  | (133 | ) |
| Deferred tax assets, net | $ | 345 |  |  | $ | 282 |  |
| Deferred tax assets: |  |  |  |
| Current portion (included in other current assets) | $ | 184 |  |  | $ | 160 |  |
| Non-current portion (included in other non-current assets) | 452 |  |  | 411 |  |
| Total deferred tax assets | 636 |  |  | 571 |  |
| Deferred tax liabilities: |  |  |  |
| Current portion (included in other current assets) | (2 | ) |  | — |  |
| Non-current portion (included in other non-current assets) | (161 | ) |  | (156 | ) |
| Total deferred tax liabilities | (163 | ) |  | (156 | ) |
| Valuation allowances (included in non-current portion of deferred tax assets) | (128 | ) |  | (133 | ) |
| Deferred tax assets, net | $ | 345 |  |  | $ | 282 |  |

[0000106040-14-000015:notes:106]
The net deferred tax asset valuation allowance was $128 million as of June 27, 2014. The valuation allowance is based on the Company’s assessment that it is more likely than not that certain deferred tax assets will not be realized in the foreseeable future.

[0000106040-14-000015:notes:107]
In addition to the deferred tax assets presented above, the Company had additional NOL benefits related to stock-based compensation deductions of $11 million and $13 million at June 27, 2014 and June 28, 2013, respectively. During the current year, the Company generated an additional $66 million of benefits related to stock-based compensation deductions, of which $60 million were utilized in the current year and recorded as a credit to shareholder's equity.

[0000106040-14-000015:notes:108]
Effective Tax Rate

[0000106040-14-000015:notes:109]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows for the three years ended June 27, 2014:

[0000106040-14-000015:notes:110]
|  | 2014 |  | 2013 |  | 2012 |
| U.S. Federal statutory rate | 35 | % |  | 35 | % |  | 35 | % |
| Tax rate differential on international income | (28 | ) |  | (19 | ) |  | (29 | ) |
| Tax effect of U.S. permanent differences | 2 |  |  | — |  |  | 3 |  |
| State income tax, net of federal tax | — |  |  | 8 |  |  | 1 |  |
| Income tax credits | (1 | ) |  | (4 | ) |  | (2 | ) |
| Effective tax rate | 8 | % |  | 20 | % |  | 8 | % |

[0000106040-14-000015:notes:111]
Tax Holidays and Carryforwards

[0000106040-14-000015:notes:112]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines, Singapore and Thailand operate under various tax holidays and tax incentive programs which will expire in whole or in part at various dates from 2015 through 2025. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was to increase the Company’s net earnings by $905 million ($3.74 per diluted share), $899 million ($3.65 per diluted share), and $729 million ($2.98 per diluted share) in 2014, 2013 and 2012, respectively.

[0000106040-14-000015:notes:113]
As of June 27, 2014, the Company had federal and state NOL carryforwards of $440 million and $480 million, respectively. In addition, as of June 27, 2014, the Company had various federal and state tax credit carryforwards of $331 million combined. The NOL carryforwards available to offset future federal and state taxable income expire at various dates from 2020 to 2032 and 2017 to 2032, respectively. Approximately $50 million of the credit carryforwards available to offset future taxable income expire at various dates from 2016 to 2033. The remaining amount is available indefinitely. NOLs and credits relating to Komag, Incorporated (“Komag”), which was acquired by the Company on September 5, 2007, HGST, sTec and Virident are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company does not expect these limitations to result in a reduction in the total amount of Komag, sTec or Virident's NOLs and credits ultimately realized. The Company expects the total amount of HGST’s NOLs and credits ultimately realized will be reduced by $39 million and $25 million, respectively. Because the Company expects the amount of HGST’s NOLs and credits ultimately realized will be reduced, the Company has adjusted goodwill accordingly.

[0000106040-14-000015:notes:114]
Uncertain Tax Positions

[0000106040-14-000015:notes:115]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. First, the tax position is evaluated for recognition by determining if it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to be recognized in the financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Company’s balance sheet. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. As of June 27, 2014, such interest and penalties were not material. As of June 27, 2014, the Company had $300 million of unrecognized tax benefits.

[0000106040-14-000015:notes:116]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits for the years ended June 27, 2014, June 28, 2013 and June 29, 2012 (in millions):

[0000106040-14-000015:notes:117]
|  | 2014 |  | 2013 |  | 2012 |
| Unrecognized tax benefit at beginning of period | $ | 240 |  |  | $ | 280 |  |  | $ | 245 |  |
| Gross increases related to current year tax positions | 27 |  |  | 29 |  |  | 14 |  |
| Gross increases related to prior year tax positions | 26 |  |  | 10 |  |  | — |  |
| Gross decreases related to prior year tax positions | (5 | ) |  | (8 | ) |  | — |  |
| Settlements | — |  |  | (64 | ) |  | (18 | ) |
| Lapse of statute of limitations | — |  |  | (7 | ) |  | — |  |
| Acquisitions | 12 |  |  | — |  |  | 39 |  |
| Unrecognized tax benefit at end of period | $ | 300 |  |  | $ | 240 |  |  | $ | 280 |  |

[0000106040-14-000015:notes:118]
The Company’s unrecognized tax benefits are primarily included within long-term liabilities in the Company’s consolidated balance sheets. The entire balance of unrecognized tax benefits at June 27, 2014, June 28, 2013 and June 29, 2012, if recognized, would affect the effective tax rate.

[0000106040-14-000015:notes:119]
The Company files U.S. Federal, U.S. state, and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2008 through 2013. In foreign jurisdictions, with few exceptions, the Company is subject to examination for all years subsequent to fiscal 2007. The Company is no longer subject to examination by the IRS for periods prior to 2008, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period.

[0000106040-14-000015:notes:120]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 and 2007 and issued Revenue Agent Reports that proposed adjustments to income before income taxes of approximately $970 million primarily related to transfer pricing and intercompany payable balances. The Company disagreed with the proposed adjustments and filed a protest with the IRS Appeals Office. In June 2013, the Company reached an agreement with the IRS to resolve the transfer pricing issue. This agreement resulted in a decrease in the amount of net operating loss and tax credits realized, but did not have an impact to the Company’s consolidated statements of income. The proposed adjustment relating to intercompany payable balances for fiscal years 2006 and 2007 will be addressed in conjunction with the IRS’s examination of the Company’s fiscal years 2008 and 2009, which commenced in January 2012. In addition, in January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag. In February 2013, the IRS commenced an examination of calendar years 2010 and 2011 of HGST, which was acquired by the Company on March 8, 2012.

[0000106040-14-000015:notes:121]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 27, 2014, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0000106040-14-000015:notes:122]
Income Taxes

[0000106040-14-000015:notes:123]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized.

[0000106040-14-000015:notes:124]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.


## us-gaap:InventoryPolicyTextBlock

[0000106040-14-000015:notes:125]
Inventories

[0000106040-14-000015:notes:126]
The Company values inventories at the lower of cost (first-in, first out and weighted average methods) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories, while the weighted-average method is used to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by the Company. The Company has determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, precious metals are relieved from inventory based on the weighted-average cost of the inventory at the time the inventory is used in production. The weighted average method of valuing precious metals does not materially differ from a FIFO method. As of June 27, 2014 and June 28, 2013, 92% and 91%, respectively, of the inventory was valued using the FIFO method with the remainder valued using the weighted average method. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-14-000015:notes:127]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.


## us-gaap:InvestmentPolicyTextBlock

[0000106040-14-000015:notes:128]
Investments

[0000106040-14-000015:notes:129]
The Company's investments in U.S. Treasury securities, U.S. Government agency securities, commercial paper and certificates of deposit with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within short-term investments and other non-current assets in the consolidated balance sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of shareholders' equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in interest and other income and other in the consolidated statements of income. In addition, realized gains and losses are included in total other expense, net in the consolidated statements of income.

[0000106040-14-000015:notes:130]
In addition, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the consolidated balance sheets and are periodically analyzed to determine whether or not there are indicators of impairment. Lastly, the Company’s investments included auction-rate securities which were all sold during 2014. The Company's auction rate securities were classified as available-for-sale securities and carried at fair value within other non-current assets in the consolidated balance sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-14-000015:notes:131]
Note 5. Legal Proceedings

[0000106040-14-000015:notes:132]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-14-000015:notes:133]
Solely for purposes of this footnote, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the HGST Closing Date. HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-14-000015:notes:134]
Intellectual Property Litigation

[0000106040-14-000015:notes:135]
On June 20, 2008, plaintiff Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and one other company alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. On October 10, 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. A trial in the matter began on July 18, 2011 and concluded on July 26, 2011 with a verdict against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. WD and HGST have filed post-trial motions challenging the verdict. On January 17, 2014, the Court denied the Company’s motion for judgment as a matter of law on invalidity. On May 20, 2014, the Court ordered supplemental briefing related to post-trial motions related to infringement.  Convolve and the Company filed their supplemental briefs on May 30, 2014 and June 6, 2014, respectively.  Additional post-trial motions are pending, and the Company will evaluate its options for appeal after the Court rules on the remaining post-trial motions. The Company intends to continue to defend itself vigorously in this matter.

[0000106040-14-000015:notes:136]
On December 7, 2009, plaintiff Nazomi Communications (“Nazomi”) filed a complaint in the Eastern District of Texas against WD and seven other companies alleging infringement of U.S. Patent Nos. 7,080,362 and 7,225,436. Nazomi dismissed the Eastern District of Texas suit after filing a similar complaint in the Central District of California on February 8, 2010. The case was subsequently transferred to the Northern District of California on October 14, 2010. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The asserted patents allegedly relate to processor cores capable of Java hardware acceleration. In August 2012, the Court dismissed WD on summary judgment for non-infringement. Nazomi filed a notice of appeal on January 16, 2013. The Federal Circuit heard oral argument on the appeal on November 4, 2013 and affirmed the Court's grant of summary judgment of non-infringement on January 10, 2014. Because Nazomi did not file a petition for a writ of certiorari with the Supreme Court during the requisite time period, this matter is now closed.

[0000106040-14-000015:notes:137]
On August 1, 2011, plaintiff Guzik Technical Enterprises (“Guzik”) filed a complaint in the Northern District of California against WD and various of its subsidiaries alleging infringement of U.S. Patent Nos. 6,023,145 and 6,785,085, breach of contract and misappropriation of trade secrets. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The patents asserted by Guzik allegedly relate to devices used to test hard disk drive heads and media. On November 30, 2013, WD entered into a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company recorded an accrual in the three months ended December 27, 2013. Guzik is disputing the enforceability of the agreement and on December 27, 2013, WD filed a motion to enforce the agreement. The Court heard oral argument on WD’s motion on January 31, 2014.  The Court granted WD’s motion to enforce the settlement agreement on March 21, 2014.  On April 14, 2014, Guzik filed a Notice of Appeal to the Federal Circuit.  On June 17, 2014, Guzik filed its opening appellate brief.  The Company filed its appellate brief on August 14, 2014. WD intends to continue to defend itself vigorously in this matter.

[0000106040-14-000015:notes:138]
On July 9, 2012, Siemens Aktiengesellschaft (“Siemens”) filed a complaint in German court against WD, Western Digital GmbH, and Digital River International, S.a.r.l. alleging patent infringement of European patent no. EP 674769, which claims an artificial antiferromagnetic (AAF) (aka, synthetic antiferromagnetic) structure for magneto-resistive sensors.  On March 14-15, 2013, Western Digital GmbH filed a response of non-infringement and also filed a separate nullity action.  Siemens separately served WD on July 15, 2013. The patent expired on December 16, 2013 and, on March 10, 2014, Siemens withdrew its motion for injunctive relief. On February 5, 2014, the Company filed a submission in support of its nullity action. On March 25, 2014, Siemens served an extension of the complaint including WDT as a defendant. On March 28, 2014, Siemens filed its response to WD’s noninfringement submission. On June 27, 2014, WDT filed its response to the extension of the complaint. On or around July 14, 2014, Siemens filed a response to the Company’s nullity action.  On July 18, 2014, the Company filed two expert opinions in support of its nullity action. Siemens has until September 5, 2014 to respond to WDT’s response to the extension of the complaint. WD’s deadline to make its last noninfringement submission is September 26, 2014. The oral hearing on infringement is scheduled for October 2, 2014. The oral hearing on the nullity action to challenge the validity of the patent is scheduled for February 3, 2015. WD intends to defend itself vigorously in this matter.

[0000106040-14-000015:notes:139]
On September 5, 2013, plaintiff Lake Cherokee Hard Drive Technologies, LLC (“Lake Cherokee”) filed a complaint in the Eastern District of Texas against: Marvell Asia PTE, Ltd., Samsung Semiconductor, Inc., Seagate Tech. LLC, Seagate Tech. Int’l., Toshiba Corp., Toshiba Am. Elec. Components, Toshiba Am. Inf. Sys., Inc., Toshiba Am. Inf. Equip. (Philippines), Inc., and WDT alleging infringement of US Patent Nos. 5,844,738 and 5,978,162. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’738 and ’162 patents.  The complaint seeks unspecified monetary damages, fees and costs. On April 3, 2014, Lake Cherokee and Marvell Semiconductor, Inc. (“MSI”) engaged in mediation which resulted in a settlement-in-principle on April 8, 2014.  On April 21, 2014, Lake Cherokee and MSI filed a motion to stay deadlines while the parties finalized a settlement agreement.  In this motion, Lake Cherokee and MSI represented to the Court that the settlement between Lake Cherokee and MSI will result in a with-prejudice dismissal of Lake Cherokee’s claims against each of the defendants, including WDT, with respect to their sale or use of Marvell chips.  On April 23, 2014, the Court granted a stay of deadlines.  On June 6, 2014, Lake Cherokee and MSI participated in an arbitration hearing as to the remaining settlement agreement disputes. WDT intends to defend itself vigorously in this matter.

[0000106040-14-000015:notes:140]
On September 25, 2013, plaintiff Lake Cherokee filed a complaint in the Eastern District of Texas against: Marvell Semiconductor, Inc., Marvell Asia PTE, Ltd., Dell Inc., and WDT alleging infringement of US Patent No. 5,583,706. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’706 patent.  The complaint seeks an injunction, unspecified monetary damages, fees and costs. On April 3, 2014, Lake Cherokee and MSI engaged in mediation which resulted in a settlement-in-principle on April 8, 2014.  On April 21, 2014, Lake Cherokee and MSI filed a motion to stay deadlines while the parties finalized a settlement agreement.  In this motion, Lake Cherokee and MSI represented to the Court that the settlement between Lake Cherokee and MSI will result in a with-prejudice dismissal of Lake Cherokee’s claims against each of the defendants, including WDT, with respect to their sale or use of Marvell chips.  On April 23, 2014, the Court granted a stay of deadlines.  On June 6, 2014, Lake Cherokee and MSI participated in an arbitration hearing as to the remaining settlement agreement disputes. WDT intends to defend itself vigorously in this matter.

[0000106040-14-000015:notes:141]
On March 24, 2014, plaintiff Steven F. Reiber (“Reiber”) filed a complaint in the Eastern District of California against the Company, alleging infringement of U.S. Patent Nos. 7,124,927 and 7,389,905.  Reiber alleges that the Company’s actions of making, using, distributing, offering for sale and selling in the United States and importing into the United States HDD heads, head gimbal assemblies, and head stack assemblies infringe the claims of the two patents at issue. The complaint seeks an injunction, unspecified monetary damages, fees and costs. Pursuant to the parties' stipulations, the Court has extended the deadline for the Company to respond to the Complaint to September 8, 2014, and set the parties' status conference for October 30, 2014. The Company intends to defend itself vigorously in this matter.

[0000106040-14-000015:notes:142]
Seagate Matter

[0000106040-14-000015:notes:143]
On October 4, 2006, plaintiff Seagate Technology LLC (“Seagate”) filed an action in the District Court of Hennepin County, Minnesota, naming as defendants WD and one of its now former employees previously employed by Seagate. The complaint in the action alleged claims based on supposed misappropriation of trade secrets and sought injunctive relief and unspecified monetary damages, fees and costs. On June 19, 2007, WD’s former employee filed a demand for arbitration with the American Arbitration Association. A motion to stay the litigation as against all defendants and to compel arbitration of all Seagate’s claims was granted on September 19, 2007. On September 23, 2010, Seagate filed a motion to amend its claims and add allegations based on the supposed misappropriation of additional confidential information, and the arbitrator granted Seagate’s motion. The arbitration hearing commenced on May 23, 2011 and concluded on July 11, 2011.

[0000106040-14-000015:notes:144]
On November 18, 2011, the sole arbitrator ruled in favor of WD in connection with five of the eight alleged trade secrets at issue, based on evidence that such trade secrets were known publicly at the time the former employee joined WD. Based on a determination that the employee had fabricated evidence, the arbitrator then concluded that WD had to know of the fabrications. As a sanction, the arbitrator precluded any evidence or defense by WD disputing the validity, misappropriation, or use of the three remaining alleged trade secrets by WD, and entered judgment in favor of Seagate with respect to such trade secrets. Using an unjust enrichment theory of damages, the arbitrator issued an interim award against WD in the amount of $525 million plus pre-award interest at the Minnesota statutory rate of 10% per year. In his decision with respect to these three trade secrets, the arbitrator did not question the relevance, veracity or credibility of any of WD’s ten expert and fact witnesses (other than WD’s former employee), nor the authenticity of any other evidence WD presented. On January 23, 2012, the arbitrator issued a final award adding pre-award interest in the amount of $105.4 million for a total final award of $630.4 million.  On January 23, 2012, WD filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated. A hearing on the petition to vacate was held on March 1, 2012.

[0000106040-14-000015:notes:145]
On October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award. Specifically, the Court confirmed the arbitration award with respect to each of the five trade secret claims that WD and the former employee had won at the arbitration and vacated the arbitration award with respect to the three trade secret claims that WD and the former employee had lost at the arbitration. The Court ordered that a rehearing be held concerning those three alleged trade secret claims before a new arbitrator.

[0000106040-14-000015:notes:146]
On October 30, 2012, Seagate initiated an appeal of the Court’s decision with the Minnesota Court of Appeals.  On July 22, 2013, the Minnesota Court of Appeals reversed the District Court’s decision and remanded for entry of an order and judgment confirming the arbitration award. The Company strongly disagrees with the decision of the Court of Appeals and believes that the District Court’s decision was correct.  On August 20, 2013, the Company filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, the Company was informed that the Minnesota Supreme Court granted the Company’s petition. The appeal before the Minnesota Supreme Court was fully briefed, and oral argument was held on February 5, 2014. The Company will continue to vigorously defend itself in this matter. In light of uncertainties with respect to this matter, the Company recorded an accrual of $681 million for this matter in its financial statements in the fourth quarter of fiscal 2013 and recorded additional interest totaling $52 million in 2014, which is included within charges related to arbitration award in the consolidated statements of income. This amount is in addition to the $25 million previously accrued in the fourth quarter of fiscal 2011. The total amount accrued of $758 million represents the amount of the final arbitration award, plus interest accrued on the initial arbitration award at the statutory rate of 10% from January 24, 2012 through June 27, 2014.

[0000106040-14-000015:notes:147]
Other Matters

[0000106040-14-000015:notes:148]
On December 22, 2011 the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), ("ZPÜ”), an organization consisting of several levy collecting societies, submitted a pleading to the Copyright Arbitration Board (“CAB”) in Munich claiming retroactive copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD from January 2008 through December 2010.  The CAB was required to issue a settlement proposal within one year of the initiation of the action, failed to do so and requested the parties to consent to continue the deadline.  WD declined to provide consent and, on February 1, 2013, WD filed a declaratory relief against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. On May 22, 2014, oral argument on the pleadings occurred.  A decision from the Higher Court is expected by October 30, 2014, which either party may appeal. WD intends to defend itself vigorously in this matter.

[0000106040-14-000015:notes:149]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties and is therefore not predictable with assurance, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, there can be no assurance with respect to such result, and monetary liability or financial impact to the Company from these other matters could differ materially from those projected.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-14-000015:notes:150]
Note 1. Organization and Summary of Significant Accounting Policies

[0000106040-14-000015:notes:151]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. The Company's product portfolio includes hard disk drives (“HDDs”) and solid-state drives ("SSDs"). HDDs are the Company's principal products and are today’s primary storage medium for digital content, with the use of solid-state storage products growing rapidly. The Company's products are marketed under the HGST, WD and G-Technology brand names.  The Company currently operate our global business through two independent subsidiaries due to regulatory requirements—HGST and WD.

[0000106040-14-000015:notes:152]
The Company has prepared its consolidated financial statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-14-000015:notes:153]
Fiscal Year

[0000106040-14-000015:notes:154]
The Company has a 52 or 53-week fiscal year. The 2014, 2013 and 2012 fiscal years which ended on June 27, 2014, June 28, 2013 and June 29, 2012, respectively, consisted of 52 weeks each.

[0000106040-14-000015:notes:155]
Basis of Presentation

[0000106040-14-000015:notes:156]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. In fiscal 2014 and fiscal 2013, the accounts for all foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. In fiscal 2012, the accounts for all foreign subsidiaries, except for one Japanese subsidiary in which Yen was the functional currency, have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement or translation of these accounts from local currencies into U.S. dollars were immaterial to the consolidated financial statements.

[0000106040-14-000015:notes:157]
The Company acquired Virident Systems, Inc. ("Virident") on October 17, 2013, sTec, Inc. (“sTec”) on September 12, 2013, and VeloBit, Inc. ("VeloBit") on July 9, 2013. In addition, on March 8, 2012, the Company completed its acquisition of all of the issued and paid-up share capital of Viviti Technologies Ltd., known until shortly before acquisition as Hitachi Global Storage Technologies Holdings Pte. Ltd. (“HGST”), from Hitachi, Ltd. (“Hitachi”). These acquisitions are further described in Note 15 below. In connection with the acquisitions, Virident, sTec, VeloBit and HGST became indirect wholly-owned subsidiaries of the Company. The results of operations of Virident, sTec, VeloBit and HGST since the respective dates of acquisition are included in the consolidated financial statements.

[0000106040-14-000015:notes:158]
Fair Value of Financial Instruments

[0000106040-14-000015:notes:159]
The carrying amounts of cash equivalents, accounts receivable, investments, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities or, in the case of investments, these are recorded using appropriate market information. The carrying amount of debt approximates fair value because of its variable interest rate.

[0000106040-14-000015:notes:160]
Concentration of Credit Risk

[0000106040-14-000015:notes:161]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. At June 27, 2014 and June 28, 2013, the Company had two customers that accounted for 29% of the Company's net accounts receivable. At June 27, 2014 and June 28, 2013, the Company had reserves for potential credit losses of $11 million and $9 million, respectively, and net accounts receivable of $2.0 billion and $1.8 billion at each date, respectively.

[0000106040-14-000015:notes:162]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-14-000015:notes:163]
Property, Plant and Equipment

[0000106040-14-000015:notes:164]
The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s equipment is depreciated over periods of two to seven years. Depreciation is computed on a straight-line basis. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-14-000015:notes:165]
Revenue and Accounts Receivable

[0000106040-14-000015:notes:166]
Revenue is recognized when the title and risk of loss have passed to the customer, there is persuasive evidence of an arrangement, delivery has occurred, or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured. The Company establishes provisions against revenue and cost of revenue for estimated sales returns in the same period that the related revenue is recognized based on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-14-000015:notes:167]
In accordance with standard industry practice, the Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions, and the Company provides resellers and OEMs with other sales incentive programs. At the time the Company recognizes revenue to resellers and OEMs, a reduction of revenue is recorded for estimated price protection until the resellers sell such inventory to their customers and the Company also records a reduction of revenue for the other programs in effect. The Company bases these adjustments on several factors including anticipated price decreases during the reseller holding period, reseller’s sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information and customer claim processing. If customer demand for the Company's products or market conditions differ from the Company’s expectations, the Company’s operating results could be materially affected. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. Customer sales incentive and marketing programs are recorded as a reduction of revenue.

[0000106040-14-000015:notes:168]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-14-000015:notes:169]
Warranty

[0000106040-14-000015:notes:170]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on hard drive reliability, such as factory test data, historical field return rates, and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected.

[0000106040-14-000015:notes:171]
Litigation and Other Contingencies

[0000106040-14-000015:notes:172]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 5.

[0000106040-14-000015:notes:173]
Stock-based Compensation

[0000106040-14-000015:notes:174]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options and cash-settled stock appreciation rights (“SARs”) granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. The Company accounts for SARs as liability awards based upon management’s intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. The Company is required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and the results of operations could be materially affected.

[0000106040-14-000015:notes:175]
Other Comprehensive Income (Loss)

[0000106040-14-000015:notes:176]
Other comprehensive income (loss) refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss) is comprised of unrealized gains and losses on foreign exchange contracts, unrealized gains and losses on the Company's available-for-sale securities, foreign currency translation gains and losses and actuarial gains and losses related to pensions. The income tax impact on components of other comprehensive income is immaterial for all periods presented.

[0000106040-14-000015:notes:177]
The following table illustrates the changes in the balances of each component of accumulated comprehensive income for 2014, 2013 and 2012:

[0000106040-14-000015:notes:178]
|  | ActuarialPensionGains(Losses) |  | ForeignCurrencyTranslationGains(Losses) |  | UnrealizedGains(Losses)on ForeignExchangeContracts |  | AccumulatedOtherComprehensiveIncome (Loss) |
| Balance at July 1, 2011 | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (5 | ) |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | (12 | ) |  | (12 | ) |
| Amounts reclassified from accumulated other comprehensive income | (3 | ) |  | 4 |  |  | 1 |  |  | 2 |  |
| Net current-period other comprehensive income (loss) | (3 | ) |  | 4 |  |  | (11 | ) |  | (10 | ) |
| Balance at June 29, 2012 | $ | (3 | ) |  | $ | 4 |  |  | $ | (16 | ) |  | $ | (15 | ) |
| Other comprehensive loss before reclassifications | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Amounts reclassified from accumulated other comprehensive income | 14 |  |  | (4 | ) |  | (43 | ) |  | (33 | ) |
| Net current-period other comprehensive income (loss) | 14 |  |  | (4 | ) |  | (30 | ) |  | (20 | ) |
| Balance at June 28, 2013 | $ | 11 |  |  | $ | — |  |  | $ | (46 | ) |  | $ | (35 | ) |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Amounts reclassified from accumulated other comprehensive income | (4 | ) |  | — |  |  | 38 |  |  | 34 |  |
| Net current-period other comprehensive income (loss) | (4 | ) |  | — |  |  | 51 |  |  | 47 |  |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 12 |  |

[0000106040-14-000015:notes:179]
Pensions and Other Postretirement Benefit Plans

[0000106040-14-000015:notes:180]
The Company has defined benefit pension plans and other postretirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and postretirement plans in the consolidated balance sheets, with changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. See Note 14 for additional disclosures related to the Company’s pension and other postretirement benefit plans.

[0000106040-14-000015:notes:181]
Use of Estimates

[0000106040-14-000015:notes:182]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-14-000015:notes:183]
Recent Accounting Pronouncements

[0000106040-14-000015:notes:184]
In February 2013, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2013-02, “Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income” (“ASU 2013-02”). The new standard requires an entity to provide information about the amounts reclassified out of accumulated other comprehensive income by component. The Company adopted this pronouncement in the first quarter of fiscal 2014. Since ASU 2013-02 related only to the presentation and disclosure of information, it did not have a material effect on the Company’s consolidated financial statements.

[0000106040-14-000015:notes:185]
In July 2013, the FASB issued ASU 2013-11, "Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists" ("ASU 2013-11"). The new standard requires the presentation of certain unrecognized tax benefits as reductions to deferred tax assets rather than as liabilities in the consolidated balance sheets when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2013, which for the Company is the first quarter of fiscal 2015. The Company does not expect the adoption of ASU 2013-11 to have a material impact on its consolidated financial statements.

[0000106040-14-000015:notes:186]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification ("ASC") Topic 605, "Revenue Recognition", to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years beginning after December 15, 2016, which for the Company is the first quarter of fiscal 2018. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.

[0000106040-14-000015:notes:187]
In April 2014, the FASB issued ASU 2014-08, "Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity" ("ASU 2014-08"), which amends the criteria for determining which disposals can be presented as discontinued operations and enhances related disclosure requirements. Under the new guidance, a disposal of a component of an entity or a group of components of an entity is required to be reported in discontinued operations if the disposal represents a strategic shift that has or may have a major effect on an entity’s operations and financial results. The new standard is effective for fiscal years beginning after December 15, 2014, which for the Company is the first quarter of fiscal 2016. The Company does not expect the adoption of ASU 2014-08 to have a material impact on its consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-14-000015:notes:188]
Note 14. Pensions and Other Post-retirement Benefit Plans

[0000106040-14-000015:notes:189]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s consolidated financial statements.

[0000106040-14-000015:notes:190]
Obligations and Funded Status

[0000106040-14-000015:notes:191]
_____________________

[0000106040-14-000015:notes:192]
| (1) | During fiscal 2014 the Japan entity assumed benefit obligations and plan assets from Hitachi. These pension obligations related to former Hitachi employees who were hired into the HGST Japan entity during or soon after the 2012 acquisition of HGST by the Company. |

[0000106040-14-000015:notes:193]
The following table presents the unfunded amounts as recognized on the Company’s consolidated balance sheets as of June 27, 2014 and June 28, 2013 (in millions):

[0000106040-14-000015:notes:194]
|  | 2014 |  | 2013 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 63 |  |  | 66 |  |
| Net amount recognized | $ | 64 |  |  | $ | 67 |  |

[0000106040-14-000015:notes:195]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $255 million at June 27, 2014. As of June 27, 2014, net actuarial losses for the Japanese defined benefit pension plans of $10 million are included in accumulated other comprehensive income (loss) in the consolidated balance. There were no prior service credits for the defined benefit pension plans recognized in accumulated other comprehensive income (loss) in the consolidated balance sheet as of June 27, 2014. The amount expected to be amortized into net periodic benefit cost in fiscal 2015 is immaterial to the consolidated financial statements.

[0000106040-14-000015:notes:196]
Assumptions

[0000106040-14-000015:notes:197]
Weighted-Average Assumptions

[0000106040-14-000015:notes:198]
The weighted-average actuarial assumptions used to determine benefit obligations for the Japanese defined benefit pension plans were as follows for 2014, 2013 and 2012:

[0000106040-14-000015:notes:199]
|  | 2014 |  | 2013 |  | 2012 |
| Discount rate | 1.6 | % |  | 1.6 | % |  | 1.8 | % |
| Rate of compensation increase | 1.0 | % |  | 0.9 | % |  | 1.4 | % |

[0000106040-14-000015:notes:200]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows for 2014, 2013 and 2012:

[0000106040-14-000015:notes:201]
|  | 2014 |  | 2013 |  | 2012 |
| Discount rate | 1.6 | % |  | 1.8 | % |  | 1.9 | % |
| Expected long-term rate of return on plan assets | 3.5 | % |  | 3.5 | % |  | 3.5 | % |
| Rate of compensation increase | 0.9 | % |  | 1.2 | % |  | 1.4 | % |

[0000106040-14-000015:notes:202]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to AA or higher bond ratings that match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-14-000015:notes:203]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. Management’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-14-000015:notes:204]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-14-000015:notes:205]
Plan Assets

[0000106040-14-000015:notes:206]
Investment Policies and Strategies

[0000106040-14-000015:notes:207]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks, and the current economic environment. The target asset allocation is 35% in equity securities, 62% in debt securities and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance, and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset, and the latest economic environment.

[0000106040-14-000015:notes:208]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions, and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts, and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-14-000015:notes:209]
Fair Value Measurements

[0000106040-14-000015:notes:210]
The following table presents the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 27, 2014 (in millions):

[0000106040-14-000015:notes:211]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds (1)(2) | $ | — |  |  | $ | 69 |  |  | $ | — |  |  | $ | 69 |  |
| Fixed income: |  |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds (1)(3) | — |  |  | 111 |  |  | — |  |  | 111 |  |
| Cash and short-term investments (3) | 8 |  |  | 3 |  |  | — |  |  | 11 |  |
| Fair value of plan assets | $ | 8 |  |  | $ | 183 |  |  | $ | — |  |  | $ | 191 |  |

[0000106040-14-000015:notes:212]
The following table presents the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 28, 2013 (in millions):

[0000106040-14-000015:notes:213]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds (1)(2) | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Fixed income: |  |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds (1)(3) | — |  |  | 101 |  |  | — |  |  | 101 |  |
| Cash and short-term investments (3) | 4 |  |  | 2 |  |  | — |  |  | 6 |  |
| Fair value of plan assets | $ | 4 |  |  | $ | 163 |  |  | $ | — |  |  | $ | 167 |  |

[0000106040-14-000015:notes:214]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-14-000015:notes:215]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-14-000015:notes:216]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-14-000015:notes:217]
Assets held in defined benefit plans in the Philippines, Taiwan and Thailand were less than $1 million and are not presented in the above table. There were no significant movements of assets between any level categories in 2014, 2013 or 2012.

[0000106040-14-000015:notes:218]
Fair Value Valuation Techniques

[0000106040-14-000015:notes:219]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-14-000015:notes:220]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-14-000015:notes:221]
Cash includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-14-000015:notes:222]
Cash Flows

[0000106040-14-000015:notes:223]
Contributions

[0000106040-14-000015:notes:224]
The Company’s expected employer contributions for 2015 are $14 million for its Japanese defined benefit pension plans.

[0000106040-14-000015:notes:225]
Estimated Future Benefits Payments

[0000106040-14-000015:notes:226]
Annual benefit payments from the Japanese defined benefit pension plans are estimated to range from $7 million to $11 million annually over the next five years.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-14-000015:notes:227]
Note 18. Quarterly Results of Operations (unaudited)

[0000106040-14-000015:notes:228]
|  | First |  | Second |  | Third |  | Fourth |
| 2014(1) |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,804 |  |  | $ | 3,972 |  |  | $ | 3,703 |  |  | $ | 3,651 |  |
| Gross profit | 1,099 |  |  | 1,156 |  |  | 1,076 |  |  | 1,029 |  |
| Operating income | 542 |  |  | 478 |  |  | 419 |  |  | 352 |  |
| Net income | 495 |  |  | 430 |  |  | 375 |  |  | 317 |  |
| Basic income per common share | $ | 2.10 |  |  | $ | 1.82 |  |  | $ | 1.60 |  |  | $ | 1.35 |  |
| Diluted income per common share | $ | 2.05 |  |  | $ | 1.77 |  |  | $ | 1.55 |  |  | $ | 1.32 |  |
| 2013(2) |  |  |  |  |  |  |  |
| Revenue, net | $ | 4,035 |  |  | $ | 3,824 |  |  | $ | 3,764 |  |  | $ | 3,728 |  |
| Gross profit | 1,193 |  |  | 1,059 |  |  | 1,061 |  |  | 1,050 |  |
| Operating income (loss) | 592 |  |  | 478 |  |  | 417 |  |  | (221 | ) |
| Net income (loss) | 519 |  |  | 335 |  |  | 391 |  |  | (265 | ) |
| Basic income (loss) per common share | $ | 2.11 |  |  | $ | 1.38 |  |  | $ | 1.64 |  |  | $ | (1.12 | ) |
| Diluted income (loss) per common share | $ | 2.06 |  |  | $ | 1.36 |  |  | $ | 1.60 |  |  | $ | (1.12 | ) |

[0000106040-14-000015:notes:229]
| (1) | Certain prior quarter amounts have been reclassified from gross profit to the employee termination, asset impairment and other charges line within operating expenses to conform to the annual presentation. The first, second, third and fourth quarters of 2014 included $11 million, $23 million, $25 million and $36 million, respectively, of employee termination, asset impairment and other charges. Each of the four quarters of 2014 included $13 million of charges related to interest on an arbitration award. The first quarter of 2014 included a $65 million gain on insurance recovery. |

[0000106040-14-000015:notes:230]
| (2) | The fourth quarter of 2013 included a $681 million charge related to an arbitration award. The first, second, third and fourth quarters of 2013 included $26 million, $41 million, $63 million and $8 million, respectively, of employee termination, asset impairment and other charges. The second quarter of 2013 included an $88 million charge related to California Proposition 39 to reduce the Company’s previously recognized California deferred tax assets as of December 28, 2012. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000106040-14-000015:notes:231]
The following table summarizes the Company’s operations by geographic area for the three years ended June 27, 2014 (in millions):

[0000106040-14-000015:notes:232]
|  | 2014 |  | 2013 |  | 2012 |
| Net revenue(1): |  |  |  |  |  |
| United States | $ | 3,013 |  |  | $ | 3,403 |  |  | $ | 2,366 |  |
| China | 3,499 |  |  | 4,145 |  |  | 2,826 |  |
| Asia | 4,756 |  |  | 4,129 |  |  | 4,393 |  |
| Europe, Middle East and Africa | 3,117 |  |  | 3,056 |  |  | 2,325 |  |
| Other | 745 |  |  | 618 |  |  | 568 |  |
| Total | $ | 15,130 |  |  | $ | 15,351 |  |  | $ | 12,478 |  |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,415 |  |  | $ | 1,517 |  |  | $ | 1,687 |  |
| China | 279 |  |  | 348 |  |  | 428 |  |
| Asia | 4,002 |  |  | 4,434 |  |  | 4,915 |  |
| Europe, Middle East and Africa | 83 |  |  | 139 |  |  | 35 |  |
| Total | $ | 6,779 |  |  | $ | 6,438 |  |  | $ | 7,065 |  |

[0000106040-14-000015:notes:233]
| (1) | Net revenue is attributed to geographic regions based on the ship to location of the customer. |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0000106040-14-000015:notes:234]
The following table summarizes information about options outstanding and exercisable under the Stock Plans as of June 27, 2014 (in millions, except exercise price):

[0000106040-14-000015:notes:235]
|  | Options Outstanding |  | Options Exercisable |
| Range ofExercise Prices | Numberof Shares |  | Weighted AverageRemainingContractual Life(in years) |  | Weighted AverageExercise Price |  | Numberof Shares |  | Weighted AverageExercise Price |
| $3.08 – $23.78 | 2.5 |  |  | 4.7 |  | $ | 13.41 |  |  | 1.6 |  |  | $ | 13.79 |  |
| $25.79 – $29.60 | 2.3 |  |  | 3.5 |  | 28.03 |  |  | 1.5 |  |  | 27.63 |  |
| $30.06 – $41.75 | 1.3 |  |  | 3.2 |  | 35.82 |  |  | 0.9 |  |  | 34.54 |  |
| $43.11 – $43.11 | 2.1 |  |  | 5.2 |  | 43.11 |  |  | 0.6 |  |  | 43.11 |  |
| $48.01 – $91.64 | 1.8 |  |  | 6.1 |  | 67.31 |  |  | 0.1 |  |  | 67.50 |  |
| $91.88 – $388.77 | 0.1 |  |  | 3.6 |  | 156.90 |  |  | 0.1 |  |  | 156.93 |  |
|  | 10.1 |  |  | 4.6 |  | $ | 37.03 |  |  | 4.8 |  |  | $ | 30.03 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-14-000015:notes:236]
The following table summarizes stock option activity under the Stock Plans over the last three fiscal years (in millions, except per share amounts and remaining contractual lives):

[0000106040-14-000015:notes:237]
|  | Numberof Shares |  | Weighted AverageExercise PricePer Share |  | Weighted AverageRemainingContractual Life(in years) |  | AggregateIntrinsicValue |
| Options outstanding at July 1, 2011 | 10.2 |  |  | $ | 22.49 |  |  |  |  |  |
| Granted | 3.7 |  |  | 31.78 |  |  |  |  |  |
| Assumed | 4.2 |  |  | 8.47 |  |  |  |  |  |
| Exercised | (2.1 | ) |  | 15.14 |  |  |  |  |  |
| Forfeited or expired | (0.2 | ) |  | 28.76 |  |  |  |  |  |
| Options outstanding at June 29, 2012 | 15.8 |  |  | $ | 21.89 |  |  |  |  |  |
| Granted | 3.4 |  |  | 43.51 |  |  |  |  |  |
| Exercised | (6.8 | ) |  | 18.53 |  |  |  |  |  |
| Forfeited or expired | (0.5 | ) |  | 32.72 |  |  |  |  |  |
| Options outstanding at June 28, 2013 | 11.9 |  |  | $ | 29.47 |  |  |  |  |  |
| Granted | 1.6 |  |  | 68.96 |  |  |  |  |  |
| Assumed | 1.7 |  |  | 38.18 |  |  |  |  |  |
| Exercised | (4.5 | ) |  | 25.22 |  |  |  |  |  |
| Forfeited or expired | (0.6 | ) |  | 67.23 |  |  |  |  |  |
| Options outstanding at June 27, 2014 | 10.1 |  |  | $ | 37.03 |  |  | 4.6 |  | $ | 572 |  |
| Exercisable at June 27, 2014 | 4.8 |  |  | $ | 30.03 |  |  | 3.2 |  | $ | 310 |  |
| Vested and expected to vest after June 27, 2014 | 9.9 |  |  | $ | 36.82 |  |  | 4.5 |  | $ | 565 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-14-000015:notes:238]
The following table summarizes RSU activity (in millions, except weighted average grant date fair value):

[0000106040-14-000015:notes:239]
|  | Numberof Shares |  | Weighted AverageGrant DateFair Value |
| RSUs outstanding at July 1, 2011 | 3.1 |  |  | $ | 28.85 |  |
| Granted | 1.6 |  |  | 32.87 |  |
| Assumed | 0.4 |  |  | 38.98 |  |
| Vested | (1.3 | ) |  | 24.58 |  |
| Forfeited or expired | (0.1 | ) |  | 32.01 |  |
| RSUs outstanding at June 29, 2012 | 3.7 |  |  | $ | 33.19 |  |
| Granted | 1.7 |  |  | 43.14 |  |
| Vested | (1.4 | ) |  | 37.89 |  |
| Forfeited or expired | (0.4 | ) |  | 35.46 |  |
| RSUs outstanding at June 28, 2013 | 3.6 |  |  | $ | 35.82 |  |
| Granted | 1.4 |  |  | 69.08 |  |
| Assumed | 0.2 |  |  | 62.73 |  |
| Vested | (1.3 | ) |  | 33.61 |  |
| Forfeited or expired | (0.2 | ) |  | 47.62 |  |
| RSUs outstanding at June 27, 2014 | 3.7 |  |  | $ | 49.77 |  |
| Expected to vest after June 27, 2014 | 3.5 |  |  | $ | 49.48 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000106040-14-000015:notes:240]
WESTERN DIGITAL CORPORATION

[0000106040-14-000015:notes:241]
SCHEDULE II — CONSOLIDATED VALUATION AND QUALIFYING ACCOUNTS

[0000106040-14-000015:notes:242]
Three years ended June 27, 2014

[0000106040-14-000015:notes:243]
(in millions)

[0000106040-14-000015:notes:244]
|  | Allowance forDoubtfulAccounts |
| Balance at July 1, 2011 | $ | 5 |  |
| Other | 3 |  |
| Additions charges to operations | 1 |  |
| Balance at June 29, 2012 | $ | 9 |  |
| Additions charged to operations | 8 |  |
| Deductions | (10 | ) |
| Recovery | 2 |  |
| Balance at June 28, 2013 | $ | 9 |  |
| Additions charged to operations | 3 |  |
| Deductions | (1 | ) |
| Balance at June 27, 2014 | $ | 11 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-14-000015:notes:245]
Note 8. Shareholders’ Equity

[0000106040-14-000015:notes:246]
Stock Incentive Plans

[0000106040-14-000015:notes:247]
In addition to awards assumed in connection with acquisitions, the Company maintains two stock-based incentive plans (collectively, including the assumed awards, referred to as the “Stock Plans”): the amended and restated 2004 Performance Incentive Plan and the Employee Stock Option Plan. No new awards may be granted under the Employee Stock Option Plan. As of June 27, 2014, options to purchase 77,033 shares of the Company’s common stock remained outstanding and exercisable under the Employee Stock Option Plan. Other than for such options, no restricted stock or other awards were outstanding under the Employee Stock Option Plan as of June 27, 2014. Options granted under the Employee Stock Option Plan expire ten years from the date of grant.

[0000106040-14-000015:notes:248]
The types of awards that may be granted under the 2004 Performance Incentive Plan include stock options, SARs, RSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2004 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2004 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2004 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2004 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards or the exercise of employee stock options and ESPP.

[0000106040-14-000015:notes:249]
As of June 27, 2014, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2004 Performance Incentive Plan was 48.8 million shares. Any shares subject to awards under the Employee Stock Option Plan that are canceled, forfeited or otherwise terminate without having vested or been exercised, as applicable, will become available for other award grants under the 2004 Performance Incentive Plan. Shares issued in respect of stock options and SARs granted under the 2004 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas shares issued in respect of any other type of award granted through November 7, 2012 under the plan count against the plan’s share limit as 1.35 shares for every one share actually issued in connection with such award. Shares issued in respect of awards granted on or after November 8, 2012 count against the plan’s share limit as 1.72 shares for every one share actually issued in connection with such award. The 2004 Performance Incentive Plan was extended in 2013 and will terminate on August 6, 2022 unless terminated earlier by the Company’s Board of Directors.

[0000106040-14-000015:notes:250]
Employee Stock Purchase Plan

[0000106040-14-000015:notes:251]
The Company maintains an ESPP. Under the ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock on either the first day of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-14-000015:notes:252]
Stock-based Compensation Expense

[0000106040-14-000015:notes:253]
The Company recognized in expense $85 million, $88 million and $57 million for stock-based compensation related to the vesting of options issued by the Company under the Stock Plans and the ESPP in 2014, 2013 and 2012, respectively. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $22 million, $25 million and $12 million in 2014, 2013 and 2012, respectively. As of June 27, 2014, total compensation cost related to unvested stock options granted under the Stock Plans and ESPP rights issued to employees but not yet recognized was $128 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.2 years.

[0000106040-14-000015:notes:254]
For purposes of this footnote, references to RSUs include performance stock unit awards (“PSUs”). The effect of the PSU activity was immaterial to the consolidated financial statements in 2014, 2013 and 2012. The Company granted approximately 1.4 million RSUs during 2014, which are generally payable in an equal number of shares of the Company’s common stock at the time of vesting of the units. The aggregate market value of the shares underlying the RSUs granted in 2014 was $95 million at the date of grant. The compensation expense for granted and assumed RSUs is being recognized as expense over the corresponding vesting or measurement periods of the awards. For purposes of recognizing awards granted, the Company has assumed a weighted average forfeiture rate of 3.3% based on a historical analysis indicating forfeitures for these types of awards. The Company recognized in expense $71 million, $52 million and $35 million related to RSUs granted under the Stock Plans that vested during 2014, 2013 and 2012, respectively. The tax benefit realized as a result of the aforementioned expense was $18 million, $14 million and $10 million in 2014, 2013 and 2012, respectively. As of June 27, 2014, the aggregate unamortized fair value of all unvested RSUs granted under the Stock Plans was $91 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.4 years. In 2013, stock-based compensation expense included $5 million of accelerated expense associated with the employee termination benefits as discussed in Note 17.

[0000106040-14-000015:notes:255]
The Company recognized in expense $36 million and $46 million related to adjustments to market value as well as the vesting of SARs in 2014 and 2013, respectively, and a benefit of $7 million related to SARs in 2012. The tax benefit realized as a result of the aforementioned SARs expense was $7 million and $4 million in 2014 and 2013, respectively. There was no tax effect in 2012. The SARs will be settled in cash upon exercise. As a result, the Company had a total liability of $61 million related to SARs included in accrued liabilities as of June 27, 2014 in the consolidated balance sheet. As of June 27, 2014, total compensation cost related to unvested SARs issued to employees but not yet recognized was $1 million and will be recognized on a straight-line basis over a weighted average service period of approximately 0.5 years.

[0000106040-14-000015:notes:256]
Stock Option Activity

[0000106040-14-000015:notes:257]
If an option has an exercise price that is less than the quoted price of the Company’s common stock at the particular time, the aggregate intrinsic value of that option at that time is calculated based on the difference between the exercise price of the underlying options and the quoted price of the Company’s common stock at that time. As of June 27, 2014, the Company had options outstanding to purchase an aggregate of 10.0 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $572 million at that date. During 2014, 2013 and 2012, the aggregate intrinsic value of options exercised under the Stock Plans was $247 million, $211 million and $53 million, respectively, determined as of the date of exercise.

[0000106040-14-000015:notes:258]
RSU Activity

[0000106040-14-000015:notes:259]
The fair value of each RSU is the market price of the Company’s stock on the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of the vesting of the units. The aggregate value of RSUs that became fully-vested during 2014, 2013 and 2012 was $89 million, $71 million and $41 million, respectively, determined as of the vest date. The grant-date fair value of the shares underlying the RSU awards at the date of grant or assumption was $95 million, $74 million and $71 million in 2014, 2013 and 2012, respectively. These amounts are being recognized to expense over the corresponding vesting periods. For purposes of valuing these awards, the Company has assumed a forfeiture rate of 3.3%, 2.0% and 2.4% during 2014, 2013 and 2012, respectively, based on a historical analysis indicating forfeitures for these types of awards.

[0000106040-14-000015:notes:260]
SARs Activity

[0000106040-14-000015:notes:261]
The share-based compensation liability for SARs is recognized for the portion of fair value for which service has been rendered at the reporting date. The share-based liability is remeasured at each reporting date, using a binomial option-pricing model, through the requisite service period. As of June 27, 2014, 0.7 million SARs were outstanding with a weighted average exercise price of $7.96. There were no SARs granted and all other SARs activity was immaterial to the consolidated financial statements for the year ended June 27, 2014.

[0000106040-14-000015:notes:262]
Fair Value Disclosure — Binomial Model

[0000106040-14-000015:notes:263]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of highly subjective assumptions. The Company uses historical data to estimate exercise, employee termination, and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. The fair value of stock options granted during the three years ended June 27, 2014 was estimated using the following weighted average assumptions:

[0000106040-14-000015:notes:264]
|  | 2014 |  | 2013 |  | 2012 |
| Suboptimal exercise factor | 2.07 |  | 1.90 |  | 1.81 |
| Range of risk-free interest rates | 0.10% to 2.44% |  | 0.14% to 1.96% |  | 0.12% to 1.61% |
| Range of expected stock price volatility | 0.27 to 0.50 |  | 0.36 to 0.53 |  | 0.41 to 0.55 |
| Weighted average expected volatility | 0.43 |  | 0.49 |  | 0.49 |
| Post-vesting termination rate | 3.10% |  | 2.16% |  | 2.61% |
| Dividend yield | 1.58% |  | 2.53% |  | — |
| Fair value | $24.14 |  | $15.75 |  | $12.91 |

[0000106040-14-000015:notes:265]
The weighted average expected term of the Company’s stock options granted during 2014, 2013 and 2012 was 5.0 years, 4.0 years and 4.9 years, respectively.

[0000106040-14-000015:notes:266]
Fair Value Disclosure — Black-Scholes-Merton Model

[0000106040-14-000015:notes:267]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are granted on either June 1st or December 1st of each year.

[0000106040-14-000015:notes:268]
The fair values of all ESPP purchase rights granted on or prior to June 27, 2014 have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-14-000015:notes:269]
|  | ESPP |
|  | 2014 |  | 2013 |  | 2012 |
| Option life (in years) | 1.24 |  | 1.24 |  | 1.24 |
| Risk-free interest rate | 0.26% |  | 0.23% |  | 0.22% |
| Stock price volatility | 0.31 |  | 0.42 |  | 0.46 |
| Dividend yield | 1.64% |  | 1.61% |  | — |
| Fair value | $14.62 |  | $10.36 |  | $7.29 |

[0000106040-14-000015:notes:270]
Stock Repurchase Program

[0000106040-14-000015:notes:271]
Since May 18, 2012, the Company's Board of Directors has authorized $3.0 billion for the repurchase of its common stock until September 13, 2017. The Company repurchased 10.3 million shares for a total cost of $816 million during 2014. The remaining amount available to be purchased under the Company’s stock repurchase program as of June 27, 2014 was $1.2 billion. The Company may continue to repurchase its stock as it deems appropriate and market conditions allow. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows and borrowings under the Credit Agreement.

[0000106040-14-000015:notes:272]
Stock Reserved for Issuance

[0000106040-14-000015:notes:273]
The following table summarizes all shares of common stock reserved for issuance at June 27, 2014 (in millions):

[0000106040-14-000015:notes:274]
|  | Numberof Shares |
| Maximum shares issuable in connection with: |  |
| Outstanding awards and shares available for award grants | 23.6 |  |
| ESPP | 5.9 |  |
| Total | 29.5 |  |

[0000106040-14-000015:notes:275]
Dividends to Shareholders

[0000106040-14-000015:notes:276]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In 2014, the Company declared aggregate cash dividends of $1.25 per share of the Company’s common stock, totaling $295 million, of which $201 million was paid during 2014. On August 5, 2014, the Company declared a cash dividend of $0.40 per share of its common stock to shareholders of record as of October 3, 2014, which will be paid on October 15, 2014. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-14-000015:notes:277]
Note 2. Supplemental Financial Statement Data

[0000106040-14-000015:notes:278]
|  | June 27, 2014 |  | June 28, 2013 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 168 |  |  | $ | 167 |  |
| Work-in-process | 493 |  |  | 575 |  |
| Finished goods | 565 |  |  | 446 |  |
| Total inventories | $ | 1,226 |  |  | $ | 1,188 |  |
| Property, plant and equipment: |  |  |  |
| Land and buildings | $ | 1,364 |  |  | $ | 1,231 |  |
| Machinery and equipment | 6,109 |  |  | 5,738 |  |
| Furniture and fixtures | 54 |  |  | 39 |  |
| Leasehold improvements | 254 |  |  | 233 |  |
| Construction-in-process | 342 |  |  | 375 |  |
| Total property, plant and equipment | 8,123 |  |  | 7,616 |  |
| Accumulated depreciation | (4,830 | ) |  | (3,916 | ) |
| Property, plant and equipment, net | $ | 3,293 |  |  | $ | 3,700 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000106040-14-000015:notes:279]
Note 16. Thailand Flooding

[0000106040-14-000015:notes:280]
In October 2011, severe flooding in Thailand inundated all of the Company’s Thailand manufacturing facilities and submerged certain equipment located there. These facilities included the Company’s magnetic head slider fabrication facilities, as well as its hard drive, head gimbal assembly and head stack assembly facilities. As a result, the Company recorded $235 million of flood-related charges in fiscal 2012, offset by $21 million of insurance recoveries and other cost reimbursements. These charges are separately stated as a line item, “Charges related to flooding, net,” within operating expenses on the consolidated statements of income.

[0000106040-14-000015:notes:281]
The Company maintains insurance coverage that provides property and business interruption coverage in the event of losses arising from flooding. The Company has submitted claims to its insurers and is awaiting a determination of how much of its total losses will be covered by insurance.


## wdc:BusinessSegmentGeographicInformationAndMajorCustomersTextBlock

[0000106040-14-000015:notes:282]
Note 6. Business Segment, Geographic Information and Major Customers

[0000106040-14-000015:notes:283]
Segment Information

[0000106040-14-000015:notes:284]
The Company operates in one reportable operating segment, the hard drive business.

[0000106040-14-000015:notes:285]
Geographic Information

[0000106040-14-000015:notes:286]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines, Singapore, and Thailand as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following table summarizes the Company’s operations by geographic area for the three years ended June 27, 2014 (in millions):

[0000106040-14-000015:notes:287]
Major Customers

[0000106040-14-000015:notes:288]
For 2014 and 2012, sales to Hewlett Packard Company accounted for 11% of the Company’s net revenue. For 2013, no single customer accounted for 10%, or more, of the Company’s net revenue. For 2014, 2013, and 2012, sales to the Company’s top ten customers accounted for 44%, 44% and 50% of the Company’s net revenue, respectively.


## wdc:DefinedContributionPlanDisclosureTextBlock

[0000106040-14-000015:notes:289]
Note 7. Western Digital Corporation 401(k) Plan

[0000106040-14-000015:notes:290]
The Company has adopted the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. The Company makes a basic matching contribution on behalf of each participating eligible employee equal to fifty percent (50%) of the eligible participant’s pre-tax contributions for the contribution cycle not to exceed 5% of the eligible participant’s compensation; provided, however, that each eligible participant shall receive a minimum annual basic matching contribution equal to fifty percent (50%) of the first $4,000 of pre-tax contributions for any calendar year. The Plan was amended effective January 1, 2013, to provide for a year-end true-up matching contribution such that participants who save at least 5% of their eligible compensation for the year receive a minimum annual matching contribution equal to 2.5% of eligible compensation (up to Internal Revenue Service (“IRS”) limitations). Company contributions vest over a 5-year period of employment. For 2014, 2013, and 2012, the Company made Plan contributions of $21 million, $19 million and $12 million, respectively.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-14-000015:notes:291]
Note 17. Employee Termination, Asset Impairment and Other Charges

[0000106040-14-000015:notes:292]
The Company periodically incurs charges to realign its operations with anticipated market demand. The following table summarizes the Company's employee termination, asset impairment and other charges over the last three fiscal years (in millions):

[0000106040-14-000015:notes:293]
|  | EmployeeTerminationBenefits |  | Impairmentof Assets |  | Contract Termination and Other Charges |  | Total |
| Accrual at July 1, 2011 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charges | 8 |  |  | 56 |  |  | 16 |  |  | 80 |  |
| Cash payments | (8 | ) |  | — |  |  | — |  |  | (8 | ) |
| Non-cash charges | — |  |  | (56 | ) |  | — |  |  | (56 | ) |
| Accrual at June 29, 2012 | $ | — |  |  | $ | — |  |  | $ | 16 |  |  | $ | 16 |  |
| Charges | 109 |  |  | 14 |  |  | 15 |  |  | 138 |  |
| Cash payments | (66 | ) |  | — |  |  | (17 | ) |  | (83 | ) |
| Non-cash charges | (6 | ) |  | (14 | ) |  | (5 | ) |  | (25 | ) |
| Accrual at June 28, 2013 | $ | 37 |  |  | $ | — |  |  | $ | 9 |  |  | $ | 46 |  |
| Charges | 27 |  |  | 62 |  |  | 6 |  |  | 95 |  |
| Cash payments | (64 | ) |  | — |  |  | (15 | ) |  | (79 | ) |
| Non-cash charges | — |  |  | (62 | ) |  | — |  |  | (62 | ) |
| Accrual at June 27, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000106040-14-000015:notes:294]
As of June 27, 2014, the Company did not have any material liabilities outstanding for its employee termination, asset impairment and other charges.
