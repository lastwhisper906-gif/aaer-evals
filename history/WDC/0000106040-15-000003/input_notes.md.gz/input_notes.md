# WDC notes — 0000106040-15-000003


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-15-000003:notes:1]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments as of January 2, 2015 (in millions):

[0000106040-15-000003:notes:2]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 159 |  |  | $ | — |  |  | $ | 159 |  |
| U.S. Government agency securities | 126 |  |  | — |  |  | 126 |  |
| Commercial paper | 154 |  |  | — |  |  | 154 |  |
| Certificates of deposit | 26 |  |  | — |  |  | 26 |  |
| Total | $ | 465 |  |  | $ | — |  |  | $ | 465 |  |
| Short-term investments |  |  |  |  | $ | 241 |  |
| Included in other non-current assets |  |  |  |  | 224 |  |
| Total |  |  |  |  | $ | 465 |  |

[0000106040-15-000003:notes:3]
[same as prior period, unchanged from 0001445305-14-004772:notes:3]

[0000106040-15-000003:notes:4]
[same as prior period, unchanged from 0001445305-14-004772:notes:4]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-15-000003:notes:5]
[same as prior period, unchanged from 0001445305-14-004772:notes:5]

[0000106040-15-000003:notes:6]
The condensed consolidated financial statements include the results of operations of acquired companies commencing after their respective acquisition dates. Disclosed below are those acquisitions which have a significant impact to these condensed consolidated financial statements.

[0000106040-15-000003:notes:7]
[same as prior period, unchanged from 0001445305-14-004772:notes:6]

[0000106040-15-000003:notes:8]
On October 17, 2013, the Company acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. As a result of the acquisition, Virident has been fully integrated into the Company's HGST subsidiary and became a wholly-owned indirect subsidiary of the Company. The acquisition furthered HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures.

[0000106040-15-000003:notes:9]
The values assigned to the acquired assets and liabilities were finalized during the three months ended June 27, 2014, and the final purchase price allocation for Virident was as follows (in millions):

[0000106040-15-000003:notes:10]
[same as prior period, unchanged from 0001445305-14-004772:notes:10]

[0000106040-15-000003:notes:11]
[same as prior period, unchanged from 0001445305-14-004772:notes:12]

[0000106040-15-000003:notes:12]
On September 12, 2013, the Company completed its acquisition of sTec, a provider of enterprise solid-state drives. As a result of the acquisition, sTec has been fully integrated into the Company's HGST subsidiary and became a wholly-owned indirect subsidiary of the Company. The acquisition augmented HGST's existing solid-state storage capabilities.

[0000106040-15-000003:notes:13]
The values assigned to the acquired assets and liabilities were finalized during the three months ended October 3, 2014, and the final purchase price allocation for sTec was as follows (in millions):

[0000106040-15-000003:notes:14]
[same as prior period, unchanged from 0001445305-14-004772:notes:16]


## us-gaap:DebtDisclosureTextBlock

[0000106040-15-000003:notes:15]
4. Debt

[0000106040-15-000003:notes:16]
On January 9, 2014, Western Digital Ireland, Ltd. (“WDI”) used existing cash to repay the outstanding term loan balance of $1.8 billion under its previous credit agreement, dated March 8, 2012, and the Company, Western Digital Technologies, Inc. (“WDT”) and WDI entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"). The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT and WDI (the “Borrowers”). The revolving credit facility includes a $100 million sublimit for letters of credit and a $50 million sublimit for swing line loans. Subject to certain conditions, a Borrower may elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. The loans under the Credit Agreement have a five-year term. The obligations of the Borrowers under the Credit Agreement are guaranteed by the Company and its material domestic subsidiaries, and the obligations of WDI under the Credit Agreement are also guaranteed by WDT.

[0000106040-15-000003:notes:17]
As of January 2, 2015, no amounts were outstanding under the revolving credit facility and the term loan facility had an outstanding balance of $2.4 billion and a variable interest rate of 1.66%. The Company is required to make quarterly principal payments on the term loan facility totaling $63 million for the remainder of fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-15-000003:notes:18]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of January 2, 2015, the Company was in compliance with all covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-15-000003:notes:19]
[same as prior period, unchanged from 0001445305-14-004772:notes:24]

[0000106040-15-000003:notes:20]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for trading purposes. As of January 2, 2015, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-15-000003:notes:21]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and six months ended January 2, 2015 and December 27, 2013.

[0000106040-15-000003:notes:22]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of operating expenses. All fair value hedges were determined to be effective as of January 2, 2015 and June 27, 2014. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and six months ended January 2, 2015 and December 27, 2013.

[0000106040-15-000003:notes:23]
As of January 2, 2015, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $39 million. In addition, as of January 2, 2015, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $1.0 billion and $2.0 billion, and closed $1.1 billion and $2.1 billion, in foreign exchange contracts in the three and six months ended January 2, 2015, respectively. In addition, the Company opened $1.7 billion and $2.7 billion and closed $1.3 billion and $2.7 billion, in foreign exchange contracts in the three and six months ended December 27, 2013, respectively. The fair value and balance sheet location of the Company's foreign exchange contracts as of January 2, 2015 and June 27, 2014 were as follows (in millions):

[0000106040-15-000003:notes:24]
|  | Asset Derivatives | Liability Derivatives |
|  | January 2, 2015 | June 27, 2014 | January 2, 2015 | June 27, 2014 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | — |  | Other current assets | $ | 7 |  | Accrued expenses | $ | 45 |  | Accrued expenses | $ | 2 |  |

[0000106040-15-000003:notes:25]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of January 2, 2015 (in millions):

[0000106040-15-000003:notes:26]
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 1 |  |  | $ | (1 | ) |  | $ | — |  |
| Financial liabilities | (46 | ) |  | 1 |  |  | (45 | ) |
| Total derivative instruments | $ | (45 | ) |  | $ | — |  |  | $ | (45 | ) |

[0000106040-15-000003:notes:27]
[same as prior period, unchanged from 0001445305-14-004772:notes:32]

[0000106040-15-000003:notes:28]
[same as prior period, unchanged from 0001445305-14-004772:notes:33]

[0000106040-15-000003:notes:29]
[same as prior period, unchanged from 0001445305-14-004772:notes:34]

[0000106040-15-000003:notes:30]
|  | Amount of Loss Recognized inAccumulated OCI on Derivatives | Location of(Gain) LossReclassifiedfromAccumulatedOCI intoIncome | Amount of (Gain) Loss ReclassifiedFrom Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | ThreeMonthsEnded |  | Six Months Ended |  | ThreeMonthsEnded |  | Six Months Ended | ThreeMonthsEnded |  | Six Months Ended |  | ThreeMonthsEnded |  | Six Months Ended |
| January 2, 2015 |  | December 27, 2013 | January 2, 2015 |  | December 27, 2013 |
| Foreign exchange contracts | $ | (35 | ) |  | $ | (57 | ) |  | $ | — |  |  | $ | (11 | ) | Cost of revenue | $ | (17 | ) |  | $ | (13 | ) |  | $ | 30 |  |  | $ | 3 |  |

[0000106040-15-000003:notes:31]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three and six months ended January 2, 2015 and December 27, 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000106040-15-000003:notes:32]
[same as prior period, unchanged from 0001445305-14-004772:notes:37]

[0000106040-15-000003:notes:33]
Stock-Based Compensation Expense

[0000106040-15-000003:notes:34]
During the three and six months ended January 2, 2015, the Company recognized in expense $18 million and $37 million, respectively, for stock-based compensation related to the vesting of options issued under the Company’s stock plans and the ESPP, as compared to $24 million and $45 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $7 million and $12 million in the three and six months ended January 2, 2015, respectively, as compared to $6 million and $11 million in the three and six months ended December 27, 2013, respectively. As of January 2, 2015, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $129 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.2 years.

[0000106040-15-000003:notes:35]
During the three and six months ended January 2, 2015, the Company recognized in expense $23 million and $43 million, respectively, for stock-based compensation related to the vesting of awards of RSUs issued under the Company's stock plans, as compared to $18 million and $39 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $6 million and $11 million in the three and six months ended January 2, 2015, respectively, as compared to $5 million and $9 million in the three and six months ended December 27, 2013, respectively. As of January 2, 2015, the aggregate unamortized fair value of all unvested RSUs was $157 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.7 years. RSUs include performance stock unit awards (“PSUs”). The effect of PSUs was immaterial to the condensed consolidated financial statements in the three and six months ended January 2, 2015 and December 27, 2013.

[0000106040-15-000003:notes:36]
During the three and six months ended January 2, 2015, the Company recognized in expense $8 million and $12 million, respectively, related to adjustments to market value as well as the vesting of stock appreciation rights (“SARs”), as compared to $20 million and $24 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned SARs expense was $2 million and $3 million in the three and six months ended January 2, 2015, respectively, as compared to $4 million and $5 million in the three and six months ended December 27, 2013, respectively. The SARs will be settled in cash upon exercise. As a result, the Company had a total liability of $63 million related to SARs included in accrued expenses in the condensed consolidated balance sheet as of January 2, 2015. As of January 2, 2015, total compensation cost related to unvested SARs issued to employees but not yet recognized was not material to the Company's consolidated statement of income.

[0000106040-15-000003:notes:37]
[same as prior period, unchanged from 0001445305-14-004772:notes:42]

[0000106040-15-000003:notes:38]
[same as prior period, unchanged from 0001445305-14-004772:notes:43]

[0000106040-15-000003:notes:39]
|  | NumberofShares |  | WeightedAverageExercisePricePerShare |  | WeightedAverageRemainingContractualLife(in years) |  | AggregateIntrinsicValue |
| Options outstanding at June 27, 2014 | 10.1 |  |  | $ | 37.03 |  |  |  |  |  |
| Granted | 1.2 |  |  | 100.06 |  |  |  |  |  |
| Exercised | (1.3 | ) |  | 31.04 |  |  |  |  |  |
| Options outstanding at October 3, 2014 | 10.0 |  |  | 45.16 |  |  |  |  |  |
| Exercised | (1.1 | ) |  | 32.14 |  |  |  |  |  |
| Canceled or expired | (0.1 | ) |  | 32.53 |  |  |  |  |  |
| Options outstanding at January 2, 2015 | 8.8 |  |  | $ | 47.01 |  |  | 4.4 |  | $ | 564 |  |
| Exercisable at January 2, 2015 | 4.0 |  |  | $ | 32.98 |  |  | 3.1 |  | $ | 314 |  |
| Vested and expected to vest after January 2, 2015 | 8.6 |  |  | $ | 46.41 |  |  | 4.4 |  | $ | 558 |  |

[0000106040-15-000003:notes:40]
If an option has an exercise price that is less than the quoted price of the Company’s common stock at the particular time, the aggregate intrinsic value of that option at that time is calculated based on the difference between the exercise price of the underlying options and the quoted price of the Company’s common stock at that time. As of January 2, 2015, the Company had options outstanding to purchase an aggregate of 8.8 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $564 million at that date. During the three and six months ended January 2, 2015, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $76 million and $163 million, respectively, determined as of the date of exercise, as compared to $80 million and $107 million in the respective prior-year periods.

[0000106040-15-000003:notes:41]
[same as prior period, unchanged from 0001445305-14-004772:notes:46]

[0000106040-15-000003:notes:42]
[same as prior period, unchanged from 0001445305-14-004772:notes:47]

[0000106040-15-000003:notes:43]
|  | Numberof Shares |  | Weighted AverageGrant-DateFair Value |
| RSUs outstanding at June 27, 2014 | 3.7 |  |  | $ | 49.77 |  |
| Granted | 1.1 |  |  | 100.07 |  |
| Vested | (1.5 | ) |  | 40.57 |  |
| RSUs outstanding at October 3, 2014 | 3.3 |  |  | 70.88 |  |
| Granted* | — |  |  | 101.27 |  |
| Vested | (0.1 | ) |  | 48.25 |  |
| RSUs outstanding at January 2, 2015 | 3.2 |  |  | 72.15 |  |
| Expected to vest after January 2, 2015 | 3.0 |  |  | $ | 71.69 |  |

[0000106040-15-000003:notes:44]
| * | Shares granted were immaterial for rounding purposes. |

[0000106040-15-000003:notes:45]
The fair value of each RSU is the market price of the Company’s stock at the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of vesting of the units. The grant-date fair value of the shares underlying the RSU awards at the date of grant was $3 million and $116 million in the three and six months ended January 2, 2015, respectively. These amounts are being recognized to expense over the corresponding vesting periods. The Company has assumed a forfeiture rate of 4.3% and 4.4% for the three and six months ended January 2, 2015, respectively, based on a historical analysis indicating forfeitures for these types of awards.

[0000106040-15-000003:notes:46]
[same as prior period, unchanged from 0001445305-14-004772:notes:50]

[0000106040-15-000003:notes:47]
The share-based compensation liability for SARs is recognized for the portion of fair value for which service has been rendered at the reporting date. The share-based liability is remeasured at each reporting date, using a binomial option-pricing model, through the requisite service period. As of January 2, 2015, 0.6 million SARs were outstanding with a weighted average exercise price of $8.11. There were no SARs granted and all other SARs activity was immaterial to the condensed consolidated financial statements for the three and six months ended January 2, 2015.

[0000106040-15-000003:notes:48]
[same as prior period, unchanged from 0001445305-14-004772:notes:52]

[0000106040-15-000003:notes:49]
[same as prior period, unchanged from 0001445305-14-004772:notes:53]

[0000106040-15-000003:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Suboptimal exercise factor | 2.59 |  | 2.20 |  | 2.51 |  | 2.06 |
| Range of risk-free interest rates | 0.25% to 1.92% |  | 0.12% to 2.44% |  | 0.11% to 2.16% |  | 0.10% to 2.44% |
| Range of expected stock price volatility | 0.23 to 0.46 |  | 0.29 to 0.49 |  | 0.23 to 0.47 |  | 0.29 to 0.50 |
| Weighted average expected volatility | 0.35 |  | 0.41 |  | 0.36 |  | 0.43 |
| Post-vesting termination rate | 1.69% |  | 3.18% |  | 1.25% |  | 3.09% |
| Dividend yield | 1.45% |  | 1.45% |  | 1.68% |  | 1.58% |
| Fair value | $31.96 |  | $25.29 |  | $32.29 |  | $24.03 |

[0000106040-15-000003:notes:51]
The weighted average expected term of the Company’s stock options granted during the three and six months ended January 2, 2015 was 6.0 years and 5.8 years, respectively, compared to 5.4 years and 5.0 years in the respective prior-year periods.

[0000106040-15-000003:notes:52]
[same as prior period, unchanged from 0001445305-14-004772:notes:56]

[0000106040-15-000003:notes:53]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the current ESPP are granted on either June 1 or December 1 of each year. ESPP activity was immaterial to the condensed consolidated financial statements for the three and six months ended January 2, 2015 and December 27, 2013.

[0000106040-15-000003:notes:54]
[same as prior period, unchanged from 0001445305-14-004772:notes:58]

[0000106040-15-000003:notes:55]
Since May 21, 2012, the Company's Board of Directors has authorized $3.0 billion for the repurchase of its common stock. The Company repurchased 3.2 million and 5.4 million shares for a total cost of $309 million and $532 million during the three and six months ended January 2, 2015. The remaining amount available to be purchased under the Company’s stock repurchase program as of January 2, 2015 was $622 million. On February 3, 2015, the Company's Board of Directors authorized an additional $2.0 billion for the repurchase of its common stock and approved the extension of its stock repurchase program to February 3, 2020, resulting in a cumulative authorized repurchase amount of $5.0 billion since the inception of the repurchase program. The Company may continue to repurchase its stock as it deems appropriate and market conditions allow. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows and borrowings under the Company's Credit Agreement.

[0000106040-15-000003:notes:56]
[same as prior period, unchanged from 0001445305-14-004772:notes:60]

[0000106040-15-000003:notes:57]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In the three months ended January 2, 2015, the Company declared a cash dividend of $0.40 per share of the Company’s common stock to shareholders of record as of January 2, 2015, totaling $93 million, which was paid on January 15, 2015. In addition, in the three months ended October 3, 2014, the Company declared a cash dividend of $0.40 per share of the Company’s common stock to shareholders of record as of October 3, 2014, totaling $94 million, which was paid on October 15, 2014. On February 3, 2015, the Company declared a cash dividend of $0.50 per share of the Company's common stock to shareholders of record as of April 3, 2015, which will be paid on April 16, 2015. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:EarningsPerShareTextBlock

[0000106040-15-000003:notes:58]
[same as prior period, unchanged from 0001445305-14-004772:notes:62]

[0000106040-15-000003:notes:59]
[same as prior period, unchanged from 0001445305-14-004772:notes:63]

[0000106040-15-000003:notes:60]
[same as prior period, unchanged from 0001445305-14-004772:notes:64]

[0000106040-15-000003:notes:61]
|  | Three MonthsEnded |  | Six Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Net income | $ | 438 |  |  | $ | 430 |  |  | $ | 861 |  |  | $ | 925 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 233 |  |  | 236 |  |  | 233 |  |  | 236 |  |
| Employee stock options and other | 5 |  |  | 7 |  |  | 6 |  |  | 7 |  |
| Diluted | 238 |  |  | 243 |  |  | 239 |  |  | 243 |  |
| Income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.88 |  |  | $ | 1.82 |  |  | $ | 3.70 |  |  | $ | 3.92 |  |
| Diluted | $ | 1.84 |  |  | $ | 1.77 |  |  | $ | 3.60 |  |  | $ | 3.81 |  |
| Anti-dilutive potential common shares excluded* | 1 |  |  | 2 |  |  | 2 |  |  | 1 |  |

[0000106040-15-000003:notes:62]
[same as prior period, unchanged from 0001445305-14-004772:notes:66]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-15-000003:notes:63]
[same as prior period, unchanged from 0001445305-14-004772:notes:67]

[0000106040-15-000003:notes:64]
[same as prior period, unchanged from 0001445305-14-004772:notes:68]

[0000106040-15-000003:notes:65]
[same as prior period, unchanged from 0001445305-14-004772:notes:69]

[0000106040-15-000003:notes:66]
[same as prior period, unchanged from 0001445305-14-004772:notes:70]

[0000106040-15-000003:notes:67]
[same as prior period, unchanged from 0001445305-14-004772:notes:71]

[0000106040-15-000003:notes:68]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of January 2, 2015, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-15-000003:notes:69]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,677 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,677 |  |
| U.S. Government agency securities | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Commercial paper | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Total cash equivalents | 1,677 |  |  | 35 |  |  | — |  |  | 1,712 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Commercial paper | — |  |  | 154 |  |  | — |  |  | 154 |  |
| Certificates of deposit | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Total short-term investments | — |  |  | 241 |  |  | — |  |  | 241 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 159 |  |  | — |  |  | 159 |  |
| U.S. Government agency securities | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total long-term investments | — |  |  | 224 |  |  | — |  |  | 224 |  |
| Total assets at fair value | $ | 1,677 |  |  | $ | 500 |  |  | $ | — |  |  | $ | 2,177 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 45 |  |  | $ | — |  |  | $ | 45 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 45 |  |  | $ | — |  |  | $ | 45 |  |

[0000106040-15-000003:notes:70]
[same as prior period, unchanged from 0001445305-14-004772:notes:74]

[0000106040-15-000003:notes:71]
[same as prior period, unchanged from 0001445305-14-004772:notes:75]

[0000106040-15-000003:notes:72]
[same as prior period, unchanged from 0001445305-14-004772:notes:76]

[0000106040-15-000003:notes:73]
[same as prior period, unchanged from 0001445305-14-004772:notes:77]

[0000106040-15-000003:notes:74]
[same as prior period, unchanged from 0001445305-14-004772:notes:78]

[0000106040-15-000003:notes:75]
U.S. Government Agency Securities. The Company’s U.S. Government agency securities are investments in fixed income securities sponsored by the U.S. Government and are held in custody by a third party and recorded within cash and cash equivalents, short-term investments or other non-current assets in the condensed consolidated balance sheets depending on their original maturities. U.S. Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000003:notes:76]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government, are held in custody by a third party and are recorded within other non-current assets in the condensed consolidated balance sheets. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000003:notes:77]
[same as prior period, unchanged from 0001445305-14-004772:notes:81]

[0000106040-15-000003:notes:78]
[same as prior period, unchanged from 0001445305-14-004772:notes:82]

[0000106040-15-000003:notes:79]
[same as prior period, unchanged from 0001445305-14-004772:notes:83]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-15-000003:notes:80]
[same as prior period, unchanged from 0001445305-14-004772:notes:84]

[0000106040-15-000003:notes:81]
The Company’s income tax provision for the three and six months ended January 2, 2015 was $20 million and $57 million, respectively, as compared to $37 million and $74 million in the respective prior-year periods. The Company's tax provision for both the three and six months ended January 2, 2015 reflects a tax benefit of $16 million as a result of the retroactive extension of the U.S. Federal R&D tax credit that was signed into law on December 19, 2014. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits.

[0000106040-15-000003:notes:82]
In the three months ended January 2, 2015, the Company recorded a net increase of $9 million in its liability for unrecognized tax benefits. In the six months ended January 2, 2015, the Company recorded a net increase of $16 million in its liability for unrecognized tax benefits. As of January 2, 2015, the Company's liability for unrecognized tax benefits was approximately $316 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three months and six months ended January 2, 2015.

[0000106040-15-000003:notes:83]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company's federal income tax returns for fiscal years 2006 and 2007, and the Company and the IRS reached agreement with respect to all matters except on the proposed adjustments to income before income taxes relating to intercompany payable balances. The proposed adjustments relating to intercompany payable balances for fiscal years 2006 and 2007 will be addressed in conjunction with the IRS’s examination of the Company’s fiscal years 2008 and 2009, which commenced in January 2012. In addition, in January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag, Incorporated, which was acquired by the Company on September 5, 2007.  The Company anticipates that the IRS fieldwork will be completed in the fourth quarter of fiscal year 2015.  With respect to the 2008 and 2009 audit, the Company received a notice of proposed adjustment from the IRS relating to intercompany payable balances. The proposed adjustments to income before income taxes relating to intercompany payable balances for fiscal years 2006, 2007, 2008 and 2009 total approximately $200 million. The Company disagrees with the proposed adjustments, believes that its tax position is properly supported and will vigorously contest the position taken by the IRS. The IRS examined calendar years 2010 and 2011 of HGST, which was acquired by the Company on March 8, 2012, and completed the examination with no material adjustments.

[0000106040-15-000003:notes:84]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of January 2, 2015, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000106040-15-000003:notes:85]
The fair value of the Company’s investments classified as available-for-sale securities as of June 27, 2014, by remaining contractual maturity, were as follows (in millions):

[0000106040-15-000003:notes:86]
[same as prior period, unchanged from 0001445305-14-004772:notes:90]

[0000106040-15-000003:notes:87]
The fair value of the Company’s investments classified as available-for-sale securities at January 2, 2015, by remaining contractual maturity, were as follows (in millions):

[0000106040-15-000003:notes:88]
|  | Cost Basis |  | Fair Value |
| Due in less than one year: | $ | 241 |  |  | $ | 241 |  |
| Due in one to five years: | 224 |  |  | 224 |  |
| Total | $ | 465 |  |  | $ | 465 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-15-000003:notes:89]
5. Legal Proceedings

[0000106040-15-000003:notes:90]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-15-000003:notes:91]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the HGST Closing Date. HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-15-000003:notes:92]
Intellectual Property Litigation

[0000106040-15-000003:notes:93]
On June 20, 2008, plaintiff Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and one other company alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. On October 10, 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. A trial in the matter began on July 18, 2011 and concluded on July 26, 2011 with a verdict against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. WD and HGST have filed post-trial motions challenging the verdict. On January 17, 2014, the Court denied the Company’s motion for judgment as a matter of law on invalidity. On May 20, 2014, the Court ordered supplemental briefing on post-trial motions related to infringement.  Convolve and the Company filed their supplemental briefs on May 30, 2014 and June 6, 2014, respectively.  Additional post-trial motions are pending, and the Company will evaluate its options for appeal after the Court rules on the remaining post-trial motions. The Company intends to continue to defend itself vigorously in this matter.

[0000106040-15-000003:notes:94]
On August 1, 2011, plaintiff Guzik Technical Enterprises (“Guzik”) filed a complaint in the Northern District of California against WD and various of its subsidiaries alleging infringement of U.S. Patent Nos. 6,023,145 and 6,785,085, breach of contract and misappropriation of trade secrets. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The patents asserted by Guzik allegedly relate to devices used to test hard disk drive heads and media. On November 30, 2013, WD entered into a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company recorded an accrual. Guzik is disputing the enforceability of the agreement and on December 27, 2013, WD filed a motion to enforce the agreement. The Court heard oral argument on WD’s motion on January 23, 2014.  The Court granted WD’s motion to enforce the settlement agreement on March 21, 2014.  On April 14, 2014, Guzik filed a Notice of Appeal to the Federal Circuit.  On June 17, 2014, Guzik filed its opening appellate brief.  WD filed its appellate brief on August 14, 2014. On September 11, 2014, Guzik filed its reply brief in support of its opening appellate brief. On January 7, 2015, the Federal Circuit heard oral argument on Guzik’ s appeal and on January 9, 2015, the Federal Circuit affirmed the Court’s decision granting WD’s motion to enforce the settlement agreement. WD intends to continue to defend itself vigorously in this matter.

[0000106040-15-000003:notes:95]
On March 24, 2014, plaintiff Steven F. Reiber (“Reiber”) filed a complaint in the Eastern District of California against the Company, alleging infringement of U.S. Patent Nos. 7,124,927 and 7,389,905. On September 16, 2014, Reiber filed an amended complaint in the Eastern District of California against the Company alleging infringement of three additional patents-U.S. Patent Nos. 6,935,548, 6,651,864, and 6,354,479.  Reiber alleges that WD products (including hard disk drive heads, head gimbal assemblies, head stack assemblies and SSDs) infringe these patents based on the allegation that the manufacturing of these products involves the use of certain bonding tools (e.g., wire-bonding tips, capillary tips, and flip-chip handling tools) that have electrically “dissipative” properties, and which are used when bonding components, such as leads, wires and flip chips. The complaint seeks an injunction, unspecified monetary damages, interests, fees and costs. On September 30, 2014, the Company filed a motion to dismiss Reiber’s claims for induced infringement and contributory infringement. Oral argument on the Company’s motion to dismiss occurred on January 16, 2015. The parties' initial case management conference is set for April 16, 2015. The Company intends to defend itself vigorously in this matter.

[0000106040-15-000003:notes:96]
On October 20, 2014, plaintiff SOTA Semiconductor LLC (“SOTA”) filed a complaint in the Central District of California against the Company, Marvell Semiconductor, Inc., Belkin International, Inc., Dell Inc., Hewlett-Packard Company, Hisense USA Corp., Konica Minolta Business Solutions U.S.A., Inc., Lenovo (United States) Inc., Netgear, Inc., Samsung Electronics America, Inc., and Seagate Technology LLC, alleging infringement of U.S. Patent No. 5,991,545 (“’545 patent”).  SOTA alleges that the Company’s devices that incorporate Marvell Thumb Processors, including WD’s My Cloud EX2 network attached storage devices, which include model numbers WDBVKW0080JCH, WDBVKW0060JCH, WDBVKW0040JCH and WDBVKW0000NCH, infringe the ’545 patent.  The complaint seeks unspecified monetary damages, interests, fees, costs and expenses. On December 12, 2014, the Company filed an answer and counterclaims to SOTA’s complaint. The Company intends to defend itself vigorously in this matter.

[0000106040-15-000003:notes:97]
Seagate Matter

[0000106040-15-000003:notes:98]
On October 4, 2006, plaintiff Seagate Technology LLC ("Seagate") filed an action in the District Court of Hennepin County, Minnesota, naming as defendants WD and one of its now former employees previously employed by Seagate. The complaint in the action alleged claims based on misappropriation of trade secrets and sought injunctive relief and unspecified monetary damages, interest, fees and costs. On June 19, 2007, WD’s former employee filed a demand for arbitration with the American Arbitration Association.

[0000106040-15-000003:notes:99]
On January 23, 2012, the arbitrator issued a total final award, including pre-award interest of $630.4 million. On January 23, 2012, WD filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated, and, on October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award, ordering that a rehearing be held concerning the alleged trade secret claims before a new arbitrator.

[0000106040-15-000003:notes:100]
Seagate appealed the District Court decision to the Minnesota Court of Appeals.  On July 22, 2013, the Minnesota Court of Appeals reversed the District Court’s decision and remanded for entry of an order and judgment confirming the arbitration award. On August 20, 2013, the Company filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, the Minnesota Supreme Court granted the Company’s petition. On October 8, 2014, the Minnesota Supreme Court affirmed the decision of the Minnesota Court of Appeals. Because the Minnesota Supreme Court’s decision is not subject to appeal, on October 14, 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 13, 2014.  This amount was paid during the quarter ended January 2, 2015 by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0000106040-15-000003:notes:101]
Seagate disputes the method the Company used for calculating post-award interest and contends that the Company owes Seagate approximately $28.9 million in additional interest.  The Company denies Seagate’s contention and believes it calculated interest properly in accordance with the arbitration award.  On November 12, 2014, the Company filed a motion with the District Court seeking an order declaring that WD has paid to Seagate all amounts due under the arbitration award, including all pre-award and post-award interest, and all costs and disbursements assessed by the Minnesota Court of Appeals and the Minnesota Supreme Court.  On December 23, 2014, Seagate filed a cross-motion seeking entry of judgment in the amount of $28.9 million, plus daily interest from October 15, 2014 until the date any judgment is paid. Both parties’ motions were fully briefed and, on January 9, 2015, the Court heard oral argument on both motions. The Court has not yet ruled on the matter.

[0000106040-15-000003:notes:102]
Other Matters

[0000106040-15-000003:notes:103]
On December 22, 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several levy collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary ("WD Germany") before to the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany from January 2008 through December 2010.  The CAB, which was required to issue a settlement proposal within one year of the initiation of the action, failed to do so and requested the parties consent to continue the deadline.  WD Germany declined to provide consent and, on February 1, 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives (collectively, "Covered Products") sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. On May 22, 2014, oral argument on the pleadings occurred.  On January 15, 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 1, 2008 and December 31, 2010. The judgment specifies levy amounts on certain WD products sold from 2008 to 2010 and directs WD Germany to provide applicable sales data to the ZPÜ. The exact amount of the judgment has not been determined. WD Germany intends to appeal this decision to the German Federal Court of Justice and defend itself vigorously in this matter.

[0000106040-15-000003:notes:104]
On December 11, 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for Covered Products sold by WD or introduced into commerce in Germany from January 1, 2012 to December 31, 2013. WD Germany intends to defend itself vigorously in this matter.

[0000106040-15-000003:notes:105]
In the three months ended January 2, 2015, the Company recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows.  It is reasonably possible that the Company may incur losses totaling up to $90 million, including the amount accrued.

[0000106040-15-000003:notes:106]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties and is therefore not predictable with assurance, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, there can be no assurance with respect to such result, and monetary liability or financial impact to the Company from these other matters could differ materially from those projected.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-15-000003:notes:107]
14. Recent Accounting Pronouncements

[0000106040-15-000003:notes:108]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11, "Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists" ("ASU 2013-11"). The new standard requires the presentation of certain unrecognized tax benefits as reductions to deferred tax assets rather than as liabilities in the consolidated balance sheets when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2013, which for the Company was the first quarter of fiscal 2015. The Company adopted this pronouncement in the first quarter of fiscal 2015, and it did not have a material effect on its condensed consolidated financial statements.

[0000106040-15-000003:notes:109]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification Topic 605, "Revenue Recognition," to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years beginning after December 15, 2016, which for the Company is the first quarter of fiscal 2018. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-15-000003:notes:110]
[same as prior period, unchanged from 0001445305-14-004772:notes:116]

[0000106040-15-000003:notes:111]
The accounting policies followed by Western Digital Corporation (the “Company”) are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the year ended June 27, 2014. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the year ended June 27, 2014. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year. The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal second quarters ended January 2, 2015 and December 27, 2013 both consisted of 13 weeks. Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0000106040-15-000003:notes:112]
[same as prior period, unchanged from 0001445305-14-004772:notes:119]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-15-000003:notes:113]
[same as prior period, unchanged from 0001445305-14-004772:notes:120]

[0000106040-15-000003:notes:114]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three and six months ended January 2, 2015 and December 27, 2013. The expected long-term rate of return on the Japanese plan assets is 3.5%.

[0000106040-15-000003:notes:115]
[same as prior period, unchanged from 0001445305-14-004772:notes:122]

[0000106040-15-000003:notes:116]
|  | January 2, 2015 |  | June 27, 2014 |
| Benefit obligation | $ | 220 |  |  | $ | 255 |  |
| Fair value of plan assets | (168 | ) |  | (191 | ) |
| Unfunded status | $ | 52 |  |  | $ | 64 |  |

[0000106040-15-000003:notes:117]
[same as prior period, unchanged from 0001445305-14-004772:notes:124]

[0000106040-15-000003:notes:118]
|  | January 2, 2015 |  | June 27, 2014 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 51 |  |  | 63 |  |
| Net amount recognized | $ | 52 |  |  | $ | 64 |  |

[0000106040-15-000003:notes:119]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three and six months ended January 2, 2015 and December 27, 2013. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $11 million in fiscal 2015.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-15-000003:notes:120]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the six months ended January 2, 2015 (in millions):

[0000106040-15-000003:notes:121]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | 5 |  |  | $ | 12 |  |
| Other comprehensive income (loss) before reclassifications | — |  |  | (57 | ) |  | (57 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 13 |  |  | 13 |  |
| Net current-period other comprehensive income (loss) | — |  |  | (44 | ) |  | (44 | ) |
| Balance at January 2, 2015 | $ | 7 |  |  | $ | (39 | ) |  | $ | (32 | ) |

[0000106040-15-000003:notes:122]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the six months ended December 27, 2013 (in millions):

[0000106040-15-000003:notes:123]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 28, 2013 | $ | 11 |  |  | $ | (46 | ) |  | $ | (35 | ) |
| Other comprehensive income (loss) before reclassifications | — |  |  | (11 | ) |  | (11 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | (3 | ) |  | (3 | ) |
| Net current-period other comprehensive income (loss) | — |  |  | (14 | ) |  | (14 | ) |
| Balance at December 27, 2013 | $ | 11 |  |  | $ | (60 | ) |  | $ | (49 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-15-000003:notes:124]
[same as prior period, unchanged from 0001445305-14-004772:notes:131]

[0000106040-15-000003:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Warranty accrual, beginning of period | $ | 201 |  |  | $ | 195 |  |  | $ | 182 |  |  | $ | 187 |  |
| Warranty liability assumed as a result of acquisition | — |  |  | 1 |  |  | — |  |  | 4 |  |
| Charges to operations | 50 |  |  | 44 |  |  | 99 |  |  | 84 |  |
| Utilization | (44 | ) |  | (57 | ) |  | (93 | ) |  | (106 | ) |
| Changes in estimate related to pre-existing warranties | 16 |  |  | 7 |  |  | 35 |  |  | 21 |  |
| Warranty accrual, end of period | $ | 223 |  |  | $ | 190 |  |  | $ | 223 |  |  | $ | 190 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-15-000003:notes:126]
[same as prior period, unchanged from 0001445305-14-004772:notes:135]

[0000106040-15-000003:notes:127]
[same as prior period, unchanged from 0001445305-14-004772:notes:136]

[0000106040-15-000003:notes:128]
|  | January 2, 2015 |  | June 27, 2014 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 154 |  |  | $ | 168 |  |
| Work-in-process | 510 |  |  | 493 |  |
| Finished goods | 618 |  |  | 565 |  |
| Total inventories | $ | 1,282 |  |  | $ | 1,226 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 8,353 |  |  | $ | 8,123 |  |
| Accumulated depreciation | (5,254 | ) |  | (4,830 | ) |
| Property, plant and equipment, net | $ | 3,099 |  |  | $ | 3,293 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 983 |  |  | $ | 984 |  |
| Accumulated amortization | (624 | ) |  | (530 | ) |
| Other intangible assets, net | $ | 359 |  |  | $ | 454 |  |

[0000106040-15-000003:notes:129]
[same as prior period, unchanged from 0001445305-14-004772:notes:138]

[0000106040-15-000003:notes:130]
[same as prior period, unchanged from 0001445305-14-004772:notes:139]

[0000106040-15-000003:notes:131]
The long-term portion of the warranty accrual classified in other liabilities was $77 million as of January 2, 2015 and $63 million as of June 27, 2014.

[0000106040-15-000003:notes:132]
[same as prior period, unchanged from 0001445305-14-004772:notes:141]

[0000106040-15-000003:notes:133]
The Company determined no available-for-sale securities were other-than-temporarily impaired in the three and six months ended January 2, 2015. For more information on the Company's available-for-sale securities, see Note 7 below.

[0000106040-15-000003:notes:134]
In addition, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the consolidated balance sheets and were not material to the condensed consolidated financial statements as of January 2, 2015 and June 27, 2014.

[0000106040-15-000003:notes:135]
[same as prior period, unchanged from 0001445305-14-004772:notes:144]

[0000106040-15-000003:notes:136]
Other comprehensive income (loss) refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss) is comprised of unrealized gains and losses on foreign exchange contracts. There were no unrealized gains or losses on the Company's available-for-sale securities or actuarial gains and losses related to pensions in the six months ended January 2, 2015. In addition, the income tax impact on components of other comprehensive income (loss) is immaterial for all periods presented.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000106040-15-000003:notes:137]
13. Thailand Flooding

[0000106040-15-000003:notes:138]
In October 2011, severe flooding in Thailand inundated all of the Company’s Thailand manufacturing facilities and submerged certain equipment located there. The Company maintains insurance coverage that provides property and business interruption coverage in the event of losses arising from flooding. As a result, the Company received a total of $50 million of insurance recoveries, of which $13 million was received previously and $37 million was received in the three months ended January 2, 2015 and recorded within the "Selling, general and administrative" line item on the Company's condensed consolidated statements of income. As a result, all claims submitted by the Company to its insurers have been closed as of January 2, 2015.


## wdc:EmployeeTerminationAssetImpairmentandOtherChargesTableTextBlock

[0000106040-15-000003:notes:139]
The following table summarizes the Company's employee termination, asset impairment and other charges over fiscal year 2015 (in millions):

[0000106040-15-000003:notes:140]
|  | EmployeeTerminationBenefits |  | Impairmentof Assets |  | Total |
| Accrual at June 27, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charges | 8 |  |  | 1 |  |  | 9 |  |
| Non-cash charges | — |  |  | (1 | ) |  | (1 | ) |
| Accrual at October 3, 2014 | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Charges | 34 |  |  | 19 |  |  | 53 |  |
| Cash payments | (9 | ) |  | — |  |  | (9 | ) |
| Non-cash charges | — |  |  | (19 | ) |  | (19 | ) |
| Accrual at January 2, 2015 | $ | 33 |  |  | $ | — |  |  | $ | 33 |  |


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-15-000003:notes:141]
[same as prior period, unchanged from 0001445305-14-004772:notes:146]

[0000106040-15-000003:notes:142]
The Company periodically incurs charges to realign its operations with anticipated market demand. The following table summarizes the Company's employee termination, asset impairment and other charges over fiscal year 2015 (in millions):
