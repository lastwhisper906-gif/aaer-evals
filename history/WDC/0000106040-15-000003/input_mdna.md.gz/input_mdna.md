# WDC MD&A — 0000106040-15-000003


## mdna

[0000106040-15-000003:mdna:1]
[same as prior period, unchanged from 0001445305-14-004772:mdna:1]

[0000106040-15-000003:mdna:2]
You should read this information in conjunction with the unaudited condensed consolidated financial statements and the notes thereto included in this Quarterly Report on Form 10-Q, and the audited consolidated financial statements and notes thereto and Part II, Item 7, contained in our Annual Report on Form 10-K for the year ended June 27, 2014.

[0000106040-15-000003:mdna:3]
[same as prior period, unchanged from 0001445305-14-004772:mdna:3]

[0000106040-15-000003:mdna:4]
[same as prior period, unchanged from 0001445305-14-004772:mdna:4]

[0000106040-15-000003:mdna:5]
| • | expectations regarding industry demand and shipments in the quarter ending April 3, 2015 and the expected impact on our revenue; |

[0000106040-15-000003:mdna:6]
[same as prior period, unchanged from 0001445305-14-004772:mdna:6]

[0000106040-15-000003:mdna:7]
[same as prior period, unchanged from 0001445305-14-004772:mdna:7]

[0000106040-15-000003:mdna:8]
[same as prior period, unchanged from 0001445305-14-004772:mdna:8]

[0000106040-15-000003:mdna:9]
[same as prior period, unchanged from 0001445305-14-004772:mdna:9]

[0000106040-15-000003:mdna:10]
[same as prior period, unchanged from 0001445305-14-004772:mdna:10]

[0000106040-15-000003:mdna:11]
[same as prior period, unchanged from 0001445305-14-004772:mdna:11]

[0000106040-15-000003:mdna:12]
[same as prior period, unchanged from 0001445305-14-004772:mdna:12]

[0000106040-15-000003:mdna:13]
[same as prior period, unchanged from 0001445305-14-004772:mdna:13]

[0000106040-15-000003:mdna:14]
[same as prior period, unchanged from 0001445305-14-004772:mdna:14]

[0000106040-15-000003:mdna:15]
[same as prior period, unchanged from 0001445305-14-004772:mdna:15]

[0000106040-15-000003:mdna:16]
[same as prior period, unchanged from 0001445305-14-004772:mdna:16]

[0000106040-15-000003:mdna:17]
[same as prior period, unchanged from 0001445305-14-004772:mdna:17]

[0000106040-15-000003:mdna:18]
[same as prior period, unchanged from 0001445305-14-004772:mdna:18]

[0000106040-15-000003:mdna:19]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0000106040-15-000003:mdna:20]
[same as prior period, unchanged from 0001445305-14-004772:mdna:20]

[0000106040-15-000003:mdna:21]
[same as prior period, unchanged from 0001445305-14-004772:mdna:21]

[0000106040-15-000003:mdna:22]
[same as prior period, unchanged from 0001445305-14-004772:mdna:22]

[0000106040-15-000003:mdna:23]
Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those expressed in the forward-looking statements. We urge you to carefully review the disclosures we make concerning risks and other factors that may affect our business and operating results, including those made in Part I, Item 1A of this Quarterly

[0000106040-15-000003:mdna:24]
[same as prior period, unchanged from 0001445305-14-004772:mdna:23]

[0000106040-15-000003:mdna:25]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes hard disk drives (“HDDs”) and solid-state drives ("SSDs"), direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.  We currently operate our global business through two independent subsidiaries due to regulatory requirements - HGST and WD.

[0000106040-15-000003:mdna:26]
Second Quarter Overview

[0000106040-15-000003:mdna:27]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), we include the operating results for acquired companies commencing after their respective acquisition dates. Accordingly, Virident and sTec have been included in our results of operations since their acquisition dates of October 17, 2013, and September 12, 2013, respectively.

[0000106040-15-000003:mdna:28]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal second quarters ended January 2, 2015 and December 27, 2013 both consisted of 13 weeks. Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0000106040-15-000003:mdna:29]
For the quarter ended January 2, 2015, we believe that overall hard drive industry shipments totaled approximately 141 million units, down 1% from the prior-year period and down 4% from the first fiscal quarter.

[0000106040-15-000003:mdna:30]
The following table sets forth, for the periods presented, selected summary information from our condensed consolidated statements of income by dollars (in millions) and percentage of net revenue:

[0000106040-15-000003:mdna:31]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Net revenue | $ | 3,888 |  |  | 100.0 | % |  | $ | 3,972 |  |  | 100.0 | % |  | $ | 7,831 |  |  | 100.0 | % |  | $ | 7,776 |  |  | 100.0 | % |
| Gross profit | 1,110 |  |  | 28.5 |  |  | 1,156 |  |  | 29.1 |  |  | 2,259 |  |  | 28.8 |  |  | 2,255 |  |  | 29.0 |  |
| Total operating expenses | 644 |  |  | 16.6 |  |  | 678 |  |  | 17.1 |  |  | 1,324 |  |  | 16.9 |  |  | 1,235 |  |  | 15.9 |  |
| Operating income | 466 |  |  | 12.0 |  |  | 478 |  |  | 12.0 |  |  | 935 |  |  | 11.9 |  |  | 1,020 |  |  | 13.1 |  |
| Net income | 438 |  |  | 11.3 |  |  | 430 |  |  | 10.8 |  |  | 861 |  |  | 11.0 |  |  | 925 |  |  | 11.9 |  |

[0000106040-15-000003:mdna:32]
The following is a summary of our financial performance for the second quarter of fiscal 2015:

[0000106040-15-000003:mdna:33]
[same as prior period, unchanged from 0001445305-14-004772:mdna:33]

[0000106040-15-000003:mdna:34]
| • | Net revenue derived from enterprise SSDs was $187 million as compared to $155 million in the prior-year period. |

[0000106040-15-000003:mdna:35]
| • | Hard drive unit shipments decreased 3% from the prior-year period to 61.0 million units. |

[0000106040-15-000003:mdna:36]
| • | Gross margin decreased to 28.5%, compared to 29.1% for the prior-year period. |

[0000106040-15-000003:mdna:37]
| • | Operating income was $466 million, a decrease of $12 million from the prior-year period. |

[0000106040-15-000003:mdna:38]
| • | We generated $243 million in cash flow from operations and we ended the quarter with $4.9 billion in cash and cash equivalents. |

[0000106040-15-000003:mdna:39]
23

[0000106040-15-000003:mdna:40]
[same as prior period, unchanged from 0001445305-14-004772:mdna:42]

[0000106040-15-000003:mdna:41]
[same as prior period, unchanged from 0001445305-14-004772:mdna:43]

[0000106040-15-000003:mdna:42]
|  | Three MonthsEnded |  |  |  | Six MonthsEnded |  |  |
| (in millions, except percentages andaverage selling price) | January 2, 2015 |  | December 27, 2013 |  | Percentage Change |  | January 2, 2015 |  | December 27, 2013 |  | PercentageChange |
| Net revenue | $ | 3,888 |  |  | $ | 3,972 |  |  | (2 | )% |  | $ | 7,831 |  |  | $ | 7,776 |  |  | 1 | % |
| Average selling price (per unit)* | $ | 60 |  |  | $ | 60 |  |  | — | % |  | $ | 59 |  |  | $ | 59 |  |  | — | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas | 27 | % |  | 25 | % |  |  |  | 27 | % |  | 26 | % |  |  |
| Europe, Middle East and Africa | 24 |  |  | 23 |  |  |  |  | 23 |  |  | 21 |  |  |  |
| Asia | 49 |  |  | 52 |  |  |  |  | 50 |  |  | 53 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEM | 63 | % |  | 62 | % |  |  |  | 63 | % |  | 63 | % |  |  |
| Distributors | 23 |  |  | 24 |  |  |  |  | 24 |  |  | 24 |  |  |  |
| Retailers | 14 |  |  | 14 |  |  |  |  | 13 |  |  | 13 |  |  |  |
| Unit Shipments* |  |  |  |  |  |  |  |  |  |  |  |
| PC | 36.6 |  |  | 39.5 |  |  |  |  | 76.3 |  |  | 79.7 |  |  |  |
| Non-PC | 24.4 |  |  | 23.6 |  |  |  |  | 49.5 |  |  | 46.0 |  |  |  |
| Total units shipped | 61.0 |  |  | 63.1 |  |  | (3 | )% |  | 125.8 |  |  | 125.7 |  |  | — | % |

[0000106040-15-000003:mdna:43]
[same as prior period, unchanged from 0001445305-14-004772:mdna:45]

[0000106040-15-000003:mdna:44]
For the quarter ended January 2, 2015, net revenue was $3.9 billion, a decrease of 2% from the prior-year period. This decrease in revenue was primarily due to a decrease in total hard drive shipments, offset by changes in product mix. Total hard drive shipments decreased to 61.0 million units for the quarter ended January 2, 2015 as compared to 63.1 million units in the prior-year period. For the six months ended January 2, 2015, net revenue was $7.8 billion, an increase of 1% from the prior year period. Total hard drive shipments increased to 125.8 million units for the six months ended January 2, 2015 as compared to 125.7 million units in the prior-year period. For the quarter ended January 2, 2015, average selling price ("ASP") remained flat with the prior-year period at $60. For the six months ended January 2, 2015, ASP remained flat with the prior-year period at $59.

[0000106040-15-000003:mdna:45]
Changes in revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For both the three and six months ended January 2, 2015, Hewlett-Packard Company accounted for approximately 11% of our net revenue. For the three and six months ended December 27, 2013, Hewlett-Packard Company accounted for approximately 11% and 12% of our net revenue, respectively.

[0000106040-15-000003:mdna:46]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Generally, total sales incentive and marketing programs range from 7% to 10% of gross revenues per quarter. For the three and six months ended January 2, 2015, these programs represented 10% and 9% of gross revenues, respectively, as compared to 7% in both respective prior-year periods. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.6% of quarterly gross revenue since the first quarter of fiscal 2013.

[0000106040-15-000003:mdna:47]
[same as prior period, unchanged from 0001445305-14-004772:mdna:49]

[0000106040-15-000003:mdna:48]
|  | Three MonthsEnded |  |  |  | Six MonthsEnded |  |  |
| (in millions, except percentages) | January 2, 2015 |  | December 27, 2013 |  | Percentage Change |  | January 2, 2015 |  | December 27, 2013 |  | PercentageChange |
| Net revenue | $ | 3,888 |  |  | $ | 3,972 |  |  | (2 | )% |  | $ | 7,831 |  |  | $ | 7,776 |  |  | 1 | % |
| Gross profit | 1,110 |  |  | 1,156 |  |  | (4 | )% |  | 2,259 |  |  | 2,255 |  |  | — | % |
| Gross margin | 28.5 | % |  | 29.1 | % |  |  |  | 28.8 | % |  | 29.0 | % |  |  |

[0000106040-15-000003:mdna:49]
[same as prior period, unchanged from 0001445305-14-004772:mdna:41]

[0000106040-15-000003:mdna:50]
For the three months ended January 2, 2015, gross margin decreased to 28.5% as compared to 29.1% for the prior-year period. For the six months ended January 2, 2015, gross margin decreased to 28.8% as compared to 29.0% for the prior-year period.

[0000106040-15-000003:mdna:51]
[same as prior period, unchanged from 0001445305-14-004772:mdna:52]

[0000106040-15-000003:mdna:52]
|  | Three MonthsEnded |  |  |  | Six MonthsEnded |  |  |
| (in millions, except percentages) | January 2, 2015 |  | December 27, 2013 |  | Percentage Change |  | January 2, 2015 |  | December 27, 2013 |  | PercentageChange |
| R&D expense | $ | 426 |  |  | $ | 416 |  |  | 2 | % |  | $ | 863 |  |  | $ | 817 |  |  | 6 | % |
| SG&A expense | 164 |  |  | 226 |  |  | (27 | )% |  | 384 |  |  | 358 |  |  | 7 | % |
| Charges related to arbitration award | 1 |  |  | 13 |  |  | (92 | )% |  | 15 |  |  | 26 |  |  | (42 | )% |
| Employee termination, asset impairment and other charges | 53 |  |  | 23 |  |  | 130 | % |  | 62 |  |  | 34 |  |  | 82 | % |
| Total operating expenses | $ | 644 |  |  | $ | 678 |  |  |  |  | $ | 1,324 |  |  | $ | 1,235 |  |  |  |

[0000106040-15-000003:mdna:53]
Research and development (“R&D”) expense was $426 million for the three months ended January 2, 2015, an increase of $10 million from the prior-year period. This increase was primarily due to additional investment in our enterprise SSD business. For the six months ended January 2, 2015, R&D expense was $863 million, an increase of $46 million from the prior-year period. This increase was primarily due to additional investment in our enterprise SSD business and the inclusion of a full six month period of Virident and sTec's R&D expenses, as opposed to a partial six month period of such expenses in the comparative prior-year period, and an additional week of operating expenses due to a 14-week quarter in our first fiscal quarter in the current period. As a percentage of net revenue, R&D expense increased to 11.0% in both the three and six months ended January 2, 2015, as compared to 10.5% in both the respective prior-year periods.

[0000106040-15-000003:mdna:54]
Selling, general and administrative (“SG&A”) expense was $164 million for the three months ended January 2, 2015, a decrease of $62 million from the prior-year period. This decrease was primarily due to a $37 million flood-related insurance recovery during the period, as well as ongoing efforts to reduce our operating expenses. For the six months ended January 2, 2015, SG&A expense was $384 million, an increase of $26 million from the prior-year period. This increase was primarily due to the inclusion of a full six month period of Virident and sTec's SG&A expenses, as opposed to a partial six month period of such expenses in the comparative prior-year period, and an additional week of operating expenses due to a 14-week quarter in our first fiscal quarter in the current period. Additionally, this increase is a result of a $37 million flood-related insurance recovery in the current period compared to a $65 million flood-related insurance recovery in the prior-year period. SG&A expense as a percentage of net revenue was 4.2% and 4.9% in the three and six months ended January 2, 2015, respectively, as compared to 5.7% and 4.6% in the respective prior-year periods.

[0000106040-15-000003:mdna:55]
During the three and six months ended January 2, 2015, we recorded $1 million and $15 million, respectively, of interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC ("Seagate") as compared to $13 million and $26 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:56]
During the three and six months ended January 2, 2015, we recorded employee termination, asset impairment and other charges of $53 million and $62 million, respectively, in order to realign our operations with anticipated market demand as compared to $23 million and $34 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:57]
[same as prior period, unchanged from 0001445305-14-004772:mdna:58]

[0000106040-15-000003:mdna:58]
Interest income for the three and six months ended January 2, 2015 increased $1 million and $2 million, respectively, as compared to the prior-year periods primarily due to a higher average daily invested cash balance for the periods. Interest and other expense for both the three and six months ended January 2, 2015 decreased $2 million when compared to the respective prior-year periods primarily due to interest on a lower debt balance.

[0000106040-15-000003:mdna:59]
[same as prior period, unchanged from 0001445305-14-004772:mdna:60]

[0000106040-15-000003:mdna:60]
Our income tax provision for the three months ended January 2, 2015 was $20 million, as compared to $37 million in the prior-year period. Our income tax provision for the six months ended January 2, 2015 was $57 million, as compared to $74 million in the prior-year period. Our tax provision for the three and six months ended January 2, 2015 reflects a tax benefit of $16

[0000106040-15-000003:mdna:61]
25

[0000106040-15-000003:mdna:62]
million as a result of the retroactive extension of the U.S. Federal R&D tax credit that was signed into law on December 19, 2014. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:63]
[same as prior period, unchanged from 0001445305-14-004772:mdna:62]

[0000106040-15-000003:mdna:64]
In relation to our litigation matter with Seagate, on October 8, 2014, the Minnesota Supreme Court affirmed the decision of the Minnesota Court of Appeals, and as a result, on October 14, 2014, we paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 13, 2014. This amount was paid by one of our foreign subsidiaries using cash held outside the United States. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:65]
[same as prior period, unchanged from 0001445305-14-004772:mdna:65]

[0000106040-15-000003:mdna:66]
We ended the second quarter of fiscal 2015 with total cash and cash equivalents of $4.9 billion. The following table summarizes our statements of cash flows (in millions):

[0000106040-15-000003:mdna:67]
|  | Six Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 1,070 |  |  | $ | 1,406 |  |
| Investing activities | (254 | ) |  | (1,125 | ) |
| Financing activities | (718 | ) |  | 65 |  |
| Net increase in cash and cash equivalents | $ | 98 |  |  | $ | 346 |  |

[0000106040-15-000003:mdna:68]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, stock repurchase and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:69]
A total of $3.5 billion of our cash and cash equivalents was held outside of the United States at both January 2, 2015 and June 27, 2014. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. As described in the section "Arbitration Award" above, the amount of $773.4 million was paid on October 14, 2014 from one of our foreign subsidiaries using cash held outside the United States. On September 13, 2012, our Board of Directors approved a capital allocation plan which includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-15-000003:mdna:70]
[same as prior period, unchanged from 0001445305-14-004772:mdna:70]

[0000106040-15-000003:mdna:71]
Net cash provided by operating activities was $1.1 billion during the six months ended January 2, 2015. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used in working capital changes was $475 million for the six months ended January 2, 2015 as compared to $166 million used by working capital changes in the prior-year period.

[0000106040-15-000003:mdna:72]
[same as prior period, unchanged from 0001445305-14-004772:mdna:64]

[0000106040-15-000003:mdna:73]
[same as prior period, unchanged from 0001445305-14-004772:mdna:72]

[0000106040-15-000003:mdna:74]
|  | Three Months Ended |
|  | January 2, 2015 |  | December 27, 2013 |
| Days sales outstanding | 44 |  |  | 45 |  |
| Days in inventory | 42 |  |  | 42 |  |
| Days payables outstanding | (68 | ) |  | (68 | ) |
| Cash conversion cycle | 18 |  |  | 19 |  |

[0000106040-15-000003:mdna:75]
For the three months ended January 2, 2015, our average days sales outstanding (“DSOs”) decreased by 1 day, days in inventory (“DIOs”) remained flat, and days payable outstanding (“DPOs”) remained flat compared to the prior year period. Changes in average DSOs and DIOs are generally related to linearity of shipments and the timing of inventory builds, respectively. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-15-000003:mdna:76]
[same as prior period, unchanged from 0001445305-14-004772:mdna:78]

[0000106040-15-000003:mdna:77]
Cash used in investing activities for the six months ended January 2, 2015 was $254 million and consisted of $595 million related to the purchase of investments, $306 million of capital expenditures and $6 million related to an immaterial acquisition, net of cash acquired, partially offset by $630 million of proceeds from sales and maturities of investments, $7 million of proceeds from the sale of property, plant and equipment and $16 million, net for other investing activities. Cash used in investing activities for the six months ended December 27, 2013 was $1.1 billion and consisted of $823 million related to acquisitions, net of cash acquired, and $306 million of capital expenditures, partially offset by a net $4 million for other investing activities.

[0000106040-15-000003:mdna:78]
[same as prior period, unchanged from 0001445305-14-004772:mdna:80]

[0000106040-15-000003:mdna:79]
Net cash used in financing activities for the six months ended January 2, 2015 was $718 million as compared to $65 million provided by financing activities in the prior-year period. Net cash used in financing activities for the six months ended January 2, 2015 consisted of $532 million used to repurchase shares of our common stock, $187 million used to pay dividends on our common stock and $63 million used to make principal payments on the Credit Agreement, partially offset by a net $64 million provided by employee stock plans. Net cash provided by financing activities for the six months ended December 27, 2013 consisted of $500 million of debt proceeds under the revolving credit facility and a net $98 million provided by employee stock plans, partially offset by $300 million used to repurchase shares of our common stock, $118 million used to pay dividends on our common stock and $115 million used to repay long-term debt.

[0000106040-15-000003:mdna:80]
[same as prior period, unchanged from 0001445305-14-004772:mdna:82]

[0000106040-15-000003:mdna:81]
[same as prior period, unchanged from 0001445305-14-004772:mdna:83]

[0000106040-15-000003:mdna:82]
[same as prior period, unchanged from 0001445305-14-004772:mdna:84]

[0000106040-15-000003:mdna:83]
Long-Term Debt — On January 9, 2014, Western Digital Ireland, Ltd. (“WDI”) used existing cash to repay the outstanding term loan balance of $1.8 billion under our previous credit agreement dated March 8, 2012, and we, in our capacity as the parent entity and guarantor, and the Borrowers, entered into a new credit agreement (the "Credit Agreement").

[0000106040-15-000003:mdna:84]
As of January 2, 2015, no amounts were outstanding under the revolving credit facility of the Credit Agreement and the term loan facility had an outstanding balance of $2.4 billion with a variable interest rate of 1.66%. We are required to make quarterly principal payments on the term loan facility totaling $63 million for the remainder of fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. For additional information, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:85]
[same as prior period, unchanged from 0001445305-14-004772:mdna:76]

[0000106040-15-000003:mdna:86]
[same as prior period, unchanged from 0001445305-14-004772:mdna:87]

[0000106040-15-000003:mdna:87]
We have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components.

[0000106040-15-000003:mdna:88]
[same as prior period, unchanged from 0001445305-14-004772:mdna:90]

[0000106040-15-000003:mdna:89]
Refer to  Part II, Item 7 of our Annual Report on Form 10-K for the year ended June 27, 2014, for further discussion of our purchase orders and purchase agreements and the associated dollar amounts. See Part II, Item 1A of this Quarterly Report on Form 10-Q for a discussion of the risks associated with these commitments.

[0000106040-15-000003:mdna:90]
[same as prior period, unchanged from 0001445305-14-004772:mdna:92]

[0000106040-15-000003:mdna:91]
[same as prior period, unchanged from 0001445305-14-004772:mdna:93]

[0000106040-15-000003:mdna:92]
[same as prior period, unchanged from 0001445305-14-004772:mdna:94]

[0000106040-15-000003:mdna:93]
Unrecognized Tax Benefits — As of January 2, 2015, the cash portion of our total recorded liability for unrecognized tax benefits was $259 million. We estimate the timing of the future payments of these liabilities to be within the next one to eight years. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:94]
Stock Repurchase Program — Since May 21, 2012, our Board of Directors has authorized $3.0 billion for the repurchase of our common stock. We repurchased 3.2 million and 5.4 million shares of our common stock for a total cost of $309 million and $532 million during the three and six months ended January 2, 2015, respectively. On February 3, 2015, our Board of Directors authorized an additional $2.0 billion for the repurchase of our common stock and approved the extension of our stock repurchase program to February 3, 2020, resulting in a cumulative authorized repurchase amount of $5.0 billion since the inception of the repurchase program. Subsequent to January 2, 2015 and through February 5, 2015, we repurchased an additional 2.2 million shares of our common stock for a total cost of $240 million. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:95]
Cash Dividend Policy — During the three months ended January 2, 2015, we declared a cash dividend of $0.40 per share of our common stock to our shareholders of record as of January 2, 2015, totaling $93 million, which we paid on January 15, 2015. In addition, in the three months ended October 3, 2014, we declared a cash dividend of $0.40 per share of our common stock to our shareholders of record as of October 3, 2014, totaling $94 million, which we paid on October 15, 2014. On February 3, 2015, we declared a cash dividend of $0.50 per share of our common stock to shareholders of record as of April 3, 2015, which will be

[0000106040-15-000003:mdna:96]
paid on April 16, 2015. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000003:mdna:97]
[same as prior period, unchanged from 0001445305-14-004772:mdna:98]

[0000106040-15-000003:mdna:98]
We have prepared the unaudited condensed consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the year ended June 27, 2014. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 27, 2014 for a discussion of our critical accounting policies and estimates.

[0000106040-15-000003:mdna:99]
[same as prior period, unchanged from 0001445305-14-004772:mdna:100]

[0000106040-15-000003:mdna:100]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, refer to Part I, Item 1, Note 14 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.
