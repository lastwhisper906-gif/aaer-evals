# WDC notes — 0000106040-18-000016


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-18-000016:notes:1]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of March 30, 2018, by remaining contractual maturity, were as follows:

[0000106040-18-000016:notes:2]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 22 |  |  | $ | 20 |  |
| Due in one to five years (included in other non-current assets) | 95 |  |  | 93 |  |
| Total | $ | 117 |  |  | $ | 113 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-18-000016:notes:3]
The Company’s total cash, cash equivalents and available-for-sale securities was as follows:

[0000106040-18-000016:notes:4]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 4,963 |  |  | $ | 6,354 |  |
| Short-term available-for-sale securities | 20 |  |  | 24 |  |
| Long-term available-for-sale securities (included within other non-current assets) | 93 |  |  | 94 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 5,076 |  |  | $ | 6,472 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-18-000016:notes:5]
[same as prior period, unchanged from 0000106040-18-000010:notes:5]

[0000106040-18-000016:notes:6]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Benefit obligations | $ | 263 |  |  | $ | 249 |  |
| Fair value of plan assets | 205 |  |  | 189 |  |
| Unfunded status | $ | 58 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-18-000016:notes:7]
Commitments, Contingencies and Related Parties

[0000106040-18-000016:notes:8]
Flash Ventures

[0000106040-18-000016:notes:9]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-18-000016:notes:10]
In connection with a settlement agreement with Toshiba in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of the parties’ existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6.

[0000106040-18-000016:notes:11]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 30, 2018 and June 30, 2017:

[0000106040-18-000016:notes:12]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 838 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 76 |  |  | 119 |  |
| Notes receivable, Flash Forward | 633 |  |  | 379 |  |
| Investment in Flash Partners | 198 |  |  | 187 |  |
| Investment in Flash Alliance | 295 |  |  | 279 |  |
| Investment in Flash Forward | 120 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,160 |  |  | $ | 1,340 |  |

[0000106040-18-000016:notes:13]
During the three and nine months ended March 30, 2018, the Company made net payments to Flash Ventures of $1.00 billion and $3.0 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-18-000016:notes:14]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-18-000016:notes:15]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments for credit worthiness in the three and nine months ended March 30, 2018 and March 31, 2017.

[0000106040-18-000016:notes:16]
As of March 30, 2018 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $282 million and $206 million, respectively.

[0000106040-18-000016:notes:17]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 30, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-18-000016:notes:18]
|  | March 30, 2018 |
| Notes receivable | $ | 1,547 |  |
| Equity investments | 613 |  |
| Operating lease guarantees | 1,109 |  |
| Inventory and prepayments | 319 |  |
| Maximum estimable loss exposure | $ | 3,588 |  |

[0000106040-18-000016:notes:19]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-18-000016:notes:20]
Off-Balance Sheet Liabilities

[0000106040-18-000016:notes:21]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-18-000016:notes:22]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018.

[0000106040-18-000016:notes:23]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 118 |  |  | $ | 1,109 |  |

[0000106040-18-000016:notes:24]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 30, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018:

[0000106040-18-000016:notes:25]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 307 |  |  | $ | 15 |  |  | $ | 322 |  |
| Year 2 |  | 212 |  |  | 40 |  |  | 252 |  |
| Year 3 |  | 188 |  |  | 116 |  |  | 304 |  |
| Year 4 |  | 94 |  |  | 81 |  |  | 175 |  |
| Year 5 |  | 24 |  |  | — |  |  | 24 |  |
| Year 6 |  | 3 |  |  | 29 |  |  | 32 |  |
| Total guarantee obligations |  | $ | 828 |  |  | $ | 281 |  |  | $ | 1,109 |  |

[0000106040-18-000016:notes:26]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 30, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-18-000016:notes:27]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 61 |  |  | $ | 763 |  |  | $ | 600 |  |  | $ | (1,363 | ) |  | $ | 61 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 76 |  |  | 75 |  |  | 75 |  |  | (150 | ) |  | 76 |  |
| Net unrealized gain on derivative contracts | 21 |  |  | 13 |  |  | 14 |  |  | (27 | ) |  | 21 |  |
| Net unrealized loss on available-for-sale securities | (3 | ) |  | (3 | ) |  | (3 | ) |  | 6 |  |  | (3 | ) |
| Total other comprehensive income, before tax | 95 |  |  | 86 |  |  | 87 |  |  | (173 | ) |  | 95 |  |
| Income tax expense related to items of other comprehensive income | (3 | ) |  | (2 | ) |  | (3 | ) |  | 5 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 92 |  |  | 84 |  |  | 84 |  |  | (168 | ) |  | 92 |  |
| Total comprehensive income | $ | 153 |  |  | $ | 847 |  |  | $ | 684 |  |  | $ | (1,531 | ) |  | $ | 153 |  |

[0000106040-18-000016:notes:28]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (81 | ) |  | $ | 806 |  |  | $ | 1,770 |  |  | $ | (2,576 | ) |  | $ | (81 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 78 |  |  | 76 |  |  | 76 |  |  | (152 | ) |  | 78 |  |
| Net unrealized gain on derivative contracts | 35 |  |  | 19 |  |  | 20 |  |  | (39 | ) |  | 35 |  |
| Net unrealized loss on available-for-sale securities | (4 | ) |  | (4 | ) |  | (4 | ) |  | 8 |  |  | (4 | ) |
| Total other comprehensive income, before tax | 110 |  |  | 92 |  |  | 93 |  |  | (185 | ) |  | 110 |  |
| Income tax expense related to items of other comprehensive income | (6 | ) |  | (2 | ) |  | (4 | ) |  | 6 |  |  | (6 | ) |
| Other comprehensive income, net of tax | 104 |  |  | 90 |  |  | 89 |  |  | (179 | ) |  | 104 |  |
| Total comprehensive income | $ | 23 |  |  | $ | 896 |  |  | $ | 1,859 |  |  | $ | (2,755 | ) |  | $ | 23 |  |

[0000106040-18-000016:notes:29]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 248 |  |  | $ | 389 |  |  | $ | 217 |  |  | $ | (606 | ) |  | $ | 248 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 58 |  |  | 58 |  |  | 58 |  |  | (116 | ) |  | 58 |  |
| Net unrealized gain on derivative contracts | 45 |  |  | 42 |  |  | 41 |  |  | (83 | ) |  | 45 |  |
| Total other comprehensive income, before tax | 104 |  |  | 101 |  |  | 100 |  |  | (201 | ) |  | 104 |  |
| Income tax expense related to items of other comprehensive income | (3 | ) |  | (3 | ) |  | (2 | ) |  | 5 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 101 |  |  | 98 |  |  | 98 |  |  | (196 | ) |  | 101 |  |
| Total comprehensive income | $ | 349 |  |  | $ | 487 |  |  | $ | 315 |  |  | $ | (802 | ) |  | $ | 349 |  |

[0000106040-18-000016:notes:30]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 117 |  |  | $ | 558 |  |  | $ | 13 |  |  | $ | (571 | ) |  | $ | 117 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 7 |  |  | 7 |  |  | 7 |  |  | (14 | ) |  | 7 |  |
| Foreign currency translation adjustment | (111 | ) |  | (111 | ) |  | (134 | ) |  | 245 |  |  | (111 | ) |
| Net unrealized loss on derivative contracts | (95 | ) |  | (98 | ) |  | (95 | ) |  | 193 |  |  | (95 | ) |
| Total other comprehensive loss, before tax | (199 | ) |  | (202 | ) |  | (222 | ) |  | 424 |  |  | (199 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | — |  |
| Other comprehensive loss, net of tax | (199 | ) |  | (202 | ) |  | (223 | ) |  | 425 |  |  | (199 | ) |
| Total comprehensive income (loss) | $ | (82 | ) |  | $ | 356 |  |  | $ | (210 | ) |  | $ | (146 | ) |  | $ | (82 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000106040-18-000016:notes:31]
Debt

[0000106040-18-000016:notes:32]
Debt consisted of the following as of March 30, 2018 and June 30, 2017:

[0000106040-18-000016:notes:33]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,022 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,455 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,412 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (212 | ) |  | (205 | ) |
| Subtotal | 11,200 |  |  | 13,151 |  |
| Less current portion of long-term debt | (124 | ) |  | (233 | ) |
| Long-term debt | $ | 11,076 |  |  | $ | 12,918 |  |

[0000106040-18-000016:notes:34]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |

[0000106040-18-000016:notes:35]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of March 30, 2018, issuance costs of $20 million remained unamortized.

[0000106040-18-000016:notes:36]
In February 2018, the Company also issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company.

[0000106040-18-000016:notes:37]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of approximately $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events.

[0000106040-18-000016:notes:38]
On or after February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

[0000106040-18-000016:notes:39]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of March 30, 2018, debt discount and issuance cost of $176 million remained unamortized.

[0000106040-18-000016:notes:40]
In February 2018, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced the Company’s prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on the Company’s corporate credit ratings as described in the indenture, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. The Company used a portion of the proceeds of the Term Loan A-1 to repay in full its previous variable interest rate Term Loan A in the principal amount of $4.02 billion.

[0000106040-18-000016:notes:41]
The Term Loan A-1 bears interest at a per annum rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings.  Currently the Company has selected the LIBOR rate option, and the applicable rate was 3.38% as of March 30, 2018. Principal payments are due in quarterly installments of (i) 0.625% per quarter from June 2018 through March 2019 and (ii) 1.25% per quarter from June 2019 through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of March 30, 2018, issuance costs of $9 million remained unamortized.

[0000106040-18-000016:notes:42]
Proceeds of $500 million were drawn under the Revolving Facility and were used to fund a voluntary partial prepayment of the Company’s existing U.S. Dollar denominated term B-3 loans (“U.S. Term Loan B-3”). Loans under the Revolving Facility bear interest, at the Company’s option, at either LIBOR plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.38% as of March 30, 2018. The Company will also pay an unused commitment fee on the Revolving Facility ranging from 0.120% to 0.350% based on the Company’s corporate credit ratings as described in the indenture, with an initial fee of 0.250%.

[0000106040-18-000016:notes:43]
The Term Loan A-1 and the Revolving Facility are unconditionally guaranteed by each of the guarantors under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantees will be automatically suspended upon certain conditions.

[0000106040-18-000016:notes:44]
During the three months ended March 30, 2018, the Company completed the redemption of all of its outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of its outstanding 10.50% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Redeemed Notes”), including an aggregate of $720 million of “make-whole” and tender premiums required for the tender offer of the 2024 Notes and the optional redemption of the Redeemed Notes in accordance with the applicable indentures and accrued interest through the applicable redemption dates.

[0000106040-18-000016:notes:45]
In November 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. Additionally, in November 2017, the Company borrowed $2.96 billion under U.S. Term Loan B-3 under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.88% as of March 30, 2018. Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. During the three months ended March 30, 2018, the Company funded a voluntary partial prepayment of $500 million, which was allocated towards principal payments. As a result, the Company is not required to make principal payments on the U.S. Term Loan B-3 prior to its maturity date. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of March 30, 2018, issuance costs of $3 million remained unamortized.

[0000106040-18-000016:notes:46]
In connection with the settlements of the various debt instruments described above, the Company recognized an aggregate loss on debt extinguishment of $896 million for the nine months ended March 30, 2018, consisting of $720 million of “make-whole” and tender premiums and $176 million of unamortized issuance costs, of which $894 million was incurred in the three months ended March 30, 2018. In the three and nine months ended March 31, 2017, the Company incurred losses on the extinguishment of debt of $7 million and $274 million, respectively.

[0000106040-18-000016:notes:47]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of March 30, 2018, the Company was in compliance with all financial covenants. In addition, the Credit Agreement requires the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. In addition, the indentures governing the 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-18-000016:notes:48]
[same as prior period, unchanged from 0000106040-18-000010:notes:38]

[0000106040-18-000016:notes:49]
As of March 30, 2018, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps that were designated as cash flow hedges. The Company determined the ineffective portion and the amount excluded for effectiveness testing associated with its cash flow hedges to be immaterial to the Condensed Consolidated Financial Statements for the three and nine months ended March 30, 2018 and March 31, 2017.

[0000106040-18-000016:notes:50]
As of March 30, 2018, the amount of existing net gains related to cash flow hedges recorded in AOCI was $28 million. Over the next twelve months, the Company expects to reclassify the majority of this amount into earnings. In addition, as of March 30, 2018, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-18-000016:notes:51]
A change in the fair value of non-designated hedges is recognized in earnings in the period incurred and is reported as a component of Other expense, net. The changes in fair value on these contracts were immaterial to the Condensed Consolidated Financial Statements for the three and nine months ended March 30, 2018 and March 31, 2017.

[0000106040-18-000016:notes:52]
The Company accounts for its interest rate swap as a designated cash flow hedge to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. The Company pays interest monthly at a fixed rate and receives interest monthly at the LIBOR rate on the notional amount of the contract. The effective portion of the change in fair value of this designated cash flow hedge is deferred in Other comprehensive income (loss), net of tax, with any ineffective portion recognized in Other income (expense), net.

[0000106040-18-000016:notes:53]
[same as prior period, unchanged from 0000106040-18-000010:notes:42]

[0000106040-18-000016:notes:54]
[same as prior period, unchanged from 0000106040-18-000010:notes:43]

[0000106040-18-000016:notes:55]
|  | Derivative Assets |
|  | Other current assets |
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 9 |  |  | $ | 6 |  |
| Foreign exchange forward contracts, not designated | 15 |  |  | 10 |  |
| Interest rate swaps, designated | 14 |  |  | — |  |
| Total derivatives | $ | 38 |  |  | $ | 16 |  |

[0000106040-18-000016:notes:56]
|  | Derivative Liabilities |
|  | Accrued expenses |
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Foreign exchange forward contracts, designated | $ | 1 |  |  | $ | 2 |  |
| Foreign exchange forward contracts, not designated | 9 |  |  | 6 |  |
| Interest rate swaps, designated | — |  |  | 1 |  |
| Total derivatives | $ | 10 |  |  | $ | 9 |  |

[0000106040-18-000016:notes:57]
[same as prior period, unchanged from 0000106040-18-000010:notes:46]

[0000106040-18-000016:notes:58]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 30, 2018 and June 30, 2017, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.

[0000106040-18-000016:notes:59]
[same as prior period, unchanged from 0000106040-18-000010:notes:48]

[0000106040-18-000016:notes:60]
[same as prior period, unchanged from 0000106040-18-000010:notes:49]

[0000106040-18-000016:notes:61]
|  | Amount of Gain (Loss) Recognized in AOCI |  | Amount of Gain (Loss) Recognized in AOCI |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts | $ | 23 |  |  | $ | 50 |  |  | $ | 30 |  |  | $ | (48 | ) |
| Interest rate swaps | 7 |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 30 |  |  | $ | 50 |  |  | $ | 45 |  |  | $ | (48 | ) |

[0000106040-18-000016:notes:62]
|  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |
| Foreign exchange forward contracts | $ | 9 |  |  | $ | 5 |  |  | $ | 10 |  |  | $ | 47 |  |
| Total | $ | 9 |  |  | $ | 5 |  |  | $ | 10 |  |  | $ | 47 |  |

[0000106040-18-000016:notes:63]
The total net realized and unrealized transaction and foreign exchange forward contract currency gains and losses were not material to the Condensed Consolidated Financial Statements for the three and nine months ended March 30, 2018 and March 31, 2017.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-18-000016:notes:64]
[same as prior period, unchanged from 0000106040-18-000010:notes:53]

[0000106040-18-000016:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Options | $ | 6 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 33 |  |
| Restricted and performance stock units | 89 |  |  | 85 |  |  | 260 |  |  | 254 |  |
| Employee stock purchase plan | 8 |  |  | 7 |  |  | 20 |  |  | 16 |  |
| Subtotal | 103 |  |  | 102 |  |  | 299 |  |  | 303 |  |
| Tax benefit | (17 | ) |  | (26 | ) |  | (51 | ) |  | (80 | ) |
| Total | $ | 86 |  |  | $ | 76 |  |  | $ | 248 |  |  | $ | 223 |  |

[0000106040-18-000016:notes:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Cost of revenue | $ | 11 |  |  | $ | 13 |  |  | $ | 37 |  |  | $ | 37 |  |
| Research and development | 45 |  |  | 45 |  |  | 134 |  |  | 132 |  |
| Selling, general and administrative | 46 |  |  | 40 |  |  | 127 |  |  | 125 |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 4 |  |  | 1 |  |  | 9 |  |
| Subtotal | 103 |  |  | 102 |  |  | 299 |  |  | 303 |  |
| Tax benefit | (17 | ) |  | (26 | ) |  | (51 | ) |  | (80 | ) |
| Total | $ | 86 |  |  | $ | 76 |  |  | $ | 248 |  |  | $ | 223 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-18-000016:notes:67]
[same as prior period, unchanged from 0000106040-18-000010:notes:56]

[0000106040-18-000016:notes:68]
[same as prior period, unchanged from 0000106040-18-000010:notes:57]

[0000106040-18-000016:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 61 |  |  | $ | 248 |  |  | $ | (81 | ) |  | $ | 117 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 298 |  |  | 289 |  |  | 296 |  |  | 287 |  |
| Employee stock options, RSUs, PSUs and ESPP | 10 |  |  | 10 |  |  | — |  |  | 8 |  |
| Diluted | 308 |  |  | 299 |  |  | 296 |  |  | 295 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.20 |  |  | $ | 0.86 |  |  | $ | (0.27 | ) |  | $ | 0.41 |  |
| Diluted | $ | 0.20 |  |  | $ | 0.83 |  |  | $ | (0.27 | ) |  | $ | 0.40 |  |
| Anti-dilutive potential common shares excluded(1) | 2 |  |  | 2 |  |  | 13 |  |  | 4 |  |

[0000106040-18-000016:notes:70]
[same as prior period, unchanged from 0000106040-18-000010:notes:59]

[0000106040-18-000016:notes:71]
[same as prior period, unchanged from 0000106040-18-000010:notes:60]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-18-000016:notes:72]
[same as prior period, unchanged from 0000106040-18-000010:notes:61]

[0000106040-18-000016:notes:73]
[same as prior period, unchanged from 0000106040-18-000010:notes:62]

[0000106040-18-000016:notes:74]
[same as prior period, unchanged from 0000106040-18-000010:notes:63]

[0000106040-18-000016:notes:75]
[same as prior period, unchanged from 0000106040-18-000010:notes:64]

[0000106040-18-000016:notes:76]
[same as prior period, unchanged from 0000106040-18-000010:notes:65]

[0000106040-18-000016:notes:77]
[same as prior period, unchanged from 0000106040-18-000010:notes:66]

[0000106040-18-000016:notes:78]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 30, 2018 and June 30, 2017, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-18-000016:notes:79]
|  | March 30, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,353 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,353 |  |
| Certificates of deposit | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents | 2,353 |  |  | 6 |  |  | — |  |  | 2,359 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate notes and bonds | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Asset-backed securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Municipal notes and bonds | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Equity securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Total short-term investments | 4 |  |  | 16 |  |  | — |  |  | 20 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Asset-backed securities | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Municipal notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total long-term investments | 2 |  |  | 91 |  |  | — |  |  | 93 |  |
| Foreign exchange contracts | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Interest rate swap contract | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total assets at fair value | $ | 2,359 |  |  | $ | 151 |  |  | $ | — |  |  | $ | 2,510 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |

[0000106040-18-000016:notes:80]
[same as prior period, unchanged from 0000106040-18-000010:notes:69]

[0000106040-18-000016:notes:81]
During the three and nine months ended March 30, 2018, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-18-000016:notes:82]
[same as prior period, unchanged from 0000106040-18-000010:notes:71]

[0000106040-18-000016:notes:83]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of March 30, 2018 and June 30, 2017. The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of March 30, 2018, by remaining contractual maturity, were as follows:

[0000106040-18-000016:notes:84]
The Company determined available-for-sale securities had no material other-than-temporary impairments in the three and nine months ended March 30, 2018 or March 31, 2017.

[0000106040-18-000016:notes:85]
[same as prior period, unchanged from 0000106040-18-000010:notes:74]

[0000106040-18-000016:notes:86]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2018 and the fourth quarter of 2017, respectively.

[0000106040-18-000016:notes:87]
|  | March 30, 2018 |  | June 30, 2017 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 31 |  |  | $ | 36 |  |  | $ | 30 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | — |  |  | 4,074 |  |  | 4,130 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,013 |  |  | 5,047 |  |  | — |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | — |  |  | 2,968 |  |  | 2,989 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,452 |  |  | 2,470 |  |  | — |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | — |  |  | 1,000 |  |  | 1,010 |  |
| 7.375% senior secured notes due 2023 | — |  |  | — |  |  | 1,835 |  |  | 2,062 |  |
| 1.50% convertible notes due 2024 | 924 |  |  | 1,192 |  |  | — |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | — |  |  | 3,244 |  |  | 3,956 |  |
| 4.750% senior unsecured notes due 2026 | 2,280 |  |  | 2,301 |  |  | — |  |  | — |  |
| Total | $ | 10,700 |  |  | $ | 11,046 |  |  | $ | 13,151 |  |  | $ | 14,181 |  |

[0000106040-18-000016:notes:88]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |

[0000106040-18-000016:notes:89]
[same as prior period, unchanged from 0000106040-18-000010:notes:77]

[0000106040-18-000016:notes:90]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company reports these investments under the cost method of accounting as it does not have a significant influence over the operations of these investees. These investments consist of debt and equity securities of privately-held companies that do not have a readily determinable fair value and are carried at historical cost. The Company assesses these securities for indications of other-than-temporary impairments.

[0000106040-18-000016:notes:91]
During the three and nine months ended March 30, 2018, the Company recorded impairment charges and losses related to the sale of these cost method investments of $9 million and $15 million, respectively, which were included in Other expense, net in the Condensed Consolidated Statements of Operations. During the three and nine months ended March 31, 2017, the Company recorded impairment charges and losses related to the sale of these cost method investments of $7 million and $11 million, respectively. As of March 30, 2018 and June 30, 2017, these investments aggregated $28 million and $91 million, respectively, and are reported under Other non-current assets in the Condensed Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-18-000016:notes:92]
Income Tax Expense (Benefit)

[0000106040-18-000016:notes:93]
[same as prior period, unchanged from 0000106040-18-000010:notes:80]

[0000106040-18-000016:notes:94]
For the three and nine months ended March 30, 2018, the Company has not finalized the accounting for the tax effects of the enactment of the 2017 Act. However, consistent with applicable SEC guidance, the Company has made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and has recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $79 million related to the re-measurement of deferred tax assets and liabilities for the nine months ended March 30, 2018. For other elements of tax expense noted below, or where the Company has not made an election, the Company has not been able to make a reasonable estimate and continues to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As the Company finalizes the accounting for the tax effects of the enactment of the 2017 Act during a one-year measurement period permitted by applicable SEC guidance, the Company expects to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000016:notes:95]
[same as prior period, unchanged from 0000106040-18-000010:notes:82]

[0000106040-18-000016:notes:96]
[same as prior period, unchanged from 0000106040-18-000010:notes:83]

[0000106040-18-000016:notes:97]
The provisional income tax expense of $9 million and income tax benefit of $79 million recorded for the three and nine months ended March 30, 2018, respectively, related to the re-measurements of the Company’s deferred tax balances are based on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. However, the Company is still analyzing certain aspects of the 2017 Act and refining the calculations, which could potentially affect the measurement of these balances or potentially give rise to new deferred tax amounts. The Company is also analyzing the impact of the 2017 Act to the existing valuation allowance assessments from both a federal and state tax perspective, which could potentially affect the realizability of the existing deferred tax assets. In calculating the provisional amount, the Company utilized an estimate of the expected reversals of certain tax assets and liabilities, which will be revised in future quarters during the one-year measurement period as additional information becomes available.

[0000106040-18-000016:notes:98]
[same as prior period, unchanged from 0000106040-18-000010:notes:85]

[0000106040-18-000016:notes:99]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. The tax is to be computed using the Company’s total foreign post-1986 earnings and profits that were previously deferred from U.S. income taxes. This tax is based on the amount of foreign earnings held in cash and other specified assets which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period. For the nine months ended March 30, 2018, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.66 billion for foreign subsidiaries and $132 million of this amount is classified as a current tax liability. The calculation of the mandatory deemed repatriation tax liability is provisional and based upon preliminary estimates of post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on a provisional amount of foreign earnings held in cash and other specified assets, which the Company expects will require additional clarifying guidance from U.S. Treasury. As such, the provisional amount may change during the one-year measurement period when the Company finalizes the calculation of post-1986 foreign earnings and profits and the amount of foreign earnings held in cash or other specified assets. The Company made no adjustment to this provisional amount in the three months ended March 30, 2018.

[0000106040-18-000016:notes:100]
Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., the Company continues to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires the Company to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the provisional tax expense for the three and nine months ended March 30, 2018 is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, the Company’s plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings.  In the event the Company determines not to continue to assert the permanent reinvestment of part or all of foreign undistributed earnings, such a determination could result in the accrual and payment of additional foreign, state and local taxes.

[0000106040-18-000016:notes:101]
[same as prior period, unchanged from 0000106040-18-000010:notes:88]

[0000106040-18-000016:notes:102]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision is effective for tax years beginning on or after January 1, 2018, which for the Company would be the fiscal year beginning on June 30, 2018 (fiscal year 2019). The Company has not progressed sufficiently in the analysis of this provision to make an election either to account for the effects of this provision either as a component of future income tax expense in the period the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities have been established for timing differences between foreign U.S. GAAP income and foreign earnings and profits that would be expected to reverse under the new minimum tax in future years. Additionally, the Company has not yet completed the calculation of post-1986 foreign earnings and profits for the mandatory repatriation tax, which would be the starting point for the measurement of deferred tax assets and liabilities in order to record any provisional amounts.

[0000106040-18-000016:notes:103]
[same as prior period, unchanged from 0000106040-18-000010:notes:90]

[0000106040-18-000016:notes:104]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Income (loss) before taxes | $ | (128 | ) |  | $ | 304 |  |  | $ | 1,356 |  |  | $ | 354 |  |
| Income tax expense (benefit) | $ | (189 | ) |  | $ | 56 |  |  | $ | 1,437 |  |  | $ | 237 |  |
| Effective tax rate | 148 | % |  | 18 | % |  | 106 | % |  | 67 | % |

[0000106040-18-000016:notes:105]
Under the 2017 Act, the reduction of the U.S. federal corporate tax rate from 35% to 21% is effective January 1, 2018, requiring companies to use a blended rate for their fiscal 2018 tax year by applying a pro-rated percentage of the number of days before and after the January 1, 2018 effective date. This results in the use of an estimated annual effective tax rate of approximately 28% for the Company’s U.S. federal corporate tax rate for fiscal year 2018. The U.S. federal corporate tax rate was reduced from 35% to the blended tax rate of 28% for fiscal year 2018. For fiscal year 2019 and beyond, the Company will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000016:notes:106]
The primary drivers for the difference between the effective tax rate for the three months ended March 30, 2018 and the U.S. Federal statutory rate of 28% include discrete effects consisting of an income tax benefit of $211 million from deductible make-whole premiums and the write-off of unamortized issuance costs from the debt financing transactions. The primary drivers for the difference between the effective tax rate for the nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act and deductible make-whole premiums and the write-off of unamortized issuance costs from the debt financing transactions. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% are current year tax credits, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires the Company to now recognize $46 million and $73 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of its income tax expense for the three and nine months ended March 30, 2018, respectively. The windfall tax benefits for the three and nine months ended March 31, 2017 were recorded within shareholders’ equity.

[0000106040-18-000016:notes:107]
The primary drivers for the difference between the effective tax rate for the nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% include discrete effects consisting of income tax expense from the integration of SanDisk Corporation (“SanDisk”) of $91 million and a valuation allowance on acquired tax attributes of $111 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $98 million. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% are these discrete items, the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-18-000016:notes:108]
During the nine months ended March 30, 2018, the Company recorded a net decrease of $17 million in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of March 30, 2018, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $505 million. Accrued interest and penalties related to unrecognized tax benefits as of March 30, 2018 was approximately $105 million.

[0000106040-18-000016:notes:109]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income, which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. Meetings with the IRS Appeals Office began in March 2017. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-18-000016:notes:110]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 30, 2018, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-18-000016:notes:111]
Legal Proceedings

[0000106040-18-000016:notes:112]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-18-000016:notes:113]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-18-000016:notes:114]
Intellectual Property Litigation

[0000106040-18-000016:notes:115]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000016:notes:116]
Antitrust

[0000106040-18-000016:notes:117]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision. In April 2018, Samsung voluntarily dismissed its case against Panasonic and SD-3C with prejudice.

[0000106040-18-000016:notes:118]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000016:notes:119]
Securities

[0000106040-18-000016:notes:120]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000016:notes:121]
Copyright

[0000106040-18-000016:notes:122]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000016:notes:123]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000016:notes:124]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $189 million, inclusive of amounts accrued, if it does not prevail in this matter.

[0000106040-18-000016:notes:125]
Other Matters

[0000106040-18-000016:notes:126]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-18-000016:notes:127]
Recently Adopted Accounting Pronouncements

[0000106040-18-000016:notes:128]
In August 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-15, “Statement of Cash Flows (Topic 230), Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). ASU 2016-15 provides amendments that address eight specific cash flow classification issues for which there exists diversity in practice: Debt prepayment or debt extinguishment costs; settlement of zero-coupon debt instruments or other debt instruments with coupon interest rates that are insignificant in relation to the effective interest rate of the borrowing; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies, including bank-owned life insurance policies; distributions received from equity method investees; beneficial interests in securitization transactions; and separately identifiable cash flows and application of the predominance principle. The Company adopted ASU 2016-15 in the second quarter of 2018 on a modified retrospective basis as required by the standard. The Company’s adoption of ASU 2016-15 did not have a material effect on the Company’s historical Consolidated Financial Statements.

[0000106040-18-000016:notes:129]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). ASU 2016-09 simplifies several aspects of the accounting for stock-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The Company adopted this standard in the first quarter of 2018 using the modified retrospective approach. This adoption resulted in a one-time net increase to beginning retained earnings of $70 million, consisting of a $58 million cumulative adjustment for the previously unrecognized windfall tax benefits related to previous vesting and exercises of stock-based awards, and a $19 million cumulative adjustment related to the change in accounting policy for estimated forfeitures and share cancellations, partially offset by a decrease of $7 million for the related tax impacts of change in forfeiture policy. In addition, upon adoption of the new standard in the Company’s first quarter of 2018, the Company began prospectively reflecting the tax deficiencies and benefits as an operating activity, rather than as a financing activity under the previous standard, in the Company’s Consolidated Statements of Cash Flows. For the three and nine months ended March 30, 2018, the Company recognized excess tax benefits of $46 million and $73 million, respectively, as a component of its income tax expense (benefit).

[0000106040-18-000016:notes:130]
In March 2016, the FASB issued ASU No. 2016-07, “Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting” (“ASU 2016-07”). ASU 2016-07 eliminates the requirement to apply the equity method of accounting retrospectively when a reporting entity obtains significant influence over a previously held investment. The Company adopted this standard in the second quarter of 2018. The Company’s adoption of ASU 2016-07 did not have a material impact on its Consolidated Financial Statements.

[0000106040-18-000016:notes:131]
In July 2015, the FASB issued ASU No. 2015‑11, “Inventory (Topic 330) - Simplifying the Measurement of Inventory” (“ASU 2015‑11”), which dictates that an entity should measure inventory within the scope of this update at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this standard in the first quarter of 2018. The Company’s adoption of ASU 2015‑11 did not have a material impact on its Consolidated Financial Statements.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-18-000016:notes:132]
[same as prior period, unchanged from 0000106040-18-000010:notes:131]

[0000106040-18-000016:notes:133]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Non-current income taxes payable | $ | 1,425 |  |  | $ | — |  |
| Other non-current liabilities | 944 |  |  | 1,180 |  |
| Total other non-current liabilities | $ | 2,369 |  |  | $ | 1,180 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-18-000016:notes:134]
[same as prior period, unchanged from 0000106040-18-000010:notes:133]

[0000106040-18-000016:notes:135]
[same as prior period, unchanged from 0000106040-18-000010:notes:134]

[0000106040-18-000016:notes:136]
[same as prior period, unchanged from 0000106040-18-000010:notes:135]

[0000106040-18-000016:notes:137]
[same as prior period, unchanged from 0000106040-18-000010:notes:136]

[0000106040-18-000016:notes:138]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 57 |  |  | 59 |  |
| Net amount recognized | $ | 58 |  |  | $ | 60 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-18-000016:notes:139]
[same as prior period, unchanged from 0000106040-18-000010:notes:138]

[0000106040-18-000016:notes:140]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,927 |  |  | $ | 1,855 |  |
| Machinery and equipment | 7,102 |  |  | 6,815 |  |
| Computer equipment and software | 432 |  |  | 404 |  |
| Furniture and fixtures | 49 |  |  | 49 |  |
| Leasehold improvements | 250 |  |  | 259 |  |
| Construction-in-process | 196 |  |  | 144 |  |
| Property, plant and equipment, gross | 9,956 |  |  | 9,526 |  |
| Accumulated depreciation | (6,945 | ) |  | (6,493 | ) |
| Property, plant, and equipment, net | $ | 3,011 |  |  | $ | 3,033 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-18-000016:notes:141]
[same as prior period, unchanged from 0000106040-18-000010:notes:140]

[0000106040-18-000016:notes:142]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
| AOCI Component |  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on designated hedging activities: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 8 |  |  | $ | 9 |  |  | $ | 9 |  |  | $ | 42 |  |  | Cost of revenue |
| Foreign exchange contracts |  | 1 |  |  | (1 | ) |  | 1 |  |  | 1 |  |  | Research and development |
| Foreign exchange contracts |  | — |  |  | (3) |  |  | — |  |  | 4 |  |  | Selling, general and administrative |
| Unrealized holding gain on designated hedging activities |  | 9 |  |  | 5 |  |  | 10 |  |  | 47 |  |  |  |
| Total reclassifications for the period |  | $ | 9 |  |  | $ | 5 |  |  | $ | 10 |  |  | $ | 47 |  |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-18-000016:notes:143]
[same as prior period, unchanged from 0000106040-18-000010:notes:142]

[0000106040-18-000016:notes:144]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Available for Sale Securities |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 30, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | 2 |  |  | $ | (3 | ) |  | $ | (58 | ) |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | 78 |  |  | (4 | ) |  | 45 |  |  | 120 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | — |  |  | (10 | ) |  | (10 | ) |
| Income tax expense related to items of other comprehensive income | — |  |  | (2 | ) |  | — |  |  | (4 | ) |  | (6 | ) |
| Net current-period other comprehensive income | 1 |  |  | 76 |  |  | (4 | ) |  | 31 |  |  | 104 |  |
| Balance at March 30, 2018 | $ | (17 | ) |  | $ | 37 |  |  | $ | (2 | ) |  | $ | 28 |  |  | $ | 46 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-18-000016:notes:145]
| Condensed Consolidating Balance Sheet |
| As of March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 118 |  |  | $ | 729 |  |  | $ | 4,116 |  |  | $ | — |  |  | $ | 4,963 |  |
| Short-term investments | — |  |  | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Accounts receivable, net | — |  |  | 1,232 |  |  | 779 |  |  | — |  |  | 2,011 |  |
| Intercompany receivables | 1,869 |  |  | 3,488 |  |  | 2,209 |  |  | (7,566 | ) |  | — |  |
| Inventories | — |  |  | 1,055 |  |  | 1,877 |  |  | (262 | ) |  | 2,670 |  |
| Other current assets | 15 |  |  | 185 |  |  | 263 |  |  | 37 |  |  | 500 |  |
| Total current assets | 2,002 |  |  | 6,689 |  |  | 9,264 |  |  | (7,791 | ) |  | 10,164 |  |
| Property, plant and equipment, net | — |  |  | 1,078 |  |  | 1,933 |  |  | — |  |  | 3,011 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,160 |  |  | — |  |  | 2,160 |  |
| Goodwill | — |  |  | 387 |  |  | 9,692 |  |  | — |  |  | 10,079 |  |
| Other intangible assets, net | — |  |  | 40 |  |  | 2,916 |  |  | — |  |  | 2,956 |  |
| Investments in consolidated subsidiaries | 19,980 |  |  | 19,439 |  |  | — |  |  | (39,419 | ) |  | — |  |
| Loans due from consolidated affiliates | 1,406 |  |  | 15 |  |  | — |  |  | (1,421 | ) |  | — |  |
| Other non-current assets | 172 |  |  | 613 |  |  | 444 |  |  | (595 | ) |  | 634 |  |
| Total assets | $ | 23,560 |  |  | $ | 28,261 |  |  | $ | 26,409 |  |  | $ | (49,226 | ) |  | $ | 29,004 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 255 |  |  | $ | 1,879 |  |  | $ | — |  |  | $ | 2,134 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 282 |  |  | — |  |  | 282 |  |
| Intercompany payables | 916 |  |  | 4,277 |  |  | 2,373 |  |  | (7,566 | ) |  | — |  |
| Accrued expenses | 175 |  |  | 434 |  |  | 369 |  |  | 37 |  |  | 1,015 |  |
| Accrued compensation | — |  |  | 309 |  |  | 200 |  |  | — |  |  | 509 |  |
| Accrued warranty | — |  |  | — |  |  | 195 |  |  | — |  |  | 195 |  |
| Current portion of long-term debt | 124 |  |  | — |  |  | — |  |  | — |  |  | 124 |  |
| Total current liabilities | 1,215 |  |  | 5,275 |  |  | 5,298 |  |  | (7,529 | ) |  | 4,259 |  |
| Long-term debt | 11,045 |  |  | — |  |  | 31 |  |  | — |  |  | 11,076 |  |
| Loans due to consolidated affiliates | — |  |  | 342 |  |  | 1,079 |  |  | (1,421 | ) |  | — |  |
| Other liabilities | — |  |  | 2,458 |  |  | 506 |  |  | (595 | ) |  | 2,369 |  |
| Total liabilities | 12,260 |  |  | 8,075 |  |  | 6,914 |  |  | (9,545 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,300 |  |  | 20,186 |  |  | 19,495 |  |  | (39,681 | ) |  | 11,300 |  |
| Total liabilities and shareholders’ equity | $ | 23,560 |  |  | $ | 28,261 |  |  | $ | 26,409 |  |  | $ | (49,226 | ) |  | $ | 29,004 |  |

[0000106040-18-000016:notes:146]
[same as prior period, unchanged from 0000106040-18-000010:notes:145]


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-18-000016:notes:147]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (130 | ) |  | $ | 405 |  |  | $ | 3,284 |  |  | $ | (217 | ) |  | $ | 3,342 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (162 | ) |  | (481 | ) |  | — |  |  | (643 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | (6 | ) |  | — |  |  | (99 | ) |
| Purchases of investments | — |  |  | (11 | ) |  | (55 | ) |  | — |  |  | (66 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (1,015 | ) |  | — |  |  | (1,015 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 308 |  |  | — |  |  | 308 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | 31 |  |  | — |  |  | 30 |  |
| Intercompany loan from consolidated affiliates | 3,295 |  |  | — |  |  | — |  |  | (3,295 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (47 | ) |  | 47 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 3,248 |  |  | (220 | ) |  | (1,139 | ) |  | (3,295 | ) |  | (1,406 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 146 |  |  | — |  |  | — |  |  | — |  |  | 146 |  |
| Taxes paid on vested stock awards under employee stock plans | (164 | ) |  | — |  |  | — |  |  | — |  |  | (164 | ) |
| Repurchases of common stock | (155 | ) |  | — |  |  | — |  |  | — |  |  | (155 | ) |
| Dividends paid to shareholders | (443 | ) |  | — |  |  | — |  |  | — |  |  | (443 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt and premiums | (14,581 | ) |  | — |  |  | — |  |  | — |  |  | (14,581 | ) |
| Proceeds from debt | 11,384 |  |  | — |  |  | — |  |  | — |  |  | 11,384 |  |
| Proceeds from revolving credit facility | 500 |  |  | — |  |  | — |  |  | — |  |  | 500 |  |
| Debt issuance costs | (52 | ) |  | — |  |  | — |  |  | — |  |  | (52 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (205 | ) |  | (3,090 | ) |  | 3,295 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 319 |  |  | (463 | ) |  | (73 | ) |  | 217 |  |  | — |  |
| Net cash used in financing activities | (3,018 | ) |  | (668 | ) |  | (3,163 | ) |  | 3,512 |  |  | (3,337 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Net increase (decrease) in cash and cash equivalents | 100 |  |  | (483 | ) |  | (1,008 | ) |  | — |  |  | (1,391 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 118 |  |  | $ | 729 |  |  | $ | 4,116 |  |  | $ | — |  |  | $ | 4,963 |  |

[0000106040-18-000016:notes:148]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (443 | ) |  | $ | 617 |  |  | $ | 2,177 |  |  | $ | 147 |  |  | $ | 2,498 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (185 | ) |  | (268 | ) |  | — |  |  | (453 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Purchases of investments | — |  |  | — |  |  | (274 | ) |  | — |  |  | (274 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 75 |  |  | — |  |  | 75 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 430 |  |  | — |  |  | 430 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (480 | ) |  | — |  |  | (480 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 276 |  |  | — |  |  | 276 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Intercompany loans from (to) consolidated affiliates | 995 |  |  | (258 | ) |  | — |  |  | (737 | ) |  | — |  |
| Advances from (to) consolidated affiliates | 244 |  |  | (236 | ) |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,239 |  |  | (679 | ) |  | (261 | ) |  | (745 | ) |  | (446 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 123 |  |  | — |  |  | — |  |  | — |  |  | 123 |  |
| Taxes paid on vested stock awards under employee stock plans | (111 | ) |  | — |  |  | — |  |  | — |  |  | (111 | ) |
| Excess tax benefits from employee stock plans | 90 |  |  | — |  |  | — |  |  | — |  |  | 90 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Dividends paid to shareholders | (428 | ) |  | — |  |  | — |  |  | — |  |  | (428 | ) |
| Repayment of debt and premiums | (8,692 | ) |  | (2,995 | ) |  | (492 | ) |  | — |  |  | (12,179 | ) |
| Proceeds from revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Proceeds from debt | 7,908 |  |  | — |  |  | — |  |  | — |  |  | 7,908 |  |
| Debt issuance costs | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Intercompany loan to consolidated affiliates | 298 |  |  | (5,966 | ) |  | 4,931 |  |  | 737 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 296 |  |  | 8,673 |  |  | (8,830 | ) |  | (139 | ) |  | — |  |
| Net cash used in financing activities | (526 | ) |  | (288 | ) |  | (4,330 | ) |  | 598 |  |  | (4,546 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Net increase (decrease) in cash and cash equivalents | 270 |  |  | (350 | ) |  | (2,419 | ) |  | — |  |  | (2,499 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of period | $ | 270 |  |  | $ | 856 |  |  | $ | 4,526 |  |  | $ | — |  |  | $ | 5,652 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-18-000016:notes:149]
[same as prior period, unchanged from 0000106040-18-000010:notes:148]

[0000106040-18-000016:notes:150]
The 2026 Senior Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-18-000016:notes:151]
| Condensed Consolidating Statement of Operations |
| For the three months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,685 |  |  | $ | 4,924 |  |  | $ | (3,596 | ) |  | $ | 5,013 |  |
| Cost of revenue | — |  |  | 3,209 |  |  | 3,499 |  |  | (3,622 | ) |  | 3,086 |  |
| Gross profit | — |  |  | 476 |  |  | 1,425 |  |  | 26 |  |  | 1,927 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 361 |  |  | 241 |  |  | — |  |  | 602 |  |
| Selling, general and administrative | 3 |  |  | 264 |  |  | 109 |  |  | — |  |  | 376 |  |
| Intercompany operating expense (income) | (12 | ) |  | (391 | ) |  | 403 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 9 |  |  | 25 |  |  | — |  |  | 35 |  |
| Total operating expenses | (8 | ) |  | 243 |  |  | 778 |  |  | — |  |  | 1,013 |  |
| Operating income | 8 |  |  | 233 |  |  | 647 |  |  | 26 |  |  | 914 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 42 |  |  | 2 |  |  | 12 |  |  | (40 | ) |  | 16 |  |
| Interest expense | (160 | ) |  | (5 | ) |  | (35 | ) |  | 40 |  |  | (160 | ) |
| Other expense, net | (894 | ) |  | (7 | ) |  | (7 | ) |  | 10 |  |  | (898 | ) |
| Total interest and other expense, net | (1,012 | ) |  | (10 | ) |  | (30 | ) |  | 10 |  |  | (1,042 | ) |
| Income (loss) before taxes | (1,004 | ) |  | 223 |  |  | 617 |  |  | 36 |  |  | (128 | ) |
| Income tax expense (benefit) | (228 | ) |  | 22 |  |  | 17 |  |  | — |  |  | (189 | ) |
| Equity in earnings from subsidiaries | 837 |  |  | 562 |  |  | — |  |  | (1,399 | ) |  | — |  |
| Net income | $ | 61 |  |  | $ | 763 |  |  | $ | 600 |  |  | $ | (1,363 | ) |  | $ | 61 |  |

[0000106040-18-000016:notes:152]
| Condensed Consolidating Statement of Operations |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 11,159 |  |  | $ | 15,178 |  |  | $ | (10,807 | ) |  | $ | 15,530 |  |
| Cost of revenue | — |  |  | 9,665 |  |  | 10,849 |  |  | (10,837 | ) |  | 9,677 |  |
| Gross profit | — |  |  | 1,494 |  |  | 4,329 |  |  | 30 |  |  | 5,853 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,142 |  |  | 681 |  |  | — |  |  | 1,823 |  |
| Selling, general and administrative | 6 |  |  | 798 |  |  | 317 |  |  | — |  |  | 1,121 |  |
| Intercompany operating expense (income) | (12 | ) |  | (1,221 | ) |  | 1,233 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 30 |  |  | 104 |  |  | — |  |  | 135 |  |
| Total operating expenses | (5 | ) |  | 749 |  |  | 2,335 |  |  | — |  |  | 3,079 |  |
| Operating income | 5 |  |  | 745 |  |  | 1,994 |  |  | 30 |  |  | 2,774 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 189 |  |  | 6 |  |  | 38 |  |  | (187 | ) |  | 46 |  |
| Interest expense | (561 | ) |  | (15 | ) |  | (173 | ) |  | 187 |  |  | (562 | ) |
| Other income (expense), net | (902 | ) |  | — |  |  | (10 | ) |  | 10 |  |  | (902 | ) |
| Total interest and other expense, net | (1,274 | ) |  | (9 | ) |  | (145 | ) |  | 10 |  |  | (1,418 | ) |
| Income (loss) before taxes | (1,269 | ) |  | 736 |  |  | 1,849 |  |  | 40 |  |  | 1,356 |  |
| Income tax expense (benefit) | (319 | ) |  | 1,677 |  |  | 79 |  |  | — |  |  | 1,437 |  |
| Equity in earnings from subsidiaries | 869 |  |  | 1,747 |  |  | — |  |  | (2,616 | ) |  | — |  |
| Net income (loss) | $ | (81 | ) |  | $ | 806 |  |  | $ | 1,770 |  |  | $ | (2,576 | ) |  | $ | (81 | ) |

[0000106040-18-000016:notes:153]
| Condensed Consolidating Statement of Operations |
| For the three months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,406 |  |  | $ | 4,333 |  |  | $ | (3,090 | ) |  | $ | 4,649 |  |
| Cost of revenue | — |  |  | 2,791 |  |  | 3,403 |  |  | (3,068 | ) |  | 3,126 |  |
| Gross profit | — |  |  | 615 |  |  | 930 |  |  | (22 | ) |  | 1,523 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 413 |  |  | 200 |  |  | — |  |  | 613 |  |
| Selling, general and administrative | 1 |  |  | 240 |  |  | 105 |  |  | — |  |  | 346 |  |
| Intercompany operating expense (income) | — |  |  | (282 | ) |  | 282 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 30 |  |  | 9 |  |  | — |  |  | 39 |  |
| Total operating expenses | 1 |  |  | 401 |  |  | 596 |  |  | — |  |  | 998 |  |
| Operating income (loss) | (1 | ) |  | 214 |  |  | 334 |  |  | (22 | ) |  | 525 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 88 |  |  | 8 |  |  | 6 |  |  | (95 | ) |  | 7 |  |
| Interest expense | (211 | ) |  | — |  |  | (89 | ) |  | 95 |  |  | (205 | ) |
| Other expense, net | (9 | ) |  | (6 | ) |  | (8 | ) |  | — |  |  | (23 | ) |
| Total interest and other income (expense), net | (132 | ) |  | 2 |  |  | (91 | ) |  | — |  |  | (221 | ) |
| Income (loss) before taxes | (133 | ) |  | 216 |  |  | 243 |  |  | (22 | ) |  | 304 |  |
| Income tax expense (benefit) | (26 | ) |  | 56 |  |  | 26 |  |  | — |  |  | 56 |  |
| Equity in earnings from subsidiaries | 355 |  |  | 229 |  |  | — |  |  | (584 | ) |  | — |  |
| Net income | $ | 248 |  |  | $ | 389 |  |  | $ | 217 |  |  | $ | (606 | ) |  | $ | 248 |  |

[0000106040-18-000016:notes:154]
| Condensed Consolidating Statement of Operations |
| For the nine months ended March 31, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 10,890 |  |  | $ | 12,871 |  |  | $ | (9,510 | ) |  | $ | 14,251 |  |
| Cost of revenue | — |  |  | 8,941 |  |  | 10,451 |  |  | (9,532 | ) |  | 9,860 |  |
| Gross profit | — |  |  | 1,949 |  |  | 2,420 |  |  | 22 |  |  | 4,391 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,226 |  |  | 611 |  |  | — |  |  | 1,837 |  |
| Selling, general and administrative | 5 |  |  | 766 |  |  | 329 |  |  | — |  |  | 1,100 |  |
| Intercompany operating expense (income) | — |  |  | (851 | ) |  | 851 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 88 |  |  | 64 |  |  | — |  |  | 152 |  |
| Total operating expenses | 5 |  |  | 1,229 |  |  | 1,855 |  |  | — |  |  | 3,089 |  |
| Operating income (loss) | (5 | ) |  | 720 |  |  | 565 |  |  | 22 |  |  | 1,302 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 268 |  |  | 9 |  |  | 15 |  |  | (275 | ) |  | 17 |  |
| Interest expense | (642 | ) |  | (5 | ) |  | (274 | ) |  | 275 |  |  | (646 | ) |
| Other expense, net | (283 | ) |  | (10 | ) |  | (26 | ) |  | — |  |  | (319 | ) |
| Total interest and other expense, net | (657 | ) |  | (6 | ) |  | (285 | ) |  | — |  |  | (948 | ) |
| Income (loss) before taxes | (662 | ) |  | 714 |  |  | 280 |  |  | 22 |  |  | 354 |  |
| Income tax expense (benefit) | (207 | ) |  | 177 |  |  | 267 |  |  | — |  |  | 237 |  |
| Equity in earnings from subsidiaries | 572 |  |  | 21 |  |  | — |  |  | (593 | ) |  | — |  |
| Net income | $ | 117 |  |  | $ | 558 |  |  | $ | 13 |  |  | $ | (571 | ) |  | $ | 117 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-18-000016:notes:155]
[same as prior period, unchanged from 0000106040-18-000010:notes:154]

[0000106040-18-000016:notes:156]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,816 |  |  | $ | 5,160 |  |
| In-process research and development | 80 |  |  | 696 |  |
| Accumulated amortization | (2,940 | ) |  | (2,033 | ) |
| Intangible assets, net | $ | 2,956 |  |  | $ | 3,823 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-18-000016:notes:157]
[same as prior period, unchanged from 0000106040-18-000010:notes:156]

[0000106040-18-000016:notes:158]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 30, 2017 | $ | 10,014 |  |
| Goodwill recorded in connection with acquisitions | 61 |  |
| Foreign currency translation adjustment | 4 |  |
| Balance at March 30, 2018 | $ | 10,079 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-18-000016:notes:159]
[same as prior period, unchanged from 0000106040-18-000010:notes:158]

[0000106040-18-000016:notes:160]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 855 |  |  | $ | 646 |  |
| Work-in-process | 764 |  |  | 632 |  |
| Finished goods | 1,051 |  |  | 1,063 |  |
| Total inventories | $ | 2,670 |  |  | $ | 2,341 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-18-000016:notes:161]
[same as prior period, unchanged from 0000106040-18-000010:notes:160]

[0000106040-18-000016:notes:162]
[same as prior period, unchanged from 0000106040-18-000010:notes:161]

[0000106040-18-000016:notes:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 304 |  |  | $ | 313 |  |  | $ | 311 |  |  | $ | 279 |  |
| Charges to operations | 43 |  |  | 43 |  |  | 133 |  |  | 134 |  |
| Utilization | (37 | ) |  | (36 | ) |  | (118 | ) |  | (116 | ) |
| Changes in estimate related to pre-existing warranties | (5 | ) |  | 3 |  |  | (21 | ) |  | 26 |  |
| Warranty accrual, end of period | $ | 305 |  |  | $ | 323 |  |  | $ | 305 |  |  | $ | 323 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-18-000016:notes:164]
The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 30, 2018:

[0000106040-18-000016:notes:165]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 11 |  |  | $ | 2 |  |  | $ | 13 |  |
| Charges | 64 |  |  | 23 |  |  | 87 |  |
| Cash payments | (63 | ) |  | (16 | ) |  | (79 | ) |
| Accrual balance at March 30, 2018 | $ | 12 |  |  | $ | 9 |  |  | $ | 21 |  |

[0000106040-18-000016:notes:166]
[same as prior period, unchanged from 0000106040-18-000010:notes:165]

[0000106040-18-000016:notes:167]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 18 |  |  | $ | 5 |  |  | $ | 23 |  |
| Charges | 24 |  |  | 7 |  |  | 31 |  |
| Cash payments | (24 | ) |  | (6 | ) |  | (30 | ) |
| Accrual balance at March 30, 2018 | $ | 18 |  |  | $ | 6 |  |  | $ | 24 |  |

[0000106040-18-000016:notes:168]
[same as prior period, unchanged from 0000106040-18-000010:notes:167]

[0000106040-18-000016:notes:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 10 |  |  | $ | 6 |  |  | $ | 87 |  |  | $ | 52 |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 3 |  |  | — |  |  | 9 |  |
| Business Realignment | 8 |  |  | 26 |  |  | 31 |  |  | 69 |  |
| Total employee termination and other charges | 18 |  |  | 35 |  |  | 118 |  |  | 130 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | — |  |  |  |  |  | (1 | ) |
| Business Realignment | 1 |  |  | 4 |  |  | 1 |  |  | 10 |  |
| Total stock-based compensation accelerations and adjustments | 1 |  |  | 4 |  |  | 1 |  |  | 9 |  |
| Asset impairment: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | 16 |  |  | — |  |  | 16 |  |  | — |  |
| Closure of Foreign Manufacturing Facility | — |  |  | — |  |  | — |  |  | 13 |  |
| Total asset impairment | 16 |  |  | — |  |  | 16 |  |  | 13 |  |
| Total employee termination and other charges, and stock-based compensation accelerations and adjustments | $ | 35 |  |  | $ | 39 |  |  | $ | 135 |  |  | $ | 152 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-18-000016:notes:170]
[same as prior period, unchanged from 0000106040-18-000010:notes:169]

[0000106040-18-000016:notes:171]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 30, 2017 | 7.4 |  |  | $ | 58.14 |  |  |  |  |  |
| Exercised | (2.0 | ) |  | 44.74 |  |  |  |  | $ | 91 |  |
| Canceled or expired | (0.3 | ) |  | 61.95 |  |  |  |  |  |
| Options outstanding at March 30, 2018 | 5.1 |  |  | $ | 63.29 |  |  | 4.0 |  | $ | 158 |  |
| Exercisable at March 30, 2018 | 2.9 |  |  | $ | 69.85 |  |  | 3.3 |  | $ | 74 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-18-000016:notes:172]
[same as prior period, unchanged from 0000106040-18-000010:notes:171]

[0000106040-18-000016:notes:173]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | $ | 45.01 |  |  |  |
| Granted | 5.0 |  |  | 79.10 |  |  |  |
| Vested | (6.0 | ) |  | 44.99 |  |  | $ | 529 |  |
| Forfeited | (0.9 | ) |  | 48.72 |  |  |  |
| RSUs and PSUs outstanding at March 30, 2018 | 11.8 |  |  | $ | 57.62 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-18-000016:notes:174]
[same as prior period, unchanged from 0000106040-18-000010:notes:173]

[0000106040-18-000016:notes:175]
[same as prior period, unchanged from 0000106040-18-000010:notes:174]

[0000106040-18-000016:notes:176]
Compensation cost related to unvested stock options, restricted stock unit awards (“RSU”), performance-based restricted stock unit awards (“PSU”) and the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of March 30, 2018.

[0000106040-18-000016:notes:177]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 32 |  |  | 2.0 |
| RSUs and PSUs (1) | 528 |  |  | 2.2 |
| ESPP | 15 |  |  | 0.5 |
| Total unamortized compensation cost | $ | 575 |  |  |  |

[0000106040-18-000016:notes:178]
[same as prior period, unchanged from 0000106040-18-000010:notes:177]

[0000106040-18-000016:notes:179]
[same as prior period, unchanged from 0000106040-18-000010:notes:178]

[0000106040-18-000016:notes:180]
[same as prior period, unchanged from 0000106040-18-000010:notes:179]

[0000106040-18-000016:notes:181]
RSUs and PSUs

[0000106040-18-000016:notes:182]
[same as prior period, unchanged from 0000106040-18-000010:notes:181]

[0000106040-18-000016:notes:183]
[same as prior period, unchanged from 0000106040-18-000010:notes:182]

[0000106040-18-000016:notes:184]
The Company’s Board of Directors (the “Board”) has authorized $5.00 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company had made repurchases aggregating $2.88 billion prior to fiscal 2018. The Company repurchased 1.78 million shares for a total cost of $155 million during the three and nine months ended March 30, 2018. The remaining amount available to be purchased under the Company’s stock repurchase program as of March 30, 2018 was $1.97 billion.

[0000106040-18-000016:notes:185]
[same as prior period, unchanged from 0000106040-18-000010:notes:184]

[0000106040-18-000016:notes:186]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the nine months ended March 30, 2018, the Company declared aggregate cash dividends of $1.50 per share on its outstanding common stock totaling $446 million, of which $296 million was paid during the period and $150 million was paid on April 16, 2018.

[0000106040-18-000016:notes:187]
On May 2, 2018, the Board declared a cash dividend of $0.50 per share to shareholders of record as of June 29, 2018, which will be paid on July 16, 2018. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-18-000016:notes:188]
[same as prior period, unchanged from 0000106040-18-000010:notes:191]

[0000106040-18-000016:notes:189]
[same as prior period, unchanged from 0000106040-18-000010:notes:192]

[0000106040-18-000016:notes:190]
The aggregate purchase price of acquisitions during the nine months ended March 30, 2018 was $99 million in cash, with net assets acquired primarily consisting of developed technology and other intangible assets, of which $61 million was allocated to goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings to its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. Goodwill is expected to be deductible for tax purposes because the acquisitions were structured as asset acquisitions but accounted for as business combinations. Concurrent with these acquisitions, the Company received $36 million in proceeds on previously outstanding notes receivable due from these acquired entities.

[0000106040-18-000016:notes:191]
During the nine months ended March 30, 2018, the expenses incurred by the Company related to these acquisitions were immaterial and are primarily included within Selling, General and Administrative expenses in the Condensed Consolidated Statements of Operations. Revenues and earnings related to these acquisitions was not material.

[0000106040-18-000016:notes:192]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During the nine months ended March 30, 2018, two IPR&D projects reached technological feasibility totaling $616 million and commenced amortization over an estimated useful life of 4 years.

[0000106040-18-000016:notes:193]
The long-term portion of the warranty accrual classified in Other liabilities was $110 million and $125 million as of March 30, 2018 and June 30, 2017, respectively.

[0000106040-18-000016:notes:194]
[same as prior period, unchanged from 0000106040-18-000010:notes:197]

[0000106040-18-000016:notes:195]
Other comprehensive income (loss) (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-18-000016:notes:196]
[same as prior period, unchanged from 0000106040-18-000010:notes:200]

[0000106040-18-000016:notes:197]
[same as prior period, unchanged from 0000106040-18-000010:notes:201]

[0000106040-18-000016:notes:198]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 as presented above, the Company recognized $9 million and $37 million of accelerated depreciation on facility assets in cost of revenue during the nine months ended March 30, 2018 and March 31, 2017, respectively.

[0000106040-18-000016:notes:199]
[same as prior period, unchanged from 0000106040-18-000010:notes:203]

[0000106040-18-000016:notes:200]
[same as prior period, unchanged from 0000106040-18-000010:notes:204]


## wdc:OrganizationandBasisofPresentationTextBlock

[0000106040-18-000016:notes:201]
[same as prior period, unchanged from 0000106040-18-000010:notes:205]

[0000106040-18-000016:notes:202]
[same as prior period, unchanged from 0000106040-18-000010:notes:206]

[0000106040-18-000016:notes:203]
[same as prior period, unchanged from 0000106040-18-000010:notes:207]

[0000106040-18-000016:notes:204]
[same as prior period, unchanged from 0000106040-18-000010:notes:208]

[0000106040-18-000016:notes:205]
[same as prior period, unchanged from 0000106040-18-000010:notes:209]

[0000106040-18-000016:notes:206]
[same as prior period, unchanged from 0000106040-18-000010:notes:210]

[0000106040-18-000016:notes:207]
[same as prior period, unchanged from 0000106040-18-000010:notes:211]
