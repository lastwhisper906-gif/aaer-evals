# WDC MD&A — 0000106040-18-000016


## mdna

[0000106040-18-000016:mdna:1]
[same as prior period, unchanged from 0000106040-18-000010:mdna:1]

[0000106040-18-000016:mdna:2]
[same as prior period, unchanged from 0000106040-18-000010:mdna:2]

[0000106040-18-000016:mdna:3]
[same as prior period, unchanged from 0000106040-18-000010:mdna:3]

[0000106040-18-000016:mdna:4]
[same as prior period, unchanged from 0000106040-18-000010:mdna:4]

[0000106040-18-000016:mdna:5]
[same as prior period, unchanged from 0000106040-18-000010:mdna:5]

[0000106040-18-000016:mdna:6]
[same as prior period, unchanged from 0000106040-18-000010:mdna:6]

[0000106040-18-000016:mdna:7]
[same as prior period, unchanged from 0000106040-18-000010:mdna:23]

[0000106040-18-000016:mdna:8]
During the third quarter ended March 30, 2018, we entered into new debt facilities, amended our existing credit agreement, increased our revolving credit facility, and repaid higher rate debt. These actions reduced the aggregate principal amount of our debt by $825 million in the third quarter and by $1.94 billion since the beginning of the year and reduced our overall interest cost, extended the tenor of our debt and provided additional flexible capacity to meet our financing needs. The financing arrangement activities were as follows in the current year:

[0000106040-18-000016:mdna:9]
| • | In November 2017, we settled our then-existing U.S. dollar-denominated term B-2 loans (“U.S. Term Loan B-2”) with the proceeds of a new issuance of a $2.96 billion U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) at an interest rate lower than our U.S. Term Loan B-2 tranche. |

[0000106040-18-000016:mdna:10]
| • | In November 2017, we made a voluntary prepayment of the full principal amounts of our Euro-denominated term B-2 loans (“Euro Term Loan B-2”) using cash on hand. |

[0000106040-18-000016:mdna:11]
| • | In February 2018, we issued $2.3 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”). |

[0000106040-18-000016:mdna:12]
| • | In February 2018, we issued a $1.1 billion aggregate principal amount of 1.50% convertible senior notes due 2024 (the “2024 Convertible Notes”). |

[0000106040-18-000016:mdna:13]
| • | In February 2018, we entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced our prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on our corporate credit ratings, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. We used a portion of the proceeds of the Term Loan A-1 to repay in full our previous variable interest rate Term Loan A maturing 2021 in the principal amount of $4.02 billion. |

[0000106040-18-000016:mdna:14]
| • | In February 2018, we made a voluntary partial prepayment of $500 million of the U.S. Term Loan B-3 using drawings from the Revolving Facility. |

[0000106040-18-000016:mdna:15]
| • | In February and March 2018, we completed the redemption of all of our outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of our outstanding 10.500% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Existing Notes”). |

[0000106040-18-000016:mdna:16]
| • | In connection with the settlements of the various debt instruments described above, we incurred aggregate losses on extinguishment of debt of $896 million for the nine months ended March 30, 2018, consisting of $720 million of “make-whole” premiums and $176 million of unamortized issuance costs, of which $894 million was incurred in the three months ended March 30, 2018. |

[0000106040-18-000016:mdna:17]
[same as prior period, unchanged from 0000106040-18-000010:mdna:28]

[0000106040-18-000016:mdna:18]
[same as prior period, unchanged from 0000106040-18-000010:mdna:12]

[0000106040-18-000016:mdna:19]
On December 22, 2017, the President of the United States of America signed the Tax Cuts and Jobs Act (the “2017 Act”), which includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21% and a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred, and creates new taxes on certain foreign earnings. As a result of the 2017 Act, we have made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $79 million related to the re-measurement of deferred tax assets and liabilities for the nine months ended March 30, 2018. For additional information regarding the 2017 Act, see Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q. See also the discussion in “Results of Operations - Income Tax Expense” and “Liquidity and Capital Resources” below for information regarding the impact of the 2017 Act on our financial condition, results of operations and cash flows.

[0000106040-18-000016:mdna:20]
[same as prior period, unchanged from 0000106040-18-000010:mdna:11]

[0000106040-18-000016:mdna:21]
[same as prior period, unchanged from 0000106040-18-000010:mdna:30]

[0000106040-18-000016:mdna:22]
Third Quarter and Nine Month Overview

[0000106040-18-000016:mdna:23]
[same as prior period, unchanged from 0000106040-18-000010:mdna:32]

[0000106040-18-000016:mdna:24]
|  | Three Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 5,013 |  |  | 100.0 | % |  | $ | 4,649 |  |  | 100.0 | % |  | $ | 364 |  |  | 7.8 | % |
| Cost of revenue | 3,086 |  |  | 61.6 |  |  | 3,126 |  |  | 67.2 |  |  | (40 | ) |  | (1.3 | ) |
| Gross profit | 1,927 |  |  | 38.4 |  |  | 1,523 |  |  | 32.8 |  |  | 404 |  |  | 26.5 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 602 |  |  | 12.0 |  |  | 613 |  |  | 13.2 |  |  | (11 | ) |  | (1.8 | ) |
| Selling, general and administrative | 376 |  |  | 7.5 |  |  | 346 |  |  | 7.4 |  |  | 30 |  |  | 8.7 |  |
| Employee termination, asset impairment, and other charges | 35 |  |  | 0.7 |  |  | 39 |  |  | 0.8 |  |  | (4 | ) |  | (10.3 | ) |
| Total operating expenses | 1,013 |  |  | 20.2 |  |  | 998 |  |  | 21.5 |  |  | 15 |  |  | 1.5 |  |
| Operating income | 914 |  |  | 18.2 |  |  | 525 |  |  | 11.3 |  |  | 389 |  |  | 74.1 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 16 |  |  | 0.3 |  |  | 7 |  |  | 0.2 |  |  | 9 |  |  | 128.6 |  |
| Interest expense | (160 | ) |  | (3.2 | ) |  | (205 | ) |  | (4.4 | ) |  | 45 |  |  | (22.0 | ) |
| Other expense, net | (898 | ) |  | (17.9 | ) |  | (23 | ) |  | (0.5 | ) |  | (875 | ) |  | 3,804.3 |  |
| Total interest and other expense, net | (1,042 | ) |  | (20.8 | ) |  | (221 | ) |  | (4.8 | ) |  | (821 | ) |  | 371.5 |  |
| Income (loss) before taxes | (128 | ) |  | (2.6 | ) |  | 304 |  |  | 6.5 |  |  | (432 | ) |  | (142.1 | ) |
| Income tax expense (benefit) | (189 | ) |  | (3.8 | ) |  | 56 |  |  | 1.2 |  |  | (245 | ) |  | (437.5 | ) |
| Net income (loss) | $ | 61 |  |  | 1.2 |  |  | $ | 248 |  |  | 5.3 |  |  | (187 | ) |  | (75.4 | ) |

[0000106040-18-000016:mdna:25]
[same as prior period, unchanged from 0000106040-18-000010:mdna:34]

[0000106040-18-000016:mdna:26]
[same as prior period, unchanged from 0000106040-18-000010:mdna:22]

[0000106040-18-000016:mdna:27]
|  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 15,530 |  |  | 100.0 | % |  | $ | 14,251 |  |  | 100.0 | % |  | $ | 1,279 |  |  | 9.0 | % |
| Cost of revenue | 9,677 |  |  | 62.3 |  |  | 9,860 |  |  | 69.2 |  |  | (183 | ) |  | (1.9 | ) |
| Gross profit | 5,853 |  |  | 37.7 |  |  | 4,391 |  |  | 30.8 |  |  | 1,462 |  |  | 33.3 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,823 |  |  | 11.7 |  |  | 1,837 |  |  | 12.9 |  |  | (14 | ) |  | (0.8 | ) |
| Selling, general and administrative | 1,121 |  |  | 7.2 |  |  | 1,100 |  |  | 7.7 |  |  | 21 |  |  | 1.9 |  |
| Employee termination, asset impairment, and other charges | 135 |  |  | 0.9 |  |  | 152 |  |  | 1.1 |  |  | (17 | ) |  | (11.2 | ) |
| Total operating expenses | 3,079 |  |  | 19.8 |  |  | 3,089 |  |  | 21.7 |  |  | (10 | ) |  | (0.3 | ) |
| Operating income | 2,774 |  |  | 17.9 |  |  | 1,302 |  |  | 9.1 |  |  | 1,472 |  |  | 113.1 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 46 |  |  | 0.3 |  |  | 17 |  |  | 0.1 |  |  | 29 |  |  | 170.6 |  |
| Interest expense | (562 | ) |  | (3.6 | ) |  | (646 | ) |  | (4.5 | ) |  | 84 |  |  | (13.0 | ) |
| Other expense, net | (902 | ) |  | (5.8 | ) |  | (319 | ) |  | (2.2 | ) |  | (583 | ) |  | 182.8 |  |
| Total interest and other expense, net | (1,418 | ) |  | (9.1 | ) |  | (948 | ) |  | (6.7 | ) |  | (470 | ) |  | 49.6 |  |
| Income (loss) before taxes | 1,356 |  |  | 8.7 |  |  | 354 |  |  | 2.5 |  |  | 1,002 |  |  | 283.1 |  |
| Income tax expense (benefit) | 1,437 |  |  | 9.3 |  |  | 237 |  |  | 1.7 |  |  | 1,200 |  |  | 506.3 |  |
| Net income (loss) | $ | (81 | ) |  | (0.5 | ) |  | $ | 117 |  |  | 0.8 |  |  | $ | (198 | ) |  | (169.2 | ) |

[0000106040-18-000016:mdna:28]
[same as prior period, unchanged from 0000106040-18-000010:mdna:37]

[0000106040-18-000016:mdna:29]
[same as prior period, unchanged from 0000106040-18-000010:mdna:38]

[0000106040-18-000016:mdna:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 5,013 |  |  | $ | 4,649 |  |  | $ | 15,530 |  |  | $ | 14,251 |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |
| Americas | 28 | % |  | 26 | % |  | 27 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 18 |  |  | 18 |  |  | 18 |  |
| Asia | 53 |  |  | 56 |  |  | 55 |  |  | 56 |  |
| Revenues by End Market (%) (2) |  |  |  |  |  |  |  |
| Client Devices | 46 | % |  | 50 | % |  | 49 | % |  | 50 | % |
| Data Center Devices & Solutions | 33 |  |  | 28 |  |  | 29 |  |  | 29 |  |
| Client Solutions | 21 |  |  | 22 |  |  | 22 |  |  | 21 |  |
| Exabytes Shipped | 100 |  |  | 74 |  |  | 282 |  |  | 232 |  |

[0000106040-18-000016:mdna:31]
[same as prior period, unchanged from 0000106040-18-000010:mdna:40]

[0000106040-18-000016:mdna:32]
[same as prior period, unchanged from 0000106040-18-000010:mdna:41]

[0000106040-18-000016:mdna:33]
[same as prior period, unchanged from 0000106040-18-000010:mdna:29]

[0000106040-18-000016:mdna:34]
[same as prior period, unchanged from 0000106040-18-000010:mdna:43]

[0000106040-18-000016:mdna:35]
The increase in net revenue for the three months ended March 30, 2018, compared to the same period in the prior year, is primarily due to increased flash memory and hard disk drives (“HDD”) product revenue. Client Devices revenue was relatively flat for the three months ended March 30, 2018 as a result of growth in mobile and embedded flash memory products offset by lower client compute devices. Our revenue for Data Center Devices and Solutions for the three months ended March 30, 2018 increased 25.0% year over year, primarily due to an increase in capacity enterprise HDD driven by cloud storage demand. Client Solutions revenue for the three months ended March 30, 2018 increased 3.9% year over year, primarily due to growth in HDD retail products.

[0000106040-18-000016:mdna:36]
The increase in net revenue for the nine months ended March 30, 2018, compared to the same period in the prior year, is primarily due to increased flash products offset by a decline in client compute HDD devices. Client Devices revenue for the nine months ended March 30, 2018 increased 7.4% year over year, primarily driven by growth in mobile and embedded flash products, partially offset by lower sales of client compute HDD products. Our revenue for Data Center Devices and Solutions for the nine months ended March 30, 2018 increased 9.3% year over year, driven primarily by a significant increase in sales from our capacity enterprise HDD, partially offset by lower sales from our performance enterprise HDDs. Client Solutions revenue for the nine months ended March 30, 2018 increased 12.3% year over year, reflecting growth in both HDD and flash products.

[0000106040-18-000016:mdna:37]
Our top 10 customers accounted for 44% and 42% of our net revenue for the three and nine months ended March 30, 2018, respectively, and 41% of our net revenue for each of the three and nine months ended March 31, 2017. For the three and nine months ended March 30, 2018 and March 31, 2017, no single customer accounted for 10% or more of our net revenue.

[0000106040-18-000016:mdna:38]
[same as prior period, unchanged from 0000106040-18-000010:mdna:46]

[0000106040-18-000016:mdna:39]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended March 30, 2018, these programs represented 11% and 12% of gross revenues, respectively. For the three and nine months ended March 31, 2017, these programs represented 11% and 13%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-18-000016:mdna:40]
[same as prior period, unchanged from 0000106040-18-000010:mdna:48]

[0000106040-18-000016:mdna:41]
The increase in gross profit for the three months ended March 30, 2018 reflects the increase in revenue discussed above and improvement in our gross margin. The improvement in gross margin for the three months ended March 30, 2018 was primarily due to a favorable demand environment for flash-based products and a higher mix of flash-based product revenue, growth in higher-margin capacity enterprise HDD, and improvements in our production costs from technology transitions.

[0000106040-18-000016:mdna:42]
The increase in gross profit for the nine months ended March 30, 2018 reflects the increase in revenue discussed above and improvement in our gross margin. The improvement in our gross margin for the nine months ended March 30, 2018 was primarily due to a favorable demand environment for flash-based products and a higher mix of flash-based product revenue, as well as improvements in our production costs from technology transitions.

[0000106040-18-000016:mdna:43]
Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $247 million, or 4.9%, of revenue, for the three months ended March 30, 2018, and $303 million, or 6.5%, of revenue, for the three months ended March 31, 2017. Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $819 million, or 5.3%, of revenue, for the nine months ended March 30, 2018, and $826 million, or 5.8%, of revenue, for the nine months ended March 31, 2017.

[0000106040-18-000016:mdna:44]
[same as prior period, unchanged from 0000106040-18-000010:mdna:51]

[0000106040-18-000016:mdna:45]
The decrease in research and development (“R&D”) expense for both the three and nine months ended March 30, 2018 from the same periods in the prior year, was primarily due to lower spend as a result of our cost saving initiatives and lower variable compensation expense, partially offset by further investments in flash technologies. The three months ended March 30, 2018, and March 31, 2017, both included aggregate charges of $47 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges. The nine months ended March 30, 2018 and March 31, 2017 included aggregate charges of $142 million and $149 million, respectively, related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges.

[0000106040-18-000016:mdna:46]
The increase in selling, general and administrative (“SG&A”) expense for the three months ended March 30, 2018 from the same period in the prior year, is primarily due to higher consulting services and operating expenses of recent acquisitions, partially offset by lower variable compensation expense. Both the three months ended March 30, 2018 and March 31, 2017 included aggregate charges of $81 million related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges.

[0000106040-18-000016:mdna:47]
The increase in SG&A expense for the nine months ended March 30, 2018 from the same period in the prior year was primarily due to operating expenses from recent acquisitions, higher consulting services and legal expenses, partially offset by lower variable compensation expense. The nine months ended March 30, 2018 and March 31, 2017 included aggregate charges of $268 million and $317 million, respectively, related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges.

[0000106040-18-000016:mdna:48]
Employee termination and other charges for the three and nine months ended March 30, 2018 primarily related to further actions associated with the integration and business realignment of substantial portions of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 12, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:49]
[same as prior period, unchanged from 0000106040-18-000010:mdna:57]

[0000106040-18-000016:mdna:50]
The loss from total interest and other income (expense), net for the three months ended March 30, 2018 increased $821 million from the same period in the prior year, primarily due to the loss on extinguishment of debt of $894 million during the three months ended March 30, 2018 compared to $7 million in the prior year. The loss was partially offset by lower interest expense of $45 million resulting from reductions in the interest rates and principal amount of debt, higher interest income due to increased rates of return on investments and lower foreign exchange losses.

[0000106040-18-000016:mdna:51]
The loss from total interest and other income (expense), net for the nine months ended March 30, 2018 increased $470 million from the same period in the prior year, primarily due to the loss on extinguishment of debt of $896 million recognized in the current year, compared to $274 million of debt extinguishment charges in the prior year, partially offset by lower interest expense of $84 million resulting from reductions in the interest rates and principal amount of debt, higher interest income of $29 million related to increased rates of return on investments and lower foreign exchange losses.

[0000106040-18-000016:mdna:52]
Income Tax Expense (Benefit)

[0000106040-18-000016:mdna:53]
[same as prior period, unchanged from 0000106040-18-000010:mdna:61]

[0000106040-18-000016:mdna:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions, except percentages) |
| Income (loss) before taxes | $ | (128 | ) |  | $ | 304 |  |  | $ | 1,356 |  |  | $ | 354 |  |
| Income tax expense (benefit) | (189 | ) |  | 56 |  |  | $ | 1,437 |  |  | $ | 237 |  |
| Effective tax rate | 148 | % |  | 18 | % |  | 106 | % |  | 67 | % |

[0000106040-18-000016:mdna:55]
Under the 2017 Act, the U.S. federal corporate tax rate is reduced from 35% to 21% and is effective January 1, 2018, resulting in the use of an estimated annual effective tax rate of approximately 28% for our U.S. federal corporate tax rate for fiscal year 2018. The U.S. federal corporate tax rate was reduced from 35% to the blended tax rate of 28% for fiscal year 2018. For fiscal year 2019 and beyond, we will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000016:mdna:56]
Consistent with applicable Securities and Exchange Commission (“SEC”) guidance, we made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.66 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $79 million related to the re-measurement of deferred tax assets and liabilities for the nine months ended March 30, 2018. For other elements of tax expense noted in Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q, or where we have not made an election, we have not been able to make a reasonable estimate and continue to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As we finalize the accounting for the tax effects of the enactment of the 2017 Act during a one-year measurement period permitted by applicable SEC guidance, we expect to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000016:mdna:57]
The primary drivers for the difference between the effective tax rate for the three months ended March 30, 2018 and the U.S. Federal statutory rate of 28% include discrete effects consisting of an income tax benefit of $211 million from deductible make-whole premiums and the write-off of unamortized issuance costs from debt financing transactions. The primary drivers for the difference between the effective tax rate for the nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% are related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act and deductible make-whole premiums and the write-off of unamortized issuance costs from debt financing transactions. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% are the current year generation of tax credits, and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires us to now recognize $46 million and $73 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of our income tax expense for the three and nine months ended March 30, 2018, respectively. The windfall tax benefits for the three and nine months ended March 31, 2017 were recorded within shareholders’ equity.

[0000106040-18-000016:mdna:58]
The primary drivers for the difference between the effective tax rate for the nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% include discrete effects consisting of income tax expense from the integration of SanDisk Corporation (“SanDisk”) of $91 million and a valuation allowance on acquired tax attributes of $111 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $98 million. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 31, 2017 and the U.S. Federal statutory rate of 35% are these discrete items, the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-18-000016:mdna:59]
[same as prior period, unchanged from 0000106040-18-000010:mdna:67]

[0000106040-18-000016:mdna:60]
For additional information regarding income tax expense (benefit), see Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:61]
53

[0000106040-18-000016:mdna:62]
[same as prior period, unchanged from 0000106040-18-000010:mdna:70]

[0000106040-18-000016:mdna:63]
[same as prior period, unchanged from 0000106040-18-000010:mdna:71]

[0000106040-18-000016:mdna:64]
|  | Nine Months Ended |
|  | March 30, 2018 |  | March 31, 2017 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 3,342 |  |  | $ | 2,498 |  |
| Investing activities | (1,406 | ) |  | (446 | ) |
| Financing activities | (3,337 | ) |  | (4,546 | ) |
| Effect of exchange rate changes on cash | 10 |  |  | (5 | ) |
| Net decrease in cash and cash equivalents | $ | (1,391 | ) |  | $ | (2,499 | ) |

[0000106040-18-000016:mdna:65]
[same as prior period, unchanged from 0000106040-18-000010:mdna:73]

[0000106040-18-000016:mdna:66]
During 2018, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to Flash Ventures to be approximately $1.50 billion to $1.90 billion. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-18-000016:mdna:67]
Pursuant to the 2017 Act, we are required to pay a one-time deemed repatriation tax related to the undistributed earnings of our foreign subsidiaries.  For the nine months ended March 30, 2018, we recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.66 billion, which is payable over an 8-year period as further discussed below under “Short and Long-term Liquidity-Contractual Obligations and Commitments.” The provisional amount included in the Condensed Consolidated Financial Statements may change when we finalize the calculation of our post-1986 foreign earnings and profits that were previously deferred from U.S. income taxes and the amount of foreign earnings held in cash or other specified assets.  For additional information regarding our total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:68]
A total of $3.96 billion and $4.99 billion of our cash and cash equivalents was held outside of the U.S. as of March 30, 2018 and June 30, 2017, respectively. Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., we continue to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires us to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the U.S. deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the current tax expense is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, our plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings.  In the event we determine not to continue to assert the permanent reinvestment of part or all of our foreign undistributed earnings, such a determination could result in the accrual and payment of additional foreign, state and local taxes.

[0000106040-18-000016:mdna:69]
[same as prior period, unchanged from 0000106040-18-000010:mdna:77]

[0000106040-18-000016:mdna:70]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash provided by changes in other operating assets and liabilities was $948 million for the nine months ended March 30, 2018, as compared to net cash provided by changes in other operating assets and liabilities of $71 million for the nine months ended March 31, 2017. The increase in cash provided by changes in other operating assets and liabilities in the current year primarily reflects the payable recorded for the mandatory repatriation tax as described in the Tax Reform section of Key Developments above. Changes in our other operating assets and liabilities are also largely affected by our working capital requirements, which is dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-18-000016:mdna:71]
|  | March 30, 2018 |  | March 31, 2017 |
|  | (in days) |
| Days sales outstanding | 36 |  |  | 38 |  |
| Days in inventory | 79 |  |  | 66 |  |
| Days payables outstanding | (71 | ) |  | (69 | ) |
| Cash conversion cycle | 44 |  |  | 35 |  |

[0000106040-18-000016:mdna:72]
[same as prior period, unchanged from 0000106040-18-000010:mdna:82]

[0000106040-18-000016:mdna:73]
For the nine months ended March 30, 2018, DSO decreased by 2 days over the prior year, primarily reflecting the timing of shipments and customer receipts. DIO increased by 13 days over the prior year, primarily reflecting ongoing hard drive manufacturing transformation activities. The increase in DPO primarily reflects the increased production volume and timing of vendor payments.

[0000106040-18-000016:mdna:74]
[same as prior period, unchanged from 0000106040-18-000010:mdna:84]

[0000106040-18-000016:mdna:75]
Net cash used in investing activities for the nine months ended March 30, 2018 primarily consisted of $643 million of capital expenditures, a net $707 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion, and $99 million for acquisitions. Net cash used in investing activities for the nine months ended March 31, 2017 primarily consisted of $453 million of capital expenditures and a $224 million net increase in notes receivable issuances to and investments in Flash Ventures, partially offset by a net reduction of our available for sale securities of $231 million.

[0000106040-18-000016:mdna:76]
[same as prior period, unchanged from 0000106040-18-000010:mdna:86]

[0000106040-18-000016:mdna:77]
[same as prior period, unchanged from 0000106040-18-000010:mdna:87]

[0000106040-18-000016:mdna:78]
Net cash used in financing activities for the nine months ended March 30, 2018 primarily consisted of $14.58 billion in debt repayments, $443 million to pay dividends on our common stock and $155 million of share repurchases, partially offset by net proceeds of $11.83 billion from debt issuances and draws under our Revolving Facility. Net cash used in financing activities for the nine months ended March 31, 2017 consisted of $12.18 billion in debt repayments and $428 million to pay dividends on our common stock, partially offset by $7.91 billion of net proceeds from debt, $61 million of proceeds from call options, and a net $102 million provided by employee stock plans.

[0000106040-18-000016:mdna:79]
[same as prior period, unchanged from 0000106040-18-000010:mdna:69]

[0000106040-18-000016:mdna:80]
[same as prior period, unchanged from 0000106040-18-000010:mdna:89]

[0000106040-18-000016:mdna:81]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:82]
[same as prior period, unchanged from 0000106040-18-000010:mdna:91]

[0000106040-18-000016:mdna:83]
[same as prior period, unchanged from 0000106040-18-000010:mdna:92]

[0000106040-18-000016:mdna:84]
The following is a summary of our known contractual cash obligations and commercial commitments as of March 30, 2018:

[0000106040-18-000016:mdna:85]
|  | Total |  | 1 Year (Remaining 3 months of 2018) |  | 2-3 Years (2019-2020) |  | 4-5 Years (2021-2022) |  | More than 5 Years (Beyond 2022) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 11,412 |  |  | $ | 31 |  |  | $ | 443 |  |  | $ | 502 |  |  | $ | 10,436 |  |
| Interest on debt | 2,325 |  |  | 104 |  |  | 823 |  |  | 785 |  |  | 613 |  |
| Flash Ventures and other related commitments(1) | 9,101 |  |  | 1,158 |  |  | 4,655 |  |  | 2,283 |  |  | 1,005 |  |
| Operating leases | 171 |  |  | 34 |  |  | 80 |  |  | 42 |  |  | 15 |  |
| Purchase obligations | 2,428 |  |  | 2,189 |  |  | 238 |  |  | 1 |  |  | — |  |
| Mandatory Repatriation Tax | 1,657 |  |  | — |  |  | 265 |  |  | 265 |  |  | 1,127 |  |
| Total | $ | 27,094 |  |  | $ | 3,516 |  |  | $ | 6,504 |  |  | $ | 3,878 |  |  | $ | 13,196 |  |

[0000106040-18-000016:mdna:86]
[same as prior period, unchanged from 0000106040-18-000010:mdna:95]

[0000106040-18-000016:mdna:87]
[same as prior period, unchanged from 0000106040-18-000010:mdna:96]

[0000106040-18-000016:mdna:88]
See Part I, Item 1, Note 6, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding our indebtedness, including information about new borrowings and repayments, increased availability under our Revolving Facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness.

[0000106040-18-000016:mdna:89]
[same as prior period, unchanged from 0000106040-18-000010:mdna:98]

[0000106040-18-000016:mdna:90]
[same as prior period, unchanged from 0000106040-18-000010:mdna:99]

[0000106040-18-000016:mdna:91]
[same as prior period, unchanged from 0000106040-18-000010:mdna:79]

[0000106040-18-000016:mdna:92]
[same as prior period, unchanged from 0000106040-18-000010:mdna:100]

[0000106040-18-000016:mdna:93]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of March 30, 2018, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding Flash Ventures.

[0000106040-18-000016:mdna:94]
[same as prior period, unchanged from 0000106040-18-000010:mdna:102]

[0000106040-18-000016:mdna:95]
[same as prior period, unchanged from 0000106040-18-000010:mdna:103]

[0000106040-18-000016:mdna:96]
[same as prior period, unchanged from 0000106040-18-000010:mdna:104]

[0000106040-18-000016:mdna:97]
[same as prior period, unchanged from 0000106040-18-000010:mdna:105]

[0000106040-18-000016:mdna:98]
[same as prior period, unchanged from 0000106040-18-000010:mdna:106]

[0000106040-18-000016:mdna:99]
[same as prior period, unchanged from 0000106040-18-000010:mdna:107]

[0000106040-18-000016:mdna:100]
The following is a summary of our estimated provisional mandatory deemed repatriation tax obligations that are payable in the following fiscal years ending (in millions):

[0000106040-18-000016:mdna:101]
[same as prior period, unchanged from 0000106040-18-000010:mdna:109]

[0000106040-18-000016:mdna:102]
The 2017 Act allows for the provisional mandatory deemed repatriation tax of $1.66 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. For additional information regarding our provisional estimate of the total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:103]
[same as prior period, unchanged from 0000106040-18-000010:mdna:111]

[0000106040-18-000016:mdna:104]
As of March 30, 2018, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $505 million. Accrued interest and penalties related to unrecognized tax benefits as of March 30, 2018 was approximately $105 million. Of these amounts, approximately $477 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 10, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:105]
Stock Repurchase Program

[0000106040-18-000016:mdna:106]
Our Board of Directors has authorized $5.00 billion for the repurchase of our common stock. The stock repurchase program is effective until February 3, 2020. We made repurchases aggregating $2.88 billion prior to fiscal 2018. We repurchased 1.78 million shares for a total cost of $155 million during the three and nine months ended March 30, 2018. The remaining amount available to be purchased under our stock repurchase program as of March 30, 2018 was $1.97 billion.

[0000106040-18-000016:mdna:107]
[same as prior period, unchanged from 0000106040-18-000010:mdna:113]

[0000106040-18-000016:mdna:108]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On January 27, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of March 30, 2018. The cash dividend of $150 million was paid on April 16, 2018.

[0000106040-18-000016:mdna:109]
During the nine months ended March 30, 2018 and March 31, 2017, we declared aggregate cash dividends of $1.50 per share of our common stock totaling $446 million and $432 million, respectively.

[0000106040-18-000016:mdna:110]
On May 2, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of June 29, 2018, which will be paid on July 16, 2018. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-18-000016:mdna:111]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-18-000016:mdna:112]
In February 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the 2017 Act. Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. However, because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. The amendments in this update also require certain disclosures about stranded tax effects. ASU 2018-02 is effective for fiscal years beginning after December 15, 2018, which for us is the first quarter of 2020, and interim periods within that fiscal year. Early adoption is permitted in any interim period after issuance of the update. We are currently evaluating the impact this update will have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:113]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness, resulting in better alignment between the presentation of the effects of the hedging instrument and the hedged item in the financial statements. ASU 2017-12 is effective for fiscal years beginning after December 15, 2018, which for us is the first quarter of 2020, including interim periods within that fiscal year. Early adoption is permitted in any interim period after issuance of the update. We are currently evaluating the timing of adoption and the impact this update will have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:114]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. This ASU is effective prospectively for annual periods beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:115]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. We are currently evaluating the impact ASU 2017-07 will have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:116]
In February 2017, the FASB issued ASU No. 2017-05, “Other Income-Gains and Losses from the Derecognition of Nonfinancial Assets (Subtopic 610-20): Clarifying the Scope of Asset Derecognition Guidance and Accounting for Partial Sales of Nonfinancial Assets” (“ASU 2017-05”). ASU 2017-05 clarifies the scope and application of Accounting Standards Codification (“ASC”) 610-20 on the sale or transfer of nonfinancial assets, including real estate, and in substance nonfinancial assets to noncustomers, including partial sales. An entity should identify each distinct nonfinancial asset or in substance nonfinancial asset promised to a counterparty and derecognize each asset when a counterparty obtains control of the related asset. The ASU also clarifies that an in substance nonfinancial asset is an asset or group of assets for which substantially all of the fair value consists of nonfinancial assets and the group or subsidiary is not a business. In addition, the amendment requires an entity to derecognize a distinct nonfinancial asset or in substance nonfinancial asset in a partial sale transaction when the entity does not retain a controlling financial interest in the legal entity that holds the asset and an entity transfers control of the asset. Once control is transferred, any non-controlling interest received is required to be measured at fair value. The effective date of the new standard is aligned with the requirements in the new revenue standard ASU No. 2014-09, which for us is the first quarter of 2019. We are in the process of evaluating the impact that adoption of this guidance may have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:117]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). ASU 2017-04 simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. The new standard is effective for goodwill impairment tests in fiscal years beginning after December 15, 2019, which for us is the first quarter of 2021. Early adoption is permitted for goodwill impairment tests performed after January 1, 2017. As permitted by ASU 2017-04, we have elected to early adopt this standard for our fiscal 2018 goodwill impairment test, which is to be performed as of the first day of our fourth quarter, March 31, 2018. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:118]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business”. This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. The new standard must be applied prospectively to transactions occurring within the period of adoption. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:119]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of accounting principles generally accepted in the United States (“U.S. GAAP”) and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact that the adoption of this guidance may have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:120]
59

[0000106040-18-000016:mdna:121]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for us is the first quarter of 2021.  We are currently evaluating the impact this update will have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:122]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or control the use of, a specified asset for the lease term. Currently, lessees and lessors must apply a modified retrospective transition approach for leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements. However, the FASB approved an amendment at its March 7, 2018 meeting, which would allow entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted. As we plan for the adoption of this standard, we have completed our first phase of globally identifying our leases including the identification of embedded leases. We are in the process of identifying changes to our processes, internal controls and system requirements and configurations that would result from the new lease standard. Our implementation efforts are progressing as planned. We expect to adopt this standard in the first quarter of 2020 and expect to elect the practical expedient to not present historical comparative information. We continue to evaluate the impact ASU 2016-02 will have on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:123]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-18-000016:mdna:124]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)” (“ASC Topic 606”), which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The standard is effective beginning the first quarter of fiscal 2019, with early adoption permitted. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our plan, we will to adopt the new standard beginning with the first quarter of 2019 using the modified retrospective method.

[0000106040-18-000016:mdna:125]
We expect the implementation of the new standard to impact the recognition of our revenue and cost as follows:

[0000106040-18-000016:mdna:126]
[same as prior period, unchanged from 0000106040-18-000010:mdna:130]

[0000106040-18-000016:mdna:127]
[same as prior period, unchanged from 0000106040-18-000010:mdna:131]

[0000106040-18-000016:mdna:128]
| • | For other revenue streams such as multi-element transactions, software and IP licenses, these transactions are immaterial and the related changes to revenue recognition are not expected to be material. |

[0000106040-18-000016:mdna:129]
| • | For assets recognized from costs incurred to obtain or fulfill a contract, we do not expect to have material capitalized fees for contracts where the amortization period is greater than one year. |

[0000106040-18-000016:mdna:130]
| • | Our revenue disclosures will expand and may require judgment in certain areas. |

[0000106040-18-000016:mdna:131]
[same as prior period, unchanged from 0000106040-18-000010:mdna:134]

[0000106040-18-000016:mdna:132]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recently Adopted Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000016:mdna:133]
[same as prior period, unchanged from 0000106040-18-000010:mdna:136]

[0000106040-18-000016:mdna:134]
[same as prior period, unchanged from 0000106040-18-000010:mdna:137]

[0000106040-18-000016:mdna:135]
[same as prior period, unchanged from 0000106040-18-000010:mdna:138]
