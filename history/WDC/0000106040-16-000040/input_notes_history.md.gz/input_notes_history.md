# WDC note change history — 0000106040-16-000022 → 0000106040-16-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2016-11-08):
[0000106040-16-000040:note_history:1]
Commitments, Contingencies and Related Parties

- added (2016-11-08):
[0000106040-16-000040:note_history:2]
Flash Ventures

- added (2016-11-08):
[0000106040-16-000040:note_history:3]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through these ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

- added (2016-11-08):
[0000106040-16-000040:note_history:4]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

- added (2016-11-08):
[0000106040-16-000040:note_history:5]
During the three months ended September 30, 2016, the Company purchased NAND flash memory wafers from Flash Ventures and made loans to, and investments in, Flash Ventures totaling $127 million and $20 million, respectively, and received loan repayments from Flash Ventures of $120 million. At September 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $190 million and $168 million, respectively.

- added (2016-11-08):
[0000106040-16-000040:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016, is presented below. Flash Ventures’ investments are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2016-11-08):
[0000106040-16-000040:note_history:7]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable | $ | 580 |  |  | $ | 563 |  |
| Equity investments | 637 |  |  | 608 |  |
| Operating lease guarantees | 1,235 |  |  | 1,151 |  |
| Prepayments | 30 |  |  | 34 |  |
| Maximum estimable loss exposure | $ | 2,482 |  |  | $ | 2,356 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:8]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- added (2016-11-08):
[0000106040-16-000040:note_history:9]
The following table presents, as of September 30, 2016, the notes receivable from and equity investments in Flash Ventures:

- added (2016-11-08):
[0000106040-16-000040:note_history:10]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 63 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 196 |  |  | 235 |  |
| Notes receivable, Flash Forward | 321 |  |  | 263 |  |
| Investment in Flash Partners | 205 |  |  | 202 |  |
| Investment in Flash Alliance | 310 |  |  | 306 |  |
| Investment in Flash Forward | 122 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,217 |  |  | $ | 1,171 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:11]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

- added (2016-11-08):
[0000106040-16-000040:note_history:12]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the condensed consolidated statements of operations.

- added (2016-11-08):
[0000106040-16-000040:note_history:13]
Off-Balance Sheet Liabilities

- added (2016-11-08):
[0000106040-16-000040:note_history:14]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

- added (2016-11-08):
[0000106040-16-000040:note_history:15]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016.

- added (2016-11-08):
[0000106040-16-000040:note_history:16]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 125 |  |  | $ | 1,235 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:17]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the lease agreements, in annual installments as of September 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016:

- added (2016-11-08):
[0000106040-16-000040:note_history:18]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 298 |  |  | $ | 71 |  |  | $ | 369 |  |
| Year 2 |  | 247 |  |  | 11 |  |  | 258 |  |
| Year 3 |  | 203 |  |  | 59 |  |  | 262 |  |
| Year 4 |  | 125 |  |  | 73 |  |  | 198 |  |
| Year 5 |  | 39 |  |  | 109 |  |  | 148 |  |
| Total guarantee obligations |  | $ | 912 |  |  | $ | 323 |  |  | $ | 1,235 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:19]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0000106040-16-000040:note_history:20]
Legal Proceedings
  (was, 2016-05-09, similarity 0.9444):
[0000106040-16-000022:note_history:20]
5. Legal Proceedings

- changed (2016-11-08):
[0000106040-16-000040:note_history:21]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.
  (was, 2016-05-09, similarity 0.8424):
[0000106040-16-000022:note_history:21]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company's acquisition of HGST on March 8, 2012 (the “HGST Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

- changed (2016-11-08):
[0000106040-16-000040:note_history:22]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.
  (was, 2016-05-09, similarity 0.9982):
[0000106040-16-000022:note_history:22]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

- changed (2016-11-08):
[0000106040-16-000040:note_history:23]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.
  (was, 2016-05-09, similarity 0.9869):
[0000106040-16-000022:note_history:23]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

- added (2016-11-08):
[0000106040-16-000040:note_history:24]
Antitrust

- added (2016-11-08):
[0000106040-16-000040:note_history:25]
On June 25, 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint captioned Ritz Camera & Image, LLC v. SanDisk Corporation, Inc. and Eliyahou Harari in the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 25, 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. On February 24, 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. On May 14, 2015, the District Court granted in part plaintiffs’ motion for class certification. On April 29, 2016, the court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk's favor as to all of the plaintiffs’ claims. On May 31, 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

- added (2016-11-08):
[0000106040-16-000040:note_history:26]
On July 15, 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) in the U.S. District Court for the Northern District of California, alleging that defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. On August 25, 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint on September 16, 2011. On January 3, 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. On April 4, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint on January 20, 2015. On September 30, 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. On October 21, 2015, Samsung filed a fourth amended complaint. On November 4, 2015, the defendants filed a motion to dismiss. On September 26, 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

- added (2016-11-08):
[0000106040-16-000040:note_history:27]
On March 15, 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. in the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of Secure Digital (“SD”) cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD™ cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. On May 21, 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. On May 14, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. On February 3, 2015, the plaintiffs filed a second amended complaint in the District Court. On September 30, 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. On November 4, 2015, the plaintiffs filed a third amended complaint. On November 25, 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. On October 3, 2016, the District Court granted the defendants’ motion with leave to amend. On October 21, 2016, the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

- added (2016-11-08):
[0000106040-16-000040:note_history:28]
Securities

- added (2016-11-08):
[0000106040-16-000040:note_history:29]
Beginning on March 30, 2015, SanDisk and two officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed in the United States District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 16, 2014 and March 25, 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 16, 2014 and April 15, 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. On July 9, 2015, the Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. On January 22, 2016, the court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. On February 22, 2016, the court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). On March 23, 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss on April 29, 2016. On June 24, 2016, the court granted the motion and dismissed the amended complaint with leave to amend. On July 15, 2016, the Institutional Investor Group filed a further amended complaint. The Company filed a motion to dismiss on August 19, 2016. The Company intends to defend itself vigorously in this matter.

- changed (2016-11-08):
[0000106040-16-000040:note_history:30]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.
  (was, 2016-05-09, similarity 0.966):
[0000106040-16-000022:note_history:30]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.

- changed (2016-11-08):
[0000106040-16-000040:note_history:31]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.
  (was, 2016-05-09, similarity 0.9782):
[0000106040-16-000022:note_history:31]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. WD intends to defend itself vigorously in this matter.

- changed (2016-11-08):
[0000106040-16-000040:note_history:32]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.
  (was, 2016-05-09, similarity 0.9985):
[0000106040-16-000022:note_history:32]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company's expectations.

- removed (2016-11-08):
[0000106040-16-000022:note_history:33]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows.

- removed (2016-11-08):
[0000106040-16-000022:note_history:34]
Seagate Matter

- removed (2016-11-08):
[0000106040-16-000022:note_history:35]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the final arbitration award and interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

- removed (2016-11-08):
[0000106040-16-000022:note_history:36]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company had no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. On February 1, 2016, the matter was dismissed with prejudice pursuant to a stipulation of dismissal filed by the Company and Seagate. This matter is now closed.

- removed (2016-11-08):
[0000106040-16-000022:note_history:37]
SanDisk Matters

- removed (2016-11-08):
[0000106040-16-000022:note_history:38]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk on October 21, 2015 (the “Merger Agreement”).  The complaints alleged, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also alleged that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs were seeking injunctive relief to prevent the Merger from closing.  The plaintiffs were also seeking, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  At the request of the plaintiffs, the court ordered one of these matters dismissed without prejudice on February 26, 2016, and the other on March 8, 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0000106040-16-000040:note_history:39]
Basis of Presentation
  (was, 2016-05-09, similarity 0.9545):
[0000106040-16-000022:note_history:39]
1. Basis of Presentation

- added (2016-11-08):
[0000106040-16-000040:note_history:40]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the needs of the information technology industry and the infrastructure that enables the storage of data. The Company also generates license and royalty revenue related to its intellectual property.

- changed (2016-11-08):
[0000106040-16-000040:note_history:41]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2016-05-09, similarity 0.9698):
[0000106040-16-000022:note_history:41]
The accounting policies followed by Western Digital Corporation (the “Company”) are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the year ended July 3, 2015. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the year ended July 3, 2015. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- added (2016-11-08):
[0000106040-16-000040:note_history:42]
Fiscal Year

- added (2016-11-08):
[0000106040-16-000040:note_history:43]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal year 2017, which ends on June 30, 2017, and fiscal year 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- added (2016-11-08):
[0000106040-16-000040:note_history:44]
Reclassifications

- added (2016-11-08):
[0000106040-16-000040:note_history:45]
Certain prior year amounts have been reclassified in the condensed consolidated statement of cash flows to conform to the current year presentation.

- added (2016-11-08):
[0000106040-16-000040:note_history:46]
Use of Estimates

- added (2016-11-08):
[0000106040-16-000040:note_history:47]
Accounting Changes and Recent Accounting Pronouncements

- added (2016-11-08):
[0000106040-16-000040:note_history:48]
Recently Adopted

- added (2016-11-08):
[0000106040-16-000040:note_history:49]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015-05 at the beginning of the current year did not have a material impact on its condensed consolidated financial statements.

- added (2016-11-08):
[0000106040-16-000040:note_history:50]
Recently Issued

- added (2016-11-08):
[0000106040-16-000040:note_history:51]
In October 2016, the FASB issued ASU No. 2016-16, “Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). The new standard removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The ASU is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

- added (2016-11-08):
[0000106040-16-000040:note_history:52]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230)” (“ASU 2016-15”). The new standard addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which among others, includes the Company’s disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2019. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements and related disclosures.

- added (2016-11-08):
[0000106040-16-000040:note_history:53]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within those years, which for the Company is the first quarter of 2018. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2018. The Company is currently evaluating the impact ASU 2016-09 will have on its consolidated financial statements and related disclosures.

- added (2016-11-08):
[0000106040-16-000040:note_history:54]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for the Company is the first quarter of 2020. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2020. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements and related disclosures.

- added (2016-11-08):
[0000106040-16-000040:note_history:55]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”), which provides guidance related to accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is not permitted. The Company is currently evaluating the impact ASU 2016-01 will have on its consolidated financial statements.

- added (2016-11-08):
[0000106040-16-000040:note_history:56]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (“ASU 2014-09”), which amends the guidance in former Accounting Standards Codification Topic 605, “Revenue Recognition,” to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The Company does not expect the proposed standard to materially change the timing of revenue recognition for product revenue; however, the proposed standard may accelerate the timing of revenue recognition for the Company’s license and royalty contracts. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2015-14 by one year. The new standard allows for either a full retrospective or a modified retrospective transition method. Early application is permitted only as of annual reporting periods beginning after December 15, 2016, which for the Company is the first quarter of 2018. The Company has not yet selected a transition method and currently expects to adopt this standard in the first quarter of 2019.

- removed (2016-11-08):
[0000106040-16-000022:note_history:57]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal third quarters ended April 1, 2016 and April 3, 2015 both consisted of 13 weeks. The nine months ended April 1, 2016 and April 3, 2015 consisted of 39 and 40 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0000106040-16-000040:note_history:58]
Debt
  (was, 2016-05-09, similarity 0.8):
[0000106040-16-000022:note_history:58]
4. Debt

- added (2016-11-08):
[0000106040-16-000040:note_history:59]
Debt consisted of the following as of September 30, 2016 and July 1, 2016:

- added (2016-11-08):
[0000106040-16-000040:note_history:60]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,993 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 990 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 37 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,370 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (237 | ) |  | (532 | ) |
| Subtotal | 13,133 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (78 | ) |  | (3,334 | ) |
| Long-term debt | $ | 13,055 |  |  | $ | 13,660 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:61]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of September 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

- added (2016-11-08):
[0000106040-16-000040:note_history:62]
Term Loans

- added (2016-11-08):
[0000106040-16-000040:note_history:63]
In the first quarter ended September 30, 2016, the Company settled in full the principal amounts of the $3.75 billion U.S. Term Loan B and the €885 million Euro Term Loan B, plus accrued interest. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

- added (2016-11-08):
[0000106040-16-000040:note_history:64]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement (as defined below) and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.50% at September 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $5 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $5 million remain unamortized.

- added (2016-11-08):
[0000106040-16-000040:note_history:65]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% at September 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $2 million remain unamortized.

- added (2016-11-08):
[0000106040-16-000040:note_history:66]
Credit Agreement

- added (2016-11-08):
[0000106040-16-000040:note_history:67]
On April 29, 2016, the Company entered into a new credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. As described above, during the first quarter ended September 30, 2016, the U.S. Term Loan B and Euro Term Loan B were settled and replaced with the $3.0 billion U.S. Term Loan B-1 and the €885 million Euro Term Loan B-1, respectively.

- added (2016-11-08):
[0000106040-16-000040:note_history:68]
The revolving credit facility includes a $200 million sublimit for letters of credit. As of September 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance. Beginning in September 2017, we are required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of September 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.526%.

- added (2016-11-08):
[0000106040-16-000040:note_history:69]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

- added (2016-11-08):
[0000106040-16-000040:note_history:70]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require us to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

- added (2016-11-08):
[0000106040-16-000040:note_history:71]
Covenants

- added (2016-11-08):
[0000106040-16-000040:note_history:72]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

- added (2016-11-08):
[0000106040-16-000040:note_history:73]
Additional Bridge Facility

- added (2016-11-08):
[0000106040-16-000040:note_history:74]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.0 billion aggregate principal amount outstanding, together with accrued interest.

- added (2016-11-08):
[0000106040-16-000040:note_history:75]
Senior Notes

- added (2016-11-08):
[0000106040-16-000040:note_history:76]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

- added (2016-11-08):
[0000106040-16-000040:note_history:77]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

- added (2016-11-08):
[0000106040-16-000040:note_history:78]
Convertible Notes, Exchange Options and Call Options

- added (2016-11-08):
[0000106040-16-000040:note_history:79]
As of July 1, 2016, the Company had outstanding, through the acquisition of SanDisk, $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

- added (2016-11-08):
[0000106040-16-000040:note_history:80]
During the three months ended September 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $490 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

- added (2016-11-08):
[0000106040-16-000040:note_history:81]
As of September 30, 2016, $37 million principal amount of the 2020 Notes and less than $1 million principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

- added (2016-11-08):
[0000106040-16-000040:note_history:82]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported in Other income (expense), net in the condensed consolidated statements of operations until the Company extinguishes the related debt. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in accrued expenses and other liabilities in the condensed consolidated balance sheets. See Note 10 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three months ended September 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.

- added (2016-11-08):
[0000106040-16-000040:note_history:83]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in other current assets and other non-current assets in the condensed consolidated balance sheets. During the three months ended September 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three months ended September 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options at September 30, 2016 was immaterial.

- added (2016-11-08):
[0000106040-16-000040:note_history:84]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three months ended September 30, 2016 resulted in a net loss of $5 million.

- removed (2016-11-08):
[0000106040-16-000022:note_history:85]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the “Credit Agreement”), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.

- removed (2016-11-08):
[0000106040-16-000022:note_history:86]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. The Company repaid the $255 million outstanding balance under the revolving credit facility in January 2016. As of April 1, 2016, the term loan facility had a variable interest rate of 1.9% and a remaining outstanding balance of $2.2 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $47 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

- removed (2016-11-08):
[0000106040-16-000022:note_history:87]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of April 1, 2016, the Company was in compliance with all applicable financial covenants under the Credit Agreement.

- removed (2016-11-08):
[0000106040-16-000022:note_history:88]
For information related to the debt entered into in connection with the planned merger (the “Merger”) with SanDisk Corporation (“SanDisk”), see Note 14 to these condensed consolidated financial statements.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-11-08):
[0000106040-16-000040:note_history:89]
Debt consisted of the following as of September 30, 2016 and July 1, 2016:

- added (2016-11-08):
[0000106040-16-000040:note_history:90]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,993 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 990 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 37 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,370 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (237 | ) |  | (532 | ) |
| Subtotal | 13,133 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (78 | ) |  | (3,334 | ) |
| Long-term debt | $ | 13,055 |  |  | $ | 13,660 |  |

- added (2016-11-08):
[0000106040-16-000040:note_history:91]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of September 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2016-11-08):
[0000106040-16-000040:note_history:92]
The following table presents, as of September 30, 2016, the notes receivable from and equity investments in Flash Ventures:

- added (2016-11-08):
[0000106040-16-000040:note_history:93]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 63 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 196 |  |  | 235 |  |
| Notes receivable, Flash Forward | 321 |  |  | 263 |  |
| Investment in Flash Partners | 205 |  |  | 202 |  |
| Investment in Flash Alliance | 310 |  |  | 306 |  |
| Investment in Flash Forward | 122 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,217 |  |  | $ | 1,171 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-11-08):
[0000106040-16-000022:note_history:94]
14. Subsequent Event

- removed (2016-11-08):
[0000106040-16-000022:note_history:95]
In connection with the Merger with SanDisk, the Company expects to enter into new debt facilities totaling approximately $18.1 billion, of which the Company has incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarterly Report on Form 10-Q. In addition to the notes and new credit agreement described below, the Company expects to enter into an additional bridge facility in the amount of $3.0 billion on the closing date of the Merger.

- removed (2016-11-08):
[0000106040-16-000022:note_history:96]
Notes

- removed (2016-11-08):
[0000106040-16-000022:note_history:97]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Notes were issued pursuant to indentures (the “Indentures”) among (i) the Company, (ii) HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (the “WD Guarantors”) and (iii) U.S. Bank National Association, as trustee (and as collateral agent with respect to the Secured Notes). Immediately following the consummation of the Merger, SanDisk Technologies, Inc., which will be an indirect subsidiary of the Company (the “SD Guarantor”), and the other parties to the Indentures will enter into supplemental indentures and the SD Guarantor will become party to the Indentures and will agree to guarantee the Company’s obligations under the Notes. The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the Indentures) or with the proceeds of certain non-ordinary course asset sales.

- removed (2016-11-08):
[0000106040-16-000022:note_history:98]
The Company has deposited the gross proceeds from the offering of each series of Notes into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreements. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must redeem the Notes at a price equal to 100% of the initial issue price of the Notes, plus accrued and unpaid interest.

- removed (2016-11-08):
[0000106040-16-000022:note_history:99]
Prior to the release of the Notes offering proceeds from escrow, each series of Notes and the related guarantees are secured by an exclusive first-priority lien on the funds held in the respective escrow account from the issuance of such series of Notes. Following the release of the Notes offering proceeds from escrow, the Secured Notes and related guarantees will be secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the New Credit Agreement as described below and, as a result, will be effectively senior to the Unsecured Notes to the extent of the value of the assets that secure the Secured Notes and will be effectively pari passu with obligations under the New Credit Agreement and all other existing and future obligations of WDC and the WD Guarantors secured by first-priority liens on the assets securing the Secured Notes (subject to permitted liens and certain limitations).

- removed (2016-11-08):
[0000106040-16-000022:note_history:100]
New Credit Agreement

- removed (2016-11-08):
[0000106040-16-000022:note_history:101]
On April 29, 2016, the Company entered into a new credit agreement (the “New Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent (the “Administrative Agent”), and the lenders party thereto, which provides for secured loan facilities consisting of a $4.125 billion term loan facility (the “Term Loan A Facility”), a $3.75 billion term loan facility (the “U.S. Term Loan B Facility”), an €885 million term loan facility (the “Euro Term Loan B Facility” and, together with the U.S. Term Loan B Facility, the “Term Loan B Facilities”), and a $1.0 billion revolving credit facility (the “Revolving Credit Facility”). The Revolving Credit Facility includes a $200 million sublimit for letters of credit. The Term Loan B Facilities closed into escrow on April 29, 2016. Borrowings under the U.S. Term Loan B Facility bear interest at a rate per annum, at the Company's option, of either an adjusted LIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.50% or at a base rate plus an applicable margin of 4.50%. The borrowings under the Euro Term Loan B Facility bear interest at a rate per annum equal to an adjusted EURIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.25%. As of April 29, 2016, the variable interest rates on the Term Loan B Facility and the Euro Term Loan B Facility were 6.25% and 6.00%, respectively.

- removed (2016-11-08):
[0000106040-16-000022:note_history:102]
The Term Loan A Facility will close and the related proceeds will be received by the Company on the closing date of the Merger. The Revolving Credit Facility will be available starting on the closing date of the Merger. The Term Loan A Facility and the Revolving Credit Facility have terms of five years. The Term Loan B Facilities have terms of seven years. The obligations under the New Credit Agreement are guaranteed by the WD Guarantors. Immediately following the consummation of the Merger, the SD Guarantor will execute a guaranty supplement and will agree to guarantee the Company’s obligations under the New Credit Agreement. The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the Term Loan B Facilities require the Company to pay a 1.00% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before the one year anniversary of the effective date.

- removed (2016-11-08):
[0000106040-16-000022:note_history:103]
As of the date of this Quarterly Report on Form 10-Q, the outstanding balances under the New Credit Agreement were $3.75 billion for the U.S. Term Loan B Facility and €885 million for the Euro Term Loan B Facility. Beginning in September 2016, the Company is required to make quarterly principal payments on the Term Loan B Facilities equal to 0.25% of the original principal amount thereof, with the remaining balance due in 2023.

- removed (2016-11-08):
[0000106040-16-000022:note_history:104]
The Company has deposited the net proceeds of the borrowings under the Term Loan B Facilities into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreement for the Term Loan B Facilities. Prior to the release of the Term Loan B Facilities proceeds from escrow, the Administrative Agent will have a perfected first-priority lien on the funds held in the respective escrow accounts on behalf of the lenders under the Term Loan B Facilities. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must prepay in full the amount of the Term Loan B Facilities funded into escrow, plus accrued and unpaid interest.

- removed (2016-11-08):
[0000106040-16-000022:note_history:105]
At the closing of the Merger, (i) the net proceeds of the borrowings under the Term Loan B Facilities will be released from escrow and (ii) the Company will borrow the full amount of the term loans under the Term Loan A Facility and will have the ability to borrow under the Revolving Credit Facility.

- removed (2016-11-08):
[0000106040-16-000022:note_history:106]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the obligations under the New Credit Agreement will be secured on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by such entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

- removed (2016-11-08):
[0000106040-16-000022:note_history:107]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the New Credit Agreement will require the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the New Credit Agreement contains customary covenants that will apply following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, make acquisitions and investments, loans and guarantees, enter into transactions with affiliates, make certain modifications of organizational documents and certain debt agreements and merge or consolidate, and customary events of default.

- removed (2016-11-08):
[0000106040-16-000022:note_history:108]
Subject to certain exceptions and thresholds, following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the Term Loan A Facility and the Term Loan B Facilities require mandatory prepayments in connection with (i) excess cash flow (with respect to the Term Loan B Facilities only), (ii) non-ordinary course asset sales and other dispositions and (iii) the issuance of certain debt obligations, among other things. In addition, if more than $100 million in aggregate principal amount of SanDisk’s convertible notes due 2017 and 2020 remains outstanding on the date that is 90 days after the closing date of the Merger, the New Credit Agreement requires the Company to make a mandatory prepayment of the term loans under the Term Loan B Facilities in an amount equal to the outstanding amount of such convertible notes.

- removed (2016-11-08):
[0000106040-16-000022:note_history:109]
Termination of Existing Credit Agreement

- removed (2016-11-08):
[0000106040-16-000022:note_history:110]
On the closing date of the Merger, pursuant to the terms of the New Credit Agreement, Western Digital Technologies, Inc., Western Digital Ireland, Ltd. and Western Digital International Ltd. (collectively, the “Existing Borrowers”) will repay all outstanding loans, together with accrued interest, and will terminate all commitments under the credit agreement dated as of January 9, 2014, as amended, among the Company, the Existing Borrowers, the lenders party thereto and JPMorgan Chase Bank, N.A., as administrative agent.
