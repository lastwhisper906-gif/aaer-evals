# WDC notes — 0000106040-16-000040


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-16-000040:notes:1]
The following tables summarize, by major type, the fair value and cost basis of the Company’s investments classified as available-for-sale:

[0000106040-16-000040:notes:2]
|  | September 30, 2016 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
|  | (in millions) |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Government agency securities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Certificates of deposit | 222 |  |  | — |  |  | 222 |  |
| International government securities | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | 76 |  |  | — |  |  | 76 |  |
| Asset-backed securities | 19 |  |  | — |  |  | 19 |  |
| Municipal notes and bonds | 13 |  |  | — |  |  | 13 |  |
| Total | $ | 335 |  |  | $ | — |  |  | $ | 335 |  |

[0000106040-16-000040:notes:3]
|  | July 1, 2016 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
|  | (in millions) |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| U.S. Government agency securities | 10 |  |  | — |  |  | 10 |  |
| Certificates of deposit | 202 |  |  | — |  |  | 202 |  |
| International government securities | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | 96 |  |  | 1 |  |  | 97 |  |
| Asset-backed securities | 22 |  |  | — |  |  | 22 |  |
| Municipal notes and bonds | 12 |  |  | — |  |  | 12 |  |
| Total | $ | 345 |  |  | $ | 1 |  |  | $ | 346 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000106040-16-000040:notes:4]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of 2016.

[0000106040-16-000040:notes:5]
|  | Three Months Ended |
|  | October 2, 2015 |
|  | (in millions, except per share amounts) |
| Revenue, net | $ | 4,812 |  |
| Net income | 98 |  |
| Basic income per common share | $ | 0.35 |  |
| Diluted income per common share | $ | 0.35 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-16-000040:notes:6]
Acquisitions

[0000106040-16-000040:notes:7]
Fiscal 2016 Acquisition

[0000106040-16-000040:notes:8]
In May 2016, we acquired SanDisk, a global leader in NAND flash storage solutions primarily to deepen the Company’s expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000040:notes:9]
Assets Acquired and Liabilities Assumed at Fair Value

[0000106040-16-000040:notes:10]
During the period, the Company adjusted the assessment of fair value for certain acquired inventory and property and equipment and a portion of the deferred tax liability. Management is continuing to assess the values assigned to the remaining assets acquired and liabilities assumed and may make further adjustments during the measurement period (through May 11, 2017) as further information becomes available. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in adjustments to goodwill.

[0000106040-16-000040:notes:11]
Pro Forma Financial Information

[0000106040-16-000040:notes:12]
The financial information in the table below summarizes the combined results of operations for the Company and SanDisk, on a pro forma basis, as though the combination had occurred as of the beginning of 2016. The pro forma financial information for the period presented includes the effects of adjustments related to amortization charges from acquired intangible assets, depreciation charges from acquired fixed assets, interest expenses from financing the acquisition, stock-based compensation expenses from the conversion of unvested equity awards and the elimination of certain expenses directly related to the transaction. The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of 2016.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-16-000040:notes:13]
The following table presents the unfunded status of the benefit obligations for the Japanese defined benefit pension plans were as follows:

[0000106040-16-000040:notes:14]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Benefit obligations | $ | 324 |  |  | $ | 326 |  |
| Fair value of plan assets | 217 |  |  | 212 |  |
| Unfunded status | $ | 107 |  |  | $ | 114 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-16-000040:notes:15]
Commitments, Contingencies and Related Parties

[0000106040-16-000040:notes:16]
Flash Ventures

[0000106040-16-000040:notes:17]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through these ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

[0000106040-16-000040:notes:18]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-16-000040:notes:19]
During the three months ended September 30, 2016, the Company purchased NAND flash memory wafers from Flash Ventures and made loans to, and investments in, Flash Ventures totaling $127 million and $20 million, respectively, and received loan repayments from Flash Ventures of $120 million. At September 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $190 million and $168 million, respectively.

[0000106040-16-000040:notes:20]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016, is presented below. Flash Ventures’ investments are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-16-000040:notes:21]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable | $ | 580 |  |  | $ | 563 |  |
| Equity investments | 637 |  |  | 608 |  |
| Operating lease guarantees | 1,235 |  |  | 1,151 |  |
| Prepayments | 30 |  |  | 34 |  |
| Maximum estimable loss exposure | $ | 2,482 |  |  | $ | 2,356 |  |

[0000106040-16-000040:notes:22]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-16-000040:notes:23]
The following table presents, as of September 30, 2016, the notes receivable from and equity investments in Flash Ventures:

[0000106040-16-000040:notes:24]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 63 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 196 |  |  | 235 |  |
| Notes receivable, Flash Forward | 321 |  |  | 263 |  |
| Investment in Flash Partners | 205 |  |  | 202 |  |
| Investment in Flash Alliance | 310 |  |  | 306 |  |
| Investment in Flash Forward | 122 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,217 |  |  | $ | 1,171 |  |

[0000106040-16-000040:notes:25]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-16-000040:notes:26]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-16-000040:notes:27]
Off-Balance Sheet Liabilities

[0000106040-16-000040:notes:28]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-16-000040:notes:29]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016.

[0000106040-16-000040:notes:30]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 125 |  |  | $ | 1,235 |  |

[0000106040-16-000040:notes:31]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the lease agreements, in annual installments as of September 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016:

[0000106040-16-000040:notes:32]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 298 |  |  | $ | 71 |  |  | $ | 369 |  |
| Year 2 |  | 247 |  |  | 11 |  |  | 258 |  |
| Year 3 |  | 203 |  |  | 59 |  |  | 262 |  |
| Year 4 |  | 125 |  |  | 73 |  |  | 198 |  |
| Year 5 |  | 39 |  |  | 109 |  |  | 148 |  |
| Total guarantee obligations |  | $ | 912 |  |  | $ | 323 |  |  | $ | 1,235 |  |

[0000106040-16-000040:notes:33]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0000106040-16-000040:notes:34]
Investments

[0000106040-16-000040:notes:35]
The fair value of the Company’s investments classified as available-for-sale securities at September 30, 2016, by remaining contractual maturity, were as follows:

[0000106040-16-000040:notes:36]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 248 |  |  | $ | 248 |  |
| Due in one to five years (included in other non-current assets) | 87 |  |  | 87 |  |
| Total | $ | 335 |  |  | $ | 335 |  |

[0000106040-16-000040:notes:37]
The Company determined no available-for-sale securities were other-than-temporarily impaired in three months ended September 30, 2016.


## us-gaap:DebtDisclosureTextBlock

[0000106040-16-000040:notes:38]
Debt

[0000106040-16-000040:notes:39]
Debt consisted of the following as of September 30, 2016 and July 1, 2016:

[0000106040-16-000040:notes:40]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,993 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 990 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 37 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,370 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (237 | ) |  | (532 | ) |
| Subtotal | 13,133 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (78 | ) |  | (3,334 | ) |
| Long-term debt | $ | 13,055 |  |  | $ | 13,660 |  |

[0000106040-16-000040:notes:41]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of September 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

[0000106040-16-000040:notes:42]
Term Loans

[0000106040-16-000040:notes:43]
In the first quarter ended September 30, 2016, the Company settled in full the principal amounts of the $3.75 billion U.S. Term Loan B and the €885 million Euro Term Loan B, plus accrued interest. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

[0000106040-16-000040:notes:44]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement (as defined below) and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.50% at September 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $5 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $5 million remain unamortized.

[0000106040-16-000040:notes:45]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% at September 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $2 million remain unamortized.

[0000106040-16-000040:notes:46]
Credit Agreement

[0000106040-16-000040:notes:47]
On April 29, 2016, the Company entered into a new credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. As described above, during the first quarter ended September 30, 2016, the U.S. Term Loan B and Euro Term Loan B were settled and replaced with the $3.0 billion U.S. Term Loan B-1 and the €885 million Euro Term Loan B-1, respectively.

[0000106040-16-000040:notes:48]
The revolving credit facility includes a $200 million sublimit for letters of credit. As of September 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance. Beginning in September 2017, we are required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of September 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.526%.

[0000106040-16-000040:notes:49]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-16-000040:notes:50]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require us to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

[0000106040-16-000040:notes:51]
Covenants

[0000106040-16-000040:notes:52]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

[0000106040-16-000040:notes:53]
Additional Bridge Facility

[0000106040-16-000040:notes:54]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.0 billion aggregate principal amount outstanding, together with accrued interest.

[0000106040-16-000040:notes:55]
Senior Notes

[0000106040-16-000040:notes:56]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

[0000106040-16-000040:notes:57]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

[0000106040-16-000040:notes:58]
Convertible Notes, Exchange Options and Call Options

[0000106040-16-000040:notes:59]
As of July 1, 2016, the Company had outstanding, through the acquisition of SanDisk, $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

[0000106040-16-000040:notes:60]
During the three months ended September 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $490 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

[0000106040-16-000040:notes:61]
As of September 30, 2016, $37 million principal amount of the 2020 Notes and less than $1 million principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

[0000106040-16-000040:notes:62]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported in Other income (expense), net in the condensed consolidated statements of operations until the Company extinguishes the related debt. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in accrued expenses and other liabilities in the condensed consolidated balance sheets. See Note 10 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three months ended September 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.

[0000106040-16-000040:notes:63]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in other current assets and other non-current assets in the condensed consolidated balance sheets. During the three months ended September 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three months ended September 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options at September 30, 2016 was immaterial.

[0000106040-16-000040:notes:64]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three months ended September 30, 2016 resulted in a net loss of $5 million.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-16-000040:notes:65]
Derivatives

[0000106040-16-000040:notes:66]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. As of September 30, 2016, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-16-000040:notes:67]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in accumulated other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three months ended September 30, 2016 and October 2, 2015.

[0000106040-16-000040:notes:68]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges were determined to be effective as of September 30, 2016 and July 1, 2016. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three months ended September 30, 2016 and October 2, 2015.

[0000106040-16-000040:notes:69]
As of September 30, 2016, the net amount of unrealized gains with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $70 million. In addition, as of September 30, 2016, the Company did not have any foreign exchange contracts with credit-risk-related contingent features.

[0000106040-16-000040:notes:70]
See Note 10 to the condensed consolidated financial statements for additional disclosures related to the Company’s foreign exchange contracts.

[0000106040-16-000040:notes:71]
Derivative Instruments

[0000106040-16-000040:notes:72]
The fair value and balance sheet location of the Company’s derivative instruments were as follows:

[0000106040-16-000040:notes:73]
|  | Derivative Assets Reported in |
|  | Other Current Assets |  | Other Non-current Assets |
|  | September 30, 2016 |  | July 1, 2016 |  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 65 |  |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 11 |  |  | 12 |  |  | — |  |  | — |  |
| Call options | — |  |  | 70 |  |  | — |  |  | 1 |  |
| Total derivatives | $ | 76 |  |  | $ | 196 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-16-000040:notes:74]
|  | Derivative Liabilities Reported in |
|  | Accrued Expenses |  | Other Liabilities |
|  | September 30, 2016 |  | July 1, 2016 |  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 22 |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |
| Exchange option | 1 |  |  | 141 |  |  | — |  |  | 14 |  |
| Total derivatives | $ | 23 |  |  | $ | 164 |  |  | $ | — |  |  | $ | 14 |  |

[0000106040-16-000040:notes:75]
Netting Arrangements

[0000106040-16-000040:notes:76]
The following table presents the gross amounts of the Company’s derivative instruments, amounts offset due to master netting arrangements with the Company’s various counterparties and the net amounts recognized in the condensed consolidated balance sheet as of September 30, 2016:

[0000106040-16-000040:notes:77]
| Derivatives Designated as Hedging Instruments |  | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Gross Amounts Not Offset in the Balance Sheet |  | Net Amount |
|  |  |  |  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  |  | (in millions) |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets |  | $ | 70 |  |  | $ | (5 | ) |  | $ | 65 |  |  | $ | — |  |  | $ | — |  |  | $ | 65 |  |
| Financial liabilities |  | (27 | ) |  | 5 |  |  | (22 | ) |  | — |  |  | — |  |  | (22 | ) |
| Total derivative instruments |  | $ | 43 |  |  | $ | — |  |  | $ | 43 |  |  | $ | — |  |  | $ | — |  |  | $ | 43 |  |

[0000106040-16-000040:notes:78]
The Company had a gross and net liability of $91 million related to its derivative instruments outstanding at July 1, 2016. There were no amounts offset due to master netting arrangements in place at July 1, 2016.

[0000106040-16-000040:notes:79]
Effect of Foreign Exchange Contracts on the Condensed Consolidated Statements of Operations

[0000106040-16-000040:notes:80]
The impact of foreign exchange contracts on the consolidated financial statements was as follows:

[0000106040-16-000040:notes:81]
|  |  | Three Months Ended |
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in Accumulated Other Comprehensive Income on Derivatives |  | Amount of Gain (Loss) Reclassified from Accumulated Other Comprehensive Income into Income |
|  | September 30, 2016 |  | October 2, 2015 |  | September 30, 2016 |  | October 2, 2015 |
|  |  | (in millions) |
| Foreign exchange contracts |  | $ | 22 |  |  | $ | (53 | ) |  | $ | 26 |  |  | $ | (28 | ) |

[0000106040-16-000040:notes:82]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements for the three months ended September 30, 2016 and October 2, 2015.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-16-000040:notes:83]
Stock-based Compensation Expense

[0000106040-16-000040:notes:84]
The following tables present the Company’s stock-based compensation for equity-settled awards and related tax benefit by type and financial statement line included in the Company’s condensed consolidated statements of operations:

[0000106040-16-000040:notes:85]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Options | $ | 12 |  |  | $ | 14 |  |
| Employee Stock Purchase Plan | 8 |  |  | 5 |  |
| Restricted Stock Units(1) | 79 |  |  | 23 |  |
| Subtotal | 99 |  |  | 42 |  |
| Tax benefit | (25 | ) |  | (10 | ) |
| Total | $ | 74 |  |  | $ | 32 |  |

[0000106040-16-000040:notes:86]
| (1) | Restricted stock units (“RSUs”) include performance stock units (“PSUs”) |

[0000106040-16-000040:notes:87]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Cost of Revenue | $ | 13 |  |  | $ | 5 |  |
| Research and Development | 44 |  |  | 15 |  |
| Selling, General and Administrative | 42 |  |  | 22 |  |
| Subtotal | 99 |  |  | 42 |  |
| Tax benefit | (25 | ) |  | (10 | ) |
| Total | $ | 74 |  |  | $ | 32 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-16-000040:notes:88]
Net Income (Loss) Per Common Share

[0000106040-16-000040:notes:89]
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-16-000040:notes:90]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (366 | ) |  | $ | 283 |  |
| Weighted average shares outstanding: |  |  |  |
| Basic | 285 |  |  | 231 |  |
| Employee stock options, RSUs, PSUs, ESPP | — |  |  | 3 |  |
| Diluted | 285 |  |  | 234 |  |
| Income (loss) per common share |  |  |  |
| Basic | $ | (1.28 | ) |  | $ | 1.23 |  |
| Diluted | $ | (1.28 | ) |  | $ | 1.21 |  |
| Anti-dilutive potential common shares excluded(1) | 5 |  |  | 4 |  |

[0000106040-16-000040:notes:91]
| (1) | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-16-000040:notes:92]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s ESPP, awards of RSUs and exchange options related to the Company’s Convertible Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000106040-16-000040:notes:93]
The following is a reconciliation of the call options reported in other current assets and other non-current assets in the Company’s condensed consolidated balance sheets as of September 30, 2016.

[0000106040-16-000040:notes:94]
|  | 2017 Call Options |  | 2020 Call Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 70 |  |  | $ | 1 |  |  | $ | 71 |  |
| Net realized gain | — |  |  | (1 | ) |  | (1 | ) |
| Redemptions | (70 | ) |  | — |  |  | (70 | ) |
| Fair value at September 30, 2016 | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-16-000040:notes:95]
Fair Value Measurements

[0000106040-16-000040:notes:96]
Financial Instruments Carried at Fair Value

[0000106040-16-000040:notes:97]
[same as prior period, unchanged from 0000106040-16-000022:notes:63]

[0000106040-16-000040:notes:98]
| Level 1. | Quoted prices in active markets for identical assets or liabilities. |

[0000106040-16-000040:notes:99]
| Level 2. | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000106040-16-000040:notes:100]
| Level 3. | Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities. |

[0000106040-16-000040:notes:101]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of September 30, 2016 and July 1, 2016, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-16-000040:notes:102]
|  | September 30, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,355 |  |
| Certificates of deposit | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents | 1,355 |  |  | 6 |  |  | — |  |  | 1,361 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 222 |  |  | — |  |  | 222 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total short-term investments | — |  |  | 248 |  |  | — |  |  | 248 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 64 |  |  | — |  |  | 64 |  |
| Asset-backed securities | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total long-term investments | — |  |  | 87 |  |  | — |  |  | 87 |  |
| Foreign exchange contracts | — |  |  | 76 |  |  | — |  |  | 76 |  |
| Total assets at fair value | $ | 1,355 |  |  | $ | 417 |  |  | $ | — |  |  | $ | 1,772 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Exchange option | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 22 |  |  | $ | 1 |  |  | $ | 23 |  |

[0000106040-16-000040:notes:103]
|  | July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,199 |  |
| Certificates of deposit | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 2,199 |  |  | 1 |  |  | — |  |  | 2,200 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202 |  |  | — |  |  | 202 |  |
| Corporate notes and bonds | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total short-term investments | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total long-term investments | 2 |  |  | 117 |  |  | — |  |  | 119 |  |
| Foreign exchange contracts | — |  |  | 126 |  |  | — |  |  | 126 |  |
| Call options | — |  |  | — |  |  | 71 |  |  | 71 |  |
| Total assets at fair value | $ | 2,201 |  |  | $ | 471 |  |  | $ | 71 |  |  | $ | 2,743 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Exchange option | — |  |  | — |  |  | 155 |  |  | 155 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 23 |  |  | $ | 155 |  |  | $ | 178 |  |

[0000106040-16-000040:notes:104]
[same as prior period, unchanged from 0000106040-16-000022:notes:70]

[0000106040-16-000040:notes:105]
[same as prior period, unchanged from 0000106040-16-000022:notes:71]

[0000106040-16-000040:notes:106]
U.S. and International Government Agency Securities. The Company’s U.S. and International Government agency securities are investments in fixed income securities sponsored by the U.S. and International Government and are held in custody by a third party. U.S. and International Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000040:notes:107]
Asset-Backed Securities, and Corporate and Municipal Notes and Bonds. The Company’s asset-backed securities, and Corporate and Municipal notes and bonds securities are investments issued by corporations and U.S. state municipalities which are held in custody by a third party. Asset-backed securities, and Corporate and Municipal notes and bonds are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000040:notes:108]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000040:notes:109]
[same as prior period, unchanged from 0000106040-16-000022:notes:74]

[0000106040-16-000040:notes:110]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the condensed consolidated balance sheets. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 12 to the condensed consolidated financial statements.

[0000106040-16-000040:notes:111]
During the three months ended September 30, 2016 and October 2, 2015, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-16-000040:notes:112]
Assets and Liabilities Measured at Fair Value on a Recurring Basis Using Significant Unobservable Inputs (Level 3)

[0000106040-16-000040:notes:113]
The fair value measurement of the call options and exchange options arising from the assumed Convertible Notes which are not actively traded, is determined using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) economic incentive for holders to exercise their exchange options. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-16-000040:notes:114]
There were no transfers of call options or exchange options out of Level 3 for three months ended September 30, 2016.

[0000106040-16-000040:notes:115]
The following is a reconciliation of the exchange options reported in accrued expenses and other liabilities in the Company’s condensed consolidated balance sheets as of September 30, 2016.

[0000106040-16-000040:notes:116]
|  | 2017 Exchange Options |  | 2020 Exchange Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 87 |  |  | $ | 68 |  |  | $ | 155 |  |
| Net realized gain | (3 | ) |  | (31 | ) |  | (34 | ) |
| Redemptions | (83 | ) |  | (46 | ) |  | (129 | ) |
| Net unrealized loss | — |  |  | 9 |  |  | 9 |  |
| Fair value at September 30, 2016 | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-16-000040:notes:117]
Financial Instruments Not Carried at Fair Value

[0000106040-16-000040:notes:118]
For those financial instruments where the carrying amounts differ from fair value, the following table represents the related carrying values and fair values, which are based on quoted market prices. Each of the debt instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2017 and the fourth quarter of 2016, respectively.

[0000106040-16-000040:notes:119]
|  | September 30, 2016 |  | July 1, 2016 |
|  | Aggregated Principal |  | Aggregated Fair Value |  | Aggregated Principal |  | Aggregated Fair Value |
|  | (in millions) |
| Secured Notes | $ | 1,875 |  |  | $ | 2,044 |  |  | $ | 1,875 |  |  | $ | 2,044 |  |
| Unsecured Notes | 3,350 |  |  | 3,891 |  |  | 3,350 |  |  | 3,575 |  |
| Term Loan A | 4,125 |  |  | 4,084 |  |  | 4,125 |  |  | 4,161 |  |
| U.S. Term Loan B | — |  |  | — |  |  | 3,750 |  |  | 3,773 |  |
| U.S. Term Loan B-1 | 2,993 |  |  | 3,029 |  |  | — |  |  | — |  |
| Euro Term Loan B | — |  |  | — |  |  | 987 |  |  | 981 |  |
| Euro Term Loan B-1 | 990 |  |  | 1,006 |  |  | — |  |  | — |  |
| Bridge Loan | — |  |  | — |  |  | 3,000 |  |  | 3,000 |  |
| Total | $ | 13,333 |  |  | $ | 14,054 |  |  | $ | 17,087 |  |  | $ | 17,534 |  |

[0000106040-16-000040:notes:120]
Cost Method Investments

[0000106040-16-000040:notes:121]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. As of September 30, 2016 and July 1, 2016, the Company had aggregate net investments under the cost method of accounting of $129 million and $135 million, respectively, and these investments consisted of privately-held equity securities without a readily determinable fair value. The Company has determined that it is not practicable to estimate the fair value of these investments. These privately-held equity investments are reported under other non-current assets in the condensed consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-16-000040:notes:122]
Income Tax Expense

[0000106040-16-000040:notes:123]
The following table presents the income tax expense and the effective tax rate:

[0000106040-16-000040:notes:124]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Income tax expense | $ | 95 |  |  | $ | 31 |  |
| Effective tax rate | (35 | )% |  | 10 | % |

[0000106040-16-000040:notes:125]
Income tax expense of $95 million for the three months ended September 30, 2016 is attributable to discrete effects consisting of income tax expense from the integration of SanDisk of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt refinancing of $96 million and from decreases in the Company’s liability for unrecognized tax benefits due to lapses in the statute of limitations of $8 million. These discrete items are the primary drivers of the negative effective tax rate for the three months ended September 30, 2016.

[0000106040-16-000040:notes:126]
The primary drivers for the difference between the effective tax rate for the three months ended September 30, 2016 and the U.S. Federal statutory rate of 35% are the discrete items described above, the current year generation of tax credits and tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029. For the three months ended October 2, 2015, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029.

[0000106040-16-000040:notes:127]
In the three months ended September 30, 2016, the Company recorded a net decrease of $6 million in its liability for unrecognized tax benefits. As of September 30, 2016, the Company’s liability for unrecognized tax benefits was approximately $485 million. Accrued interest and penalties related to unrecognized tax benefits as of September 30, 2016 was $78 million.

[0000106040-16-000040:notes:128]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-16-000040:notes:129]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of September 30, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-16-000040:notes:130]
Legal Proceedings

[0000106040-16-000040:notes:131]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-16-000040:notes:132]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-16-000040:notes:133]
Intellectual Property Litigation

[0000106040-16-000040:notes:134]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-16-000040:notes:135]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

[0000106040-16-000040:notes:136]
Antitrust

[0000106040-16-000040:notes:137]
On June 25, 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint captioned Ritz Camera & Image, LLC v. SanDisk Corporation, Inc. and Eliyahou Harari in the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 25, 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. On February 24, 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. On May 14, 2015, the District Court granted in part plaintiffs’ motion for class certification. On April 29, 2016, the court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk's favor as to all of the plaintiffs’ claims. On May 31, 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

[0000106040-16-000040:notes:138]
On July 15, 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) in the U.S. District Court for the Northern District of California, alleging that defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. On August 25, 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint on September 16, 2011. On January 3, 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. On April 4, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint on January 20, 2015. On September 30, 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. On October 21, 2015, Samsung filed a fourth amended complaint. On November 4, 2015, the defendants filed a motion to dismiss. On September 26, 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

[0000106040-16-000040:notes:139]
On March 15, 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. in the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of Secure Digital (“SD”) cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD™ cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. On May 21, 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. On May 14, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. On February 3, 2015, the plaintiffs filed a second amended complaint in the District Court. On September 30, 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. On November 4, 2015, the plaintiffs filed a third amended complaint. On November 25, 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. On October 3, 2016, the District Court granted the defendants’ motion with leave to amend. On October 21, 2016, the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000040:notes:140]
Securities

[0000106040-16-000040:notes:141]
Beginning on March 30, 2015, SanDisk and two officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed in the United States District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 16, 2014 and March 25, 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 16, 2014 and April 15, 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. On July 9, 2015, the Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. On January 22, 2016, the court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. On February 22, 2016, the court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). On March 23, 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss on April 29, 2016. On June 24, 2016, the court granted the motion and dismissed the amended complaint with leave to amend. On July 15, 2016, the Institutional Investor Group filed a further amended complaint. The Company filed a motion to dismiss on August 19, 2016. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000040:notes:142]
Other Matters

[0000106040-16-000040:notes:143]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000040:notes:144]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000040:notes:145]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows. It is reasonably possible that the Company may incur losses totaling up to $133 million, including the amounts accrued.

[0000106040-16-000040:notes:146]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-16-000040:notes:147]
Basis of Presentation

[0000106040-16-000040:notes:148]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the needs of the information technology industry and the infrastructure that enables the storage of data. The Company also generates license and royalty revenue related to its intellectual property.

[0000106040-16-000040:notes:149]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-16-000040:notes:150]
Fiscal Year

[0000106040-16-000040:notes:151]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal year 2017, which ends on June 30, 2017, and fiscal year 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-16-000040:notes:152]
Reclassifications

[0000106040-16-000040:notes:153]
Certain prior year amounts have been reclassified in the condensed consolidated statement of cash flows to conform to the current year presentation.

[0000106040-16-000040:notes:154]
Use of Estimates

[0000106040-16-000040:notes:155]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-16-000040:notes:156]
Accounting Changes and Recent Accounting Pronouncements

[0000106040-16-000040:notes:157]
Recently Adopted

[0000106040-16-000040:notes:158]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015-05 at the beginning of the current year did not have a material impact on its condensed consolidated financial statements.

[0000106040-16-000040:notes:159]
Recently Issued

[0000106040-16-000040:notes:160]
In October 2016, the FASB issued ASU No. 2016-16, “Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). The new standard removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The ASU is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

[0000106040-16-000040:notes:161]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230)” (“ASU 2016-15”). The new standard addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which among others, includes the Company’s disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2019. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000040:notes:162]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within those years, which for the Company is the first quarter of 2018. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2018. The Company is currently evaluating the impact ASU 2016-09 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000040:notes:163]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for the Company is the first quarter of 2020. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2020. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000040:notes:164]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”), which provides guidance related to accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is not permitted. The Company is currently evaluating the impact ASU 2016-01 will have on its consolidated financial statements.

[0000106040-16-000040:notes:165]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (“ASU 2014-09”), which amends the guidance in former Accounting Standards Codification Topic 605, “Revenue Recognition,” to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The Company does not expect the proposed standard to materially change the timing of revenue recognition for product revenue; however, the proposed standard may accelerate the timing of revenue recognition for the Company’s license and royalty contracts. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2015-14 by one year. The new standard allows for either a full retrospective or a modified retrospective transition method. Early application is permitted only as of annual reporting periods beginning after December 15, 2016, which for the Company is the first quarter of 2018. The Company has not yet selected a transition method and currently expects to adopt this standard in the first quarter of 2019.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-16-000040:notes:166]
Pension and Other Post-Retirement Benefit Plans

[0000106040-16-000040:notes:167]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans are immaterial to the Company’s condensed consolidated financial statements. The expected long-term rate of return on the Japanese plan assets is 2.5%.

[0000106040-16-000040:notes:168]
Obligations and Funded Status

[0000106040-16-000040:notes:169]
The following table presents the unfunded amounts related to the Japanese defined pension plans as recognized on the Company’s condensed consolidated balance sheets:

[0000106040-16-000040:notes:170]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Non-current liabilities | $ | 107 |  |  | $ | 114 |  |
| Net amount recognized | $ | 107 |  |  | $ | 114 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-16-000040:notes:171]
Property, Plant and Equipment

[0000106040-16-000040:notes:172]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and buildings | $ | 1,920 |  |  | $ | 1,900 |  |
| Machinery and equipment | 7,155 |  |  | 7,070 |  |
| Furniture and fixtures | 50 |  |  | 110 |  |
| Leasehold improvements | 313 |  |  | 307 |  |
| Construction-in-process | 149 |  |  | 245 |  |
| Property, plant and equipment, gross | $ | 9,587 |  |  | $ | 9,632 |  |
| Accumulated depreciation | (6,228 | ) |  | (6,129 | ) |
| Property, plant and equipment, net | $ | 3,359 |  |  | $ | 3,503 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-16-000040:notes:173]
The following table illustrates the significant amounts reclassified out of each component of accumulated comprehensive income (loss) (“AOCI”):

[0000106040-16-000040:notes:174]
|  |  | Three Months Ended |  |  |
| AOCI Component |  | September 30, 2016 |  | October 2, 2015 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on cash flow hedging activities: |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 24 |  |  | $ | (28 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | 2 |  |  | — |  |  | Research and development |
| Unrealized holding gain (loss) on cash flow hedging activities |  | $ | 26 |  |  | $ | (28 | ) |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-16-000040:notes:175]
Other comprehensive income (loss), net of tax refers to expenses, gains and losses that are recorded as an element of stockholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss):

[0000106040-16-000040:notes:176]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Foreign Exchange Contracts |  | Total Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 1, 2016 | $ | (45 | ) |  | $ | 74 |  |  | $ | 74 |  |  | $ | 103 |  |
| Other comprehensive income before reclassifications | 5 |  |  | 17 |  |  | 22 |  |  | 44 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | (26 | ) |  | (26 | ) |
| Income tax expense related to items of other comprehensive income | (1 | ) |  | (5 | ) |  | — |  |  | (6 | ) |
| Net current-period other comprehensive income (loss) | 4 |  |  | 12 |  |  | (4 | ) |  | 12 |  |
| Balance at September 30, 2016 | $ | (41 | ) |  | $ | 86 |  |  | $ | 70 |  |  | $ | 115 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-16-000040:notes:177]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 1, 2016 | $ | 9,951 |  |
| Purchase price adjustments to goodwill | 15 |  |
| Foreign currency translation adjustment | 1 |  |
| Balance at September 30, 2016 | $ | 9,967 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0000106040-16-000040:notes:178]
Intangible Assets

[0000106040-16-000040:notes:179]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 3,539 |  |  | $ | 3,539 |  |
| In-process research and development | 2,435 |  |  | 2,435 |  |
| Accumulated amortization | (1,183 | ) |  | (940 | ) |
| Intangible assets, net | $ | 4,791 |  |  | $ | 5,034 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-16-000040:notes:180]
Inventories

[0000106040-16-000040:notes:181]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 610 |  |  | $ | 569 |  |
| Work-in-process | 680 |  |  | 589 |  |
| Finished goods | 819 |  |  | 971 |  |
| Total inventories | $ | 2,109 |  |  | $ | 2,129 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-16-000040:notes:182]
Product Warranty Liability

[0000106040-16-000040:notes:183]
Changes in the warranty accrual were as follows:

[0000106040-16-000040:notes:184]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 279 |  |  | $ | 221 |  |
| Charges to operations | 47 |  |  | 45 |  |
| Utilization | (45 | ) |  | (54 | ) |
| Changes in estimate related to pre-existing warranties | (4 | ) |  | 6 |  |
| Warranty accrual, end of period | $ | 277 |  |  | $ | 218 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-16-000040:notes:185]
The following table presents an analysis of the components of the activity against the reserve during the three months ended September 30, 2016:

[0000106040-16-000040:notes:186]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 11 |  |  | $ | 3 |  |  | $ | 14 |  |
| Charges | 37 |  |  | — |  |  | 37 |  |
| Cash payments | (22 | ) |  | — |  |  | (22 | ) |
| Non-cash items and other | 6 |  |  | — |  |  | 6 |  |
| Accrual balance at September 30, 2016 | $ | 32 |  |  | $ | 3 |  |  | $ | 35 |  |

[0000106040-16-000040:notes:187]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Charges | 2 |  |  | 2 |  |  | 4 |  |
| Cash payments | (9 | ) |  | (5 | ) |  | (14 | ) |
| Non-cash items and other | — |  |  | 3 |  |  | 3 |  |
| Accrual balance at September 30, 2016 | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0000106040-16-000040:notes:188]
The Company recorded the following charges related to employee terminations benefits, asset impairment and other charges:

[0000106040-16-000040:notes:189]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |
| Restructuring Plan 2016 | $ | 27 |  |  | $ | — |  |
| Closure of Foreign Manufacturing Facility | 4 |  |  | — |  |
| Business Realignment | 37 |  |  | 48 |  |
| Total employee termination and other charges | 68 |  |  | 48 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |
| Restructuring Plan 2016 | (1 | ) |  | — |  |
| Business Realignment | 1 |  |  | — |  |
| Total stock-based compensation accelerations and adjustments | — |  |  | — |  |
| Asset impairment: |  |  |  |
| Business Realignment | — |  |  | 8 |  |
| Total asset impairment | — |  |  | 8 |  |
| Total employee termination and other charges, stock-based compensation adjustments and asset impairments | $ | 68 |  |  | $ | 56 |  |

[0000106040-16-000040:notes:190]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| Charges | 8 |  |  | 19 |  |  | 27 |  |
| Cash payments | (21 | ) |  | (19 | ) |  | (40 | ) |
| Non-cash items and other | 1 |  |  | — |  |  | 1 |  |
| Accrual balance at September 30, 2016 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-16-000040:notes:191]
Stock Option Activity

[0000106040-16-000040:notes:192]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-16-000040:notes:193]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 1, 2016 | 9.0 |  |  | $ | 55.74 |  |  | 3.9 |  | $ | 60 |  |
| Granted | 2.8 |  |  |  |  |  |  |  |  |
| Exercised | (0.8 | ) |  |  |  |  |  |  |  |
| Canceled or expired | (0.3 | ) |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2016 | 10.7 |  |  | 54.30 |  |  | 4.6 |  |  | 140 |  |
| Exercisable at September 30, 2016 | 5.0 |  |  | 51.79 |  |  | 3.0 |  |  | 79 |  |
| Vested and expected to vest after September 30, 2016 | 10.3 |  |  | 54.38 |  |  | 4.5 |  |  | 136 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-16-000040:notes:194]
RSU and PSU Activity

[0000106040-16-000040:notes:195]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-16-000040:notes:196]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
|  | (in millions) |  |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | $ | 41.92 |  |
| Granted | 5.1 |  |  | 44.98 |  |
| Vested | (1.6 | ) |  | 72.36 |  |
| Forfeited | (0.5 | ) |  | 46.47 |  |
| RSUs and PSUs outstanding at September 30, 2016 | 18.7 |  |  | 42.64 |  |
| Expected to vest after September 30, 2016 | 17.4 |  |  | 42.64 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-16-000040:notes:197]
Shareholders’ Equity

[0000106040-16-000040:notes:198]
As of September 30, 2016, total compensation cost related to unvested stock options was $97 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.9 years. As of September 30, 2016, total compensation cost related to the Company’s Employee Stock Purchase Plan (“ESPP”) rights issued to employees but not yet recognized was $46 million and will be amortized on a straight-line basis over a weighted average service period of approximately 1.7 years.

[0000106040-16-000040:notes:199]
As of September 30, 2016, the aggregate unamortized fair value of all unvested RSUs and PSUs was $685 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 2.8 years, assuming the performance metrics are met for the PSUs.

[0000106040-16-000040:notes:200]
As of September 30, 2016, the Company had options outstanding to purchase an aggregate of 7.3 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $140 million at that date.

[0000106040-16-000040:notes:201]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The aggregate value of RSUs and PSUs that became fully-vested during the three months ended September 30, 2016 was $76 million, determined as of the vest date.

[0000106040-16-000040:notes:202]
SARs Activity

[0000106040-16-000040:notes:203]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| SAR expense (benefit) | $ | 5 |  |  | $ | (1 | ) |
| Tax expense (benefit) | (1 | ) |  | — |  |
| Total SAR expense (benefit) | $ | 4 |  |  | $ | (1 | ) |

[0000106040-16-000040:notes:204]
As of September 30, 2016, all outstanding stock appreciation rights (“SARs”) issued to employees were fully vested, and the fair values are solely subject to market price fluctuations. As of September 30, 2016, 0.5 million SARs were outstanding with a weighted average exercise price of $6.17.

[0000106040-16-000040:notes:205]
The Company’s SARs will be settled in cash upon exercise. The Company had a total liability of $24 million and $20 million related to SARs included in accrued expenses in the Company’s condensed consolidated balance sheet as of September 30, 2016 and July 1, 2016, respectively.

[0000106040-16-000040:notes:206]
Stock Repurchase Program

[0000106040-16-000040:notes:207]
The Company’s Board of Directors (the “Board”) has authorized $5.0 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares during the three months ended September 30, 2016. The remaining amount available to be purchased under the Company’s stock repurchase program as of September 30, 2016 was $2.1 billion.

[0000106040-16-000040:notes:208]
Dividends to Shareholders

[0000106040-16-000040:notes:209]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. The Company paid $142 million in cash of dividends on July 15, 2016 relating to dividends declared on May 3, 2016.

[0000106040-16-000040:notes:210]
On August 3, 2016, the Company’s Board of Directors declared a cash dividend for the quarter ended September 30, 2016 of $0.50 per share of the Company’s common stock, $0.01 par value per share. The cash dividend of $143 million was paid on October 17, 2016 to the Company’s stockholders of record as of September 30, 2016.

[0000106040-16-000040:notes:211]
On November 3, 2016, the Company’s Board of Directors declared a cash dividend for the quarter ended December 30, 2016 of $0.50 per share of the Company’s common stock, $0.01 par value per share. The cash dividend will be paid on January 17, 2017 to shareholders of record as of December 30, 2016.

[0000106040-16-000040:notes:212]
The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-16-000040:notes:213]
Supplemental Financial Statement Data

[0000106040-16-000040:notes:214]
Accounts receivables

[0000106040-16-000040:notes:215]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. During the three months ended September 30, 2016, the Company did not sell any trade accounts receivables. During the three months ended October 2, 2015, the Company sold trade accounts receivable and received cash proceeds of $200 million. The discounts on the trade accounts receivables sold during the three months ended October 2, 2015 were not material and were recorded within Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-16-000040:notes:216]
Goodwill

[0000106040-16-000040:notes:217]
The purchase price adjustments resulted from adjustments to the assessment of fair value for certain acquired inventory and property and equipment and a portion of the deferred tax liability related to the acquisition of SanDisk Corporation (“SanDisk”). See Note 14 to the condensed consolidated financial statements for additional disclosures related to these adjustments.

[0000106040-16-000040:notes:218]
The long-term portion of the warranty accrual classified in other liabilities was $107 million at September 30, 2016 and July 1, 2016.

[0000106040-16-000040:notes:219]
Accumulated Other Comprehensive Income (Loss)


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-16-000040:notes:220]
Employee Termination, Asset Impairment and Other Charges

[0000106040-16-000040:notes:221]
Restructuring Plan 2016

[0000106040-16-000040:notes:222]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (the “Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. The following table presents an analysis of the components of the activity against the reserve during the three months ended September 30, 2016:

[0000106040-16-000040:notes:223]
Closure of Foreign Manufacturing Facility

[0000106040-16-000040:notes:224]
In January 2016, the Company announced the closing of its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. As of September 30, 2016, the Company substantially completed all activities related to the closure of the facility. The following table presents an analysis of the components of the activity against the reserve during the three months ended September 30, 2016:

[0000106040-16-000040:notes:225]
Business Realignment

[0000106040-16-000040:notes:226]
The Company periodically incurs charges to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the three months ended September 30, 2016:
