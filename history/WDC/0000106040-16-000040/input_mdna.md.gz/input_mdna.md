# WDC MD&A — 0000106040-16-000040


## mdna

[0000106040-16-000040:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000106040-16-000040:mdna:2]
[same as prior period, unchanged from 0000106040-16-000022:mdna:3]

[0000106040-16-000040:mdna:3]
[same as prior period, unchanged from 0000106040-16-000022:mdna:17]

[0000106040-16-000040:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. Our broad portfolio of offerings addresses three categories: Data Center Devices and Solutions (capacity and performance enterprise hard disk drives (“HDD”), enterprise solid-state drives (“SSD”), data center software and system solutions); Client Devices (mobile, desktop, gaming and digital video hard drives, client SSDs, embedded products and wafers); and Client Solutions (removable products, hard drive content solutions and flash content solutions). We also generate license and royalty revenue related to our intellectual property which is included in each of the three categories.

[0000106040-16-000040:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2017, which ends on June 30, 2017, and 2016, which ended July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-16-000040:mdna:6]
[same as prior period, unchanged from 0000106040-16-000022:mdna:20]

[0000106040-16-000040:mdna:7]
Debt Facilities

[0000106040-16-000040:mdna:8]
During the first quarter of 2017, we settled certain debt facilities and entered into new debt facilities at more favorable rates. The financing arrangement activities during the quarter were:

[0000106040-16-000040:mdna:9]
| • | We paid in full, with accrued interest, our $3.0 billion short-term senior secured bridge credit agreement. |

[0000106040-16-000040:mdna:10]
| • | We settled our $3.750 billion U.S. Term Loan B tranche with a new issuance of a $3.0 billion seven-year U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) at an interest rate lower than our U.S. Term Loan B tranche. Proceeds from this new loan and a voluntary cash prepayment of $750 million were used to settle our U.S. Term Loan B tranche. |

[0000106040-16-000040:mdna:11]
| • | We settled our €885 million Euro Term Loan B tranche with a new issuance of a €885 million seven-year Euro-denominated term loan (“Euro Term Loan B-1”) at an interest rate lower than our Euro Term Loan B tranche. Proceeds from this new loan were used to settle our Euro Term Loan B tranche. |

[0000106040-16-000040:mdna:12]
| • | We paid to the holders of our Convertible Notes (as defined below), for conversion and repurchase, $490 million of cash and 0.3 million shares of our common stock with an aggregate value of $16 million. In conjunction with the settlements, we received from the exercise of the related call options, $61 million of cash and 0.1 million shares of our common stock which had an aggregate value of $11 million. |

[0000106040-16-000040:mdna:13]
For additional information regarding our debt facilities, see Part I, Item 1, Note 4, in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:14]
Unis Joint Venture

[0000106040-16-000040:mdna:15]
In November 2015, we entered into an agreement to form a joint venture with Unisplendour Corporation Limited (“Unis”) to market and sell our current data center storage systems in China and to develop data storage systems for the Chinese market in the future. The joint venture became operational during the first quarter of 2017. The joint venture is 49% owned by us and 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd. The financial results of this joint venture did not have a material impact on our condensed consolidated financial statements for the first quarter of 2017.

[0000106040-16-000040:mdna:16]
39

[0000106040-16-000040:mdna:17]
[same as prior period, unchanged from 0000106040-16-000022:mdna:53]

[0000106040-16-000040:mdna:18]
First Quarter Overview

[0000106040-16-000040:mdna:19]
The following table sets forth, for the periods presented, selected summary information from our condensed consolidated statements of operations by dollars and percentage of net revenue:

[0000106040-16-000040:mdna:20]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 4,714 |  |  | 100.0 | % |  | $ | 3,360 |  |  | 100.0 | % |  | 40 | % |
| Gross profit | 1,335 |  |  | 28.3 |  |  | 955 |  |  | 28.4 |  |  | 40 |  |
| Total operating expenses | 1,103 |  |  | 23.4 |  |  | 633 |  |  | 18.8 |  |  | 74 |  |
| Operating income | 232 |  |  | 4.9 |  |  | 322 |  |  | 9.6 |  |  | (28 | ) |
| Net income (loss) | (366 | ) |  | (7.8 | ) |  | 283 |  |  | 8.4 |  |  | (229 | ) |

[0000106040-16-000040:mdna:21]
The following is a summary of our financial performance for the first quarter of 2017 compared to the first quarter of 2016:

[0000106040-16-000040:mdna:22]
| • | Net revenue increased by 40.3% to $4.7 billion on higher revenues related to our NAND-flash memory products due primarily to our acquisition of SanDisk Corporation (“SanDisk”), partially offset by lower HDD unit shipments, as compared to net revenue of $3.4 billion in the prior year. |

[0000106040-16-000040:mdna:23]
| • | Gross profit as a percentage of net revenue was 28.3%, as compared to 28.4% in the prior year. |

[0000106040-16-000040:mdna:24]
| • | Operating income decreased to $232 million, as compared to $322 million in the prior year. Operating income in the first quarter of 2017 included $263 million of amortization of intangible assets and $68 million of employee termination, contract terminations and other charges, as compared to $23 million and $56 million in the first quarter of 2016, respectively. |

[0000106040-16-000040:mdna:25]
| • | The first quarter of 2017 reflected a net loss of $366 million, or a loss of $1.28 per diluted share, as compared to net income of $283 million, or income of $1.21 per diluted share, in the prior year. |

[0000106040-16-000040:mdna:26]
The following table sets forth, for the periods presented, summary information regarding unit shipments, average selling prices (“ASPs”) and net revenues by geography and channel:

[0000106040-16-000040:mdna:27]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions, except percentages and ASPs) |
| Revenue, net | $ | 4,714 |  |  | $ | 3,360 |  |
| HDD ASPs (per unit) | $ | 61 |  |  | $ | 60 |  |
| Revenues by Geography (%) |  |  |  |
| Americas | 40 | % |  | 30 | % |
| Europe, Middle East and Africa | 16 |  |  | 21 |  |
| Asia | 44 |  |  | 49 |  |
| Revenues by Channel (%) |  |  |  |
| Original Equipment Manufacturers | 64 | % |  | 67 | % |
| Distributors | 17 |  |  | 21 |  |
| Retailers | 19 |  |  | 12 |  |
| HDD Unit Shipments |  |  |  |
| PC | 24 |  |  | 28 |  |
| Non-PC | 24 |  |  | 24 |  |
| Total units shipped | 48 |  |  | 52 |  |

[0000106040-16-000040:mdna:28]
40

[0000106040-16-000040:mdna:29]
[same as prior period, unchanged from 0000106040-16-000022:mdna:54]

[0000106040-16-000040:mdna:30]
Net revenue for the three months ended September 30, 2016 increased $1.35 billion, or 40%, from the prior year, which reflects an increase from NAND-flash products from our acquisition of SanDisk, partially offset by lower HDD unit shipments. Total HDD shipments for the three months ended September 30, 2016 decreased to 48 million units, as compared to 52 million units in the prior year, primarily due to lower HDD shipments for personal computer (“PC”) and performance enterprise. This was partially offset by an increase in HDD ASP per unit of $1 from the prior year, primarily due to a change in product mix driven by increased capacity enterprise shipments.

[0000106040-16-000040:mdna:31]
For the three months ended September 30, 2016, no customer accounted for 10% or more of our net revenue. For the three months ended October 2, 2015, one customer, Hewlett-Packard Company, accounted for 13% of our net revenue. For the three months ended September 30, 2016 and October 2, 2015, our top 10 customers accounted for 43% and 44%, respectively, of our net revenue.

[0000106040-16-000040:mdna:32]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For each of the three months ended September 30, 2016 and October 2, 2015, these programs represented 8% and 11% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-16-000040:mdna:33]
Net Revenue by Geography

[0000106040-16-000040:mdna:34]
Changes in the mix of net revenue by geography for the three months ended September 30, 2016, compared to the prior year, reflect the additional revenues from NAND-flash products from our acquisition of SanDisk which have a larger market in the Americas.

[0000106040-16-000040:mdna:35]
Net Revenue by Channel

[0000106040-16-000040:mdna:36]
Changes in the mix of net revenue by channel for the three months ended September 30, 2016, compared to the prior year, also reflect the increase in revenues from NAND-flash products from our acquisition of SanDisk which has a higher market presence in retail.

[0000106040-16-000040:mdna:37]
Gross Profit and Gross Margin

[0000106040-16-000040:mdna:38]
Gross profit for the three months ended September 30, 2016 was $1.3 billion, an increase of $380 million from the prior year driven by the increased revenues from NAND-flash products from our acquisition of SanDisk. Gross profit as a percentage of net revenue was 28.3% in the three months ended September 30, 2016, as compared to 28.4% in the prior year. Gross profit in the current year was negatively impacted by amortization expense on acquired intangible assets, acquisition related charges, and charges related to the implementation of cost-saving initiatives, which aggregated $249 million or 5.3% of revenue, compared to $17 million or 0.5% in the prior year. The current year costs were largely offset by higher margins on NAND-flash memory products, increased HDD ASPs, and cost improvements resulting from increased volumes and integration activities.

[0000106040-16-000040:mdna:39]
[same as prior period, unchanged from 0000106040-16-000022:mdna:64]

[0000106040-16-000040:mdna:40]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Research and development | $ | 639 |  |  | 13.6 | % |  | $ | 385 |  |  | 11.5 | % |  | 66 | % |
| Selling, general and administrative | 396 |  |  | 8.4 |  |  | 192 |  |  | 5.7 |  |  | 106 |  |
| Employee termination, asset impairment and other charges | 68 |  |  | 1.4 |  |  | 56 |  |  | 1.7 |  |  | 21 |  |
| Total operating expenses | $ | 1,103 |  |  | 23.4 |  |  | $ | 633 |  |  | 18.8 |  |  | 74 |  |

[0000106040-16-000040:mdna:41]
The increase in research and development (“R&D”) expense in the three months ended September 30, 2016, compared to the prior year, was primarily related to our acquisition of SanDisk and continued development of NAND technology to complement our existing product offerings. These costs were partially offset by cost savings from our integration activities.

[0000106040-16-000040:mdna:42]
The increase in selling, general and administrative (“SG&A”) expense in the three months ended September 30, 2016, compared to the prior year, was primarily related to our acquisition of SanDisk. The current year also included an aggregate of $77 million in charges related to amortization expense on acquired intangible assets, acquisition related charges, and charges related to the implementation of cost-saving initiatives, compared to $9 million of such charges in the prior year. These costs were partially offset by cost savings from our integration activities.

[0000106040-16-000040:mdna:43]
Employee termination and other charges were $68 million in the three months ended September 30, 2016, an increase of $12 million from the prior year. The charges of $68 million for the three months ended September 30, 2016 consisted of $47 million of employee termination costs and $21 million of contract termination and other charges. The charges of $56 million for the three months ended October 2, 2015, consisted of $38 million of employee termination, $8 million of asset impairment and $10 million of contract termination and other charges. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 15 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:44]
Interest and Other Income (Expense)

[0000106040-16-000040:mdna:45]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Interest income | $ | 5 |  |  | 0.1 | % |  | $ | 5 |  |  | 0.1 | % |  | — | % |
| Interest expense | (236 | ) |  | (5.0 | ) |  | (13 | ) |  | (0.4 | ) |  | ** |
| Other income (expense), net | (272 | ) |  | (5.8 | ) |  | — |  |  | — |  |  | ** |
| Total interest and other income (expense), net | $ | (503 | ) |  | (10.7 | ) |  | $ | (8 | ) |  | (0.2 | ) |  | ** |

[0000106040-16-000040:mdna:46]
| ** | Amount not meaningful. |

[0000106040-16-000040:mdna:47]
Interest expense increased for the three months ended September 30, 2016, compared to the same period in 2016, primarily due to the additional debt issued in connection with the acquisition of SanDisk.

[0000106040-16-000040:mdna:48]
Other income (expense), net for the three months ended September 30, 2016 was primarily comprised of the write-off of debt issuance costs on the settlement of the original U.S. Term Loan B and Euro Term Loan B, and loss on the settlement of our convertible debt instruments.

[0000106040-16-000040:mdna:49]
Income Tax Expense

[0000106040-16-000040:mdna:50]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Income tax expense | $ | 95 |  |  | 2.0 | % |  | $ | 31 |  |  | 0.9 | % |  | 206 | % |
| Effective tax rate | (35 | )% |  |  |  | 10 | % |  |  |  |  |

[0000106040-16-000040:mdna:51]
Income tax expense of $95 million for the three months ended September 30, 2016 is attributable to discrete effects consisting of income tax expense from the integration of SanDisk of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt refinancing of $96 million and from decreases in our liability for unrecognized tax benefits due to lapses in the statute of limitations of $8 million. These discrete items are the primary drivers of the negative effective tax rate for the three months ended September 30, 2016.

[0000106040-16-000040:mdna:52]
The primary drivers for the difference between the effective tax rate for the three months ended September 30, 2016 and the U.S. Federal statutory rate of 35% are the discrete items described above, the current year generation of tax credits and tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029. For the three months ended October 2, 2015, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029.

[0000106040-16-000040:mdna:53]
We recognized a net decrease of $6 million in our liability for unrecognized tax benefits during the three months ended September 30, 2016. As of September 30, 2016, we had a liability recorded for unrecognized tax benefits of $485 million. Accrued interest and penalties related to unrecognized tax benefits as of September 30, 2016 was $78 million.

[0000106040-16-000040:mdna:54]
The Internal Revenue Service (“IRS”) previously completed its field examination of our federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. We have received Revenue Agent Reports from the IRS that seek to increase our U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with our foreign subsidiaries and intercompany payable balances. We disagree with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. We believe that our tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of our fiscal years 2010 through 2012.

[0000106040-16-000040:mdna:55]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in our tax examinations are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of September 30, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-16-000040:mdna:56]
43

[0000106040-16-000040:mdna:57]
[same as prior period, unchanged from 0000106040-16-000022:mdna:75]

[0000106040-16-000040:mdna:58]
The following table summarizes our statements of cash flows for the three months ended September 30, 2016 and October 2, 2015:

[0000106040-16-000040:mdna:59]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in millions) |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 440 |  |  | $ | 545 |  |
| Investing activities | (202 | ) |  | (273 | ) |
| Financing activities | (4,312 | ) |  | (215 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (4,074 | ) |  | $ | 57 |  |

[0000106040-16-000040:mdna:60]
We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:61]
The cash on hand and indebtedness used to finance our acquisition of SanDisk could cause us to place more reliance on cash generated from operations to pay principal and interest on our debt, thereby reducing the availability of our cash flow for working capital, capital expenditure needs, dividends, or to pursue other potential strategic plans.

[0000106040-16-000040:mdna:62]
During 2017, we expect cash used for purchases of property, plant and equipment, and net activity in Flash Ventures notes receivable and equity investments to be approximately $0.6 billion to $1.0 billion of our cash.

[0000106040-16-000040:mdna:63]
A total of $2.8 billion and $6.9 billion of our cash and cash equivalents was held outside of the U.S. as of September 30, 2016 and July 1, 2016, respectively. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or dividends to our shareholders pursuant to our quarterly cash dividend policy. In the event funds from foreign operations are needed in the U.S., any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-16-000040:mdna:64]
[same as prior period, unchanged from 0000106040-16-000022:mdna:83]

[0000106040-16-000040:mdna:65]
Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used for working capital changes was $205 million for the first quarter of 2017, as compared to $28 million used for working capital changes in the first quarter of 2016.

[0000106040-16-000040:mdna:66]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles for the three months ended September 30, 2016 and October 2, 2015 were as follows:

[0000106040-16-000040:mdna:67]
|  | Three Months Ended |
|  | September 30, 2016 |  | October 2, 2015 |
|  | (in days) |
| Days sales outstanding | 39 |  |  | 44 |  |
| Days in inventory | 57 |  |  | 48 |  |
| Days payables outstanding | (58 | ) |  | (68 | ) |
| Cash conversion cycle | 38 |  |  | 24 |  |

[0000106040-16-000040:mdna:68]
For the three months ended September 30, 2016, our days sales outstanding (“DSOs”) decreased by 5 days, days in inventory (“DIOs”) increased by 9 days and days payables outstanding (“DPOs”) decreased by 10 days, as compared to the prior year. Changes in DSOs are generally due to the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-16-000040:mdna:69]
44

[0000106040-16-000040:mdna:70]
[same as prior period, unchanged from 0000106040-16-000022:mdna:88]

[0000106040-16-000040:mdna:71]
Net cash used in investing activities in three months ended September 30, 2016 was $202 million, as compared to $273 million in the three months ended October 2, 2015. During the three months ended September 30, 2016, net cash used in investing activities primarily consisted of $184 million of capital expenditures and a net $27 million increase in notes receivable to and investments in Flash Ventures, partially offset by a net $9 million decrease in our investments in marketable securities. During the three months ended October 2, 2015, net cash used in investing activities primarily consisted of $151 million of capital expenditures and a net $112 million increase in investments in marketable securities.

[0000106040-16-000040:mdna:72]
Our cash equivalents are primarily invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government Agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government Agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds.

[0000106040-16-000040:mdna:73]
[same as prior period, unchanged from 0000106040-16-000022:mdna:90]

[0000106040-16-000040:mdna:74]
Net cash used in financing activities was $4.3 billion in three months ended September 30, 2016, as compared to net cash used of $215 million in the three months ended October 2, 2015. During the three months ended September 30, 2016, net cash used in financing activities consisted of $8.2 billion to repay debt and $142 million to pay dividends on our common stock, partially offset by $4.0 billion of proceeds from debt, net of issuance costs, $61 million of proceeds from call options and a net $26 million provided by employee stock plans. During the three months ended October 2, 2015, net cash used in financing activities primarily consisted of $115 million to pay dividends on our common stock, $60 million to repurchase shares of our common stock and $31 million to repay debt.

[0000106040-16-000040:mdna:75]
[same as prior period, unchanged from 0000106040-16-000022:mdna:92]

[0000106040-16-000040:mdna:76]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the condensed consolidated financial statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:77]
Short and Long-term Liquidity

[0000106040-16-000040:mdna:78]
[same as prior period, unchanged from 0000106040-16-000022:mdna:95]

[0000106040-16-000040:mdna:79]
The following is a summary of our known contractual cash obligations and commercial commitments as of September 30, 2016:

[0000106040-16-000040:mdna:80]
|  | Total |  | 1 Year (Remaining 9 months of 2017) |  | 2-3 Years (2018-2019) |  | 4-5 Years (2020-2021) |  | More than 5 Years (Beyond 2021) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 13,370 |  |  | $ | 30 |  |  | $ | 597 |  |  | $ | 3,727 |  |  | $ | 9,016 |  |
| Interest on debt | 5,280 |  |  | 689 |  |  | 1,567 |  |  | 1,535 |  |  | 1,489 |  |
| Flash Ventures and other related commitments(1) | 5,174 |  |  | 1,431 |  |  | 2,231 |  |  | 1,135 |  |  | 377 |  |
| Operating leases | 304 |  |  | 77 |  |  | 142 |  |  | 48 |  |  | 37 |  |
| Purchase obligations | 457 |  |  | 448 |  |  | 9 |  |  | — |  |  | — |  |
| Total | $ | 24,585 |  |  | $ | 2,675 |  |  | $ | 4,546 |  |  | $ | 6,445 |  |  | $ | 10,919 |  |

[0000106040-16-000040:mdna:81]
| (1) | Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and reimbursement for other committed expenses, including R&D. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments. |

[0000106040-16-000040:mdna:82]
Term Loans

[0000106040-16-000040:mdna:83]
In the first quarter ended September 30, 2016, we settled in full, $4.815 billion of term loans, which was composed of principal amounts of the $3.75 billion U.S. Term Loan B and the €885 million Euro Term Loan B, plus accrued interest. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, we recognized $227 million in unamortized issuance cost and debt discount fees.

[0000106040-16-000040:mdna:84]
On August 17, 2016, we borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement (as defined blow) and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at our option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.50% at September 30, 2016). Principal payments of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023.

[0000106040-16-000040:mdna:85]
On September 22, 2016, we borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% at September 30, 2016). Principal payments of Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023.

[0000106040-16-000040:mdna:86]
Term Loan A and the revolving credit facility have a term of five years. Beginning in September 2017, we are required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of September 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.526%.

[0000106040-16-000040:mdna:87]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the term loans B-1 require us to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

[0000106040-16-000040:mdna:88]
Credit Agreement

[0000106040-16-000040:mdna:89]
On April 29, 2016, we entered into a new credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility.

[0000106040-16-000040:mdna:90]
The revolving credit facility includes a $200 million sublimit for letters of credit. As of September 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance.

[0000106040-16-000040:mdna:91]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-16-000040:mdna:92]
Covenants

[0000106040-16-000040:mdna:93]
The Credit Agreement requires us to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require us to comply with customary covenants that limit or restrict our and our subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. As of September 30, 2016, we were in compliance with these covenants.

[0000106040-16-000040:mdna:94]
Senior Notes

[0000106040-16-000040:mdna:95]
On April 13, 2016, we completed an offering of $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). We are not required to make principal payments on the Notes prior to their respective maturity dates, except that we may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

[0000106040-16-000040:mdna:96]
The obligations under the Notes are guaranteed by WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

[0000106040-16-000040:mdna:97]
Convertible Notes

[0000106040-16-000040:mdna:98]
As of September 30, 2016, $37 million principal amount of the 0.5% Convertible Senior Notes due 2020 (“2020 Notes”) and less than of $1 million of principal amount the 1.5% Convertible Senior Notes due 2017 (“2017 Notes”) were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of our common stock and $735.79 in cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

[0000106040-16-000040:mdna:99]
Non-Guarantors

[0000106040-16-000040:mdna:100]
As of September 30, 2016, excluding intercompany transactions, our non-guarantor subsidiaries had $3 billion of aggregate total liabilities, all of which were structurally senior to the Notes and the related guarantees, and approximately $24 billion of consolidated assets. For the three months ended September 30, 2016, our non-guarantor subsidiaries accounted for $1.6 billion of net sales and less than $0.1 billion of operating income.

[0000106040-16-000040:mdna:101]
Flash Ventures

[0000106040-16-000040:mdna:102]
We are a 49.9% owner of each entity within Flash Ventures (Flash Partners, Ltd., Flash Alliance, Ltd., and Flash Forward, Ltd.), our business ventures with Toshiba Corporation (“Toshiba”) to develop and manufacture NAND flash memory products. These NAND flash memory products are manufactured by Toshiba at Toshiba’s Yokkaichi, Japan operations using the semiconductor manufacturing equipment owned or leased by Flash Ventures. This equipment is funded, or will be funded, by investments in, or loans to, Flash Ventures from us and Toshiba as well as through operating leases received by Flash Ventures from third-party banks and guaranteed by us and Toshiba. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to us and Toshiba at cost plus a markup. We are contractually obligated to purchase half of Flash Ventures’ NAND wafer supply or pay for 50% of the fixed costs of Flash Ventures. We are not able to estimate our total wafer purchase obligations beyond our rolling three month purchase commitment because the price is determined by reference to the future cost to produce the semiconductor wafers. We are also committed to fund 49.9% to 50% of Flash Ventures’ investments to the extent that Flash Ventures’ operating cash flow is insufficient to fund these investments.

[0000106040-16-000040:mdna:103]
For semiconductor manufacturing equipment that is leased by Flash Ventures, we and Toshiba each guarantee, on an unsecured and several basis, 50% of the outstanding Flash Ventures’ lease obligations under lease agreements entered into by Flash Ventures. These lease obligations are denominated in Japanese yen and are noncancelable. Our lease obligation guarantees as of September 30, 2016, which reflects future payments and any lease adjustments, totaled $1.24 billion, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016. The lease agreements contain certain covenants and cancellation events that are customary for Japanese lease facilities and that relate to Flash Ventures and each of the guarantors. The breach of a covenant or the occurrence of another cancellation event could result in an acceleration of Flash Ventures’ lease obligations. As of September 30, 2016, we were in compliance with all covenants under these Japanese lease facilities.

[0000106040-16-000040:mdna:104]
For additional information regarding Flash Ventures, see Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:105]
Foreign Exchange Contracts

[0000106040-16-000040:mdna:106]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 3, under the heading “Disclosure About Foreign Currency Risk,” and Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:107]
Indemnifications

[0000106040-16-000040:mdna:108]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-16-000040:mdna:109]
[same as prior period, unchanged from 0000106040-16-000022:mdna:103]

[0000106040-16-000040:mdna:110]
Unrecognized Tax Benefits

[0000106040-16-000040:mdna:111]
As of September 30, 2016, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $563 million, of which $420 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 8 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000040:mdna:112]
Cash Dividend

[0000106040-16-000040:mdna:113]
Since the first quarter of 2014, we have issued a quarterly cash dividend. On August 3, 2016, we declared a cash dividend of $0.50 per share of our common stock to our stockholders of record as of September 30, 2016. The cash dividend of $143 million was paid on October 17, 2016. On November 3, 2016, we declared a cash dividend of $0.50 per share of our common stock to our stockholders of record as of December 30, 2016.  The cash dividend will be paid on January 17, 2017. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-16-000040:mdna:114]
[same as prior period, unchanged from 0000106040-16-000022:mdna:107]

[0000106040-16-000040:mdna:115]
We have prepared the accompanying unaudited condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material.

[0000106040-16-000040:mdna:116]
There have been no material changes in our critical accounting policies and estimates since our fiscal year ended July 1, 2016. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 1, 2016 for a discussion of our critical accounting policies and estimates.

[0000106040-16-000040:mdna:117]
[same as prior period, unchanged from 0000106040-16-000022:mdna:110]

[0000106040-16-000040:mdna:118]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 2 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, which is incorporated by reference in response to this item.

[0000106040-16-000040:mdna:119]
48
