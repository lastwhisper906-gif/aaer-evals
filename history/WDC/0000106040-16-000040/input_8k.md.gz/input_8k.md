# WDC 8-K — 0001193125-16-747970 filed 2016-10-26

## item codes, every 8-K on or before 2016-11-08

- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2016-11-08

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-747970:8k_2_02:1]
EX-99.1
2
d278570dex991.htm
EX-99.1

[0001193125-16-747970:8k_2_02:2]
EX-99.1

[0001193125-16-747970:8k_2_02:3]
Exhibit 99.1

[0001193125-16-747970:8k_2_02:4]
FOR IMMEDIATE RELEASE:

[0001193125-16-747970:8k_2_02:5]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0001193125-16-747970:8k_2_02:6]
FIRST FISCAL QUARTER 2017

[0001193125-16-747970:8k_2_02:7]
IRVINE, Calif.
— Oct. 26, 2016 — Western Digital Corp. (NASDAQ: WDC) today reported revenue of $4.7 billion, operating income of $232 million and a net loss of $366 million, or $1.28 per share, for its first fiscal quarter ended Sept. 30, 2016. The GAAP
net loss for the period includes charges associated with the company’s recent acquisitions and debt extinguishment charges related to its repricing and repayment of outstanding debt. Excluding these charges and other non-GAAP adjustments, first
quarter non-GAAP operating income was $632 million and non-GAAP net income was $341 million, or $1.18 per share.

[0001193125-16-747970:8k_2_02:8]
In the year-ago quarter,
the company reported revenue of $3.4 billion, operating income of $322 million and net income of $283 million, or $1.21 per share. Non-GAAP operating income in the year-ago quarter was $405 million and non-GAAP net income was $366 million, or $1.56
per share.

[0001193125-16-747970:8k_2_02:9]
The company generated $440 million in cash from operations during the first fiscal quarter of 2017, ending with total cash and
cash equivalents of $4.1 billion. On Aug. 3, 2016, the company declared a cash dividend of $0.50 per share of its common stock, which was paid to shareholders on Oct.17, 2016.

[0001193125-16-747970:8k_2_02:10]
“We are pleased with our performance in the September quarter, the first full quarter as an integrated company following the SanDisk
acquisition in May,” said Steve Milligan, chief executive officer. “Demand for both hard drive and flash-based products was strong across all customer categories, driven by cloud and mobile applications, as well as better-than-expected PC
market trends. We are encouraged by the uniformly positive response to the new Western Digital platform from our broadened customer base.

[0001193125-16-747970:8k_2_02:11]
“The Western Digital team is executing very well against our top business objectives, including the integrations of the legacy HGST,
SanDisk and WD operations, and our transition to next-generation NAND technology. We are on track to achieve our synergy goals associated with these integrations and our transition to 3D NAND continues to progress as planned.”

[0001193125-16-747970:8k_2_02:12]
Western Digital Announces Financial Results for First Fiscal Quarter 2017

[0001193125-16-747970:8k_2_02:13]
The investment community conference call to discuss these results and the company’s
guidance for the second fiscal quarter 2017 will be broadcast live over the Internet today at 2 p.m. Pacific/5 p.m. Eastern. The live and archived conference call/webcast can be accessed online at investor.wdc.com. Supplemental financial
information, including the company’s guidance for the second fiscal quarter 2017, will also be posted on the same website. The telephone replay number in the U.S. is 1-(855) 859-2056 or +1-(404) 537-3406 for international callers. The required
passcode is 87154641.

[0001193125-16-747970:8k_2_02:14]
About Western Digital

[0001193125-16-747970:8k_2_02:15]
Western Digital is an industry-leading provider of storage technologies and solutions that enable people to create, leverage, experience and
preserve data. The company addresses ever-changing market needs by providing a full portfolio of compelling, high-quality storage solutions with customer-focused innovation, high efficiency, flexibility and speed. Our products are marketed under the
HGST, SanDisk and WD brands to OEMs, distributors, resellers, cloud infrastructure providers and consumers. Financial and investor information is available on the company’s Investor Relations website at investor.wdc.com.

[0001193125-16-747970:8k_2_02:16]
Forward-Looking Statements

[0001193125-16-747970:8k_2_02:17]
Western Digital Announces Financial Results for First Fiscal Quarter 2017

[0001193125-16-747970:8k_2_02:18]
Sept. 30, 2016 included in this press release represent the most current information available to management. The company’s actual results when disclosed in its quarterly report on Form 10-Q
may differ from these preliminary results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review by the company’s independent registered accounting firm and other
developments that may arise between now and the disclosure of the final results. Other risks and uncertainties that could cause actual results to differ materially from those expressed or implied in the forward-looking statements include: volatility
in global economic conditions; business conditions and growth in the storage ecosystem; impact of competitive products and pricing; market acceptance and cost of commodity materials and specialized product components; actions by competitors;
unexpected advances in competing technologies; our development and introduction of products based on new technologies and expansion into new data storage markets; risks associated with acquisitions, mergers and joint ventures; difficulties or delays
in manufacturing; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-K filed with the SEC on Aug. 29, 2016, to which your
attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update these forward-looking statements to reflect new information or
events.

[0001193125-16-747970:8k_2_02:19]
###

[0001193125-16-747970:8k_2_02:20]
Western Digital, WD, the HGST
logo, SanDisk and G-Technology are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the U.S. and/or other countries. Other trademarks, registered trademarks, and/or service marks, indicated or otherwise, are
the property of their respective owners.

[0001193125-16-747970:8k_2_02:21]
| Company contacts: |  |  |
| Western Digital Corp. |  | Investor Contact: |
| Media Contact: |  | Bob Blair |
| Jim Pascoe |  | 949.672.7834 |
| 408.717.6999 |  | robert.blair@wdc.com |
| jim.pascoe@wdc.com |  |  |

[0001193125-16-747970:8k_2_02:22]
WESTERN DIGITAL CORPORATION

[0001193125-16-747970:8k_2_02:23]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-747970:8k_2_02:24]
(in millions; unaudited)

[0001193125-16-747970:8k_2_02:25]
|  |  | Sep. 30, |  |  | July 1, |  |
|  |  | 2016 |  |  | 2016 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,077 |  |  | $ | 8,151 |  |
| Short-term investments |  |  | 248 |  |  |  | 227 |  |
| Accounts receivable, net |  |  | 2,023 |  |  |  | 1,461 |  |
| Inventories |  |  | 2,109 |  |  |  | 2,129 |  |
| Other current assets |  |  | 666 |  |  |  | 616 |  |
| Total current assets |  |  | 9,123 |  |  |  | 12,584 |  |
| Property, plant and equipment, net |  |  | 3,359 |  |  |  | 3,503 |  |
| Notes receivable and investments in Flash Ventures |  |  | 1,217 |  |  |  | 1,171 |  |
| Goodwill |  |  | 9,967 |  |  |  | 9,951 |  |
| Other intangible assets, net |  |  | 4,791 |  |  |  | 5,034 |  |
| Other non-current assets |  |  | 553 |  |  |  | 619 |  |
| Total assets |  | $ | 29,010 |  |  | $ | 32,862 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 1,946 |  |  | $ | 1,888 |  |
| Accounts payable to related parties |  |  | 190 |  |  |  | 168 |  |
| Accrued expenses |  |  | 983 |  |  |  | 995 |  |
| Accrued compensation |  |  | 552 |  |  |  | 392 |  |
| Accrued warranty |  |  | 170 |  |  |  | 172 |  |
| Bridge loan |  |  | — |  |  |  | 2,995 |  |
| Current portion of long-term debt |  |  | 78 |  |  |  | 339 |  |
| Total current liabilities |  |  | 3,919 |  |  |  | 6,949 |  |
| Long-term debt |  |  | 13,055 |  |  |  | 13,660 |  |
| Other liabilities |  |  | 1,261 |  |  |  | 1,108 |  |
| Total liabilities |  |  | 18,235 |  |  |  | 21,717 |  |
| Total shareholders’ equity |  |  | 10,775 |  |  |  | 11,145 |  |
| Total liabilities and shareholders’ equity |  | $ | 29,010 |  |  | $ | 32,862 |  |

[0001193125-16-747970:8k_2_02:26]
WESTERN DIGITAL CORPORATION

[0001193125-16-747970:8k_2_02:27]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-747970:8k_2_02:28]
(in millions, except per share amounts; unaudited)

[0001193125-16-747970:8k_2_02:29]
|  |  | Three Months Ended |  |
|  |  | Sep. 30, |  |  | Oct. 2, |  |
|  |  | 2016 |  |  | 2015 |  |
| Revenue, net |  | $ | 4,714 |  |  | $ | 3,360 |  |
| Cost of revenue |  |  | 3,379 |  |  |  | 2,405 |  |
| Gross profit |  |  | 1,335 |  |  |  | 955 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 639 |  |  |  | 385 |  |
| Selling, general and administrative |  |  | 396 |  |  |  | 192 |  |
| Employee termination, asset impairment and other charges |  |  | 68 |  |  |  | 56 |  |
| Total operating expenses |  |  | 1,103 |  |  |  | 633 |  |
| Operating income |  |  | 232 |  |  |  | 322 |  |
| Interest and other expense, net |  |  | (503 | ) |  |  | (8 | ) |
| Income (loss) before income taxes |  |  | (271 | ) |  |  | 314 |  |
| Income tax expense |  |  | 95 |  |  |  | 31 |  |
| Net income (loss) |  | $ | (366 | ) |  | $ | 283 |  |
| Income (loss) per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.28 | ) |  | $ | 1.23 |  |
| Diluted |  | $ | (1.28 | ) |  | $ | 1.21 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 285 |  |  |  | 231 |  |
| Diluted |  |  | 285 |  |  |  | 234 |  |

[0001193125-16-747970:8k_2_02:30]
WESTERN DIGITAL CORPORATION

[0001193125-16-747970:8k_2_02:31]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-747970:8k_2_02:32]
(in millions; unaudited)

[0001193125-16-747970:8k_2_02:33]
|  |  | Three Months Ended |  |
|  |  | Sep. 30, |  |  | Oct. 2, |  |
|  |  | 2016 |  |  | 2015 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (366 | ) |  | $ | 283 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 508 |  |  |  | 236 |  |
| Stock-based compensation |  |  | 99 |  |  |  | 42 |  |
| Deferred income taxes |  |  | 147 |  |  |  | (7 | ) |
| Loss on disposal of assets |  |  | 4 |  |  |  | — |  |
| Amortization and write-off of debt discount and issuance costs |  |  | 247 |  |  |  | 1 |  |
| Loss on settlement of convertible debt |  |  | 5 |  |  |  | — |  |
| Non-cash portion of employee termination, asset impairment and other charges |  |  | — |  |  |  | 18 |  |
| Other non-cash operating activities, net |  |  | 1 |  |  |  | — |  |
| Changes in operating assets and liabilities, net |  |  | (205 | ) |  |  | (28 | ) |
| Net cash provided by operating activities |  |  | 440 |  |  |  | 545 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net |  |  | (183 | ) |  |  | (151 | ) |
| Activity related to Flash Ventures, net |  |  | (27 | ) |  |  | — |  |
| Investment activity, net |  |  | 9 |  |  |  | (112 | ) |
| Strategic investments and other, net |  |  | (1 | ) |  |  | (10 | ) |
| Net cash used in investing activities |  |  | (202 | ) |  |  | (273 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Employee stock plans, net |  |  | 26 |  |  |  | (9 | ) |
| Proceeds from acquired call option |  |  | 61 |  |  |  | — |  |
| Repurchases of common stock |  |  | — |  |  |  | (60 | ) |
| Dividends paid to shareholders |  |  | (142 | ) |  |  | (115 | ) |
| Proceeds from debt, net of issuance costs |  |  | 3,985 |  |  |  | — |  |
| Repayment of debt |  |  | (8,242 | ) |  |  | (31 | ) |
| Net cash used in financing activities |  |  | (4,312 | ) |  |  | (215 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (4,074 | ) |  |  | 57 |  |
| Cash and cash equivalents, beginning of period |  |  | 8,151 |  |  |  | 5,024 |  |
| Cash and cash equivalents, end of period |  | $ | 4,077 |  |  | $ | 5,081 |  |

[0001193125-16-747970:8k_2_02:34]
WESTERN DIGITAL CORPORATION

[0001193125-16-747970:8k_2_02:35]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001193125-16-747970:8k_2_02:36]
(in millions, except per share amounts; unaudited)

[0001193125-16-747970:8k_2_02:37]
|  |  | Three Months Ended |  |
|  |  | Sep. 30, |  |  | Oct. 2, |  |
|  |  | 2016 |  |  | 2015 |  |
| Reconciliation of GAAP to Non-GAAP Operating Income |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 232 |  |  | $ | 322 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 242 |  |  |  | 25 |  |
| Employee termination, asset impairment and other charges |  |  | 68 |  |  |  | 56 |  |
| Acquisition-related charges |  |  | 27 |  |  |  | — |  |
| Charges related to cost saving initiatives |  |  | 63 |  |  |  | — |  |
| Other |  |  | — |  |  |  | 2 |  |
| Non-GAAP operating income |  | $ | 632 |  |  | $ | 405 |  |
| Reconciliation of GAAP to Non-GAAP Net Income (Loss) |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | (366 | ) |  | $ | 283 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 242 |  |  |  | 25 |  |
| Employee termination, asset impairment and other charges |  |  | 68 |  |  |  | 56 |  |
| Acquisition-related charges |  |  | 27 |  |  |  | — |  |
| Charges related to cost saving initiatives |  |  | 63 |  |  |  | — |  |
| Convertible debt activity, net |  |  | 5 |  |  |  | — |  |
| Debt extinguishment costs |  |  | 267 |  |  |  | — |  |
| Other |  |  | 4 |  |  |  | 2 |  |
| Income tax adjustments |  |  | 31 |  |  |  | — |  |
| Non-GAAP net income |  | $ | 341 |  |  | $ | 366 |  |
| Diluted net income (loss) per common share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | (1.28 | ) |  | $ | 1.21 |  |
| Non-GAAP |  | $ | 1.18 |  |  | $ | 1.56 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| GAAP |  |  | 285 |  |  |  | 234 |  |
| Non-GAAP |  |  | 290 |  |  |  | 234 |  |

[0001193125-16-747970:8k_2_02:38]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally
accepted accounting principles (“GAAP”), the table above sets forth non-GAAP operating income, non-GAAP net income and non-GAAP diluted net income per common share (“Non-GAAP measures”). These Non-GAAP measures are not in
accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. Western Digital Corporation believes the presentation of these Non-GAAP measures, when shown
in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods.

[0001193125-16-747970:8k_2_02:39]
Non-GAAP operating income, non-GAAP net income and non-GAAP diluted net income per common share are Non-GAAP measures defined as operating income, net income
and diluted net income per common share, respectively, before any charges that may not be indicative of ongoing operations, or any tax impact related to those charges. These Non-GAAP measures exclude: amortization of acquired intangible assets;
employee termination, asset impairment and other charges; convertible debt activity, net; charges related to cost saving initiatives; acquisition-related charges; debt extinguishments; other charges; and income tax adjustments.

[0001193125-16-747970:8k_2_02:40]
As described above, we exclude the following items from our Non-GAAP measures:

[0001193125-16-747970:8k_2_02:41]
Amortization of acquired intangible assets. We incur expenses from the amortization of acquired intangible assets over their economic
lives. Such charges are significantly impacted by the timing and magnitude of our acquisitions and any related impairment charges.

[0001193125-16-747970:8k_2_02:42]
Employee
termination, asset impairment and other charges. From time-to-time, in order to realign our operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, we may terminate employees and/or
restructure our operations. From time-to-time, we may also incur charges from the impairment of intangible assets and other long-lived assets. These charges (including any reversals of charges recorded in prior periods) are inconsistent in
amount and frequency and are not indicative of the underlying performance of our business.

[0001193125-16-747970:8k_2_02:43]
Acquisition-related charges. In connection with
our business combinations, we incur expenses which we would not have otherwise incurred as part of our business operations. These expenses include third-party professional service and legal fees, third-party integration services, severance
costs, non-cash adjustments to the fair value of acquired inventory, contract termination costs, and retention bonuses. We may also experience other accounting impacts in connection with these transactions. These charges and impacts are
related to acquisitions, are inconsistent in amount and frequency, and are not indicative of the underlying performance of our business.

[0001193125-16-747970:8k_2_02:44]
Charges related to cost saving initiatives. In connection with the transformation of our business, we have incurred charges related to cost saving
initiatives which do not qualify for special accounting treatment as exit or disposal activities. These charges, which are not indicative of the underlying performance of our business, primarily relate to costs associated with rationalizing our
channel partners or vendors, transforming our information systems infrastructure, integrating our product roadmap, and accelerated depreciation on assets.

[0001193125-16-747970:8k_2_02:45]
Convertible debt activity, net. We exclude non-cash economic interest expense associated with the convertible senior notes, the gains and losses on the
conversion of the convertible senior notes and call option, and unrealized gains and losses related to the change in fair value of the exercise option and call option. These charges and gains and losses do not reflect our cash operating results and
are not indicative of the underlying performance of our business.

[0001193125-16-747970:8k_2_02:46]
Debt extinguishment costs. From time-to-time, we replace our existing debt with new financing at more
favorable interest rates or utilize available capital to settle debt early, both of which generate interest savings in future periods. We incur debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off
of any related unamortized debt issuance costs. These gains and losses related to our debt activity occur infrequently and are not indicative of the underlying performance of our business.

[0001193125-16-747970:8k_2_02:47]
Other charges. From time-to-time, we sell investments or other assets which are not considered strategic or necessary to our business; are a party to
legal or arbitration proceedings, which could result in an expense or benefit due to settlements, final judgments, or accruals for loss contingencies; or incur other charges or gains which are not a part of the ongoing operation of our
business. The resulting expense or benefit is inconsistent in amount and frequency.

[0001193125-16-747970:8k_2_02:48]
Income tax adjustments. Income tax adjustments reflect
the difference between income taxes based on a forecasted annual non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments.
