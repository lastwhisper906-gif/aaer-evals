# WDC 10-Q controls and the auditor's report


## item_4_controls

[0000106040-20-000024:item_4_controls:1]
Item 4. Controls and Procedures

[0000106040-20-000024:item_4_controls:2]
As required by Rule 13a-15(b) promulgated by the Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Quarterly Report on Form 10-Q, our disclosure controls and procedures were effective.

[0000106040-20-000024:item_4_controls:3]
There were no changes in our internal control over financial reporting that occurred during our most recently completed fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000106040-20-000024:item_4_controls:4]
We are implementing an enterprise resource planning (“ERP”) system on a worldwide basis, which is expected to improve the efficiency of certain financial and related transactional processes. The gradual implementation is expected to occur in phases over the next several years. We have completed the implementation of certain processes, including the financial consolidation and reporting, fixed assets, supplier management and indirect procure-to-pay processes, and have revised and updated the related controls. These changes did not materially affect our internal control over financial reporting. As we implement the remaining functionality under this ERP system over the next several years, we will continue to assess the impact on our internal control over financial reporting.

[0000106040-20-000024:item_4_controls:5]
50
