# WDC notes — 0000106040-20-000024


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-20-000024:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

[0000106040-20-000024:notes:2]
[same as prior period, unchanged from 0000106040-20-000011:notes:3]

[0000106040-20-000024:notes:3]
[same as prior period, unchanged from 0000106040-20-000011:notes:4]

[0000106040-20-000024:notes:4]
[same as prior period, unchanged from 0000106040-20-000011:notes:5]

[0000106040-20-000024:notes:5]
[same as prior period, unchanged from 0000106040-20-000011:notes:6]

[0000106040-20-000024:notes:6]
[same as prior period, unchanged from 0000106040-20-000011:notes:7]

[0000106040-20-000024:notes:7]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-20-000024:notes:8]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-20-000024:notes:9]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes Accounting Standards Codification (“ASC”) 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The Company adopted this standard effective June 29, 2019, the first day of the fiscal year ending July 3, 2020, and has elected the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company has elected the package of practical expedients and did not reassess prior conclusions including (a) whether its contracts are or contain a lease, (b) lease classification and (c) capitalization of initial direct costs. The adoption of Topic 842 resulted in an increase in lease assets and a corresponding increase in lease liabilities on the Condensed Consolidated Balance Sheet of $221 million as of June 29, 2019. The cumulative effect of adopting Topic 842 also included an after-tax decrease to opening retained earnings of $5 million as of June 29, 2019, which was primarily related to previously recorded sublease proceed assumptions on lease exit liabilities for which there was no expected future economic benefit at transition. See Note 10, Leases and Other Commitments, for additional disclosures related to this standard.

[0000106040-20-000024:notes:10]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. The Company adopted this standard in the first quarter of 2020. The Company’s adoption of ASU 2018-16 did not have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000024:notes:11]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-20-000024:notes:12]
In December 2019, the FASB issued ASU 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2020, which for the Company is the first quarter of fiscal 2021. Early adoption is permitted. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000024:notes:13]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-20-000024:notes:14]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 3, 2020 or June 28, 2019.

[0000106040-20-000024:notes:15]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 3, 2020 and June 28, 2019 as well as the related amortization for the three and nine months ended April 3, 2020 and March 29, 2019 were not material.

[0000106040-20-000024:notes:16]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 3, 2020 and June 28, 2019, contract liabilities were not material.

[0000106040-20-000024:notes:17]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 3, 2020 was $122 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $11 million during the remainder of fiscal 2020, $41 million in fiscal 2021, $39 million in fiscal 2022 and $31 million thereafter.

[0000106040-20-000024:notes:18]
[same as prior period, unchanged from 0000106040-20-000011:notes:21]

[0000106040-20-000024:notes:19]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |

[0000106040-20-000024:notes:20]
The Company’s top 10 customers accounted for 44% of its net revenue for both the three and nine months ended April 3, 2020, and 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively. For the three and nine months ended April 3, 2020 and March 29, 2019, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-20-000024:notes:21]
Supplemental Financial Statement Data
Accounts receivable, net

[0000106040-20-000024:notes:22]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the nine months ended April 3, 2020 and March 29, 2019, the Company sold trade accounts receivable and received cash proceeds of $298 million and $702 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. As of April 3, 2020 and June 28, 2019, the amount of factored receivables that remained outstanding was $100 million and $318 million, respectively.

[0000106040-20-000024:notes:23]
[same as prior period, unchanged from 0000106040-20-000011:notes:27]

[0000106040-20-000024:notes:24]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,302 |  |  | $ | 1,142 |  |
| Work-in-process | 842 |  |  | 968 |  |
| Finished goods | 947 |  |  | 1,173 |  |
| Total inventories | $ | 3,091 |  |  | $ | 3,283 |  |

[0000106040-20-000024:notes:25]
[same as prior period, unchanged from 0000106040-20-000011:notes:29]

[0000106040-20-000024:notes:26]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Property, plant and equipment: |  |  |  |
| Land | $ | 294 |  |  | $ | 294 |  |
| Buildings and improvements | 1,823 |  |  | 1,743 |  |
| Machinery and equipment | 7,290 |  |  | 7,267 |  |
| Computer equipment and software | 437 |  |  | 441 |  |
| Furniture and fixtures | 51 |  |  | 56 |  |
| Construction-in-process | 190 |  |  | 202 |  |
| Property, plant and equipment, gross | 10,085 |  |  | 10,003 |  |
| Accumulated depreciation | (7,350) |  |  | (7,160) |  |
| Property, plant and equipment, net | $ | 2,735 |  |  | $ | 2,843 |  |

[0000106040-20-000024:notes:27]
[same as prior period, unchanged from 0000106040-20-000011:notes:31]

[0000106040-20-000024:notes:28]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 28, 2019 | $ | 10,076 |  |
| Goodwill recorded in connection with an acquisition | 14 |  |
| Reduction in goodwill in connection with disposition of business | (21) |  |
| Foreign currency translation adjustment | (3) |  |
| Balance at April 3, 2020 | $ | 10,066 |  |

[0000106040-20-000024:notes:29]
[same as prior period, unchanged from 0000106040-20-000011:notes:33]

[0000106040-20-000024:notes:30]
[same as prior period, unchanged from 0000106040-20-000011:notes:34]

[0000106040-20-000024:notes:31]
[same as prior period, unchanged from 0000106040-20-000011:notes:35]

[0000106040-20-000024:notes:32]
In September 2019, the Company announced the sale of its IntelliFlash business and intention to exit Storage Systems, which consists of IntelliFlash and ActiveScale. These actions will allow the Company to redirect investments to other high value priorities. In November 2019, the Company completed its sale of IntelliFlash for a price of $28 million, to be collected over the next three years. The sale of the IntelliFlash business included an immaterial amount of inventory, other tangible and intangible assets, and goodwill and resulted in a gain of approximately $17 million recorded in Employee termination, asset impairment, and other charges in the Condensed Consolidated Statements of Operations for both the three and nine months ended April 3, 2020. Additionally, in March 2020, the Company completed the sale of ActiveScale. The net assets sold and the proceeds from the sale of ActiveScale were not material. The revenues and expenses related to these businesses were not material to the Condensed Consolidated Financial Statements and did not qualify to be reported as discontinued operations. The operating results of these businesses have been reflected in the Company’s results from continuing operations in the Condensed Consolidated Statements of Operations for all periods presented through the date of disposition.

[0000106040-20-000024:notes:33]
[same as prior period, unchanged from 0000106040-20-000011:notes:37]

[0000106040-20-000024:notes:34]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Finite-lived intangible assets | $ | 5,725 |  |  | $ | 5,824 |  |
| In-process research and development | 80 |  |  | 72 |  |
| Accumulated amortization | (4,679) |  |  | (4,185) |  |
| Intangible assets, net | $ | 1,126 |  |  | $ | 1,711 |  |

[0000106040-20-000024:notes:35]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-20-000024:notes:36]
[same as prior period, unchanged from 0000106040-20-000011:notes:40]

[0000106040-20-000024:notes:37]
[same as prior period, unchanged from 0000106040-20-000011:notes:41]

[0000106040-20-000024:notes:38]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Warranty accrual, beginning of period | $ | 378 |  |  | $ | 337 |  |  | $ | 350 |  |  | $ | 318 |  |  |  |
| Charges to operations | 45 |  |  | 38 |  |  | 144 |  |  | 119 |  |  |  |
| Utilization | (41) |  |  | (40) |  |  | (124) |  |  | (108) |  |  |  |
| Changes in estimate related to pre-existing warranties | 1 |  |  | (4) |  |  | 13 |  |  | 2 |  |  |  |
| Warranty accrual, end of period | $ | 383 |  |  | $ | 331 |  |  | $ | 383 |  |  | $ | 331 |  |  |  |

[0000106040-20-000024:notes:39]
[same as prior period, unchanged from 0000106040-20-000011:notes:43]

[0000106040-20-000024:notes:40]
|  | April 3,2020 |  | June 28,2019 |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 185 |  |  | $ | 188 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 198 |  |  | 162 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 383 |  |  | $ | 350 |  |  |  |  |  |  |  |

[0000106040-20-000024:notes:41]
[same as prior period, unchanged from 0000106040-20-000011:notes:45]

[0000106040-20-000024:notes:42]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 830 |  |  | $ | 928 |  |
| Payables related to unrecognized tax benefits | 716 |  |  | 699 |  |
| Other non-current liabilities | 906 |  |  | 713 |  |
| Total other liabilities | $ | 2,452 |  |  | $ | 2,340 |  |

[0000106040-20-000024:notes:43]
[same as prior period, unchanged from 0000106040-20-000011:notes:47]

[0000106040-20-000024:notes:44]
Accumulated other comprehensive income (loss) (“AOCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCI:

[0000106040-20-000024:notes:45]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Balance at June 28, 2019 | $ | (53) |  |  | $ | 4 |  |  |  |  |  |  | $ | (19) |  |  | $ | (68) |  |
| Other comprehensive income (loss) before reclassifications | 4 |  |  | (21) |  |  |  |  |  |  | (98) |  |  | (115) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | (17) |  |  | (17) |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (1) |  |  | 1 |  |  |  |  |  |  | 17 |  |  | 17 |  |
| Net current-period other comprehensive income (loss) | 3 |  |  | (20) |  |  |  |  |  |  | (98) |  |  | (115) |  |
| Balance at April 3, 2020 | $ | (50) |  |  | $ | (16) |  |  |  |  |  |  | $ | (117) |  |  | $ | (183) |  |

[0000106040-20-000024:notes:46]
During the three and nine months ended April 3, 2020 and March 29, 2019, the amounts reclassified out of AOCI related to derivative contracts were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-20-000024:notes:47]
Fair Value Measurements and Investments
Financial Instruments Carried at Fair Value

[0000106040-20-000024:notes:48]
[same as prior period, unchanged from 0000106040-20-000011:notes:53]

[0000106040-20-000024:notes:49]
Level 1. Quoted prices in active markets for identical assets or liabilities.

[0000106040-20-000024:notes:50]
Level 2. Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-20-000024:notes:51]
Level 3. Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-20-000024:notes:52]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of April 3, 2020 and June 28, 2019, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-20-000024:notes:53]
|  | April 3, 2020 |  |  |  |  |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,028 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,028 |  |
| Foreign exchange contracts | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Total assets at fair value | $ | 1,028 |  |  | $ | 38 |  |  | $ | — |  |  | $ | 1,066 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |
| Interest rate swap contract | — |  |  | 132 |  |  | — |  |  | 132 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 160 |  |  | $ | — |  |  | $ | 160 |  |

[0000106040-20-000024:notes:54]
|  | June 28, 2019 |  |  |  |  |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,388 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,388 |  |
| Certificates of deposit | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Total cash equivalents | 1,388 |  |  | 17 |  |  | — |  |  | 1,405 |  |
| Foreign exchange contracts | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Interest rate swap contracts | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total assets at fair value | $ | 1,388 |  |  | $ | 63 |  |  | $ | — |  |  | $ | 1,451 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |
| Interest rate swap contract |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000106040-20-000024:notes:55]
During the three and nine months ended April 3, 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-20-000024:notes:56]
[same as prior period, unchanged from 0000106040-20-000011:notes:61]

[0000106040-20-000024:notes:57]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2020 and the fourth quarter of 2019, respectively.

[0000106040-20-000024:notes:58]
|  | April 3, 2020 |  |  |  | June 28, 2019 |  |  |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |  |  |  |  |  |  |
| 0.50% convertible senior notes due 2020 | $ | 34 |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | 31 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,637 |  |  | 4,413 |  |  | 4,824 |  |  | 4,780 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,693 |  |  | 1,640 |  |  | 2,424 |  |  | 2,370 |  |
| 1.50% convertible notes due 2024 | 980 |  |  | 966 |  |  | 958 |  |  | 986 |  |
| 4.75% senior unsecured notes due 2026 | 2,285 |  |  | 2,256 |  |  | 2,283 |  |  | 2,263 |  |
| Total | $ | 9,629 |  |  | $ | 9,308 |  |  | $ | 10,522 |  |  | $ | 10,430 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-20-000024:notes:59]
Derivative Instruments and Hedging Activities
As of April 3, 2020, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-20-000024:notes:60]
As of April 3, 2020, the amount of existing net losses related to cash flow hedges recorded in AOCI included $87 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of April 3, 2020, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-20-000024:notes:61]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and nine months ended April 3, 2020 and March 29, 2019, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-20-000024:notes:62]
[same as prior period, unchanged from 0000106040-20-000011:notes:68]

[0000106040-20-000024:notes:63]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of April 3, 2020 and June 28, 2019, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-20-000024:notes:64]
Debt
Debt consisted of the following as of April 3, 2020 and June 28, 2019:

[0000106040-20-000024:notes:65]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,645 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,694 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,774 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (145) |  |  | (172) |  |
| Subtotal | 9,629 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286) |  |  | (276) |  |
| Long-term debt | $ | 9,343 |  |  | $ | 10,246 |  |

[0000106040-20-000024:notes:66]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 3, 2020, the Company was in compliance with these financial covenants.
During the nine months ended April 3, 2020, the Company made aggregate voluntary prepayments of $725 million on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of April 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-20-000024:notes:67]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Condensed Consolidated Financial Statements. The expected long-term rate of return on the Japanese Plan assets is 2.5%.

[0000106040-20-000024:notes:68]
[same as prior period, unchanged from 0000106040-20-000011:notes:77]

[0000106040-20-000024:notes:69]
[same as prior period, unchanged from 0000106040-20-000011:notes:78]

[0000106040-20-000024:notes:70]
|  | April 3,2020 |  | June 28,2019 |  |  |
|  | (in millions) |  |  |  |  |
| Benefit obligation at end of period | $ | 277 |  |  | $ | 280 |  |  |  |
| Fair value of plan assets at end of period | 211 |  |  | 208 |  |  |  |
| Unfunded status | $ | 66 |  |  | $ | 72 |  |  |  |

[0000106040-20-000024:notes:71]
[same as prior period, unchanged from 0000106040-20-000011:notes:80]

[0000106040-20-000024:notes:72]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 65 |  |  | 71 |  |
| Net amount recognized | $ | 66 |  |  | $ | 72 |  |

[0000106040-20-000024:notes:73]
Net periodic benefit costs were not material for either the three or nine months ended April 3, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-20-000024:notes:74]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-20-000024:notes:75]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-20-000024:notes:76]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 3, 2020 and June 28, 2019:

[0000106040-20-000024:notes:77]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Notes receivable, Flash Partners | $ | 335 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 423 |  |  | 878 |  |
| Notes receivable, Flash Forward | 777 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 125 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,157 |  |  | $ | 2,791 |  |

[0000106040-20-000024:notes:78]
During the three and nine months ended April 3, 2020 and during the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $842 million and $2.36 billion, and $1.04 billion and $2.90 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-20-000024:notes:79]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-20-000024:notes:80]
As of April 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $397 million and $331 million, respectively.

[0000106040-20-000024:notes:81]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-20-000024:notes:82]
|  | April 3,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,535 |  |
| Equity investments | 622 |  |
| Operating lease guarantees | 1,827 |  |
| Inventory and prepayments | 468 |  |
| Maximum estimable loss exposure | $ | 4,452 |  |

[0000106040-20-000024:notes:83]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-20-000024:notes:84]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-20-000024:notes:85]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the end of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 3, 2020, remaining committed prepayments totaled $205 million.

[0000106040-20-000024:notes:86]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-20-000024:notes:87]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-20-000024:notes:88]
Off-Balance Sheet Liabilities

[0000106040-20-000024:notes:89]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-20-000024:notes:90]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020.

[0000106040-20-000024:notes:91]
|  | Lease Amounts |  |  |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 198 |  |  | $ | 1,827 |  |

[0000106040-20-000024:notes:92]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020:

[0000106040-20-000024:notes:93]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |  |  |  |  |
| Remaining three months of 2020 |  | $ | 128 |  |  | $ | 20 |  |  | $ | 148 |  |
| 2021 |  | 450 |  |  | 108 |  |  | 558 |  |
| 2022 |  | 370 |  |  | 49 |  |  | 419 |  |
| 2023 |  | 259 |  |  | 67 |  |  | 326 |  |
| 2024 |  | 123 |  |  | 120 |  |  | 243 |  |
| Thereafter |  | 23 |  |  | 110 |  |  | 133 |  |
| Total guarantee obligations |  | $ | 1,353 |  |  | $ | 474 |  |  | $ | 1,827 |  |

[0000106040-20-000024:notes:94]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-20-000024:notes:95]
Unis Venture

[0000106040-20-000024:notes:96]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 3, 2020 and March 29, 2019, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of April 3, 2020 or June 28, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-20-000024:notes:97]
Leases and Other Commitments 
Leases

[0000106040-20-000024:notes:98]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of April 3, 2020:

[0000106040-20-000024:notes:99]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | (in millions) |  |  |  |  |  |  |  |  |
| Remaining three months of 2020 | $ | 12 |  |  |  |  |  |  |  |  |  |
| 2021 | 43 |  |  |  |  |  |  |  |  |  |
| 2022 | 30 |  |  |  |  |  |  |  |  |  |
| 2023 | 26 |  |  |  |  |  |  |  |  |  |
| 2024 | 28 |  |  |  |  |  |  |  |  |  |
| Thereafter | 170 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 309 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | (61) |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 248 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 34 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 214 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 233 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 9.3 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.2 | % |  |  |  |  |  |  |  |  |

[0000106040-20-000024:notes:100]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases for the three and nine months ended April 3, 2020:

[0000106040-20-000024:notes:101]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Cost of operating leases | $ | 12 |  |  | $ | 42 |  |  |  |  |  |  |  |
| Cash paid for operating leases | 12 |  |  | 41 |  |  |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 1 |  |  | 51 |  |  |  |  |  |  |  |

[0000106040-20-000024:notes:102]
[same as prior period, unchanged from 0000106040-20-000011:notes:113]

[0000106040-20-000024:notes:103]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of April 3, 2020, the Company had the following minimum long-term commitments:

[0000106040-20-000024:notes:104]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining three months of 2020 |  | $ | 61 |  |
| 2021 |  | 320 |  |
| 2022 |  | 510 |  |
| 2023 |  | 563 |  |
| 2024 |  | 260 |  |
| Thereafter |  | 338 |  |
| Total |  | $ | 2,052 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-20-000024:notes:105]
Shareholders’ Equity
Stock-based Compensation Expense

[0000106040-20-000024:notes:106]
[same as prior period, unchanged from 0000106040-20-000011:notes:118]

[0000106040-20-000024:notes:107]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Options | $ | 1 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 12 |  |  |  |
| Restricted and performance stock units | 68 |  |  | 71 |  |  | 204 |  |  | 208 |  |  |  |
| Employee stock purchase plan | 9 |  |  | 10 |  |  | 23 |  |  | 22 |  |  |  |
| Total | $ | 78 |  |  | $ | 84 |  |  | $ | 232 |  |  | $ | 242 |  |  |  |

[0000106040-20-000024:notes:108]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Cost of revenue | $ | 13 |  |  | $ | 13 |  |  | $ | 38 |  |  | $ | 37 |  |  |  |
| Research and development | 41 |  |  | 41 |  |  | 123 |  |  | 122 |  |  |  |
| Selling, general and administrative | 24 |  |  | 30 |  |  | 71 |  |  | 83 |  |  |  |
| Subtotal | 78 |  |  | 84 |  |  | 232 |  |  | 242 |  |  |  |
| Tax benefit | (9) |  |  | (14) |  |  | (32) |  |  | (39) |  |  |  |
| Total | $ | 69 |  |  | $ | 70 |  |  | $ | 200 |  |  | $ | 203 |  |  |  |

[0000106040-20-000024:notes:109]
[same as prior period, unchanged from 0000106040-20-000011:notes:121]

[0000106040-20-000024:notes:110]
Compensation cost related to unvested stock options, restricted stock units (“RSUs”), performance-based stock units (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of April 3, 2020:

[0000106040-20-000024:notes:111]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 2 |  |  | 0.3 |
| RSUs and PSUs (1) | 610 |  |  | 2.6 |
| ESPP | 41 |  |  | 1.2 |
| Total unamortized compensation cost | $ | 653 |  |  |  |

[0000106040-20-000024:notes:112]
(1) Weighted average service period assumes the performance metrics are met for the PSUs.

[0000106040-20-000024:notes:113]
[same as prior period, unchanged from 0000106040-20-000011:notes:125]

[0000106040-20-000024:notes:114]
[same as prior period, unchanged from 0000106040-20-000011:notes:126]

[0000106040-20-000024:notes:115]
[same as prior period, unchanged from 0000106040-20-000011:notes:127]

[0000106040-20-000024:notes:116]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 28, 2019 | 3.9 |  |  | $ | 65.72 |  |  |  |  |  |
| Exercised | (0.8) |  |  | 43.39 |  |  |  |  | $ | 11 |  |
| Canceled or expired | (0.3) |  |  | 92.67 |  |  |  |  |  |
| Options outstanding at April 3, 2020 | 2.8 |  |  | 68.97 |  |  | 2.3 |  | $ | — |  |
| Exercisable at April 3, 2020 | 2.6 |  |  | 70.89 |  |  | 2.2 |  | $ | — |  |

[0000106040-20-000024:notes:117]
[same as prior period, unchanged from 0000106040-20-000011:notes:129]

[0000106040-20-000024:notes:118]
[same as prior period, unchanged from 0000106040-20-000011:notes:130]

[0000106040-20-000024:notes:119]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2019 | 11.6 |  |  | $ | 62.07 |  |  |  |
| Granted | 7.0 |  |  | 56.08 |  |  |  |
| Vested | (4.2) |  |  | 58.21 |  |  | $ | 243 |  |
| Forfeited | (1.1) |  |  | 63.28 |  |  |  |
| RSUs and PSUs outstanding at April 3, 2020 | 13.3 |  |  | 61.56 |  |  |  |

[0000106040-20-000024:notes:120]
[same as prior period, unchanged from 0000106040-20-000011:notes:132]

[0000106040-20-000024:notes:121]
[same as prior period, unchanged from 0000106040-20-000011:notes:133]

[0000106040-20-000024:notes:122]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. For the nine months ended April 3, 2020, the Company did not make any stock repurchases. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of April 3, 2020 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-20-000024:notes:123]
[same as prior period, unchanged from 0000106040-20-000011:notes:135]

[0000106040-20-000024:notes:124]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the nine months ended April 3, 2020, the Company declared aggregate cash dividends of $1.50 per share on its outstanding common stock totaling $448 million, of which $150 million was paid on April 17, 2020. The Company has since suspended its dividend to reinvest in the business and to support its ongoing deleveraging efforts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-20-000024:notes:125]
Income Tax Expense
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted in response to the COVID-19 pandemic in the U.S. The CARES Act, among other things, allows NOLs arising in tax years 2018, 2019, and 2020 to be carried back to each of the five preceding taxable years to generate a refund of previously paid income taxes and increases the business interest expense limitation from 30% to 50% of adjusted taxable income for tax years 2019 and 2020. Additionally, countries around the world continue to implement emergency tax measures to provide relief similar to the CARES Act. The Company at present does not expect any of the provisions of the CARES Act or the emergency tax measures around the world would result in a material cash benefit. However, the Company continues to monitor and evaluate the regulatory and interpretive guidance related to the CARES Act as well as in other jurisdictions.

[0000106040-20-000024:notes:126]
[same as prior period, unchanged from 0000106040-20-000011:notes:138]

[0000106040-20-000024:notes:127]
[same as prior period, unchanged from 0000106040-20-000011:notes:139]

[0000106040-20-000024:notes:128]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | $ | 46 |  |  | $ | (477) |  |  | $ | (231) |  |  | $ | 187 |  |  |  |
| Income tax expense | 29 |  |  | 104 |  |  | 167 |  |  | 744 |  |  |  |
| Effective tax rate | 63 | % |  | (22) | % |  | (72) | % |  | 398 | % |  |  |

[0000106040-20-000024:notes:129]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the nine months ended April 3, 2020 includes the discrete effect of a de-recognition of $31 million for certain deferred tax assets associated with the Company’s creditable foreign withholding taxes due to the issuance of final regulatory guidance. The regulatory guidance does not preclude the Company from potentially claiming these creditable taxes as a period benefit when paid.

[0000106040-20-000024:notes:130]
The primary driver of the difference between the effective tax rate for the three and nine months ended March 29, 2019 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended March 29, 2019, these discrete effects consist of an income tax benefit of $71 million related to the mandatory deemed repatriation tax. For the nine months ended March 29, 2019, these discrete effects consist of $107 million related to the mandatory deemed repatriation tax and $152 million related to the Company’s decision to change its indefinite reinvestment assertion. For both periods, the remaining difference primarily is attributable to an increase in the estimated effective tax rate due to changes in the relative mix of earnings by jurisdiction, partially offset by credits and tax holidays.

[0000106040-20-000024:notes:131]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest and penalties. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest and penalties. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. On May 4, 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The Company continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-20-000024:notes:132]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of April 3, 2020, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-20-000024:notes:133]
As of April 3, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $710 million. Accrued interest and penalties related to unrecognized tax benefits as of April 3, 2020 was approximately $136 million. Of these amounts, approximately $716 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-20-000024:notes:134]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-20-000024:notes:135]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions, except per share data) |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 17 |  |  | $ | (581) |  |  | $ | (398) |  |  | $ | (557) |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 299 |  |  | 292 |  |  | 298 |  |  | 291 |  |  |  |
| Employee stock options, RSUs, PSUs and ESPP | 4 |  |  | — |  |  | — |  |  | — |  |  |  |
| Diluted | 303 |  |  | 292 |  |  | 298 |  |  | 291 |  |  |  |
| Income (loss) per common share |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.06 |  |  | $ | (1.99) |  |  | $ | (1.34) |  |  | $ | (1.91) |  |  |  |
| Diluted | $ | 0.06 |  |  | $ | (1.99) |  |  | $ | (1.34) |  |  | $ | (1.91) |  |  |  |
| Anti-dilutive potential common shares excluded | 3 |  |  | 17 |  |  | 15 |  |  | 17 |  |  |  |

[0000106040-20-000024:notes:136]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended April 3, 2020, the Company excluded common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For the nine months ended April 3, 2020 and the three and nine months ended March 29, 2019, the Company recorded net losses, and all shares subject to outstanding equity awards have been excluded for those periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-20-000024:notes:137]
Employee Termination, Asset Impairment and Other Charges
The Company recorded the following charges related to employee termination benefits, asset impairment, and other charges:

[0000106040-20-000024:notes:138]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | 1 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 16 |  |  |  |
| Business Realignment | 7 |  |  | 71 |  |  | 37 |  |  | 126 |  |  |  |
| Total employee termination and other charges | 8 |  |  | 76 |  |  | 42 |  |  | 142 |  |  |  |
| Gain on disposition of assets: |  |  |  |  |  |  |  |  |  |
| Business Realignment | — |  |  | — |  |  | (17) |  |  | — |  |  |  |
| Total gain on disposition of assets | — |  |  | — |  |  | (17) |  |  | — |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 8 |  |  | $ | 76 |  |  | $ | 25 |  |  | $ | 142 |  |  |  |

[0000106040-20-000024:notes:139]
[same as prior period, unchanged from 0000106040-20-000011:notes:153]

[0000106040-20-000024:notes:140]
[same as prior period, unchanged from 0000106040-20-000011:notes:154]

[0000106040-20-000024:notes:141]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the nine months ended April 3, 2020:

[0000106040-20-000024:notes:142]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 28, 2019 | $ | 30 |  |  | $ | 2 |  |  | $ | 32 |  |
| Charges | 3 |  |  | 2 |  |  | 5 |  |
| Cash payments | (26) |  |  | (4) |  |  | (30) |  |
| Accrual balance at April 3, 2020 | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0000106040-20-000024:notes:143]
[same as prior period, unchanged from 0000106040-20-000011:notes:157]

[0000106040-20-000024:notes:144]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. In addition to the amounts recognized under Business Realignment as presented above, the Company recognized $5 million of accelerated depreciation on facility assets in Cost of revenue and Operating expenses in the Condensed Consolidated Statements of Operations for the nine months ended April 3, 2020.

[0000106040-20-000024:notes:145]
The following table presents an analysis of the components of the activity against the reserve during the nine months ended April 3, 2020:

[0000106040-20-000024:notes:146]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 28, 2019 | $ | 37 |  |  | $ | 8 |  |  | $ | 45 |  |
| Charges | 16 |  |  | 4 |  |  | 20 |  |
| Cash payments | (39) |  |  | (12) |  |  | (51) |  |
| Accrual balance at April 3, 2020 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-20-000024:notes:147]
The Company recorded the following charges related to employee termination benefits, asset impairment, and other charges:


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-20-000024:notes:148]
Legal Proceedings
Tax

[0000106040-20-000024:notes:149]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 12, Income Tax Expense.

[0000106040-20-000024:notes:150]
Other Matters

[0000106040-20-000024:notes:151]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
