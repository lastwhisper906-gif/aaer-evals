# WDC MD&A — 0000106040-20-000024


## mdna

[0000106040-20-000024:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-20-000024:mdna:2]
[same as prior period, unchanged from 0000106040-20-000011:mdna:2]

[0000106040-20-000024:mdna:3]
[same as prior period, unchanged from 0000106040-20-000011:mdna:3]

[0000106040-20-000024:mdna:4]
[same as prior period, unchanged from 0000106040-20-000011:mdna:4]

[0000106040-20-000024:mdna:5]
[same as prior period, unchanged from 0000106040-20-000011:mdna:5]

[0000106040-20-000024:mdna:6]
[same as prior period, unchanged from 0000106040-20-000011:mdna:6]

[0000106040-20-000024:mdna:7]
[same as prior period, unchanged from 0000106040-20-000011:mdna:7]

[0000106040-20-000024:mdna:8]
COVID-19 Pandemic

[0000106040-20-000024:mdna:9]
In December 2019, coronavirus disease 2019 (“COVID-19”) was first reported in Wuhan, China, and on March 11, 2020, the World Health Organization declared COVID-19 a pandemic. In recent months, the COVID-19 outbreak has spread globally and has led governments and other authorities around the world, including federal, state and local authorities in the United States, to impose measures intended to reduce its spread, including restrictions on freedom of movement and business operations such as travel bans, border closings, business limitations and closures (subject to exceptions for essential operations and businesses), quarantines and shelter-in-place orders. These measures may remain in place for a significant amount of time. In light of these events, we have taken actions to protect the health and safety of our employees while continuing to serve our global customers as an essential business. We have implemented more thorough sanitation practices as outlined by health organizations and instituted social distancing policies at our locations around the world, including working from home, limiting the number of employees attending meetings, reducing the number of people in our sites at any one time, and suspending employee travel. These actions have resulted in some reductions of production levels as we adapt to a more limited number of employees in facilities and, as a result, we incurred charges of approximately $13 million in cost of revenue related to under-absorbed overhead and higher logistics and other costs during the three months ended April 3, 2020. In the near term, we expect COVID-19 related charges to be higher in the fourth quarter, partially offset by increased pricing for our products.

[0000106040-20-000024:mdna:10]
As an essential business, we continue to provide products and solutions that enable the proliferation of data and facilitate the sharing of information remotely, which has become more critical as much of the world is interacting from areas of self-isolation. While we have experienced some reductions of sales in certain areas such as retail in our Client Solutions end market where brick and mortar operations were impacted, we have seen strong demand for capacity enterprise products in our Data Center Devices and Solutions end market as the current environment has accelerated the movement to the Cloud. As such, our net revenue for the third quarter was not significantly impacted by COVID-19. However, we cannot predict the duration of this crisis and how demand may change if it becomes more protracted.

[0000106040-20-000024:mdna:11]
We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “The recent COVID-19 pandemic could adversely affect our business, results of operations and financial condition” in Part II, Item 1A, Risk Factors, of this Quarterly Report on Form 10-Q for more information regarding the risks we face as a result of the COVID-19 pandemic.

[0000106040-20-000024:mdna:12]
[same as prior period, unchanged from 0000106040-20-000011:mdna:8]

[0000106040-20-000024:mdna:13]
[same as prior period, unchanged from 0000106040-20-000011:mdna:9]

[0000106040-20-000024:mdna:14]
Since its inception, Flash Ventures’ primary manufacturing site has been located in Yokkaichi, Japan, which currently includes five wafer fabrication facilities. These facilities historically operated near 100% of their manufacturing capacity. As a result of supply/demand imbalance for flash-based products arising in the prior year, we temporarily reduced our utilization of our share of Flash Ventures’ manufacturing capacity to an abnormally low level for several quarters to more closely align our flash-based wafer supply with the projected demand. As a result of this temporary reduction to abnormally low production levels, we incurred costs of $148 million and $197 million associated with the reduction in utilization, which was recorded as a charge to cost of revenue in the three and nine months ended March 29, 2019, respectively. In addition, production levels at the Yokkaichi site were temporarily reduced as a result of an unexpected power outage incident that occurred in the Yokkaichi region on June 15, 2019. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production. The incident resulted in a reduction of our flash wafer availability by approximately 4 exabytes, the majority of which was contained in the first quarter of fiscal year 2020. As a result of this power outage incident, we incurred aggregate charges of $68 million and $145 million recorded in Cost of revenue in the quarters ended October 4, 2019 and June 28, 2019, respectively, which primarily consisted of the write-off of damaged inventory and unabsorbed manufacturing overhead costs. We continue to pursue recovery of our losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-20-000024:mdna:15]
In May 2019, we entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. We have paid for most of our share of initial K1 equipment investments and relocation costs, with approximately $65 million remaining to be paid in the fourth quarter of fiscal year 2020.  Other period expenses associated with the initial production ramp at K1 will begin trailing off as output increases toward the end of the calendar year. We also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 3, 2020, remaining committed prepayments totaled $205 million.

[0000106040-20-000024:mdna:16]
[same as prior period, unchanged from 0000106040-20-000011:mdna:12]

[0000106040-20-000024:mdna:17]
In September 2019, we announced the sale of our IntelliFlash business and our strategic intention to exit Storage Systems, which consists of IntelliFlash and ActiveScale. These actions will allow us to redirect investments to other higher value priorities. In November 2019, the Company completed its sale of IntelliFlash for a price of $28 million, to be collected over the next three years. The sale of our IntelliFlash business included an immaterial amount of inventory, other tangible and intangible assets, and goodwill and resulted in a gain of approximately $17 million recorded in Employee termination, asset impairment, and other charges in the Condensed Consolidated Statements of Operations for both the three and nine months ended January 3, 2020. Additionally, in March 2020, we completed the sale of ActiveScale. The net assets sold and the proceeds from the sale of ActiveScale were not material.

[0000106040-20-000024:mdna:18]
[same as prior period, unchanged from 0000106040-20-000011:mdna:14]

[0000106040-20-000024:mdna:19]
Third Quarter and Nine Month Overview

[0000106040-20-000024:mdna:20]
[same as prior period, unchanged from 0000106040-20-000011:mdna:16]

[0000106040-20-000024:mdna:21]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | April 3,2020 |  |  |  | March 29,2019 |  |  |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue, net | $ | 4,175 |  |  | 100.0 | % |  | $ | 3,674 |  |  | 100.0 | % |  | $ | 501 |  |  | 14 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,170 |  |  | 75.9 |  |  | 3,095 |  |  | 84.2 |  |  | 75 |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,005 |  |  | 24.1 |  |  | 579 |  |  | 15.8 |  |  | 426 |  |  | 74 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 563 |  |  | 13.5 |  |  | 544 |  |  | 14.8 |  |  | 19 |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 281 |  |  | 6.7 |  |  | 353 |  |  | 9.6 |  |  | (72) |  |  | (20) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 8 |  |  | 0.2 |  |  | 76 |  |  | 2.1 |  |  | (68) |  |  | (89) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 852 |  |  | 20.4 |  |  | 973 |  |  | 26.5 |  |  | (121) |  |  | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 153 |  |  | 3.7 |  |  | (394) |  |  | (10.7) |  |  | 547 |  |  | (139) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 6 |  |  | 0.1 |  |  | 13 |  |  | 0.4 |  |  | (7) |  |  | (54) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (99) |  |  | (2.4) |  |  | (118) |  |  | (3.2) |  |  | 19 |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (14) |  |  | (0.3) |  |  | 22 |  |  | 0.6 |  |  | (36) |  |  | (164) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (107) |  |  | (2.6) |  |  | (83) |  |  | (2.3) |  |  | (24) |  |  | 29 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 46 |  |  | 1.1 |  |  | (477) |  |  | (13.0) |  |  | 523 |  |  | (110) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 29 |  |  | 0.7 |  |  | 104 |  |  | 2.8 |  |  | (75) |  |  | (72) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 17 |  |  | 0.4 |  |  | $ | (581) |  |  | (15.8) |  |  | 598 |  |  | (103) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-20-000024:mdna:22]
(1) Percentages may not total due to rounding.

[0000106040-20-000024:mdna:23]
40

[0000106040-20-000024:mdna:24]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | April 3,2020 |  |  |  | March 29,2019 |  |  |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue, net | $ | 12,449 |  |  | 100.0 | % |  | $ | 12,935 |  |  | 100.0 | % |  | $ | (486) |  |  | (4) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 9,751 |  |  | 78.3 |  |  | 9,648 |  |  | 74.6 |  |  | 103 |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 2,698 |  |  | 21.7 |  |  | 3,287 |  |  | 25.4 |  |  | (589) |  |  | (18) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,715 |  |  | 13.8 |  |  | 1,659 |  |  | 12.8 |  |  | 56 |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 884 |  |  | 7.1 |  |  | 1,018 |  |  | 7.9 |  |  | (134) |  |  | (13) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 25 |  |  | 0.2 |  |  | 142 |  |  | 1.1 |  |  | (117) |  |  | (82) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 2,624 |  |  | 21.1 |  |  | 2,819 |  |  | 21.8 |  |  | (195) |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 74 |  |  | 0.6 |  |  | 468 |  |  | 3.6 |  |  | (394) |  |  | (84) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 26 |  |  | 0.2 |  |  | 43 |  |  | 0.3 |  |  | (17) |  |  | (40) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (326) |  |  | (2.6) |  |  | (352) |  |  | (2.7) |  |  | 26 |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (5) |  |  | — |  |  | 28 |  |  | 0.2 |  |  | (33) |  |  | (118) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (305) |  |  | (2.4) |  |  | (281) |  |  | (2.2) |  |  | (24) |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | (231) |  |  | (1.9) |  |  | 187 |  |  | 1.4 |  |  | (418) |  |  | (224) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 167 |  |  | 1.3 |  |  | 744 |  |  | 5.8 |  |  | (577) |  |  | (78) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (398) |  |  | (3.2) |  |  | $ | (557) |  |  | (4.3) |  |  | 159 |  |  | (29) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-20-000024:mdna:25]
(1) Percentages may not total due to rounding.

[0000106040-20-000024:mdna:26]
[same as prior period, unchanged from 0000106040-20-000011:mdna:21]

[0000106040-20-000024:mdna:27]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |

[0000106040-20-000024:mdna:28]
[same as prior period, unchanged from 0000106040-20-000011:mdna:24]

[0000106040-20-000024:mdna:29]
The increase in net revenue for the three months ended April 3, 2020 from the comparable period in the prior year reflects higher volumes of memory for both HDD and flash products that contributed approximately 15 and 17 percentage points of growth, respectively, which were partially offset by lower average selling prices. Client Devices revenue increased 13% year over year. Higher volumes of memory contributed 16 percentage points of growth, primarily from client compute SSD and mobililty, partially offset by lower HDD pricing. Our revenue for Data Center Devices and Solutions increased 22% year over year, with volumes up 38% due to strength in both capacity enterprise HDD and SSD, partially offset by lower average selling prices with more efficient form factors. Client Solutions revenue increased 2% year over year with volume of memory up approximately 12 percentage points , primarily in flash products, partially offset by lower year-over-year pricing. While pricing for flash products remains down compared to the prior year, pricing has increased compared to last quarter and we expect flash pricing to continue to increase in the near term, if supply and demand become more closely aligned as expected.

[0000106040-20-000024:mdna:30]
The slight decrease in net revenue for the nine months ended April 3, 2020 from the comparable period in the prior year reflects lower average selling prices which generated approximately 31 percentage points of the year-over-year decline, partially offset by higher HDD volumes contributing approximately 17 percentage points of growth and higher volumes of flash products contributing approximately 10 percentage points of growth. Client Devices revenue decreased 19% year over year, with approximately 14 percentage points due to lower average selling prices, predominantly related to flash products, and lower volumes for HDD products. Our revenue for Data Center Devices and Solutions increased 21% year over year, resulting from an approximately 44 percentage points of growth in volume of memory, primarily driven by strength in capacity enterprise HDD, partially offset by lower average selling prices with more efficient form factors. Client Solutions revenue was essentially flat year over year, with approximately 12 percentage points of growth from higher volumes of memory largely offset by lower prices on retail products.

[0000106040-20-000024:mdna:31]
The changes in net revenue by geography for the year to date reflect a decrease in Asia earlier this year primarily driven by our decision to limit our participation in the mobile market resulting in lower sales to manufacturers in the Asia region and a slight increase in the Americas driven by increased sales of capacity enterprise HDD.

[0000106040-20-000024:mdna:32]
Our top 10 customers accounted for 44% of our net revenue for both the three and nine months ended April 3, 2020, and 41% and 45% of our net revenue for the three and nine months ended March 29, 2019, respectively. For the three and nine months ended April 3, 2020 and March 29, 2019, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-20-000024:mdna:33]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended April 3, 2020, these programs represented 15% and 16%, respectively, of gross revenues. For the three and nine months ended March 29, 2019, these programs represented 17% and 15%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-20-000024:mdna:34]
[same as prior period, unchanged from 0000106040-20-000011:mdna:30]

[0000106040-20-000024:mdna:35]
The increase in Gross profit for the three months ended April 3, 2020 from the comparable period in the prior year was primarily due to the increase in revenues for the period as noted above, as well as manufacturing underutilization charges of $148 million incurred in the prior year, a charge to cost of revenue of $110 million in the prior year primarily to reduce component inventory to net realizable value for flash-based multi-chip package products that include externally-sourced dynamic random access memory products, and $43 million of higher charges in the prior year related to amortization expense on acquired intangible assets. Gross margin increased 8 percentage points for the three months ended April 3, 2020 from the comparable period in the prior year, substantially all of which is attributable to these costs in the prior year.

[0000106040-20-000024:mdna:36]
The decrease in Gross profit for the nine months ended April 3, 2020 from the comparable periods in the prior year was due to the decrease in revenues for the period as noted above, partially offset by lower aggregate charges for amortization expense on acquired intangible assets, manufacturing underutilization charges, the charge to reduce inventory to net realizable value, and charges related to the power outage incident. These charges aggregated $534 million and $945 million, or 4% and 7% of net revenue, for the nine-month periods ended April 3, 2020 and March 29, 2019, respectively. Gross margin declined 3 percentage points for the nine months ended April 3, 2020 from the comparable period in the prior year, with substantially all of the decline attributable to the lower aggregate charges noted above.

[0000106040-20-000024:mdna:37]
[same as prior period, unchanged from 0000106040-20-000011:mdna:32]

[0000106040-20-000024:mdna:38]
Research and development (“R&D”) expense increased $19 million for the three months ended April 3, 2020 from the comparable period in the prior year primarily due to increased variable compensation. R&D expense increased $56 million for the nine months ended April 3, 2020 from the comparable period in the prior year, reflecting approximately $30 million of additional expense related to the additional week in the current year with the remainder primarily attributable to higher variable compensation.

[0000106040-20-000024:mdna:39]
Selling, general and administrative (“SG&A”) expense decreased $72 million for the three months ended April 3, 2020 from the comparable period in the prior year primarily due to approximately $50 million lower litigation-related and outside services costs as well as savings realized from our cost reduction actions. SG&A expense decreased $134 million for the nine months ended April 3, 2020 from the comparable period in the prior year primarily due to approximately $80 million lower litigation-related and outside services costs, approximately $40 million of savings from the exit of our storage systems business as well as savings from our cost reduction actions, partially offset by approximately $10 million of additional expense related to the additional week in the current year.

[0000106040-20-000024:mdna:40]
[same as prior period, unchanged from 0000106040-20-000011:mdna:35]

[0000106040-20-000024:mdna:41]
[same as prior period, unchanged from 0000106040-20-000011:mdna:36]

[0000106040-20-000024:mdna:42]
The increases in total interest and other expense, net for both the three and nine months ended April 3, 2020 primarily reflect less Interest income resulting from lower invested cash in the current year and gains on the sales of investments included in Other income (expense), net in the prior year, partially offset by decreases in Interest expense resulting from the pay-down of principal on our debt and lower index rates.

[0000106040-20-000024:mdna:43]
[same as prior period, unchanged from 0000106040-20-000011:mdna:38]

[0000106040-20-000024:mdna:44]
[same as prior period, unchanged from 0000106040-20-000011:mdna:39]

[0000106040-20-000024:mdna:45]
[same as prior period, unchanged from 0000106040-20-000011:mdna:40]

[0000106040-20-000024:mdna:46]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |
|  | ($ in millions) |  |  |  |  |  |  |  |
| Income (loss) before taxes | $ | 46 |  |  | $ | (477) |  |  | $ | (231) |  |  | $ | 187 |  |  |
| Income tax expense | 29 |  |  | 104 |  |  | 167 |  |  | 744 |  |  |
| Effective tax rate |  | 63 | % |  | (22) | % |  | (72) | % |  | 398 | % |  |

[0000106040-20-000024:mdna:47]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the nine months ended April 3, 2020 includes the discrete effect of a de-recognition of $31 million for certain deferred tax assets associated with creditable foreign withholding taxes due to the issuance of final regulatory guidance. The regulatory guidance does not preclude us from potentially claiming these creditable taxes as a period benefit when paid.

[0000106040-20-000024:mdna:48]
43

[0000106040-20-000024:mdna:49]
The primary driver of the difference between the effective tax rate for the three and nine months ended March 29, 2019 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended March 29, 2019, these discrete effects consist of income tax benefits of $71 million related to the mandatory deemed repatriation. For the nine months ended March 29, 2019, these discrete effects consist of $107 million related to the mandatory deemed repatriation tax and $152 million related to the decision to change our indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to an increase in the estimated effective tax rate due to changes in the relative mix of earnings by jurisdiction, partially offset by credits and tax holidays.

[0000106040-20-000024:mdna:50]
[same as prior period, unchanged from 0000106040-20-000011:mdna:45]

[0000106040-20-000024:mdna:51]
[same as prior period, unchanged from 0000106040-20-000011:mdna:46]

[0000106040-20-000024:mdna:52]
[same as prior period, unchanged from 0000106040-20-000011:mdna:47]

[0000106040-20-000024:mdna:53]
[same as prior period, unchanged from 0000106040-20-000011:mdna:48]

[0000106040-20-000024:mdna:54]
|  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |
| Net cash provided by (used in): |  |  |  |  |  |  |
| Operating activities | $ | 652 |  |  | $ | 1,378 |  |  |  |
| Investing activities | 192 |  |  | (1,042) |  |  |  |
| Financing activities | (1,354) |  |  | (1,657) |  |  |  |
| Effect of exchange rate changes on cash | (2) |  |  | (2) |  |  |  |
| Net decrease in cash and cash equivalents |  | $ | (512) |  |  | $ | (1,323) |  |  |  |

[0000106040-20-000024:mdna:55]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q.

[0000106040-20-000024:mdna:56]
During fiscal 2020, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $1.7 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and cash flow from operations, we expect the Flash Ventures to continue to return cash to our company through net payments on our notes receivable during the remainder of fiscal 2020. As such, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash inflow of approximately $250 million. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-20-000024:mdna:57]
During fiscal 2019, we made the determination that it was our intention to repatriate all of our foreign undistributed earnings as a result of the 2017 Act, except a portion of our foreign undistributed earnings, which could result in additional federal taxes based on interpretive guidance issued by the IRS. After consideration of this interpretative guidance affecting the taxation of a certain portion of our foreign undistributed earnings, we made the determination that we do not intend to repatriate this portion of our foreign undistributed earnings and did not establish an accrual for this liability.

[0000106040-20-000024:mdna:58]
A total of $2.14 billion and $2.37 billion of our Cash and cash equivalents was held outside of the U.S. as of April 3, 2020 and June 28, 2019, respectively. As a result of the change in our permanent reinvestment assertion, there are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-20-000024:mdna:59]
[same as prior period, unchanged from 0000106040-20-000011:mdna:53]

[0000106040-20-000024:mdna:60]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $331 million for the nine months ended April 3, 2020, as compared to $7 million of net cash used for changes in operating assets and liabilities for the nine months ended March 29, 2019. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-20-000024:mdna:61]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  |  |  |  |
|  | (in days) |  |  |  |  |  |  |
| Days sales outstanding | 43 |  |  | 30 |  |  |  |  |  |
| Days in inventory | 89 |  |  | 101 |  |  |  |  |  |
| Days payables outstanding | (63) |  |  | (55) |  |  |  |  |  |
| Cash conversion cycle | 69 |  |  | 76 |  |  |  |  |  |

[0000106040-20-000024:mdna:62]
Changes in days sales outstanding (“DSO”) are generally due to the linearity of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-20-000024:mdna:63]
For the three months ended April 3, 2020, DSO increased by 13 days over the prior year, primarily reflecting lower factoring of receivables and the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO decreased by 12 days over the prior year, reflecting higher stocking levels of HDD inventory in the prior year in response to the plant closure in Kuala Lumpur. DPO increased by 8 days over the prior year, primarily reflecting resumptions of normal flash production volumes as well as routine variations in the timing of purchases and payments during the period.

[0000106040-20-000024:mdna:64]
[same as prior period, unchanged from 0000106040-20-000011:mdna:58]

[0000106040-20-000024:mdna:65]
Net cash provided by investing activities for the nine months ended April 3, 2020 primarily consisted of a $627 million net decrease in notes receivable issuances to Flash Ventures, partially offset by $432 million of capital expenditures and $22 million for acquisitions. Net cash used in investing activities for the nine months ended March 29, 2019 primarily consisted of $722 million of capital expenditures and a net $288 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion.

[0000106040-20-000024:mdna:66]
[same as prior period, unchanged from 0000106040-20-000011:mdna:60]

[0000106040-20-000024:mdna:67]
[same as prior period, unchanged from 0000106040-20-000011:mdna:61]

[0000106040-20-000024:mdna:68]
During the nine months ended April 3, 2020, net cash used in financing activities primarily consisted of $919 million for repayment of debt, $445 million to pay dividends on our common stock and $69 million for taxes paid on vested stock awards under employee stock plans, partially offset by $79 million of proceeds from the issuance of stock under our employee stock plans. Net cash used in financing activities for the nine months ended March 29, 2019 primarily consisted of $613 million for the repayment of our revolving credit facility and other debt, $563 million for share repurchases, $438 million to pay dividends on our common stock and $109 million for taxes paid on vested stock awards under employee stock plans, partially offset by $66 million of proceeds from the issuance of stock under our employee stock plans. We are suspending our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-20-000024:mdna:69]
[same as prior period, unchanged from 0000106040-20-000011:mdna:63]

[0000106040-20-000024:mdna:70]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000024:mdna:71]
46

[0000106040-20-000024:mdna:72]
[same as prior period, unchanged from 0000106040-20-000011:mdna:65]

[0000106040-20-000024:mdna:73]
[same as prior period, unchanged from 0000106040-20-000011:mdna:66]

[0000106040-20-000024:mdna:74]
The following is a summary of our known contractual cash obligations and commercial commitments as of April 3, 2020:

[0000106040-20-000024:mdna:75]
|  | Total |  | Remaining three months of 2020 |  | 2021-2022 |  | 2023-2024 |  | Beyond 2024 |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Long-term debt, including current portion(1) | $ | 9,774 |  |  | $ | 63 |  |  | $ | 537 |  |  | $ | 6,874 |  |  | $ | 2,300 |  |
| Interest on debt | 1,296 |  |  | 50 |  |  | 644 |  |  | 383 |  |  | 219 |  |
| Flash Ventures related commitments(2) | 5,977 |  |  | 991 |  |  | 3,505 |  |  | 1,239 |  |  | 242 |  |
| Operating leases | 309 |  |  | 12 |  |  | 73 |  |  | 54 |  |  | 170 |  |
| Purchase obligations and other commitments | 3,309 |  |  | 1,146 |  |  | 994 |  |  | 831 |  |  | 338 |  |
| Mandatory Deemed Repatriation Tax | 1,039 |  |  | — |  |  | 198 |  |  | 285 |  |  | 556 |  |
| Total | $ | 21,704 |  |  | $ | 2,262 |  |  | $ | 5,951 |  |  | $ | 9,666 |  |  | $ | 3,825 |  |

[0000106040-20-000024:mdna:76]
(1)Principal portion of debt, excluding discounts and issuance costs.

[0000106040-20-000024:mdna:77]
(2)Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0000106040-20-000024:mdna:78]
[same as prior period, unchanged from 0000106040-20-000011:mdna:71]

[0000106040-20-000024:mdna:79]
In addition to our existing debt, we have $2.25 billion available under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2019. The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 3, 2020, we were in compliance with these financial covenants.

[0000106040-20-000024:mdna:80]
[same as prior period, unchanged from 0000106040-20-000011:mdna:73]

[0000106040-20-000024:mdna:81]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of April 3, 2020, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-20-000024:mdna:82]
[same as prior period, unchanged from 0000106040-20-000011:mdna:75]

[0000106040-20-000024:mdna:83]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0000106040-20-000024:mdna:84]
[same as prior period, unchanged from 0000106040-20-000011:mdna:77]

[0000106040-20-000024:mdna:85]
[same as prior period, unchanged from 0000106040-20-000011:mdna:78]

[0000106040-20-000024:mdna:86]
|  |  | April 3,2020 |
| Remaining three months of 2020 |  | $ | — |  |
| 2021 |  | 99 |  |
| 2022 |  | 99 |  |
| 2023 |  | 99 |  |
| 2024 |  | 186 |  |
| 2025 |  | 247 |  |
| 2026 |  | 309 |  |
| Total |  | $ | 1,039 |  |

[0000106040-20-000024:mdna:87]
[same as prior period, unchanged from 0000106040-20-000011:mdna:80]

[0000106040-20-000024:mdna:88]
[same as prior period, unchanged from 0000106040-20-000011:mdna:81]

[0000106040-20-000024:mdna:89]
As of April 3, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $710 million. Accrued interest and penalties related to unrecognized tax benefits as of April 3, 2020 was approximately $136 million. Of these amounts, approximately $716 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-20-000024:mdna:90]
[same as prior period, unchanged from 0000106040-20-000011:mdna:83]

[0000106040-20-000024:mdna:91]
We have generally held a balance of fixed and variable rate debt. At April 3, 2020, we had $6.34 billion of variable rate debt, comprising 65% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $4.34 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual expense by $43 million.

[0000106040-20-000024:mdna:92]
[same as prior period, unchanged from 0000106040-20-000011:mdna:85]

[0000106040-20-000024:mdna:93]
[same as prior period, unchanged from 0000106040-20-000011:mdna:86]

[0000106040-20-000024:mdna:94]
[same as prior period, unchanged from 0000106040-20-000011:mdna:87]

[0000106040-20-000024:mdna:95]
[same as prior period, unchanged from 0000106040-20-000011:mdna:88]

[0000106040-20-000024:mdna:96]
[same as prior period, unchanged from 0000106040-20-000011:mdna:89]

[0000106040-20-000024:mdna:97]
[same as prior period, unchanged from 0000106040-20-000011:mdna:90]

[0000106040-20-000024:mdna:98]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. For the nine months ended April 3, 2020, we did not make any stock repurchases. The remaining amount available to be repurchased under our current stock repurchase program as of April 3, 2020 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-20-000024:mdna:99]
[same as prior period, unchanged from 0000106040-20-000011:mdna:92]

[0000106040-20-000024:mdna:100]
Since the first quarter of 2013, we have issued a quarterly cash dividend. During the nine months ended April 3, 2020, we declared aggregate cash dividends of $1.50 per share on our outstanding common stock totaling $448 million, of which $150 million was paid on April 17, 2020. We are suspending our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-20-000024:mdna:101]
[same as prior period, unchanged from 0000106040-20-000011:mdna:94]

[0000106040-20-000024:mdna:102]
[same as prior period, unchanged from 0000106040-20-000011:mdna:95]

[0000106040-20-000024:mdna:103]
[same as prior period, unchanged from 0000106040-20-000011:mdna:96]

[0000106040-20-000024:mdna:104]
[same as prior period, unchanged from 0000106040-20-000011:mdna:97]

[0000106040-20-000024:mdna:105]
See Part I, Item 1, Note 2, Recent Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for a discussion of a recently adopted accounting pronouncement that affects our accounting for lease obligations. There have been no other material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the fiscal year ended June 28, 2019 for a discussion of our critical accounting policies and estimates.
