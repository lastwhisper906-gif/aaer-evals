# WDC MD&A — 0000106040-24-000022


## mdna

[0000106040-24-000022:mdna:1]
[same as prior period, unchanged from 0000106040-24-000014:mdna:1]

[0000106040-24-000022:mdna:2]
[same as prior period, unchanged from 0000106040-24-000014:mdna:2]

[0000106040-24-000022:mdna:3]
[same as prior period, unchanged from 0000106040-24-000014:mdna:3]

[0000106040-24-000022:mdna:4]
[same as prior period, unchanged from 0000106040-24-000014:mdna:4]

[0000106040-24-000022:mdna:5]
[same as prior period, unchanged from 0000106040-24-000014:mdna:5]

[0000106040-24-000022:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended on June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-24-000022:mdna:7]
[same as prior period, unchanged from 0000106040-24-000014:mdna:7]

[0000106040-24-000022:mdna:8]
[same as prior period, unchanged from 0000106040-24-000014:mdna:8]

[0000106040-24-000022:mdna:9]
On October 30, 2023, we announced that our Board of Directors had completed its strategic review of our business and, after evaluating a comprehensive range of alternatives, authorized us to pursue a plan to separate our HDD and Flash business units to create two independent, public companies. We believe the separation will better position each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, and operate more efficiently with distinct capital structures. The completion of the planned separation is subject to certain conditions, including final approval by our Board of Directors. Significant effort is underway towards completion of the separation of the businesses and we are targeting to complete the separation in the second half of calendar year 2024.

[0000106040-24-000022:mdna:10]
[same as prior period, unchanged from 0000106040-24-000014:mdna:10]

[0000106040-24-000022:mdna:11]
In recent quarters, macroeconomic factors such as inflation, higher interest rates and recession concerns had softened demand for our products, with certain customers reducing purchases as they adjusted their production levels and right-size their inventories. As a result, we and our industry experienced a supply-demand imbalance, which resulted in reduced shipments and negatively impacted pricing, particularly in Flash. To adapt to these conditions, we implemented measures to reduce operating expenses and to proactively manage supply and inventory to align with demand and improve our capital efficiency, while continuing to deploy innovative products. These actions have enabled us to scale back on capital expenditures, consolidate production lines and reduce production bit growth since the beginning of 2023 in order to better align with market demand. These actions resulted in incremental charges for employee termination, asset impairment and other, and manufacturing underutilization charges in Flash and HDD. In the current quarter, we began to see signs of a recovery in supply-demand balance. We believe digital transformation will continue to drive improved market conditions in the near term and long-term growth for data storage in both Flash and HDD.

[0000106040-24-000022:mdna:12]
[same as prior period, unchanged from 0000106040-24-000014:mdna:12]

[0000106040-24-000022:mdna:13]
See Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended June 30, 2023 and Part II, Item 1A, Risk Factors, of our Quarterly Report on Form 10-Q for the three months ended September 29, 2023 and our Quarterly Report on Form 10-Q for the three months ended December 29, 2023 for more information regarding the risks we face as a result of macroeconomic conditions and supply chain disruptions.

[0000106040-24-000022:mdna:14]
Agreement to Sell a Majority Interest in a Subsidiary

[0000106040-24-000022:mdna:15]
In March 2024, our wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) entered into an Equity Purchase Agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), our indirect wholly-owned subsidiary to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a joint venture between SanDisk China and JCET (the “Transaction”). Closing of the transaction is subject to the satisfaction or waiver of certain conditions, after which, JCET will own 80% of the equity interest in SDSS, with SanDisk China owning the remaining 20%. Following the Closing, we expect to enter into various ancillary agreements, including (i) a shareholders agreement governing the joint venture relationships from and after the Closing; (ii) a supply agreement with the joint venture to supply us with certain flash-based products currently produced by SDSS, which may include flash memory cards, embedded flash products, and flash components; and (iii) an intellectual property license agreement granting SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on our behalf for the term of and pursuant to the Supply Agreement.

[0000106040-24-000022:mdna:16]
[same as prior period, unchanged from 0000106040-24-000014:mdna:14]

[0000106040-24-000022:mdna:17]
In August 2023, we drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement we entered into in January 2023 and amended in June 2023, which allowed us to draw a single loan of up to $600 million through August 14, 2023. Proceeds from this loan were primarily used for payments on our tax liability to the Internal Revenue Service (“IRS”) for the years 2008 through 2012. During the nine months ended March 29, 2024, we repaid $300 million of the principal amount of the Delayed Draw Term Loan. The remaining outstanding borrowings on this loan will mature on June 28, 2024.

[0000106040-24-000022:mdna:18]
On November 3, 2023, we issued $1.60 billion aggregate principal amount of convertible senior notes, which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). We received net proceeds of approximately $1.56 billion after issuance costs. Contemporaneously with the issuance of the 2028 Convertible Notes, we entered into individually negotiated transactions with certain holders of our existing 1.50% convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”) to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount using net proceeds from the offering of the 2028 Convertible Notes. In connection with the issuance of the 2028 Convertible Notes, we also used approximately $155 million of the net proceeds from the offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 to hedge the potential dilution impact of the conversion feature. On February 1, 2024, we used a portion of the remaining net proceeds from the offering of the 2028 Convertible Notes to settle the remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-24-000022:mdna:19]
During the three months ended March 29, 2024, we drew and repaid $300 million principal amount under our $2.25 billion revolving credit facility maturing in January 2027.

[0000106040-24-000022:mdna:20]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-24-000022:mdna:21]
[same as prior period, unchanged from 0000106040-24-000014:mdna:18]

[0000106040-24-000022:mdna:22]
[same as prior period, unchanged from 0000106040-24-000014:mdna:19]

[0000106040-24-000022:mdna:23]
43

[0000106040-24-000022:mdna:24]
[same as prior period, unchanged from 0000106040-24-000014:mdna:20]

[0000106040-24-000022:mdna:25]
In connection with the actions described in “Operational Update” above, we reassessed our existing capacity development plans and made a decision in the first quarter of 2024 to cancel certain projects, including projects to expand capacity in our Penang, Malaysia facility. This resulted in a $94 million impairment of existing construction in progress and other assets and recognition of $29 million for certain contract termination costs during the nine months ended March 29, 2024.

[0000106040-24-000022:mdna:26]
[same as prior period, unchanged from 0000106040-24-000014:mdna:22]

[0000106040-24-000022:mdna:27]
As previously disclosed, we had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the nine months ended March 29, 2024, we made payments aggregating $523 million for tax and interest with respect to years 2008 through 2012 and have a remaining liability of $182 million as of March 29, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our “Results of Operations” below, as well as in Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements, and in the “Short- and Long-term Liquidity – Unrecognized Tax Benefits” section below.

[0000106040-24-000022:mdna:28]
[same as prior period, unchanged from 0000106040-24-000014:mdna:24]

[0000106040-24-000022:mdna:29]
[same as prior period, unchanged from 0000106040-24-000014:mdna:25]

[0000106040-24-000022:mdna:30]
Third Quarter and Nine Month Overview

[0000106040-24-000022:mdna:31]
[same as prior period, unchanged from 0000106040-24-000014:mdna:27]

[0000106040-24-000022:mdna:32]
|  | Three Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 3,457 |  |  | 100.0 | % |  | $ | 2,803 |  |  | 100.0 | % |  | $ | 654 |  |  | 23 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,456 |  |  | 71.0 |  |  | 2,517 |  |  | 89.8 |  |  | (61) |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,001 |  |  | 29.0 |  |  | 286 |  |  | 10.2 |  |  | 715 |  |  | 250 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 494 |  |  | 14.3 |  |  | 476 |  |  | 17.0 |  |  | 18 |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 203 |  |  | 5.9 |  |  | 242 |  |  | 8.6 |  |  | (39) |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other | 8 |  |  | 0.2 |  |  | 40 |  |  | 1.4 |  |  | (32) |  |  | (80) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 23 |  |  | 0.7 |  |  | — |  |  | — |  |  | 23 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 728 |  |  | 21.1 |  |  | 758 |  |  | 27.0 |  |  | (30) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 273 |  |  | 7.9 |  |  | (472) |  |  | (16.8) |  |  | 745 |  |  | (158) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 0.3 |  |  | 10 |  |  | 0.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (108) |  |  | (3.1) |  |  | (80) |  |  | (2.9) |  |  | (28) |  |  | 35 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 3 |  |  | 0.1 |  |  | 14 |  |  | 0.5 |  |  | (11) |  |  | (79) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (95) |  |  | (2.7) |  |  | (56) |  |  | (2.0) |  |  | (39) |  |  | 70 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 178 |  |  | 5.1 |  |  | (528) |  |  | (18.8) |  |  | 706 |  |  | (134) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 43 |  |  | 1.2 |  |  | 43 |  |  | 1.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 135 |  |  | 3.9 |  |  | (571) |  |  | (20.4) |  |  | 706 |  |  | (124) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 15 |  |  | 0.4 |  |  | 9 |  |  | 0.3 |  |  | 6 |  |  | 67 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: income attributable to preferred shareholders | 7 |  |  | 0.2 |  |  | — |  |  | — |  |  | 7 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 113 |  |  | 3.3 | % |  | $ | (580) |  |  | (20.7) | % |  | $ | 693 |  |  | (119) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-24-000022:mdna:33]
[same as prior period, unchanged from 0000106040-24-000014:mdna:29]

[0000106040-24-000022:mdna:34]
[same as prior period, unchanged from 0000106040-24-000014:mdna:30]

[0000106040-24-000022:mdna:35]
|  | Nine Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 9,239 |  |  | 100.0 | % |  | $ | 9,646 |  |  | 100.0 | % |  | $ | (407) |  |  | (4) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 7,647 |  |  | 82.8 |  |  | 7,851 |  |  | 81.4 |  |  | (204) |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,592 |  |  | 17.2 |  |  | 1,795 |  |  | 18.6 |  |  | (203) |  |  | (11) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,369 |  |  | 14.8 |  |  | 1,551 |  |  | 16.1 |  |  | (182) |  |  | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 608 |  |  | 6.6 |  |  | 739 |  |  | 7.7 |  |  | (131) |  |  | (18) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other | 89 |  |  | 1.0 |  |  | 140 |  |  | 1.5 |  |  | (51) |  |  | (36) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 59 |  |  | 0.6 |  |  | — |  |  | — |  |  | 59 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 2,125 |  |  | 23.0 |  |  | 2,430 |  |  | 25.2 |  |  | (305) |  |  | (13) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating loss | (533) |  |  | (5.8) |  |  | (635) |  |  | (6.6) |  |  | 102 |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 30 |  |  | 0.3 |  |  | 15 |  |  | 0.2 |  |  | 15 |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (314) |  |  | (3.4) |  |  | (223) |  |  | (2.3) |  |  | (91) |  |  | 41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 54 |  |  | 0.6 |  |  | 27 |  |  | 0.3 |  |  | 27 |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (230) |  |  | (2.5) |  |  | (181) |  |  | (1.9) |  |  | (49) |  |  | 27 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss before taxes | (763) |  |  | (8.3) |  |  | (816) |  |  | (8.5) |  |  | 53 |  |  | (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 74 |  |  | 0.8 |  |  | 159 |  |  | 1.6 |  |  | (85) |  |  | (53) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | (837) |  |  | (9.1) |  |  | (975) |  |  | (10.1) |  |  | 138 |  |  | (14) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 44 |  |  | 0.5 |  |  | 9 |  |  | 0.1 |  |  | 35 |  |  | 389 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: income attributable to preferred shareholders | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to common shareholders | $ | (881) |  |  | (9.5) | % |  | $ | (984) |  |  | (10.2) | % |  | $ | 103 |  |  | (10) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-24-000022:mdna:36]
[same as prior period, unchanged from 0000106040-24-000014:mdna:32]

[0000106040-24-000022:mdna:37]
[same as prior period, unchanged from 0000106040-24-000014:mdna:33]

[0000106040-24-000022:mdna:38]
[same as prior period, unchanged from 0000106040-24-000014:mdna:34]

[0000106040-24-000022:mdna:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | $ in millions |
| Revenue, net: |  |  |  |  |  |  |  |
| Flash | $ | 1,705 |  |  | $ | 1,307 |  |  | $ | 4,926 |  |  | $ | 4,686 |  |
| HDD | 1,752 |  |  | 1,496 |  |  | 4,313 |  |  | 4,960 |  |
| Total net revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 467 |  |  | $ | (65) |  |  | $ | 437 |  |  | $ | 597 |  |
| HDD | 545 |  |  | 363 |  |  | 1,157 |  |  | 1,237 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (11) |  |  | (12) |  |  | (37) |  |  | (38) |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (2) |  |  | (1) |  |
| Recovery from contamination incident | 1 |  |  | — |  |  | 37 |  |  | — |  |
| Total unallocated corporate items | (11) |  |  | (12) |  |  | (2) |  |  | (39) |  |
| Consolidated gross profit | $ | 1,001 |  |  | $ | 286 |  |  | $ | 1,592 |  |  | $ | 1,795 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 27.4 | % |  | (5.0) | % |  | 8.9 | % |  | 12.7 | % |
| HDD | 31.1 | % |  | 24.3 | % |  | 26.8 | % |  | 24.9 | % |
| Consolidated gross margin | 29.0 | % |  | 10.2 | % |  | 17.2 | % |  | 18.6 | % |

[0000106040-24-000022:mdna:40]
[same as prior period, unchanged from 0000106040-24-000014:mdna:36]

[0000106040-24-000022:mdna:41]
[same as prior period, unchanged from 0000106040-24-000014:mdna:37]

[0000106040-24-000022:mdna:42]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 1,553 |  |  | $ | 1,205 |  |  | $ | 3,496 |  |  | $ | 4,258 |  |
| Client | 1,174 |  |  | 975 |  |  | 3,443 |  |  | 3,293 |  |
| Consumer | 730 |  |  | 623 |  |  | 2,300 |  |  | 2,095 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,740 |  |  | $ | 1,353 |  |  | $ | 4,990 |  |  | $ | 4,533 |  |
| Americas | 1,154 |  |  | 935 |  |  | 2,620 |  |  | 3,448 |  |
| Europe, Middle East and Africa | 563 |  |  | 515 |  |  | 1,629 |  |  | 1,665 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |

[0000106040-24-000022:mdna:43]
[same as prior period, unchanged from 0000106040-24-000014:mdna:39]

[0000106040-24-000022:mdna:44]
Comparison of Three and Nine Months Ended March 29, 2024 to Three and Nine Months Ended March 31, 2023

[0000106040-24-000022:mdna:45]
The increase in consolidated net revenue for the three months ended March 29, 2024 from the comparable period in the prior year reflected growth in exabytes shipped and a better pricing environment, resulting from a recent improvement in the supply-demand balance as discussed in the “Key Developments – Operational Update” section above. The decrease in consolidated net revenue for the nine months ended March 29, 2024 from the comparable period in the prior year reflected the impact of the supply-demand imbalance in the first half of the year prior to the recent improvement in supply-demand conditions.

[0000106040-24-000022:mdna:46]
Flash revenue increased 30% for the three months ended March 29, 2024 from the comparable period in the prior year, reflecting a 20% increase in exabytes sold and a 10% increase in average selling prices per gigabyte. The increase in exabytes sold was due to improved demand from our OEM customers in our Client end market and from products across our Consumer and Cloud end market. The increase in average selling prices per gigabyte was due to improved pricing as we started to see demand stabilizing. Flash revenue increased 5% for the nine months ended March 29, 2024 from the comparable period in the prior year, reflecting a 30% increase in exabytes sold, partially offset by a 19% decline in average selling prices per gigabyte. The increase in exabytes sold was attributable to the same factors described above for the three-month period while the decline in average selling prices per gigabyte for the period was due to the supply-demand imbalance in the first half of the year, prior to the recent improvement in supply-demand conditions, as described above.

[0000106040-24-000022:mdna:47]
HDD revenue increased 17% for the three months ended March 29, 2024 from the comparable period in the prior year, as a result of a 25% increase in exabytes sold, partially offset by a 6% decline in average selling prices per gigabyte. The increase in exabytes sold reflected an increase in shipments of our high capacity enterprise drives. The decline in average selling prices per gigabyte was due to a shift in the product mix to larger capacity drives. HDD revenue decreased 13% for the nine months ended March 29, 2024 from the comparable period in the prior year, as a result of a 9% decrease in exabytes sold, which was primarily driven by lower shipments to customers in our Cloud end market in the first half of the year as they adjusted their production levels and right-sized their inventories, and a 5% decline in average selling prices per gigabyte primarily attributable to a shift in product mix.

[0000106040-24-000022:mdna:48]
Cloud revenue increased 29% for the three months ended March 29, 2024 from the comparable period in the prior year, reflecting a 35% increase in exabytes sold, partially offset by a 5% decline in average selling prices per gigabyte. The increase in exabytes sold was driven by higher shipments of our high capacity enterprise HDD products. The decline in average selling prices per gigabyte was primarily due to a shift in the product mix to those larger capacity drives. Cloud revenue decreased 18% for the nine months ended March 29, 2024 from the comparable period in the prior year, which reflected a 9% decrease in exabytes sold and a 10% decline in average selling prices per gigabyte attributable to the supply-demand imbalance in the first half of the year as described above.

[0000106040-24-000022:mdna:49]
Client revenue increased 20% for the three months ended March 29, 2024 from the comparable period in the prior year, reflecting a 24% increase in average selling prices per gigabyte, partially offset by a 3% decrease in exabytes sold. The increase in average selling prices per gigabyte over the prior year period was primarily due to improved pricing in Flash. The decrease in exabytes sold reflected a small lag in recovery in this end market and timing of shipments as many OEMs transition to newer Flash products. Client revenue increased 5% for the nine months ended March 29, 2024 from the comparable period in the prior year, reflecting a 17% increase in exabytes sold, partially offset by an 11% decline in average selling prices per gigabyte. The increase in exabytes sold was primarily driven by an increase in SSD shipments into PC applications and the decline in average selling prices per gigabyte was primarily due to the decline in Flash pricing caused by the supply-demand imbalance in the first half of the year as described above.

[0000106040-24-000022:mdna:50]
Consumer revenue increased 17% for the three months ended March 29, 2024 from the comparable period in the prior year, reflecting an increase in average selling prices per gigabyte while exabytes sold remained relatively consistent overall with a decrease in HDD bit shipments largely offsetting an increase in flash bit shipments. The increase in average selling prices per gigabyte was driven by improved pricing in Flash and more favorable product mix. Consumer revenue increased 10% for the nine months ended March 29, 2024 from the comparable period in the prior year, reflecting an 8% increase in exabytes sold and a 2% increase in average selling prices per gigabyte. The increase in exabytes sold was primarily driven by improved demand across our products in Flash, partially offset by a decline in HDD shipments. The increase in average selling prices per gigabyte was primarily due to a shift in product mix, partially offset by the decline in Flash pricing caused by the supply-demand imbalance in the first half of the year as described above.

[0000106040-24-000022:mdna:51]
The allocation of our net revenue by geography for the three months ended March 29, 2024 was relatively consistent with the comparable period in the prior year. The changes in net revenue by geography for nine months ended March 29, 2024 from the comparable period in the prior year reflected higher revenue in the first half of the year from Cloud customers in the Asia region, particularly in China and a decline in the Americas as certain large customers reduced purchases to align their inventories with current market demand.

[0000106040-24-000022:mdna:52]
Our top 10 customers accounted for 42% of our net revenue for the three months ended March 29, 2024, compared to 49% of our net revenue for the three months ended March 31, 2023. Our top 10 customers accounted for 38% of our net revenue for the nine months ended March 29, 2024, compared to 45% of our net revenue for the nine months ended March 31, 2023. For each of the three and nine months ended March 29, 2024 and March 31, 2023, no single customer accounted for 10% or more of our net revenue.

[0000106040-24-000022:mdna:53]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 13% and 17% of gross revenue for the three and nine months ended March 29, 2024, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-24-000022:mdna:54]
[same as prior period, unchanged from 0000106040-24-000014:mdna:51]

[0000106040-24-000022:mdna:55]
[same as prior period, unchanged from 0000106040-24-000014:mdna:52]

[0000106040-24-000022:mdna:56]
Consolidated gross profit increased by $715 million for the three months ended March 29, 2024 from the comparable period in the prior year, which primarily reflected better pricing in Flash as well as lower charges for unabsorbed manufacturing overhead costs in the current period of approximately $16 million, all in HDD, as a result of the reduced utilization of our manufacturing capacity, compared to $275 million of such charges in the same period in the prior year ($213 million in Flash and $62 million in HDD). Consolidated gross margin increased 19 percentage points year over year, with approximately 9 percentage points of the increase due to the lower underutilization charges in the current period and the remainder driven by better pricing in Flash as noted above. Flash gross margin increased by approximately 32 percentage points year over year, with approximately 16 percentage points of the increase due to the lower underutilization charges in the current period as noted above and the remainder driven by the higher average selling prices per gigabyte. HDD gross margin increased by 7 percentage points year over year, with approximately 3 percentage points of the increase due to the lower underutilization charges in the current period as noted above and the remainder driven by better product mix.

[0000106040-24-000022:mdna:57]
Consolidated gross profit decreased by $203 million for the nine months ended March 29, 2024 from the comparable period in the prior year, which was primarily driven by the decline in pricing, particularly in Flash as mentioned above. Consolidated gross margin remained flat for the nine months ended March 29, 2024 from the comparable period in the prior year. Flash gross margin decreased by approximately 4 percentage points year over year, primarily driven by the lower average selling prices per gigabyte. HDD gross margin increased by 2 percentage point year over year, primarily driven by better product mix.

[0000106040-24-000022:mdna:58]
[same as prior period, unchanged from 0000106040-24-000014:mdna:55]

[0000106040-24-000022:mdna:59]
Research and development (“R&D”) expense increased $18 million for the three months ended March 29, 2024 from the comparable period in the prior year. The increase was primarily driven by a $26 million increase in compensation and benefits due to higher variable compensation, partially offset by lower headcount, and a $9 million decrease due to reductions in R&D project spending. R&D expense decreased $182 million for the nine months ended March 29, 2024 from the comparable period in the prior year. The decline was primarily driven by an $88 million decrease in compensation and benefits due to lower headcount, partially offset by higher variable compensation, a $94 million decrease due to lower depreciation expenses and reductions in R&D project spending as well as other savings as we took actions to reduce expenses in the current environment.

[0000106040-24-000022:mdna:60]
Selling, general and administrative (“SG&A”) expense decreased $39 million for the three months ended March 29, 2024 from the comparable period in the prior year. The decline was primarily driven by a $39 million decrease in intangible amortization expense, as certain assets became fully amortized, and a $15 million decrease in strategic review costs, partially offset by an $18 million increase in compensation and benefits due to higher variable compensation. SG&A expense decreased $131 million for the nine months ended March 29, 2024 from the comparable period in the prior year. The decline was primarily driven by a $116 million decrease in intangible amortization expense, a $19 million decrease in compensation and benefits due to lower headcount, and a $13 million decrease in sales and marketing expenses, partially offset by a $22 million increase in strategic review costs and a $12 million increase in material purchases.

[0000106040-24-000022:mdna:61]
Employee termination, asset impairment and other charges decreased $32 million for the three months ended March 29, 2024 from the comparable period in the prior year, reflecting fewer restructuring actions taken in the current period. Employee termination, asset impairment and other charges decreased $51 million for the nine months ended March 29, 2024 from the comparable period in the prior year. The decrease primarily reflected fewer restructuring actions taken and a gain on the sale-leaseback of our Milpitas, California facility, partially offset by higher contract termination charges and asset impairments caused by project cancellations. For information regarding Employee termination, asset impairment and other, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment, and Other of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000022:mdna:62]
Business separation costs were $23 million for the three months ended March 29, 2024, primarily reflecting outside service fees to support the planned separation of our Flash and HDD businesses. Business separation costs were $59 million for the nine months ended March 29, 2024 primarily reflecting the charges similar to those noted for the three months ended March 29, 2024, as well as $33 million of charges incurred earlier in the year for stamp duties associated with establishing new legal entities to support the planned separation of our Flash and HDD businesses.

[0000106040-24-000022:mdna:63]
[same as prior period, unchanged from 0000106040-24-000014:mdna:61]

[0000106040-24-000022:mdna:64]
Total interest and other expense, net increased $39 million for the three months ended March 29, 2024 from the comparable period in the prior year, primarily reflecting $28 million of higher interest expense resulting from increases in interest rates and a higher outstanding debt balance. Total interest and other expense, net increased $49 million for the nine months ended March 29, 2024 from the comparable period in the prior year, primarily reflecting $91 million of higher interest expense resulting from increases in interest rates and the higher outstanding debt balance, partially offset by higher other income, net, of $27 million, driven primarily by a net gain on our strategic investments, and $15 million of higher interest income due to higher interest rates.

[0000106040-24-000022:mdna:65]
[same as prior period, unchanged from 0000106040-24-000014:mdna:63]

[0000106040-24-000022:mdna:66]
[same as prior period, unchanged from 0000106040-24-000014:mdna:64]

[0000106040-24-000022:mdna:67]
[same as prior period, unchanged from 0000106040-24-000014:mdna:65]

[0000106040-24-000022:mdna:68]
[same as prior period, unchanged from 0000106040-24-000014:mdna:66]

[0000106040-24-000022:mdna:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | $ in millions |
| Income (loss) before taxes | $ | 178 |  | $ | (528) |  | $ | (763) |  | $ | (816) |
| Income tax expense | 43 |  | 43 |  | 74 |  | 159 |
| Effective tax rate | 24% |  | (8)% |  | (10)% |  | (19)% |

[0000106040-24-000022:mdna:70]
Beginning in 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and nine months ended March 29, 2024, and March 31, 2023, but did not have a material impact on our effective tax rate. The primary drivers of the difference between the effective tax rate for the three and nine months ended March 29, 2024 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during fiscal years 2024 through 2031. On November 1, 2023, one of our tax holidays in Malaysia expired. We have applied for an extension and anticipate it will apply retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, we are applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, we will make an adjustment to our effective tax rate in that period. The effective tax rate for the three and nine months ended March 29, 2024 includes the discrete effect of a net increase of $35 million and $48 million, respectively, to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, related to transfer pricing matters, withholding taxes and certain tax deductions. This is offset in part by a net decrease of $7 million and $34 million, respectively, to the liability for unrecognized tax benefits for the three and nine months ended March 29, 2024, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000022:mdna:71]
The primary drivers of the difference between the effective tax rate for the three and nine months ended March 31, 2023 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-24-000022:mdna:72]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for the three and nine months ended March 29, 2024, but did not have a material impact on the effective tax rate in those periods due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-24-000022:mdna:73]
[same as prior period, unchanged from 0000106040-24-000014:mdna:72]

[0000106040-24-000022:mdna:74]
52

[0000106040-24-000022:mdna:75]
[same as prior period, unchanged from 0000106040-24-000014:mdna:73]

[0000106040-24-000022:mdna:76]
[same as prior period, unchanged from 0000106040-24-000014:mdna:74]

[0000106040-24-000022:mdna:77]
|  | Nine Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (660) |  |  | $ | (340) |  |  |  |
| Investing activities | 31 |  |  | (620) |  |  |  |
| Financing activities | 506 |  |  | 856 |  |  |  |
| Effect of exchange rate changes on cash | (6) |  |  | (3) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (129) |  |  | $ | (107) |  |  |  |

[0000106040-24-000022:mdna:78]
We had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the nine months ended March 29, 2024, the Company made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $182 million as of March 29, 2024, related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000022:mdna:79]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $164 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules. See Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-24-000022:mdna:80]
[same as prior period, unchanged from 0000106040-24-000014:mdna:78]

[0000106040-24-000022:mdna:81]
[same as prior period, unchanged from 0000106040-24-000014:mdna:79]

[0000106040-24-000022:mdna:82]
We believe our Cash and cash equivalents and our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended June 30, 2023.

[0000106040-24-000022:mdna:83]
A total of $1.51 billion and $1.28 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of March 29, 2024 and June 30, 2023, respectively. There are no material tax consequences that have not been accrued for on the repatriation of this cash.

[0000106040-24-000022:mdna:84]
[same as prior period, unchanged from 0000106040-24-000014:mdna:82]

[0000106040-24-000022:mdna:85]
53

[0000106040-24-000022:mdna:86]
[same as prior period, unchanged from 0000106040-24-000014:mdna:83]

[0000106040-24-000022:mdna:87]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $405 million for the nine months ended March 29, 2024, as compared to $296 million for the nine months ended March 31, 2023, which largely reflects payments made on the IRS matter, partially offset by a decrease in net operating assets and liabilities resulting from the reduction in volume of our business, as discussed above. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as the timing of payments for taxes. During the nine months ended March 29, 2024, the change in operating assets and liabilities included payments to the IRS of $523 million, including interest, as discussed in “Short- and Long-term Liquidity – Unrecognized Tax Benefits” section below. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-24-000022:mdna:88]
|  | Three Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  |  |  |  |
| Days sales outstanding | 47 |  |  | 52 |  |  |  |  |  |
| Days in inventory | 119 |  |  | 144 |  |  |  |  |  |
| Days payable outstanding | (63) |  |  | (57) |  |  |  |  |  |
| Cash conversion cycle | 103 |  |  | 139 |  |  |  |  |  |

[0000106040-24-000022:mdna:89]
[same as prior period, unchanged from 0000106040-24-000014:mdna:86]

[0000106040-24-000022:mdna:90]
For the three months ended March 29, 2024, DSO decreased by 5 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO decreased by 25 days from the comparable period in the prior year, primarily reflecting lower inventory cycle time, which reduces the inventory levels needed to meet customer orders, and an increase in products shipped. DPO increased by 6 days from the comparable period in the prior year primarily due to routine variations in the timing of purchases and payments during the period as well as slightly more favorable payment terms.

[0000106040-24-000022:mdna:91]
[same as prior period, unchanged from 0000106040-24-000014:mdna:88]

[0000106040-24-000022:mdna:92]
Net cash provided by investing activities for the nine months ended March 29, 2024 primarily consisted of $207 million in net proceeds from activity related to Flash Ventures, partially offset by $176 million in capital expenditures, net of proceeds from disposals of assets, which includes the proceeds from the sale-leaseback of our Milpitas, California facility. Net cash used in investing activities for the nine months ended March 31, 2023 primarily consisted of $688 million in capital expenditures, partially offset by $46 million in net proceeds from activity related to Flash Ventures.

[0000106040-24-000022:mdna:93]
[same as prior period, unchanged from 0000106040-24-000014:mdna:90]

[0000106040-24-000022:mdna:94]
During the nine months ended March 29, 2024, net cash provided by financing activities primarily consisted of $2.50 billion in proceeds from the issuance of the 2028 Convertible Notes, the drawdown of the Delayed Draw Term Loan and draws on the revolving credit facility. These sources were partially offset by $505 million used to repurchase a portion of the 2024 Convertible Notes; $1.27 billion used for the repayment of draws on the revolving credit facility, payments on the Delayed Draw Term Loan, scheduled payments on the Term Loan A-2, and settlement of the remaining 2024 Convertible Notes; and $155 million for the purchase of capped calls to hedge the potential dilution impact of the conversion feature of the 2028 Convertible Notes. During the nine months ended March 31, 2023, cash flows from financing activities primarily consisted of proceeds of $882 million from the issuance of our convertible preferred stock. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the prior year period.

[0000106040-24-000022:mdna:95]
[same as prior period, unchanged from 0000106040-24-000014:mdna:92]

[0000106040-24-000022:mdna:96]
[same as prior period, unchanged from 0000106040-24-000014:mdna:93]

[0000106040-24-000022:mdna:97]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity – Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000022:mdna:98]
55

[0000106040-24-000022:mdna:99]
[same as prior period, unchanged from 0000106040-24-000014:mdna:95]

[0000106040-24-000022:mdna:100]
[same as prior period, unchanged from 0000106040-24-000014:mdna:96]

[0000106040-24-000022:mdna:101]
In addition to cash requirements for unrecognized tax benefits and dividend rights with respect to the Series A Preferred Stock discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of March 29, 2024:

[0000106040-24-000022:mdna:102]
|  | Total |  | 1 Year (Remaining Three Months of 2024) |  | 2-3 Years (2025-2026) |  | 4-5 Years (2027-2028) |  | More than 5 Years (Beyond 2028) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,825 |  |  | $ | 338 |  |  | $ | 2,600 |  |  | $ | 3,887 |  |  | $ | 1,000 |  |
| Interest on debt | 1,151 |  |  | 79 |  |  | 734 |  |  | 238 |  |  | 100 |  |
| Flash Ventures related commitments(2) | 2,463 |  |  | 322 |  |  | 1,576 |  |  | 572 |  |  | (7) |  |
| Operating leases | 593 |  |  | 17 |  |  | 135 |  |  | 112 |  |  | 329 |  |
| Purchase obligations and other commitments | 522 |  |  | 45 |  |  | 268 |  |  | 79 |  |  | 130 |  |
| Mandatory deemed repatriation tax | 466 |  |  | — |  |  | 466 |  |  | — |  |  | — |  |
| Total | $ | 13,020 |  |  | $ | 801 |  |  | $ | 5,779 |  |  | $ | 4,888 |  |  | $ | 1,552 |  |

[0000106040-24-000022:mdna:103]
(1)Principal portion of debt, excluding issuance costs.

[0000106040-24-000022:mdna:104]
[same as prior period, unchanged from 0000106040-24-000014:mdna:100]

[0000106040-24-000022:mdna:105]
[same as prior period, unchanged from 0000106040-24-000014:mdna:101]

[0000106040-24-000022:mdna:106]
[same as prior period, unchanged from 0000106040-24-000014:mdna:102]

[0000106040-24-000022:mdna:107]
[same as prior period, unchanged from 0000106040-24-000014:mdna:103]

[0000106040-24-000022:mdna:108]
As described in “Key Developments – Financing Activities” above, we undertook several liability-management actions during the second and third quarters of 2024, including the issuance of the 2028 Convertible Notes, the repurchase and/or settlement of our remaining outstanding 2024 Convertible Notes and the partial repayment of the Delayed Term Loan.

[0000106040-24-000022:mdna:109]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000022:mdna:110]
In addition to our existing debt, as of March 29, 2024, we had $2.24 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 30, 2023 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-24-000022:mdna:111]
The loan agreements governing our revolving credit facility, our Term Loan A-2 maturing 2027, and our Delayed Draw Term Loan require us to comply with certain financial covenants, consisting of a leverage ratio, and a minimum liquidity requirement. As of March 29, 2024, we were in compliance with these financial covenants.

[0000106040-24-000022:mdna:112]
[same as prior period, unchanged from 0000106040-24-000014:mdna:108]

[0000106040-24-000022:mdna:113]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of March 29, 2024, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-24-000022:mdna:114]
[same as prior period, unchanged from 0000106040-24-000014:mdna:110]

[0000106040-24-000022:mdna:115]
[same as prior period, unchanged from 0000106040-24-000014:mdna:111]

[0000106040-24-000022:mdna:116]
[same as prior period, unchanged from 0000106040-24-000014:mdna:112]

[0000106040-24-000022:mdna:117]
[same as prior period, unchanged from 0000106040-24-000014:mdna:113]

[0000106040-24-000022:mdna:118]
|  |  | March 29,2024 |
|  |  | (in millions) |
| 2025 |  | $ | 265 |  |
| 2026 |  | 201 |  |
| Total |  | $ | 466 |  |

[0000106040-24-000022:mdna:119]
[same as prior period, unchanged from 0000106040-24-000014:mdna:115]

[0000106040-24-000022:mdna:120]
As of March 29, 2024, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $708 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of March 29, 2024 was $173 million. Of these amounts, approximately $719 million could result in potential cash payments.

[0000106040-24-000022:mdna:121]
As noted above, we had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the nine months ended March 29, 2024, we made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $182 million as of March 29, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000022:mdna:122]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $164 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-24-000022:mdna:123]
[same as prior period, unchanged from 0000106040-24-000014:mdna:119]

[0000106040-24-000022:mdna:124]
[same as prior period, unchanged from 0000106040-24-000014:mdna:120]

[0000106040-24-000022:mdna:125]
[same as prior period, unchanged from 0000106040-24-000014:mdna:121]

[0000106040-24-000022:mdna:126]
[same as prior period, unchanged from 0000106040-24-000014:mdna:122]

[0000106040-24-000022:mdna:127]
[same as prior period, unchanged from 0000106040-24-000014:mdna:123]

[0000106040-24-000022:mdna:128]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-24-000022:mdna:129]
[same as prior period, unchanged from 0000106040-24-000014:mdna:125]

[0000106040-24-000022:mdna:130]
[same as prior period, unchanged from 0000106040-24-000014:mdna:126]

[0000106040-24-000022:mdna:131]
[same as prior period, unchanged from 0000106040-24-000014:mdna:127]

[0000106040-24-000022:mdna:132]
[same as prior period, unchanged from 0000106040-24-000014:mdna:128]

[0000106040-24-000022:mdna:133]
[same as prior period, unchanged from 0000106040-24-000014:mdna:129]

[0000106040-24-000022:mdna:134]
[same as prior period, unchanged from 0000106040-24-000014:mdna:130]
