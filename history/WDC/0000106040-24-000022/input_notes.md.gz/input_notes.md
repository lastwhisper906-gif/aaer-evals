# WDC notes — 0000106040-24-000022


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-24-000022:notes:1]
[same as prior period, unchanged from 0000106040-24-000014:notes:1]

[0000106040-24-000022:notes:2]
[same as prior period, unchanged from 0000106040-24-000014:notes:2]

[0000106040-24-000022:notes:3]
[same as prior period, unchanged from 0000106040-24-000014:notes:3]

[0000106040-24-000022:notes:4]
[same as prior period, unchanged from 0000106040-24-000014:notes:4]

[0000106040-24-000022:notes:5]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended on June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-24-000022:notes:6]
[same as prior period, unchanged from 0000106040-24-000014:notes:6]

[0000106040-24-000022:notes:7]
[same as prior period, unchanged from 0000106040-24-000014:notes:7]

[0000106040-24-000022:notes:8]
[same as prior period, unchanged from 0000106040-24-000014:notes:8]

[0000106040-24-000022:notes:9]
[same as prior period, unchanged from 0000106040-24-000014:notes:9]

[0000106040-24-000022:notes:10]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its Flash and HDD business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

[0000106040-24-000022:notes:11]
[same as prior period, unchanged from 0000106040-24-000014:notes:11]

[0000106040-24-000022:notes:12]
[same as prior period, unchanged from 0000106040-24-000014:notes:12]

[0000106040-24-000022:notes:13]
[same as prior period, unchanged from 0000106040-24-000014:notes:13]

[0000106040-24-000022:notes:14]
As previously disclosed in the Company’s Quarterly Report on Form 10-Q for the period ended December 28, 2023, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, “Flash Ventures”). The errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.

[0000106040-24-000022:notes:15]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the period detected would have been material to the Company's results of operations for that period. Accordingly, the Company has revised previously reported financial information presented herein for such immaterial errors. A summary of revisions to the Condensed Consolidated Financial Statements presented herein is included for comparative purposes in Note 17, Revision of Previously Issued Financial Statements.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-24-000022:notes:16]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-24-000022:notes:17]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU requires the Company to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 and to provide certain rollforward information related to those obligations beginning in the Company’s first fiscal quarter of 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. The Company adopted the guidance on the first day of fiscal year 2024, except for the rollforward information, which the Company is compiling and intends to provide beginning in fiscal year 2025. See Note 15, Supplier Finance Program, of the Notes to Condensed Consolidated Financial Statements for information regarding the supplier finance program.

[0000106040-24-000022:notes:18]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-24-000022:notes:19]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures”, which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. The ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity's CODM, a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.

[0000106040-24-000022:notes:20]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures”. The ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The amendments are effective for the Company’s fiscal year 2026, with early adoption permitted. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-24-000022:notes:21]
[same as prior period, unchanged from 0000106040-24-000014:notes:21]

[0000106040-24-000022:notes:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | $ in millions |
| Revenue, net: |  |  |  |  |  |  |  |
| Flash | $ | 1,705 |  |  | $ | 1,307 |  |  | $ | 4,926 |  |  | $ | 4,686 |  |
| HDD | 1,752 |  |  | 1,496 |  |  | 4,313 |  |  | 4,960 |  |
| Total net revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 467 |  |  | $ | (65) |  |  | $ | 437 |  |  | $ | 597 |  |
| HDD | 545 |  |  | 363 |  |  | 1,157 |  |  | 1,237 |  |
| Total gross profit for segments | 1,012 |  |  | 298 |  |  | 1,594 |  |  | 1,834 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (11) |  |  | (12) |  |  | (37) |  |  | (38) |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (2) |  |  | (1) |  |
| Recovery from contamination incident | 1 |  |  | — |  |  | 37 |  |  | — |  |
| Total unallocated corporate items | (11) |  |  | (12) |  |  | (2) |  |  | (39) |  |
| Consolidated gross profit | $ | 1,001 |  |  | $ | 286 |  |  | $ | 1,592 |  |  | $ | 1,795 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 27.4 | % |  | (5.0) | % |  | 8.9 | % |  | 12.7 | % |
| HDD | 31.1 | % |  | 24.3 | % |  | 26.8 | % |  | 24.9 | % |
| Consolidated gross margin | 29.0 | % |  | 10.2 | % |  | 17.2 | % |  | 18.6 | % |

[0000106040-24-000022:notes:23]
[same as prior period, unchanged from 0000106040-24-000014:notes:23]

[0000106040-24-000022:notes:24]
[same as prior period, unchanged from 0000106040-24-000014:notes:24]

[0000106040-24-000022:notes:25]
[same as prior period, unchanged from 0000106040-24-000014:notes:25]

[0000106040-24-000022:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 1,553 |  |  | $ | 1,205 |  |  | $ | 3,496 |  |  | $ | 4,258 |  |
| Client | 1,174 |  |  | 975 |  |  | 3,443 |  |  | 3,293 |  |
| Consumer | 730 |  |  | 623 |  |  | 2,300 |  |  | 2,095 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,740 |  |  | $ | 1,353 |  |  | $ | 4,990 |  |  | $ | 4,533 |  |
| Americas | 1,154 |  |  | 935 |  |  | 2,620 |  |  | 3,448 |  |
| Europe, Middle East and Africa | 563 |  |  | 515 |  |  | 1,629 |  |  | 1,665 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |

[0000106040-24-000022:notes:27]
The Company’s top 10 customers accounted for 42% and 38% of its net revenue for each of the three and nine months ended March 29, 2024 and 49% and 45% of its net revenue for the three and nine months ended March 31, 2023, respectively. For the three and nine months ended March 29, 2024 and March 31, 2023, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-24-000022:notes:28]
[same as prior period, unchanged from 0000106040-24-000014:notes:28]

[0000106040-24-000022:notes:29]
[same as prior period, unchanged from 0000106040-24-000014:notes:29]

[0000106040-24-000022:notes:30]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at June 30, 2023 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |
| Foreign currency translation adjustment | (2) |  |  | (1) |  |  | (3) |  |
| Balance at March 29, 2024 | $ | 5,714 |  |  | $ | 4,320 |  |  | $ | 10,034 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-24-000022:notes:31]
[same as prior period, unchanged from 0000106040-24-000014:notes:31]

[0000106040-24-000022:notes:32]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. During the nine months ended March 29, 2024 and March 31, 2023, the Company sold trade accounts receivable aggregating $623 million and $626 million, respectively. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of March 29, 2024 and June 30, 2023, the amount of factored receivables that remained outstanding was $102 million and $150 million, respectively.

[0000106040-24-000022:notes:33]
[same as prior period, unchanged from 0000106040-24-000014:notes:33]

[0000106040-24-000022:notes:34]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,666 |  |  | $ | 2,096 |  |
| Work-in-process | 1,045 |  |  | 979 |  |
| Finished goods | 504 |  |  | 623 |  |
| Total inventories | $ | 3,215 |  |  | $ | 3,698 |  |

[0000106040-24-000022:notes:35]
[same as prior period, unchanged from 0000106040-24-000014:notes:35]

[0000106040-24-000022:notes:36]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 235 |  |  | $ | 269 |  |
| Buildings and improvements | 1,826 |  |  | 1,955 |  |
| Machinery and equipment | 8,655 |  |  | 8,704 |  |
| Computer equipment and software | 473 |  |  | 470 |  |
| Furniture and fixtures | 54 |  |  | 54 |  |
| Construction-in-process | 793 |  |  | 798 |  |
| Property, plant and equipment, gross | 12,036 |  |  | 12,250 |  |
| Accumulated depreciation | (8,783) |  |  | (8,630) |  |
| Property, plant and equipment, net | $ | 3,253 |  |  | $ | 3,620 |  |

[0000106040-24-000022:notes:37]
Other intangible assets, net

[0000106040-24-000022:notes:38]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During the three months ended December 29, 2023, one IPR&D project reached technological feasibility and $8 million was reclassified from IPR&D to existing technology and commenced amortization over an estimated useful life of three years. As of March 29, 2024 and June 30, 2023, IPR&D included in intangible assets, net was $72 million and $80 million, respectively.

[0000106040-24-000022:notes:39]
[same as prior period, unchanged from 0000106040-24-000014:notes:39]

[0000106040-24-000022:notes:40]
[same as prior period, unchanged from 0000106040-24-000014:notes:40]

[0000106040-24-000022:notes:41]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 202 |  |  | $ | 289 |  |  | $ | 244 |  |  | $ | 345 |  |  |  |
| Charges to operations | 28 |  |  | 26 |  |  | 76 |  |  | 83 |  |  |  |
| Utilization | (29) |  |  | (43) |  |  | (112) |  |  | (137) |  |  |  |
| Changes in estimate related to pre-existing warranties | 2 |  |  | — |  |  | (5) |  |  | (19) |  |  |  |
| Warranty accrual, end of period | $ | 203 |  |  | $ | 272 |  |  | $ | 203 |  |  | $ | 272 |  |  |  |

[0000106040-24-000022:notes:42]
[same as prior period, unchanged from 0000106040-24-000014:notes:42]

[0000106040-24-000022:notes:43]
|  | March 29,2024 |  | June 30,2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 47 |  |  | $ | 97 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 156 |  |  | 147 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 203 |  |  | $ | 244 |  |  |  |  |  |  |  |

[0000106040-24-000022:notes:44]
[same as prior period, unchanged from 0000106040-24-000014:notes:44]

[0000106040-24-000022:notes:45]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 201 |  |  | $ | 464 |  |
| Non-current portion of unrecognized tax benefits | 552 |  |  | 408 |  |
| Other non-current liabilities | 680 |  |  | 543 |  |
| Total other liabilities | $ | 1,433 |  |  | $ | 1,415 |  |

[0000106040-24-000022:notes:46]
[same as prior period, unchanged from 0000106040-24-000014:notes:46]

[0000106040-24-000022:notes:47]
[same as prior period, unchanged from 0000106040-24-000014:notes:47]

[0000106040-24-000022:notes:48]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 30, 2023 | $ | (2) |  |  | $ | (389) |  |  |  |  |  |  | $ | (157) |  |  | $ | (548) |  |
| Other comprehensive loss before reclassifications | — |  |  | (55) |  |  |  |  |  |  | (196) |  |  | (251) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 151 |  |  | 151 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | 1 |  |  |  |  |  |  | 11 |  |  | 12 |  |
| Net current-period other comprehensive loss | — |  |  | (54) |  |  |  |  |  |  | (34) |  |  | (88) |  |
| Balance at March 29, 2024 | $ | (2) |  |  | $ | (443) |  |  |  |  |  |  | $ | (191) |  |  | $ | (636) |  |

[0000106040-24-000022:notes:49]
During the three and nine months ended March 29, 2024, the amounts reclassified out of AOCL were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. 
As of March 29, 2024, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months. In addition, as of March 29, 2024, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-24-000022:notes:50]
[same as prior period, unchanged from 0000106040-24-000014:notes:50]

[0000106040-24-000022:notes:51]
[same as prior period, unchanged from 0000106040-24-000014:notes:51]

[0000106040-24-000022:notes:52]
[same as prior period, unchanged from 0000106040-24-000014:notes:52]

[0000106040-24-000022:notes:53]
[same as prior period, unchanged from 0000106040-24-000014:notes:53]

[0000106040-24-000022:notes:54]
[same as prior period, unchanged from 0000106040-24-000014:notes:54]

[0000106040-24-000022:notes:55]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 29, 2024 and June 30, 2023, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-24-000022:notes:56]
|  | March 29, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 333 |  |  | $ | — |  |  | $ | — |  |  | $ | 333 |  |
| Short-term investments - Certificates of deposit | 27 |  |  | — |  |  | — |  |  | 27 |  |
| Foreign exchange contracts | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total assets at fair value | $ | 360 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 369 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 142 |  |  | $ | — |  |  | $ | 142 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 142 |  |  | $ | — |  |  | $ | 142 |  |

[0000106040-24-000022:notes:57]
[same as prior period, unchanged from 0000106040-24-000014:notes:57]

[0000106040-24-000022:notes:58]
[same as prior period, unchanged from 0000106040-24-000014:notes:58]

[0000106040-24-000022:notes:59]
[same as prior period, unchanged from 0000106040-24-000014:notes:59]

[0000106040-24-000022:notes:60]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2024 and the fourth quarter of 2023, respectively.

[0000106040-24-000022:notes:61]
|  | March 29, 2024 |  | June 30, 2023 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | 1,067 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | 300 |  |  | — |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,295 |  |  | 2,253 |  |  | 2,293 |  |  | 2,193 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,615 |  |  | 2,556 |  |  | 2,687 |  |  | 2,661 |  |
| 3.00% convertible notes due 2028 | 1,566 |  |  | 2,351 |  |  | — |  |  | — |  |
| 2.85% senior notes due 2029 | 496 |  |  | 436 |  |  | 496 |  |  | 400 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 403 |  |  | 495 |  |  | 371 |  |
| Total | $ | 7,768 |  |  | $ | 8,299 |  |  | $ | 7,070 |  |  | $ | 6,692 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-24-000022:notes:62]
Derivative Instruments and Hedging Activities
As of March 29, 2024, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of March 29, 2024, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-24-000022:notes:63]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three and nine months ended March 29, 2024 and March 31, 2023, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-24-000022:notes:64]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 4, Supplemental Financial Statement Data – Accumulated other comprehensive loss.

[0000106040-24-000022:notes:65]
[same as prior period, unchanged from 0000106040-24-000014:notes:65]

[0000106040-24-000022:notes:66]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 29, 2024 and June 30, 2023, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-24-000022:notes:67]
Debt
Debt consisted of the following:

[0000106040-24-000022:notes:68]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,625 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,825 |  |  | 7,100 |  |
| Issuance costs | (57) |  |  | (30) |  |
| Subtotal | 7,768 |  |  | 7,070 |  |
| Less current portion of long-term debt | (450) |  |  | (1,213) |  |
| Long-term debt | $ | 7,318 |  |  | $ | 5,857 |  |

[0000106040-24-000022:notes:69]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the nine months ended March 29, 2024.

[0000106040-24-000022:notes:70]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of March 29, 2024 was 7.550%.

[0000106040-24-000022:notes:71]
During the three and nine months ended March 29, 2024, the Company made scheduled repayments of the Term Loan A-2 of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of March 29, 2024 was 6.930%.

[0000106040-24-000022:notes:72]
During the three and nine months ended March 29, 2024, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

[0000106040-24-000022:notes:73]
On March 25, 2024, the Company issued a standby letter of credit of $15 million, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.24 billion as of March 29, 2024.

[0000106040-24-000022:notes:74]
The loan agreements governing the Company’s 2027 Revolving Credit Facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, and a minimum liquidity requirement. As of March 29, 2024, the Company was in compliance with these financial covenants.

[0000106040-24-000022:notes:75]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 4.75% senior unsecured notes due 2026 (currently, Western Digital Technologies, Inc.).

[0000106040-24-000022:notes:76]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000022:notes:77]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes.

[0000106040-24-000022:notes:78]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.

[0000106040-24-000022:notes:79]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to Additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of March 29, 2024.

[0000106040-24-000022:notes:80]
On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-24-000022:notes:81]
[same as prior period, unchanged from 0000106040-24-000014:notes:79]

[0000106040-24-000022:notes:82]
[same as prior period, unchanged from 0000106040-24-000014:notes:80]

[0000106040-24-000022:notes:83]
[same as prior period, unchanged from 0000106040-24-000014:notes:81]

[0000106040-24-000022:notes:84]
|  | March 29,2024 |  | June 30,2023 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 258 |  |  | $ | 273 |  |  |  |
| Fair value of plan assets at end of period | 176 |  |  | 185 |  |  |  |
| Unfunded status | $ | 82 |  |  | $ | 88 |  |  |  |

[0000106040-24-000022:notes:85]
[same as prior period, unchanged from 0000106040-24-000014:notes:83]

[0000106040-24-000022:notes:86]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 81 |  |  | 87 |  |
| Net amount recognized | $ | 82 |  |  | $ | 88 |  |

[0000106040-24-000022:notes:87]
Net periodic benefit costs were not material for the three and nine months ended March 29, 2024.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-24-000022:notes:88]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-24-000022:notes:89]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-24-000022:notes:90]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-24-000022:notes:91]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | — |  |  | 48 |  |
| Notes receivable, Flash Forward | 556 |  |  | 709 |  |
| Investment in Flash Partners | 157 |  |  | 161 |  |
| Investment in Flash Alliance | 234 |  |  | 276 |  |
| Investment in Flash Forward | 152 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,099 |  |  | $ | 1,410 |  |

[0000106040-24-000022:notes:92]
During the three and nine months ended March 29, 2024 and March 31, 2023, the Company made net payments to Flash Ventures of $0.7 billion and $2.5 billion, and $1.2 billion and $3.2 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-24-000022:notes:93]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-24-000022:notes:94]
As of March 29, 2024 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $310 million and $292 million, respectively.

[0000106040-24-000022:notes:95]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-24-000022:notes:96]
|  | March 29,2024 |
|  | (in millions) |
| Notes receivable | $ | 556 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,431 |  |
| Inventory and prepayments | 1,046 |  |
| Maximum estimable loss exposure | $ | 3,576 |  |

[0000106040-24-000022:notes:97]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-24-000022:notes:98]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, during the second half of 2023 and the first two quarters of 2024, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level during that period to more closely align the Company’s flash-based wafer supply with projected demand. During the nine months ended March 29, 2024, the Company incurred costs of $249 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended March 29, 2024 nor the three and nine months ended March 31, 2023.

[0000106040-24-000022:notes:99]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, as well as charges for under absorption of overhead costs. During the three months ended December 29, 2023, the Company received a recovery of $36 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its remaining losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-24-000022:notes:100]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of March 29, 2024, such prepayments aggregated $496 million and will be credited against future wafer charges.

[0000106040-24-000022:notes:101]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-24-000022:notes:102]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-24-000022:notes:103]
Off-Balance Sheet Liabilities

[0000106040-24-000022:notes:104]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-24-000022:notes:105]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024.

[0000106040-24-000022:notes:106]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 216 |  |  | $ | 1,431 |  |

[0000106040-24-000022:notes:107]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024:

[0000106040-24-000022:notes:108]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2024 |  | $ | 110 |  |  | $ | 27 |  |  | $ | 137 |  |
| 2025 |  | 290 |  |  | 79 |  |  | 369 |  |
| 2026 |  | 359 |  |  | 119 |  |  | 478 |  |
| 2027 |  | 154 |  |  | 101 |  |  | 255 |  |
| 2028 |  | 50 |  |  | 97 |  |  | 147 |  |
| 2029 |  | 6 |  |  | 39 |  |  | 45 |  |
| Total guarantee obligations |  | $ | 969 |  |  | $ | 462 |  |  | $ | 1,431 |  |

[0000106040-24-000022:notes:109]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2024, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-24-000022:notes:110]
Unis Venture

[0000106040-24-000022:notes:111]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 29, 2024, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 10% and 8% of Accounts receivable, net as of both March 29, 2024 and June 30, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-24-000022:notes:112]
[same as prior period, unchanged from 0000106040-24-000014:notes:110]

[0000106040-24-000022:notes:113]
[same as prior period, unchanged from 0000106040-24-000014:notes:111]

[0000106040-24-000022:notes:114]
The following table summarizes supplemental balance sheet information related to operating leases as of March 29, 2024:

[0000106040-24-000022:notes:115]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining three months of 2024 | $ | 17 |  |  |  |  |  |  |  |  |  |
| 2025 | 67 |  |  |  |  |  |  |  |  |  |
| 2026 | 68 |  |  |  |  |  |  |  |  |  |
| 2027 | 60 |  |  |  |  |  |  |  |  |  |
| 2028 | 52 |  |  |  |  |  |  |  |  |  |
| Thereafter | 329 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 593 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 164 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 429 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 47 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 382 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 408 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 10.0 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 6.0 | % |  |  |  |  |  |  |  |  |

[0000106040-24-000022:notes:116]
[same as prior period, unchanged from 0000106040-24-000014:notes:114]

[0000106040-24-000022:notes:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions) |
| Cost of operating leases | $ | 15 |  |  | $ | 15 |  |  | $ | 47 |  |  | $ | 43 |  |
| Cash paid for operating leases | 17 |  |  | 12 |  |  | 49 |  |  | 38 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 1 |  |  | 10 |  |  | 178 |  |  | 14 |  |

[0000106040-24-000022:notes:118]
[same as prior period, unchanged from 0000106040-24-000014:notes:116]

[0000106040-24-000022:notes:119]
[same as prior period, unchanged from 0000106040-24-000014:notes:117]

[0000106040-24-000022:notes:120]
[same as prior period, unchanged from 0000106040-24-000014:notes:118]

[0000106040-24-000022:notes:121]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of March 29, 2024, the Company had the following minimum long-term commitments:

[0000106040-24-000022:notes:122]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining three months of 2024 |  | $ | 45 |  |
| 2025 |  | 172 |  |
| 2026 |  | 96 |  |
| 2027 |  | 59 |  |
| 2028 |  | 20 |  |
| Thereafter |  | 130 |  |
| Total |  | $ | 522 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-24-000022:notes:123]
[same as prior period, unchanged from 0000106040-24-000014:notes:121]

[0000106040-24-000022:notes:124]
[same as prior period, unchanged from 0000106040-24-000014:notes:122]

[0000106040-24-000022:notes:125]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |  |
|  | (in millions) |
| RSUs and PSUs | $ | 65 |  |  | $ | 63 |  |  | $ | 198 |  |  | $ | 217 |  |  |
| ESPP | 12 |  |  | 11 |  |  | 28 |  |  | 29 |  |  |
| Total | $ | 77 |  |  | $ | 74 |  |  | $ | 226 |  |  | $ | 246 |  |  |

[0000106040-24-000022:notes:126]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |  |
|  | (in millions) |
| Cost of revenue | $ | 11 |  |  | $ | 12 |  |  | $ | 37 |  |  | $ | 38 |  |  |
| Research and development | 36 |  |  | 37 |  |  | 102 |  |  | 116 |  |  |
| Selling, general and administrative | 30 |  |  | 25 |  |  | 87 |  |  | 92 |  |  |
| Subtotal | 77 |  |  | 74 |  |  | 226 |  |  | 246 |  |  |
| Tax benefit | (10) |  |  | (11) |  |  | (30) |  |  | (35) |  |  |
| Total | $ | 67 |  |  | $ | 63 |  |  | $ | 196 |  |  | $ | 211 |  |  |

[0000106040-24-000022:notes:127]
[same as prior period, unchanged from 0000106040-24-000014:notes:125]

[0000106040-24-000022:notes:128]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of March 29, 2024:

[0000106040-24-000022:notes:129]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 454 |  |  | 2.4 |
| ESPP | 33 |  |  | 0.7 |
| Total unamortized compensation cost | $ | 487 |  |  |  |

[0000106040-24-000022:notes:130]
[same as prior period, unchanged from 0000106040-24-000014:notes:128]

[0000106040-24-000022:notes:131]
[same as prior period, unchanged from 0000106040-24-000014:notes:129]

[0000106040-24-000022:notes:132]
[same as prior period, unchanged from 0000106040-24-000014:notes:130]

[0000106040-24-000022:notes:133]
The following table summarizes stock option activity under the Company’s incentive plans. As of March 29, 2024, there were no remaining outstanding options.

[0000106040-24-000022:notes:134]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at June 30, 2023 | 0.3 |  |  | $ | 44.95 |  |  | 0.10 |  |  |
| Canceled or expired | (0.3) |  |  | 44.95 |  |  |  |  |  |
| Options outstanding at March 29, 2024 | — |  |  | $ | — |  |  |  |  |  |

[0000106040-24-000022:notes:135]
[same as prior period, unchanged from 0000106040-24-000014:notes:133]

[0000106040-24-000022:notes:136]
[same as prior period, unchanged from 0000106040-24-000014:notes:134]

[0000106040-24-000022:notes:137]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | $ | 46.56 |  |  |  |
| Granted | 5.7 |  |  | 38.31 |  |  |  |
| Vested | (4.9) |  |  | 47.62 |  |  | $ | 228 |  |
| Forfeited | (1.4) |  |  | 45.76 |  |  |  |
| RSUs and PSUs outstanding at March 29, 2024 | 13.2 |  |  | $ | 43.36 |  |  |  |

[0000106040-24-000022:notes:138]
[same as prior period, unchanged from 0000106040-24-000014:notes:136]

[0000106040-24-000022:notes:139]
[same as prior period, unchanged from 0000106040-24-000014:notes:137]

[0000106040-24-000022:notes:140]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million. The Preferred Shares accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of March 29, 2024 and June 30, 2023, unpaid and cumulative dividends payable with respect to the Preferred Shares were $68 million and $24 million, respectively.

[0000106040-24-000022:notes:141]
As of March 29, 2024 and June 30, 2023, the Preferred Shares outstanding had an aggregate liquidation preference of $968 million and $924 million, respectively, and would have been convertible, if otherwise permitted, into approximately 20 million shares of common stock on each such date.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-24-000022:notes:142]
[same as prior period, unchanged from 0000106040-24-000014:notes:140]

[0000106040-24-000022:notes:143]
[same as prior period, unchanged from 0000106040-24-000014:notes:141]

[0000106040-24-000022:notes:144]
[same as prior period, unchanged from 0000106040-24-000014:notes:142]

[0000106040-24-000022:notes:145]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 178 |  | (528) |  | $ | (763) |  | (816) |
| Income tax expense | 43 |  | 43 |  | 74 |  | 159 |
| Effective tax rate | 24 | % |  | (8) | % |  | (10) | % |  | (19) | % |

[0000106040-24-000022:notes:146]
Beginning in 2023, the 2017 Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and nine months ended March 29, 2024 and March 31, 2023.

[0000106040-24-000022:notes:147]
The primary drivers of the difference between the effective tax rate for the three and nine months ended March 29, 2024 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during years 2024 through 2031. On November 1, 2023, one of the Company’s tax holidays in Malaysia expired. The Company has applied for an extension and anticipates this extension, if granted, will be applied retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, the Company is applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, the Company will make an adjustment to its effective tax rate in that period. The effective tax rate for the three and nine months ended March 29, 2024 includes the discrete effect of a net increase of $35 million and $48 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, related to transfer pricing matters, withholding taxes and certain tax deductions. This is offset in part by a net decrease of $7 million and $34 million to the liability for unrecognized tax benefits for the three and nine months ended March 29, 2024, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000022:notes:148]
The primary drivers of the difference between the effective tax rate for the three and nine months ended March 31, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-24-000022:notes:149]
[same as prior period, unchanged from 0000106040-24-000014:notes:147]

[0000106040-24-000022:notes:150]
[same as prior period, unchanged from 0000106040-24-000014:notes:148]

[0000106040-24-000022:notes:151]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended March 29, 2024 (in millions):

[0000106040-24-000022:notes:152]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 23 |  |
| Gross increases related to prior year tax positions | 56 |  |
| Gross decreases related to prior year tax positions | (28) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at March 29, 2024 | $ | 708 |  |

[0000106040-24-000022:notes:153]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of March 29, 2024 were $173 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of March 29, 2024, approximately $719 million could result in potential cash payments and the Company believes it is reasonably likely that payments of approximately $182 million may be made within the next twelve months and has classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on the Condensed Consolidated Balance Sheets as of March 29, 2024. The remaining payables related to unrecognized tax benefits are included in Other liabilities on the Condensed Consolidated Balance Sheets as of March 29, 2024.

[0000106040-24-000022:notes:154]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the nine months ended March 29, 2024, the Company made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $182 million as of March 29, 2024 related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000022:notes:155]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $164 million. Of this amount, $34 million of the interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-24-000022:notes:156]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 29, 2024, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-24-000022:notes:157]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-24-000022:notes:158]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 135 |  |  |  | $ | (571) |  |  | $ | (837) |  |  | $ | (975) |  |
| Less: cumulative dividends on Preferred Stock | 15 |  |  |  | 9 |  |  | 44 |  |  | 9 |  |
| Less: income attributable to participating securities(1) | 7 |  |  |  | — |  |  | — |  |  | — |  |
| Net income (loss) attributable to common shareholders | $ | 113 |  |  |  | $ | (580) |  |  | $ | (881) |  |  | $ | (984) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 326 |  |  |  | 319 |  |  | 324 |  |  | 318 |  |
| RSUs, PSUs, ESPP, and the convertible notes | 9 |  |  |  | — |  |  | — |  |  | — |  |
| Diluted | 335 |  |  |  | 319 |  |  | 324 |  |  | 318 |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  |  | $ | (1.82) |  |  | $ | (2.72) |  |  | $ | (3.09) |  |
| Diluted | $ | 0.34 |  |  |  | $ | (1.82) |  |  | $ | (2.72) |  |  | $ | (3.09) |  |
| Anti-dilutive potential common shares excluded | — |  |  |  | 15 |  |  | 13 |  |  | 15 |  |

[0000106040-24-000022:notes:159]
(1)     Preferred Stock represents participating securities because they participate in any dividends on shares of common stock on a pari passu, pro rata basis. Preferred Stock does not participate in undistributed net losses.

[0000106040-24-000022:notes:160]
Basic net income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the convertible notes and the Preferred Shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-24-000022:notes:161]
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and the Preferred Shares. For the three months ended March 29, 2024, all common shares subject to outstanding equity awards are included in the calculation of diluted shares based on the Company’s average stock price during the period. For the three months ended March 31, 2023 and the nine months ended March 29, 2024 and March 31, 2023, the Company recorded a net loss, and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-24-000022:notes:162]
[same as prior period, unchanged from 0000106040-24-000014:notes:159]

[0000106040-24-000022:notes:163]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. In this regard, in the nine months ended March 29, 2024, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress, other assets and the recognition of a liability for certain contract termination costs. The Company has also taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in September 2023. The Company recorded the following net charges related to these actions for the periods noted below:

[0000106040-24-000022:notes:164]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 1 |  |  | $ | 40 |  |  | $ | 44 |  |  | $ | 125 |  |  |  |
| Contract termination and other | 2 |  |  | — |  |  | 31 |  |  | — |  |  |  |
| Asset impairments | 5 |  |  | — |  |  | 99 |  |  | 15 |  |  |  |
| Gain on sale-leaseback of facility | — |  |  | — |  |  | (85) |  |  | — |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 8 |  |  | $ | 40 |  |  | $ | 89 |  |  | $ | 140 |  |  |  |

[0000106040-24-000022:notes:165]
The following table presents an analysis of the components of these activities against the reserve during the nine months ended March 29, 2024:

[0000106040-24-000022:notes:166]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 30, 2023 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |  |  |  |  |
| Charges | 44 |  |  | 31 |  |  | 75 |  |  |  |  |  |
| Cash payments | (74) |  |  | (9) |  |  | (83) |  |  |  |  |  |
| Accrual balance at March 29, 2024 | $ | 1 |  |  | $ | 27 |  |  | $ | 28 |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-24-000022:notes:167]
[same as prior period, unchanged from 0000106040-24-000014:notes:164]

[0000106040-24-000022:notes:168]
[same as prior period, unchanged from 0000106040-24-000014:notes:165]

[0000106040-24-000022:notes:169]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $37 million and $38 million as of March 29, 2024 and June 30, 2023, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-24-000022:notes:170]
Legal Proceedings
Tax

[0000106040-24-000022:notes:171]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

[0000106040-24-000022:notes:172]
Other Matters

[0000106040-24-000022:notes:173]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:ErrorCorrectionTextBlock

[0000106040-24-000022:notes:174]
Revision of Previously Issued Financial Statements
As described in Note 1, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Ventures. These errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.

[0000106040-24-000022:notes:175]
The following tables provide a summary of the revisions made to the Company’s Condensed Consolidated Financial Statements for the periods presented.

[0000106040-24-000022:notes:176]
|  |  | Three Months Ended March 31, 2023 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating loss |  | $ | (472) |  |  | $ | — |  |  | $ | (472) |  |
| Interest and other expense: |  |  |  |  |  |  |
| Interest income |  | 10 |  |  | — |  |  | 10 |  |
| Interest expense |  | (80) |  |  | — |  |  | (80) |  |
| Other income, net |  | 13 |  |  | 1 |  |  | 14 |  |
| Total interest and other expense, net |  | (57) |  |  | 1 |  |  | (56) |  |
| Loss before taxes |  | (529) |  |  | 1 |  |  | (528) |  |
| Income tax expense |  | 43 |  |  | — |  |  | 43 |  |
| Net loss |  | (572) |  |  | 1 |  |  | (571) |  |
| Less: cumulative dividends allocated to preferred shareholders |  | 9 |  |  | — |  |  | 9 |  |
| Net loss attributable to common shareholders |  | $ | (581) |  |  | $ | 1 |  |  | $ | (580) |  |
| Net loss per common share: |  |  |  |  |  |  |
| Basic |  | $ | (1.82) |  |  | $ | — |  |  | $ | (1.82) |  |
| Diluted |  | $ | (1.82) |  |  | $ | — |  |  | $ | (1.82) |  |

[0000106040-24-000022:notes:177]
|  |  | Nine Months Ended March 31, 2023 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating loss |  | $ | (635) |  |  | $ | — |  |  | $ | (635) |  |
| Interest and other expense: |  |  |  |  |  |  |
| Interest income |  | 15 |  |  | — |  |  | 15 |  |
| Interest expense |  | (223) |  |  | — |  |  | (223) |  |
| Other income, net |  | 13 |  |  | 14 |  |  | 27 |  |
| Total interest and other expense, net |  | (195) |  |  | 14 |  |  | (181) |  |
| Loss before taxes |  | (830) |  |  | 14 |  |  | (816) |  |
| Income tax expense |  | 161 |  |  | (2) |  |  | 159 |  |
| Net loss |  | (991) |  |  | 16 |  |  | (975) |  |
| Less: cumulative dividends allocated to preferred shareholders |  | 9 |  |  | — |  |  | 9 |  |
| Net loss attributable to common shareholders |  | $ | (1,000) |  |  | $ | 16 |  |  | $ | (984) |  |
| Net loss per common share: |  |  |  |  |  |  |
| Basic |  | $ | (3.14) |  |  | $ | 0.05 |  |  | $ | (3.09) |  |
| Diluted |  | $ | (3.14) |  |  | $ | 0.05 |  |  | $ | (3.09) |  |

[0000106040-24-000022:notes:178]
|  |  | Three Months Ended March 31, 2023 |
| Condensed Consolidated Statement of Comprehensive Loss |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net loss |  | $ | (572) |  |  | $ | 1 |  |  | $ | (571) |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |
| Actuarial pension loss |  | (1) |  |  | — |  |  | (1) |  |
| Foreign currency translation adjustment |  | (7) |  |  | (1) |  |  | (8) |  |
| Net unrealized gain on derivative contracts |  | 21 |  |  | — |  |  | 21 |  |
| Total other comprehensive income, before tax |  | 13 |  |  | (1) |  |  | 12 |  |
| Income tax expense related to items of other comprehensive income, before tax |  | (6) |  |  | — |  |  | (6) |  |
| Other comprehensive income, net of tax |  | 7 |  |  | (1) |  |  | 6 |  |
| Total comprehensive loss |  | $ | (565) |  |  | $ | — |  |  | $ | (565) |  |

[0000106040-24-000022:notes:179]
|  |  | Nine Months Ended March 31, 2023 |
| Condensed Consolidated Statement of Comprehensive Loss |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net loss |  | $ | (991) |  |  | $ | 16 |  |  | $ | (975) |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |
| Actuarial pension loss |  | (1) |  |  | — |  |  | (1) |  |
| Foreign currency translation adjustment |  | 8 |  |  | 3 |  |  | 11 |  |
| Net unrealized gain on derivative contracts |  | 233 |  |  | — |  |  | 233 |  |
| Total other comprehensive income, before tax |  | 240 |  |  | 3 |  |  | 243 |  |
| Income tax expense related to items of other comprehensive income, before tax |  | (48) |  |  | 9 |  |  | (39) |  |
| Other comprehensive income, net of tax |  | 192 |  |  | 12 |  |  | 204 |  |
| Total comprehensive loss |  | $ | (799) |  |  | $ | 28 |  |  | $ | (771) |  |

[0000106040-24-000022:notes:180]
|  |  | Nine Months Ended March 31, 2023 |
| Condensed Consolidated Statement of Cash Flows |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |
| Net loss |  | $ | (991) |  |  | $ | 16 |  |  | $ | (975) |  |
| Deferred income taxes |  | 34 |  |  | (4) |  |  | 30 |  |
| Other non-cash operating activities, net |  | 6 |  |  | (14) |  |  | (8) |  |
| Other assets and liabilities, net |  | (165) |  |  | 2 |  |  | (163) |  |
| Net cash used in operating activities |  | (340) |  |  | — |  |  | (340) |  |

[0000106040-24-000022:notes:181]
| Condensed Consolidated Statement of Shareholders’ Equity |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Retained earnings as of March 31, 2023 |  | $ | 8,139 |  |  | $ | 143 |  |  | $ | 8,282 |  |
| Accumulated other comprehensive loss as of March 31, 2023 |  | (362) |  |  | (13) |  |  | (375) |  |
| Foreign currency translation adjustment for the three months ended March 31, 2023 |  | (8) |  |  | (1) |  |  | (9) |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000106040-24-000022:notes:182]
Michael Ray, a former Executive Vice President, Chief Legal Officer and Secretary of the Company who left the Company effective January 12, 2024, terminated a Rule 10b5-1 Plan on February 23, 2024.
