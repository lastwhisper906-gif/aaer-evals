# WDC note change history — 0000106040-24-000014 → 0000106040-24-000022


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:1]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended March 29, 2024 (in millions):
  (was, 2024-02-12, similarity 0.962):
[0000106040-24-000014:note_history:1]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the six months ended December 29, 2023 (in millions):

- changed (2024-04-30):
[0000106040-24-000022:note_history:2]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 23 |  |
| Gross increases related to prior year tax positions | 56 |  |
| Gross decreases related to prior year tax positions | (28) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at March 29, 2024 | $ | 708 |  |
  (was, 2024-02-12, similarity 0.984):
[0000106040-24-000014:note_history:2]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 19 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at December 29, 2023 | $ | 677 |  |


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:3]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | — |  |  | 48 |  |
| Notes receivable, Flash Forward | 556 |  |  | 709 |  |
| Investment in Flash Partners | 157 |  |  | 161 |  |
| Investment in Flash Alliance | 234 |  |  | 276 |  |
| Investment in Flash Forward | 152 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,099 |  |  | $ | 1,410 |  |
  (was, 2024-02-12, similarity 0.9802):
[0000106040-24-000014:note_history:3]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 9 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 28 |  |  | 48 |  |
| Notes receivable, Flash Forward | 689 |  |  | 709 |  |
| Investment in Flash Partners | 168 |  |  | 161 |  |
| Investment in Flash Alliance | 279 |  |  | 276 |  |
| Investment in Flash Forward | 171 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,344 |  |  | $ | 1,410 |  |

- changed (2024-04-30):
[0000106040-24-000022:note_history:4]
During the three and nine months ended March 29, 2024 and March 31, 2023, the Company made net payments to Flash Ventures of $0.7 billion and $2.5 billion, and $1.2 billion and $3.2 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2024-02-12, similarity 0.8371):
[0000106040-24-000014:note_history:4]
During the three and six months ended December 29, 2023 and December 30, 2022, the Company made net payments to Flash Ventures of $0.8 billion and $1.8 billion, and $1.0 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2024-04-30):
[0000106040-24-000022:note_history:5]
As of March 29, 2024 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $310 million and $292 million, respectively.
  (was, 2024-02-12, similarity 0.9673):
[0000106040-24-000014:note_history:5]
As of December 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $251 million and $292 million, respectively.

- changed (2024-04-30):
[0000106040-24-000022:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2024-02-12, similarity 0.9851):
[0000106040-24-000014:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2024-04-30):
[0000106040-24-000022:note_history:7]
|  | March 29,2024 |
|  | (in millions) |
| Notes receivable | $ | 556 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,431 |  |
| Inventory and prepayments | 1,046 |  |
| Maximum estimable loss exposure | $ | 3,576 |  |
  (was, 2024-02-12, similarity 0.9742):
[0000106040-24-000014:note_history:7]
|  | December 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 618 |  |
| Operating lease guarantees | 1,609 |  |
| Inventory and prepayments | 1,058 |  |
| Maximum estimable loss exposure | $ | 4,011 |  |

- changed (2024-04-30):
[0000106040-24-000022:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, during the second half of 2023 and the first two quarters of 2024, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level during that period to more closely align the Company’s flash-based wafer supply with projected demand. During the nine months ended March 29, 2024, the Company incurred costs of $249 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended March 29, 2024 nor the three and nine months ended March 31, 2023.
  (was, 2024-02-12, similarity 0.6403):
[0000106040-24-000014:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 30, 2022.

- changed (2024-04-30):
[0000106040-24-000022:note_history:9]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of March 29, 2024, such prepayments aggregated $496 million and will be credited against future wafer charges.
  (was, 2024-02-12, similarity 0.9862):
[0000106040-24-000014:note_history:9]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of December 29, 2023, such prepayments aggregated $549 million and will be credited against future wafer charges.

- changed (2024-04-30):
[0000106040-24-000022:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024.
  (was, 2024-02-12, similarity 0.9785):
[0000106040-24-000014:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023.

- changed (2024-04-30):
[0000106040-24-000022:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024:
  (was, 2024-02-12, similarity 0.9639):
[0000106040-24-000014:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2023:

- changed (2024-04-30):
[0000106040-24-000022:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2024 |  | $ | 110 |  |  | $ | 27 |  |  | $ | 137 |  |
| 2025 |  | 290 |  |  | 79 |  |  | 369 |  |
| 2026 |  | 359 |  |  | 119 |  |  | 478 |  |
| 2027 |  | 154 |  |  | 101 |  |  | 255 |  |
| 2028 |  | 50 |  |  | 97 |  |  | 147 |  |
| 2029 |  | 6 |  |  | 39 |  |  | 45 |  |
| Total guarantee obligations |  | $ | 969 |  |  | $ | 462 |  |  | $ | 1,431 |  |
  (was, 2024-02-12, similarity 0.991):
[0000106040-24-000014:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2024 |  | $ | 237 |  |  | $ | 57 |  |  | $ | 294 |  |
| 2025 |  | 300 |  |  | 84 |  |  | 384 |  |
| 2026 |  | 362 |  |  | 127 |  |  | 489 |  |
| 2027 |  | 150 |  |  | 108 |  |  | 258 |  |
| 2028 |  | 47 |  |  | 104 |  |  | 151 |  |
| 2029 |  | 3 |  |  | 30 |  |  | 33 |  |
| Total guarantee obligations |  | $ | 1,099 |  |  | $ | 510 |  |  | $ | 1,609 |  |

- changed (2024-04-30):
[0000106040-24-000022:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2024, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2024-02-12, similarity 0.9873):
[0000106040-24-000014:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2024-04-30):
[0000106040-24-000022:note_history:14]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 29, 2024, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 10% and 8% of Accounts receivable, net as of both March 29, 2024 and June 30, 2023, respectively.
  (was, 2024-02-12, similarity 0.8841):
[0000106040-24-000014:note_history:14]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. For both the three and six months ended December 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 8% of Accounts receivable, net as of both December 29, 2023 and June 30, 2023.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:15]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended on June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2024-02-12, similarity 0.9962):
[0000106040-24-000014:note_history:15]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- changed (2024-04-30):
[0000106040-24-000022:note_history:16]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its Flash and HDD business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.
  (was, 2024-02-12, similarity 0.9808):
[0000106040-24-000014:note_history:16]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

- changed (2024-04-30):
[0000106040-24-000022:note_history:17]
As previously disclosed in the Company’s Quarterly Report on Form 10-Q for the period ended December 28, 2023, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, “Flash Ventures”). The errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.
  (was, 2024-02-12, similarity 0.9374):
[0000106040-24-000014:note_history:17]
In connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, the “Flash Ventures”). The errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in the Flash Ventures.

- changed (2024-04-30):
[0000106040-24-000022:note_history:18]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the period detected would have been material to the Company's results of operations for that period. Accordingly, the Company has revised previously reported financial information presented herein for such immaterial errors. A summary of revisions to the Condensed Consolidated Financial Statements presented herein is included for comparative purposes in Note 17, Revision of Previously Issued Financial Statements.
  (was, 2024-02-12, similarity 0.6398):
[0000106040-24-000014:note_history:18]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the current period would be material to the Company's results of operations for the three and six months ended December 29, 2023. Accordingly, the Company has revised previously reported financial information for such immaterial errors. A summary of revisions to previously reported financial information presented herein for comparative purposes is included in Note 17, Revision of Previously Issued Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:19]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,625 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,825 |  |  | 7,100 |  |
| Issuance costs | (57) |  |  | (30) |  |
| Subtotal | 7,768 |  |  | 7,070 |  |
| Less current portion of long-term debt | (450) |  |  | (1,213) |  |
| Long-term debt | $ | 7,318 |  |  | $ | 5,857 |  |
  (was, 2024-02-12, similarity 0.9214):
[0000106040-24-000014:note_history:19]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,662 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 8,454 |  |  | 7,100 |  |
| Issuance costs | (61) |  |  | (30) |  |
| Subtotal | 8,393 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,042) |  |  | (1,213) |  |
| Long-term debt | $ | 7,351 |  |  | $ | 5,857 |  |

- changed (2024-04-30):
[0000106040-24-000022:note_history:20]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the nine months ended March 29, 2024.
  (was, 2024-02-12, similarity 0.9419):
[0000106040-24-000014:note_history:20]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the quarter ended December 29, 2023.

- changed (2024-04-30):
[0000106040-24-000022:note_history:21]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of March 29, 2024 was 7.550%.
  (was, 2024-02-12, similarity 0.9892):
[0000106040-24-000014:note_history:21]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of December 29, 2023 was 7.582%.

- changed (2024-04-30):
[0000106040-24-000022:note_history:22]
During the three and nine months ended March 29, 2024, the Company made scheduled repayments of the Term Loan A-2 of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of March 29, 2024 was 6.930%.
  (was, 2024-02-12, similarity 0.8536):
[0000106040-24-000014:note_history:22]
During the three months ended December 29, 2023, the Company made a $38 million scheduled repayment of the Term Loan A-2. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 29, 2023 was 6.966%.

- added (2024-04-30):
[0000106040-24-000022:note_history:23]
During the three and nine months ended March 29, 2024, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- added (2024-04-30):
[0000106040-24-000022:note_history:24]
On March 25, 2024, the Company issued a standby letter of credit of $15 million, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.24 billion as of March 29, 2024.

- changed (2024-04-30):
[0000106040-24-000022:note_history:25]
The loan agreements governing the Company’s 2027 Revolving Credit Facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, and a minimum liquidity requirement. As of March 29, 2024, the Company was in compliance with these financial covenants.
  (was, 2024-02-12, similarity 0.9425):
[0000106040-24-000014:note_history:25]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of December 29, 2023, the Company was in compliance with these financial covenants.

- added (2024-04-30):
[0000106040-24-000022:note_history:26]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- changed (2024-04-30):
[0000106040-24-000022:note_history:27]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes.
  (was, 2024-02-12, similarity 0.8697):
[0000106040-24-000014:note_history:27]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes. As of December 29, 2023, unamortized debt issuance costs were $36 million.

- changed (2024-04-30):
[0000106040-24-000022:note_history:28]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to Additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of March 29, 2024.
  (was, 2024-02-12, similarity 0.9963):
[0000106040-24-000014:note_history:28]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of December 29, 2023.

- removed (2024-04-30):
[0000106040-24-000014:note_history:29]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:30]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,625 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,825 |  |  | 7,100 |  |
| Issuance costs | (57) |  |  | (30) |  |
| Subtotal | 7,768 |  |  | 7,070 |  |
| Less current portion of long-term debt | (450) |  |  | (1,213) |  |
| Long-term debt | $ | 7,318 |  |  | $ | 5,857 |  |
  (was, 2024-02-12, similarity 0.9214):
[0000106040-24-000014:note_history:30]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 592 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,662 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 8,454 |  |  | 7,100 |  |
| Issuance costs | (61) |  |  | (30) |  |
| Subtotal | 8,393 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,042) |  |  | (1,213) |  |
| Long-term debt | $ | 7,351 |  |  | $ | 5,857 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:31]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | — |  |  | 48 |  |
| Notes receivable, Flash Forward | 556 |  |  | 709 |  |
| Investment in Flash Partners | 157 |  |  | 161 |  |
| Investment in Flash Alliance | 234 |  |  | 276 |  |
| Investment in Flash Forward | 152 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,099 |  |  | $ | 1,410 |  |
  (was, 2024-02-12, similarity 0.9802):
[0000106040-24-000014:note_history:31]
|  | December 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 9 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 28 |  |  | 48 |  |
| Notes receivable, Flash Forward | 689 |  |  | 709 |  |
| Investment in Flash Partners | 168 |  |  | 161 |  |
| Investment in Flash Alliance | 279 |  |  | 276 |  |
| Investment in Flash Forward | 171 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,344 |  |  | $ | 1,410 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000106040-24-000022:note_history:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 1,553 |  |  | $ | 1,205 |  |  | $ | 3,496 |  |  | $ | 4,258 |  |
| Client | 1,174 |  |  | 975 |  |  | 3,443 |  |  | 3,293 |  |
| Consumer | 730 |  |  | 623 |  |  | 2,300 |  |  | 2,095 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,740 |  |  | $ | 1,353 |  |  | $ | 4,990 |  |  | $ | 4,533 |  |
| Americas | 1,154 |  |  | 935 |  |  | 2,620 |  |  | 3,448 |  |
| Europe, Middle East and Africa | 563 |  |  | 515 |  |  | 1,629 |  |  | 1,665 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
  (was, 2024-02-12, similarity 0.92):
[0000106040-24-000014:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,071 |  |  | $ | 1,224 |  |  | $ | 1,943 |  |  | $ | 3,053 |  |
| Client | 1,122 |  |  | 1,089 |  |  | 2,269 |  |  | 2,318 |  |
| Consumer | 839 |  |  | 794 |  |  | 1,570 |  |  | 1,472 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,699 |  |  | $ | 1,494 |  |  | $ | 3,250 |  |  | $ | 3,180 |  |
| Americas | 804 |  |  | 1,090 |  |  | 1,466 |  |  | 2,513 |  |
| Europe, Middle East and Africa | 529 |  |  | 523 |  |  | 1,066 |  |  | 1,150 |  |
| Total Revenue | $ | 3,032 |  |  | $ | 3,107 |  |  | $ | 5,782 |  |  | $ | 6,843 |  |
