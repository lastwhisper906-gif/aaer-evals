# WDC 8-K — 0000106040-24-000020 filed 2024-04-25

## item codes, every 8-K on or before 2024-04-30

- 2024-04-25 0000106040-24-000020 — 2.02, 9.01
- 2024-03-05 0001193125-24-059385 — 8.01, 9.01
- 2024-03-04 0001193125-24-056949 — 1.01, 8.01
- 2024-01-25 0000106040-24-000003 — 2.02, 9.01
- 2024-01-04 0001193125-24-002432 — 5.02
- 2023-12-26 0001193125-23-302249 — 8.01, 9.01
- 2023-11-17 0001193125-23-279782 — 5.02, 5.07, 9.01
- 2023-11-03 0001193125-23-270415 — 1.01, 2.03, 3.02, 9.01
- 2023-11-01 0001193125-23-267654 — 7.01, 9.01
- 2023-10-30 0001193125-23-266188 — 7.01, 9.01
- 2023-10-30 0001193125-23-265708 — 7.01, 9.01
- 2023-10-30 0000106040-23-000032 — 2.02, 9.01
- 2023-10-10 0001193125-23-253508 — 1.01, 9.01
- 2023-07-31 0000106040-23-000020 — 2.02, 5.02, 9.01
- 2023-06-21 0001193125-23-171211 — 1.01, 9.01
- 2023-05-08 0000106040-23-000014 — 2.02, 9.01
- 2023-05-05 0001193125-23-137241 — 8.01, 9.01
- 2023-04-03 0001193125-23-088802 — 8.01, 9.01
- 2023-02-07 0001193125-23-026907 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01 — amendment of 0001193125-23-020502
- 2023-02-01 0001193125-23-020502 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01
- 2023-01-31 0000106040-23-000006 — 1.01, 2.02, 2.03, 9.01
- 2022-12-23 0001193125-22-311796 — 1.01, 9.01
- 2022-11-18 0001193125-22-288992 — 5.02, 5.07, 9.01
- 2022-10-27 0000106040-22-000061 — 2.02, 9.01
- 2022-08-05 0000106040-22-000049 — 2.02, 9.01
- 2022-07-01 0001193125-22-187239 — 1.01, 9.01
- 2022-06-17 0001193125-22-176478 — 5.02, 9.01
- 2022-06-08 0001193125-22-169552 — 1.01, 7.01, 8.01, 9.01
- 2022-04-28 0000106040-22-000030 — 2.02, 9.01
- 2022-01-27 0001193125-22-019801 — 5.02, 7.01, 9.01
- 2022-01-27 0000106040-22-000010 — 2.02, 9.01
- 2022-01-07 0001193125-22-004434 — 1.01, 2.03, 7.01
- 2021-12-10 0001193125-21-353971 — 1.01, 2.03, 7.01, 8.01, 9.01
- 2021-12-06 0001193125-21-348304 — 7.01
- 2021-11-19 0001193125-21-335120 — 5.04, 9.01
- 2021-11-18 0001193125-21-332703 — 5.02
- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2024-04-30

- 2024-02-08 0000106040-24-000011 — NT 10-Q, for the period ended 2023-12-29
- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-24-000020:8k_2_02:1]
EX-99.1
2
a4ex991-pressreleaseq324.htm
EX-99.1

[0000106040-24-000020:8k_2_02:2]
Document

[0000106040-24-000020:8k_2_02:3]
Exhibit 99.1

[0000106040-24-000020:8k_2_02:4]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:5]
News Summary

[0000106040-24-000020:8k_2_02:6]
•Third quarter revenue was $3.46 billion, up 14% sequentially (QoQ). Cloud revenue increased 45% (QoQ), Client revenue increased 5% (QoQ) and Consumer revenue decreased (13)% (QoQ).

[0000106040-24-000020:8k_2_02:7]
•Third quarter GAAP earnings per share (EPS) was $0.34 and Non-GAAP EPS was $0.63, which includes underutilization-related charges in HDD.

[0000106040-24-000020:8k_2_02:8]
•Expect fiscal fourth quarter 2024 revenue to be in the range of $3.60 billion to $3.80 billion.

[0000106040-24-000020:8k_2_02:9]
•Expect Non-GAAP EPS in the range of $0.90 to $1.20.

[0000106040-24-000020:8k_2_02:10]
SAN JOSE, Calif., — April 25, 2024 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal third quarter 2024 financial results.

[0000106040-24-000020:8k_2_02:11]
“As evidenced by our excellent third quarter results, Western Digital continues improving through-cycle profitability and dampening business cycles by leveraging our strategy of developing a diversified portfolio of industry-leading products across a broad range of end markets,” said David Goeckeler, Western Digital CEO. “We are in the early innings of unlocking the full potential of this company, and as industry supply and demand dynamics continue to improve, we will remain disciplined around our capital spending and focused on driving innovation and efficiency across our businesses. We are confident in our strategy and the actions we have taken to-date, which successfully position us to capitalize on the promising growth prospects that lie ahead.”

[0000106040-24-000020:8k_2_02:12]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:13]
Q3 2024 Financial Highlights

[0000106040-24-000020:8k_2_02:14]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2024 | Q2 2024 | Q/Q |  | Q3 2024 | Q2 2024 | Q/Q |
| Revenue ($M) |  | $3,457 | $3,032 | up 14% |  | $3,457 | $3,032 | up 14% |
| Gross Margin |  | 29.0% | 16.2% | up 12.8 ppt |  | 29.3% | 15.5% | up 13.8 ppt |
| Operating Expenses ($M) |  | $728 | $702 | up 4% |  | $632 | $561 | up 13% |
| Operating Income (Loss) ($M) |  | $273 | $(210) | * |  | $380 | $(91) | * |
| Diluted Net Income (Loss) Attributable to Common Shareholders ($M) |  | $113 | $(301) | * |  | $210 | $(243) | * |
| Net Income (Loss) Per Share |  | $0.34 | $(0.93) | * |  | $0.63 | $(0.75) | * |

[0000106040-24-000020:8k_2_02:15]
* not a meaningful figure

[0000106040-24-000020:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2024 | Q3 2023 | Y/Y |  | Q3 2024 | Q3 2023 | Y/Y |
| Revenue ($M) |  | $3,457 | $2,803 | up 23% |  | $3,457 | $2,803 | up 23% |
| Gross Margin |  | 29.0% | 10.2% | up 18.8 ppt |  | 29.3% | 10.6% | up 18.7 ppt |
| Operating Expenses ($M) |  | $728 | $758 | down 4% |  | $632 | $602 | up 5% |
| Operating Income (Loss) ($M) |  | $273 | $(472) | * |  | $380 | $(304) | * |
| Diluted Net Income (Loss) Attributable to Common Shareholders ($M) |  | $113 | $(580) | * |  | $210 | ($435) | * |
| Net Income (Loss) Per Share |  | $0.34 | $(1.82) | * |  | $0.63 | $(1.36) | * |

[0000106040-24-000020:8k_2_02:17]
* not a meaningful figure

[0000106040-24-000020:8k_2_02:18]
The company had an operating cash inflow of $58 million and ended the quarter with $1.89 billion of total cash and cash equivalents.

[0000106040-24-000020:8k_2_02:19]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-24-000020:8k_2_02:20]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:21]
End Market Summary

[0000106040-24-000020:8k_2_02:22]
| Revenue ($M) | Q3 2024 | Q2 2024 | Q/Q |  |  | Q3 2023 | Y/Y |  |  |  |
| Cloud | $1,553 | $1,071 | up 45% |  |  | $1,205 | up 29% |  |  |  |
| Client | 1,174 | 1,122 | up 5% |  |  | 975 | up 20% |  |  |  |
| Consumer | 730 | 839 | down 13% |  |  | 623 | up 17% |  |  |  |
| Total Revenue | $3,457 | $3,032 | up 14% |  |  | $2,803 | up 23% |  |  |  |

[0000106040-24-000020:8k_2_02:23]
In the fiscal third quarter:

[0000106040-24-000020:8k_2_02:24]
•Cloud represented 45% of total revenue. The growth was primarily attributed to higher nearline shipments and improved nearline per unit pricing with flash revenue up both sequentially and year-over-year.

[0000106040-24-000020:8k_2_02:25]
•Client represented 34% of total revenue. Sequentially, the increase in flash ASP more than offset a decline in flash bit shipments while HDD revenue decreased. The year-over-year increase was driven by growth in both flash and HDD ASPs and flash bit shipments.

[0000106040-24-000020:8k_2_02:26]
•Consumer represented 21% of total revenue. Sequentially, both flash and HDD were down at approximately similar rates and in line with seasonality. The year-over-year increase was driven by growth in flash bit shipments and ASP.

[0000106040-24-000020:8k_2_02:27]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:28]
Business Outlook for Fiscal Fourth Quarter of 2024

[0000106040-24-000020:8k_2_02:29]
|  | Three Months Ending |
|  | June 28, 2024 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) | $3.60 - $3.80 |  | $3.60 - $3.80 |
| Gross margin | 31.5% - 33.5% |  | 32.0% - 34.0% |
| Operating expenses ($M) | $770 - $800 |  | $670 - $690 |
| Interest and other expense, net ($M) | ~ $105 |  | ~ $105 |
| Income tax expense ($M)(2) | N/A |  | $30 - $40 |
| Diluted earnings per share | N/A |  | $0.90 - $1.20 |
| Diluted shares outstanding (in millions) | ~342 |  | ~342 |

[0000106040-24-000020:8k_2_02:30]
(1) Non-GAAP gross margin guidance excludes amortization of acquired intangible assets and stock-based compensation expense of approximately $10 million to $15 million. The company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense, and expenses related to business separation costs, totaling approximately $100 million to $110 million. In the aggregate, Non-GAAP diluted earnings per share guidance excludes these items totaling approximately $110 million to $125 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, and Non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. The timing and amount of additional charges the company excludes from its Non-GAAP income tax expense and Non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP income tax expense and Non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (GAAP gross profit, GAAP operating expenses, income tax expense and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-24-000020:8k_2_02:31]
(2) Non-GAAP income tax expense is determined based on a percentage of Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax dollars may differ from our GAAP tax dollars (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax rate for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0000106040-24-000020:8k_2_02:32]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:33]
Revisions to Prior Period Financial Results

[0000106040-24-000020:8k_2_02:34]
As previously reported, in connection with the preparation of its condensed consolidated financial statements as of and for the three and six months ended December 29, 2023, the company identified certain errors related to the company’s reporting and recording of its interests in its equity method investments in Flash Ventures. These errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the company in Other income (expense), net and the carrying value of the company’s equity method investments in Flash Ventures in the unaudited condensed consolidated financial statements. The company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred. The company has revised previously reported financial information for such immaterial errors, and the unaudited preliminary condensed consolidated financial statements included in this press release incorporate revisions made to correct these errors for the periods presented. Please refer to the tables outlining revisions to results of operations in the company's earnings presentation, which is accessible online at investor.wdc.com, and to the company's upcoming Quarterly Report on Form 10-Q for the fiscal third quarter ending March 29, 2024, for additional information related to these revisions.

[0000106040-24-000020:8k_2_02:35]
Investor Communications

[0000106040-24-000020:8k_2_02:36]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal fourth quarter of 2024 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-24-000020:8k_2_02:37]
About Western Digital

[0000106040-24-000020:8k_2_02:38]
Western Digital is on a mission to unlock the potential of data by harnessing the possibility to use it. With Flash and HDD franchises, underpinned by advancements in storage technologies, we create breakthrough innovations and powerful data storage solutions that enable the world to actualize its aspirations. Core to our values, we recognize the urgency to combat climate change and have committed to ambitious carbon reduction goals approved by the Science Based Targets initiative. Learn more about Western Digital and the Western Digital®, SanDisk® and WD® brands at www.westerndigital.com.

[0000106040-24-000020:8k_2_02:39]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:40]
Forward-Looking Statements

[0000106040-24-000020:8k_2_02:41]
Western Digital Reports Fiscal Third Quarter 2024 Financial Results

[0000106040-24-000020:8k_2_02:42]
with the SEC on August 22, 2023 and Quarterly Reports on Form 10-Q filed with the SEC on November 7, 2023 and February 12, 2024, to which your attention is directed. You should not place undue reliance on these

[0000106040-24-000020:8k_2_02:43]
forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update or revise these forward-looking statements to reflect new information or events, except as required by law.

[0000106040-24-000020:8k_2_02:44]
###

[0000106040-24-000020:8k_2_02:45]
Western Digital, the Western Digital logo, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-24-000020:8k_2_02:46]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:47]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-24-000020:8k_2_02:48]
(in millions; unaudited; on a US GAAP basis)

[0000106040-24-000020:8k_2_02:49]
|  | March 29,2024 |  | June 30,2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,894 |  |  | $ | 2,023 |  |
| Accounts receivable, net | 1,800 |  |  | 1,598 |  |
| Inventories | 3,215 |  |  | 3,698 |  |
| Other current assets | 623 |  |  | 567 |  |
| Total current assets | 7,532 |  |  | 7,886 |  |
| Property, plant and equipment, net | 3,253 |  |  | 3,620 |  |
| Notes receivable and investments in Flash Ventures | 1,099 |  |  | 1,410 |  |
| Goodwill | 10,034 |  |  | 10,037 |  |
| Other intangible assets, net | 78 |  |  | 80 |  |
| Other non-current assets | 1,805 |  |  | 1,513 |  |
| Total assets | $ | 23,801 |  |  | $ | 24,546 |  |
| LIABILITIES, CONVERTIBLE PREFERRED STOCK AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,400 |  |  | $ | 1,293 |  |
| Accounts payable to related parties | 310 |  |  | 292 |  |
| Accrued expenses | 972 |  |  | 1,288 |  |
| Income taxes payable | 476 |  |  | 999 |  |
| Accrued compensation | 445 |  |  | 349 |  |
| Current portion of long-term debt | 450 |  |  | 1,213 |  |
| Total current liabilities | 4,053 |  |  | 5,434 |  |
| Long-term debt | 7,318 |  |  | 5,857 |  |
| Other liabilities | 1,433 |  |  | 1,415 |  |
| Total liabilities | 12,804 |  |  | 12,706 |  |
| Convertible preferred stock, aggregate liquidation preference of $968 and $924, respectively | 876 |  |  | 876 |  |
| Total shareholders’ equity | 10,121 |  |  | 10,964 |  |
| Total liabilities, convertible preferred stock and shareholders’ equity | $ | 23,801 |  |  | $ | 24,546 |  |

[0000106040-24-000020:8k_2_02:50]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:51]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-24-000020:8k_2_02:52]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-24-000020:8k_2_02:53]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenue, net | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |  |  |
| Cost of revenue | 2,456 |  |  | 2,517 |  |  | 7,647 |  |  | 7,851 |  |  |  |
| Gross profit | 1,001 |  |  | 286 |  |  | 1,592 |  |  | 1,795 |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 494 |  |  | 476 |  |  | 1,369 |  |  | 1,551 |  |  |  |
| Selling, general and administrative | 203 |  |  | 242 |  |  | 608 |  |  | 739 |  |  |  |
| Employee termination, asset impairment, and other | 8 |  |  | 40 |  |  | 89 |  |  | 140 |  |  |  |
| Business separation costs | 23 |  |  | — |  |  | 59 |  |  | — |  |  |  |
| Total operating expenses | 728 |  |  | 758 |  |  | 2,125 |  |  | 2,430 |  |  |  |
| Operating income (loss) | 273 |  |  | (472) |  |  | (533) |  |  | (635) |  |  |  |
| Interest and other expense | (95) |  |  | (56) |  |  | (230) |  |  | (181) |  |  |  |
| Income (loss) before taxes | 178 |  |  | (528) |  |  | (763) |  |  | (816) |  |  |  |
| Income tax expense | 43 |  |  | 43 |  |  | 74 |  |  | 159 |  |  |  |
| Net income (loss) | 135 |  |  | (571) |  |  | (837) |  |  | (975) |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 15 |  |  | 9 |  |  | 44 |  |  | 9 |  |  |  |
| Less: income attributable to preferred shareholders | 7 |  |  | — |  |  | — |  |  | — |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 113 |  |  | $ | (580) |  |  | $ | (881) |  |  | $ | (984) |  |  |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | (1.82) |  |  | $ | (2.72) |  |  | $ | (3.09) |  |  |  |
| Diluted | $ | 0.34 |  |  | $ | (1.82) |  |  | $ | (2.72) |  |  | $ | (3.09) |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 326 |  |  | 319 |  |  | 324 |  |  | 318 |  |  |  |
| Diluted | 335 |  |  | 319 |  |  | 324 |  |  | 318 |  |  |  |

[0000106040-24-000020:8k_2_02:54]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:55]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-24-000020:8k_2_02:56]
(in millions; unaudited; on a US GAAP basis)

[0000106040-24-000020:8k_2_02:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | 135 |  |  | $ | (571) |  |  | $ | (837) |  |  | $ | (975) |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 140 |  |  | 213 |  |  | 430 |  |  | 643 |  |
| Stock-based compensation | 77 |  |  | 74 |  |  | 226 |  |  | 246 |  |
| Deferred income taxes | (52) |  |  | 9 |  |  | (120) |  |  | 30 |  |
| Gain on disposal of assets | — |  |  | (8) |  |  | (87) |  |  | (7) |  |
| Non-cash asset impairment | 4 |  |  | 3 |  |  | 99 |  |  | 18 |  |
| Gain on repurchase of debt | — |  |  | — |  |  | (4) |  |  | — |  |
| Amortization of debt issuance costs and discounts | 5 |  |  | 4 |  |  | 14 |  |  | 9 |  |
| Other non-cash operating activities, net | 52 |  |  | (64) |  |  | 24 |  |  | (8) |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (277) |  |  | 314 |  |  | (202) |  |  | 1,213 |  |
| Inventories | 1 |  |  | (206) |  |  | 483 |  |  | (341) |  |
| Accounts payable | (88) |  |  | 79 |  |  | 211 |  |  | (442) |  |
| Accounts payable to related parties | 59 |  |  | (103) |  |  | 18 |  |  | (54) |  |
| Accrued expenses | (64) |  |  | (258) |  |  | (310) |  |  | (484) |  |
| Income taxes payable | (30) |  |  | (12) |  |  | (524) |  |  | 144 |  |
| Accrued compensation | 93 |  |  | (7) |  |  | 97 |  |  | (169) |  |
| Other assets and liabilities, net | 3 |  |  | 152 |  |  | (178) |  |  | (163) |  |
| Net cash provided by (used in) operating activities | 58 |  |  | (381) |  |  | (660) |  |  | (340) |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (95) |  |  | (110) |  |  | (176) |  |  | (688) |  |
| Activity related to Flash Ventures, net | 128 |  |  | (36) |  |  | 207 |  |  | 46 |  |
| Strategic investments and other, net | (26) |  |  | 8 |  |  | — |  |  | 22 |  |
| Net cash provided by (used in) investing activities | 7 |  |  | (138) |  |  | 31 |  |  | (620) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | (16) |  |  | (13) |  |  | (26) |  |  | (20) |  |
| Net proceeds from convertible preferred stock | — |  |  | 882 |  |  | (5) |  |  | 882 |  |
| Purchase of capped calls | — |  |  | — |  |  | (155) |  |  | — |  |
| Repurchases of debt | — |  |  | — |  |  | (505) |  |  | — |  |
| Proceeds from debt, net of repayments | (629) |  |  | — |  |  | 1,233 |  |  | — |  |
| Debt issuance costs | — |  |  | (1) |  |  | (36) |  |  | (6) |  |
| Net cash provided by (used in) financing activities | (645) |  |  | 868 |  |  | 506 |  |  | 856 |  |
| Effect of exchange rate changes on cash | (7) |  |  | — |  |  | (6) |  |  | (3) |  |
| Net increase (decrease) in cash and cash equivalents | (587) |  |  | 349 |  |  | (129) |  |  | (107) |  |
| Cash and cash equivalents, beginning of period | 2,481 |  |  | 1,871 |  |  | 2,023 |  |  | 2,327 |  |
| Cash and cash equivalents, end of period | $ | 1,894 |  |  | $ | 2,220 |  |  | $ | 1,894 |  |  | $ | 2,220 |  |

[0000106040-24-000020:8k_2_02:58]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:59]
SUPPLEMENTAL OPERATING SEGMENT RESULTS

[0000106040-24-000020:8k_2_02:60]
(in millions; except percentages; unaudited)

[0000106040-24-000020:8k_2_02:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,705 |  |  | $ | 1,307 |  |  | $ | 4,926 |  |  | $ | 4,686 |  |
| HDD | 1,752 |  |  | 1,496 |  |  | 4,313 |  |  | 4,960 |  |
| Total net revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 467 |  |  | $ | (65) |  |  | $ | 437 |  |  | $ | 597 |  |
| HDD | 545 |  |  | 363 |  |  | 1,157 |  |  | 1,237 |  |
| Total gross profit for segments | 1,012 |  |  | 298 |  |  | 1,594 |  |  | 1,834 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (11) |  |  | (12) |  |  | (37) |  |  | (38) |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (2) |  |  | (1) |  |
| Recovery from contamination incident | 1 |  |  | — |  |  | 37 |  |  | — |  |
| Total unallocated corporate items | (11) |  |  | (12) |  |  | (2) |  |  | (39) |  |
| Consolidated gross profit | $ | 1,001 |  |  | $ | 286 |  |  | $ | 1,592 |  |  | $ | 1,795 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 27.4 | % |  | (5.0) | % |  | 8.9 | % |  | 12.7 | % |
| HDD | 31.1 | % |  | 24.3 | % |  | 26.8 | % |  | 24.9 | % |
| Total gross margin for segments | 29.3 | % |  | 10.6 | % |  | 17.3 | % |  | 19.0 | % |
| Consolidated gross margin | 29.0 | % |  | 10.2 | % |  | 17.2 | % |  | 18.6 | % |

[0000106040-24-000020:8k_2_02:62]
The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”). In the table above, total gross profit for segments and total gross margin for segments are Non-GAAP financial measures, which are also referred to herein as Non-GAAP gross profit and Non-GAAP gross margin, respectively.

[0000106040-24-000020:8k_2_02:63]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:64]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-24-000020:8k_2_02:65]
(in millions; unaudited)

[0000106040-24-000020:8k_2_02:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | December 29,2023 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| GAAP gross profit | $ | 1,001 |  |  | $ | 492 |  |  | $ | 286 |  |  | $ | 1,592 |  |  | $ | 1,795 |  |
| Stock-based compensation expense | 11 |  |  | 13 |  |  | 12 |  |  | 37 |  |  | 38 |  |
| Amortization of acquired intangible assets | 1 |  |  | 1 |  |  | — |  |  | 2 |  |  | 1 |  |
| Recovery from contamination incident | (1) |  |  | (36) |  |  | — |  |  | (37) |  |  | — |  |
| Non-GAAP gross profit | $ | 1,012 |  |  | $ | 470 |  |  | $ | 298 |  |  | $ | 1,594 |  |  | $ | 1,834 |  |
| GAAP operating expenses | $ | 728 |  |  | $ | 702 |  |  | $ | 758 |  |  | $ | 2,125 |  |  | $ | 2,430 |  |
| Stock-based compensation expense | (66) |  |  | (59) |  |  | (62) |  |  | (189) |  |  | (208) |  |
| Business separation costs | (23) |  |  | (36) |  |  | — |  |  | (59) |  |  | — |  |
| Employee termination, asset impairment, and other | (8) |  |  | (24) |  |  | (40) |  |  | (89) |  |  | (140) |  |
| Strategic review | — |  |  | (20) |  |  | (15) |  |  | (37) |  |  | (15) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (39) |  |  | — |  |  | (116) |  |
| Other | 1 |  |  | (2) |  |  | — |  |  | (3) |  |  | (1) |  |
| Non-GAAP operating expenses | $ | 632 |  |  | $ | 561 |  |  | $ | 602 |  |  | $ | 1,748 |  |  | $ | 1,950 |  |
| GAAP operating income (loss) | $ | 273 |  |  | $ | (210) |  |  | $ | (472) |  |  | $ | (533) |  |  | $ | (635) |  |
| Gross profit adjustments | 11 |  |  | (22) |  |  | 12 |  |  | 2 |  |  | 39 |  |
| Operating expense adjustments | 96 |  |  | 141 |  |  | 156 |  |  | 377 |  |  | 480 |  |
| Non-GAAP operating income (loss) | $ | 380 |  |  | $ | (91) |  |  | $ | (304) |  |  | $ | (154) |  |  | $ | (116) |  |
| GAAP interest and other expense, net | $ | (95) |  |  | $ | (49) |  |  | $ | (56) |  |  | $ | (230) |  |  | $ | (181) |  |
| Other | 3 |  |  | (64) |  |  | (6) |  |  | (61) |  |  | (7) |  |
| Non-GAAP interest and other expense, net | $ | (92) |  |  | $ | (113) |  |  | $ | (62) |  |  | $ | (291) |  |  | $ | (188) |  |
| GAAP income tax expense | $ | 43 |  |  | $ | 28 |  |  | $ | 43 |  |  | $ | 74 |  |  | $ | 159 |  |
| Income tax adjustments | 8 |  |  | (3) |  |  | 17 |  |  | 27 |  |  | 21 |  |
| Non-GAAP income tax expense | $ | 51 |  |  | $ | 25 |  |  | $ | 60 |  |  | $ | 101 |  |  | $ | 180 |  |

[0000106040-24-000020:8k_2_02:67]
WESTERN DIGITAL CORPORATION

[0000106040-24-000020:8k_2_02:68]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-24-000020:8k_2_02:69]
(in millions, except per share amounts; unaudited)

[0000106040-24-000020:8k_2_02:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | December 29,2023 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| GAAP net income (loss) | $ | 135 |  |  | $ | (287) |  |  | $ | (571) |  |  | $ | (837) |  |  | $ | (975) |  |
| Stock-based compensation expense | 77 |  |  | 72 |  |  | 74 |  |  | 226 |  |  | 246 |  |
| Business separation costs | 23 |  |  | 36 |  |  | — |  |  | 59 |  |  | — |  |
| Employee termination, asset impairment and other | 8 |  |  | 24 |  |  | 40 |  |  | 89 |  |  | 140 |  |
| Strategic review | — |  |  | 20 |  |  | 15 |  |  | 37 |  |  | 15 |  |
| Amortization of acquired intangible assets | 1 |  |  | 1 |  |  | 39 |  |  | 2 |  |  | 117 |  |
| Recovery from contamination incident | (1) |  |  | (36) |  |  | — |  |  | (37) |  |  | — |  |
| Other | 2 |  |  | (62) |  |  | (6) |  |  | (58) |  |  | (6) |  |
| Income tax adjustments | (8) |  |  | 3 |  |  | (17) |  |  | (27) |  |  | (21) |  |
| Non-GAAP net income (loss) | 237 |  |  | (229) |  |  | (426) |  |  | (546) |  |  | (484) |  |
| Less: amount allocated to preferred shareholders | 27 |  |  | 14 |  |  | 9 |  |  | 44 |  |  | 9 |  |
| Non-GAAP diluted net income (loss) attributable to common shareholders | $ | 210 |  |  | $ | (243) |  |  | $ | (435) |  |  | $ | (590) |  |  | $ | (493) |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 0.34 |  |  | $ | (0.93) |  |  | $ | (1.82) |  |  | $ | (2.72) |  |  | $ | (3.09) |  |
| Non-GAAP | $ | 0.63 |  |  | $ | (0.75) |  |  | $ | (1.36) |  |  | $ | (1.82) |  |  | $ | (1.55) |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 335 |  |  | 325 |  |  | 319 |  |  | 324 |  |  | 318 |  |
| Non-GAAP | 335 |  |  | 325 |  |  | 319 |  |  | 324 |  |  | 318 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 58 |  |  | $ | (92) |  |  | $ | (381) |  |  | $ | (660) |  |  | $ | (340) |  |
| Purchases of property, plant and equipment, net | (95) |  |  | (150) |  |  | (110) |  |  | (176) |  |  | (688) |  |
| Activity related to Flash Ventures, net | 128 |  |  | 66 |  |  | (36) |  |  | 207 |  |  | 46 |  |
| Free cash flow | $ | 91 |  |  | $ | (176) |  |  | $ | (527) |  |  | $ | (629) |  |  | $ | (982) |  |

[0000106040-24-000020:8k_2_02:71]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth Non-GAAP gross profit; Non-GAAP gross margin; Non-GAAP operating expenses; Non-GAAP operating income and loss; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income and loss; Non-GAAP diluted income and loss per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense, business separation costs, employee termination, asset impairment, and other, expenses related to our strategic review, amortization of acquired intangible assets, recovery from contamination incident, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-24-000020:8k_2_02:72]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-24-000020:8k_2_02:73]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company’s control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0000106040-24-000020:8k_2_02:74]
Business separation cost. The company incurred expenses associated with the separation of its HDD and Flash business units to create two independent, public companies. The Company believes these charges do not reflect the company's operating results and that they are not indicative of the underlying performance of its business.

[0000106040-24-000020:8k_2_02:75]
Employee termination, asset impairment, and other. From time-to-time, in order to realign the company’s operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. In addition, the Company has taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-24-000020:8k_2_02:76]
Strategic review. The company incurred expenses associated with its review of strategic alternatives that resulted in the planned separation of its HDD and Flash business units to create two independent, public companies. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-24-000020:8k_2_02:77]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company’s acquisitions and any related impairment charges.

[0000106040-24-000020:8k_2_02:78]
Recovery from contamination incident. In February 2022, a contamination of certain materials used in the company's manufacturing process occurred and affected production operations at the flash-based memory manufacturing facilities in Yokkaichi and Kitakami, Japan, which are operated through the company's joint business ventures with Kioxia Corporation (collectively, "Flash Ventures"). The contamination resulted in scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs which were expensed as incurred. During the quarters ended December 29, 2023, and March 29, 2024, the company received a partial recovery of these losses from other parties. The contamination charges and the related recovery are inconsistent in amount and frequency, and the company believes they are not part of the ongoing production operation of its business.

[0000106040-24-000020:8k_2_02:79]
Other adjustments. From time-to-time, the company sells or impairs investments or other assets which are not considered necessary to its business operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-24-000020:8k_2_02:80]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments for the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-24-000020:8k_2_02:81]
Additionally, free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company’s business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-24-000020:8k_2_02:82]
___________________

[0000106040-24-000020:8k_2_02:83]
Contacts:

[0000106040-24-000020:8k_2_02:84]
Western Digital Corp.

[0000106040-24-000020:8k_2_02:85]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Media Relations |
| 949.672.9655 |  | 408.801.0021 |
| peter.andrew@wdc.com |  | WD.Mediainquiries@wdc.com |
| investor@wdc.com |  |  |
