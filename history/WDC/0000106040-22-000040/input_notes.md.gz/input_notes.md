# WDC notes — 0000106040-22-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-22-000040:notes:1]
[same as prior period, unchanged from 0000106040-22-000018:notes:1]

[0000106040-22-000040:notes:2]
[same as prior period, unchanged from 0000106040-22-000018:notes:2]

[0000106040-22-000040:notes:3]
[same as prior period, unchanged from 0000106040-22-000018:notes:3]

[0000106040-22-000040:notes:4]
[same as prior period, unchanged from 0000106040-22-000018:notes:4]

[0000106040-22-000040:notes:5]
[same as prior period, unchanged from 0000106040-22-000018:notes:5]

[0000106040-22-000040:notes:6]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activities can resume.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-22-000040:notes:7]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-22-000040:notes:8]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted this ASU on July 3, 2021, which is the beginning of fiscal 2022, and its adoption did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-22-000040:notes:9]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-22-000040:notes:10]
In August 2020, the FASB issued ASU No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. For instruments that do not have a component mandatorily settled in cash, the change will likely result in a higher amount of share dilution in the calculation of earnings per share. The Company expects to adopt this ASU in the first quarter of fiscal 2023, and is currently assessing the impact of adoption.

[0000106040-22-000040:notes:11]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of fiscal 2023. Early adoption is permitted. The Company is currently assessing the impact and timing of adoption of this ASU.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-22-000040:notes:12]
Segment Information
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products (“Flash”) and hard disk drives (“HDD”). To align with the new operating model and business structure, the Company made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, the Company’s management finalized its assessment of the Company’s operating segments and concluded that the Company now has two reportable segments: Flash and HDD.

[0000106040-22-000040:notes:13]
[same as prior period, unchanged from 0000106040-22-000018:notes:13]

[0000106040-22-000040:notes:14]
[same as prior period, unchanged from 0000106040-22-000018:notes:14]

[0000106040-22-000040:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 2,243 |  |  | $ | 2,175 |  |  | $ | 7,353 |  |  | $ | 6,287 |  |
| HDD | 2,138 |  |  | 1,962 |  |  | 6,912 |  |  | 5,715 |  |
| Total net revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 798 |  |  | $ | 653 |  |  | $ | 2,665 |  |  | $ | 1,752 |  |
| HDD | 592 |  |  | 491 |  |  | 2,061 |  |  | 1,462 |  |
| Total gross profit for segments | 1,390 |  |  | 1,144 |  |  | 4,726 |  |  | 3,214 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Contamination related charges | (203) |  |  | — |  |  | (203) |  |  | — |  |
| Stock-based compensation expense | (13) |  |  | (14) |  |  | (36) |  |  | (41) |  |
| Amortization of acquired intangible assets | — |  |  | (39) |  |  | (65) |  |  | (293) |  |
| Recoveries from a power outage incident | 7 |  |  | — |  |  | 7 |  |  | 75 |  |
| Total unallocated corporate items | (209) |  |  | (53) |  |  | (297) |  |  | (259) |  |
| Consolidated gross profit | $ | 1,181 |  |  | $ | 1,091 |  |  | $ | 4,429 |  |  | $ | 2,955 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 35.6 | % |  | 30.0 | % |  | 36.2 | % |  | 27.9 | % |
| HDD | 27.7 | % |  | 25.0 | % |  | 29.8 | % |  | 25.6 | % |
| Consolidated gross margin | 27.0 | % |  | 26.4 | % |  | 31.0 | % |  | 24.6 | % |

[0000106040-22-000040:notes:16]
[same as prior period, unchanged from 0000106040-22-000018:notes:16]

[0000106040-22-000040:notes:17]
The Company’s broad portfolio of technology and products address multiple end markets. In the fiscal first quarter of 2022, the Company refined the end markets it reports to be Cloud, Client and Consumer. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both flash and hard drive products. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-22-000040:notes:18]
[same as prior period, unchanged from 0000106040-22-000018:notes:18]

[0000106040-22-000040:notes:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,774 |  |  | $ | 1,423 |  |  | $ | 5,919 |  |  | $ | 3,728 |  |  |  |
| Client | 1,732 |  |  | 1,767 |  |  | 5,439 |  |  | 5,386 |  |  |  |
| Consumer | 875 |  |  | 947 |  |  | 2,907 |  |  | 2,888 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Asia | $ | 2,400 |  |  | $ | 2,215 |  |  | $ | 7,685 |  |  | $ | 6,702 |  |  |  |
| Americas | 1,377 |  |  | 1,009 |  |  | 4,398 |  |  | 3,033 |  |  |  |
| Europe, Middle East and Africa | 604 |  |  | 913 |  |  | 2,182 |  |  | 2,267 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |

[0000106040-22-000040:notes:20]
The Company’s top 10 customers accounted for 44% and 43% of its net revenue for the three and nine months ended April 1, 2022, respectively, and 42% and 40% of its net revenue for the three and nine months ended April 2, 2021, respectively. For the three and nine months ended April 1, 2022 and April 2, 2021, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-22-000040:notes:21]
[same as prior period, unchanged from 0000106040-22-000018:notes:21]

[0000106040-22-000040:notes:22]
In connection with the Company’s determination of its reportable segments, effective July 3, 2021, the Company allocated its goodwill between its segments based on the estimated relative fair values of the business units. In addition, management performed a goodwill impairment assessment for each segment and concluded there were no impairment indicators as of both the beginning and end of the nine months ended April 1, 2022. The following table provides a summary of goodwill activity for the period:

[0000106040-22-000040:notes:23]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at July 3, 2021 | $ | 5,738 |  |  | $ | 4,328 |  |  | $ | 10,066 |  |
| Foreign currency translation adjustment | (3) |  |  | (2) |  |  | (5) |  |
| Balance at April 1, 2022 | $ | 5,735 |  |  | $ | 4,326 |  |  | $ | 10,061 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-22-000040:notes:24]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 1, 2022 or July 2, 2021.

[0000106040-22-000040:notes:25]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 1, 2022 and July 2, 2021 as well as the related amortization for the three and nine months ended April 1, 2022 and April 2, 2021 were not material.

[0000106040-22-000040:notes:26]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 1, 2022 and July 2, 2021, contract liabilities were not material.

[0000106040-22-000040:notes:27]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 1, 2022 was $42 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $10 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $2 million in fiscal 2024 and thereafter.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-22-000040:notes:28]
[same as prior period, unchanged from 0000106040-22-000018:notes:28]

[0000106040-22-000040:notes:29]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the nine months ended April 1, 2022 and April 2, 2021, the Company sold trade accounts receivable and received cash proceeds of $100 million and $233 million, respectively. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of April 1, 2022 and July 2, 2021, the amount of factored receivables that remained outstanding was $100 million and $0, respectively.

[0000106040-22-000040:notes:30]
[same as prior period, unchanged from 0000106040-22-000018:notes:30]

[0000106040-22-000040:notes:31]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,662 |  |  | $ | 1,623 |  |
| Work-in-process | 1,028 |  |  | 1,088 |  |
| Finished goods | 971 |  |  | 905 |  |
| Total inventories | $ | 3,661 |  |  | $ | 3,616 |  |

[0000106040-22-000040:notes:32]
[same as prior period, unchanged from 0000106040-22-000018:notes:32]

[0000106040-22-000040:notes:33]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 272 |  |  | $ | 278 |  |
| Buildings and improvements | 1,898 |  |  | 1,854 |  |
| Machinery and equipment | 8,438 |  |  | 7,860 |  |
| Computer equipment and software | 479 |  |  | 440 |  |
| Furniture and fixtures | 54 |  |  | 51 |  |
| Construction-in-process | 566 |  |  | 476 |  |
| Property, plant and equipment, gross | 11,707 |  |  | 10,959 |  |
| Accumulated depreciation | (8,219) |  |  | (7,771) |  |
| Property, plant and equipment, net | $ | 3,488 |  |  | $ | 3,188 |  |

[0000106040-22-000040:notes:34]
[same as prior period, unchanged from 0000106040-22-000018:notes:34]

[0000106040-22-000040:notes:35]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,495 |  |  | $ | 5,508 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,323) |  |  | (5,146) |  |
| Intangible assets, net | $ | 252 |  |  | $ | 442 |  |

[0000106040-22-000040:notes:36]
[same as prior period, unchanged from 0000106040-22-000018:notes:36]

[0000106040-22-000040:notes:37]
[same as prior period, unchanged from 0000106040-22-000018:notes:37]

[0000106040-22-000040:notes:38]
[same as prior period, unchanged from 0000106040-22-000018:notes:38]

[0000106040-22-000040:notes:39]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 351 |  |  | $ | 366 |  |  | $ | 363 |  |  | $ | 408 |  |  |  |
| Charges to operations | 35 |  |  | 27 |  |  | 111 |  |  | 86 |  |  |  |
| Utilization | (20) |  |  | (27) |  |  | (71) |  |  | (82) |  |  |  |
| Changes in estimate related to pre-existing warranties | (11) |  |  | (9) |  |  | (48) |  |  | (55) |  |  |  |
| Warranty accrual, end of period | $ | 355 |  |  | $ | 357 |  |  | $ | 355 |  |  | $ | 357 |  |  |  |

[0000106040-22-000040:notes:40]
[same as prior period, unchanged from 0000106040-22-000018:notes:40]

[0000106040-22-000040:notes:41]
|  | April 1,2022 |  | July 2,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 167 |  |  | $ | 175 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 188 |  |  | 188 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 355 |  |  | $ | 363 |  |  |  |  |  |  |  |

[0000106040-22-000040:notes:42]
[same as prior period, unchanged from 0000106040-22-000018:notes:42]

[0000106040-22-000040:notes:43]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 547 |  |  | $ | 684 |  |
| Payables related to unrecognized tax benefits | 996 |  |  | 750 |  |
| Other non-current liabilities | 688 |  |  | 633 |  |
| Total other liabilities | $ | 2,231 |  |  | $ | 2,067 |  |

[0000106040-22-000040:notes:44]
[same as prior period, unchanged from 0000106040-22-000018:notes:44]

[0000106040-22-000040:notes:45]
[same as prior period, unchanged from 0000106040-22-000018:notes:45]

[0000106040-22-000040:notes:46]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 2, 2021 | $ | (35) |  |  | $ | (38) |  |  |  |  |  |  | $ | (124) |  |  | $ | (197) |  |
| Other comprehensive income (loss) before reclassifications | 2 |  |  | (123) |  |  |  |  |  |  | (172) |  |  | (293) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | 121 |  |  | 121 |  |
| Income tax benefit related to items of other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | 12 |  |  | 12 |  |
| Net current-period other comprehensive income (loss) | 2 |  |  | (123) |  |  |  |  |  |  | (39) |  |  | (160) |  |
| Balance at April 1, 2022 | $ | (33) |  |  | $ | (161) |  |  |  |  |  |  | $ | (163) |  |  | $ | (357) |  |

[0000106040-22-000040:notes:47]
During the three and nine months ended April 1, 2022, the amounts reclassified out of AOCI were losses related to foreign exchange contracts and interest rate swap contracts. Losses reclassified out of AOCI related to foreign exchange contracts were $14 million and $83 million, for the three and nine months ended April 1, 2022, respectively, and were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. Losses reclassified out of AOCI related to interest rate swap contracts were $13 million and $38 million, for the three and nine months ended April 1, 2022, respectively, and were charged to Interest expense in the Condensed Consolidated Statements of Operations.
As of April 1, 2022, substantially all of existing net losses related to cash flow hedges recorded in AOCI are expected to be reclassified to earnings within the next twelve months. In addition, as of April 1, 2022, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-22-000040:notes:48]
[same as prior period, unchanged from 0000106040-22-000018:notes:48]

[0000106040-22-000040:notes:49]
[same as prior period, unchanged from 0000106040-22-000018:notes:49]

[0000106040-22-000040:notes:50]
[same as prior period, unchanged from 0000106040-22-000018:notes:50]

[0000106040-22-000040:notes:51]
[same as prior period, unchanged from 0000106040-22-000018:notes:51]

[0000106040-22-000040:notes:52]
[same as prior period, unchanged from 0000106040-22-000018:notes:52]

[0000106040-22-000040:notes:53]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of April 1, 2022 and July 2, 2021, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-22-000040:notes:54]
|  | April 1, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 53 |  |  | $ | — |  |  | $ | — |  |  | $ | 53 |  |
| Foreign exchange contracts | — |  |  | 31 |  |  | — |  |  | 31 |  |
| Total assets at fair value | $ | 53 |  |  | $ | 31 |  |  | $ | — |  |  | $ | 84 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 188 |  |  | $ | — |  |  | $ | 188 |  |
| Interest rate swap contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 204 |  |  | $ | — |  |  | $ | 204 |  |

[0000106040-22-000040:notes:55]
[same as prior period, unchanged from 0000106040-22-000018:notes:55]

[0000106040-22-000040:notes:56]
During the periods presented, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-22-000040:notes:57]
[same as prior period, unchanged from 0000106040-22-000018:notes:57]

[0000106040-22-000040:notes:58]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of fiscal 2022 and the fourth quarter of fiscal 2021, respectively.

[0000106040-22-000040:notes:59]
|  | April 1, 2022 |  | July 2, 2021 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | — |  |  | $ | 4,327 |  |  | $ | 4,346 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | — |  |  | 1,093 |  |  | 1,094 |  |
| 1.50% convertible notes due 2024 | 1,040 |  |  | 1,063 |  |  | 1,017 |  |  | 1,173 |  |
| 4.75% senior unsecured notes due 2026 | 2,290 |  |  | 2,342 |  |  | 2,288 |  |  | 2,556 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,843 |  |  | 2,802 |  |  | — |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 495 |  |  | 457 |  |  | — |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 494 |  |  | 445 |  |  | — |  |  | — |  |
| Total | $ | 7,162 |  |  | $ | 7,109 |  |  | $ | 8,725 |  |  | $ | 9,169 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-22-000040:notes:60]
Derivative Instruments and Hedging Activities
As of April 1, 2022, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments through February 2023, on a portion of its term loans.

[0000106040-22-000040:notes:61]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and nine months ended April 1, 2022 and April 2, 2021, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-22-000040:notes:62]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCI. For more information regarding cash flow hedges, see Part I, Item 1, Note 5. Supplemental Information - Accumulated other comprehensive income (loss), of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000040:notes:63]
[same as prior period, unchanged from 0000106040-22-000018:notes:63]

[0000106040-22-000040:notes:64]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of April 1, 2022 and July 2, 2021, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-22-000040:notes:65]
Debt
Debt consisted of the following as of April 1, 2022 and July 2, 2021:

[0000106040-22-000040:notes:66]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,850 |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,250 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (88) |  |  | (100) |  |
| Subtotal | 7,162 |  |  | 8,725 |  |
| Less current portion of long-term debt | (75) |  |  | (251) |  |
| Long-term debt | $ | 7,087 |  |  | $ | 8,474 |  |

[0000106040-22-000040:notes:67]
In October 2021, the Company voluntarily prepaid the remaining principal balance of its Term Loan B-4 in accordance with its terms.

[0000106040-22-000040:notes:68]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates.

[0000106040-22-000040:notes:69]
During the six months ended December 31, 2021, the Company made scheduled principal payments of $126 million and voluntary prepayments of  $1.21 billion on the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.00 billion. Payments were made using proceeds from the issuance of the 2029 Notes and the 2032 Notes and available cash on hand. On January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.00 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace its previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace its previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement are the senior unsecured obligations of the Company and do not benefit from any collateral or subsidiary guarantees.

[0000106040-22-000040:notes:70]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 amortizes in quarterly installments of $19 million for each of the first four quarters beginning the quarter ending July 1, 2022 through the quarter ending March 31, 2023; $38 million per quarter thereafter; and the remaining balance payable January 7, 2027.

[0000106040-22-000040:notes:71]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

[0000106040-22-000040:notes:72]
Issuance costs and discounts are amortized to interest expense over their respective terms, and as of April 1, 2022, unamortized issuance costs and discounts were $5 million for the 2029 Notes, $6 million for the 2032 Notes, and $7 million for the Term Loan A-2.
In accordance with the Loan Agreement, the Company is required to comply with a leverage ratio financial covenant. As of April 1, 2022, the Company was in compliance with this financial covenant.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-22-000040:notes:73]
[same as prior period, unchanged from 0000106040-22-000018:notes:74]

[0000106040-22-000040:notes:74]
[same as prior period, unchanged from 0000106040-22-000018:notes:75]

[0000106040-22-000040:notes:75]
[same as prior period, unchanged from 0000106040-22-000018:notes:76]

[0000106040-22-000040:notes:76]
|  | April 1,2022 |  | July 2,2021 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 339 |  |  | $ | 359 |  |  |  |
| Fair value of plan assets at end of period | 210 |  |  | 227 |  |  |  |
| Unfunded status | $ | 129 |  |  | $ | 132 |  |  |  |

[0000106040-22-000040:notes:77]
[same as prior period, unchanged from 0000106040-22-000018:notes:78]

[0000106040-22-000040:notes:78]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 128 |  |  | 131 |  |
| Net amount recognized | $ | 129 |  |  | $ | 132 |  |

[0000106040-22-000040:notes:79]
Net periodic benefit costs were not material for the three and nine months ended April 1, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-22-000040:notes:80]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-22-000040:notes:81]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-22-000040:notes:82]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 1, 2022 and July 2, 2021:

[0000106040-22-000040:notes:83]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 51 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 130 |  |  | 213 |  |
| Notes receivable, Flash Forward | 666 |  |  | 561 |  |
| Investment in Flash Partners | 182 |  |  | 199 |  |
| Investment in Flash Alliance | 266 |  |  | 293 |  |
| Investment in Flash Forward | 122 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,417 |  |  | $ | 1,586 |  |

[0000106040-22-000040:notes:84]
During the three and nine months ended April 1, 2022 and during the three and nine months ended April 2, 2021, the Company made net payments to Flash Ventures of $1.1 billion and $3.4 billion, and $1.1 billion and $3.3 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-22-000040:notes:85]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-22-000040:notes:86]
As of April 1, 2022 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $396 million and $398 million, respectively.

[0000106040-22-000040:notes:87]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 1, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-22-000040:notes:88]
|  | April 1,2022 |
|  | (in millions) |
| Notes receivable | $ | 847 |  |
| Equity investments | 570 |  |
| Operating lease guarantees | 1,897 |  |
| Inventory and prepayments | 983 |  |
| Maximum estimable loss exposure | $ | 4,297 |  |

[0000106040-22-000040:notes:89]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-22-000040:notes:90]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments of $482 million as follows: $142 million in fiscal year 2022, $314 million in fiscal year 2023 and $26 million in fiscal year 2024, to be credited against future wafer charges.

[0000106040-22-000040:notes:91]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company recovered $7 million related to this incident from insurance carriers. During the three and nine months ended April 2, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from insurance carriers. Recoveries related to the incident were recorded in Cost of revenue.

[0000106040-22-000040:notes:92]
In February 2022, contamination of certain material used in manufacturing processes occurred at both the Yokkaichi and Kitakami, Japan fabrication facilities, resulting in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company incurred charges of $203 million related to this contamination incident that were recorded in Cost of revenue, which primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs. The Company is evaluating potential options for recovery.

[0000106040-22-000040:notes:93]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-22-000040:notes:94]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-22-000040:notes:95]
Off-Balance Sheet Liabilities

[0000106040-22-000040:notes:96]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-22-000040:notes:97]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022.

[0000106040-22-000040:notes:98]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 223 |  |  | $ | 1,897 |  |

[0000106040-22-000040:notes:99]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 1, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022:

[0000106040-22-000040:notes:100]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2022 |  | $ | 150 |  |  | $ | — |  |  | $ | 150 |  |
| 2023 |  | 516 |  |  | 59 |  |  | 575 |  |
| 2024 |  | 369 |  |  | 106 |  |  | 475 |  |
| 2025 |  | 181 |  |  | 97 |  |  | 278 |  |
| 2026 |  | 153 |  |  | 146 |  |  | 299 |  |
| Thereafter |  | 27 |  |  | 93 |  |  | 120 |  |
| Total guarantee obligations |  | $ | 1,396 |  |  | $ | 501 |  |  | $ | 1,897 |  |

[0000106040-22-000040:notes:101]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 1, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-22-000040:notes:102]
Unis Venture

[0000106040-22-000040:notes:103]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 2, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for April 1, 2022 and July 2, 2021, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-22-000040:notes:104]
[same as prior period, unchanged from 0000106040-22-000018:notes:102]

[0000106040-22-000040:notes:105]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of April 1, 2022:

[0000106040-22-000040:notes:106]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | ($ in millions) |  |  |  |  |  |  |  |  |
| Remaining three months of 2022 | $ | 14 |  |  |  |  |  |  |  |  |  |
| 2023 | 48 |  |  |  |  |  |  |  |  |  |
| 2024 | 48 |  |  |  |  |  |  |  |  |  |
| 2025 | 44 |  |  |  |  |  |  |  |  |  |
| 2026 | 44 |  |  |  |  |  |  |  |  |  |
| Thereafter | 188 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 386 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | 55 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 331 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 41 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 290 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 313 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.4 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.4 | % |  |  |  |  |  |  |  |  |

[0000106040-22-000040:notes:107]
[same as prior period, unchanged from 0000106040-22-000018:notes:105]

[0000106040-22-000040:notes:108]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
|  | (in millions) |
| Cost of operating leases | $ | 15 |  |  | $ | 12 |  |  | $ | 42 |  |  | $ | 37 |  |
| Cash paid for operating leases | 13 |  |  | 12 |  |  | 37 |  |  | 38 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 9 |  |  | 1 |  |  | 132 |  |  | 28 |  |

[0000106040-22-000040:notes:109]
[same as prior period, unchanged from 0000106040-22-000018:notes:107]

[0000106040-22-000040:notes:110]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of April 1, 2022, the Company had the following minimum long-term commitments:

[0000106040-22-000040:notes:111]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining three months of 2022 |  | $ | 162 |  |
| 2023 |  | 560 |  |
| 2024 |  | 309 |  |
| 2025 |  | 148 |  |
| 2026 |  | 20 |  |
| Thereafter |  | 170 |  |
| Total |  | $ | 1,369 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-22-000040:notes:112]
[same as prior period, unchanged from 0000106040-22-000018:notes:110]

[0000106040-22-000040:notes:113]
The following tables present the Company’s stock-based compensation for equity-settled awards by type (i.e., restricted stock units (“RSUs”), restricted stock unit awards with performance conditions or market conditions (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”)) and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-22-000040:notes:114]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 75 |  |  | $ | 73 |  |  | $ | 220 |  |  | $ | 212 |  |  |  |
| ESPP | 11 |  |  | 10 |  |  | 29 |  |  | 27 |  |  |  |
| Total | $ | 86 |  |  | $ | 83 |  |  | $ | 249 |  |  | $ | 239 |  |  |  |

[0000106040-22-000040:notes:115]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 14 |  |  | $ | 36 |  |  | $ | 41 |  |  |  |
| Research and development | 43 |  |  | 41 |  |  | 126 |  |  | 120 |  |  |  |
| Selling, general and administrative | 30 |  |  | 28 |  |  | 87 |  |  | 78 |  |  |  |
| Subtotal | 86 |  |  | 83 |  |  | 249 |  |  | 239 |  |  |  |
| Tax benefit | (9) |  |  | (11) |  |  | (37) |  |  | (35) |  |  |  |
| Total | $ | 77 |  |  | $ | 72 |  |  | $ | 212 |  |  | $ | 204 |  |  |  |

[0000106040-22-000040:notes:116]
[same as prior period, unchanged from 0000106040-22-000018:notes:114]

[0000106040-22-000040:notes:117]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of April 1, 2022:

[0000106040-22-000040:notes:118]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 589 |  |  | 2.3 |
| ESPP | 70 |  |  | 1.5 |
| Total unamortized compensation cost | $ | 659 |  |  |  |

[0000106040-22-000040:notes:119]
[same as prior period, unchanged from 0000106040-22-000018:notes:117]

[0000106040-22-000040:notes:120]
[same as prior period, unchanged from 0000106040-22-000018:notes:118]

[0000106040-22-000040:notes:121]
[same as prior period, unchanged from 0000106040-22-000018:notes:119]

[0000106040-22-000040:notes:122]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at April 1, 2022:

[0000106040-22-000040:notes:123]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 2, 2021 | 1.5 |  |  | $ | 72.84 |  |  | 1.2 |  | $ | 15 |  |
| Exercised | (0.2) |  |  | 43.52 |  |  |  |  | 3 |  |
| Canceled or expired | (0.4) |  |  | 98.24 |  |  |  |  |  |
| Options outstanding at April 1, 2022 | 0.9 |  |  | 65.97 |  |  | 0.77 |  | 2 |  |

[0000106040-22-000040:notes:124]
[same as prior period, unchanged from 0000106040-22-000018:notes:122]

[0000106040-22-000040:notes:125]
[same as prior period, unchanged from 0000106040-22-000018:notes:123]

[0000106040-22-000040:notes:126]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | $ | 50.12 |  |  |  |
| Granted | 5.5 |  |  | 62.53 |  |  |  |
| Vested | (4.9) |  |  | 53.93 |  |  | $ | 301 |  |
| Forfeited | (1.7) |  |  | 51.77 |  |  |  |
| RSUs and PSUs outstanding at April 1, 2022 | 15.0 |  |  | 53.33 |  |  |  |

[0000106040-22-000040:notes:127]
[same as prior period, unchanged from 0000106040-22-000018:notes:125]

[0000106040-22-000040:notes:128]
Stock Repurchase Program
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the nine months ended April 1, 2022 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of April 1, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-22-000040:notes:129]
[same as prior period, unchanged from 0000106040-22-000018:notes:127]

[0000106040-22-000040:notes:130]
[same as prior period, unchanged from 0000106040-22-000018:notes:128]

[0000106040-22-000040:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
|  | ($ in millions) |
| Income before taxes | $ | 262 |  |  | $ | 249 |  |  | $ | 1,612 |  |  | $ | 331 |  |
| Income tax expense | 237 |  |  | 52 |  |  | 413 |  |  | 132 |  |
| Effective tax rate | 90 | % |  | 21 | % |  | 26 | % |  | 40 | % |

[0000106040-22-000040:notes:132]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 1, 2022 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and nine months ended April 1, 2022 includes the discrete effect of a net increase to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of ongoing discussions with various taxing authorities of $194 million and $219 million, respectively.

[0000106040-22-000040:notes:133]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 2, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the three and nine months ended April 2, 2021 includes discrete effects for increases to unrecognized tax benefits of $35 million as a result of ongoing discussions with various taxing authorities that are offset in part by a release of certain unrecognized tax benefits of $22 million as a result of business realignment activities. The effective tax rate for the nine months ended April 2, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes paid by the Company.

[0000106040-22-000040:notes:134]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2008 through 2015. The Company filed petitions with the U.S. Tax Court covering fiscal years 2008 through 2012, for which it had received statutory notices of deficiency, while fiscal years 2013 through 2015 remain in the jurisdiction of the IRS’s Examination function. The IRS has filed various Amendments to Answer with the U.S. Tax Court which, together with the notices of proposed adjustments, would result in additional federal income tax liabilities totaling approximately $1.6 billion and penalties totaling $449 million with respect to fiscal years 2008 through 2015. During the three months ended April 1, 2022, in preparation for trial in May 2022, new information became available which required the Company to re-measure its unrecognized tax benefits for which an additional tax expense of $224 million, including interest, was recorded.

[0000106040-22-000040:notes:135]
Uncertain Tax Positions

[0000106040-22-000040:notes:136]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Condensed Consolidated Balance Sheets.

[0000106040-22-000040:notes:137]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended April 1, 2022 (in millions):

[0000106040-22-000040:notes:138]
| Accrual balance at July 2, 2021 | $ | 748 |  |
| Gross increases related to current year tax positions | 7 |  |
| Gross increases related to prior year tax positions | 216 |  |
| Gross decreases related to prior year tax positions | (57) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (5) |  |
| Accrual balance at April 1, 2022 | $ | 907 |  |

[0000106040-22-000040:notes:139]
As of April 1, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $907 million. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of April 1, 2022 was $231 million. Of these amounts, approximately $996 million could result in potential cash payments.

[0000106040-22-000040:notes:140]
Subsequent to April 1, 2022, the Company and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. As a result, the trial originally scheduled to take place in May 2022 has been cancelled. The tentative basis for resolution would incrementally increase the liability for unrecognized tax benefits, including interest and offsetting tax benefits, by approximately $80 million to $100 million. Including this incremental increase, the Company expects to pay tax and interest totaling approximately $600 million to $700 million within the next twelve months, which the Company expects to be partially offset by reductions to its mandatory deemed repatriation tax obligations aggregating to approximately $100 million in later years. The Company is not able to provide a reasonable estimate of the timing of future tax and interest payments related to the remaining unrecognized tax benefits.

[0000106040-22-000040:notes:141]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-22-000040:notes:142]
[same as prior period, unchanged from 0000106040-22-000018:notes:135]

[0000106040-22-000040:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
|  | (in millions, except per share data) |
| Net income | $ | 25 |  |  |  | $ | 197 |  |  | $ | 1,199 |  |  | $ | 199 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 313 |  |  |  | 306 |  |  | 312 |  |  | 305 |  |
| Employee stock options, RSUs, PSUs and ESPP | 3 |  |  |  | 7 |  |  | 4 |  |  | 3 |  |
| Basic and diluted | 316 |  |  |  | 313 |  |  | 316 |  |  | 308 |  |
| Income per common share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.08 |  |  |  | $ | 0.64 |  |  | $ | 3.84 |  |  | $ | 0.65 |  |
| Diluted | $ | 0.08 |  |  |  | $ | 0.63 |  |  | $ | 3.79 |  |  | $ | 0.65 |  |
| Anti-dilutive potential common shares excluded | 5 |  |  |  | 1 |  |  | 4 |  |  | 7 |  |

[0000106040-22-000040:notes:144]
[same as prior period, unchanged from 0000106040-22-000018:notes:137]


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-22-000040:notes:145]
[same as prior period, unchanged from 0000106040-22-000018:notes:138]

[0000106040-22-000040:notes:146]
[same as prior period, unchanged from 0000106040-22-000018:notes:139]

[0000106040-22-000040:notes:147]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 4 |  |  | $ | 2 |  |  | $ | 22 |  |  | $ | 27 |  |  |  |
| Asset impairments and losses (gains) on disposal of assets | — |  |  | (70) |  |  | 2 |  |  | (70) |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 4 |  |  | $ | (68) |  |  | $ | 24 |  |  | $ | (43) |  |  |  |

[0000106040-22-000040:notes:148]
The following table presents an analysis of the components of these activities against the reserve during the nine months ended April 1, 2022:

[0000106040-22-000040:notes:149]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 2, 2021 | $ | 2 |  |  |  |  |  |
| Charges | 22 |  |  |  |  |  |
| Cash payments | (20) |  |  |  |  |  |
| Accrual balance at April 1, 2022 | $ | 4 |  |  |  |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-22-000040:notes:150]
Legal Proceedings
Tax

[0000106040-22-000040:notes:151]
For disclosures regarding statutory notices of deficiency issued by the IRS in June 2018 and December 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-22-000040:notes:152]
Other Matters

[0000106040-22-000040:notes:153]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
