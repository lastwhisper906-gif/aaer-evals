# WDC MD&A — 0000106040-22-000040


## mdna

[0000106040-22-000040:mdna:1]
[same as prior period, unchanged from 0000106040-22-000018:mdna:1]

[0000106040-22-000040:mdna:2]
[same as prior period, unchanged from 0000106040-22-000018:mdna:2]

[0000106040-22-000040:mdna:3]
[same as prior period, unchanged from 0000106040-22-000018:mdna:3]

[0000106040-22-000040:mdna:4]
We are on a mission to unlock the potential of data by harnessing the possibility to use it. With both Flash and HDD franchises, underpinned by advancements in memory technologies, we create breakthrough innovations and powerful data storage solutions that enable the world to actualize its aspirations.

[0000106040-22-000040:mdna:5]
[same as prior period, unchanged from 0000106040-22-000018:mdna:5]

[0000106040-22-000040:mdna:6]
[same as prior period, unchanged from 0000106040-22-000018:mdna:6]

[0000106040-22-000040:mdna:7]
Joint Venture Contamination Incident

[0000106040-22-000040:mdna:8]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in our flash wafer availability. During the three and nine months ended April 1, 2022, we incurred charges of $203 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs. We are evaluating potential options for recovery.

[0000106040-22-000040:mdna:9]
Tax Resolution

[0000106040-22-000040:mdna:10]
As previously disclosed, we have received statutory notices of deficiency and notices of proposed adjustments from the IRS with respect to fiscal years 2008 through 2015. During the three months ended April 1, 2022, new information became available which required us to re-measure our unrecognized tax benefits for this IRS matter. Subsequent to April 1, 2022, we and the IRS tentatively reached a basis for resolving this matter. Additional information is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 13, Income Tax Expense, of the Notes to the Condensed Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity--Unrecognized Tax Benefits” section below.

[0000106040-22-000040:mdna:11]
[same as prior period, unchanged from 0000106040-22-000018:mdna:7]

[0000106040-22-000040:mdna:12]
In fiscal 2022, we continued to execute on our commitment to reduce our overall debt levels and Fitch Ratings, Inc. raised our Company credit rating to investment grade in December 2021. We fully repaid our Term Loan B-4 in October 2021 and shortly thereafter initiated a series of transactions to further reduce our debt levels and better stagger the maturities of our debt. In December 2021, we issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”). We used the proceeds from these notes offerings and available cash to voluntarily repay $1.21 billion of our Term Loan A-1 and reduce its principal amount to $3.0 billion as of December 31, 2021. In January 2022, we amended and restated our existing loan agreement to provide for, among other things: (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 to replace our previously existing Term Loan A-1; (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 to replace our previously existing $2.25 billion revolving credit facility; and (iii) additional covenant flexibility and other modifications. Upon completion of these transactions, over 85% of the principal

[0000106040-22-000040:mdna:13]
amount of our debt is now due in 2026 or later. We believe this new debt structure gives us greater financial stability and flexibility to manage our business over the longer term.

[0000106040-22-000040:mdna:14]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-22-000040:mdna:15]
[same as prior period, unchanged from 0000106040-22-000018:mdna:18]

[0000106040-22-000040:mdna:16]
In January 2022, we entered into additional agreements with Kioxia regarding Flash Ventures’ investment in a new wafer fabrication facility, known as “Y7”, located in Yokkaichi, Japan. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from Y7 is expected to begin in the first half of fiscal year 2023. Our share of the initial commitment for Y7 is expected to result in equipment investments and start-up costs totaling approximately $140 million, to be incurred primarily through the second half of fiscal year 2022. We also agreed to pay, among other items, future building depreciation payments of $482 million as follows: $142 million in fiscal year 2022, $314 million in fiscal year 2023 and $26 million in fiscal year 2024, to be credited against future wafer charges.

[0000106040-22-000040:mdna:17]
[same as prior period, unchanged from 0000106040-22-000018:mdna:10]

[0000106040-22-000040:mdna:18]
Historically, our company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is our Chief Operating Decision Maker, announced a decision to reorganize our business by forming two separate product business units: flash-based products (“Flash”) and hard disk drives (“HDD”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. To align with the new operating model and business structure, we made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of our operating segments and concluded that we now have two reportable segments: Flash and HDD.

[0000106040-22-000040:mdna:19]
Our broad portfolio of technology and products address multiple end markets. In the fiscal first quarter of 2022, we refined the end markets we report to be “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which we believe we are uniquely positioned to address as the only provider of both flash and hard drive products. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-22-000040:mdna:20]
[same as prior period, unchanged from 0000106040-22-000018:mdna:13]

[0000106040-22-000040:mdna:21]
[same as prior period, unchanged from 0000106040-22-000018:mdna:14]

[0000106040-22-000040:mdna:22]
As the ongoing COVID-19 pandemic has evolved, we have implemented and maintained more thorough sanitation practices as outlined by health organizations and supported vaccination efforts. We continually monitor and update our practices based on recommendations from health organizations to ensure the continued safety of our employees and business partners as we continue to return to site. In addition, the responses to COVID-19 taken by others in the supply chain have increased the costs of their services which have in turn impacted our operations. We incurred incremental charges primarily related to logistics, absorption and other factory-related costs of approximately $59 million and $185 million, and $33 million and $94 million during the three and nine months ended April 1, 2022 and April 2, 2021, respectively, which were recorded in Cost of revenue.

[0000106040-22-000040:mdna:23]
The technology hardware and semiconductor industries continued to face supply chain disruptions and component shortages during the quarter that negatively impacted both our customers’ ability to ship products, and our ability to build products. In order to meet our end customers’ demand, we are incurring increased component costs in addition to COVID-related expenses, which we expect to weigh primarily on our hard drive gross margins through the first half of calendar year 2022. While these supply disruptions may continue for the near term, we ultimately expect that they will be transitory as demand for our products remained solid during the COVID-19 pandemic, with work-from-home, distance learning, and at home entertainment driving demand for cloud environments, new devices, and retail products.

[0000106040-22-000040:mdna:24]
The COVID-19 environment remains dynamic with outbreaks in various geographies including China, where we experienced a temporary lockdown. We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “The COVID-19 pandemic could negatively affect our business” and “We are dependent on a limited number of qualified suppliers who provide critical services, materials or components, and a disruption in our supply chain could negatively affect our business” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021 for more information regarding the risks we face as a result of the COVID-19 pandemic and supply chain disruptions.

[0000106040-22-000040:mdna:25]
Russia Sanctions

[0000106040-22-000040:mdna:26]
In February 2022, the U.S. and other countries imposed sanctions on Russia. In accordance with these sanctions, we have ceased shipments to distributors for customers located in Russia. Our revenue from distributors for customers in Russia have not been significant. We have no material assets or operations in Russia.

[0000106040-22-000040:mdna:27]
[same as prior period, unchanged from 0000106040-22-000018:mdna:20]

[0000106040-22-000040:mdna:28]
Third Quarter and Nine Month Overview

[0000106040-22-000040:mdna:29]
[same as prior period, unchanged from 0000106040-22-000018:mdna:22]

[0000106040-22-000040:mdna:30]
|  | Three Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 4,381 |  |  | 100.0 | % |  | $ | 4,137 |  |  | 100.0 | % |  | $ | 244 |  |  | 6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,200 |  |  | 73.0 |  |  | 3,046 |  |  | 73.6 |  |  | 154 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,181 |  |  | 27.0 |  |  | 1,091 |  |  | 26.4 |  |  | 90 |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 572 |  |  | 13.1 |  |  | 555 |  |  | 13.4 |  |  | 17 |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 281 |  |  | 6.4 |  |  | 287 |  |  | 6.9 |  |  | (6) |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 4 |  |  | 0.1 |  |  | (68) |  |  | (1.6) |  |  | 72 |  |  | (106) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 857 |  |  | 19.6 |  |  | 774 |  |  | 18.7 |  |  | 83 |  |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 324 |  |  | 7.4 |  |  | 317 |  |  | 7.7 |  |  | 7 |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 1 |  |  | — |  |  | 2 |  |  | — |  |  | (1) |  |  | (50) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (75) |  |  | (1.7) |  |  | (81) |  |  | (2.0) |  |  | 6 |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (loss), net | 12 |  |  | 0.3 |  |  | 11 |  |  | 0.3 |  |  | 1 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (62) |  |  | (1.4) |  |  | (68) |  |  | (1.6) |  |  | 6 |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 262 |  |  | 6.0 |  |  | 249 |  |  | 6.0 |  |  | 13 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 237 |  |  | 5.4 |  |  | 52 |  |  | 1.3 |  |  | 185 |  |  | 356 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 25 |  |  | 0.6 |  |  | $ | 197 |  |  | 4.8 |  |  | (172) |  |  | (87) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-22-000040:mdna:31]
[same as prior period, unchanged from 0000106040-22-000018:mdna:24]

[0000106040-22-000040:mdna:32]
|  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 14,265 |  |  | 100.0 | % |  | $ | 12,002 |  |  | 100.0 | % |  | $ | 2,263 |  |  | 19 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 9,836 |  |  | 69.0 |  |  | 9,047 |  |  | 75.4 |  |  | 789 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 4,429 |  |  | 31.0 |  |  | 2,955 |  |  | 24.6 |  |  | 1,474 |  |  | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,725 |  |  | 12.1 |  |  | 1,645 |  |  | 13.7 |  |  | 80 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 851 |  |  | 6.0 |  |  | 808 |  |  | 6.7 |  |  | 43 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 24 |  |  | 0.2 |  |  | (43) |  |  | (0.4) |  |  | 67 |  |  | (156) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 2,600 |  |  | 18.2 |  |  | 2,410 |  |  | 20.1 |  |  | 190 |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 1,829 |  |  | 12.8 |  |  | 545 |  |  | 4.5 |  |  | 1,284 |  |  | 236 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 4 |  |  | — |  |  | 6 |  |  | — |  |  | (2) |  |  | (33) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (229) |  |  | (1.6) |  |  | (246) |  |  | (2.0) |  |  | 17 |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 8 |  |  | 0.1 |  |  | 26 |  |  | 0.2 |  |  | (18) |  |  | (69) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (217) |  |  | (1.5) |  |  | (214) |  |  | (1.8) |  |  | (3) |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 1,612 |  |  | 11.3 |  |  | 331 |  |  | 2.8 |  |  | 1,281 |  |  | 387 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 413 |  |  | 2.9 |  |  | 132 |  |  | 1.1 |  |  | 281 |  |  | 213 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 1,199 |  |  | 8.4 |  |  | $ | 199 |  |  | 1.7 |  |  | 1,000 |  |  | 503 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-22-000040:mdna:33]
[same as prior period, unchanged from 0000106040-22-000018:mdna:27]

[0000106040-22-000040:mdna:34]
[same as prior period, unchanged from 0000106040-22-000018:mdna:28]

[0000106040-22-000040:mdna:35]
[same as prior period, unchanged from 0000106040-22-000018:mdna:29]

[0000106040-22-000040:mdna:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
|  | ($ in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 2,243 |  |  | $ | 2,175 |  |  | $ | 7,353 |  |  | $ | 6,287 |  |
| HDD | 2,138 |  |  | 1,962 |  |  | 6,912 |  |  | 5,715 |  |
| Total net revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 798 |  |  | $ | 653 |  |  | $ | 2,665 |  |  | $ | 1,752 |  |
| HDD | 592 |  |  | 491 |  |  | 2,061 |  |  | 1,462 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Contamination related charges | (203) |  |  | — |  |  | (203) |  |  | — |  |
| Amortization of acquired intangible assets | — |  |  | (39) |  |  | (65) |  |  | (293) |  |
| Stock-based compensation expense | (13) |  |  | (14) |  |  | (36) |  |  | (41) |  |
| Recoveries from a power outage incident | 7 |  |  | — |  |  | 7 |  |  | 75 |  |
| Total unallocated corporate items | (209) |  |  | (53) |  |  | (297) |  |  | (259) |  |
| Consolidated gross profit | $ | 1,181 |  |  | $ | 1,091 |  |  | $ | 4,429 |  |  | $ | 2,955 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 35.6 | % |  | 30.0 | % |  | 36.2 | % |  | 27.9 | % |
| HDD | 27.7 | % |  | 25.0 | % |  | 29.8 | % |  | 25.6 | % |
| Consolidated gross margin | 27.0 | % |  | 26.4 | % |  | 31.0 | % |  | 24.6 | % |

[0000106040-22-000040:mdna:37]
Our disaggregated revenue information is as follows:

[0000106040-22-000040:mdna:38]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,774 |  |  | $ | 1,423 |  |  | $ | 5,919 |  |  | $ | 3,728 |  |  |  |  |  |  |  |
| Client | 1,732 |  |  | 1,767 |  |  | 5,439 |  |  | 5,386 |  |  |  |  |  |  |  |
| Consumer | 875 |  |  | 947 |  |  | 2,907 |  |  | 2,888 |  |  |  |  |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia | $ | 2,400 |  |  | $ | 2,215 |  |  | $ | 7,685 |  |  | $ | 6,702 |  |  |  |  |  |  |  |
| Americas | 1,377 |  |  | 1,009 |  |  | 4,398 |  |  | 3,033 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 604 |  |  | 913 |  |  | 2,182 |  |  | 2,267 |  |  |  |  |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |  |  |  |  |

[0000106040-22-000040:mdna:39]
[same as prior period, unchanged from 0000106040-22-000018:mdna:33]

[0000106040-22-000040:mdna:40]
[same as prior period, unchanged from 0000106040-22-000018:mdna:34]

[0000106040-22-000040:mdna:41]
The increases in consolidated net revenue for the three and nine months ended April 1, 2022 from the comparable periods in the prior year reflect increases in exabytes of Flash and HDD sold as further discussed below. The revenue increases driven by exabyte growth were partially offset by declines in the average price per gigabyte of storage for both Flash and HDD as product mix shifted.

[0000106040-22-000040:mdna:42]
Despite the disruption to our Flash production from the contamination event at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan, Flash revenue increased 3% for the three months ended April 1, 2022 from the comparable period in the prior year, primarily driven by a 9% increase in exabytes sold, partially offset by a decline in the average price per gigabyte. The higher exabytes sold primarily reflected the ramp of our latest BiCS5 flash solutions. Higher volume was also driven by strong demand in gaming along with a growing brand recognition of WD_Black based products in our Consumer market. Flash revenue increased 17% for the nine months ended April 1, 2022 from the comparable period in the prior year, primarily driven by a 24% increase in exabytes sold, partially offset by a decline in the average price per gigabyte. The increase in exabytes for the nine-month period was largely attributable to the same factors noted above for the three-month period.

[0000106040-22-000040:mdna:43]
HDD revenue increased 9% for the three months ended April 1, 2022 from the comparable period in the prior year, primarily driven by a 20% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The increase in exabytes sold was due to continued demand for our latest generation energy assisted drives among our public and private cloud customers. The strong demand in Cloud was partly offset by a decline in HDD exabytes sold in our Client and Consumer end markets due to continued pressure in the commercial channel related to component issues impacting our customers’ ability to ship product and greater component sourcing constraints within our own operations, and customers transitioning to client SSD. HDD revenue increased 21% for the nine months ended April 1, 2022 from the comparable period in the prior year, primarily driven by a 33% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The increase in exabytes for the nine-month period was largely attributable to the same factors noted above for the three-month period.

[0000106040-22-000040:mdna:44]
The increase in Cloud revenue for the three months ended April 1, 2022 from the comparable period in the prior year was led by demand for HDD capacity enterprise drives, including growth in our 18-terabyte capacity drives and ramp of our 20-terabyte capacity drives. The growth was partially offset by lower revenues from enterprise SSDs primarily caused by the supply impact as a result of the contamination event mentioned above and lower revenues from smart video hard drives. In Client, the slight decrease in revenues for the three months ended April 1, 2022 from the comparable period in the prior year reflected declines in both client SSD and client HDD revenue, as a result of the supply chain disruptions noted previously, partially offset by the ramp of 5G phones. In Consumer, the slight decrease in revenues for the three months ended April 1, 2022 from the comparable period in the prior year reflected declines in both Flash and HDD as a result of short term demand weakness outside the U.S. tied to geopolitical events in Europe, as well as COVID-related lockdowns in China.

[0000106040-22-000040:mdna:45]
The increase in Cloud revenue for the nine months ended April 1, 2022 from the comparable period in the prior year primarily reflects the same drivers noted above for the three-month period. Client revenue was relatively flat for the nine months ended April 1, 2022 compared to the prior year, with growth in mobile (led by 5G growth), gaming, automotive, IOT, and industrial applications in the first quarter of fiscal 2022, partially offset by declines in both client SSD and client HDD revenue, as a result of the supply chain disruptions noted previously. Consumer revenue was relatively flat for the nine months ended April 1, 2022 from the comparable period in the prior year with growth in gaming along with a growing brand recognition of WD_Black tempered by the slightly weaker demand in the third quarter noted above.

[0000106040-22-000040:mdna:46]
The changes in net revenue by geography for both the three and nine months ended April 1, 2022 from the comparable periods in the prior year reflect routine variations in the mix of business.

[0000106040-22-000040:mdna:47]
Our top 10 customers accounted for 44% and 43% of our net revenue for the three and nine months ended April 1, 2022, respectively, compared to 42% and 40% of our net revenue for the three and nine months ended April 2, 2021, respectively. For each of the three and nine months ended April 1, 2022 and April 2, 2021, no single customer accounted for 10% or more of our net revenue.

[0000106040-22-000040:mdna:48]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 17% and 18% of gross revenues for both the three and nine months ended April 1, 2022, and 18% and 19% of gross revenues for the three and nine months ended April 2, 2021, respectively. Adjustments due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies,

[0000106040-22-000040:mdna:49]
[same as prior period, unchanged from 0000106040-22-000018:mdna:43]

[0000106040-22-000040:mdna:50]
seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-22-000040:mdna:51]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. We have largely completed qualification of BiCS5 based product for client and consumer end markets. Additionally, qualification of OptiNAND-based hard drives progress as planned across multiple cloud and OEM customers and we continue to see an increase in customer interest in adopting shingled magnetic recording (“SMR”) technology. Combining OptiNAND with our SMR leadership positions us to drive business results in our capacity enterprise business. For our next generation 3D-flash, we continued commercial shipment of consumer flash devices based on our 162-layer BiCs6. We expect these developments to contribute to further revenue growth when supply chain disruptions begin to abate.

[0000106040-22-000040:mdna:52]
[same as prior period, unchanged from 0000106040-22-000018:mdna:46]

[0000106040-22-000040:mdna:53]
Consolidated gross profit increased by $90 million for the three months ended April 1, 2022 from the comparable period in the prior year, which reflects the increase in revenue in both Flash and HDD and reduced costs as we ramped production on newer products, partially offset by charges of $203 million related to the contamination event in the Flash Ventures’ fabrication facilities. Consolidated gross margin increased 0.6 percentage points for the three months ended April 1, 2022 from the comparable period in the prior year, which reflects cost reductions as we ramped production on newer products and a shift in product mix to higher-margin flash drives, partially offset by the impact of the contamination related charges which represented approximately 4.6 percentage points of gross margin. Flash and HDD gross margin increased by 5.6 and 2.7 percentage points year over year, respectively, reflecting cost reductions as we ramped production on newer products.

[0000106040-22-000040:mdna:54]
Consolidated gross profit increased by $1.47 billion for the nine months ended April 1, 2022 from the comparable period in the prior year, which reflects the increase in revenue in both Flash and HDD, as well as a $228 million decrease in charges in the current period related to amortization expense on acquired intangible assets, some of which became fully amortized, partially offset by the contamination related charges of $203 million noted above. Consolidated gross margin increased 6.4 percentage points for the nine months ended April 1, 2022 from the comparable period in the prior year, which reflects higher gross margin in both Flash and HDD as a result of cost reductions as we ramped production on newer products and a shift in product mix to higher-margin flash drives, as well as the lower charges for amortization of acquired intangible assets noted above. Flash and HDD gross margin increased by 8.3 and 4.2 percentage points year over year, respectively, reflecting cost reductions as we ramped production on newer products.

[0000106040-22-000040:mdna:55]
[same as prior period, unchanged from 0000106040-22-000018:mdna:49]

[0000106040-22-000040:mdna:56]
Research and development (“R&D”) expense increased $17 million and $80 million for the three and nine months ended April 1, 2022, respectively, from the comparable period in the prior year. The primary increase was due to increased headcount.

[0000106040-22-000040:mdna:57]
Selling, general and administrative (“SG&A”) expense decreased $6 million for the three months ended April 1, 2022 from the comparable period in the prior year, primarily reflecting slightly lower variable compensation expense. SG&A expense increased $43 million for the nine months ended April 1, 2022 from the comparable period in the prior year and primarily reflected higher outside professional services.

[0000106040-22-000040:mdna:58]
Employee termination, asset impairment and other charges for both the three and nine months ended April 1, 2022 reflect minor actions taken in each period, while the prior year periods primarily reflected gains related to the disposition of assets associated with actions taken in earlier periods. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment, and Other Charges of the Notes to Condensed  Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000040:mdna:59]
[same as prior period, unchanged from 0000106040-22-000018:mdna:53]

[0000106040-22-000040:mdna:60]
Total interest and other expense, net for the three months ended April 1, 2022 slightly decreased compared to the prior year, mainly reflecting lower interest expense primarily resulting from the pay-down of principal on our debt. Total interest and other expense, net for the nine months ended April 1, 2022 increased slightly compared to the prior year, mainly reflecting unfavorable exchange rates in the current period mostly offset by lower interest expense resulting from the pay-down of principal on our debt.

[0000106040-22-000040:mdna:61]
43

[0000106040-22-000040:mdna:62]
[same as prior period, unchanged from 0000106040-22-000018:mdna:55]

[0000106040-22-000040:mdna:63]
[same as prior period, unchanged from 0000106040-22-000018:mdna:56]

[0000106040-22-000040:mdna:64]
[same as prior period, unchanged from 0000106040-22-000018:mdna:57]

[0000106040-22-000040:mdna:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
|  | ($ in millions) |
| Income before taxes | $ | 262 |  |  | $ | 249 |  |  | $ | 1,612 |  |  | $ | 331 |  |
| Income tax expense | 237 |  |  | 52 |  |  | 413 |  |  | 132 |  |
| Effective tax rate | 90 | % |  | 21 | % |  | 26 | % |  | 40 | % |

[0000106040-22-000040:mdna:66]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 1, 2022 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and nine months ended April 1, 2022 includes the discrete effect of a net increase to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of ongoing discussions with various taxing authorities of $194 million and $219 million, respectively.

[0000106040-22-000040:mdna:67]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 2, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the three and nine months ended April 2, 2021 includes discrete effects for increases to the liability for unrecognized tax benefits of $35 million as a result of ongoing discussions with various taxing authorities that are offset in part by a release of certain unrecognized tax benefits of $22 million as a result of business realignment activities. The effective tax rate for the nine months ended April 2, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes that we paid.

[0000106040-22-000040:mdna:68]
Subsequent to April 1, 2022, we and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015. See the “--Short- and Long-Term Liquidity--Unrecognized Tax Benefits” section below for additional information related to this matter.

[0000106040-22-000040:mdna:69]
[same as prior period, unchanged from 0000106040-22-000018:mdna:61]

[0000106040-22-000040:mdna:70]
[same as prior period, unchanged from 0000106040-22-000018:mdna:62]

[0000106040-22-000040:mdna:71]
[same as prior period, unchanged from 0000106040-22-000018:mdna:63]

[0000106040-22-000040:mdna:72]
[same as prior period, unchanged from 0000106040-22-000018:mdna:64]

[0000106040-22-000040:mdna:73]
|  | Nine Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,585 |  |  | $ | 904 |  |  |  |
| Investing activities | (822) |  |  | (562) |  |  |  |
| Financing activities | (1,623) |  |  | (662) |  |  |  |
| Effect of exchange rate changes on cash | (5) |  |  | 6 |  |  |  |
| Net decrease in cash and cash equivalents | $ | (865) |  |  | $ | (314) |  |  |  |

[0000106040-22-000040:mdna:74]
We and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015. We expect to pay tax and interest totaling approximately $600 million to $700 million within the next twelve months. See Part I, Item 1, Note 13, Income Tax Expense for further details. We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to satisfy this obligation and meet our working capital, debt and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-22-000040:mdna:75]
As further explained under Key Developments- Financing Activities above, we have taken recent actions to reduce our overall debt levels and extend the average maturity. Following these actions, we have reduced the outstanding principal amount of our debt by approximately $1.58 billion since July 2, 2021 and over 85% of the principal amount is now due in 2026 or later. We also have an existing shelf registration statement (the “Shelf Registration Statement”) filed with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We used the Shelf Registration Statement to complete our offering of $1.0 billion aggregate principal amount of senior unsecured notes in December 2021, and we may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-22-000040:mdna:76]
During fiscal 2022, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $2.9 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we now expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.3 billion during fiscal 2022. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-22-000040:mdna:77]
A total of $1.96 billion and $1.97 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of April 1, 2022 and April 2, 2021, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-22-000040:mdna:78]
[same as prior period, unchanged from 0000106040-22-000018:mdna:71]

[0000106040-22-000040:mdna:79]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $674 million for the nine months ended April 1, 2022, as compared to $393 million for the nine months ended April 2, 2021. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-22-000040:mdna:80]
|  | Three Months Ended |  |  |
|  | April 1,2022 |  | April 2,2021 |  |  |  |  |
| Days sales outstanding | 49 |  |  | 42 |  |  |  |  |  |
| Days in inventory | 104 |  |  | 110 |  |  |  |  |  |
| Days payables outstanding | (63) |  |  | (66) |  |  |  |  |  |
| Cash conversion cycle | 90 |  |  | 86 |  |  |  |  |  |

[0000106040-22-000040:mdna:81]
[same as prior period, unchanged from 0000106040-22-000018:mdna:74]

[0000106040-22-000040:mdna:82]
For the three months ended April 1, 2022, DSO increased by 7 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO and DPO decreased by 6 days and 3 days, respectively, from the comparable period in the prior year primarily reflecting improved supply chain management in the HDD business, as well as routine variations in the timing of purchases and payments during the period.

[0000106040-22-000040:mdna:83]
[same as prior period, unchanged from 0000106040-22-000018:mdna:76]

[0000106040-22-000040:mdna:84]
Net cash used in investing activities for the nine months ended April 1, 2022 primarily consisted of $842 million in capital expenditures partially offset by a $23 million net decrease in notes receivable issuances to Flash Ventures. Net cash used in investing activities for the nine months ended April 2, 2021 primarily consisted of $820 million in capital expenditures, partially offset by a $129 million net decrease in notes receivable issuances to Flash Ventures.

[0000106040-22-000040:mdna:85]
[same as prior period, unchanged from 0000106040-22-000018:mdna:78]

[0000106040-22-000040:mdna:86]
[same as prior period, unchanged from 0000106040-22-000018:mdna:79]

[0000106040-22-000040:mdna:87]
During the nine months ended April 1, 2022, net cash used in financing activities primarily consisted of $5.58 billion for repayment of debt, as well as $85 million for taxes paid on vested stock awards under employee stock plans offset by net proceeds of  $4.0 billion from the issuance of new debt, which was used to fund a portion of the debt repayment, and $62 million from the issuance of stock under employee stock plans. Net cash used in financing activities for the nine months ended months ended April 2, 2021 primarily consisted of $673 million for the repayment of our debt, which included a $300 million voluntary prepayment on our Term Loan B-4.

[0000106040-22-000040:mdna:88]
[same as prior period, unchanged from 0000106040-22-000018:mdna:81]

[0000106040-22-000040:mdna:89]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000040:mdna:90]
[same as prior period, unchanged from 0000106040-22-000018:mdna:83]

[0000106040-22-000040:mdna:91]
[same as prior period, unchanged from 0000106040-22-000018:mdna:84]

[0000106040-22-000040:mdna:92]
[same as prior period, unchanged from 0000106040-22-000018:mdna:85]

[0000106040-22-000040:mdna:93]
The following is a summary of our known contractual cash obligations and commercial commitments as of April 1, 2022:

[0000106040-22-000040:mdna:94]
|  | Total |  | Remaining Three Months of 2022 |  | 2023-2024 |  | 2025-2026 |  | Beyond 2026 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,250 |  |  | $ | 19 |  |  | $ | 1,344 |  |  | $ | 2,600 |  |  | $ | 3,287 |  |
| Interest on debt | 1,009 |  |  | 25 |  |  | 448 |  |  | 377 |  |  | 159 |  |
| Flash Ventures related commitments(2) | 5,038 |  |  | 1,427 |  |  | 2,967 |  |  | 835 |  |  | (191) |  |
| Operating leases | 386 |  |  | 14 |  |  | 96 |  |  | 88 |  |  | 188 |  |
| Purchase obligations and other commitments | 4,013 |  |  | 1,823 |  |  | 1,852 |  |  | 168 |  |  | 170 |  |
| Mandatory Deemed Repatriation Tax | 791 |  |  | — |  |  | 277 |  |  | 514 |  |  | — |  |
| Total | $ | 18,487 |  |  | $ | 3,308 |  |  | $ | 6,984 |  |  | $ | 4,582 |  |  | $ | 3,613 |  |

[0000106040-22-000040:mdna:95]
[same as prior period, unchanged from 0000106040-22-000018:mdna:88]

[0000106040-22-000040:mdna:96]
[same as prior period, unchanged from 0000106040-22-000018:mdna:89]

[0000106040-22-000040:mdna:97]
[same as prior period, unchanged from 0000106040-22-000018:mdna:90]

[0000106040-22-000040:mdna:98]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-22-000040:mdna:99]
[same as prior period, unchanged from 0000106040-22-000018:mdna:92]

[0000106040-22-000040:mdna:100]
[same as prior period, unchanged from 0000106040-22-000018:mdna:93]

[0000106040-22-000040:mdna:101]
[same as prior period, unchanged from 0000106040-22-000018:mdna:94]

[0000106040-22-000040:mdna:102]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Current assets (excluding net intercompany receivable from non-guarantor subsidiaries) | $ | 2,067 |  |  | $ | 2,898 |  |
| Non-current assets | 1,882 |  |  | 1,903 |  |
| Net intercompany payable to non-guarantor subsidiaries | 1,001 |  |  | 463 |  |
| Current liabilities | 1,985 |  |  | 2,325 |  |
| Non-current liabilities | 8,538 |  |  | 9,726 |  |

[0000106040-22-000040:mdna:103]
[same as prior period, unchanged from 0000106040-22-000018:mdna:96]

[0000106040-22-000040:mdna:104]
|  | Nine Months Ended |  | Year Ended |
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Net sales | $ | 6,337 |  |  | $ | 12,378 |  |
| Gross profit | 1,683 |  |  | 1,861 |  |
| Operating income | 106 |  |  | 142 |  |
| Net income (loss) | (121) |  |  | 377 |  |
| Intercompany revenue | 1,855 |  |  | 5,190 |  |
| Net intercompany interest expense (income) | (22) |  |  | 23 |  |
| Intercompany dividends | 252 |  |  | 528 |  |

[0000106040-22-000040:mdna:105]
[same as prior period, unchanged from 0000106040-22-000018:mdna:98]

[0000106040-22-000040:mdna:106]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of April 1, 2022, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-22-000040:mdna:107]
[same as prior period, unchanged from 0000106040-22-000018:mdna:100]

[0000106040-22-000040:mdna:108]
[same as prior period, unchanged from 0000106040-22-000018:mdna:101]

[0000106040-22-000040:mdna:109]
[same as prior period, unchanged from 0000106040-22-000018:mdna:102]

[0000106040-22-000040:mdna:110]
[same as prior period, unchanged from 0000106040-22-000018:mdna:103]

[0000106040-22-000040:mdna:111]
[same as prior period, unchanged from 0000106040-22-000018:mdna:104]

[0000106040-22-000040:mdna:112]
|  |  | April 1,2022 |
| 2023 |  | $ | 106 |  |
| 2024 |  | 171 |  |
| 2025 |  | 228 |  |
| 2026 |  | 286 |  |
| Total |  | $ | 791 |  |

[0000106040-22-000040:mdna:113]
[same as prior period, unchanged from 0000106040-22-000018:mdna:106]

[0000106040-22-000040:mdna:114]
[same as prior period, unchanged from 0000106040-22-000018:mdna:107]

[0000106040-22-000040:mdna:115]
As of April 1, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $907 million. Interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of April 1, 2022 was $231 million. Of these amounts, approximately $996 million could result in potential cash payments.

[0000106040-22-000040:mdna:116]
Subsequent to April 1, 2022, we and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. As a result, the trial originally scheduled to take place in May 2022 has been cancelled. The tentative basis for resolution would incrementally increase the liability for unrecognized tax benefits, including interest and offsetting tax benefits, by approximately $80 million to $100 million. Including this incremental increase, we expect to pay tax and interest totaling approximately $600 million to $700 million within the next twelve months, which we expect to be partially offset by reductions to our mandatory deemed repatriation tax obligations aggregating to approximately $100 million in later years. We are not able to provide a reasonable estimate of the timing of future tax and interest payments related to the remaining unrecognized tax benefits.

[0000106040-22-000040:mdna:117]
[same as prior period, unchanged from 0000106040-22-000018:mdna:109]

[0000106040-22-000040:mdna:118]
[same as prior period, unchanged from 0000106040-22-000018:mdna:110]

[0000106040-22-000040:mdna:119]
50

[0000106040-22-000040:mdna:120]
[same as prior period, unchanged from 0000106040-22-000018:mdna:111]

[0000106040-22-000040:mdna:121]
[same as prior period, unchanged from 0000106040-22-000018:mdna:112]

[0000106040-22-000040:mdna:122]
[same as prior period, unchanged from 0000106040-22-000018:mdna:113]

[0000106040-22-000040:mdna:123]
[same as prior period, unchanged from 0000106040-22-000018:mdna:114]

[0000106040-22-000040:mdna:124]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the nine months ended April 1, 2022 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of April 1, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-22-000040:mdna:125]
[same as prior period, unchanged from 0000106040-22-000018:mdna:116]

[0000106040-22-000040:mdna:126]
[same as prior period, unchanged from 0000106040-22-000018:mdna:117]

[0000106040-22-000040:mdna:127]
[same as prior period, unchanged from 0000106040-22-000018:mdna:118]

[0000106040-22-000040:mdna:128]
[same as prior period, unchanged from 0000106040-22-000018:mdna:119]

[0000106040-22-000040:mdna:129]
[same as prior period, unchanged from 0000106040-22-000018:mdna:120]
