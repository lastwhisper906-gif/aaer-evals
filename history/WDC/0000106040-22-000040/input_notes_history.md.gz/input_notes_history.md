# WDC note change history — 0000106040-22-000018 → 0000106040-22-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 1, 2022 and July 2, 2021:
  (was, 2022-02-03, similarity 0.9572):
[0000106040-22-000018:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 31, 2021 and July 2, 2021:

- changed (2022-05-04):
[0000106040-22-000040:note_history:2]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 51 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 130 |  |  | 213 |  |
| Notes receivable, Flash Forward | 666 |  |  | 561 |  |
| Investment in Flash Partners | 182 |  |  | 199 |  |
| Investment in Flash Alliance | 266 |  |  | 293 |  |
| Investment in Flash Forward | 122 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,417 |  |  | $ | 1,586 |  |
  (was, 2022-02-03, similarity 0.9848):
[0000106040-22-000018:note_history:2]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 92 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 161 |  |  | 213 |  |
| Notes receivable, Flash Forward | 694 |  |  | 561 |  |
| Investment in Flash Partners | 194 |  |  | 199 |  |
| Investment in Flash Alliance | 284 |  |  | 293 |  |
| Investment in Flash Forward | 128 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,553 |  |  | $ | 1,586 |  |

- changed (2022-05-04):
[0000106040-22-000040:note_history:3]
During the three and nine months ended April 1, 2022 and during the three and nine months ended April 2, 2021, the Company made net payments to Flash Ventures of $1.1 billion and $3.4 billion, and $1.1 billion and $3.3 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2022-02-03, similarity 0.8307):
[0000106040-22-000018:note_history:3]
During the three and six months ended December 31, 2021 and during the three and six months ended January 1, 2021, the Company made net payments to Flash Ventures of $1.11 billion and $2.30 billion, and $1.21 billion and $2.19 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2022-05-04):
[0000106040-22-000040:note_history:4]
As of April 1, 2022 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $396 million and $398 million, respectively.
  (was, 2022-02-03, similarity 0.96):
[0000106040-22-000018:note_history:4]
As of December 31, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $389 million and $398 million, respectively.

- changed (2022-05-04):
[0000106040-22-000040:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 1, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2022-02-03, similarity 0.9851):
[0000106040-22-000018:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 31, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2022-05-04):
[0000106040-22-000040:note_history:6]
|  | April 1,2022 |
|  | (in millions) |
| Notes receivable | $ | 847 |  |
| Equity investments | 570 |  |
| Operating lease guarantees | 1,897 |  |
| Inventory and prepayments | 983 |  |
| Maximum estimable loss exposure | $ | 4,297 |  |
  (was, 2022-02-03, similarity 0.9696):
[0000106040-22-000018:note_history:6]
|  | December 31,2021 |
|  | (in millions) |
| Notes receivable | $ | 947 |  |
| Equity investments | 606 |  |
| Operating lease guarantees | 1,964 |  |
| Inventory and prepayments | 865 |  |
| Maximum estimable loss exposure | $ | 4,382 |  |

- added (2022-05-04):
[0000106040-22-000040:note_history:7]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments of $482 million as follows: $142 million in fiscal year 2022, $314 million in fiscal year 2023 and $26 million in fiscal year 2024, to be credited against future wafer charges.

- changed (2022-05-04):
[0000106040-22-000040:note_history:8]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company recovered $7 million related to this incident from insurance carriers. During the three and nine months ended April 2, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from insurance carriers. Recoveries related to the incident were recorded in Cost of revenue.
  (was, 2022-02-03, similarity 0.7256):
[0000106040-22-000018:note_history:8]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and six months ended January 1, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from its insurance carriers, which was recorded in Cost of revenue.

- added (2022-05-04):
[0000106040-22-000040:note_history:9]
In February 2022, contamination of certain material used in manufacturing processes occurred at both the Yokkaichi and Kitakami, Japan fabrication facilities, resulting in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company incurred charges of $203 million related to this contamination incident that were recorded in Cost of revenue, which primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs. The Company is evaluating potential options for recovery.

- changed (2022-05-04):
[0000106040-22-000040:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022.
  (was, 2022-02-03, similarity 0.9746):
[0000106040-22-000018:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021.

- changed (2022-05-04):
[0000106040-22-000040:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 1, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022:
  (was, 2022-02-03, similarity 0.9639):
[0000106040-22-000018:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 31, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021:

- changed (2022-05-04):
[0000106040-22-000040:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2022 |  | $ | 150 |  |  | $ | — |  |  | $ | 150 |  |
| 2023 |  | 516 |  |  | 59 |  |  | 575 |  |
| 2024 |  | 369 |  |  | 106 |  |  | 475 |  |
| 2025 |  | 181 |  |  | 97 |  |  | 278 |  |
| 2026 |  | 153 |  |  | 146 |  |  | 299 |  |
| Thereafter |  | 27 |  |  | 93 |  |  | 120 |  |
| Total guarantee obligations |  | $ | 1,396 |  |  | $ | 501 |  |  | $ | 1,897 |  |
  (was, 2022-02-03, similarity 0.9912):
[0000106040-22-000018:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2022 |  | $ | 304 |  |  | $ | — |  |  | $ | 304 |  |
| 2023 |  | 507 |  |  | 63 |  |  | 570 |  |
| 2024 |  | 353 |  |  | 113 |  |  | 466 |  |
| 2025 |  | 161 |  |  | 103 |  |  | 264 |  |
| 2026 |  | 124 |  |  | 156 |  |  | 280 |  |
| Thereafter |  | 15 |  |  | 65 |  |  | 80 |  |
| Total guarantee obligations |  | $ | 1,464 |  |  | $ | 500 |  |  | $ | 1,964 |  |

- changed (2022-05-04):
[0000106040-22-000040:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 1, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2022-02-03, similarity 0.8059):
[0000106040-22-000018:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 31, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2022-05-04):
[0000106040-22-000040:note_history:14]
Unis Venture

- changed (2022-05-04):
[0000106040-22-000040:note_history:15]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 2, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for April 1, 2022 and July 2, 2021, respectively.
  (was, 2022-02-03, similarity 0.9366):
[0000106040-22-000018:note_history:15]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended January 1, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 6% of Accounts receivable, net as of December 31, 2021 and July 2, 2021, respectively.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:16]
For disclosures regarding statutory notices of deficiency issued by the IRS in June 2018 and December 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.
  (was, 2022-02-03, similarity 0.7929):
[0000106040-22-000018:note_history:16]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2022-05-04):
[0000106040-22-000040:note_history:17]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended April 1, 2022 (in millions):

- added (2022-05-04):
[0000106040-22-000040:note_history:18]
| Accrual balance at July 2, 2021 | $ | 748 |  |
| Gross increases related to current year tax positions | 7 |  |
| Gross increases related to prior year tax positions | 216 |  |
| Gross decreases related to prior year tax positions | (57) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (5) |  |
| Accrual balance at April 1, 2022 | $ | 907 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:19]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activities can resume.
  (was, 2022-02-03, similarity 0.9976):
[0000106040-22-000018:note_history:19]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activity can resume.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:20]
Debt
Debt consisted of the following as of April 1, 2022 and July 2, 2021:
  (was, 2022-02-03, similarity 0.9185):
[0000106040-22-000018:note_history:20]
Debt
Debt consisted of the following as of December 31, 2021 and July 2, 2021:

- changed (2022-05-04):
[0000106040-22-000040:note_history:21]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,850 |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,250 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (88) |  |  | (100) |  |
| Subtotal | 7,162 |  |  | 8,725 |  |
| Less current portion of long-term debt | (75) |  |  | (251) |  |
| Long-term debt | $ | 7,087 |  |  | $ | 8,474 |  |
  (was, 2022-02-03, similarity 0.7028):
[0000106040-22-000018:note_history:21]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 3,000 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,400 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (92) |  |  | (100) |  |
| Subtotal | 7,308 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 7,057 |  |  | $ | 8,474 |  |

- added (2022-05-04):
[0000106040-22-000040:note_history:22]
In October 2021, the Company voluntarily prepaid the remaining principal balance of its Term Loan B-4 in accordance with its terms.

- changed (2022-05-04):
[0000106040-22-000040:note_history:23]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates.
  (was, 2022-02-03, similarity 0.9012):
[0000106040-22-000018:note_history:23]
In December 2021, the Company issued $500 million aggregate principal amount of  2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates. Issuance costs and discounts are amortized to interest expense over their respective terms and as of December 31, 2021, unamortized issuance costs and discounts were $5 million for the 2029 Notes and $6 million for the 2032 Notes.

- changed (2022-05-04):
[0000106040-22-000040:note_history:24]
During the six months ended December 31, 2021, the Company made scheduled principal payments of $126 million and voluntary prepayments of  $1.21 billion on the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.00 billion. Payments were made using proceeds from the issuance of the 2029 Notes and the 2032 Notes and available cash on hand. On January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.00 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace its previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace its previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement are the senior unsecured obligations of the Company and do not benefit from any collateral or subsidiary guarantees.
  (was, 2022-02-03, similarity 0.7782):
[0000106040-22-000018:note_history:24]
Subsequent to the end of the second quarter of fiscal 2022, on January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace our previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace our previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement will be the senior unsecured obligations of the Company and will not benefit from any collateral or subsidiary guarantees.

- changed (2022-05-04):
[0000106040-22-000040:note_history:25]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 amortizes in quarterly installments of $19 million for each of the first four quarters beginning the quarter ending July 1, 2022 through the quarter ending March 31, 2023; $38 million per quarter thereafter; and the remaining balance payable January 7, 2027.
  (was, 2022-02-03, similarity 0.8059):
[0000106040-22-000018:note_history:25]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from  0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 will amortize in equal quarterly installments of (i) 0.625% per quarter during the first through the fourth

- changed (2022-05-04):
[0000106040-22-000040:note_history:26]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.
  (was, 2022-02-03, similarity 0.9817):
[0000106040-22-000018:note_history:26]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company will also pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

- added (2022-05-04):
[0000106040-22-000040:note_history:27]
Issuance costs and discounts are amortized to interest expense over their respective terms, and as of April 1, 2022, unamortized issuance costs and discounts were $5 million for the 2029 Notes, $6 million for the 2032 Notes, and $7 million for the Term Loan A-2.
In accordance with the Loan Agreement, the Company is required to comply with a leverage ratio financial covenant. As of April 1, 2022, the Company was in compliance with this financial covenant.

- removed (2022-05-04):
[0000106040-22-000018:note_history:28]
During the six months ended December 31, 2021, the Company voluntarily paid $1.09 billion to prepay the remaining principal balance of its Term Loan B-4 in accordance with its terms. In addition, during the three months ended December 31, 2021, the Company repaid $1.27 billion of the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.0 billion using proceeds from the issuance of the 2029 Notes and the 2032 Notes and using cash on hand.

- removed (2022-05-04):
[0000106040-22-000018:note_history:29]
full fiscal quarters following the date of the Restatement Agreement (the “Restatement Effective Date”) and (ii) 1.25% per quarter for the fifth through the nineteenth full fiscal quarters following the Restatement Effective Date, with the remaining balance payable on the date that is five years after the Restatement Effective Date.

- removed (2022-05-04):
[0000106040-22-000018:note_history:30]
Prior to its restatement on January 7, 2022, the Loan Agreement required the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of December 31, 2021, the Company was in compliance with these financial covenants. Following its restatement on January 7, 2022, the covenants under the Loan Agreement were simplified and the interest coverage ratio requirement was removed.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:31]
Debt consisted of the following as of April 1, 2022 and July 2, 2021:
  (was, 2022-02-03, similarity 0.912):
[0000106040-22-000018:note_history:31]
Debt consisted of the following as of December 31, 2021 and July 2, 2021:

- changed (2022-05-04):
[0000106040-22-000040:note_history:32]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,850 |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,250 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (88) |  |  | (100) |  |
| Subtotal | 7,162 |  |  | 8,725 |  |
| Less current portion of long-term debt | (75) |  |  | (251) |  |
| Long-term debt | $ | 7,087 |  |  | $ | 8,474 |  |
  (was, 2022-02-03, similarity 0.7028):
[0000106040-22-000018:note_history:32]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 3,000 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,400 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (92) |  |  | (100) |  |
| Subtotal | 7,308 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 7,057 |  |  | $ | 8,474 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:33]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 1, 2022 and July 2, 2021:
  (was, 2022-02-03, similarity 0.9572):
[0000106040-22-000018:note_history:33]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 31, 2021 and July 2, 2021:

- changed (2022-05-04):
[0000106040-22-000040:note_history:34]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 51 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 130 |  |  | 213 |  |
| Notes receivable, Flash Forward | 666 |  |  | 561 |  |
| Investment in Flash Partners | 182 |  |  | 199 |  |
| Investment in Flash Alliance | 266 |  |  | 293 |  |
| Investment in Flash Forward | 122 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,417 |  |  | $ | 1,586 |  |
  (was, 2022-02-03, similarity 0.9848):
[0000106040-22-000018:note_history:34]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 92 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 161 |  |  | 213 |  |
| Notes receivable, Flash Forward | 694 |  |  | 561 |  |
| Investment in Flash Partners | 194 |  |  | 199 |  |
| Investment in Flash Alliance | 284 |  |  | 293 |  |
| Investment in Flash Forward | 128 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,553 |  |  | $ | 1,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,774 |  |  | $ | 1,423 |  |  | $ | 5,919 |  |  | $ | 3,728 |  |  |  |
| Client | 1,732 |  |  | 1,767 |  |  | 5,439 |  |  | 5,386 |  |  |  |
| Consumer | 875 |  |  | 947 |  |  | 2,907 |  |  | 2,888 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Asia | $ | 2,400 |  |  | $ | 2,215 |  |  | $ | 7,685 |  |  | $ | 6,702 |  |  |  |
| Americas | 1,377 |  |  | 1,009 |  |  | 4,398 |  |  | 3,033 |  |  |  |
| Europe, Middle East and Africa | 604 |  |  | 913 |  |  | 2,182 |  |  | 2,267 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |
  (was, 2022-02-03, similarity 0.808):
[0000106040-22-000018:note_history:35]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,920 |  |  | $ | 1,014 |  |  | $ | 4,145 |  |  | $ | 2,305 |  |  |  |
| Client | 1,854 |  |  | 1,869 |  |  | 3,707 |  |  | 3,619 |  |  |  |
| Consumer | 1,059 |  |  | 1,060 |  |  | 2,032 |  |  | 1,941 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,407 |  |  | $ | 945 |  |  | $ | 3,021 |  |  | $ | 2,024 |  |  |  |
| Europe, Middle East and Africa | 816 |  |  | 725 |  |  | 1,578 |  |  | 1,354 |  |  |  |
| Asia | 2,610 |  |  | 2,273 |  |  | 5,285 |  |  | 4,487 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000106040-22-000040:note_history:36]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 1, 2022 or July 2, 2021.
  (was, 2022-02-03, similarity 0.9773):
[0000106040-22-000018:note_history:36]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 31, 2021 or July 2, 2021.

- changed (2022-05-04):
[0000106040-22-000040:note_history:37]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 1, 2022 and July 2, 2021 as well as the related amortization for the three and nine months ended April 1, 2022 and April 2, 2021 were not material.
  (was, 2022-02-03, similarity 0.9566):
[0000106040-22-000018:note_history:37]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of December 31, 2021 and July 2, 2021 as well as the related amortization for the three and six months ended December 31, 2021 and January 1, 2021 were not material.

- changed (2022-05-04):
[0000106040-22-000040:note_history:38]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 1, 2022 and July 2, 2021, contract liabilities were not material.
  (was, 2022-02-03, similarity 0.9754):
[0000106040-22-000018:note_history:38]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 31, 2021 and July 2, 2021, contract liabilities were not material.

- changed (2022-05-04):
[0000106040-22-000040:note_history:39]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 1, 2022 was $42 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $10 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $2 million in fiscal 2024 and thereafter.
  (was, 2022-02-03, similarity 0.9932):
[0000106040-22-000018:note_history:39]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 31, 2021 was $51 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.
