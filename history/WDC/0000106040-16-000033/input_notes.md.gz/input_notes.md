# WDC notes — 0000106040-16-000033


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000106040-16-000033:notes:1]
Advertising Expense

[0000106040-16-000033:notes:2]
Advertising costs are expensed as incurred. Selling, general and administrative expenses of the Company included advertising costs of $60 million, $71 million and $60 million in 2016, 2015 and 2014, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-16-000033:notes:3]
The following tables summarize, by major type, the fair value and cost basis of the Company’s investments classified as available-for-sale:

[0000106040-16-000033:notes:4]
|  | July 1, 2016 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
|  | (in millions) |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| U.S. Government agency securities | 10 |  |  | — |  |  | 10 |  |
| Certificates of deposit | 202 |  |  | — |  |  | 202 |  |
| International government securities | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | 96 |  |  | 1 |  |  | 97 |  |
| Asset-backed securities | 22 |  |  | — |  |  | 22 |  |
| Municipal notes and bonds | 12 |  |  | — |  |  | 12 |  |
| Total | $ | 345 |  |  | $ | 1 |  |  | $ | 346 |  |

[0000106040-16-000033:notes:5]
|  | July 3, 2015 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
|  | (in millions) |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 287 |  |  | $ | — |  |  | $ | 287 |  |
| U.S. Government agency securities | 95 |  |  | — |  |  | 95 |  |
| Commercial paper | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000106040-16-000033:notes:6]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition and any borrowings undertaken to finance the acquisition had taken place at the beginning of the earliest period presented, nor does it intend to be a projection of future results:

[0000106040-16-000033:notes:7]
|  | 2016 |  | 2015 |
|  | (in millions, except per share amounts) |
| Revenue | $ | 17,846 |  |  | $ | 20,613 |  |
| Net income | 65 |  |  | 762 |  |
| Basic income per common share | $ | 0.23 |  |  | $ | 2.71 |  |
| Diluted income per common share | 0.23 |  |  | 2.65 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-16-000033:notes:8]
Acquisitions

[0000106040-16-000033:notes:9]
The consolidated financial statements include the results of operations of acquired companies commencing after their respective acquisition dates.

[0000106040-16-000033:notes:10]
Acquisition of SanDisk

[0000106040-16-000033:notes:11]
On May 12, 2016, WDT, a wholly-owned subsidiary of the Company, completed the acquisition of SanDisk, a global leader in NAND flash storage solutions. The Merger is primarily intended to deepen the Company’s expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000033:notes:12]
At the SanDisk Closing Date, each issued and outstanding share of SanDisk common stock, other than shares of SanDisk common stock held in the treasury of SanDisk, shares of SanDisk common stock owned by stockholders who had validly exercised their appraisal rights under Delaware law and shares of SanDisk common stock owned by Western Digital or any subsidiary of Western Digital, was converted into the right to receive $67.50 per share in cash; and 0.2387 shares of Western Digital common stock per share of SanDisk common stock, with cash paid in lieu of fractional shares.

[0000106040-16-000033:notes:13]
The aggregate purchase price of the SanDisk acquisition was $15.588 billion, consisting of $13.77 billion in cash funded with existing cash and cash from new debt, 49 million newly issued shares of the Company’s common stock with a fair value of $1.76 billion and $58 million related to the fair value of stock options and RSUs assumed. The fair value of the newly issued shares of the Company’s common stock was determined based on the closing market price of the Company’s shares of common stock on the date of the acquisition. The fair values of stock options assumed were estimated using a binomial option-pricing model.

[0000106040-16-000033:notes:14]
|  | May 12, 2016 |
|  | (in millions) |
| Cash consideration | $ | 13,766 |  |
| Equity consideration | 1,764 |  |
| Fair value of assumed equity attributed to pre-combination service | 58 |  |
| Total purchase price | $ | 15,588 |  |

[0000106040-16-000033:notes:15]
Assets Acquired and Liabilities Assumed at Fair Value

[0000106040-16-000033:notes:16]
The transaction has been accounted for using the acquisition method of accounting which requires that assets acquired and liabilities assumed be recognized at their fair values as of the acquisition date. The values assigned to the assets acquired and liabilities assumed are based on preliminary estimates of fair value available as of the date of this Annual Report on Form 10-K, and may be adjusted during the measurement period of up to 12 months from the date of acquisition as further information becomes available. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in adjustments to goodwill. As of July 1, 2016, the primary areas that are not yet finalized due to information that may become available subsequently and may result in changes in the values assigned to various assets and liabilities, include the fair values of acquired property, plant and equipment, intangible assets and related deferred tax liabilities as well as assumed tax assets and liabilities.

[0000106040-16-000033:notes:17]
The following table summarizes the preliminary fair values of the assets acquired and liabilities assumed at the SanDisk Closing Date:

[0000106040-16-000033:notes:18]
|  | May 12, 2016 |
|  | (in millions) |
| Cash and cash equivalents | $ | 3,931 |  |
| Marketable securities | 737 |  |
| Accounts receivables, net | 394 |  |
| Inventories | 1,069 |  |
| Other current assets | 787 |  |
| Property, plant and equipment | 917 |  |
| Notes receivable and investments in Flash Ventures | 1,012 |  |
| Intangible assets | 4,955 |  |
| Other non-current assets | 144 |  |
| Total assets | 13,946 |  |
| Accounts payable, accrued liabilities and other current liabilities | 1,036 |  |
| Deferred tax liabilities | 572 |  |
| Other long-term liabilities | 190 |  |
| Convertible notes and related derivatives | 3,743 |  |
| Total liabilities | 5,541 |  |
| Net assets acquired | 8,405 |  |
| Goodwill | 7,183 |  |
| Total purchase price | $ | 15,588 |  |

[0000106040-16-000033:notes:19]
Accounts Receivable, Net

[0000106040-16-000033:notes:20]
Accounts receivable are net of allowances for program-related incentives and doubtful accounts of $262 million.

[0000106040-16-000033:notes:21]
Inventories

[0000106040-16-000033:notes:22]
Finished goods were valued at estimated selling prices less costs of disposal and a reasonable profit allowance for the selling effort. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort, or at estimated replacement costs for certain components. Raw materials were valued at estimated replacement costs at the date of acquisition.

[0000106040-16-000033:notes:23]
Property, Plant and Equipment

[0000106040-16-000033:notes:24]
The property, plant and equipment acquired were valued using either the replacement cost or market value approach, as appropriate, as of the date of acquisition. The following table summarizes the preliminary estimated fair value of the property, plant and equipment acquired and their estimated useful lives:

[0000106040-16-000033:notes:25]
|  | Estimated Fair Value |  | Estimated Weighted-Average Useful Life |
|  | (in millions) |  | (in years) |
| Land | $ | 73 |  |  | — |
| Buildings | 315 |  |  | 15 |
| Machinery and equipment | 491 |  |  | 2 |
| Furniture and fixtures | 16 |  |  | 4 |
| Leasehold improvements | 22 |  |  | 5 |
| Total property, plant and equipment | $ | 917 |  |  |  |

[0000106040-16-000033:notes:26]
Identifiable Intangible Assets Acquired

[0000106040-16-000033:notes:27]
The following table summarizes the preliminary fair values and estimated useful lives of the intangibles acquired:

[0000106040-16-000033:notes:28]
|  | Estimated Fair Value |  | Estimated Weighted-Average Useful Life |
|  | (in millions) |  | (in years) |
| Developed technology | $ | 1,360 |  |  | 2.5 |
| Trade name and trademarks | 610 |  |  | 7.0 |
| Customer relationships | 475 |  |  | 7.0 |
| Supply agreements | 130 |  |  | 2.5 |
| Backlog | 50 |  |  | 0.1 |
| In-process research and development | 2,330 |  |  | N/A |
| Total acquired identifiable intangible assets | $ | 4,955 |  |  |  |

[0000106040-16-000033:notes:29]
The fair values of the identifiable intangible assets acquired were estimated using an income approach. The fair value of the finite-lived intangible assets will be amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received to cost of revenue and operating expenses. SanDisk had IPR&D projects associated with new generations of 3D BICS memory technology, a next generation of controllers for retail products, and a new platform for enterprise solutions products that have not yet reached technological feasibility as of the SanDisk Closing Date. These projects are expected to enable increased layers in and achieve lower costs for memory products compared to existing 2D NAND technology, improve controller performance and cost, and expand the range of enterprise solutions offerings. Accordingly, the Company recorded indefinite-lived intangible assets of $2.3 billion for the fair value of these projects, which will initially not be amortized. Instead, the projects will be tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that the projects may be impaired or may have reached technological feasibility. Once a project reaches technological feasibility, the Company will begin to amortize the intangible asset over its estimated useful life.

[0000106040-16-000033:notes:30]
Goodwill

[0000106040-16-000033:notes:31]
Goodwill represents the excess of the preliminary estimated purchase price over the sum of the estimated fair values assigned to assets acquired less liabilities assumed. The $7.18 billion of goodwill recognized is primarily attributable to the benefits the Company expects to derive from deepening the Company’s expertise in non-volatile memory and enabling the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost. None of the goodwill is expected to be deductible for tax purposes.

[0000106040-16-000033:notes:32]
Convertible Notes and Related Derivatives

[0000106040-16-000033:notes:33]
On the SanDisk Closing Date, SanDisk had outstanding $997 million aggregate principal amount of the 2017 Notes and $1.5 billion aggregate principal amount of the 2020 Notes. Concurrently with the issuance of the SanDisk Notes, SanDisk also purchased call options and sold warrants. The assumed liability for the SanDisk Notes and related derivatives reflects the estimated fair values of the SanDisk Notes and the related call options and warrants. See Note 3 to the consolidated financial statements for additional disclosures related to the SanDisk Notes.

[0000106040-16-000033:notes:34]
Stock-Based Compensation

[0000106040-16-000033:notes:35]
In connection with the Merger, each outstanding SanDisk option and RSU that was unvested as of the SanDisk Closing Date and each outstanding underwater vested option was converted into equivalent options and RSUs, in each case with respect to shares of the Company’s common stock, using the equity award exchange ratio in accordance with the Merger agreement. The value of these converted awards related to pre-combination expense was $58 million and is included in the aggregate purchase price. The remaining value of the converted awards represents post-combination expense and will be recognized by the Company over the remaining service periods. As of July 1, 2016, the future expense for the assumed SanDisk options and RSUs was $347 million, which will be recognized over a weighted average service period of approximately 2.7 years.

[0000106040-16-000033:notes:36]
Acquisition-related Expenses

[0000106040-16-000033:notes:37]
During 2016, the Company incurred $98 million of transaction expenses related to the Merger, which are included within selling, general and administrative expense in the consolidated statements of income. During 2016, the Company incurred merger-related charges of $30 million associated with the acceleration of certain equity awards in connection with the Merger, of which $24 million was recorded in selling, general and administrative expenses and $6 million was recorded in R&D. The Company also incurred $31 million of other acquisition related expenses, primarily consisting of retention and separation costs in connection with the Merger which are included in selling, general and administrative expenses in 2016.

[0000106040-16-000033:notes:38]
SanDisk Results

[0000106040-16-000033:notes:39]
Management does not have a practical method for allocating certain costs and tax elements to the SanDisk operations; however, the amount of revenue attributable to SanDisk in the Company’s consolidated statement of income from the acquisition date to July 1, 2016 was $793 million.

[0000106040-16-000033:notes:40]
Pro Forma Financial Information (Unaudited)

[0000106040-16-000033:notes:41]
The unaudited financial information in the table below summarizes the combined results of operations of the Company and SanDisk, on a pro forma basis, as though the combination had occurred as of the beginning of fiscal 2015. The pro forma financial information presented includes the effects of adjustments related to the fair value of acquired inventory, amortization charges from acquired intangible assets, depreciation charges from acquired fixed assets, interest expenses from financing the acquisition, share-based compensation expenses from the conversion of unvested equity awards and the elimination of certain expenses directly related to the transaction. The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition and any borrowings undertaken to finance the acquisition had taken place at the beginning of the earliest period presented, nor does it intend to be a projection of future results:

[0000106040-16-000033:notes:42]
Acquisition of Amplidata

[0000106040-16-000033:notes:43]
On March 9, 2015, the Company acquired Amplidata NV (“Amplidata”), a developer of object storage software for public and private cloud data centers. As a result of the acquisition, Amplidata became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition furthers the Company’s strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers.

[0000106040-16-000033:notes:44]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition and allocated the remaining value of $215 million to goodwill. The values assigned to the acquired assets and liabilities were finalized prior to March 9, 2016, which was the final date of the 12-month measurement period following the date of the acquisition. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company’s consolidated financial statements.

[0000106040-16-000033:notes:45]
The final purchase price allocation for Amplidata was as follows:

[0000106040-16-000033:notes:46]
|  | March 9,2015 |
|  | (in millions) |
| Tangible assets acquired and (liabilities) assumed, net | $ | (24 | ) |
| Intangible assets | 76 |  |
| Goodwill | 215 |  |
| Total | $ | 267 |  |

[0000106040-16-000033:notes:47]
The final purchase price allocation reflects adjustments since the date of acquisition, that consist of an increase of $42 million to goodwill, which primarily related to an adjustment to the value of deferred taxes acquired, an adjustment to the value of intangible assets acquired and an adjustment for the fair value of stock options assumed in the acquisition of Amplidata. The $215 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create HDD storage solutions leveraging the core software acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Amplidata was immaterial to the Company’s consolidated financial statements for 2016.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000106040-16-000033:notes:48]
Cash and Cash Equivalents

[0000106040-16-000033:notes:49]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-16-000033:notes:50]
The changes in the benefit obligations and plan assets for the Japanese defined benefit pension plans were as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:51]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Benefit obligation at beginning of period | $ | 231 |  |  | $ | 255 |  |  | $ | 234 |  |
| Service cost | 8 |  |  | 9 |  |  | 10 |  |
| Interest cost | 3 |  |  | 4 |  |  | 4 |  |
| Actuarial loss | 52 |  |  | 16 |  |  | 13 |  |
| Benefits paid | (16 | ) |  | (8 | ) |  | (7 | ) |
| Settlement/Curtailment | (1 | ) |  | — |  |  | — |  |
| Other(1) | — |  |  | — |  |  | 8 |  |
| Non-U.S. currency movement | 49 |  |  | (45 | ) |  | (7 | ) |
| Benefit obligation at end of period | 326 |  |  | 231 |  |  | 255 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 185 |  |  | 191 |  |  | 167 |  |
| Actual return on plan assets | (14 | ) |  | 22 |  |  | 15 |  |
| Employer contributions | 20 |  |  | 14 |  |  | 14 |  |
| Benefits paid | (16 | ) |  | (8 | ) |  | (7 | ) |
| Other(1) | — |  |  | — |  |  | 7 |  |
| Non-U.S. currency movement | 37 |  |  | (34 | ) |  | (5 | ) |
| Fair value of plan assets at end of period | 212 |  |  | 185 |  |  | 191 |  |
| Unfunded status at end of year | $ | 114 |  |  | $ | 46 |  |  | $ | 64 |  |

[0000106040-16-000033:notes:52]
| (1) | During fiscal 2014 the Japan entity assumed benefit obligations and plan assets from Hitachi Ltd. (“Hitachi”). These pension obligations related to former Hitachi employees who were hired into the HGST Japan entity during or soon after the 2012 acquisition of HGST by the Company. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-16-000033:notes:53]
Commitments and Contingencies

[0000106040-16-000033:notes:54]
Lease Commitments

[0000106040-16-000033:notes:55]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2025. Rental expense under these operating leases, including month-to-month rentals, was $59 million, $60 million and $59 million in 2016, 2015 and 2014, respectively. Future minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year at July 1, 2016 are as follows:

[0000106040-16-000033:notes:56]
| Fiscal Years |  | Lease Amounts |
|  |  | (in millions) |
| 2017 |  | $ | 95 |  |
| 2018 |  | 79 |  |
| 2019 |  | 69 |  |
| 2020 |  | 27 |  |
| 2021 |  | 22 |  |
| Thereafter |  | 37 |  |
| Future minimum payments |  | $ | 329 |  |

[0000106040-16-000033:notes:57]
Product Warranty Liability

[0000106040-16-000033:notes:58]
Changes in the warranty accrual for 2016, 2015 and 2014 were as follows:

[0000106040-16-000033:notes:59]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 221 |  |  | $ | 182 |  |  | $ | 187 |  |
| Warranty liabilities assumed as a result of acquisitions | 45 |  |  | 1 |  |  | 4 |  |
| Charges to operations | 162 |  |  | 187 |  |  | 170 |  |
| Utilization | (178 | ) |  | (190 | ) |  | (207 | ) |
| Changes in estimate related to pre-existing warranties | 29 |  |  | 41 |  |  | 28 |  |
| Warranty accrual, end of period | $ | 279 |  |  | $ | 221 |  |  | $ | 182 |  |

[0000106040-16-000033:notes:60]
The long-term portion of the warranty accrual classified in other liabilities was $107 million at July 1, 2016 and $71 million at July 3, 2015.

[0000106040-16-000033:notes:61]
Flash Ventures

[0000106040-16-000033:notes:62]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through these ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup. The Company accounts for its ownership position in each Flash Ventures entity under the equity method of accounting. The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-16-000033:notes:63]
Flash Partners. Flash Partners was formed in 2004. NAND flash memory products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 3”) located in Yokkaichi, Japan.

[0000106040-16-000033:notes:64]
Flash Alliance. Flash Alliance was formed in 2006. NAND flash memory products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 4”) located in Yokkaichi, Japan.

[0000106040-16-000033:notes:65]
Flash Forward. Flash Forward was formed in 2010. NAND flash memory products provided to the Company by this venture are manufactured by Toshiba primarily at its 300-millimeter wafer fabrication facility (“Fab 5”) located in Yokkaichi, Japan. Fab 5 was built in two phases of approximately equal size.

[0000106040-16-000033:notes:66]
New Fab 2. The Company has a facility agreement with Toshiba related to the construction and operation of Toshiba’s “New Fab 2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Fab 2 is primarily intended to provide additional cleanroom space to convert a portion of 2D NAND capacity to 3D NAND. Production wafers in New Fab 2 started in January 2016.

[0000106040-16-000033:notes:67]
The following table presents, as of July 1, 2016, the notes receivable from and equity investments in Flash Ventures assumed in connection with the Merger:

[0000106040-16-000033:notes:68]
|  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 65 |  |
| Notes receivable, Flash Alliance | 235 |  |
| Notes receivable, Flash Forward | 263 |  |
| Investment in Flash Partners | 202 |  |
| Investment in Flash Alliance | 306 |  |
| Investment in Flash Forward | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,171 |  |

[0000106040-16-000033:notes:69]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-16-000033:notes:70]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in other income (expense).

[0000106040-16-000033:notes:71]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-16-000033:notes:72]
Research and Development Activities. The Company participates in common R&D activities with Toshiba and is contractually committed to a minimum funding level. R&D commitments are immaterial to the consolidated financial statements.

[0000106040-16-000033:notes:73]
Off-Balance Sheet Liabilities

[0000106040-16-000033:notes:74]
Flash Ventures sells and leases back from a consortium of financial institutions (“lessors”) a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-16-000033:notes:75]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the exchange rate at July 1, 2016:

[0000106040-16-000033:notes:76]
|  |  | Lease Amounts |
|  |  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations |  | ¥ | 118.0 |  |  | $ | 1,151 |  |

[0000106040-16-000033:notes:77]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the lease agreements, in annual installments as of July 1, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate at July 1, 2016:

[0000106040-16-000033:notes:78]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 287 |  |  | $ | 61 |  |  | $ | 348 |  |
| Year 2 |  | 225 |  |  | 19 |  |  | 244 |  |
| Year 3 |  | 186 |  |  | 48 |  |  | 234 |  |
| Year 4 |  | 120 |  |  | 57 |  |  | 177 |  |
| Year 5 |  | 43 |  |  | 105 |  |  | 148 |  |
| Total guarantee obligations |  | $ | 861 |  |  | $ | 290 |  |  | $ | 1,151 |  |

[0000106040-16-000033:notes:79]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of July 1, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.

[0000106040-16-000033:notes:80]
Purchase Agreements

[0000106040-16-000033:notes:81]
The Company has entered into long-term purchase agreements with various component suppliers. The commitments depend on specific products ordered and may be subject to minimum quality requirements and future price negotiations. The Company expects these commitments to total $15 million for 2017, $7 million for 2018, $1 million for 2019 and no remaining commitments for 2020.

[0000106040-16-000033:notes:82]
The Company also has contracts with its other sources of silicon wafers that generally require the Company to provide monthly purchase order commitments. The purchase orders placed under these arrangements are generally binding and cannot be canceled. In addition, the Company’s subcontractors periodically procure production materials based on the forecast the Company provides to them. The Company’s agreements with these subcontractors require that the Company reimburse them for materials that are purchased on the Company’s behalf in accordance with such forecast. Accordingly, the Company may be committed to certain costs over and above its open noncancelable purchase orders with these subcontractors.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0000106040-16-000033:notes:83]
Investments

[0000106040-16-000033:notes:84]
The fair value of the Company’s investments classified as available-for-sale securities at July 1, 2016, by remaining contractual maturity, were as follows:

[0000106040-16-000033:notes:85]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 226 |  |  | $ | 227 |  |
| Due in one to five years (included in other non-current assets) | 119 |  |  | 119 |  |
| Total | $ | 345 |  |  | $ | 346 |  |

[0000106040-16-000033:notes:86]
The Company determined no available-for-sale securities were other-than-temporarily impaired in 2016, 2015 or 2014. For more information on the Company’s available-for-sale securities, see Note 11 to the consolidated financial statements.

[0000106040-16-000033:notes:87]
In November 2015, the Company entered into an agreement to form a joint venture with Unis to market and sell the Company’s current data center storage systems in China and to develop data storage systems for the Chinese market in the future. A business plan for the joint venture has been completed, and the Company expects that the joint venture will be operational during calendar year 2016. The joint venture is 49% owned by the Company and 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd. The Company accounts for its investment in the joint venture under the equity method of accounting. The investment is recorded within other non-current assets in the consolidated balance sheet and is not material to the consolidated financial statements as of July 1, 2016.


## us-gaap:DebtDisclosureTextBlock

[0000106040-16-000033:notes:88]
Debt

[0000106040-16-000033:notes:89]
Debt consisted of the following as of July 1, 2016 and July 3, 2015:

[0000106040-16-000033:notes:90]
|  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Variable interest rate term loan maturing 2019 | $ | — |  |  | $ | 2,312 |  |
| Variable interest rate term loan maturing 2021 (Term Loan A) | 4,125 |  |  | — |  |
| Variable interest rate USD term loan maturing 2023 (U.S. Term Loan B) | 3,750 |  |  | — |  |
| Variable interest rate Euro term loan maturing 2023 (Euro Term Loan B)(1) | 987 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | — |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | — |  |
| Convertible senior notes | 439 |  |  | — |  |
| Bridge loans | 3,000 |  |  | — |  |
| Total debt | 17,526 |  |  | 2,312 |  |
| Issuance costs and debt discounts | (532 | ) |  | (11 | ) |
| Subtotal | 16,994 |  |  | 2,301 |  |
| Less bridge loans and current portion of long-term debt | (3,334 | ) |  | (152 | ) |
| Long-term debt | $ | 13,660 |  |  | $ | 2,149 |  |

[0000106040-16-000033:notes:91]
| (1) | Euro Term Loan B principal amount was based upon the Euro exchange rate as of July 1, 2016. |

[0000106040-16-000033:notes:92]
In connection with the merger (the “Merger”) with SanDisk Corporation (“SanDisk”), the Company entered into new debt facilities. The proceeds from the new debt facilities were used to, among other things, (i) finance, in part, the cash portion of the purchase price, (ii) refinance certain existing indebtedness of Western Digital and SanDisk, and (iii) pay certain transaction costs.

[0000106040-16-000033:notes:93]
Notes

[0000106040-16-000033:notes:94]
On April 13, 2016, the Company completed an offering consisting of $1.875 billion 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that it may be required to offer to purchase the Notes upon the occurrence of a change of control or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears. The obligations under the Notes are guaranteed by certain of the Company’s existing and subsequently acquired or organized wholly-owned, material domestic subsidiaries.

[0000106040-16-000033:notes:95]
The Secured Notes were funded on May 12, 2016, and the Company received net cash proceeds of $1.826 billion. The Company pays cash interest on the Secured Notes quarterly at an annual rate of 7.375%. The Secured Notes mature in April 2023. The Secured Notes issuance cost was $49 million, which is amortized to interest expense over the term of the Secured Notes. The Secured Notes are collateralized on an equal and ratable basis by liens on the same assets that secure indebtedness under the New Credit Agreement (as defined below).

[0000106040-16-000033:notes:96]
The Unsecured Notes were funded on May 12, 2016, and the Company received net cash proceeds of $3.226 billion. The Company pays cash interest on the Unsecured Notes quarterly at an annual rate of 10.500%. The Unsecured Notes mature in April 2024. The Unsecured Notes issuance cost was $124 million, which is amortized to interest expense over the term of the Secured Notes.

[0000106040-16-000033:notes:97]
New Credit Agreement

[0000106040-16-000033:notes:98]
On April 29, 2016, the Company entered into a new credit agreement (the “New Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent (the “Administrative Agent”), and the lenders party thereto, which provides for variable interest rate secured loans consisting of a $4.125 billion term loan (the “Term Loan A”), a term loan (the “Term Loan B”) composed of a $3.750 billion U.S. dollar tranche (the “U.S. Term Loan B”) and a €885 million Euro tranche (the “Euro Term Loan B”), and a $1.000 billion revolving credit facility (the “Revolving Credit Facility”). The Revolving Credit Facility includes a $200 million sublimit for letters of credit.

[0000106040-16-000033:notes:99]
The Term Loan A was funded on May 12, 2016, and the Company received net cash proceeds of $4.059 billion. The Company pays monthly cash interest on the Term Loan A at a rate based on LIBOR, plus the applicable spread of 2.00% (approximately 2.450% at July 1, 2016). Term Loan A issuance costs were $66 million, which are amortized to interest expense over the term of the loan.

[0000106040-16-000033:notes:100]
The U.S. Term Loan B tranche was funded on April 29, 2016, and the Company received net cash proceeds of $3.541 billion. The Company pays monthly cash interest on the U.S. Term Loan B tranche at a rate based on LIBOR, subject to a 0.750% floor, plus the applicable spread of 5.500% (6.250% at July 1, 2016). The U.S. Term Loan B tranche issuance costs were $209 million, which are amortized to interest expense over the term of the loan. On August 17, 2016, the Company settled the U.S. Term Loan B tranche with proceeds of a new U.S. dollar-denominated Term Loan B-1 and a voluntary cash prepayment. For additional information, see Note 19 to the consolidated financial statements.

[0000106040-16-000033:notes:101]
The Euro Term Loan B tranche was funded on April 29, 2016, and the Company received net cash proceeds of $980 million, based on the Euro exchange rate. The Company pays monthly cash interest on the Euro Term Loan B tranche at a rate based on EURIBOR, subject to a 0.750% floor, plus the applicable spread of 5.250% (6.000% at July 1, 2016). The Euro Term Loan B tranche issuance costs were $28 million, which are amortized to interest expense over the term of the loan.

[0000106040-16-000033:notes:102]
The Revolving Credit Facility was not drawn upon, and there was no outstanding balance as of July 1, 2016.

[0000106040-16-000033:notes:103]
Term Loan A and the Revolving Credit Facility have a five-year term. Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in fiscal 2018, $309 million in fiscal 2019, $413 million in fiscal 2020 and the remaining balance of $3.197 billion due in fiscal 2021. Term Loan B has a seven-year term. Beginning in September 2016, the Company is required to make quarterly principal payments on Term Loan B equal to 0.25% of the original principal amount thereof, with the remaining balance due in fiscal 2023.

[0000106040-16-000033:notes:104]
The obligations under the New Credit Agreement are secured on a first-priority basis by a lien on substantially all the assets and properties of (i) the Company and (ii) HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-16-000033:notes:105]
The obligations under the New Credit Agreement are guaranteed by the WD Guarantors. The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that Term Loan B requires the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before the one-year anniversary of the effective date.

[0000106040-16-000033:notes:106]
Covenants

[0000106040-16-000033:notes:107]
The Notes and the loans under the New Credit Agreement require the Company to comply with certain financial covenants, such as a leverage ratio, an interest coverage ratio and customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. As of July 1, 2016, the Company was in compliance with all of the financial covenants.

[0000106040-16-000033:notes:108]
Additional Bridge Facility

[0000106040-16-000033:notes:109]
On May 12, 2016, WDT entered into a 45-day senior secured bridge credit agreement (the “Additional Bridge Credit Agreement”) among JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, the lenders from time to time party thereto and Western Digital providing for $3.0 billion in aggregate principal amount of senior secured bridge loans (the “Additional Bridge Facility”). On June 9, 2016, this agreement was amended to extend the maturity to 75 days.

[0000106040-16-000033:notes:110]
The Additional Bridge Facility was funded on May 12, 2016, and the Company received net cash proceeds of $2.972 billion. The bridge loan interest rate was 2.450%. The Additional Bridge Facility issuance costs were $28 million and are amortized to interest expense over the term of the bridge facility. On July 21, 2016, the Company paid in full the $3.0 billion aggregate principal amount of the bridge loan outstanding together with accrued interest.

[0000106040-16-000033:notes:111]
Termination of Existing Credit Agreement

[0000106040-16-000033:notes:112]
On May 12, 2016, pursuant to the terms of the New Credit Agreement, Western Digital Technologies, Inc., Western Digital Ireland, Ltd. and Western Digital International Ltd. (collectively, the “Existing Borrowers”) extinguished all outstanding loans, together with accrued interest and related fees, of $2.2 billion and terminated all commitments under the credit agreement dated as of January 9, 2014, as amended, among the Company, the Existing Borrowers, the lenders party thereto and JPMorgan Chase Bank, N.A., as administrative agent. Upon extinguishment of the outstanding loans, the Company recorded a loss of $11 million, which related to the write-off of previously capitalized debt issuance costs.

[0000106040-16-000033:notes:113]
Assumed SanDisk Convertible Notes, Call Options and Warrants

[0000106040-16-000033:notes:114]
On May 12, 2016, the closing date of the Merger (the “SanDisk Closing Date”), SanDisk had outstanding $997 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $1.5 billion aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “SanDisk Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on October 15, 2020.

[0000106040-16-000033:notes:115]
The Merger constituted a fundamental change under each indenture governing the SanDisk Notes. As a result, the conversion rate for each $1,000 of principal amount of SanDisk Notes surrendered for conversion from March 8, 2016 to June 9, 2016 was increased temporarily to 20.8004 units of reference property in the case of the 2017 Notes and 13.7726 units of reference property in the case of the 2020 Notes. Each reference unit is comprised of 0.2387 shares of Western Digital common stock and $67.50 in cash.

[0000106040-16-000033:notes:116]
The SanDisk Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange option is accounted for as a derivative liability because it is predominantly settled in cash. Changes in the fair value of the exchange option are reported in the consolidated statements of income in other income (expense), net until the Company extinguishes the related debt. The initial fair value of the exchange option reduced the carrying value of the SanDisk Notes (effectively an original issuance discount). This discount is amortized using the effective interest rate method through the recognition of non-cash interest expense over the remaining term of the debt. This has resulted in the recognition of interest expense on the 2017 Notes and the 2020 Notes at an effective rate of 5.0% and 5.5%, respectively. As of July 1, 2016, the 2017 Notes and the 2020 Notes have a remaining unamortized discount of $5 million and $59 million, respectively.

[0000106040-16-000033:notes:117]
The exchange option is measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange option was reported in current portion of long-term debt and long-term debt in the consolidated balance sheets. See Note 11 to the consolidated financial statements for additional disclosures related to the fair values of the exchange option. For the quarter ended July 1, 2016, the change in the fair value of the exchange option related to the 2017 Notes and 2020 Notes resulted in a loss of $8 million and a gain of $6 million, respectively.

[0000106040-16-000033:notes:118]
During the quarter ended July 1, 2016, the Company paid to the holders of the SanDisk Notes for conversion and repurchase $2.611 billion cash and 1.959 million shares of Western Digital common stock with an aggregate value of $94 million. After taking into account the exchanges and repurchases settled prior to July 1, 2016, $129 million principal amount of the 2017 Notes and $310 million principal amount of the 2020 Notes were outstanding. After taking into account the exchanges and repurchases settled after July 1, 2016 and the principal amount of $25 million of 2020 Notes repurchased by the Company, as of August 26, 2016, $37 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the remaining outstanding 2020 Notes, the conversion rate is 10.9006 units of reference property, corresponding to 2.6020 shares of Western Digital common stock and $735.79, per $1,000 principal amount of the 2020 Notes, subject to adjustments under the applicable indenture. The 2020 Notes are not currently exchangeable into reference property.

[0000106040-16-000033:notes:119]
Concurrently with the assumption of the SanDisk Notes, the Company assumed the outstanding call options and the warrants that were entered into by SanDisk at the inception of the respective SanDisk Notes, which were structured to reduce the potential economic dilution associated with the conversion of SanDisk Notes. SanDisk negotiated the termination of the warrants prior to the closing of the Merger and recorded a liability on the SanDisk Closing Date of $613 million. This amount was subsequently paid in the quarter ended July 1, 2016.

[0000106040-16-000033:notes:120]
The SanDisk call options are derivative instruments classified as an asset that result in the Company receiving cash and shares partially offsetting amounts payable upon exchange of the SanDisk Notes. During the quarter ended July 1, 2016, under the SanDisk call options, the Company received $409 million of cash and 1.4 million shares of Western Digital common stock which had an aggregate value of $70 million. During the quarter ended July 1, 2016, the Company recognized a non-cash gain of $7 million related to the change in value in the SanDisk call options, recorded in other income (expense), net in the consolidated statements of income. The value of the SanDisk call options at July 1, 2016 was $71 million.

[0000106040-16-000033:notes:121]
The exchange and repurchase of the 2017 Notes and related settlement of the debt instruments during the quarter ended July 1, 2016 resulted in a loss of $14 million. The exchange and repurchase of the 2020 Notes and related settlement of the debt instruments during the quarter ended July 1, 2016 resulted in a loss of $42 million.

[0000106040-16-000033:notes:122]
Debt maturities

[0000106040-16-000033:notes:123]
As of July 1, 2016, annual debt maturities were as follows:

[0000106040-16-000033:notes:124]
| Fiscal Years |  | Debt Maturities |
|  |  | (in millions) |
| 2017 |  | $ | 3,424 |  |
| 2018 |  | 254 |  |
| 2019 |  | 357 |  |
| 2020 |  | 460 |  |
| 2021 |  | 3,306 |  |
| Thereafter |  | 9,725 |  |
| Total |  | 17,526 |  |
| Issuance costs and debt discounts |  | (532 | ) |
| Net carrying value |  | $ | 16,994 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-16-000033:notes:125]
Derivatives

[0000106040-16-000033:notes:126]
Foreign Exchange Contracts

[0000106040-16-000033:notes:127]
As of July 1, 2016, the net amount of unrealized gains with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $74 million. In addition, as of July 1, 2016, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $5.3 billion and $4.6 billion, and closed $4.5 billion and $4.8 billion, in foreign exchange contracts during the years ended July 1, 2016 and July 3, 2015, respectively.

[0000106040-16-000033:notes:128]
Call Options and Exchange Option Derivatives

[0000106040-16-000033:notes:129]
The Company assumed call option and exchange option instruments related to the assumed SanDisk Notes in connection with the Merger. See Notes 3 and 11 for further discussion.

[0000106040-16-000033:notes:130]
Derivative Instruments

[0000106040-16-000033:notes:131]
The fair value and balance sheet location of the Company’s derivative instruments as of July 1, 2016 and July 3, 2015 were as follows:

[0000106040-16-000033:notes:132]
|  | Derivative Assets Reported in |
|  | Other Current Assets |  | Other Non-current Assets |
|  | July 1, 2016 |  | July 3, 2015 |  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 114 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 12 |  |  | — |  |  | — |  |  | — |  |
| Call options | 70 |  |  | — |  |  | 1 |  |  | — |  |
| Total derivatives | $ | 196 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |

[0000106040-16-000033:notes:133]
|  | Derivative Liabilities Reported in |
|  | Accrued Expenses |  | Other Liabilities |
|  | July 1, 2016 |  | July 3, 2015 |  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 23 |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | — |  |  | — |  |  | — |  |  | — |  |
| Exchange option | 141 |  |  | — |  |  | 14 |  |  | — |  |
| Total derivatives | $ | 164 |  |  | $ | 31 |  |  | $ | 14 |  |  | $ | — |  |

[0000106040-16-000033:notes:134]
Netting Arrangements

[0000106040-16-000033:notes:135]
The following table presents the gross amounts of the Company’s derivative instruments, amounts offset due to master netting arrangements with the Company’s various counterparties and the net amounts recognized in the consolidated balance sheet as of July 1, 2016:

[0000106040-16-000033:notes:136]
|  |  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated as Hedging Instruments |  | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
|  |  | (in millions) |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets |  | $ | 118 |  |  | $ | (4 | ) |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |  | $ | 114 |  |
| Financial liabilities |  | (27 | ) |  | 4 |  |  | (23 | ) |  | — |  |  | — |  |  | (23 | ) |
| Total derivative instruments |  | $ | 91 |  |  | $ | — |  |  | $ | 91 |  |  | $ | — |  |  | $ | — |  |  | $ | 91 |  |

[0000106040-16-000033:notes:137]
The Company had a gross and net liability of $31 million related to its derivative instruments outstanding at July 3, 2015. There were no amounts offset due to master netting arrangements in place at July 3, 2015.

[0000106040-16-000033:notes:138]
Effect of Foreign Exchange Contracts on the Consolidated Statements of Operations

[0000106040-16-000033:notes:139]
The impact of foreign exchange contracts on the consolidated financial statements was as follows:

[0000106040-16-000033:notes:140]
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in Accumulated Other Comprehensive Income on Derivatives |  | Amount of Gain (Loss) Reclassified from Accumulated Other Comprehensive Income into Income |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in millions) |
| Foreign exchange contracts |  | $ | 48 |  |  | $ | (74 | ) |  | $ | (51 | ) |  | $ | (44 | ) |

[0000106040-16-000033:notes:141]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the consolidated financial statements during 2016, 2015 and 2014. See Notes 1 and 11 to the consolidated financial statements for additional disclosures related to the Company’s foreign exchange contracts.


## us-gaap:DerivativesPolicyTextBlock

[0000106040-16-000033:notes:142]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British Pound Sterling, European Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges and had an aggregate notional amount of $3.1 billion and $1.3 billion at July 1, 2016 and July 3, 2015, respectively.

[0000106040-16-000033:notes:143]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in cost of revenue and R&D and presented within cash flows from operating activities. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the consolidated financial statements for all years presented.

[0000106040-16-000033:notes:144]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported in cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges, if any, were determined to be effective as of July 1, 2016 and July 3, 2015. See Notes 11 and 13 to the consolidated financial statements for additional disclosures related to the Company’s foreign exchange contracts.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-16-000033:notes:145]
The following table presents the Company’s stock-based compensation and related tax benefit for 2016, 2015 and 2014:

[0000106040-16-000033:notes:146]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Options | $ | 55 |  |  | $ | 58 |  |  | $ | 67 |  |
| ESPP | 13 |  |  | 16 |  |  | 18 |  |
| RSUs | 123 |  |  | 88 |  |  | 71 |  |
| Subtotal | 191 |  |  | 162 |  |  | 156 |  |
| Tax Benefit | (48 | ) |  | (43 | ) |  | (40 | ) |
| Total | $ | 143 |  |  | $ | 119 |  |  | $ | 116 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000106040-16-000033:notes:147]
Income per Common Share

[0000106040-16-000033:notes:148]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and shares issuable in connection with convertible debt.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000106040-16-000033:notes:149]
The following is a reconciliation of the call options reported in other current assets and other non-current assets in the Company’s consolidated balance sheets as of July 1, 2016.

[0000106040-16-000033:notes:150]
|  | 2017 Call Options |  | 2020 Call Options |  | Total |
|  | (in millions) |
| Initial estimate upon acquisition | $ | 501 |  |  | $ | — |  |  | $ | 501 |  |
| Redemptions | (437 | ) |  | — |  |  | (437 | ) |
| Net unrealized gain (loss) | 6 |  |  | 1 |  |  | 7 |  |
| Fair value at end of period | $ | 70 |  |  | $ | 1 |  |  | $ | 71 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-16-000033:notes:151]
Fair Value Measurements

[0000106040-16-000033:notes:152]
Financial Instruments Carried at Fair Value

[0000106040-16-000033:notes:153]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-16-000033:notes:154]
Level 1. Quoted prices in active markets for identical assets or liabilities.

[0000106040-16-000033:notes:155]
Level 2. Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-16-000033:notes:156]
Level 3. Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-16-000033:notes:157]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of July 1, 2016 and July 3, 2015, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-16-000033:notes:158]
|  | July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 2,199 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,199 |  |
| Certificates of deposit | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 2,199 |  |  | 1 |  |  | — |  |  | 2,200 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202 |  |  | — |  |  | 202 |  |
| Corporate notes and bonds | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total short-term investments | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Asset-backed securities | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Municipal notes and bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total long-term investments | 2 |  |  | 117 |  |  | — |  |  | 119 |  |
| Foreign exchange contracts | — |  |  | 126 |  |  | — |  |  | 126 |  |
| Call options | — |  |  | — |  |  | 71 |  |  | 71 |  |
| Total assets at fair value | $ | 2,201 |  |  | $ | 471 |  |  | $ | 71 |  |  | $ | 2,743 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Exchange option | — |  |  | — |  |  | 155 |  |  | 155 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 23 |  |  | $ | 155 |  |  | $ | 178 |  |

[0000106040-16-000033:notes:159]
|  | July 3, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 135 |  |  | $ | — |  |  | $ | — |  |  | $ | 135 |  |
| Total cash equivalents | 135 |  |  | — |  |  | — |  |  | 135 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| U.S. Government agency securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Commercial paper | — |  |  | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total short-term investments | — |  |  | 262 |  |  | — |  |  | 262 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 237 |  |  | — |  |  | 237 |  |
| U.S. Government agency securities | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Total long-term investments | — |  |  | 328 |  |  | — |  |  | 328 |  |
| Total assets at fair value | $ | 135 |  |  | $ | 590 |  |  | $ | — |  |  | $ | 725 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000106040-16-000033:notes:160]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government Agency securities. Money market funds are valued based on quoted market prices.

[0000106040-16-000033:notes:161]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government and are held in custody by a third party. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000033:notes:162]
U.S. and International Government Agency Securities. The Company’s U.S. and International Government agency securities are investments in fixed income securities sponsored by the U.S. and International Government and are held in custody by a third party. U.S. and International Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000033:notes:163]
Asset-Backed Securities, and Corporate and Municipal Notes and Bonds. The Company’s asset-backed securities, and Corporate and Municipal notes and bonds securities are investments issued by corporations and U.S. state municipalities which are held in custody by a third party. Asset-backed securities, and Corporate and Municipal notes and bonds are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000033:notes:164]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-16-000033:notes:165]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-16-000033:notes:166]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the consolidated balance sheets. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 13 to the consolidated financial statements.

[0000106040-16-000033:notes:167]
During years 2016 and 2015, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-16-000033:notes:168]
Assets and Liabilities Measured at Fair Value on a Recurring Basis Using Significant Unobservable Inputs (Level 3)

[0000106040-16-000033:notes:169]
In connection with the Merger, the Company assumed the previously issued SanDisk Notes which were determined to contain an embedded exchange option derivative and also assumed call options that were intended to offset the dilution of the exchange option (see Note 3). The fair value measurement of the call options and exchange option arising from the assumed SanDisk Notes are not actively traded and are determined via a lattice model, using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) economic incentive for holders to exercise their exchange option. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-16-000033:notes:170]
There were no transfers of call options or exchange option out of Level 3 for 2016.

[0000106040-16-000033:notes:171]
The following is a reconciliation of the exchange option reported in accrued expenses and other liabilities in the Company’s consolidated balance sheets as of July 1, 2016.

[0000106040-16-000033:notes:172]
|  | 2017 Exchange Options |  | 2020 Exchange Options |  | Total |
|  | (in millions) |
| Initial estimate upon acquisition | $ | 610 |  |  | $ | 357 |  |  | $ | 967 |  |
| Net realized loss (gain) | 8 |  |  | 8 |  |  | 16 |  |
| Redemptions | (531 | ) |  | (283 | ) |  | (814 | ) |
| Net unrealized loss (gain) | — |  |  | (14 | ) |  | (14 | ) |
| Fair value at end of period | $ | 87 |  |  | $ | 68 |  |  | $ | 155 |  |

[0000106040-16-000033:notes:173]
Financial Instruments Not Carried at Fair Value

[0000106040-16-000033:notes:174]
For those financial instruments where the carrying amounts differ from fair value, the following table represents the related carrying values and fair values, which are based on quoted market prices. As of July 1, 2016, the Secured Notes, Unsecured Notes, Term Loan A, the U.S. Term Loan B tranche, the Euro Term Loan B tranche and senior secured bridge loan were categorized as Level 2, based on the frequency of trading directly prior to the end of the fourth quarter of 2016. See Note 3 to the consolidated financial statements for additional disclosures related to these financial instruments.

[0000106040-16-000033:notes:175]
|  | July 1, 2016 |
|  | Aggregated Principal |  | Aggregated Fair Value |
|  | (in millions) |
| Secured Notes | $ | 1,875 |  |  | $ | 2,044 |  |
| Unsecured Notes | 3,350 |  |  | 3,575 |  |
| Term Loan A | 4,125 |  |  | 4,161 |  |
| U.S. Term Loan B | 3,750 |  |  | 3,773 |  |
| Euro Term Loan B | 987 |  |  | 981 |  |
| Bridge Loan | 3,000 |  |  | 3,000 |  |

[0000106040-16-000033:notes:176]
Cost Method Investments

[0000106040-16-000033:notes:177]
As of July 1, 2016, the Company had aggregate net investments under the cost method of accounting of $135 million, and these investments consisted of privately-held equity securities without a readily determinable fair value. The Company has determined that it is not practicable to estimate the fair value of these investments. These privately-held equity investments are reported under other non-current assets in the consolidated balance sheets.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-16-000033:notes:178]
Goodwill and Other Intangible Assets

[0000106040-16-000033:notes:179]
The following table summarizes the activity related to the carrying amount of goodwill:

[0000106040-16-000033:notes:180]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 27, 2014 | $ | 2,559 |  |
| Goodwill recorded in connection with acquisitions | 207 |  |
| Balance at July 3, 2015 | 2,766 |  |
| Goodwill recorded in connection with acquisitions | 7,183 |  |
| Foreign currency translation adjustment | 2 |  |
| Balance at July 1, 2016 | $ | 9,951 |  |

[0000106040-16-000033:notes:181]
The following tables present intangible assets as of July 1, 2016 and July 3, 2015:

[0000106040-16-000033:notes:182]
|  | July 1, 2016 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Existing technology | 3 |  | $ | 2,008 |  |  | $ | 632 |  |  | $ | 1,376 |  |
| Trade names and trademarks | 7 |  | 645 |  |  | 45 |  |  | 600 |  |
| Customer relationships | 6 |  | 628 |  |  | 157 |  |  | 471 |  |
| Other | 2 |  | 219 |  |  | 96 |  |  | 123 |  |
| Leasehold interests | 31 |  | 39 |  |  | 10 |  |  | 29 |  |
| Total finite intangible assets |  |  | 3,539 |  |  | 940 |  |  | 2,599 |  |
| In-process research and development |  |  | 2,435 |  |  | — |  |  | 2,435 |  |
| Total intangible assets |  |  | $ | 5,974 |  |  | $ | 940 |  |  | $ | 5,034 |  |

[0000106040-16-000033:notes:183]
|  | July 3, 2015 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Existing technology | 5 |  | $ | 638 |  |  | $ | 471 |  |  | $ | 167 |  |
| Customer relationships | 4 |  | 152 |  |  | 126 |  |  | 26 |  |
| Other | 3 |  | 74 |  |  | 68 |  |  | 6 |  |
| Leasehold interests | 31 |  | 39 |  |  | 11 |  |  | 28 |  |
| Total finite intangible assets |  |  | 903 |  |  | 676 |  |  | 227 |  |
| In-process research and development |  |  | 105 |  |  | — |  |  | 105 |  |
| Total intangible assets |  |  | $ | 1,008 |  |  | $ | 676 |  |  | $ | 332 |  |

[0000106040-16-000033:notes:184]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Amortization expense for intangible assets was $266 million, $171 million and $213 million for 2016, 2015 and 2014, respectively. During 2016, 2015 and 2014, the Company recorded $36 million, $39 million and $53 million of impairment charges related to intangible assets, respectively, which are recorded in the employee termination, asset impairment and other charges within the Company’s consolidated statements of income. The impairment charges primarily relate to acquired IPR&D projects that were abandoned and resulted in full impairment.

[0000106040-16-000033:notes:185]
The following table presents estimated future amortization expense for intangible assets currently subject to amortization:

[0000106040-16-000033:notes:186]
|  | July 1, 2016 |
|  | (in millions) |
| 2017 | $ | 912 |  |
| 2018 | 670 |  |
| 2019 | 377 |  |
| 2020 | 167 |  |
| 2021 | 161 |  |
| 2022 and thereafter | 312 |  |
| Future amortization expense | $ | 2,599 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000106040-16-000033:notes:187]
Goodwill and Other Long-Lived Assets

[0000106040-16-000033:notes:188]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the first day of its fiscal fourth quarter. The Company either uses qualitative factors to determine whether goodwill is more likely than not impaired or performs a two-step approach to quantify impairment. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to follow a two-step approach to quantify the impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment for each reporting unit. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-16-000033:notes:189]
Acquired intangibles are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. IPR&D is not amortized until the point at which it reaches technological feasibility. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The Company recorded impairments to certain long-lived assets in 2016, 2015 and 2014. See Notes 14 and 17 to the consolidated financial statements for additional disclosures related to the Company’s other intangible assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-16-000033:notes:190]
Income Taxes

[0000106040-16-000033:notes:191]
Pre-tax Income

[0000106040-16-000033:notes:192]
The domestic and foreign components of income before income taxes were as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:193]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Foreign | $ | 516 |  |  | $ | 1,501 |  |  | $ | 1,664 |  |
| Domestic | (363 | ) |  | 76 |  |  | 88 |  |
| Income before income taxes | $ | 153 |  |  | $ | 1,577 |  |  | $ | 1,752 |  |

[0000106040-16-000033:notes:194]
Income Tax Provision

[0000106040-16-000033:notes:195]
The components of the provision for income taxes were as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:196]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 59 |  |  | $ | 54 |  |  | $ | 47 |  |
| Domestic-federal | 2 |  |  | 43 |  |  | 98 |  |
| Domestic-state | (1 | ) |  | (13 | ) |  | 3 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (39 | ) |  | 12 |  |  | (3 | ) |
| Domestic-federal | (109 | ) |  | 11 |  |  | (14 | ) |
| Domestic-state | (1 | ) |  | 5 |  |  | 4 |  |
| Income tax provision | $ | (89 | ) |  | $ | 112 |  |  | $ | 135 |  |

[0000106040-16-000033:notes:197]
The Company’s income tax benefit for 2016 reflects tax benefits from expenses related to the Merger and from interest expense related to new debt facilities.

[0000106040-16-000033:notes:198]
Remaining net undistributed earnings from foreign subsidiaries at July 1, 2016 on which no U.S. tax has been provided amounted to $12 billion. The net undistributed earnings are intended to finance local operating requirements and capital investments. Accordingly, an additional U.S. tax provision has not been made on these earnings. The tax liability for these earnings would be approximately $4 billion if the Company repatriated the $12 billion in undistributed earnings from the foreign subsidiaries.

[0000106040-16-000033:notes:199]
Deferred Taxes

[0000106040-16-000033:notes:200]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities as of July 1, 2016 and July 3, 2015 were as follows:

[0000106040-16-000033:notes:201]
|  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 82 |  |  | $ | 50 |  |
| Accrued compensation and benefits not currently deductible | 207 |  |  | 138 |  |
| Domestic net operating loss carryforward | 259 |  |  | 137 |  |
| Business credit carryforward | 264 |  |  | 167 |  |
| Long-lived assets | 256 |  |  | 49 |  |
| Other | 177 |  |  | 65 |  |
| Total deferred tax assets | 1,245 |  |  | 606 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (1,030 | ) |  | (126 | ) |
| Other | (9 | ) |  | (10 | ) |
| Total deferred tax liabilities | (1,039 | ) |  | (136 | ) |
| Valuation allowances | (294 | ) |  | (166 | ) |
| Deferred tax (liabilities) assets, net | $ | (88 | ) |  | $ | 304 |  |

[0000106040-16-000033:notes:202]
The net deferred tax asset valuation allowance increased by $128 million in 2016 and decreased by $38 million in 2015. $103 million of the net deferred tax asset valuation allowance increase in 2016 is primarily attributable to balances assumed as a result of the Merger. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-16-000033:notes:203]
In addition to the deferred tax assets presented above, the Company had additional net operating loss (“NOL”) benefits related to stock-based compensation deductions of $119 million and $90 million at July 1, 2016 and July 3, 2015, respectively. During 2016, the Company generated an additional $34 million of benefits related to stock-based compensation deductions, of which $7 million were utilized in 2016 and recorded to stockholders’ equity.

[0000106040-16-000033:notes:204]
Effective Tax Rate

[0000106040-16-000033:notes:205]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:206]
|  | 2016 |  | 2015 |  | 2014 |
| U.S. Federal statutory rate | 35 | % |  | 35 | % |  | 35 | % |
| Tax rate differential on international income | (103 | ) |  | (29 | ) |  | (28 | ) |
| Tax effect of U.S. non-deductible convertible debt costs | 13 |  |  | — |  |  | — |  |
| Tax effect of U.S. non-deductible acquisition costs | 10 |  |  | — |  |  | — |  |
| Tax effect of U.S. foreign income inclusion | 9 |  |  | — |  |  | — |  |
| Tax effect of U.S. non-deductible share-based compensation | 9 |  |  | — |  |  | — |  |
| Tax effect of U.S. permanent differences | 1 |  |  | 1 |  |  | 2 |  |
| State income tax, net of federal tax | (1 | ) |  | — |  |  | — |  |
| Retroactive extension of Federal R&D credit | (9 | ) |  | — |  |  | — |  |
| Creditable foreign taxes | (13 | ) |  | — |  |  | — |  |
| Income tax credits | (14 | ) |  | (2 | ) |  | (1 | ) |
| Other | 5 |  |  | 2 |  |  | — |  |
| Effective tax rate | (58 | )% |  | 7 | % |  | 8 | % |

[0000106040-16-000033:notes:207]
Tax Holidays and Carryforwards

[0000106040-16-000033:notes:208]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines, Singapore and Thailand operate under various tax holidays and tax incentive programs which will expire in whole or in part at various dates from 2016 through 2029. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was to increase the Company’s net earnings by $500 million ($2.07 per diluted share), $641 million ($2.70 per diluted share) and $905 million ($3.74 per diluted share) in 2016, 2015 and 2014, respectively.

[0000106040-16-000033:notes:209]
As of July 1, 2016, the Company had federal and state NOL carryforwards of $848 million and $612 million, respectively. In addition, as of July 1, 2016, the Company had various federal and state tax credit carryforwards of $664 million combined. The NOL carryforwards available to offset future federal and state taxable income expire at various dates from 2018 to 2035 and 2017 to 2036, respectively. $200 million of the credit carryforwards available to offset future taxable income expire at various dates from 2017 to 2036. The remaining amount is available indefinitely. NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of NOLs and credits ultimately realized will be reduced by $483 million and $32 million, respectively.

[0000106040-16-000033:notes:210]
Uncertain Tax Positions

[0000106040-16-000033:notes:211]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Company’s balance sheet. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. As of July 1, 2016, the Company had $491 million of unrecognized tax benefits. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of July 1, 2016, July 3, 2015 and June 27, 2014 was $75 million, $55 million and $44 million, respectively. $120 million of the unrecognized tax benefits increase is attributable primarily to balances assumed as a result of the Merger.

[0000106040-16-000033:notes:212]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for 2016, 2015 and 2014:

[0000106040-16-000033:notes:213]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Unrecognized tax benefit at beginning of period | $ | 350 |  |  | $ | 300 |  |  | $ | 240 |  |
| Gross increases related to current year tax positions | 46 |  |  | 44 |  |  | 27 |  |
| Gross increases related to prior year tax positions | 6 |  |  | 6 |  |  | 26 |  |
| Gross decreases related to prior year tax positions | (15 | ) |  | — |  |  | (5 | ) |
| Settlements | (8 | ) |  | — |  |  | — |  |
| Lapse of statute of limitations | (8 | ) |  | (3 | ) |  | — |  |
| Acquisitions | 120 |  |  | 3 |  |  | 12 |  |
| Unrecognized tax benefit at end of period | $ | 491 |  |  | $ | 350 |  |  | $ | 300 |  |

[0000106040-16-000033:notes:214]
The Company’s unrecognized tax benefits are primarily included within long-term liabilities in the Company’s consolidated balance sheets. The entire balance of unrecognized tax benefits at July 1, 2016, July 3, 2015 and June 27, 2014, if recognized, would affect the effective tax rate, subject to certain future valuation allowance reversals.

[0000106040-16-000033:notes:215]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2008 through 2015. In foreign jurisdictions, with few exceptions, the Company is subject to examination for all years subsequent to fiscal 2008. The Company is no longer subject to examination by the IRS for periods prior to 2008, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period.

[0000106040-16-000033:notes:216]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-16-000033:notes:217]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of July 1, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0000106040-16-000033:notes:218]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized.

[0000106040-16-000033:notes:219]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.


## us-gaap:InventoryPolicyTextBlock

[0000106040-16-000033:notes:220]
The Company values inventories at the lower of cost (first-in, first out and weighted-average methods) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories, while the weighted-average method is used to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by the Company. The Company has determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, precious metals are relieved from inventory based on the weighted-average cost of the inventory at the time the inventory is used in production. The weighted average method of valuing precious metals does not materially differ from the FIFO method. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-16-000033:notes:221]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-16-000033:notes:222]
Legal Proceedings

[0000106040-16-000033:notes:223]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-16-000033:notes:224]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-16-000033:notes:225]
Intellectual Property Litigation

[0000106040-16-000033:notes:226]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-16-000033:notes:227]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

[0000106040-16-000033:notes:228]
Antitrust

[0000106040-16-000033:notes:229]
On June 25, 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint captioned Ritz Camera & Image, LLC v. SanDisk Corporation, Inc. and Eliyahou Harari in the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 25, 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. On February 24, 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. On May 14, 2015, the District Court granted in part plaintiffs’ motion for class certification. On April 29, 2016, the court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk's favor as to all of the plaintiffs’ claims. On May 31, 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

[0000106040-16-000033:notes:230]
On July 15, 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3D LLC (“SD-3C”) in the U.S. District Court for the Northern District of California, alleging that defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD‑3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD‑3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. On August 25, 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint on September 16, 2011. On January 3, 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. On April 4, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint on January 20, 2015. On September 30, 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. On October 21, 2015, Samsung filed a fourth amended complaint. On November 4, 2015, the defendants filed a motion to dismiss, which is currently under submission. Discovery is presently stayed until after completion of the pleading stage.

[0000106040-16-000033:notes:231]
On March 15, 2011, a complaint was filed against SanDisk, SD‑3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. in the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of Secure Digital (“SD”) cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD™ cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. On May 21, 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. On May 14, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. On February 3, 2015, the plaintiffs filed a second amended complaint in the District Court. On September 30, 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. On November 4, 2015, the plaintiffs filed a third amended complaint. On November 25, 2015, the defendants filed a motion to dismiss, which is currently pending. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000033:notes:232]
Securities

[0000106040-16-000033:notes:233]
Beginning on March 30, 2015, SanDisk and two officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed in the United States District Court for the Northern District of. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 16, 2014 and March 25, 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 16, 2014 and April 15, 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. On July 9, 2015, the Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. On January 22, 2016, the court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. On February 22, 2016, the court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). On March 23, 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss on April 29, 2016. On June 24, 2016, the court granted the motion and dismissed the amended complaint with leave to amend. On July 15, 2016, the Institutional Investor Group filed a further amended complaint. The Company filed a motion to dismiss on August 19, 2016. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000033:notes:234]
Other Matters

[0000106040-16-000033:notes:235]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000033:notes:236]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-16-000033:notes:237]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows. It is reasonably possible that the Company may incur losses totaling up to $123 million, including the amounts accrued.

[0000106040-16-000033:notes:238]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000106040-16-000033:notes:239]
| Long-lived assets(2): |  |  |  |  |  |
|  |  |  | July 1, 2016 |  | July 3, 2015 |
|  |  |  | (in millions) |
| United States |  |  | $ | 1,406 |  |  | $ | 1,121 |  |
| China |  |  | 463 |  |  | 367 |  |
| Asia |  |  | 1,628 |  |  | 1,473 |  |
| Europe, Middle East and Africa |  |  | 6 |  |  | 4 |  |
| Total |  |  | $ | 3,503 |  |  | $ | 2,965 |  |

[0000106040-16-000033:notes:240]
| (1) | Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee. |

[0000106040-16-000033:notes:241]
| (2) | Long-lived assets are attributed to the geographic location in which they are located. |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-16-000033:notes:242]
Recent Accounting Pronouncements

[0000106040-16-000033:notes:243]
Recently Adopted

[0000106040-16-000033:notes:244]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-16, “Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments” (“ASU 2015-16”), which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Acquirers must recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. The Company early adopted ASU 2015-16 during the fourth quarter of fiscal 2016 on a prospective basis. The Company adopted this standard in the fourth quarter of 2016 on a prospective basis. No adjustments were made to prior-period consolidated financial statements.

[0000106040-16-000033:notes:245]
In November 2015, the FASB issued ASU No. 2015-17, “Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes” (“ASU 2015-17”), which requires that deferred tax liabilities and assets for each tax-paying jurisdiction within each tax-paying component to be classified as noncurrent in a classified statement of financial position. The Company early adopted ASU 2015-17 during the second quarter of fiscal 2016 on a prospective basis, which resulted in the reclassification of $165 million of net deferred tax assets as of January 1, 2016 from current assets to noncurrent assets. Since the Company adopted this standard on a prospective basis, no adjustments were made to prior-period balance sheets.

[0000106040-16-000033:notes:246]
In April 2015, the FASB issued ASU No. 2015-03, “Interest — Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs” (“ASU 2015-03”). The new standard requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The Company early adopted ASU 2015-03 during the fourth quarter of fiscal 2016 on a retrospective basis, which resulted in a reduction of $4 million in other current assets and the current portion of long-term debt, and a reduction of $7 million in other non-current assets and long-term debt within the consolidated balance sheet as of July 3, 2015.

[0000106040-16-000033:notes:247]
Recently Issued

[0000106040-16-000033:notes:248]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within these periods, which for the Company is the first quarter of fiscal 2018. The Company is currently evaluating the impact ASU 2016-09 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000033:notes:249]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for the Company is the first quarter of fiscal 2020. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000033:notes:250]
In April 2015, the FASB issued ASU No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The standard is effective for fiscal years beginning after December 15, 2015, including interim periods within those fiscal years, which for the Company is the first quarter of fiscal 2017. The Company is currently evaluating the impact ASU 2015-05 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000033:notes:251]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers” (“ASU 2014-09”), which amends the guidance in former Accounting Standards Codification Topic 605, “Revenue Recognition,” to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The proposed standard may accelerate the timing of revenue recognition for the Company’s license and royalty contracts. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of this ASU by one year. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years and interim periods within those years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019. The Company has not yet selected a transition method and is currently expecting to adopt this standard in the first quarter of fiscal 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-16-000033:notes:252]
Organization and Summary of Significant Accounting Policies

[0000106040-16-000033:notes:253]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the needs of the information technology industry and the infrastructure that enables the storage of data. The Company also generates license and royalty revenue related to its intellectual property.

[0000106040-16-000033:notes:254]
The Company has prepared its consolidated financial statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-16-000033:notes:255]
Fiscal Year

[0000106040-16-000033:notes:256]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2016 ended on July 1, 2016 and was comprised of 52 weeks. Fiscal year 2015 ended on July 3, 2015 and was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the second, third and fourth quarters consisting of 13 weeks each. Fiscal year 2014 ended on June 27, 2014 and was comprised of 52 weeks.

[0000106040-16-000033:notes:257]
Basis of Presentation

[0000106040-16-000033:notes:258]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the consolidated financial statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of income items. Translation adjustments are recorded in accumulated other comprehensive income, a component of stockholders’ equity.

[0000106040-16-000033:notes:259]
Reclassifications

[0000106040-16-000033:notes:260]
Certain prior year amounts have been reclassified in the balance sheet, statement of income and footnotes to conform with the current year presentation.

[0000106040-16-000033:notes:261]
Available-for-Sale Securities

[0000106040-16-000033:notes:262]
The Company invests in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds, with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within short-term investments and other non-current assets in the consolidated balance sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of stockholders’ equity. Gains and losses on available-for-sale securities are recorded based on the specific identification method. The Company evaluates the available-for-sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in total other expense, net in the consolidated statements of income. In addition, realized gains and losses are included in total other expense, net in the consolidated statements of income.

[0000106040-16-000033:notes:263]
Equity Investments

[0000106040-16-000033:notes:264]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company accounts for investments in equity securities of other entities that are not consolidated under the cost method of accounting if the Company’s ownership interest is less than 20%, and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies.

[0000106040-16-000033:notes:265]
Investments accounted for under the cost method are recorded within other non-current assets in the consolidated balance sheets as of July 1, 2016 and July 3, 2015. They are also periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-16-000033:notes:266]
Variable Interest Entities

[0000106040-16-000033:notes:267]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-16-000033:notes:268]
Fair Value of Financial Instruments

[0000106040-16-000033:notes:269]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-16-000033:notes:270]
Property and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty-five years. The majority of the Company’s equipment is depreciated over periods of two to seven years. Depreciation is computed on a straight-line basis. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-16-000033:notes:271]
Business Combinations

[0000106040-16-000033:notes:272]
The application of acquisition accounting to a business combination requires that the Company identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the excess purchase price are based upon preliminary estimates and assumptions and subject to revision when the Company receives final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. The Company will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-16-000033:notes:273]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. The Company recognizes the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). The Company generally assesses the estimated fair values of acquired intangibles using a combination of valuation techniques. To estimate fair value, the Company is required make certain estimates and assumptions, including future economic and market conditions, revenue growth, market share, operating costs and margins, and risk-adjusted discount rates. These estimates require significant judgment and are based on historical data, various internal estimates, and external sources. The Company’s assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-16-000033:notes:274]
Revenue and Accounts Receivable

[0000106040-16-000033:notes:275]
Revenue is recognized when the title and risk of loss have passed to the customer, there is persuasive evidence of an arrangement, delivery has occurred, or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured. The Company establishes provisions against revenue and cost of revenue for estimated sales returns in the same period that the related revenue is recognized based on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-16-000033:notes:276]
In accordance with standard industry practice, the Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return, and the Company provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. At the time the Company recognizes revenue to resellers and OEMs, a reduction of revenue is recorded for estimated price protection and/or returns until the resellers sell such inventory to their customers and the Company also records a reduction of revenue for the other programs in effect. The Company bases these adjustments on several factors including anticipated price decreases during the reseller holding period, reseller’s sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for the Company’s products or market conditions differ from the Company’s expectations, the Company’s operating results could be materially affected. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue.

[0000106040-16-000033:notes:277]
Revenue from patent licensing arrangements is recognized when earned, estimable and realizable. The timing of revenue recognition is dependent on the terms of each license agreement and on the timing of sales of licensed products. The Company generally recognizes royalty revenue when it is reported to the Company by its licensees, which is generally one quarter in arrears from the licensees’ sales of licensed products. For licensing fees that are not determined by the licensees’ sales, the Company generally recognizes license fee revenue on a straight-line basis over the life of the license.

[0000106040-16-000033:notes:278]
Some of the Company’s revenue arrangements are multiple-element arrangements because they are generally comprised of product, software and support services or multiple distinct licenses. For multiple-element arrangements, the Company evaluates whether each deliverable should be accounted for as a separate unit of accounting. For multiple-element arrangements that include support or software elements, the Company analyzes whether tangible products containing software and non-software components function together and therefore should be excluded from industry-specific software revenue recognition guidance. For all multiple-element arrangements, the Company allocates revenue to each element, or the software elements as a group, based on the relative selling price determined in accordance with the Company’s normal pricing and discounting practices for the specific element when sold separately. For multiple-element license agreements that include more than one license to distinct technology that are separate units of accounting, the Company allocates revenue to each license based on the relative selling price of each deliverable. License fees related to existing technology with no continuing performance obligations are generally recognized upon license commencement and other license fees are generally recognized on a straight-line basis over the life of the license. The Company primarily uses an estimate of selling price to allocate revenue for multiple-element license agreements based upon similar licenses, historical and estimated future sales volume, duration, and market conditions.

[0000106040-16-000033:notes:279]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-16-000033:notes:280]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. The Company sold trade accounts receivable and received cash proceeds of $225 million, $269 million and $187 million during 2016, 2015 and 2014, respectively. The discounts on the sales of trade accounts receivables were not material and were recorded within interest expense in the consolidated statements of income.

[0000106040-16-000033:notes:281]
Warranty

[0000106040-16-000033:notes:282]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected.

[0000106040-16-000033:notes:283]
Litigation and Other Contingencies

[0000106040-16-000033:notes:284]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 6 to the consolidated financial statements for additional disclosures related to the Company’s litigation.

[0000106040-16-000033:notes:285]
Research and Development Expense

[0000106040-16-000033:notes:286]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-16-000033:notes:287]
The following table presents the computation of basic and diluted income per common share for 2016, 2015 and 2014:

[0000106040-16-000033:notes:288]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions, except per share data) |
| Net income | $ | 242 |  |  | $ | 1,465 |  |  | $ | 1,617 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 239 |  |  | 232 |  |  | 235 |  |
| Employee stock options, RSUs, PSUs, ESPP | 3 |  |  | 5 |  |  | 7 |  |
| Diluted | 242 |  |  | 237 |  |  | 242 |  |
| Income per common share: |  |  |  |  |  |
| Basic | $ | 1.01 |  |  | $ | 6.31 |  |  | $ | 6.88 |  |
| Diluted | $ | 1.00 |  |  | $ | 6.18 |  |  | $ | 6.68 |  |
| Anti-dilutive potential common shares excluded(1) | 5 |  |  | 1 |  |  | 2 |  |

[0000106040-16-000033:notes:289]
| (1) | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-16-000033:notes:290]
Stock-based Compensation

[0000106040-16-000033:notes:291]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. The Company accounts for stock appreciation rights (“SARs”) as liability awards based upon management’s intention to settle such awards in cash. All SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. The Company is required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and the results of operations could be materially affected. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics. Once the performance metrics are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period.

[0000106040-16-000033:notes:292]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-16-000033:notes:293]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of stockholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is comprised of unrealized gains and losses on foreign exchange contracts designated as cash flow hedges, foreign currency translation gains and actuarial losses related to pensions.

[0000106040-16-000033:notes:294]
The following table illustrates the changes in the balances of each component of accumulated comprehensive income (loss) for 2016 and 2015:

[0000106040-16-000033:notes:295]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Foreign Exchange Contracts |  | Total Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 12 |  |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | (74 | ) |  | (74 | ) |
| Amounts reclassified from accumulated other comprehensive income | (2 | ) |  | — |  |  | 44 |  |  | 42 |  |
| Net current-period other comprehensive loss | (2 | ) |  | — |  |  | (30 | ) |  | (32 | ) |
| Balance at July 3, 2015 | 5 |  |  | — |  |  | (25 | ) |  | (20 | ) |
| Other comprehensive income before reclassifications | (73 | ) |  | 74 |  |  | 48 |  |  | 49 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | 51 |  |  | 51 |  |
| Income tax benefit related to items of other comprehensive income (loss) | 23 |  |  | — |  |  | — |  |  | 23 |  |
| Net current-period other comprehensive income (loss) | (50 | ) |  | 74 |  |  | 99 |  |  | 123 |  |
| Balance at July 1, 2016 | $ | (45 | ) |  | $ | 74 |  |  | $ | 74 |  |  | $ | 103 |  |

[0000106040-16-000033:notes:296]
The following table illustrates the significant amounts reclassified out of each component of accumulated comprehensive income (loss) for 2016, 2015 and 2014:

[0000106040-16-000033:notes:297]
| AOCI Component |  | 2016 |  | 2015 |  | 2014 |  | Statement of OperationsLine Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on cash flow hedging activities: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (17 | ) |  | $ | (44 | ) |  | $ | (38 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | (34 | ) |  | — |  |  | — |  |  | Research and development |
| Unrealized holding loss on cash flow hedging activities |  | (51 | ) |  | (44 | ) |  | (38 | ) |  |  |
| Total reclassifications for the period |  | $ | (51 | ) |  | $ | (44 | ) |  | $ | (38 | ) |  |  |

[0000106040-16-000033:notes:298]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-16-000033:notes:299]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and postretirement plans in the consolidated balance sheets, with changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. See Note 15 to the consolidated financial statements for additional disclosures related to the Company’s pensions and other post-retirement benefit plans.

[0000106040-16-000033:notes:300]
Use of Estimates

[0000106040-16-000033:notes:301]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-16-000033:notes:302]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans are immaterial to the Company’s consolidated financial statements.

[0000106040-16-000033:notes:303]
Obligations and Funded Status

[0000106040-16-000033:notes:304]
The following table presents the unfunded amounts related to the Japanese defined pension plans as recognized on the Company’s consolidated balance sheets as of July 1, 2016 and July 3, 2015:

[0000106040-16-000033:notes:305]
|  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Current liabilities | $ | — |  |  | $ | 1 |  |
| Non-current liabilities | 114 |  |  | 45 |  |
| Net amount recognized | $ | 114 |  |  | $ | 46 |  |

[0000106040-16-000033:notes:306]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $326 million at July 1, 2016. As of July 1, 2016, actuarial gains for the Japanese defined benefit pension plans of $57 million are included in accumulated other comprehensive income (loss) in the consolidated balance sheet. There were no prior service credits for the defined benefit pension plans recognized in accumulated other comprehensive income (loss) in the consolidated balance sheet as of July 1, 2016.

[0000106040-16-000033:notes:307]
Assumptions

[0000106040-16-000033:notes:308]
Weighted-Average Assumptions

[0000106040-16-000033:notes:309]
The weighted-average actuarial assumptions used to determine benefit obligations for the Japanese defined benefit pension plans were as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:310]
|  | 2016 |  | 2015 |  | 2014 |
| Discount rate | 0.4 | % |  | 1.3 | % |  | 1.6 | % |
| Rate of compensation increase | 0.8 | % |  | 0.9 | % |  | 1.0 | % |

[0000106040-16-000033:notes:311]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows for 2016, 2015 and 2014:

[0000106040-16-000033:notes:312]
|  | 2016 |  | 2015 |  | 2014 |
| Discount rate | 1.3 | % |  | 1.6 | % |  | 1.6 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 3.5 | % |  | 3.5 | % |
| Rate of compensation increase | 0.9 | % |  | 1.0 | % |  | 0.9 | % |

[0000106040-16-000033:notes:313]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to AA or higher bond ratings that match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-16-000033:notes:314]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. Management’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-16-000033:notes:315]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-16-000033:notes:316]
Plan Assets

[0000106040-16-000033:notes:317]
Investment Policies and Strategies

[0000106040-16-000033:notes:318]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 35% in equity securities, 62% in debt securities and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-16-000033:notes:319]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-16-000033:notes:320]
The following tables present the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of July 1, 2016 and July 3, 2015:

[0000106040-16-000033:notes:321]
|  | July 1, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |
| Equity securities(1) | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Equity commingled/mutual funds(1)(2) | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 129 |  |  | — |  |  | 129 |  |
| Cash and short-term investments | 9 |  |  | 3 |  |  | — |  |  | 12 |  |
| Fair value of plan assets | $ | 8 |  |  | $ | 204 |  |  | $ | — |  |  | $ | 212 |  |

[0000106040-16-000033:notes:322]
|  | July 3, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 112 |  |  | — |  |  | 112 |  |
| Cash and short-term investments | 6 |  |  | 2 |  |  | — |  |  | 8 |  |
| Fair value of plan assets | $ | 6 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 185 |  |

[0000106040-16-000033:notes:323]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-16-000033:notes:324]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-16-000033:notes:325]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-16-000033:notes:326]
Assets held in defined benefit plans in the Philippines, Taiwan and Thailand were less than $1 million and are not presented in the above tables. There were no significant movements of assets between any level categories in 2016, 2015 or 2014.

[0000106040-16-000033:notes:327]
Fair Value Valuation Techniques

[0000106040-16-000033:notes:328]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-16-000033:notes:329]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-16-000033:notes:330]
Cash includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-16-000033:notes:331]
Cash Flows

[0000106040-16-000033:notes:332]
Contributions

[0000106040-16-000033:notes:333]
The Company’s expected employer contributions for 2017 are $9 million for its Japanese defined benefit pension plans.

[0000106040-16-000033:notes:334]
Estimated Future Benefits Payments

[0000106040-16-000033:notes:335]
Annual benefit payments from the Japanese defined benefit pension plans are estimated to range from $6 million to $13 million annually over the next five years.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-16-000033:notes:336]
|  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and buildings | $ | 1,900 |  |  | $ | 1,441 |  |
| Machinery and equipment | 7,070 |  |  | 6,520 |  |
| Furniture and fixtures | 110 |  |  | 71 |  |
| Leasehold improvements | 307 |  |  | 276 |  |
| Construction-in-process | 245 |  |  | 296 |  |
| Total property, plant and equipment | 9,632 |  |  | 8,604 |  |
| Accumulated depreciation | (6,129 | ) |  | (5,639 | ) |
| Property, plant and equipment, net | $ | 3,503 |  |  | $ | 2,965 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-16-000033:notes:337]
Quarterly Results of Operations (unaudited)

[0000106040-16-000033:notes:338]
|  | First (1) |  | Second (2) |  | Third (3) |  | Fourth (4) |
|  | (in millions, except per share amounts) |
| 2016 |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,360 |  |  | $ | 3,317 |  |  | $ | 2,822 |  |  | $ | 3,495 |  |
| Gross profit | 955 |  |  | 906 |  |  | 753 |  |  | 821 |  |
| Operating income | 322 |  |  | 251 |  |  | 88 |  |  | (195 | ) |
| Net income | 283 |  |  | 251 |  |  | 74 |  |  | (366 | ) |
| Basic income per common share | $ | 1.23 |  |  | $ | 1.08 |  |  | $ | 0.32 |  |  | $ | (1.40 | ) |
| Diluted income per common share | $ | 1.21 |  |  | $ | 1.07 |  |  | $ | 0.32 |  |  | $ | (1.40 | ) |

[0000106040-16-000033:notes:339]
| (1) | Includes $56 million of employee termination, asset impairment and other charges related to business realignment. |

[0000106040-16-000033:notes:340]
| (2) | Includes $27 million of employee termination, asset impairment and other charges related to business realignment, $32 million of charges related to interest on an arbitration award and $27 million of costs related to the acquisition of SanDisk. |

[0000106040-16-000033:notes:341]
| (3) | Includes $140 million of employee termination, asset impairment and other charges related to the closure of the Company’s Odawara Facility and business realignment and $16 million of costs related to the acquisition of SanDisk. |

[0000106040-16-000033:notes:342]
| (4) | Includes $122 million of employee termination, asset impairment and other charges related to the closure of the Company’s Odawara Facility and Restructuring Plan, and $116 million of costs related to the acquisition of SanDisk. |

[0000106040-16-000033:notes:343]
|  | First (1) |  | Second (2) |  | Third (3) |  | Fourth (4) |
|  | (in millions, except per share amounts) |
| 2015 |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,943 |  |  | $ | 3,888 |  |  | $ | 3,550 |  |  | $ | 3,191 |  |
| Gross profit | 1,149 |  |  | 1,110 |  |  | 1,032 |  |  | 930 |  |
| Operating income | 469 |  |  | 466 |  |  | 421 |  |  | 255 |  |
| Net income | 423 |  |  | 438 |  |  | 384 |  |  | 220 |  |
| Basic income per common share | $ | 1.81 |  |  | $ | 1.88 |  |  | $ | 1.66 |  |  | $ | 0.95 |  |
| Diluted income per common share | $ | 1.76 |  |  | $ | 1.84 |  |  | $ | 1.63 |  |  | $ | 0.94 |  |

[0000106040-16-000033:notes:344]
| (1) | Includes $9 million of employee termination, asset impairment and other charges and $14 million of charges related to interest on an arbitration award. |

[0000106040-16-000033:notes:345]
| (2) | Includes $53 million of employee termination, asset impairment and other charges, $1 million of charges related to interest on an arbitration award and a $37 million gain on flood-related insurance recovery. |

[0000106040-16-000033:notes:346]
| (3) | Includes $10 million of employee termination, asset impairment and other charges. |

[0000106040-16-000033:notes:347]
| (4) | Includes $104 million of employee termination, asset impairment and other charges. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000106040-16-000033:notes:348]
Related Parties

[0000106040-16-000033:notes:349]
The Company owns 49.9% of each entity within Flash Ventures and accounts for its ownership position under the equity method of accounting. The Company’s obligations with respect to Flash Ventures’ master lease agreements, take-or-pay supply arrangements and R&D cost sharing are described in Note 4 to the consolidated financial statements. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-16-000033:notes:350]
From the SanDisk Closing Date through the Company’s year-end, the Company purchased NAND flash memory wafers from Flash Ventures and made prepayments and loans to Flash Ventures totaling $387 million and received loan repayments from Flash Ventures of $16 million. At July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $168 million.

[0000106040-16-000033:notes:351]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits), based upon the exchange rate at July 1, 2016, as a result of its involvement with Flash Ventures, is presented below. Flash Ventures’ investments are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-16-000033:notes:352]
|  | July 1, 2016 |
|  | (in millions) |
| Notes receivable | $ | 563 |  |
| Equity investments | 608 |  |
| Operating lease guarantees | 1,151 |  |
| Prepayments | 34 |  |
| Maximum estimable loss exposure | $ | 2,356 |  |

[0000106040-16-000033:notes:353]
As of July 1, 2016, the Company’s retained earnings included undistributed earnings of Flash Ventures of $2 million.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000106040-16-000033:notes:354]
The following tables summarize the Company’s operations by geographic area:

[0000106040-16-000033:notes:355]
| Net revenue(1): |  |  |  |  |  |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| United States | $ | 3,651 |  |  | $ | 3,054 |  |  | $ | 3,013 |  |
| China | 2,413 |  |  | 2,726 |  |  | 3,499 |  |
| Asia | 3,989 |  |  | 4,552 |  |  | 4,756 |  |
| Europe, Middle East and Africa | 2,664 |  |  | 3,169 |  |  | 3,117 |  |
| Other | 277 |  |  | 1,071 |  |  | 745 |  |
| Total | $ | 12,994 |  |  | $ | 14,572 |  |  | $ | 15,130 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-16-000033:notes:356]
|  | July 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 569 |  |  | $ | 168 |  |
| Work-in-process | 589 |  |  | 500 |  |
| Finished goods | 971 |  |  | 700 |  |
| Total inventories | $ | 2,129 |  |  | $ | 1,368 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-16-000033:notes:357]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve as of July 1, 2016:

[0000106040-16-000033:notes:358]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 27, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charges | 82 |  |  | 12 |  |  | 94 |  |
| Cash payments | (72 | ) |  | (2 | ) |  | (74 | ) |
| Non-cash items and other | — |  |  | (10 | ) |  | (10 | ) |
| Accrual balance at July 3, 2015 | 10 |  |  | — |  |  | 10 |  |
| Charges | 74 |  |  | 29 |  |  | 103 |  |
| Cash payments | (67 | ) |  | (23 | ) |  | (90 | ) |
| Non-cash items and other | (6 | ) |  | (3 | ) |  | (9 | ) |
| Accrual balance at July 1, 2016 | $ | 11 |  |  | $ | 3 |  |  | $ | 14 |  |

[0000106040-16-000033:notes:359]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Charges | $ | 58 |  |  | $ | 19 |  |  | $ | 77 |  |
| Cash payments | (32 | ) |  | (19 | ) |  | (51 | ) |
| Accrual balance at July 1, 2016 | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |

[0000106040-16-000033:notes:360]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Charges | $ | 119 |  |  | $ | 9 |  |  | $ | 128 |  |
| Cash payments | (104 | ) |  | (10 | ) |  | (114 | ) |
| Non-cash items | (1 | ) |  | 1 |  |  | — |  |
| Accrual balance at July 1, 2016 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |

[0000106040-16-000033:notes:361]
The Company recorded the following charges related to employee terminations benefits, asset impairment and other charges:

[0000106040-16-000033:notes:362]
|  | 2016 |  | 2015 |  | 2014 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |
| Restructuring Plan | $ | 77 |  |  | $ | — |  |  | $ | — |  |
| Closure of Foreign Manufacturing Facility | 128 |  |  | — |  |  | — |  |
| Business Realignment | 103 |  |  | 94 |  |  | 33 |  |
| Total employee termination and other charges | 308 |  |  | 94 |  |  | 33 |  |
| Asset impairment: |  |  |  |  |  |
| Restructuring Plan | 5 |  |  | — |  |  | — |  |
| Closure of Foreign Manufacturing Facility | 24 |  |  | — |  |  | — |  |
| Business Realignment | 8 |  |  | 82 |  |  | 62 |  |
| Total asset impairment | 37 |  |  | 82 |  |  | 62 |  |
| Total employee termination, asset impairment and other charges | $ | 345 |  |  | $ | 176 |  |  | $ | 95 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-16-000033:notes:363]
The following table summarizes stock option activity under the 2004 Performance Incentive Plan and any assumed plan, including the SanDisk 2013 Incentive Plan, during the last three fiscal years:

[0000106040-16-000033:notes:364]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 28, 2013 | 11.9 |  |  | $ | 29.47 |  |  |  |  |  |
| Granted | 1.6 |  |  | 68.96 |  |  |  |  |  |
| Assumed | 1.7 |  |  | 38.18 |  |  |  |  |  |
| Exercised | (4.5 | ) |  | 25.22 |  |  |  |  |  |
| Canceled or expired | (0.6 | ) |  | 67.23 |  |  |  |  |  |
| Options outstanding at June 27, 2014 | 10.1 |  |  | 37.03 |  |  |  |  |  |
| Granted | 1.2 |  |  | 94.10 |  |  |  |  |  |
| Assumed | 0.1 |  |  | 3.49 |  |  |  |  |  |
| Exercised | (4.1 | ) |  | 31.90 |  |  |  |  |  |
| Canceled or expired | (0.5 | ) |  | 56.41 |  |  |  |  |  |
| Options outstanding at July 3, 2015 | 6.8 |  |  | 50.00 |  |  |  |  |  |
| Granted | 1.7 |  |  | 82.68 |  |  |  |  |  |
| Assumed | 2.9 |  |  | 38.37 |  |  |  |  |  |
| Exercised | (1.7 | ) |  | 27.43 |  |  |  |  |  |
| Canceled or expired | (0.7 | ) |  | 66.03 |  |  |  |  |  |
| Options outstanding at July 1, 2016 | 9.0 |  |  | 55.74 |  |  | 3.9 |  | $ | 60 |  |
| Exercisable at July 1, 2016 | 5.0 |  |  | 47.11 |  |  | 2.8 |  | $ | 45 |  |
| Vested and expected to vest after July 1, 2016 | 8.8 |  |  | 55.42 |  |  | 3.9 |  | $ | 60 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-16-000033:notes:365]
The following table summarizes RSU and PSU activity under the 2004 Performance Incentive Plan and any assumed plan, including the SanDisk 2013 Incentive Plan, during the last three fiscal years:

[0000106040-16-000033:notes:366]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
|  | (in millions) |  |  |
| RSUs and PSUs outstanding at June 28, 2013 | 3.6 |  |  | $ | 35.82 |  |
| Granted | 1.4 |  |  | 69.08 |  |
| Assumed | 0.2 |  |  | 62.73 |  |
| Vested | (1.3 | ) |  | 33.61 |  |
| Forfeited | (0.2 | ) |  | 47.62 |  |
| RSUs and PSUs outstanding at June 27, 2014 | 3.7 |  |  | 49.77 |  |
| Granted | 1.3 |  |  | 100.13 |  |
| Vested | (1.7 | ) |  | 42.24 |  |
| Forfeited | (0.3 | ) |  | 67.31 |  |
| RSUs and PSUs outstanding at July 3, 2015 | 3.0 |  |  | 73.80 |  |
| Granted | 2.7 |  |  | 61.32 |  |
| Assumed | 12.5 |  |  | 32.14 |  |
| Vested | (2.0 | ) |  | 56.11 |  |
| Forfeited | (0.5 | ) |  | 62.09 |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | 41.92 |  |
| Expected to vest after July 1, 2016 | 14.2 |  |  | 42.27 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000106040-16-000033:notes:367]
WESTERN DIGITAL CORPORATION

[0000106040-16-000033:notes:368]
SCHEDULE II — CONSOLIDATED VALUATION AND QUALIFYING ACCOUNTS

[0000106040-16-000033:notes:369]
(in millions)

[0000106040-16-000033:notes:370]
|  | Allowance for Doubtful Accounts |
| Balance at June 28, 2013 | $ | 9 |  |
| Additions charges to operations | 3 |  |
| Deductions | (1 | ) |
| Balance at June 27, 2014 | 11 |  |
| Deductions | (4 | ) |
| Balance at July 3, 2015 | 7 |  |
| Balance assumed as a result of SanDisk acquisition | 6 |  |
| Deductions | (3 | ) |
| Balance at July 1, 2016 | $ | 10 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-16-000033:notes:371]
Shareholders’ Equity

[0000106040-16-000033:notes:372]
Stock Incentive Plans

[0000106040-16-000033:notes:373]
2004 Performance Incentive Plan

[0000106040-16-000033:notes:374]
The types of awards that may be granted under the amended and restated 2004 Performance Incentive Plan include stock options, SARs, RSUs, PSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2004 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2004 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2004 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2004 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics. Once the performance metrics are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-16-000033:notes:375]
Outstanding RSU awards have dividend equivalent rights which entitle holders of outstanding RSUs to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-16-000033:notes:376]
As of July 1, 2016, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2004 Performance Incentive Plan was 65.8 million shares. Shares issued in respect of stock options and SARs granted under the 2004 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas shares issued in respect of any other type of award granted through November 7, 2012 under the plan count against the plan’s share limit as 1.35 shares for every one share actually issued in connection with such award. Shares issued in respect of awards, other than options and SARs, granted on or after November 8, 2012 count against the plan’s share limit as 1.72 shares for every one share actually issued in connection with such award. The 2004 Performance Incentive Plan was extended in 2013 and will terminate on August 4, 2025 unless terminated earlier by the Company’s Board of Directors (the “Board”).

[0000106040-16-000033:notes:377]
Acquired Plan

[0000106040-16-000033:notes:378]
In connection with the Merger, the Company assumed the SanDisk 2013 Incentive Plan. Options eligible for exercise may be exercised for shares of the Company’s common stock at any time prior to the expiration of the seven-year option term or any earlier termination of those options in connection with the optionee’s cessation of service with the Company. Outstanding RSU awards under the SanDisk 2013 Incentive Plan have dividend equivalent rights which entitle holders of RSUs to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. Dividend equivalent rights are accumulated and paid when the underlying shares vest.

[0000106040-16-000033:notes:379]
The Company assumed all of the unvested and underwater vested stock options and RSUs outstanding under SanDisk’s stock plans as of the SanDisk Closing Date. In addition, the Company assumed 14.4 million shares that were available to be granted to SanDisk employees under the SanDisk 2013 Incentive Plan. The assumed stock options and RSUs were converted into equivalent stock options and RSUs with respect to shares of the Company’s common stock using an equity award exchange ratio specified in the Merger agreement.

[0000106040-16-000033:notes:380]
Employee Stock Purchase Plan

[0000106040-16-000033:notes:381]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock on either the first day of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-16-000033:notes:382]
Stock-Based Compensation Expense

[0000106040-16-000033:notes:383]
For purposes of this footnote, references to RSUs include PSUs. The following table presents the Company’s stock-based compensation and related tax benefit for 2016, 2015 and 2014:

[0000106040-16-000033:notes:384]
Included in the stock-based compensation expense for 2016 was $29 million related to converted awards in connection with the Merger. As of July 1, 2016, total compensation cost related to unvested stock options was $76 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.3 years. As of July 1, 2016, total compensation cost related to ESPP rights issued to employees but not yet recognized was $45 million and will be amortized on a straight-line basis over a weighted average service period of approximately 1.8 years.

[0000106040-16-000033:notes:385]
As of July 1, 2016, the aggregate unamortized fair value of all unvested RSUs and PSUs was $498 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 2.5 years, assuming the performance metrics are met for the PSUs.

[0000106040-16-000033:notes:386]
Stock Option Activity

[0000106040-16-000033:notes:387]
Options granted during 2016 had a weighted average fair value per share of $22.54. As of July 1, 2016, the Company had options outstanding to purchase an aggregate of 5.2 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $60 million at that date. During 2016, 2015 and 2014, the aggregate intrinsic value of options exercised under the 2004 Performance Incentive Plan was $57 million, $283 million and $247 million, respectively, determined as of the date of exercise.

[0000106040-16-000033:notes:388]
RSU and PSU Activity

[0000106040-16-000033:notes:389]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The aggregate value of RSUs and PSUs that became fully-vested during 2016, 2015 and 2014 was $144 million, $170 million and $89 million, respectively, determined as of the vest date. The fair value of the shares underlying the RSU and PSU awards at the date of grant was $163 million, $125 million and $95 million in 2016, 2015 and 2014, respectively.

[0000106040-16-000033:notes:390]
During 2016, the Company granted 1.2 million PSUs at a weighted average grant-date fair value of $53.59 per share. The total number of PSUs outstanding as of July 1, 2016 was 1.2 million with a weighted average fair value per share of $55.73.

[0000106040-16-000033:notes:391]
SARs Activity

[0000106040-16-000033:notes:392]
During 2016, 2015 and 2014, the Company recognized an $18 million benefit, $3 million benefit and $36 million expense, respectively, related to adjustments to fair market value of SARs. The tax expense realized as a result of the aforementioned SARs benefit was $2 million during 2016, as compared to no tax benefit or expense realized in 2015 and tax benefits realized of $7 million in 2014. The Company’s SARs will be settled in cash upon exercise. The Company had a total liability of $20 million and $41 million related to SARs included in accrued expenses in the consolidated balance sheet as of July 1, 2016 and July 3, 2015, respectively.

[0000106040-16-000033:notes:393]
As of July 1, 2016, all SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. As of July 1, 2016, 0.5 million SARs were outstanding with a weighted average exercise price of $7.90. There were no SARs granted in 2016, 2015 and 2014, and all other SARs activity was immaterial to the consolidated financial statements for the year ended July 1, 2016.

[0000106040-16-000033:notes:394]
Vested Options, RSUs and PSUs

[0000106040-16-000033:notes:395]
The total grant date fair value of options, RSUs and PSUs vested during the period was as follows:

[0000106040-16-000033:notes:396]
|  | Years ended |
|  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
|  | (in millions) |
| Options | $ | 61 |  |  | $ | 62 |  |  | $ | 96 |  |
| RSUs and PSUs | 113 |  |  | 65 |  |  | 46 |  |
| Total grant date fair value of options, RSUs and PSUs vested during the period | $ | 174 |  |  | $ | 127 |  |  | $ | 142 |  |

[0000106040-16-000033:notes:397]
Fair Value Valuation Assumptions

[0000106040-16-000033:notes:398]
Stock Option Grants — Binomial Model

[0000106040-16-000033:notes:399]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of highly subjective assumptions. The Company uses historical data to estimate exercise, employee termination and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. The fair value of stock options granted during 2016, 2015 and 2014 was estimated using the following weighted average assumptions:

[0000106040-16-000033:notes:400]
|  | 2016 |  | 2015 |  | 2014 |
| Suboptimal exercise factor | 2.71 |  | 2.52 |  | 2.07 |
| Range of risk-free interest rates | 0.25% to 2.09% |  | 0.11% to 2.16% |  | 0.10% to 2.44% |
| Range of expected stock price volatility | 0.28 to 0.49 |  | 0.23 to 0.47 |  | 0.27 to 0.50 |
| Weighted-average expected volatility | 0.35 |  | 0.36 |  | 0.43 |
| Post-vesting termination rate | 0.47% |  | 1.25% |  | 3.10% |
| Dividend yield | 2.61% |  | 1.69% |  | 1.58% |
| Fair value | $22.54 |  | $32.19 |  | $24.14 |
| Weighted-average expected term (in years) | 4.7 |  | 5.8 |  | 5.0 |

[0000106040-16-000033:notes:401]
RSU and PSU Grants

[0000106040-16-000033:notes:402]
The fair value of the Company’s RSU and PSU awards granted, excluding unvested RSU awards assumed through acquisitions, was based upon the closing price of the Company’s stock price on the date of grant.

[0000106040-16-000033:notes:403]
ESPP — Black-Scholes-Merton Model

[0000106040-16-000033:notes:404]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are granted on either June 1st or December 1st of each year.

[0000106040-16-000033:notes:405]
The fair values of all ESPP purchase rights granted on or prior to July 1, 2016 have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-16-000033:notes:406]
|  | 2016 |  | 2015 |  | 2014 |
| Option life (in years) | 1.27 |  | 1.26 |  | 1.24 |
| Risk-free interest rate | 0.82% |  | 0.45% |  | 0.26% |
| Stock price volatility | 0.38 |  | 0.26 |  | 0.31 |
| Dividend yield | 3.92% |  | 2.34% |  | 1.64% |
| Fair value | $9.91 |  | $14.50 |  | $14.62 |

[0000106040-16-000033:notes:407]
Stock Repurchase Program

[0000106040-16-000033:notes:408]
The Board previously authorized $5.0 billion for the repurchase of the Company’s common stock and approved the extension of its stock repurchase program to February 3, 2020. Effective October 21, 2015, in connection with the Merger, the stock repurchase program was suspended. The Company repurchased 0.7 million shares for a total cost of $60 million during 2016. The remaining amount available to be purchased under the Company’s stock repurchase program as of July 1, 2016 was $2.1 billion.

[0000106040-16-000033:notes:409]
Stock Reserved for Issuance

[0000106040-16-000033:notes:410]
The following table summarizes all common stock reserved for issuance at July 1, 2016:

[0000106040-16-000033:notes:411]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 56.6 |  |
| ESPP | 9.4 |  |
| Convertible notes | 0.3 |  |
| Total | 66.3 |  |

[0000106040-16-000033:notes:412]
Dividends to Shareholders

[0000106040-16-000033:notes:413]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. In 2016, the Company declared aggregate cash dividends of $2.00 per share of the Company’s common stock, totaling $490 million, of which $348 million was paid during 2016. The Company also paid $116 million of dividends in 2016 related to dividends accrued in 2015. On August 3, 2016, the Company declared a cash dividend of $0.50 per share to shareholders of record as of September 30, 2016, which will be paid on October 17, 2016. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SubsequentEventsTextBlock

[0000106040-16-000033:notes:414]
Subsequent Event

[0000106040-16-000033:notes:415]
On July 21, 2016, the Company paid in full $3.0 billion aggregate principal amount outstanding of the Additional Bridge Facility, together with accrued interest. For additional information on debt, see Note 3 to the consolidated financial statements.

[0000106040-16-000033:notes:416]
On August 17, 2016 the Company issued a new $3.0 billion U.S. dollar-denominated Term Loan B-1 at an interest rate of LIBOR plus 3.75% or a base rate plus 2.75%. Principal payments of 0.25% are due quarterly beginning September 30, 2016 with the balance due on April 29, 2023. In connection with this transaction, the Company settled the previous U.S. Term Loan B tranche with the proceeds of this new loan and a voluntary cash prepayment of $750 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-16-000033:notes:417]
Supplemental Financial Statement Data

[0000106040-16-000033:notes:418]
Depreciation expense of property, plant and equipment totaled $888 million, $809 million and $914 million in 2016, 2015 and 2014, respectively.


## wdc:BusinessSegmentGeographicInformationAndMajorCustomersTextBlock

[0000106040-16-000033:notes:419]
Business Segment, Geographic Information and Concentration of Risk

[0000106040-16-000033:notes:420]
Segment Information

[0000106040-16-000033:notes:421]
The Company historically was organized into two operating segments that have been aggregated into one reportable operating segment, the hard drive business. In October 2015, the Company received a decision from the Ministry of Commerce of the People’s Republic of China which enables it to integrate substantial portions of its HGST and WD subsidiaries. In May 2016, the Company completed its acquisition of SanDisk. With the integration and acquisition, the Company is going through a transformation into a storage solutions company with global scale, extensive product and technology assets and expertise in non-volatile memory within the data storage industry. As part of the transformation, the Company introduced a new operating model during the fourth quarter of 2016 that incorporates the HGST, WD and SanDisk businesses. As of fiscal year-end, the Company remained in a transition period from the existing operating model to the new operating model such that discrete information was not yet available that aligns with the revised management structure under the new operating model. Therefore as of July 1, 2016, the Company concluded that it has one reportable segment. The Company will continue to assess its operating segments and reportable segments under the new operating model in future periods once transition is complete.

[0000106040-16-000033:notes:422]
Geographic Information

[0000106040-16-000033:notes:423]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0000106040-16-000033:notes:424]
Concentration and Credit Risk

[0000106040-16-000033:notes:425]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. For 2016, no single customer accounted for 10% or more of the Company’s net revenue. For both 2015 and 2014, Hewlett-Packard Company accounted for 11% of the Company’s net revenue. Sales to the Company’s top ten customers accounted for 43%, 44% and 44% of the Company’s net revenue for 2016, 2015 and 2014, respectively.

[0000106040-16-000033:notes:426]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. At July 1, 2016, no single customer accounted for 10% or more of the Company’s net accounts receivable. As of July 3, 2015, the Company had two customers that accounted for 30% of the Company’s net accounts receivable. At July 1, 2016 and July 3, 2015, the Company had reserves for potential credit losses of $10 million and $7 million, respectively, and net accounts receivable of $1.5 billion and $1.5 billion, respectively.

[0000106040-16-000033:notes:427]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-16-000033:notes:428]
Supplier Concentration

[0000106040-16-000033:notes:429]
All of the Company’s flash memory system products require silicon wafers for the memory and controller components. The Company’s memory wafers are currently supplied almost entirely from Flash Ventures and the controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-16-000033:notes:430]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## wdc:DefinedContributionPlanDisclosureTextBlock

[0000106040-16-000033:notes:431]
Western Digital Corporation 401(k) Plan

[0000106040-16-000033:notes:432]
The Company adopted the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. The Company makes a basic matching contribution on behalf of each participating eligible employee equal to fifty percent (50%) of the eligible participant’s combined pre-tax contributions and deferrals for the contribution cycle, not to exceed 5% of the eligible participant’s compensation; provided, however, that each eligible participant shall receive a minimum annual basic matching contribution equal to fifty percent (50%) of the first $4,000 of combined pre-tax contributions and deferrals for any calendar year. The Plan was amended effective January 1, 2013 to provide for an alternate year-end true-up matching contribution such that participants who save at least 5% of their eligible compensation for the year receive a minimum annual matching contribution equal to 2.5% of eligible compensation (up to Internal Revenue Service (“IRS”) limitations). Company contributions vest over a 5-year period of employment. For 2016, 2015 and 2014, the Company made Plan contributions of $20 million, $22 million and $21 million, respectively.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-16-000033:notes:433]
Employee Termination, Asset Impairment and Other Charges

[0000106040-16-000033:notes:434]
Restructuring Plan

[0000106040-16-000033:notes:435]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (the “Restructuring Plan”). The Restructuring Plan consists of asset and footprint reduction, product roadmap consolidation and organization rationalization.

[0000106040-16-000033:notes:436]
The Company expects the Restructuring Plan to be substantially completed by the end of calendar year 2017 and it is expected to result in total pre-tax charges of $400 million. These charges are expected to consist of $185 million in employee termination benefits, $125 million in asset charges and $90 million in other related costs. $275 million of these charges are expected to be cash expenditures. All of the components of the Restructuring Plan are not finalized, and actual costs, cash expenditures and timing may vary from the Company’s estimates due to changes in the scope or assumptions underlying the Restructuring Plan.

[0000106040-16-000033:notes:437]
In 2016, the Company recognized $82 million of expenses related to the Restructuring Plan, which consisted of $58 million in employee termination benefits, $19 million in contract termination and other charges, and $5 million in asset impairment. In addition, the Company recognized $22 million of accelerated depreciation charges on facility assets in cost of revenue.

[0000106040-16-000033:notes:438]
Closure of Foreign Manufacturing Facility

[0000106040-16-000033:notes:439]
In January 2016, the Company announced the closing of its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. In 2016, the Company recognized $152 million of expenses related to the closure of the facility, which consisted of $119 million in employee termination benefits, $24 million in asset impairment and $9 million in contract termination and other charges. In addition, the Company recognized $48 million of accelerated depreciation charges on assets held at the Odawara facility, of which $34 million was recognized in cost of revenue and $14 million was recognized in R&D within the consolidated statements of income. As of July 1, 2016, the Company substantially completed all activities related to the closure of the facility.

[0000106040-16-000033:notes:440]
Business Realignment

[0000106040-16-000033:notes:441]
The Company periodically incurs charges to realign its operations with anticipated market demand. In 2016, the Company recognized $111 million of expenses related to the realignment activities, which consisted of $74 million in employee termination benefits, $8 million in asset impairment and $29 million in contract termination and other charges. In 2015, the Company recognized $176 million of expenses related to the realignment activities, which consisted of $82 million in employee termination benefits, $82 million in asset impairment and $12 million in contract termination and other charges. In 2014, the Company recognized $95 million of expenses related to the realignment activities, which consisted of $27 million in employee termination benefits, $62 million in asset impairment and $6 million in contract termination and other charges.
