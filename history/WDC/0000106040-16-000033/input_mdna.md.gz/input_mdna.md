# WDC MD&A — 0000106040-16-000033


## mdna

[0000106040-16-000033:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-16-000033:mdna:2]
Forward-Looking Statements

[0000106040-16-000033:mdna:3]
Our Company

[0000106040-16-000033:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the IT industry and the infrastructure that enables the proliferation of data in virtually every industry. Our broad portfolio of offerings addresses three categories: Datacenter Devices and Solutions (capacity and performance enterprise HDDs, enterprise SSDs, datacenter software and system solutions); Client Devices (mobile, desktop, gaming and digital video hard drives, client SSDs, embedded products and wafers); and Client Solutions (removable products, hard drive content solutions and flash content solutions). We also generate license and royalty revenue related to our intellectual property which is included in each of the three categories.

[0000106040-16-000033:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Fiscal years 2016 and 2014, which ended on July 1, 2016 and June 27, 2014, respectively, comprised of 52 weeks. Fiscal year 2015, which ended on July 3, 2015, comprised of 53 weeks, with the first quarter consisting of 14 weeks and the second, third and fourth quarters consisting of 13 weeks each.

[0000106040-16-000033:mdna:6]
Recent Developments

[0000106040-16-000033:mdna:7]
Acquisition of SanDisk

[0000106040-16-000033:mdna:8]
On May 12, 2016, we completed the acquisition of SanDisk (the “Merger”), a global leader in NAND flash storage solutions, pursuant to the terms of the Agreement and Plan of Merger, dated October 21, 2015. The Merger is primarily intended to deepen our expertise in non-volatile memory and enable us to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost. The aggregate purchase price of the Merger was $15.59 billion, consisting of $13.77 billion funded with existing cash and cash from new debt, 49 million newly issued shares of our common stock with a fair value of $1.764 billion and $58 million related to the fair value of assumed share-based awards.

[0000106040-16-000033:mdna:9]
For additional information, see Part II, Item 8, Note 16 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:10]
Debt Facilities

[0000106040-16-000033:mdna:11]
In connection with the Merger, we entered into new debt facilities. The proceeds from the new debt facilities were used to finance, in part, the cash portion of the purchase price related to the Merger, refinance certain existing indebtedness of Western Digital and SanDisk, and pay certain transaction costs.

[0000106040-16-000033:mdna:12]
The new debt facilities we entered into aggregated approximately $18.1 billion in principal and consisted of the following:

[0000106040-16-000033:mdna:13]
| • | On April 13, 2016, we completed an offering of our $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). |

[0000106040-16-000033:mdna:14]
| • | On April 29, 2016, we entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and the lenders party thereto, which provides for secured loan facilities consisting of a $4.125 billion term loan facility (the “Term Loan A”), a $3.75 billion term loan facility (the “U.S. Term Loan B”), an €885 million (approximately $987 million based on the currency exchange rate at July 1, 2016) term loan facility (the “Euro Term Loan B” and, together with the U.S. Term Loan B, the “Term Loan B”) and a $1.0 billion revolving credit facility. The Term Loan A and the revolving credit facility have a five-year term. Term Loan B has a term of seven years. On May 12, 2016, concurrent with entering into the new credit agreement, we repaid all outstanding loans, together with accrued interest and related fees, and terminated all commitments under our then-existing credit agreement dated as of January 29, 2014. |

[0000106040-16-000033:mdna:15]
| • | On May 12, 2016, we and our wholly owned subsidiary, Western Digital Technologies, Inc. (“WDT”), entered into a 45-day senior secured bridge credit agreement for $3.0 billion in aggregate principal amount with JPMorgan Chase Bank and the lenders from time to time party thereto. On June 9, 2016, this agreement was amended to extend the maturity to 75 days. On July 21, 2016, the $3.0 billion aggregate principal amount of senior secured bridge loan outstanding was repaid in full, together with accrued interest. |

[0000106040-16-000033:mdna:16]
On May 12, 2016, we assumed $997 million aggregate principal amount of SanDisk outstanding 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $1.5 billion aggregate principal amount of SanDisk outstanding 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “SanDisk Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on October 15, 2020. The SanDisk Notes are not callable. As a result of the Merger, holders of $997 million of the outstanding principal amount of the 2017 Notes and $1.44 billion of the outstanding principal amount of the 2020 Notes had elected to convert their SanDisk Notes at temporarily increased conversion rates that expired on June 9, 2016. Once the holders elected conversion, there was a 20 trading day observation period which resulted in holders of $868 million principal amount of the 2017 Notes and $1.19 billion principal amount of the 2020 Notes converting by July 1, 2016 and $129 million principal amount of the 2017 Notes and $250 million principal amount of the 2020 Notes converting after July 1, 2016. In addition, during July 2016, we repurchased $25 million of the 2020 Notes. After taking into account conversions and the amounts that we repurchased, as of August 26, 2016, $37 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding.

[0000106040-16-000033:mdna:17]
For additional information, see Part II, Item 8, Note 3 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:18]
Restructuring Plan (the “Restructuring Plan”)

[0000106040-16-000033:mdna:19]
In connection with the regulatory approval process for the HGST acquisition, which closed on March 8, 2012, we agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, we have operated our global business through two independent subsidiaries — HGST and WD. In March 2014, we submitted an application to MOFCOM to lift the condition it imposed on us to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to our application that permits us to integrate our HGST and WD subsidiaries, except that we committed to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision.

[0000106040-16-000033:mdna:20]
We have initiated a set of actions relating to the Restructuring Plan associated with the integration of substantial portions of our HGST and WD subsidiaries. The Restructuring Plan consists of asset and footprint reduction, product roadmap consolidation and organization rationalization.

[0000106040-16-000033:mdna:21]
We expect the Restructuring Plan to be substantially completed by the end of calendar year 2017 and it is expected to result in total pre-tax charges of $400 million. These charges are expected to consist of $185 million in employee termination benefits, $125 million in asset charges and $90 million in other related costs. $275 million of these charges are expected to be cash expenditures. In 2016, we recognized $77 million of expenses related to the Restructuring Plan, which consisted of $58 million in employee termination benefits and $19 million in contract termination and other charges.

[0000106040-16-000033:mdna:22]
Closure of Foreign Manufacturing Facility

[0000106040-16-000033:mdna:23]
In January 2016, we announced the closing of our head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. In 2016, we recognized $152 million of expenses related to the closure of the facility, which consisted of $119 million in employee termination benefits, $24 million in asset impairment and $9 million in contract termination and other charges. In addition, we recognized $48 million of accelerated depreciation charges on assets held at the Odawara facility, of which $34 million was recognized in cost of revenue and $14 million was recognized in research and development within the consolidated statements of income. As of July 1, 2016, we substantially completed all activities related to the closure of the facility.

[0000106040-16-000033:mdna:24]
For additional information, see Part II, Item 8, Note 17 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:25]
Unis Joint Venture

[0000106040-16-000033:mdna:26]
In November 2015, we entered into an agreement to form a joint venture with Unis to market and sell our current data center storage systems in China and to develop data storage systems for the Chinese market in the future. A business plan for the joint venture has been completed, and we expect that the joint venture will be operational during calendar year 2016. The joint venture is 49% owned by us and 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd.

[0000106040-16-000033:mdna:27]
Results of Operations

[0000106040-16-000033:mdna:28]
Fiscal 2016 Overview

[0000106040-16-000033:mdna:29]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for SanDisk and Amplidata, which we acquired on May 12, 2016 and March 9, 2015, respectively, are included in our operating results only after the respective dates of acquisition.

[0000106040-16-000033:mdna:30]
In the course of finalizing this Annual Report on Form 10-K, we determined it was necessary to record an additional $10 million in R&D expense primarily for third party non-recurring engineering charges and $5 million in asset impairment for the discontinuation of a software project for the fourth quarter and full year of fiscal 2016 that were not included in our Current Report on Form 8-K filed with the SEC on July 28, 2016 to announce our preliminary and unaudited financial results for the fourth fiscal quarter and fiscal year ended July 1, 2016. Given this change, for fiscal year 2016, operating income decreased to $466 million and net income decreased to $242 million, or $1.00 per diluted share, and for the fourth quarter of 2016, operating loss increased to $195 million and net loss increased to $366 million, or $1.40 per diluted share.

[0000106040-16-000033:mdna:31]
The following is a summary of our financial performance for fiscal 2016:

[0000106040-16-000033:mdna:32]
| • | In 2016, our net revenue decreased by 11% to $13.0 billion on HDD shipments of 185 million units, as compared to $14.6 billion on shipments of 229 million units in 2015. |

[0000106040-16-000033:mdna:33]
| • | HDD ASPs increased to $61 in 2016, as compared to $60 in 2015. |

[0000106040-16-000033:mdna:34]
| • | Gross profit as a percentage of net revenue decreased to 26.4% in 2016, as compared to 29.0% in 2015. |

[0000106040-16-000033:mdna:35]
44

[0000106040-16-000033:mdna:36]
| • | Operating income decreased to $466 million in 2016, as compared to $1.6 billion in 2015. Operating income in 2016 included $345 million of employee termination, asset impairment and other charges, as compared to $176 million in 2015. In addition, operating income in 2016 included SanDisk acquisition-related costs of $159 million and charges related to cost savings initiatives of $143 million. |

[0000106040-16-000033:mdna:37]
| • | Net income in 2016 was $242 million, or $1.00 per diluted share, as compared to $1.5 billion, or $6.18 per diluted share, in 2015. |

[0000106040-16-000033:mdna:38]
Summary Comparison of 2016, 2015 and 2014

[0000106040-16-000033:mdna:39]
The following table sets forth, for the periods presented, selected summary information from our consolidated statements of income by dollars and percentage of net revenue:

[0000106040-16-000033:mdna:40]
|  | Years Ended |
|  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
|  | (in millions, except percentages) |
| Net revenue | $ | 12,994 |  |  | 100.0 | % |  | $ | 14,572 |  |  | 100.0 | % |  | $ | 15,130 |  |  | 100.0 | % |
| Cost of revenue | 9,559 |  |  | 73.6 |  |  | 10,351 |  |  | 71.0 |  |  | 10,770 |  |  | 71.2 |  |
| Gross profit | 3,435 |  |  | 26.4 |  |  | 4,221 |  |  | 29.0 |  |  | 4,360 |  |  | 28.8 |  |
| Research and development | 1,627 |  |  | 12.5 |  |  | 1,646 |  |  | 11.3 |  |  | 1,661 |  |  | 11.0 |  |
| Selling, general and administrative | 997 |  |  | 7.7 |  |  | 788 |  |  | 5.4 |  |  | 813 |  |  | 5.4 |  |
| Employee termination, asset impairment and other charges | 345 |  |  | 2.6 |  |  | 176 |  |  | 1.2 |  |  | 95 |  |  | 0.6 |  |
| Operating income | 466 |  |  | 3.6 |  |  | 1,611 |  |  | 11.1 |  |  | 1,791 |  |  | 11.8 |  |
| Other expense, net | (313 | ) |  | (2.4 | ) |  | (34 | ) |  | (0.2 | ) |  | (39 | ) |  | (0.3 | ) |
| Income before income taxes | 153 |  |  | 1.2 |  |  | 1,577 |  |  | 10.8 |  |  | 1,752 |  |  | 11.6 |  |
| Income tax expense (benefit) | (89 | ) |  | (0.7 | ) |  | 112 |  |  | 0.8 |  |  | 135 |  |  | 0.9 |  |
| Net income | $ | 242 |  |  | 1.9 |  |  | $ | 1,465 |  |  | 10.1 |  |  | $ | 1,617 |  |  | 10.7 |  |

[0000106040-16-000033:mdna:41]
The following table sets forth, for the periods presented, summary information regarding unit shipments, ASPs and net revenues by geography and channel:

[0000106040-16-000033:mdna:42]
|  | Years Ended |
|  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
|  | (in millions, except percentages and ASPs) |
| Net revenue | $ | 12,994 |  |  | $ | 14,572 |  |  | $ | 15,130 |  |
| ASPs (per unit)(1) | $ | 61 |  |  | $ | 60 |  |  | $ | 58 |  |
| Revenues by Geography (%) |  |  |  |  |  |
| Americas | 32 | % |  | 28 | % |  | 25 | % |
| Europe, Middle East and Africa | 21 |  |  | 22 |  |  | 21 |  |
| Asia | 47 |  |  | 50 |  |  | 54 |  |
| Revenues by Channel (%) |  |  |  |  |  |
| Original Equipment Manufacturers | 66 | % |  | 64 | % |  | 63 | % |
| Distributors | 20 |  |  | 23 |  |  | 24 |  |
| Retailers | 14 |  |  | 13 |  |  | 13 |  |
| Unit Shipments(1) |  |  |  |  |  |
| PC | 99 |  |  | 136 |  |  | 157 |  |
| Non-PC | 86 |  |  | 93 |  |  | 92 |  |
| Total units shipped | 185 |  |  | 229 |  |  | 249 |  |

[0000106040-16-000033:mdna:43]
| (1) | Based on sales of HDD units only. |

[0000106040-16-000033:mdna:44]
45

[0000106040-16-000033:mdna:45]
Fiscal Year 2016 Compared to Fiscal Year 2015

[0000106040-16-000033:mdna:46]
Net Revenue

[0000106040-16-000033:mdna:47]
Net revenue was $13.0 billion for 2016, a decrease of 11% from the prior year primarily due to lower HDD unit shipments partially offset by an increase in HDD ASP and revenues from SanDisk of $793 million following May 12, 2016, the closing date of the Merger (the “SanDisk Closing Date”). Total HDD shipments for 2016 decreased to 185 million units, as compared to 229 million units in the prior year primarily due to a softer demand environment. ASPs were $61 for 2016, an increase of $1 from 2015, primarily due to a change in product mix.

[0000106040-16-000033:mdna:48]
Changes in net revenue by geography reflect a:

[0000106040-16-000033:mdna:49]
| • | decrease in Asia primarily due to reduced demand of client HDD shipments as a result of a decline in the desktop and notebook PC market. |

[0000106040-16-000033:mdna:50]
| • | decrease in Europe, Middle East and Africa due to lower demand for our client and retail HDD products primarily due to the continued decline of PC-related after-market sales. |

[0000106040-16-000033:mdna:51]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2016 and 2015, these programs represented 13% and 10% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-16-000033:mdna:52]
Gross Profit

[0000106040-16-000033:mdna:53]
Gross profit for 2016 was $3.4 billion, a decrease of $786 million from the prior year. Gross profit as a percentage of net revenue decreased to 26.4% in 2016, as compared to 29.0% in the prior year. This decrease was primarily the result of lower HDD unit sales and the related absorption impact, and accelerated depreciation on assets related to both the closure of the Odawara, Japan facility and the Restructuring Plan. This decrease in gross profit was partially offset by SanDisk’s gross profit following the SanDisk Closing Date.

[0000106040-16-000033:mdna:54]
Operating Expenses

[0000106040-16-000033:mdna:55]
R&D expense was $1.6 billion in 2016, a decrease of $19 million, or 1%, from the prior year. This decrease was primarily the result of reductions in employee compensation expenses due to a reduction in headcount as a result of our business realignment initiatives, reduction in material spend due to the consolidation of our product roadmap in relation to the integration of our HGST and WD subsidiaries and an additional week in the prior year. These decreases were partially offset by SanDisk’s R&D expenses following the SanDisk Closing Date and expenses related to the integration of our HGST and WD subsidiaries.

[0000106040-16-000033:mdna:56]
Selling, general and administrative (“SG&A”) expense was $997 million in 2016, an increase of $209 million, or 27%, from the prior year. This increase was primarily the result of SanDisk’s SG&A expenses following the SanDisk Closing Date, charges related to the Merger and expenses related to the integration of our HGST and WD subsidiaries. These charges were partially offset by a reduction in employee compensation expenses due to a reduction in headcount as a result of our business realignment initiatives and an additional week in the prior year.

[0000106040-16-000033:mdna:57]
During 2016, we recorded $345 million of employee termination, asset impairment and other charges. These charges consisted of $251 million of employee termination costs, $37 million of asset impairment charges and $57 million of contract termination and other charges. During 2015, we recorded $176 million of employee termination, asset impairment and other charges. These charges consisted of $82 million of employee termination costs, $82 million of asset impairment charges and $12 million of contract termination and other charges. For additional information, see Part II, Item 8, Note 17 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:58]
Other Income (Expense)

[0000106040-16-000033:mdna:59]
Total other expense, net was $313 million in 2016, as compared to $34 million in the prior year. Interest income increased to $26 million in 2016, from $14 million in the prior year, primarily due to a higher average daily invested cash balance and higher market interest rates. Interest expense increased to $266 million in 2016, from $49 million in the prior year, primarily due to a higher debt balance and amortization of issuance costs related to the debt issued in connection with the Merger. Other income (expense), net was $73 million of expense, primarily comprised of settlement of the SanDisk debt instruments and the write-off of debt issuance costs related to the termination of our existing credit agreement. For additional information on debt, see Part II, Item 8, Note 3 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-16-000033:mdna:60]
Income Tax Expense (Benefit)

[0000106040-16-000033:mdna:61]
Income tax benefit was $89 million in 2016, as compared to a $112 million expense in the prior year. Tax benefit as a percentage of income before taxes was 58.2% in 2016, as compared to tax expense of 7.1% in the prior year. Our income tax benefit for 2016 reflects tax benefits from expenses related to the Merger and from interest expense related to new debt facilities. The difference between the effective tax rate and the U.S. Federal statutory rate is primarily due to foreign income taxed at lower tax rates due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029, the current year generation of income tax credits and the tax deductible expenses related to the Merger.

[0000106040-16-000033:mdna:62]
As of July 1, 2016, we had a recorded liability for unrecognized tax benefits of $491 million. We recognized a net increase of $141 million in our liability for unrecognized tax benefits during 2016. Accrued interest and penalties related to unrecognized tax benefits as of July 1, 2016 was $75 million. $120 million of the net increase in our liability for unrecognized tax benefits is attributable to balances assumed as a result of the Merger.

[0000106040-16-000033:mdna:63]
The Internal Revenue Service (“IRS”) previously completed its field examination of our federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. We have received Revenue Agent Reports from the IRS that seek to increase our U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with our foreign subsidiaries and intercompany payable balances. We disagree with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. We believe that our tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of our fiscal years 2010 through 2012.

[0000106040-16-000033:mdna:64]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in our tax examinations are resolved in a manner not consistent with management’s expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of July 1, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-16-000033:mdna:65]
Fiscal Year 2015 Compared to Fiscal Year 2014

[0000106040-16-000033:mdna:66]
Net Revenue

[0000106040-16-000033:mdna:67]
Net revenue was $14.6 billion for 2015, a decrease of 4% from 2014. The decrease was primarily due to a 8% decline in total HDD shipments, partially offset by an increase in ASPs. Total HDD shipments in 2015 decreased to 229 million units as compared to 249 million units for the prior year primarily due to a decrease in client PC demand. ASPs were $60 for 2015, an increase of $2 from 2014, primarily due to a change in product mix.

[0000106040-16-000033:mdna:68]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-16-000033:mdna:69]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2015 and 2014, these programs represented 10% and 8% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products.

[0000106040-16-000033:mdna:70]
Gross Profit

[0000106040-16-000033:mdna:71]
Gross profit for 2015 was $4.2 billion, a decrease of $139 million from the prior year. The decrease was primarily due to lower volume. Gross profit as a percentage of net revenue remained relatively flat at 29.0% in 2015, as compared to 28.8% in 2014.

[0000106040-16-000033:mdna:72]
Operating Expenses

[0000106040-16-000033:mdna:73]
R&D expense was $1.6 billion in 2015, a decrease of $15 million, or 1%, over the prior year. This slight decrease was due primarily to lower incentive compensation, partially offset by an additional week in fiscal 2015 and additional expenses related to our acquisitions.

[0000106040-16-000033:mdna:74]
SG&A expense was $788 million in 2015, a decrease of $25 million, or 3%, as compared to 2014. Adjusting for a $37 million flood-related insurance recovery in 2015, compared to a $65 million flood-related insurance recovery in 2014, and legal charges of $15 million in 2015, compared to $52 million in 2014, related to a litigation matter that is now closed, SG&A expense decreased $16 million, or 2%, compared to 2014. This slight decrease was primarily due to lower incentive compensation, partially offset by an additional week in fiscal 2015 and additional expenses related to our acquisitions.

[0000106040-16-000033:mdna:75]
47

[0000106040-16-000033:mdna:76]
During 2015, we recorded $176 million of employee termination, asset impairment and other charges. These charges consisted of $82 million of employee termination costs, $82 million of asset impairment charges and $12 million of contract termination and other charges. During 2014, we recorded $95 million of employee termination, asset impairment and other charges. These charges consisted of $27 million of employee termination costs, $62 million of asset impairment charges and $6 million of contract termination and other charges.

[0000106040-16-000033:mdna:77]
Other Income (Expense)

[0000106040-16-000033:mdna:78]
Other expense, net was $34 million in 2015, compared to $39 million in 2014. Interest income decreased to $14 million in 2015 from $15 million in 2014, primarily due to a $3 million gain on the sale of our auction-rate securities in 2014. Interest expense decreased to $49 million in 2015, from $56 million in 2014, primarily due to a $4 million write-off of debt issuance costs in 2014.

[0000106040-16-000033:mdna:79]
Income Tax Provision

[0000106040-16-000033:mdna:80]
Income tax expense was $112 million in 2015, as compared to $135 million in 2014. Tax expense as a percentage of income before taxes was 7.1% in 2015, as compared to 7.7% in 2014. Our income tax provision for 2015 reflects a tax benefit of $27 million as a result of the retroactive extension of the U.S. Federal research and development tax credit that was signed into law on December 19, 2014. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-16-000033:mdna:81]
48

[0000106040-16-000033:mdna:82]
Liquidity and Capital Resources

[0000106040-16-000033:mdna:83]
We ended 2016 with total cash and cash equivalents of $8.2 billion, an increase of $3.1 billion from July 3, 2015. The following table summarizes our statements of cash flows for the three years ended July 1, 2016:

[0000106040-16-000033:mdna:84]
|  | Years Ended |
|  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
|  | (in millions) |
| Net cash flow provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,983 |  |  | $ | 2,242 |  |  | $ | 2,816 |  |
| Investing activities | (9,608 | ) |  | (953 | ) |  | (1,936 | ) |
| Financing activities | 10,751 |  |  | (1,069 | ) |  | (385 | ) |
| Effect of exchange rate changes on cash | 1 |  |  | — |  |  | — |  |
| Net increase in cash and cash equivalents | $ | 3,127 |  |  | $ | 220 |  |  | $ | 495 |  |

[0000106040-16-000033:mdna:85]
We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:86]
In connection with the Merger, we entered into new debt facilities totaling $18.1 billion, which included Notes with an aggregate principal amount of $5.2 billion, term loans of $8.9 billion, a revolving credit facility of $1.0 billion and a bridge loan of $3.0 billion. As of July 1, 2016, we had $17.0 billion in debt facilities outstanding, net of debt issuance costs. The proceeds from the new debt facilities were used to finance, in part, the cash portion of the purchase price related to the Merger, refinance certain existing indebtedness of Western Digital and SanDisk and pay certain transaction costs. On July 21, 2016, the $3.0 billion aggregate principal amount of senior secured bridge loan outstanding was repaid in full, together with accrued interest. On May 12, 2016, we assumed SanDisk’s outstanding $997 million aggregate principal amount of its 2017 Notes and $1.5 billion aggregate principal amount of its 2020 Notes. After taking into account conversions and the amounts that we purchased, as of August 26, 2016, $37 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For additional information on the debt entered into in connection with the Merger, see Part II, Item 8, Note 3 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:87]
The cash on hand and indebtedness used to finance the Merger could cause us to place more reliance on cash generated from operations to pay principal and interest on our debt, thereby reducing the availability of our cash flow for working capital, dividend and capital expenditure needs or to pursue other potential strategic plans.

[0000106040-16-000033:mdna:88]
During 2017, we expect our total capital investment to be approximately $2.6 billion to $3.0 billion, including our net capital investments in Flash Ventures and our investment in non-fab property and equipment. We expect these 2017 investments to be funded by Flash Ventures’ working capital, anticipated new equipment leases and approximately $1.0 billion to $1.4 billion of our cash.

[0000106040-16-000033:mdna:89]
A total of $6.9 billion and $4.3 billion of our cash and cash equivalents was held outside of the United States as of July 1, 2016 and July 3, 2015, respectively. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or dividends to our shareholders pursuant to our quarterly cash dividend policy. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-16-000033:mdna:90]
Operating Activities

[0000106040-16-000033:mdna:91]
Net cash provided by operating activities was $2.0 billion in 2016, as compared to $2.2 billion and $2.8 billion in 2015 and 2014, respectively. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by working capital changes was $377 million for 2016, as compared to $593 million and $234 million used for working capital changes in 2015 and 2014, respectively.

[0000106040-16-000033:mdna:92]
49

[0000106040-16-000033:mdna:93]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles for the three years ended July 1, 2016 were as follows:

[0000106040-16-000033:mdna:94]
|  | Years Ended |
|  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
|  | (in days) |
| Days sales outstanding | 41 |  |  | 39 |  |  | 48 |  |
| Days in inventory | 81 |  |  | 49 |  |  | 41 |  |
| Days payables outstanding | (78 | ) |  | (67 | ) |  | (67 | ) |
| Cash conversion cycle | 44 |  |  | 21 |  |  | 22 |  |

[0000106040-16-000033:mdna:95]
In 2016, our days sales outstanding (“DSOs”) increased by 2 days, days in inventory (“DIOs”) increased by 32 days and days payables outstanding (“DPOs”) increased by 11 days, as compared to the prior year. These increases were primarily due to the impact of including SanDisk’s accounts receivable, inventory and accounts payable balances as of July 1, 2016, but only including SanDisk’s revenue and cost of sales following the SanDisk Closing Date. The Merger increased DSO, DIO and DPO by 12 days, 32 days and 14 days, respectively. For 2016, the increase in DSOs from the Merger was largely offset by the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-16-000033:mdna:96]
Investing Activities

[0000106040-16-000033:mdna:97]
Net cash used in investing activities in 2016 was $9.6 billion, as compared to $1.0 billion and $1.9 billion for 2015 and 2014, respectively. During 2016, net cash used in investing activities primarily consisted of $9.8 billion related to the Merger, net of cash acquired, $632 million related to the purchase of investments, $584 million of capital expenditures, $90 million net increase in notes receivable to Flash Ventures and a net $76 million of other investing activities, partially offset by $1.6 billion of proceeds from sales and maturities of investments. During 2015, net cash used in investing activities primarily consisted of $857 million related to the purchase of investments, $612 million of capital expenditures and $257 million related to acquisitions, net of cash acquired, partially offset by $768 million of proceeds from the sales and maturities of investments. During 2014, net cash used in investing activities primarily consisted of $823 million related to acquisitions, net of cash acquired, $628 million of capital expenditures and $561 million related to the purchase of investments, partially offset by $72 million of proceeds from the sales and maturities of investments.

[0000106040-16-000033:mdna:98]
Our cash equivalents are primarily invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government Agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government Agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds.

[0000106040-16-000033:mdna:99]
Financing Activities

[0000106040-16-000033:mdna:100]
Net cash provided by financing activities was $10.8 billion in 2016, as compared to net cash used of $1.1 billion and $385 million for 2015 and 2014, respectively. During 2016, net cash provided by financing activities consisted of $16.6 billion of proceeds from debt, net of issuance costs, $409 million of proceeds from call options, $125 million of proceeds from borrowings under our revolving credit facility and a net $74 million provided by employee stock plans, offset by $2.6 billion to settle convertible debt, $2.3 billion to repay debt, $613 million for payment upon settlement of warrants, $464 million to pay dividends on our common stock, $380 million to repay the revolving credit facility and $60 million to repurchase shares of our common stock. During 2015, net cash used in financing activities consisted of $970 million to repurchase shares of our common stock, $396 million to pay dividends on our common stock and $125 million to repay debt, partially offset by $255 million of proceeds from our revolving credit facility and a net $167 million provided by employee stock plans. During 2014, net cash used in financing activities consisted of $2.5 billion used to repay debt, $816 million used to repurchase shares of our common stock and $259 million used to pay dividends on our common stock, partially offset by $3.0 billion of proceeds from our term loan facility, net of issuance costs and a net $215 million provided by employee stock plans.

[0000106040-16-000033:mdna:101]
50

[0000106040-16-000033:mdna:102]
Off-Balance Sheet Arrangements

[0000106040-16-000033:mdna:103]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the consolidated financial statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 4 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:104]
Contractual Obligations and Commitments

[0000106040-16-000033:mdna:105]
The following is a summary of our known contractual cash obligations and commercial commitments as of July 1, 2016:

[0000106040-16-000033:mdna:106]
|  | Total |  | 1 Year(2017) |  | 2-3 Years (2018-2019) |  | 4-5 Years (2020-2021) |  | More than 5 Years(Beyond 2021) |
|  | (in millions) |
| Bridge loan(1) | $ | 3,000 |  |  | $ | 3,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt, including current portion(1) | 14,087 |  |  | 47 |  |  | 611 |  |  | 3,704 |  |  | 9,725 |  |
| Convertible senior notes | 439 |  |  | 377 |  |  | — |  |  | 62 |  | (2) | — |  |
| Interest on debt | 6,371 |  |  | 878 |  |  | 1,793 |  |  | 1,791 |  |  | 1,909 |  |
| Flash Ventures and other related commitments(3) | 5,604 |  |  | 2,260 |  |  | 1,877 |  |  | 1,108 |  |  | 359 |  |
| Operating leases | 329 |  |  | 95 |  |  | 148 |  |  | 49 |  |  | 37 |  |
| Purchase obligations | 1,381 |  |  | 1,372 |  |  | 9 |  |  | — |  |  | — |  |
| Total | $ | 31,211 |  |  | $ | 8,029 |  |  | $ | 4,438 |  |  | $ | 6,714 |  |  | $ | 12,030 |  |

[0000106040-16-000033:mdna:107]
| (1) | Included within our consolidated balance sheet. The bridge loan was repaid in full, together with accrued interest, on July 21, 2016. |

[0000106040-16-000033:mdna:108]
| (2) | $25 million of the 2020 Notes were repurchased after July 1, 2016. |

[0000106040-16-000033:mdna:109]
| (3) | Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and reimbursement for other committed expenses, including R&D. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments. |

[0000106040-16-000033:mdna:110]
Debt

[0000106040-16-000033:mdna:111]
In connection with the Merger, we entered into new debt facilities. The proceeds from the new debt facilities were used to finance, in part, the cash portion of the purchase price related to the Merger, refinance certain existing indebtedness of Western Digital and SanDisk and pay certain transaction costs.

[0000106040-16-000033:mdna:112]
On April 13, 2016, we completed an offering of our Notes. We are not required to make principal payments on the Notes prior to their respective maturity dates, except that we may be required to offer to purchase the Notes upon the occurrence of a change of control or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears. The obligations under the Notes are guaranteed by certain of our existing and subsequently acquired or organized wholly-owned, material domestic subsidiaries.

[0000106040-16-000033:mdna:113]
As of July 1, 2016, our non-guarantor subsidiaries had $4.3 billion of aggregate total liabilities (excluding intercompany transactions), all of which were structurally senior to the Notes and the related guarantees. For the year ended July 1, 2016, our non-guarantor subsidiaries accounted for 16% of our net sales and 86% of our total operating income, and as of July 1, 2016, our non-guarantor subsidiaries accounted for 87% of our total consolidated assets (excluding intercompany transactions).

[0000106040-16-000033:mdna:114]
On April 29, 2016, we entered into a new credit agreement which provides for secured loan facilities consisting of the $4.125 billion Term Loan A, the $3.75 billion U.S. Term Loan B tranche, the €885 million Euro Term Loan B tranche and the $1.0 billion revolving credit facility.

[0000106040-16-000033:mdna:115]
Term Loan B closed into escrow on April 29, 2016 and, at the SanDisk Closing Date, the proceeds of the borrowings under Term Loan B were released from escrow. Term Loan B has a term of seven years. Beginning in September 2016, we are required to make quarterly principal payments on Term Loan B equal to 0.25% of the original principal amount thereof, with the remaining balance due in fiscal 2023. As of July 1, 2016, the U.S. Term Loan B tranche had an outstanding balance of $3.750 billion with a variable interest rate of 6.250%, and the Euro Term Loan B tranche had an outstanding balance of €885 million (approximately $987 million based on the currency exchange rate at July 1, 2016) with a variable interest rates of 6.000%.

[0000106040-16-000033:mdna:116]
On August 17, 2016 we issued a new $3.0 billion U.S. dollar-denominated Term Loan B-1 at an interest rate of LIBOR plus 3.75% or a base rate plus 2.75%. Principal payments of 0.25% are due quarterly beginning September 30, 2016 with the balance due on April 29, 2023. In connection with this transaction, we settled the previous U.S. Term Loan B tranche with the proceeds of this new loan and a voluntary cash prepayment of $750 million. We expect to incur a debt extinguishment charge as a result of this transaction of approximately $230 million, which will be recorded in the first quarter of 2017.

[0000106040-16-000033:mdna:117]
On May 12, 2016, the loans under Term Loan A were drawn and the related proceeds were received by us, and the commitments under the revolving credit facility became available. Term Loan A and the revolving credit facility have a five‑year term. Beginning in September 2017, we are required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.2 billion due in 2021. As of July 1, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.450%. As of July 1, 2016, there was no outstanding balance on the revolving credit facility.

[0000106040-16-000033:mdna:118]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that Term Loan B requires us to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before the one year anniversary of the effective date.

[0000106040-16-000033:mdna:119]
The new credit agreement requires us to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for us and our subsidiaries. In addition, the new credit agreement contains customary covenants that limit or restrict us and our subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, make acquisitions and investments, loans and guarantees, enter into transactions with affiliates, make certain modifications of organizational documents and certain debt agreements and merge or consolidate, and customary events of default.

[0000106040-16-000033:mdna:120]
On May 12, 2016, WDT entered into a 45-day senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On June 9, 2016, this agreement was amended to extend the maturity to 75 days. On July 21, 2016, we paid in full the $3.0 billion aggregate principal outstanding together with accrued interest.

[0000106040-16-000033:mdna:121]
On May 12, 2016, we repaid all outstanding loans, together with accrued interest and related fees of $2.2 billion and terminated all commitments under the credit agreement dated as of January 9, 2014, as amended.

[0000106040-16-000033:mdna:122]
On May 12, 2016, we assumed SanDisk’s outstanding $997 million aggregate principal amount of its 2017 Notes and $1.5 billion aggregate principal amount of its 2020 Notes. The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on October 15, 2020. Holders of $997 million of the outstanding principal amount of the 2017 Notes and $1.44 billion of the outstanding principal amount of the 2020 Notes had elected to convert their Notes at temporarily increased conversion rates that expired on June 9, 2016. Once the holders elected conversion, there was a 20 trading day observation period which resulted in holders of $868 million principal amount of the 2017 Notes and $1.19 billion principal amount of the 2020 Notes converting by July 1, 2016 and $129 million principal amount of the 2017 Notes and $250 million principal amount of the 2020 Notes converting after July 1, 2016. In addition, during July 2016, we repurchased $25 million of the 2020 Notes. After taking into account conversions and the amounts that we repurchased, as of August 26, 2016, $37 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding.

[0000106040-16-000033:mdna:123]
As of July 1, 2016, under our credit agreement, we were in compliance with all covenants. For additional information, see Part II, Item 8, Note 3 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:124]
Flash Ventures

[0000106040-16-000033:mdna:125]
We are a 49.9% owner of each entity within Flash Ventures, our business ventures with Toshiba to develop and manufacture NAND flash memory products. These NAND flash memory products are manufactured by Toshiba at Toshiba’s Yokkaichi, Japan operations using the semiconductor manufacturing equipment owned or leased by Flash Ventures. This equipment is funded, or will be funded, by investments in, or loans to, Flash Ventures from us and Toshiba as well as through operating leases received by Flash Ventures from third-party banks and guaranteed by us and Toshiba. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to us and Toshiba at cost plus a markup. We are contractually obligated to purchase half of Flash Ventures’ NAND wafer supply or pay for 50% of the fixed costs of Flash Ventures. We are not able to estimate our total wafer purchase obligations beyond our rolling three month purchase commitment because the price is determined by reference to the future cost to produce the semiconductor wafers. We are also committed to fund 49.9% to 50% of Flash Ventures’ investments to the extent that Flash Ventures’ operating cash flow is insufficient to fund these investments.

[0000106040-16-000033:mdna:126]
From time-to-time, we and Toshiba mutually approve the purchase of equipment for Flash Ventures in order to convert to new process technologies or add wafer capacity. Flash Partners’ share of Fab 3 and Flash Alliance’s share of Fab 4 have been previously equipped to full wafer capacity. Fab 5, which is primarily utilized by Flash Forward, was built in two phases of approximately equal size. Phase 1 of Fab 5 is fully equipped and the majority of Phase 2 of Fab 5 is equipped. To date, we have invested in approximately 50% of Flash Forward’s equipment, and the output has been shared equally between us and Toshiba. Toshiba’s most recent 300-millimeter wafer fabrication facility, located in Yokkaichi, Japan (“New Fab 2”), for which we have a facility agreement with Toshiba, is primarily intended to provide additional cleanroom space to convert a portion of 2D NAND capacity to 3D NAND. We expect that the New Fab 2 space will accommodate conversion of somewhat less than half of the current Fab 3, Fab 4 and Fab 5 2D NAND capacity to 3D NAND. Production wafers in New Fab 2 started in January 2016.

[0000106040-16-000033:mdna:127]
For semiconductor manufacturing equipment that is leased by Flash Ventures, we and Toshiba each guarantee, on an unsecured and several basis, 50% of the outstanding Flash Ventures’ lease obligations under lease agreements entered into by Flash Ventures. These lease obligations are denominated in Japanese yen and are noncancelable. Our lease obligation guarantees as of July 1, 2016, which reflects future payments and any lease adjustments, totaled $1.15 billion, based upon the exchange rate at July 1, 2016. The lease agreements contain certain covenants and cancellation events that are customary for Japanese lease facilities and that relate to Flash Ventures and each of the guarantors. The breach of a covenant or the occurrence of another cancellation event could result in an acceleration of Flash Ventures’ lease obligations. As of July 1, 2016, we were in compliance with all covenants under these Japanese lease facilities.

[0000106040-16-000033:mdna:128]
For additional information regarding Flash Ventures, see Part II, Item 8, Notes 4 and 5 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:129]
Purchase Orders

[0000106040-16-000033:mdna:130]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into purchase orders with suppliers for capital equipment that are recorded as a liability upon receipt of the equipment. Our ability to change or cancel a capital equipment purchase order without penalty depends on the nature of the equipment being ordered. In some cases, we may be obligated to pay for certain costs related to changes to, or cancellation of, a purchase order, such as costs incurred for raw materials or work in process of components or capital equipment.

[0000106040-16-000033:mdna:131]
We have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. The estimated related minimum purchase requirements are included in “Purchase obligations” in the table above. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-16-000033:mdna:132]
We have inventory purchase commitments with Flash Ventures to purchase Flash Ventures’ NAND wafer supply. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled. We also have contracts with our other sources of silicon wafers that generally require us to provide monthly purchase order commitments. The purchase orders placed under these arrangements are generally binding and cannot be canceled. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-16-000033:mdna:133]
We enter into, from time to time, other long-term purchase agreements for components with certain vendors. Generally, future purchases under these agreements are not fixed and determinable as they depend on our overall unit volume requirements and are contingent upon the prices, technology and quality of the supplier’s products remaining competitive. These arrangements are not included under “Purchase obligations” in the table above. Please see Part I, Item 1A of this Annual Report on Form 10-K for a discussion of risks related to commitments.

[0000106040-16-000033:mdna:134]
Foreign Exchange Contracts

[0000106040-16-000033:mdna:135]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 7A, under the heading “Disclosure About Foreign Currency Risk,” and Part II, Item 8, Notes 1 and 13 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:136]
Indemnifications

[0000106040-16-000033:mdna:137]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-16-000033:mdna:138]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-16-000033:mdna:139]
Unrecognized Tax Benefits

[0000106040-16-000033:mdna:140]
As of July 1, 2016, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $566 million, of which $411 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part II, Item 8, Note 10 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:141]
Stock Repurchase Program

[0000106040-16-000033:mdna:142]
Our Board of Directors previously authorized a stock repurchase program. Effective October 21, 2015, in connection with the Merger, we suspended this stock repurchase program. For additional information, see Part II, Item 8, Note 9 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:143]
Cash Dividend Policy

[0000106040-16-000033:mdna:144]
Since the first quarter of fiscal 2014, we have issued a quarterly cash dividend. On August 3, 2016, we declared a cash dividend of $0.50 per share to the holders of record as of September 30, 2016, which will be paid on October 17, 2016. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time. For additional information, see Part II, Item 5 included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:145]
54

[0000106040-16-000033:mdna:146]
Critical Accounting Policies and Estimates

[0000106040-16-000033:mdna:147]
We have prepared the accompanying consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to the consolidated financial statements may be material.

[0000106040-16-000033:mdna:148]
Revenue and Accounts Receivable

[0000106040-16-000033:mdna:149]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return, and we provide resellers and OEMs with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection and/or returns until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for our products or market conditions differ from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Total sales incentive and marketing programs have ranged from 7% to 14% of gross revenue and adjustments to revenue due to changes in accruals for these programs related to revenue reported in prior periods have generally averaged less than 1% of gross revenue over the last three fiscal years.

[0000106040-16-000033:mdna:150]
We record an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, we routinely analyze the different receivable aging categories and establish reserves based on a combination of past due receivables and expected future losses based primarily on our historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if our overall loss history changes significantly, an adjustment in our allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-16-000033:mdna:151]
We establish provisions against revenue and cost of revenue for sales returns in the same period that the related revenue is recognized. We base these provisions on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-16-000033:mdna:152]
Warranty

[0000106040-16-000033:mdna:153]
We record an accrual for estimated warranty costs when revenue is recognized. We generally warrant our products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. Our warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, we use the estimated useful life of the product to calculate the warranty exposure. We use a statistical warranty tracking model to help prepare our estimates and assist us in exercising judgment in determining the underlying estimates. Our statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base our warranty estimates. We review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from our estimates, our future results of operations could be materially affected. For a summary of historical changes in estimates related to pre-existing warranty provisions, see Part II, Item 8, Note 4 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:154]
Inventories

[0000106040-16-000033:mdna:155]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-16-000033:mdna:156]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-16-000033:mdna:157]
Litigation and Other Contingencies

[0000106040-16-000033:mdna:158]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. For additional information, see Part II, Item 8, Note 6 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-16-000033:mdna:159]
Income Taxes

[0000106040-16-000033:mdna:160]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized.

[0000106040-16-000033:mdna:161]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-16-000033:mdna:162]
Stock-based Compensation

[0000106040-16-000033:mdna:163]
We account for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial model, and the fair values of all Employee Stock Purchase Plan purchase rights are estimated using the Black-Scholes-Merton option-pricing model. We account for stock appreciation rights (“SARs”) as liability awards based upon our intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton models require the input of highly subjective assumptions. We are required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and our results of operations could be materially affected. Performance restricted stock unit awards (“PSUs”) are subject to continued service by the employee, and expense is recognized over the vesting period. At each reporting date, we evaluate the probability that PSUs will be earned. We record stock-based compensation expense on the probability that the performance metrics will be achieved.

[0000106040-16-000033:mdna:164]
Business Combinations

[0000106040-16-000033:mdna:165]
The application of acquisition accounting to a business acquisition requires that we identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the purchase price are based upon preliminary estimates and assumptions and subject to revision when we receive final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. We will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-16-000033:mdna:166]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. We recognize the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). We generally assess the estimated fair values of acquired intangibles using a combination of valuation techniques. To estimate fair value, we are required to make certain estimates and assumptions, including future economic and market conditions, revenue growth, market share, operating costs and margins, and risk-adjusted discount rates. Our estimates require significant judgment and are based on historical data, various internal estimates, and external sources. Our assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-16-000033:mdna:167]
Goodwill and Other Long-Lived Assets

[0000106040-16-000033:mdna:168]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We either use qualitative factors to determine whether goodwill is more likely than not impaired or we perform a two-step approach to quantify impairment. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to follow a two-step approach to quantify the impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations.

[0000106040-16-000033:mdna:169]
Acquired intangibles are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. IPR&D is not amortized until the point at which it reaches technological feasibility. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-16-000033:mdna:170]
Recent Accounting Pronouncements

[0000106040-16-000033:mdna:171]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, which is incorporated by reference in response to this item.
