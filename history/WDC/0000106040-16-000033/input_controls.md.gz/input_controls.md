# WDC 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000106040-16-000033:item_9a:1]
Item 9A. Controls and Procedures

[0000106040-16-000033:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000106040-16-000033:item_9a:3]
As required by SEC Rule 13a-15(b) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K.

[0000106040-16-000033:item_9a:4]
Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Annual Report on Form 10-K, our disclosure controls and procedures were effective.

[0000106040-16-000033:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0000106040-16-000033:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) of the Exchange Act) to provide reasonable assurance regarding the reliability of our financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that in reasonable detail accurately and fairly reflect the transactions and dispositions of our assets; (ii) provide reasonable assurance that the transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and our directors; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the financial statements.

[0000106040-16-000033:item_9a:7]
Our management evaluated the effectiveness of our internal control over financial reporting using the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control — Integrated Framework (2013). Based on this evaluation, our management concluded that our internal control over financial reporting was effective as of the end of the period covered by this Annual Report on Form 10-K. KPMG LLP, our independent registered public accounting firm, which audited the consolidated financial statements included in this Annual Report on Form 10-K, has issued an audit report on our internal control over financial reporting. See Report of Independent Registered Public Accounting Firm herein.

[0000106040-16-000033:item_9a:8]
Our evaluation did not include the internal controls over financial reporting of SanDisk Corporation, which was acquired on May 12, 2016. Total assets and total sales related to SanDisk represented 17% and 6%, respectively, of the related consolidated financial statement amounts as of and for the fiscal year ended July 1, 2016.

[0000106040-16-000033:item_9a:9]
Changes in Internal Control over Financial Reporting

[0000106040-16-000033:item_9a:10]
There has been no change in our internal control over financial reporting during the fourth fiscal quarter ended July 1, 2016, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000106040-16-000033:item_9a:11]
Inherent Limitations of Effectiveness of Controls

[0000106040-16-000033:item_9a:12]
Our management, including our Chief Executive Officer and our Chief Financial Officer, does not expect our internal controls over financial reporting will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the benefits of controls must be considered relative to their costs. Because of the inherent limitations in a system of internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The design of any system of controls is also based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
