# WDC note change history — 0000106040-19-000028 → 0000106040-19-000075


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-11-12):
[0000106040-19-000075:note_history:1]
Related Parties and Related Commitments and Contingencies

- added (2019-11-12):
[0000106040-19-000075:note_history:2]
The Company’s business ventures with Kioxia Corporation (formerly known as Toshiba Memory Corporation) (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- changed (2019-11-12):
[0000106040-19-000075:note_history:3]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 4, 2019 and June 28, 2019:
  (was, 2019-05-07, similarity 0.9609):
[0000106040-19-000028:note_history:3]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 29, 2019 and June 29, 2018:

- changed (2019-11-12):
[0000106040-19-000075:note_history:4]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 482 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 905 |  |  | 878 |  |
| Notes receivable, Flash Forward | 617 |  |  | 743 |  |
| Investment in Flash Partners | 202 |  |  | 200 |  |
| Investment in Flash Alliance | 299 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,629 |  |  | $ | 2,791 |  |
  (was, 2019-05-07, similarity 0.9861):
[0000106040-19-000028:note_history:4]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 620 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 599 |  |  | 48 |  |
| Notes receivable, Flash Forward | 584 |  |  | 700 |  |
| Investment in Flash Partners | 194 |  |  | 191 |  |
| Investment in Flash Alliance | 287 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,403 |  |  | $ | 2,105 |  |

- added (2019-11-12):
[0000106040-19-000075:note_history:5]
During the three months ended October 4, 2019 and September 28, 2018, the Company made net payments to Flash Ventures of $682 million and $744 million, respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2019-11-12):
[0000106040-19-000075:note_history:6]
As of October 4, 2019 and June 28, 2019, the Company had accounts payable balances due to Flash Ventures of $507 million and $331 million, respectively.
  (was, 2019-05-07, similarity 0.9635):
[0000106040-19-000028:note_history:6]
As of March 29, 2019 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $312 million and $259 million, respectively.

- added (2019-11-12):
[0000106040-19-000075:note_history:7]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 4, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2019-11-12):
[0000106040-19-000075:note_history:8]
|  | October 4, 2019 |
| Notes receivable | $ | 2,004 |  |
| Equity investments | 625 |  |
| Operating lease guarantees | 1,694 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 4,682 |  |
  (was, 2019-05-07, similarity 0.9305):
[0000106040-19-000028:note_history:8]
|  | March 29, 2019 |
| Notes receivable | $ | 1,803 |  |
| Equity investments | 600 |  |
| Operating lease guarantees | 1,421 |  |
| Inventory | 274 |  |
| Maximum estimable loss exposure | $ | 4,098 |  |

- changed (2019-11-12):
[0000106040-19-000075:note_history:9]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.
  (was, 2019-05-07, similarity 0.8979):
[0000106040-19-000028:note_history:9]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- added (2019-11-12):
[0000106040-19-000075:note_history:10]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. For the three months ended October 4, 2019, the Company incurred charges of $68 million recorded in cost of revenue as a result of this incident, which amount primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

- added (2019-11-12):
[0000106040-19-000075:note_history:11]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 is expected in the second half of fiscal year 2020. Meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company committed to pay, among other items, future building depreciation prepayments of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges.

- added (2019-11-12):
[0000106040-19-000075:note_history:12]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

- added (2019-11-12):
[0000106040-19-000075:note_history:13]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

- added (2019-11-12):
[0000106040-19-000075:note_history:14]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

- changed (2019-11-12):
[0000106040-19-000075:note_history:15]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019.
  (was, 2019-05-07, similarity 0.9765):
[0000106040-19-000028:note_history:15]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019.

- changed (2019-11-12):
[0000106040-19-000075:note_history:16]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 4, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019:
  (was, 2019-05-07, similarity 0.9666):
[0000106040-19-000028:note_history:16]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019:

- changed (2019-11-12):
[0000106040-19-000075:note_history:17]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2020 |  | $ | 343 |  |  | $ | 56 |  |  | $ | 399 |  |
| 2021 |  | 369 |  |  | 110 |  |  | 479 |  |
| 2022 |  | 284 |  |  | 50 |  |  | 334 |  |
| 2023 |  | 177 |  |  | 67 |  |  | 244 |  |
| 2024 |  | 74 |  |  | 121 |  |  | 195 |  |
| Thereafter |  | 4 |  |  | 39 |  |  | 43 |  |
| Total guarantee obligations |  | $ | 1,251 |  |  | $ | 443 |  |  | $ | 1,694 |  |
  (was, 2019-05-07, similarity 0.9923):
[0000106040-19-000028:note_history:17]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2019 |  | $ | 106 |  |  | $ | 9 |  |  | $ | 115 |  |
| 2020 |  | 360 |  |  | 64 |  |  | 424 |  |
| 2021 |  | 271 |  |  | 106 |  |  | 377 |  |
| 2022 |  | 185 |  |  | 48 |  |  | 233 |  |
| 2023 |  | 81 |  |  | 28 |  |  | 109 |  |
| Thereafter |  | 45 |  |  | 118 |  |  | 163 |  |
| Total guarantee obligations |  | $ | 1,048 |  |  | $ | 373 |  |  | $ | 1,421 |  |

- changed (2019-11-12):
[0000106040-19-000075:note_history:18]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 4, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2019-05-07, similarity 0.9383):
[0000106040-19-000028:note_history:18]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2019-11-12):
[0000106040-19-000075:note_history:19]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three months ended October 4, 2019 and September 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of October 4, 2019 or June 28, 2019.
  (was, 2019-05-07, similarity 0.7731):
[0000106040-19-000028:note_history:19]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and nine months ended March 29, 2019 and March 30, 2018, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of March 29, 2019 or June 29, 2018.

- removed (2019-11-12):
[0000106040-19-000028:note_history:20]
Commitments, Contingencies and Related Parties

- removed (2019-11-12):
[0000106040-19-000028:note_history:21]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- removed (2019-11-12):
[0000106040-19-000028:note_history:22]
During the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $1.0 billion and $2.9 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- removed (2019-11-12):
[0000106040-19-000028:note_history:23]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and nine months ended March 29, 2019 or March 30, 2018.

- removed (2019-11-12):
[0000106040-19-000028:note_history:24]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2019-11-12):
[0000106040-19-000028:note_history:25]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of current supply/demand imbalance for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $148 million and $197 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three and nine months ended March 29, 2019, respectively.

- removed (2019-11-12):
[0000106040-19-000028:note_history:26]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

- removed (2019-11-12):
[0000106040-19-000028:note_history:27]
Purchase Agreements

- removed (2019-11-12):
[0000106040-19-000028:note_history:28]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of March 29, 2019, the Company had the following minimum long-term purchase commitments:

- removed (2019-11-12):
[0000106040-19-000028:note_history:29]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining three months of 2019 |  | $ | 15 |  |
| 2020 |  | 192 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 892 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:30]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. Mediation in this matter was held on August 16, 2019, and the parties reached an agreement in principle to settle the case for an immaterial amount, a portion of which was previously accrued in the Company’s financial statements. The parties formalized the settlement and filed a joint stipulation of dismissal with prejudice in October 2019. The matter is now closed.
  (was, 2019-05-07, similarity 0.689):
[0000106040-19-000028:note_history:30]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

- changed (2019-11-12):
[0000106040-19-000075:note_history:31]
Beginning in March 2015, SanDisk Corporation (“SanDisk”), which was acquired by the Company in May 2016, and two of SanDisk’s former officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015. The Institutional Investor Group alleged artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter. In May 2019, the court granted the motion for preliminary approval, and in October 2019, the court issued its final order and judgment approving the settlement.
  (was, 2019-05-07, similarity 0.9043):
[0000106040-19-000028:note_history:31]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter, subject to formal ratification by party representatives and approval by the court, and a hearing on the parties’ motion for preliminary approval is set for May 16, 2019. The charge related to the settlement was recorded in Selling, general and administrative expense.

- removed (2019-11-12):
[0000106040-19-000028:note_history:32]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-11-12):
[0000106040-19-000075:note_history:33]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

- added (2019-11-12):
[0000106040-19-000075:note_history:34]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. It also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.

- added (2019-11-12):
[0000106040-19-000075:note_history:35]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- removed (2019-11-12):
[0000106040-19-000028:note_history:36]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.

- removed (2019-11-12):
[0000106040-19-000028:note_history:37]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:38]
Debt consisted of the following as of October 4, 2019 and June 28, 2019:
  (was, 2019-05-07, similarity 0.9194):
[0000106040-19-000028:note_history:38]
Debt consisted of the following as of March 29, 2019 and June 29, 2018:

- changed (2019-11-12):
[0000106040-19-000075:note_history:39]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | — |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,771 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,374 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (162 | ) |  | (172 | ) |
| Subtotal | 10,212 |  |  | 10,522 |  |
| Less current portion of long-term debt | (251 | ) |  | (276 | ) |
| Long-term debt | $ | 9,961 |  |  | $ | 10,246 |  |
  (was, 2019-05-07, similarity 0.9886):
[0000106040-19-000028:note_history:39]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,896 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,431 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,762 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (177 | ) |  | (203 | ) |
| Subtotal | 10,585 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,309 |  |  | $ | 10,993 |  |

- added (2019-11-12):
[0000106040-19-000075:note_history:40]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 4, 2019, the Company was in compliance with these financial covenants.

- added (2019-11-12):
[0000106040-19-000075:note_history:41]
During the three months ended October 4, 2019, the Company made a voluntary prepayment of $250 million on its U.S. Term Loan B-4, which was applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of October 4, 2019, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.

- removed (2019-11-12):
[0000106040-19-000028:note_history:42]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At March 29, 2019, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

- removed (2019-11-12):
[0000106040-19-000028:note_history:43]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement. As of March 29, 2019, the Company was in compliance with all financial covenants under the Credit Agreement.

- removed (2019-11-12):
[0000106040-19-000028:note_history:44]
In April 2019, the Company amended the Credit Agreement for the purposes of providing additional flexibility by adjusting the leverage ratio maintenance covenant levels applicable to the term A loan and revolving facilities thereunder and amending the definition of Consolidated Adjusted EBITDA under the financial maintenance covenants to include an addback for certain depreciation related payments with respect to the Company’s Flash Ventures. As amended, the Company is now required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 2, 2020, 4.00 to 1.00 through the quarter ending July 2, 2021, 3.75 to 1.00 through the quarter ending December 31, 2021, 3.50 to 1.00 through the quarter ending July 1, 2022, and 3.25 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00.

- removed (2019-11-12):
[0000106040-19-000028:note_history:45]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:46]
Debt consisted of the following as of October 4, 2019 and June 28, 2019:
  (was, 2019-05-07, similarity 0.9194):
[0000106040-19-000028:note_history:46]
Debt consisted of the following as of March 29, 2019 and June 29, 2018:

- changed (2019-11-12):
[0000106040-19-000075:note_history:47]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | — |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,771 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,374 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (162 | ) |  | (172 | ) |
| Subtotal | 10,212 |  |  | 10,522 |  |
| Less current portion of long-term debt | (251 | ) |  | (276 | ) |
| Long-term debt | $ | 9,961 |  |  | $ | 10,246 |  |
  (was, 2019-05-07, similarity 0.9886):
[0000106040-19-000028:note_history:47]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,896 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,431 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,762 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (177 | ) |  | (203 | ) |
| Subtotal | 10,585 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,309 |  |  | $ | 10,993 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:48]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 4, 2019 and June 28, 2019:
  (was, 2019-05-07, similarity 0.9609):
[0000106040-19-000028:note_history:48]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 29, 2019 and June 29, 2018:

- changed (2019-11-12):
[0000106040-19-000075:note_history:49]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 482 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 905 |  |  | 878 |  |
| Notes receivable, Flash Forward | 617 |  |  | 743 |  |
| Investment in Flash Partners | 202 |  |  | 200 |  |
| Investment in Flash Alliance | 299 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,629 |  |  | $ | 2,791 |  |
  (was, 2019-05-07, similarity 0.9861):
[0000106040-19-000028:note_history:49]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 620 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 599 |  |  | 48 |  |
| Notes receivable, Flash Forward | 584 |  |  | 700 |  |
| Investment in Flash Partners | 194 |  |  | 191 |  |
| Investment in Flash Alliance | 287 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,403 |  |  | $ | 2,105 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:50]
The Company’s disaggregated revenue information is as follows:
  (was, 2019-05-07, similarity 0.9764):
[0000106040-19-000028:note_history:50]
The Company’s disaggregated revenue information is as follows(1):

- added (2019-11-12):
[0000106040-19-000075:note_history:51]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except percentages) |
| Revenue by Product |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,408 |  |  | $ | 2,494 |  |
| Flash-based | 1,632 |  |  | 2,534 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 1,616 |  |  | $ | 2,650 |  |
| Data Center Devices & Solutions | 1,532 |  |  | 1,446 |  |
| Client Solutions | 892 |  |  | 932 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by Geography |  |  |  |
| Americas | $ | 1,313 |  |  | $ | 1,281 |  |
| Europe, Middle East and Africa | 779 |  |  | 884 |  |
| Asia | 1,948 |  |  | 2,863 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |

- removed (2019-11-12):
[0000106040-19-000028:note_history:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,064 |  |  | $ | 2,640 |  |  | $ | 6,618 |  |  | $ | 7,944 |  |
| Flash-based | 1,610 |  |  | 2,373 |  |  | 6,317 |  |  | 7,586 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |

- removed (2019-11-12):
[0000106040-19-000028:note_history:53]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-12):
[0000106040-19-000075:note_history:54]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 4, 2019 or June 28, 2019.
  (was, 2019-05-07, similarity 0.9185):
[0000106040-19-000028:note_history:54]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 29, 2019 or the date of adoption of Topic 606.

- changed (2019-11-12):
[0000106040-19-000075:note_history:55]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 4, 2019 and June 28, 2019 as well as the related amortization for the three months ended October 4, 2019 and September 28, 2018 were not material.
  (was, 2019-05-07, similarity 0.8159):
[0000106040-19-000028:note_history:55]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and nine months ended March 29, 2019 were not material.

- added (2019-11-12):
[0000106040-19-000075:note_history:56]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 4, 2019 and June 28, 2019, contract liabilities were not material.

- changed (2019-11-12):
[0000106040-19-000075:note_history:57]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 4, 2019 was $182 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $50 million during the remainder of fiscal 2020, $50 million in fiscal 2021, $45 million in fiscal 2022 and $37 million thereafter.
  (was, 2019-05-07, similarity 0.9941):
[0000106040-19-000028:note_history:57]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 29, 2019 was $204 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2019, $62 million in fiscal 2020, $47 million in fiscal 2021 and $75 million thereafter.

- changed (2019-11-12):
[0000106040-19-000075:note_history:58]
The Company’s disaggregated revenue information is as follows:
  (was, 2019-05-07, similarity 0.9764):
[0000106040-19-000028:note_history:58]
The Company’s disaggregated revenue information is as follows(1):

- added (2019-11-12):
[0000106040-19-000075:note_history:59]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except percentages) |
| Revenue by Product |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,408 |  |  | $ | 2,494 |  |
| Flash-based | 1,632 |  |  | 2,534 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 1,616 |  |  | $ | 2,650 |  |
| Data Center Devices & Solutions | 1,532 |  |  | 1,446 |  |
| Client Solutions | 892 |  |  | 932 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by Geography |  |  |  |
| Americas | $ | 1,313 |  |  | $ | 1,281 |  |
| Europe, Middle East and Africa | 779 |  |  | 884 |  |
| Asia | 1,948 |  |  | 2,863 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |

- added (2019-11-12):
[0000106040-19-000075:note_history:60]
For the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue and for the three months ended September 28, 2018, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended October 4, 2019 and September 28, 2018, the Company’s top 10 customers accounted for 43% and 48% of its net revenue, respectively.

- removed (2019-11-12):
[0000106040-19-000028:note_history:61]
The Company offers a broad range of data storage products that include Client Devices, Data Center Devices and Solutions, and Client Solutions. Client Devices consist of hard disk drives (“HDDs”) and solid state drives (“SSDs”) for computing devices; flash-based embedded storage products; and flash-based memory wafers. Data Center Devices and Solutions consist of high-capacity enterprise HDDs and high-performance enterprise SSDs, data center software and system solutions. Client Solutions consist of HDDs and SSDs embedded into external storage products and removable flash-based products. The Company also generates license and royalty revenues related to its IP patent licenses which are not material.

- removed (2019-11-12):
[0000106040-19-000028:note_history:62]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and that uncertainties are resolved in a fairly short period of time.

- removed (2019-11-12):
[0000106040-19-000028:note_history:63]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

- removed (2019-11-12):
[0000106040-19-000028:note_history:64]
The Company’s customer payment terms are typically less than three months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

- removed (2019-11-12):
[0000106040-19-000028:note_history:65]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company believes the estimate of variable consideration is not constrained and that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics. The Company’s methodology for the estimates is based on several factors, including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are typically recorded as a reduction of the transaction price and, therefore, of revenue.

- removed (2019-11-12):
[0000106040-19-000028:note_history:66]
An immaterial amount of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

- removed (2019-11-12):
[0000106040-19-000028:note_history:67]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of March 29, 2019 and the date of adoption of Topic 606, contract liabilities were $46 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the nine months ended March 29, 2019 include $93 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

- removed (2019-11-12):
[0000106040-19-000028:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,064 |  |  | $ | 2,640 |  |  | $ | 6,618 |  |  | $ | 7,944 |  |
| Flash-based | 1,610 |  |  | 2,373 |  |  | 6,317 |  |  | 7,586 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |

- removed (2019-11-12):
[0000106040-19-000028:note_history:69]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material. |

- removed (2019-11-12):
[0000106040-19-000028:note_history:70]
The Company’s top 10 customers accounted for 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively, and 44% and 42% of its net revenue for the three and nine months ended March 30, 2018, respectively. For the three and nine months ended March 29, 2019 and March 30, 2018, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-11-12):
[0000106040-19-000028:note_history:71]
Subsequent Events

- removed (2019-11-12):
[0000106040-19-000028:note_history:72]
In April 2019, the Company completed a sale and leaseback of its manufacturing facility in Fremont, California. The Company received proceeds from the sale of $115 million and expects to recognize an approximate loss of $25 million. The property is being leased back over a term of 15 years at an annual lease rate of $7 million for the first year and increasing by 3% per year thereafter. The lease includes four 5-year renewal options for the ability to extend up to 20 years.
