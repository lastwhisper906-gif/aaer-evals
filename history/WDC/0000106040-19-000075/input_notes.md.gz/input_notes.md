# WDC notes — 0000106040-19-000075


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-19-000075:notes:1]
[same as prior period, unchanged from 0000106040-19-000028:notes:134]

[0000106040-19-000075:notes:2]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

[0000106040-19-000075:notes:3]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. It also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.

[0000106040-19-000075:notes:4]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-19-000075:notes:5]
[same as prior period, unchanged from 0000106040-19-000028:notes:137]

[0000106040-19-000075:notes:6]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-19-000075:notes:7]
[same as prior period, unchanged from 0000106040-19-000028:notes:139]

[0000106040-19-000075:notes:8]
[same as prior period, unchanged from 0000106040-19-000028:notes:140]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-19-000075:notes:9]
Recent Accounting Pronouncements

[0000106040-19-000075:notes:10]
Accounting Pronouncements Recently Adopted

[0000106040-19-000075:notes:11]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The Company adopted this standard effective June 29, 2019, the first day of the fiscal year ending July 3, 2020, and has elected the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company has elected the package of practical expedients and did not reassess prior conclusions including (a) whether its contracts are or contain a lease, (b) lease classification and (c) capitalization of initial direct costs. The adoption of Topic 842 resulted in an increase in lease assets and a corresponding increase in lease liabilities on the Condensed Consolidated Balance Sheet of $221 million. The cumulative effect of adopting Topic 842 also included an after-tax decrease to opening retained earnings of $5 million as of June 29, 2019, which was primarily related to previously recorded sublease proceeds on lease exit liabilities for which there was no expected future economic benefit at transition. See Note 10, Leases and Other Commitments, for additional disclosures related to this standard.

[0000106040-19-000075:notes:12]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. The Company adopted this standard in the first quarter of 2020. The Company’s adoption of ASU 2018-16 did not have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-19-000075:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-19-000075:notes:14]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-19-000075:notes:15]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-19-000075:notes:16]
[same as prior period, unchanged from 0000106040-19-000028:notes:152]

[0000106040-19-000075:notes:17]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 4, 2019 or June 28, 2019.

[0000106040-19-000075:notes:18]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 4, 2019 and June 28, 2019 as well as the related amortization for the three months ended October 4, 2019 and September 28, 2018 were not material.

[0000106040-19-000075:notes:19]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 4, 2019 and June 28, 2019, contract liabilities were not material.

[0000106040-19-000075:notes:20]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 4, 2019 was $182 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $50 million during the remainder of fiscal 2020, $50 million in fiscal 2021, $45 million in fiscal 2022 and $37 million thereafter.

[0000106040-19-000075:notes:21]
The Company’s disaggregated revenue information is as follows:

[0000106040-19-000075:notes:22]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except percentages) |
| Revenue by Product |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,408 |  |  | $ | 2,494 |  |
| Flash-based | 1,632 |  |  | 2,534 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 1,616 |  |  | $ | 2,650 |  |
| Data Center Devices & Solutions | 1,532 |  |  | 1,446 |  |
| Client Solutions | 892 |  |  | 932 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by Geography |  |  |  |
| Americas | $ | 1,313 |  |  | $ | 1,281 |  |
| Europe, Middle East and Africa | 779 |  |  | 884 |  |
| Asia | 1,948 |  |  | 2,863 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |

[0000106040-19-000075:notes:23]
For the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue and for the three months ended September 28, 2018, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended October 4, 2019 and September 28, 2018, the Company’s top 10 customers accounted for 43% and 48% of its net revenue, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-19-000075:notes:24]
[same as prior period, unchanged from 0000106040-19-000028:notes:201]

[0000106040-19-000075:notes:25]
[same as prior period, unchanged from 0000106040-19-000028:notes:202]

[0000106040-19-000075:notes:26]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three months ended October 4, 2019 and September 28, 2018, the Company sold trade accounts receivable and received cash proceeds of $85 million and $243 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income (expense), net in the Condensed Consolidated Financial Statements. As of October 4, 2019 and June 28, 2019, the amount of factored receivables that remained outstanding was $85 million and $318 million, respectively.

[0000106040-19-000075:notes:27]
Inventories

[0000106040-19-000075:notes:28]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,370 |  |  | $ | 1,142 |  |
| Work-in-process | 900 |  |  | 968 |  |
| Finished goods | 1,017 |  |  | 1,173 |  |
| Total inventories | $ | 3,287 |  |  | $ | 3,283 |  |

[0000106040-19-000075:notes:29]
Property, plant and equipment, net

[0000106040-19-000075:notes:30]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land | $ | 294 |  |  | $ | 294 |  |
| Buildings and improvements | 1,783 |  |  | 1,743 |  |
| Machinery and equipment | 7,184 |  |  | 7,267 |  |
| Computer equipment and software | 450 |  |  | 441 |  |
| Furniture and fixtures | 55 |  |  | 56 |  |
| Construction-in-process | 190 |  |  | 202 |  |
| Property, plant and equipment, gross | 9,956 |  |  | 10,003 |  |
| Accumulated depreciation | (7,160 | ) |  | (7,160 | ) |
| Property, plant, and equipment, net | $ | 2,796 |  |  | $ | 2,843 |  |

[0000106040-19-000075:notes:31]
[same as prior period, unchanged from 0000106040-19-000028:notes:204]

[0000106040-19-000075:notes:32]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 28, 2019 | $ | 10,076 |  |
| Goodwill recorded in connection with an acquisition | 14 |  |
| Balance at October 4, 2019 | $ | 10,090 |  |

[0000106040-19-000075:notes:33]
On September 10, 2019, the Company acquired substantially all the assets of Kazan Networks, Inc., an innovator in high-performance networking and non-volatile memory express over fabrics technology ("NVMe-oF"), and an industry leader in application-specific integrated circuit and adapter solutions to connect storage platforms and systems over ethernet fabrics. The purchase price of this acquisition was $22 million in cash, with net assets acquired primarily consisting of in-process research and development (“IPR&D”) of $8 million and $14 million allocated to goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings in its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. During the three months ended October 4, 2019, the expenses incurred by the Company related to the acquisition were not material. Revenues and earnings related to this acquisition were not material.

[0000106040-19-000075:notes:34]
Intangible assets

[0000106040-19-000075:notes:35]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,823 |  |  | $ | 5,824 |  |
| In-process research and development | 80 |  |  | 72 |  |
| Accumulated amortization | (4,389 | ) |  | (4,185 | ) |
| Intangible assets, net | $ | 1,514 |  |  | $ | 1,711 |  |

[0000106040-19-000075:notes:36]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-19-000075:notes:37]
Product warranty liability

[0000106040-19-000075:notes:38]
Changes in the warranty accrual were as follows:

[0000106040-19-000075:notes:39]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 350 |  |  | $ | 318 |  |
| Charges to operations | 49 |  |  | 34 |  |
| Utilization | (48 | ) |  | (26 | ) |
| Changes in estimate related to pre-existing warranties | 6 |  |  | (3 | ) |
| Warranty accrual, end of period | $ | 357 |  |  | $ | 323 |  |

[0000106040-19-000075:notes:40]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-19-000075:notes:41]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion (included in Accrued expenses) | $ | 182 |  |  | $ | 188 |  |
| Long-term portion (included in Other liabilities) | 175 |  |  | 162 |  |
| Total warranty accrual | $ | 357 |  |  | $ | 350 |  |

[0000106040-19-000075:notes:42]
Other liabilities

[0000106040-19-000075:notes:43]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 839 |  |  | $ | 928 |  |
| Payables related to unrecognized tax benefits | 698 |  |  | 699 |  |
| Other non-current liabilities | 928 |  |  | 713 |  |
| Total other non-current liabilities | $ | 2,465 |  |  | $ | 2,340 |  |

[0000106040-19-000075:notes:44]
[same as prior period, unchanged from 0000106040-19-000028:notes:209]

[0000106040-19-000075:notes:45]
[same as prior period, unchanged from 0000106040-19-000028:notes:210]

[0000106040-19-000075:notes:46]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 28, 2019 | (53 | ) |  | 4 |  |  | (19 | ) |  | (68 | ) |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | 5 |  |  | (26 | ) |  | (20 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (7 | ) |  | (7 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | — |  |  | (1 | ) |  | 6 |  |  | 5 |  |
| Net current-period other comprehensive loss | 1 |  |  | 4 |  |  | (27 | ) |  | (22 | ) |
| Balance at October 4, 2019 | $ | (52 | ) |  | $ | 8 |  |  | $ | (46 | ) |  | $ | (90 | ) |

[0000106040-19-000075:notes:47]
During the three months ended October 4, 2019 and September 28, 2018, the amounts reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-19-000075:notes:48]
[same as prior period, unchanged from 0000106040-19-000028:notes:67]

[0000106040-19-000075:notes:49]
[same as prior period, unchanged from 0000106040-19-000028:notes:68]

[0000106040-19-000075:notes:50]
[same as prior period, unchanged from 0000106040-19-000028:notes:69]

[0000106040-19-000075:notes:51]
[same as prior period, unchanged from 0000106040-19-000028:notes:70]

[0000106040-19-000075:notes:52]
[same as prior period, unchanged from 0000106040-19-000028:notes:71]

[0000106040-19-000075:notes:53]
[same as prior period, unchanged from 0000106040-19-000028:notes:72]

[0000106040-19-000075:notes:54]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of October 4, 2019 and June 28, 2019, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-19-000075:notes:55]
|  | October 4, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 889 |  |  | $ | — |  |  | $ | — |  |  | $ | 889 |  |
| Foreign exchange contracts | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total assets at fair value | $ | 889 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 911 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |
| Interest rate swap contract | — |  |  | 88 |  |  | — |  |  | 88 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 106 |  |  | $ | — |  |  | $ | 106 |  |

[0000106040-19-000075:notes:56]
|  | June 28, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,388 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,388 |  |
| Certificates of deposit | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Total cash equivalents | 1,388 |  |  | 17 |  |  | — |  |  | 1,405 |  |
| Foreign exchange contracts | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Interest rate swap contracts | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total assets at fair value | $ | 1,388 |  |  | $ | 63 |  |  | $ | — |  |  | $ | 1,451 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |
| Interest rate swap contract | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000106040-19-000075:notes:57]
During the three months ended October 4, 2019 and September 28, 2018, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-19-000075:notes:58]
[same as prior period, unchanged from 0000106040-19-000028:notes:81]

[0000106040-19-000075:notes:59]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2020 and the fourth quarter of 2019, respectively.

[0000106040-19-000075:notes:60]
|  | October 4, 2019 |  | June 28, 2019 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 33 |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | 31 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,762 |  |  | 4,774 |  |  | 4,824 |  |  | 4,780 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,167 |  |  | 2,424 |  |  | 2,370 |  |
| 1.50% convertible notes due 2024 | 965 |  |  | 1,058 |  |  | 958 |  |  | 986 |  |
| 4.750% senior unsecured notes due 2026 | 2,284 |  |  | 2,351 |  |  | 2,283 |  |  | 2,263 |  |
| Total | $ | 10,212 |  |  | $ | 10,383 |  |  | $ | 10,522 |  |  | $ | 10,430 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-19-000075:notes:61]
[same as prior period, unchanged from 0000106040-19-000028:notes:51]

[0000106040-19-000075:notes:62]
As of October 4, 2019, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-19-000075:notes:63]
As of October 4, 2019, the amount of existing net losses related to cash flow hedges recorded in AOCI included $70 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of October 4, 2019, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-19-000075:notes:64]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three months ended October 4, 2019 and September 28, 2018, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000075:notes:65]
[same as prior period, unchanged from 0000106040-19-000028:notes:55]

[0000106040-19-000075:notes:66]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of October 4, 2019 and June 28, 2019, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-19-000075:notes:67]
Debt

[0000106040-19-000075:notes:68]
Debt consisted of the following as of October 4, 2019 and June 28, 2019:

[0000106040-19-000075:notes:69]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | — |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,771 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,374 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (162 | ) |  | (172 | ) |
| Subtotal | 10,212 |  |  | 10,522 |  |
| Less current portion of long-term debt | (251 | ) |  | (276 | ) |
| Long-term debt | $ | 9,961 |  |  | $ | 10,246 |  |

[0000106040-19-000075:notes:70]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 4, 2019, the Company was in compliance with these financial covenants.

[0000106040-19-000075:notes:71]
During the three months ended October 4, 2019, the Company made a voluntary prepayment of $250 million on its U.S. Term Loan B-4, which was applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of October 4, 2019, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-19-000075:notes:72]
[same as prior period, unchanged from 0000106040-19-000028:notes:143]

[0000106040-19-000075:notes:73]
[same as prior period, unchanged from 0000106040-19-000028:notes:144]

[0000106040-19-000075:notes:74]
[same as prior period, unchanged from 0000106040-19-000028:notes:145]

[0000106040-19-000075:notes:75]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan:

[0000106040-19-000075:notes:76]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Benefit obligations | $ | 281 |  |  | $ | 280 |  |
| Fair value of plan assets | 211 |  |  | 208 |  |
| Unfunded status | $ | 70 |  |  | $ | 72 |  |

[0000106040-19-000075:notes:77]
[same as prior period, unchanged from 0000106040-19-000028:notes:146]

[0000106040-19-000075:notes:78]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 69 |  |  | 71 |  |
| Net amount recognized | $ | 70 |  |  | $ | 72 |  |

[0000106040-19-000075:notes:79]
Net periodic benefit costs were not material for the three months ended October 4, 2019 or September 28, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-19-000075:notes:80]
Related Parties and Related Commitments and Contingencies

[0000106040-19-000075:notes:81]
Flash Ventures

[0000106040-19-000075:notes:82]
The Company’s business ventures with Kioxia Corporation (formerly known as Toshiba Memory Corporation) (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-19-000075:notes:83]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 4, 2019 and June 28, 2019:

[0000106040-19-000075:notes:84]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 482 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 905 |  |  | 878 |  |
| Notes receivable, Flash Forward | 617 |  |  | 743 |  |
| Investment in Flash Partners | 202 |  |  | 200 |  |
| Investment in Flash Alliance | 299 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,629 |  |  | $ | 2,791 |  |

[0000106040-19-000075:notes:85]
During the three months ended October 4, 2019 and September 28, 2018, the Company made net payments to Flash Ventures of $682 million and $744 million, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-19-000075:notes:86]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-19-000075:notes:87]
As of October 4, 2019 and June 28, 2019, the Company had accounts payable balances due to Flash Ventures of $507 million and $331 million, respectively.

[0000106040-19-000075:notes:88]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 4, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-19-000075:notes:89]
|  | October 4, 2019 |
| Notes receivable | $ | 2,004 |  |
| Equity investments | 625 |  |
| Operating lease guarantees | 1,694 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 4,682 |  |

[0000106040-19-000075:notes:90]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-19-000075:notes:91]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. For the three months ended October 4, 2019, the Company incurred charges of $68 million recorded in cost of revenue as a result of this incident, which amount primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

[0000106040-19-000075:notes:92]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 is expected in the second half of fiscal year 2020. Meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company committed to pay, among other items, future building depreciation prepayments of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges.

[0000106040-19-000075:notes:93]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-19-000075:notes:94]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-19-000075:notes:95]
Off-Balance Sheet Liabilities

[0000106040-19-000075:notes:96]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-19-000075:notes:97]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019.

[0000106040-19-000075:notes:98]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 181 |  |  | $ | 1,694 |  |

[0000106040-19-000075:notes:99]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 4, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019:

[0000106040-19-000075:notes:100]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2020 |  | $ | 343 |  |  | $ | 56 |  |  | $ | 399 |  |
| 2021 |  | 369 |  |  | 110 |  |  | 479 |  |
| 2022 |  | 284 |  |  | 50 |  |  | 334 |  |
| 2023 |  | 177 |  |  | 67 |  |  | 244 |  |
| 2024 |  | 74 |  |  | 121 |  |  | 195 |  |
| Thereafter |  | 4 |  |  | 39 |  |  | 43 |  |
| Total guarantee obligations |  | $ | 1,251 |  |  | $ | 443 |  |  | $ | 1,694 |  |

[0000106040-19-000075:notes:101]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 4, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-19-000075:notes:102]
Unis Venture

[0000106040-19-000075:notes:103]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three months ended October 4, 2019 and September 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of October 4, 2019 or June 28, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-19-000075:notes:104]
Leases and Other Commitments

[0000106040-19-000075:notes:105]
Leases

[0000106040-19-000075:notes:106]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of October 4, 2019:

[0000106040-19-000075:notes:107]
|  | Lease Amounts |
| Minimum lease payments by fiscal year: | (in millions) |
| Remaining nine months of 2020 | $ | 37 |  |
| 2021 | 40 |  |
| 2022 | 28 |  |
| 2023 | 24 |  |
| 2024 | 27 |  |
| Thereafter | 163 |  |
| Total future minimum lease payments | 319 |  |
| Less: Imputed Interest | (62 | ) |
| Present value of lease liabilities | 257 |  |
| Less: Current portion (included in Accrued expenses) | 40 |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 217 |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 243 |  |
| Weighted average remaining lease term in years | 9.5 |  |
| Weighted average discount rate | 4.1 | % |

[0000106040-19-000075:notes:108]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases for the three months ended October 4, 2019:

[0000106040-19-000075:notes:109]
|  | Three Months Ended |
|  | October 4, 2019 |
|  | (in millions) |
| Cost of operating leases | $ | 12 |  |
| Cash paid for operating leases | 16 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 49 |  |

[0000106040-19-000075:notes:110]
Purchase Agreements and Other Commitments

[0000106040-19-000075:notes:111]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of October 4, 2019, the Company had the following minimum long-term commitments:

[0000106040-19-000075:notes:112]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining nine months of 2020 |  | $ | 70 |  |
| 2021 |  | 183 |  |
| 2022 |  | 250 |  |
| 2023 |  | 267 |  |
| 2024 |  | 40 |  |
| Thereafter |  | 210 |  |
| Total |  | $ | 1,020 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-19-000075:notes:113]
[same as prior period, unchanged from 0000106040-19-000028:notes:185]

[0000106040-19-000075:notes:114]
[same as prior period, unchanged from 0000106040-19-000028:notes:186]

[0000106040-19-000075:notes:115]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-19-000075:notes:116]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions) |
| Options | $ | 2 |  |  | $ | 5 |  |
| Restricted and performance stock units | 66 |  |  | 67 |  |
| Employee stock purchase plan | 9 |  |  | 7 |  |
| Total | $ | 77 |  |  | $ | 79 |  |

[0000106040-19-000075:notes:117]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions) |
| Cost of revenue | $ | 12 |  |  | $ | 11 |  |
| Research and development | 41 |  |  | 39 |  |
| Selling, general and administrative | 24 |  |  | 29 |  |
| Subtotal | 77 |  |  | 79 |  |
| Tax benefit | (12 | ) |  | (11 | ) |
| Total | $ | 65 |  |  | $ | 68 |  |

[0000106040-19-000075:notes:118]
Compensation cost related to unvested stock options, restricted stock units (“RSUs”), performance-based stock units (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of October 4, 2019:

[0000106040-19-000075:notes:119]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 5 |  |  | 0.8 |
| RSUs and PSUs (1) | 722 |  |  | 2.9 |
| ESPP | 56 |  |  | 1.7 |
| Total unamortized compensation cost | $ | 783 |  |  |  |

[0000106040-19-000075:notes:120]
[same as prior period, unchanged from 0000106040-19-000028:notes:189]

[0000106040-19-000075:notes:121]
[same as prior period, unchanged from 0000106040-19-000028:notes:190]

[0000106040-19-000075:notes:122]
[same as prior period, unchanged from 0000106040-19-000028:notes:191]

[0000106040-19-000075:notes:123]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-19-000075:notes:124]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 28, 2019 | 3.9 |  |  | 65.72 |  |  |  |  |  |
| Exercised | (0.6 | ) |  | 43.50 |  |  |  |  | $ | 7 |  |
| Canceled or expired | (0.2 | ) |  | 94.55 |  |  |  |  |  |
| Options outstanding at October 4, 2019 | 3.1 |  |  | $ | 67.75 |  |  | 2.8 |  | $ | 21 |  |
| Exercisable at October 4, 2019 | 2.6 |  |  | $ | 71.51 |  |  | 2.6 |  | $ | 15 |  |

[0000106040-19-000075:notes:125]
[same as prior period, unchanged from 0000106040-19-000028:notes:192]

[0000106040-19-000075:notes:126]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-19-000075:notes:127]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2019 | 11.6 |  |  | 62.07 |  |  |  |
| Granted | 5.4 |  |  | 59.31 |  |  |  |
| Vested | (3.1 | ) |  | 63.67 |  |  | $ | 177 |  |
| Forfeited | (0.4 | ) |  | 62.66 |  |  |  |
| RSUs and PSUs outstanding at October 4, 2019 | 13.5 |  |  | $ | 61.01 |  |  |  |

[0000106040-19-000075:notes:128]
[same as prior period, unchanged from 0000106040-19-000028:notes:193]

[0000106040-19-000075:notes:129]
[same as prior period, unchanged from 0000106040-19-000028:notes:194]

[0000106040-19-000075:notes:130]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of the Company’s common stock, which authorization is effective through July 25, 2023. For the three months ended October 4, 2019, the Company did not make any stock repurchases. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of October 4, 2019 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000075:notes:131]
[same as prior period, unchanged from 0000106040-19-000028:notes:196]

[0000106040-19-000075:notes:132]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the three months ended October 4, 2019, the Company declared aggregate cash dividends of $0.50 per share on its outstanding common stock totaling $149 million, which was paid on October 22, 2019. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-19-000075:notes:133]
Income Tax Expense

[0000106040-19-000075:notes:134]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. However, any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-19-000075:notes:135]
The following table presents the Company’s income tax expense and the effective tax rate:

[0000106040-19-000075:notes:136]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions) |
| Income (loss) before taxes | $ | (237 | ) |  | $ | 583 |  |
| Income tax expense | $ | 39 |  |  | $ | 72 |  |
| Effective tax rate | (16 | )% |  | 12 | % |

[0000106040-19-000075:notes:137]
The primary drivers of the difference between the effective tax rate for the three months ended October 4, 2019 and the

[0000106040-19-000075:notes:138]
U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2020 through 2030.

[0000106040-19-000075:notes:139]
The primary driver of the difference between the effective tax rate for the three months ended September 28, 2018 and the

[0000106040-19-000075:notes:140]
U.S. Federal statutory rate of 21% is the discrete effect of the provisional income tax benefit of $52 million related to the decision to utilize the Company’s 2018 operating loss to partially offset the mandatory deemed repatriation tax.

[0000106040-19-000075:notes:141]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-19-000075:notes:142]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of October 4, 2019, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-19-000075:notes:143]
As of October 4, 2019, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $691 million. Accrued interest and penalties related to unrecognized tax benefits as of October 4, 2019 was approximately $126 million. Of these amounts, approximately $698 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-19-000075:notes:144]
[same as prior period, unchanged from 0000106040-19-000028:notes:63]

[0000106040-19-000075:notes:145]
[same as prior period, unchanged from 0000106040-19-000028:notes:64]

[0000106040-19-000075:notes:146]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (276 | ) |  | $ | 511 |  |
| Weighted average shares outstanding: |  |  |  |
| Basic | 296 |  |  | 292 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | 6 |  |
| Diluted | 296 |  |  | 298 |  |
| Income (loss) per common share |  |  |  |
| Basic | $ | (0.93 | ) |  | $ | 1.75 |  |
| Diluted | $ | (0.93 | ) |  | $ | 1.71 |  |

[0000106040-19-000075:notes:147]
The Company computes basic income (loss) per common share using net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended September 28, 2018, the Company excluded 3 million common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period.  For the three months ended October 4, 2019, the Company recorded a net loss, and all shares subject to outstanding equity awards have been excluded for the period because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-19-000075:notes:148]
[same as prior period, unchanged from 0000106040-19-000028:notes:212]

[0000106040-19-000075:notes:149]
The Company recorded the following charges related to employee terminations benefits, asset impairment, and other charges:

[0000106040-19-000075:notes:150]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | 4 |  |  | $ | 4 |  |
| Business Realignment | 4 |  |  | 42 |  |
| Total employee termination and other charges | $ | 8 |  |  | $ | 46 |  |

[0000106040-19-000075:notes:151]
[same as prior period, unchanged from 0000106040-19-000028:notes:213]

[0000106040-19-000075:notes:152]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company substantially completed the closure in fiscal year 2019.

[0000106040-19-000075:notes:153]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the three months ended October 4, 2019:

[0000106040-19-000075:notes:154]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 28, 2019 | $ | 30 |  |  | $ | 2 |  |  | $ | 32 |  |
| Charges | 2 |  |  | 2 |  |  | 4 |  |
| Cash payments | (18 | ) |  | (3 | ) |  | (21 | ) |
| Accrual balance at October 4, 2019 | $ | 14 |  |  | $ | 1 |  |  | $ | 15 |  |

[0000106040-19-000075:notes:155]
[same as prior period, unchanged from 0000106040-19-000028:notes:215]

[0000106040-19-000075:notes:156]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources.

[0000106040-19-000075:notes:157]
The following table presents an analysis of the components of the activity against the reserve during the three months ended October 4, 2019:

[0000106040-19-000075:notes:158]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 28, 2019 | $ | 37 |  |  | $ | 8 |  |  | $ | 45 |  |
| Charges | 3 |  |  | 1 |  |  | 4 |  |
| Cash payments | (16 | ) |  | (8 | ) |  | (24 | ) |
| Accrual balance at October 4, 2019 | $ | 24 |  |  | $ | 1 |  |  | $ | 25 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-19-000075:notes:159]
Legal Proceedings

[0000106040-19-000075:notes:160]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-19-000075:notes:161]
Intellectual Property Litigation

[0000106040-19-000075:notes:162]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. Mediation in this matter was held on August 16, 2019, and the parties reached an agreement in principle to settle the case for an immaterial amount, a portion of which was previously accrued in the Company’s financial statements. The parties formalized the settlement and filed a joint stipulation of dismissal with prejudice in October 2019. The matter is now closed.

[0000106040-19-000075:notes:163]
Securities

[0000106040-19-000075:notes:164]
Beginning in March 2015, SanDisk Corporation (“SanDisk”), which was acquired by the Company in May 2016, and two of SanDisk’s former officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015. The Institutional Investor Group alleged artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter. In May 2019, the court granted the motion for preliminary approval, and in October 2019, the court issued its final order and judgment approving the settlement.

[0000106040-19-000075:notes:165]
Tax

[0000106040-19-000075:notes:166]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 12, Income Tax Expense.

[0000106040-19-000075:notes:167]
Other Matters

[0000106040-19-000075:notes:168]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## srt:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-19-000075:notes:169]
[same as prior period, unchanged from 0000106040-19-000028:notes:8]

[0000106040-19-000075:notes:170]
The Company’s 4.750% senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the credit agreement governing the revolving credit facility and term loans or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-19-000075:notes:171]
| Condensed Consolidating Balance Sheet |
| As of October 4, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 7 |  |  | $ | 579 |  |  | $ | 2,662 |  |  | $ | — |  |  | $ | 3,248 |  |
| Accounts receivable, net | — |  |  | 1,031 |  |  | 417 |  |  | — |  |  | 1,448 |  |
| Intercompany receivables | 2,514 |  |  | 6,248 |  |  | 1,738 |  |  | (10,500 | ) |  | — |  |
| Inventories | — |  |  | 797 |  |  | 2,602 |  |  | (112 | ) |  | 3,287 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 58 |  |  | (58 | ) |  | — |  |
| Other current assets | — |  |  | 263 |  |  | 254 |  |  | — |  |  | 517 |  |
| Total current assets | 2,521 |  |  | 8,918 |  |  | 7,731 |  |  | (10,670 | ) |  | 8,500 |  |
| Property, plant and equipment, net | — |  |  | 857 |  |  | 1,939 |  |  | — |  |  | 2,796 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,629 |  |  | — |  |  | 2,629 |  |
| Goodwill | — |  |  | 390 |  |  | 9,700 |  |  | — |  |  | 10,090 |  |
| Other intangible assets, net | — |  |  | 19 |  |  | 1,495 |  |  | — |  |  | 1,514 |  |
| Investments in consolidated subsidiaries | 20,616 |  |  | 15,884 |  |  | — |  |  | (36,500 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 1,164 |  |  | — |  |  | (1,164 | ) |  | — |  |
| Other non-current assets | 58 |  |  | 237 |  |  | 456 |  |  | — |  |  | 751 |  |
| Total assets | $ | 23,195 |  |  | $ | 27,469 |  |  | $ | 23,950 |  |  | $ | (48,334 | ) |  | $ | 26,280 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 166 |  |  | $ | 1,558 |  |  | $ | — |  |  | $ | 1,724 |  |
| Accounts payable to related parties | — |  |  | 42 |  |  | 465 |  |  | — |  |  | 507 |  |
| Intercompany payables | 2,067 |  |  | 3,702 |  |  | 4,731 |  |  | (10,500 | ) |  | — |  |
| Accrued expenses | 174 |  |  | 689 |  |  | 511 |  |  | — |  |  | 1,374 |  |
| Accrued compensation | — |  |  | 263 |  |  | 169 |  |  | — |  |  | 432 |  |
| Loans due to consolidated affiliates | — |  |  | 58 |  |  | — |  |  | (58 | ) |  | — |  |
| Current portion of long-term debt | 251 |  |  | — |  |  | — |  |  | — |  |  | 251 |  |
| Total current liabilities | 2,492 |  |  | 4,920 |  |  | 7,434 |  |  | (10,558 | ) |  | 4,288 |  |
| Long-term debt | 9,927 |  |  | — |  |  | 34 |  |  | — |  |  | 9,961 |  |
| Loans due to consolidated affiliates | 1,141 |  |  | — |  |  | 23 |  |  | (1,164 | ) |  | — |  |
| Other liabilities | 69 |  |  | 1,853 |  |  | 543 |  |  | — |  |  | 2,465 |  |
| Total liabilities | 13,629 |  |  | 6,773 |  |  | 8,034 |  |  | (11,722 | ) |  | 16,714 |  |
| Total shareholders’ equity | 9,566 |  |  | 20,696 |  |  | 15,916 |  |  | (36,612 | ) |  | 9,566 |  |
| Total liabilities and shareholders’ equity | $ | 23,195 |  |  | $ | 27,469 |  |  | $ | 23,950 |  |  | $ | (48,334 | ) |  | $ | 26,280 |  |

[0000106040-19-000075:notes:172]
| Condensed Consolidating Balance Sheet |
| As of June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 8 |  |  | $ | 985 |  |  | $ | 2,462 |  |  | $ | — |  |  | $ | 3,455 |  |
| Accounts receivable, net | — |  |  | 779 |  |  | 425 |  |  | — |  |  | 1,204 |  |
| Intercompany receivables | 2,409 |  |  | 5,808 |  |  | 1,581 |  |  | (9,798 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,438 |  |  | (145 | ) |  | 3,283 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 50 |  |  | (50 | ) |  | — |  |
| Other current assets | 2 |  |  | 251 |  |  | 282 |  |  | — |  |  | 535 |  |
| Total current assets | 2,419 |  |  | 8,813 |  |  | 7,238 |  |  | (9,993 | ) |  | 8,477 |  |
| Property, plant and equipment, net | — |  |  | 873 |  |  | 1,970 |  |  | — |  |  | 2,843 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,791 |  |  | — |  |  | 2,791 |  |
| Goodwill | — |  |  | 388 |  |  | 9,688 |  |  | — |  |  | 10,076 |  |
| Other intangible assets, net | — |  |  | 23 |  |  | 1,688 |  |  | — |  |  | 1,711 |  |
| Investments in consolidated subsidiaries | 20,772 |  |  | 16,355 |  |  | — |  |  | (37,127 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 674 |  |  | — |  |  | (674 | ) |  | — |  |
| Other non-current assets | 60 |  |  | 51 |  |  | 361 |  |  | — |  |  | 472 |  |
| Total assets | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 195 |  |  | $ | 1,372 |  |  | $ | — |  |  | $ | 1,567 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 331 |  |  | — |  |  | 331 |  |
| Intercompany payables | 1,871 |  |  | 3,515 |  |  | 4,412 |  |  | (9,798 | ) |  | — |  |
| Accrued expenses | 195 |  |  | 522 |  |  | 579 |  |  | — |  |  | 1,296 |  |
| Accrued compensation | — |  |  | 214 |  |  | 133 |  |  | — |  |  | 347 |  |
| Loans due to consolidated affiliates | — |  |  | 50 |  |  | — |  |  | (50 | ) |  | — |  |
| Current portion of long-term debt | 276 |  |  | — |  |  | — |  |  | — |  |  | 276 |  |
| Total current liabilities | 2,342 |  |  | 4,496 |  |  | 6,827 |  |  | (9,848 | ) |  | 3,817 |  |
| Long-term debt | 10,213 |  |  | — |  |  | 33 |  |  | — |  |  | 10,246 |  |
| Loans due to consolidated affiliates | 674 |  |  | — |  |  | — |  |  | (674 | ) |  | — |  |
| Other liabilities | 55 |  |  | 1,795 |  |  | 490 |  |  | — |  |  | 2,340 |  |
| Total liabilities | 13,284 |  |  | 6,291 |  |  | 7,350 |  |  | (10,522 | ) |  | 16,403 |  |
| Total shareholders’ equity | 9,967 |  |  | 20,886 |  |  | 16,386 |  |  | (37,272 | ) |  | 9,967 |  |
| Total liabilities and shareholders’ equity | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |

[0000106040-19-000075:notes:173]
| Condensed Consolidating Statement of Operations |
| For the three months ended October 4, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,361 |  |  | $ | 3,984 |  |  | $ | (3,305 | ) |  | $ | 4,040 |  |
| Cost of revenue | — |  |  | 2,952 |  |  | 3,690 |  |  | (3,360 | ) |  | 3,282 |  |
| Gross profit | — |  |  | 409 |  |  | 294 |  |  | 55 |  |  | 758 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 364 |  |  | 210 |  |  | — |  |  | 574 |  |
| Selling, general and administrative | 1 |  |  | 203 |  |  | 101 |  |  | — |  |  | 305 |  |
| Intercompany operating expense (income) | 3 |  |  | (425 | ) |  | 422 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total operating expenses | 4 |  |  | 142 |  |  | 741 |  |  | — |  |  | 887 |  |
| Operating income (loss) | (4 | ) |  | 267 |  |  | (447 | ) |  | 55 |  |  | (129 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 12 |  |  | 10 |  |  | (10 | ) |  | 12 |  |
| Interest expense | (131 | ) |  | — |  |  | (1 | ) |  | 10 |  |  | (122 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total interest and other income (expense), net | (131 | ) |  | 12 |  |  | 11 |  |  | — |  |  | (108 | ) |
| Income (loss) before taxes | (135 | ) |  | 279 |  |  | (436 | ) |  | 55 |  |  | (237 | ) |
| Equity in earnings from subsidiaries | (164 | ) |  | (460 | ) |  | — |  |  | 624 |  |  | — |  |
| Income tax expense (benefit) | (23 | ) |  | 39 |  |  | 23 |  |  | — |  |  | 39 |  |
| Net loss | $ | (276 | ) |  | $ | (220 | ) |  | $ | (459 | ) |  | $ | 679 |  |  | $ | (276 | ) |

[0000106040-19-000075:notes:174]
| Condensed Consolidating Statement of Operations |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,485 |  |  | $ | 4,996 |  |  | $ | (3,453 | ) |  | $ | 5,028 |  |
| Cost of revenue | — |  |  | 3,005 |  |  | 3,824 |  |  | (3,465 | ) |  | 3,364 |  |
| Gross profit | — |  |  | 480 |  |  | 1,172 |  |  | 12 |  |  | 1,664 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 363 |  |  | 213 |  |  | — |  |  | 576 |  |
| Selling, general and administrative | 1 |  |  | 251 |  |  | 104 |  |  | — |  |  | 356 |  |
| Intercompany operating expense (income) | — |  |  | (407 | ) |  | 407 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 32 |  |  | 14 |  |  | — |  |  | 46 |  |
| Total operating expenses | 1 |  |  | 239 |  |  | 738 |  |  | — |  |  | 978 |  |
| Operating income (loss) | (1 | ) |  | 241 |  |  | 434 |  |  | 12 |  |  | 686 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 8 |  |  | 3 |  |  | 12 |  |  | (8 | ) |  | 15 |  |
| Interest expense | (116 | ) |  | (6 | ) |  | (2 | ) |  | 8 |  |  | (116 | ) |
| Other income (expense), net | 1 |  |  | — |  |  | (1 | ) |  | (2 | ) |  | (2 | ) |
| Total interest and other income (expense), net | (107 | ) |  | (3 | ) |  | 9 |  |  | (2 | ) |  | (103 | ) |
| Income (loss) before taxes | (108 | ) |  | 238 |  |  | 443 |  |  | 10 |  |  | 583 |  |
| Equity in earnings from subsidiaries | 475 |  |  | 345 |  |  | — |  |  | (820 | ) |  | — |  |
| Income tax expense (benefit) | (144 | ) |  | 118 |  |  | 98 |  |  | — |  |  | 72 |  |
| Net income | $ | 511 |  |  | $ | 465 |  |  | $ | 345 |  |  | $ | (810 | ) |  | $ | 511 |  |

[0000106040-19-000075:notes:175]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended October 4, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (276 | ) |  | $ | (220 | ) |  | $ | (459 | ) |  | $ | 679 |  |  | $ | (276 | ) |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 5 |  |  | 5 |  |  | 5 |  |  | (10 | ) |  | 5 |  |
| Net unrealized loss, on derivative contracts and available-for-sale securities | (33 | ) |  | (8 | ) |  | (9 | ) |  | 17 |  |  | (33 | ) |
| Total other comprehensive loss, before tax | (27 | ) |  | (2 | ) |  | (3 | ) |  | 5 |  |  | (27 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | 5 |  |  | (1 | ) |  | (1 | ) |  | 2 |  |  | 5 |  |
| Other comprehensive loss, net of tax | (22 | ) |  | (3 | ) |  | (4 | ) |  | 7 |  |  | (22 | ) |
| Total comprehensive loss | $ | (298 | ) |  | $ | (223 | ) |  | $ | (463 | ) |  | $ | 686 |  |  | $ | (298 | ) |

[0000106040-19-000075:notes:176]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 511 |  |  | $ | 465 |  |  | $ | 345 |  |  | $ | (810 | ) |  | $ | 511 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | (37 | ) |  | (34 | ) |  | (34 | ) |  | 68 |  |  | (37 | ) |
| Net unrealized loss, on derivative contracts and available-for-sale securities | (1 | ) |  | (8 | ) |  | (10 | ) |  | 18 |  |  | (1 | ) |
| Total other comprehensive loss, before tax | (38 | ) |  | (42 | ) |  | (44 | ) |  | 86 |  |  | (38 | ) |
| Income tax benefit related to items of other comprehensive loss | 1 |  |  | — |  |  | 1 |  |  | (1 | ) |  | 1 |  |
| Other comprehensive loss, net of tax | (37 | ) |  | (42 | ) |  | (43 | ) |  | 85 |  |  | (37 | ) |
| Total comprehensive income | $ | 474 |  |  | $ | 423 |  |  | $ | 302 |  |  | $ | (725 | ) |  | $ | 474 |  |

[0000106040-19-000075:notes:177]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended October 4, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (178 | ) |  | $ | 204 |  |  | $ | 200 |  |  | $ | 27 |  |  | $ | 253 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (46 | ) |  | (99 | ) |  | — |  |  | (145 | ) |
| Acquisitions, net of cash acquired | — |  |  | (2 | ) |  | (20 | ) |  | — |  |  | (22 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (171 | ) |  | — |  |  | (171 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 357 |  |  | — |  |  | 357 |  |
| Strategic investments and other, net | — |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Intercompany loan from (to) consolidated affiliates | — |  |  | (490 | ) |  | (8 | ) |  | 498 |  |  | — |  |
| Advances from (to) parent and consolidated affiliates | 126 |  |  | (126 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 126 |  |  | (664 | ) |  | 74 |  |  | 498 |  |  | 34 |  |
| Cash flows from financing activities |  |  |  |  |  |  | — |  |  |  |
| Issuance of stock under employee stock plans | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |
| Taxes paid on vested stock awards under employee stock plans | (52 | ) |  | — |  |  | — |  |  | — |  |  | (52 | ) |
| Dividends paid to shareholders | (147 | ) |  | — |  |  | — |  |  | — |  |  | (147 | ) |
| Repayment of debt | (319 | ) |  | — |  |  | — |  |  | — |  |  | (319 | ) |
| Intercompany loan from (to) consolidated affiliates | 467 |  |  | 8 |  |  | 23 |  |  | (498 | ) |  | — |  |
| Change in investment in consolidated subsidiaries | 76 |  |  | 46 |  |  | (95 | ) |  | (27 | ) |  | — |  |
| Net cash provided by (used in) financing activities | 51 |  |  | 54 |  |  | (72 | ) |  | (525 | ) |  | (492 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net increase (decrease) in cash and cash equivalents | (1 | ) |  | (406 | ) |  | 200 |  |  | — |  |  | (207 | ) |
| Cash and cash equivalents, beginning of year | 8 |  |  | 985 |  |  | 2,462 |  |  | — |  |  | 3,455 |  |
| Cash and cash equivalents, end of period | $ | 7 |  |  | $ | 579 |  |  | $ | 2,662 |  |  | $ | — |  |  | $ | 3,248 |  |

[0000106040-19-000075:notes:178]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (101 | ) |  | $ | (691 | ) |  | $ | 1,244 |  |  | $ | 253 |  |  | $ | 705 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (63 | ) |  | (214 | ) |  | — |  |  | (277 | ) |
| Purchases of investments | — |  |  | (2 | ) |  | (9 | ) |  | — |  |  | (11 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (115 | ) |  | — |  |  | (115 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 144 |  |  | — |  |  | 144 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Intercompany loan from (to) consolidated affiliates | 696 |  |  | — |  |  | — |  |  | (696 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | 97 |  |  | (97 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 793 |  |  | (162 | ) |  | (194 | ) |  | (696 | ) |  | (259 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Taxes paid on vested stock awards under employee stock plans | (66 | ) |  | — |  |  | — |  |  | — |  |  | (66 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Dividends paid to shareholders | (148 | ) |  | — |  |  | — |  |  | — |  |  | (148 | ) |
| Repayment of debt | (38 | ) |  | — |  |  | — |  |  | — |  |  | (38 | ) |
| Intercompany loan from (to) consolidated affiliates | — |  |  | (180 | ) |  | (516 | ) |  | 696 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 80 |  |  | 1,426 |  |  | (1,253 | ) |  | (253 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (727 | ) |  | 1,246 |  |  | (1,769 | ) |  | 443 |  |  | (807 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net increase (decrease) in cash and cash equivalents | (35 | ) |  | 393 |  |  | (717 | ) |  | — |  |  | (359 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | $ | 5 |  |  | $ | 1,061 |  |  | $ | 3,580 |  |  | $ | — |  |  | $ | 4,646 |  |
