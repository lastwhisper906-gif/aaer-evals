# WDC note change history — 0000106040-16-000040 → 0000106040-17-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:1]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, referred to as “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.
  (was, 2016-11-08, similarity 0.986):
[0000106040-16-000040:note_history:1]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through these ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

- changed (2017-02-07):
[0000106040-17-000007:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 30, 2016 and July 1, 2016:
  (was, 2016-11-08, similarity 0.7773):
[0000106040-16-000040:note_history:2]
The following table presents, as of September 30, 2016, the notes receivable from and equity investments in Flash Ventures:

- changed (2017-02-07):
[0000106040-17-000007:note_history:3]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 138 |  |  | 235 |  |
| Notes receivable, Flash Forward | 248 |  |  | 263 |  |
| Investment in Flash Partners | 178 |  |  | 202 |  |
| Investment in Flash Alliance | 267 |  |  | 306 |  |
| Investment in Flash Forward | 106 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,082 |  |  | $ | 1,171 |  |
  (was, 2016-11-08, similarity 0.9919):
[0000106040-16-000040:note_history:3]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 63 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 196 |  |  | 235 |  |
| Notes receivable, Flash Forward | 321 |  |  | 263 |  |
| Investment in Flash Partners | 205 |  |  | 202 |  |
| Investment in Flash Alliance | 310 |  |  | 306 |  |
| Investment in Flash Forward | 122 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,217 |  |  | $ | 1,171 |  |

- added (2017-02-07):
[0000106040-17-000007:note_history:4]
During the three and six months ended December 30, 2016, the Company made net payments to Flash Ventures of $766 million and $1.5 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.

- added (2017-02-07):
[0000106040-17-000007:note_history:5]
As of December 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $175 million and $168 million, respectively.

- added (2017-02-07):
[0000106040-17-000007:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2016, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2017-02-07):
[0000106040-17-000007:note_history:7]
|  | December 30, 2016 |
|  | (in millions) |
| Notes receivable | $ | 531 |  |
| Equity investments | 551 |  |
| Operating lease guarantees | 1,102 |  |
| Prepayments | 26 |  |
| Maximum estimable loss exposure | $ | 2,210 |  |

- changed (2017-02-07):
[0000106040-17-000007:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016.
  (was, 2016-11-08, similarity 0.9725):
[0000106040-16-000040:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016.

- changed (2017-02-07):
[0000106040-17-000007:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016:
  (was, 2016-11-08, similarity 0.9492):
[0000106040-16-000040:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the lease agreements, in annual installments as of September 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016:

- changed (2017-02-07):
[0000106040-17-000007:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 269 |  |  | $ | 47 |  |  | $ | 316 |  |
| Year 2 |  | 230 |  |  | — |  |  | 230 |  |
| Year 3 |  | 184 |  |  | 71 |  |  | 255 |  |
| Year 4 |  | 108 |  |  | 58 |  |  | 166 |  |
| Year 5 |  | 33 |  |  | 102 |  |  | 135 |  |
| Total guarantee obligations |  | $ | 824 |  |  | $ | 278 |  |  | $ | 1,102 |  |
  (was, 2016-11-08, similarity 0.9976):
[0000106040-16-000040:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 298 |  |  | $ | 71 |  |  | $ | 369 |  |
| Year 2 |  | 247 |  |  | 11 |  |  | 258 |  |
| Year 3 |  | 203 |  |  | 59 |  |  | 262 |  |
| Year 4 |  | 125 |  |  | 73 |  |  | 198 |  |
| Year 5 |  | 39 |  |  | 109 |  |  | 148 |  |
| Total guarantee obligations |  | $ | 912 |  |  | $ | 323 |  |  | $ | 1,235 |  |

- changed (2017-02-07):
[0000106040-17-000007:note_history:11]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.
  (was, 2016-11-08, similarity 0.9931):
[0000106040-16-000040:note_history:11]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.

- removed (2017-02-07):
[0000106040-16-000040:note_history:12]
During the three months ended September 30, 2016, the Company purchased NAND flash memory wafers from Flash Ventures and made loans to, and investments in, Flash Ventures totaling $127 million and $20 million, respectively, and received loan repayments from Flash Ventures of $120 million. At September 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $190 million and $168 million, respectively.

- removed (2017-02-07):
[0000106040-16-000040:note_history:13]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2016, is presented below. Flash Ventures’ investments are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2017-02-07):
[0000106040-16-000040:note_history:14]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable | $ | 580 |  |  | $ | 563 |  |
| Equity investments | 637 |  |  | 608 |  |
| Operating lease guarantees | 1,235 |  |  | 1,151 |  |
| Prepayments | 30 |  |  | 34 |  |
| Maximum estimable loss exposure | $ | 2,482 |  |  | $ | 2,356 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:15]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.
  (was, 2016-11-08, similarity 0.96):
[0000106040-16-000040:note_history:15]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

- changed (2017-02-07):
[0000106040-17-000007:note_history:16]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the District Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.
  (was, 2016-11-08, similarity 0.9739):
[0000106040-16-000040:note_history:16]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

- changed (2017-02-07):
[0000106040-17-000007:note_history:17]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.
  (was, 2016-11-08, similarity 0.9663):
[0000106040-16-000040:note_history:17]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

- added (2017-02-07):
[0000106040-17-000007:note_history:18]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints – one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California – against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,452; RE45,486; 7,464,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The Company intends to defend itself vigorously in these matters.

- changed (2017-02-07):
[0000106040-17-000007:note_history:19]
In June 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint with the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. In February 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. In May 2015, the District Court granted in part plaintiffs’ motion for class certification. In April 2016, the District Court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk’s favor as to all of the plaintiffs’ claims. In May 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.
  (was, 2016-11-08, similarity 0.9302):
[0000106040-16-000040:note_history:19]
On June 25, 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint captioned Ritz Camera & Image, LLC v. SanDisk Corporation, Inc. and Eliyahou Harari in the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 25, 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. On February 24, 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. On May 14, 2015, the District Court granted in part plaintiffs’ motion for class certification. On April 29, 2016, the court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk's favor as to all of the plaintiffs’ claims. On May 31, 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

- added (2017-02-07):
[0000106040-17-000007:note_history:20]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In August 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint in September 2011. In January 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. In April 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint in January 2015. In September 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. In October 2015, Samsung filed a fourth amended complaint. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

- added (2017-02-07):
[0000106040-17-000007:note_history:21]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In May 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. In May 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. In February 2015, the plaintiffs filed a second amended complaint in the District Court. In September 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. In November 2015, the plaintiffs filed a third amended complaint. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

- changed (2017-02-07):
[0000106040-17-000007:note_history:22]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss in April 2016. In June 2016, the District Court granted the motion and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. The defendants filed a motion to dismiss in August 2016. In January 2017, the District Court denied the motion to dismiss without prejudice to the defendants filing a renewed motion to dismiss, which the defendants filed soon thereafter. The Company intends to defend itself vigorously in this matter.
  (was, 2016-11-08, similarity 0.839):
[0000106040-16-000040:note_history:22]
Beginning on March 30, 2015, SanDisk and two officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed in the United States District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 16, 2014 and March 25, 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 16, 2014 and April 15, 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. On July 9, 2015, the Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. On January 22, 2016, the court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. On February 22, 2016, the court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). On March 23, 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss on April 29, 2016. On June 24, 2016, the court granted the motion and dismissed the amended complaint with leave to amend. On July 15, 2016, the Institutional Investor Group filed a further amended complaint. The Company filed a motion to dismiss on August 19, 2016. The Company intends to defend itself vigorously in this matter.

- changed (2017-02-07):
[0000106040-17-000007:note_history:23]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue.  In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.
  (was, 2016-11-08, similarity 0.989):
[0000106040-16-000040:note_history:23]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.

- removed (2017-02-07):
[0000106040-16-000040:note_history:24]
On July 15, 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) in the U.S. District Court for the Northern District of California, alleging that defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. On August 25, 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint on September 16, 2011. On January 3, 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. On April 4, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint on January 20, 2015. On September 30, 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. On October 21, 2015, Samsung filed a fourth amended complaint. On November 4, 2015, the defendants filed a motion to dismiss. On September 26, 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

- removed (2017-02-07):
[0000106040-16-000040:note_history:25]
On March 15, 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. in the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of Secure Digital (“SD”) cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD™ cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. On May 21, 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. On May 14, 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. On February 3, 2015, the plaintiffs filed a second amended complaint in the District Court. On September 30, 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. On November 4, 2015, the plaintiffs filed a third amended complaint. On November 25, 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. On October 3, 2016, the District Court granted the defendants’ motion with leave to amend. On October 21, 2016, the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:26]
Certain prior year amounts have been reclassified in the condensed consolidated statements of operations and condensed consolidated statements of cash flows to conform to the current year presentation.
  (was, 2016-11-08, similarity 0.8481):
[0000106040-16-000040:note_history:26]
Certain prior year amounts have been reclassified in the condensed consolidated statement of cash flows to conform to the current year presentation.

- removed (2017-02-07):
[0000106040-16-000040:note_history:27]
Accounting Changes and Recent Accounting Pronouncements

- removed (2017-02-07):
[0000106040-16-000040:note_history:28]
Recently Adopted

- removed (2017-02-07):
[0000106040-16-000040:note_history:29]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015-05 at the beginning of the current year did not have a material impact on its condensed consolidated financial statements.

- removed (2017-02-07):
[0000106040-16-000040:note_history:30]
Recently Issued

- removed (2017-02-07):
[0000106040-16-000040:note_history:31]
In October 2016, the FASB issued ASU No. 2016-16, “Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). The new standard removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The ASU is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

- removed (2017-02-07):
[0000106040-16-000040:note_history:32]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230)” (“ASU 2016-15”). The new standard addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which among others, includes the Company’s disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2019. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements and related disclosures.

- removed (2017-02-07):
[0000106040-16-000040:note_history:33]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within those years, which for the Company is the first quarter of 2018. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2018. The Company is currently evaluating the impact ASU 2016-09 will have on its consolidated financial statements and related disclosures.

- removed (2017-02-07):
[0000106040-16-000040:note_history:34]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for the Company is the first quarter of 2020. Early adoption is permitted. The Company expects to adopt this standard in the first quarter of 2020. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements and related disclosures.

- removed (2017-02-07):
[0000106040-16-000040:note_history:35]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”), which provides guidance related to accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of 2019. Early adoption is not permitted. The Company is currently evaluating the impact ASU 2016-01 will have on its consolidated financial statements.

- removed (2017-02-07):
[0000106040-16-000040:note_history:36]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (“ASU 2014-09”), which amends the guidance in former Accounting Standards Codification Topic 605, “Revenue Recognition,” to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The Company does not expect the proposed standard to materially change the timing of revenue recognition for product revenue; however, the proposed standard may accelerate the timing of revenue recognition for the Company’s license and royalty contracts. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2015-14 by one year. The new standard allows for either a full retrospective or a modified retrospective transition method. Early application is permitted only as of annual reporting periods beginning after December 15, 2016, which for the Company is the first quarter of 2018. The Company has not yet selected a transition method and currently expects to adopt this standard in the first quarter of 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:37]
Debt consisted of the following as of December 30, 2016 and July 1, 2016:
  (was, 2016-11-08, similarity 0.9612):
[0000106040-16-000040:note_history:37]
Debt consisted of the following as of September 30, 2016 and July 1, 2016:

- changed (2017-02-07):
[0000106040-17-000007:note_history:38]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,985 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 929 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,299 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (226 | ) |  | (532 | ) |
| Subtotal | 13,073 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (129 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,944 |  |  | $ | 13,660 |  |
  (was, 2016-11-08, similarity 0.9957):
[0000106040-16-000040:note_history:38]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,993 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 990 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 37 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,370 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (237 | ) |  | (532 | ) |
| Subtotal | 13,133 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (78 | ) |  | (3,334 | ) |
| Long-term debt | $ | 13,055 |  |  | $ | 13,660 |  |

- changed (2017-02-07):
[0000106040-17-000007:note_history:39]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of December 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2016-11-08, similarity 0.9872):
[0000106040-16-000040:note_history:39]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of September 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

- added (2017-02-07):
[0000106040-17-000007:note_history:40]
Credit Agreement – Term Loans and Revolving Credit Facility

- changed (2017-02-07):
[0000106040-17-000007:note_history:41]
On April 29, 2016, the Company entered into a credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. The revolving credit facility includes a $200 million sublimit for letters of credit.
  (was, 2016-11-08, similarity 0.6062):
[0000106040-16-000040:note_history:41]
On April 29, 2016, the Company entered into a new credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. As described above, during the first quarter ended September 30, 2016, the U.S. Term Loan B and Euro Term Loan B were settled and replaced with the $3.0 billion U.S. Term Loan B-1 and the €885 million Euro Term Loan B-1, respectively.

- changed (2017-02-07):
[0000106040-17-000007:note_history:42]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.52% as of December 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $6 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $5 million remain unamortized.
  (was, 2016-11-08, similarity 0.9749):
[0000106040-16-000040:note_history:42]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement (as defined below) and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.50% at September 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $5 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $5 million remain unamortized.

- changed (2017-02-07):
[0000106040-17-000007:note_history:43]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% as of December 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $2 million remain unamortized.
  (was, 2016-11-08, similarity 0.9852):
[0000106040-16-000040:note_history:43]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% at September 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of September 30, 2016, issuance costs of $2 million remain unamortized.

- added (2017-02-07):
[0000106040-17-000007:note_history:44]
As of December 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance.

- changed (2017-02-07):
[0000106040-17-000007:note_history:45]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of December 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.775%.
  (was, 2016-11-08, similarity 0.6871):
[0000106040-16-000040:note_history:45]
The revolving credit facility includes a $200 million sublimit for letters of credit. As of September 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance. Beginning in September 2017, we are required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of September 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.526%.

- changed (2017-02-07):
[0000106040-17-000007:note_history:46]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.
  (was, 2016-11-08, similarity 0.9864):
[0000106040-16-000040:note_history:46]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require us to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

- changed (2017-02-07):
[0000106040-17-000007:note_history:47]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.
  (was, 2016-11-08, similarity 0.9862):
[0000106040-16-000040:note_history:47]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

- added (2017-02-07):
[0000106040-17-000007:note_history:48]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. On February 6, 2017, substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.

- changed (2017-02-07):
[0000106040-17-000007:note_history:49]
The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.
  (was, 2016-11-08, similarity 0.7299):
[0000106040-16-000040:note_history:49]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

- changed (2017-02-07):
[0000106040-17-000007:note_history:50]
During the three months ended December 30, 2016, the Company repurchased Convertible Notes for $3 million of cash. During the six months ended December 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $493 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.
  (was, 2016-11-08, similarity 0.8055):
[0000106040-16-000040:note_history:50]
During the three months ended September 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $490 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

- changed (2017-02-07):
[0000106040-17-000007:note_history:51]
As of December 30, 2016, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.
  (was, 2016-11-08, similarity 0.9557):
[0000106040-16-000040:note_history:51]
As of September 30, 2016, $37 million principal amount of the 2020 Notes and less than $1 million principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

- changed (2017-02-07):
[0000106040-17-000007:note_history:52]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and six months ended December 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.
  (was, 2016-11-08, similarity 0.9349):
[0000106040-16-000040:note_history:52]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported in Other income (expense), net in the condensed consolidated statements of operations until the Company extinguishes the related debt. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in accrued expenses and other liabilities in the condensed consolidated balance sheets. See Note 10 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three months ended September 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.

- changed (2017-02-07):
[0000106040-17-000007:note_history:53]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the six months ended December 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and six months ended December 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of December 30, 2016 was immaterial.
  (was, 2016-11-08, similarity 0.9553):
[0000106040-16-000040:note_history:53]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in other current assets and other non-current assets in the condensed consolidated balance sheets. During the three months ended September 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three months ended September 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options at September 30, 2016 was immaterial.

- changed (2017-02-07):
[0000106040-17-000007:note_history:54]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three and six months ended December 30, 2016 resulted in an immaterial net loss.
  (was, 2016-11-08, similarity 0.8914):
[0000106040-16-000040:note_history:54]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three months ended September 30, 2016 resulted in a net loss of $5 million.

- removed (2017-02-07):
[0000106040-16-000040:note_history:55]
Term Loans

- removed (2017-02-07):
[0000106040-16-000040:note_history:56]
Credit Agreement

- removed (2017-02-07):
[0000106040-16-000040:note_history:57]
Covenants


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:58]
Debt consisted of the following as of December 30, 2016 and July 1, 2016:
  (was, 2016-11-08, similarity 0.9612):
[0000106040-16-000040:note_history:58]
Debt consisted of the following as of September 30, 2016 and July 1, 2016:

- changed (2017-02-07):
[0000106040-17-000007:note_history:59]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,985 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 929 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,299 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (226 | ) |  | (532 | ) |
| Subtotal | 13,073 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (129 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,944 |  |  | $ | 13,660 |  |
  (was, 2016-11-08, similarity 0.9957):
[0000106040-16-000040:note_history:59]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,993 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 990 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 37 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,370 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (237 | ) |  | (532 | ) |
| Subtotal | 13,133 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (78 | ) |  | (3,334 | ) |
| Long-term debt | $ | 13,055 |  |  | $ | 13,660 |  |

- changed (2017-02-07):
[0000106040-17-000007:note_history:60]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of December 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2016-11-08, similarity 0.9872):
[0000106040-16-000040:note_history:60]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of September 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0000106040-17-000007:note_history:61]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 30, 2016 and July 1, 2016:
  (was, 2016-11-08, similarity 0.7773):
[0000106040-16-000040:note_history:61]
The following table presents, as of September 30, 2016, the notes receivable from and equity investments in Flash Ventures:

- changed (2017-02-07):
[0000106040-17-000007:note_history:62]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 138 |  |  | 235 |  |
| Notes receivable, Flash Forward | 248 |  |  | 263 |  |
| Investment in Flash Partners | 178 |  |  | 202 |  |
| Investment in Flash Alliance | 267 |  |  | 306 |  |
| Investment in Flash Forward | 106 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,082 |  |  | $ | 1,171 |  |
  (was, 2016-11-08, similarity 0.9919):
[0000106040-16-000040:note_history:62]
|  | September 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 63 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 196 |  |  | 235 |  |
| Notes receivable, Flash Forward | 321 |  |  | 263 |  |
| Investment in Flash Partners | 205 |  |  | 202 |  |
| Investment in Flash Alliance | 310 |  |  | 306 |  |
| Investment in Flash Forward | 122 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,217 |  |  | $ | 1,171 |  |
