# WDC MD&A — 0000106040-17-000007


## mdna

[0000106040-17-000007:mdna:1]
[same as prior period, unchanged from 0000106040-16-000040:mdna:1]

[0000106040-17-000007:mdna:2]
[same as prior period, unchanged from 0000106040-16-000040:mdna:2]

[0000106040-17-000007:mdna:3]
[same as prior period, unchanged from 0000106040-16-000040:mdna:3]

[0000106040-17-000007:mdna:4]
[same as prior period, unchanged from 0000106040-16-000040:mdna:4]

[0000106040-17-000007:mdna:5]
[same as prior period, unchanged from 0000106040-16-000040:mdna:5]

[0000106040-17-000007:mdna:6]
[same as prior period, unchanged from 0000106040-16-000040:mdna:6]

[0000106040-17-000007:mdna:7]
[same as prior period, unchanged from 0000106040-16-000040:mdna:7]

[0000106040-17-000007:mdna:8]
During the first half of 2017, we settled certain debt facilities and entered into new debt facilities at lower rates. The financing arrangement activities during the first half of 2017 were:

[0000106040-17-000007:mdna:9]
[same as prior period, unchanged from 0000106040-16-000040:mdna:9]

[0000106040-17-000007:mdna:10]
| • | We settled our $3.750 billion U.S. Term Loan B tranche with a new issuance of a $3.0 billion six-year U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) at an interest rate lower than our U.S. Term Loan B tranche. Proceeds from this new loan and a voluntary cash prepayment of $750 million were used to settle our U.S. Term Loan B tranche. |

[0000106040-17-000007:mdna:11]
| • | We settled our €885 million Euro Term Loan B tranche with a new issuance of a €885 million seven-year Euro-denominated term loan (“Euro Term Loan B-1”) at an interest rate lower than our Euro Term Loan B tranche. |

[0000106040-17-000007:mdna:12]
| • | We paid to the holders of our Convertible Notes (as defined below), for conversion and repurchase, $493 million of cash and 0.3 million shares of our common stock with an aggregate value of $16 million. In conjunction with the settlements, we received from the exercise of the related call options, $61 million of cash and 0.1 million shares of our common stock which had an aggregate value of $11 million. |

[0000106040-17-000007:mdna:13]
For additional information regarding our debt facilities, see Part I, Item 1, Note 6, in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:14]
[same as prior period, unchanged from 0000106040-16-000040:mdna:119]

[0000106040-17-000007:mdna:15]
[same as prior period, unchanged from 0000106040-16-000040:mdna:17]

[0000106040-17-000007:mdna:16]
Second Quarter and First Half Overview

[0000106040-17-000007:mdna:17]
[same as prior period, unchanged from 0000106040-16-000040:mdna:19]

[0000106040-17-000007:mdna:18]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | % Change |  | December 30, 2016 |  | January 1, 2016 |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 4,888 |  |  | 100.0 | % |  | $ | 3,317 |  |  | 100.0 | % |  | 47 | % |  | $ | 9,602 |  |  | 100.0 | % |  | $ | 6,677 |  |  | 100.0 | % |  | 44 | % |
| Gross profit | 1,533 |  |  | 31.4 |  |  | 906 |  |  | 27.3 |  |  | 69 |  |  | 2,868 |  |  | 29.9 |  |  | 1,861 |  |  | 27.9 |  |  | 54 |  |
| Total operating expenses | 988 |  |  | 20.2 |  |  | 655 |  |  | 19.7 |  |  | 51 |  |  | 2,091 |  |  | 21.8 |  |  | 1,288 |  |  | 19.3 |  |  | 62 |  |
| Operating income | 545 |  |  | 11.1 |  |  | 251 |  |  | 7.6 |  |  | 117 |  |  | 777 |  |  | 8.1 |  |  | 573 |  |  | 8.6 |  |  | 36 |  |
| Net income (loss) | 235 |  |  | 4.8 |  |  | 251 |  |  | 7.6 |  |  | (6 | ) |  | (131 | ) |  | (1.4 | ) |  | 534 |  |  | 8.0 |  |  | (125 | ) |

[0000106040-17-000007:mdna:19]
The following table sets forth, for the periods presented, summary information regarding unit shipments, average selling prices (“ASPs”) and net revenues by geography and end market:

[0000106040-17-000007:mdna:20]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions, except exabytes, percentages and ASPs) |
| Revenue, net | $ | 4,888 |  |  | $ | 3,317 |  |  | $ | 9,602 |  |  | $ | 6,677 |  |
| HDD ASPs (per unit) | $ | 62 |  |  | $ | 61 |  |  | $ | 61 |  |  | $ | 61 |  |
| Revenues by Geography (%) |  |  |  |  |  |  |  |
| Americas | 39 | % |  | 31 | % |  | 39 | % |  | 31 | % |
| Europe, Middle East and Africa | 17 |  |  | 23 |  |  | 17 |  |  | 22 |  |
| Asia | 44 |  |  | 46 |  |  | 44 |  |  | 47 |  |
| Revenues by End Market (%) |  |  |  |  |  |  |  |
| Client Devices | 49 | % |  | 48 | % |  | 50 | % |  | 49 | % |
| Client Solutions | 22 |  |  | 14 |  |  | 21 |  |  | 13 |  |
| Data Center Devices & Solutions | 29 |  |  | 38 |  |  | 29 |  |  | 38 |  |
| HDD Unit Shipments | 44 |  |  | 49 |  |  | 92 |  |  | 101 |  |
| Exabytes Shipped | 78 |  |  | 69 |  |  | 158 |  |  | 133 |  |

[0000106040-17-000007:mdna:21]
49

[0000106040-17-000007:mdna:22]
[same as prior period, unchanged from 0000106040-16-000040:mdna:29]

[0000106040-17-000007:mdna:23]
Net revenue for the three months ended December 30, 2016 increased $1.6 billion, or 47%, compared to the same period in 2016, which reflects an increase from NAND-flash products from our acquisition of SanDisk, partially offset by lower HDD unit shipments. Total HDD shipments for the three months ended December 30, 2016 decreased to 44 million units, as compared to 49 million units in the same period in 2016, primarily due to lower HDD shipments for personal computer (“PC”) and performance enterprise. This was partially offset by an increase in HDD ASP per unit of $1 compared to the same period in 2016, primarily due to a change in product mix.

[0000106040-17-000007:mdna:24]
Net revenue for the six months ended December 30, 2016 increased $2.9 billion, or 44%, compared to the same period in 2016, which reflects an increase from NAND-flash products from our acquisition of SanDisk, partially offset by lower HDD unit shipments. Total HDD shipments for the six months ended December 30, 2016 decreased to 92 million units, as compared to 101 million units in the same period in 2016, primarily due to lower HDD shipments.

[0000106040-17-000007:mdna:25]
For the three and six months ended December 30, 2016 and January 1, 2016, no customer accounted for 10% or more of our net revenue. For the three and six months ended December 30, 2016, our top 10 customers accounted for 43% and 42%, respectively. For each of the three and six months ended January 1, 2016, our top 10 customers accounted for 44% of our net revenue.

[0000106040-17-000007:mdna:26]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For each of the three and six months ended December 30, 2016, these programs represented 8% of gross revenues. For the three and six months ended January 1, 2016, these programs represented 13% and 12% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-17-000007:mdna:27]
[same as prior period, unchanged from 0000106040-16-000040:mdna:33]

[0000106040-17-000007:mdna:28]
Changes in the mix of net revenue by geography for the three and six months ended December 30, 2016, compared to the same period in 2016, reflect the additional revenues from our acquisition of SanDisk which has comparatively higher revenue in the Americas than our pre-acquisition business.

[0000106040-17-000007:mdna:29]
Net Revenue by End Market

[0000106040-17-000007:mdna:30]
Changes in the mix of net revenue by end market for the three and six months ended December 30, 2016, compared to the same period in 2016, also reflect the increase in revenues from our acquisition of SanDisk which has comparatively higher revenue in Client Devices and Data Center Devices and Solutions than our pre-acquisition business.

[0000106040-17-000007:mdna:31]
[same as prior period, unchanged from 0000106040-16-000040:mdna:37]

[0000106040-17-000007:mdna:32]
Gross profit for the three months ended December 30, 2016 was $1.5 billion, an increase of $627 million compared to the same period in 2016, driven by gross profit from NAND-flash products from our acquisition of SanDisk. Gross profit as a percentage of net revenue was 31.4% in the three months ended December 30, 2016, as compared to 27.3% in the same period in 2016. The increase in gross profit was due primarily to higher margins on NAND-flash memory products, increased HDD ASPs and cost improvements resulting from integration activities. Gross profit in the three months ended December 30, 2016 was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and acquisition related charges, which aggregated $259 million, or 5.3% of revenue. Gross profit in the three months ended January 1, 2016 was negatively impacted by charges related to the implementation of cost-saving initiatives, amortization expense on acquired intangible assets and stock-based compensation, which aggregated $39 million, or 1.2% of revenue.

[0000106040-17-000007:mdna:33]
50

[0000106040-17-000007:mdna:34]
Gross profit for the six months ended December 30, 2016 was $2.9 billion, an increase of $1.0 billion compared to the same period in 2016, driven by the increased revenues from NAND-flash products from our acquisition of SanDisk. Gross profit as a percentage of net revenue was 29.9% in the six months ended December 30, 2016, as compared to 27.9% in the same period in 2016. The increase in gross profit was due primarily to higher margins on NAND-flash memory products and cost improvements resulting from integration activities. Gross profit in the six months ended December 30, 2016 was negatively impacted by amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, stock-based compensation and acquisition related charges, which aggregated $523 million, or 5.4% of revenue. Gross profit in the six months ended January 1, 2016 was negatively impacted by amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives and stock-based compensation, which aggregated was $61 million, or 0.9% of revenue.

[0000106040-17-000007:mdna:35]
[same as prior period, unchanged from 0000106040-16-000040:mdna:39]

[0000106040-17-000007:mdna:36]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  |  |  | December 30, 2016 |  | January 1, 2016 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Research and development | $ | 585 |  |  | 12.0 | % |  | $ | 389 |  |  | 11.7 | % |  | 50 | % |  | $ | 1,224 |  |  | 12.7 | % |  | $ | 774 |  |  | 11.6 | % |  | 58 | % |
| Selling, general and administrative | 358 |  |  | 7.3 |  |  | 239 |  |  | 7.2 |  |  | 50 |  |  | 754 |  |  | 7.9 |  |  | 431 |  |  | 6.5 |  |  | 75 |  |
| Employee termination, asset impairment and other charges | 45 |  |  | 0.9 |  |  | 27 |  |  | 0.8 |  |  | 67 |  |  | 113 |  |  | 1.2 |  |  | 83 |  |  | 1.2 |  |  | 36 |  |
| Total operating expenses | $ | 988 |  |  | 20.2 |  |  | $ | 655 |  |  | 19.7 |  |  | 51 |  |  | $ | 2,091 |  |  | 21.8 |  |  | $ | 1,288 |  |  | 19.3 |  |  | 62 |  |

[0000106040-17-000007:mdna:37]
The increase in research and development (“R&D”) expense in the three and six months ended December 30, 2016, compared to the same period in 2016, was primarily related to our acquisition of SanDisk and continued development of NAND technology to complement our existing product offerings. The three and six months ended December 30, 2016 also included aggregate charges of $49 million and $102 million, respectively, related to share-based compensation expenses, charges related to the implementation of cost-saving initiatives and acquisition-related charges. These costs were partially offset by cost savings from our integration activities. The three and six months ended January 1, 2016 also included aggregate charges of $20 million and $36 million, respectively, related to share-based compensation expenses, charges related to the implementation of cost-saving initiatives and other charges.

[0000106040-17-000007:mdna:38]
The increase in selling, general and administrative (“SG&A”) expense in the three and six months ended December 30, 2016, compared to the same period in 2016, was primarily related to our acquisition of SanDisk. The three and six months ended December 30, 2016 also included aggregate charges of $97 million and $216 million, respectively, related to share-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives and acquisition-related charges. The three and six months ended January 1, 2016 also included aggregate charges of $90 million and $120 million, respectively, related to share-based compensation expenses, acquisition-related charges, charges related to an arbitration award, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives and other charges.

[0000106040-17-000007:mdna:39]
Employee termination and other charges were $45 million and $113 million in the three and six months ended December 30, 2016, respectively, an increase of $18 million and $30 million from the three and six months ended January 1, 2016, respectively. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 13 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:40]
51

[0000106040-17-000007:mdna:41]
[same as prior period, unchanged from 0000106040-16-000040:mdna:44]

[0000106040-17-000007:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  |  |  | December 30, 2016 |  | January 1, 2016 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Interest income | $ | 5 |  |  | 0.1 | % |  | $ | 5 |  |  | 0.2 | % |  | 100 | % |  | $ | 10 |  |  | 0.1 | % |  | $ | 9 |  |  | 0.1 | % |  | 11 | % |
| Interest expense | (205 | ) |  | (4.2 | ) |  | (13 | ) |  | (0.4 | ) |  | ** |  | (441 | ) |  | (4.6 | ) |  | (26 | ) |  | (0.4 | ) |  | ** |
| Other income (expense), net | (24 | ) |  | (0.5 | ) |  | 1 |  |  | — |  |  | ** |  | (296 | ) |  | (3.1 | ) |  | 2 |  |  | — |  |  | ** |
| Total interest and other expense, net | $ | (224 | ) |  | (4.6 | ) |  | $ | (7 | ) |  | (0.2 | ) |  | ** |  | $ | (727 | ) |  | (7.6 | ) |  | $ | (15 | ) |  | (0.2 | ) |  | ** |

[0000106040-17-000007:mdna:43]
[same as prior period, unchanged from 0000106040-16-000040:mdna:46]

[0000106040-17-000007:mdna:44]
Interest expense increased for the three and six months ended December 30, 2016, compared to the same period in 2016, primarily due to the additional debt issued in connection with the acquisition of SanDisk.

[0000106040-17-000007:mdna:45]
Other income (expense), net for the three months ended December 30, 2016 was primarily comprised of foreign exchange losses. Other income (expense), net for the six months ended December 30, 2016 was primarily comprised of the write-off of debt issuance costs on the settlement of the original U.S. Term Loan B and Euro Term Loan B, loss on the settlement of our convertible debt instruments, and foreign exchange losses.

[0000106040-17-000007:mdna:46]
Income Tax Expense (Benefit)

[0000106040-17-000007:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  |  |  | December 30, 2016 |  | January 1, 2016 |  |  |
|  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |  | Amount |  | % of Rev |  | Amount |  | % of Rev |  | % Change |
|  | (in millions, except percentages) |
| Income tax expense (benefit) | $ | 86 |  |  | 1.8 | % |  | $ | (7 | ) |  | (0.2 | )% |  | ** |  | $ | 181 |  |  | 1.9 | % |  | $ | 24 |  |  | 0.4 | % |  | ** |
| Effective tax rate | 27 | % |  |  |  | (3 | )% |  |  |  |  |  | 362 | % |  |  |  | 4 | % |  |  |  |  |

[0000106040-17-000007:mdna:48]
| ** | Amount not meaningful. |

[0000106040-17-000007:mdna:49]
Income tax expense of $181 million for the six months ended December 30, 2016 is attributable primarily to discrete effects consisting of income tax expense from the integration of SanDisk of $90 million and a valuation allowance on acquired tax attributes of $109 million. Income tax expense related to the SanDisk integration is partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt refinancing of $96 million. These discrete items are the primary drivers of the effective tax rate for the six months ended December 30, 2016.

[0000106040-17-000007:mdna:50]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 30, 2016 and the U.S. Federal statutory rate of 35% are the current year generation of tax credits, tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029, for both periods, and the discrete items described above for the six months ended December 30, 2016. For the three and six months ended January 1, 2016, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029.

[0000106040-17-000007:mdna:51]
For additional information regarding income tax expense (benefit), see Part I, Item 1, Note 10 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:52]
[same as prior period, unchanged from 0000106040-16-000040:mdna:57]

[0000106040-17-000007:mdna:53]
The following table summarizes our statements of cash flows for the six months ended December 30, 2016 and January 1, 2016:

[0000106040-17-000007:mdna:54]
|  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 1,500 |  |  | $ | 1,143 |  |
| Investing activities | (316 | ) |  | (454 | ) |
| Financing activities | (4,386 | ) |  | (350 | ) |
| Effect of exchange rate changes on cash | (9 | ) |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | (3,211 | ) |  | $ | 339 |  |

[0000106040-17-000007:mdna:55]
[same as prior period, unchanged from 0000106040-16-000040:mdna:60]

[0000106040-17-000007:mdna:56]
[same as prior period, unchanged from 0000106040-16-000040:mdna:61]

[0000106040-17-000007:mdna:57]
During 2017, we expect cash used for purchases of property, plant and equipment, and net activity in notes receivable and equity investments relating to our business ventures with Toshiba Corporation (“Flash Ventures”) to be approximately $0.7 billion to $1.1 billion of our cash. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-17-000007:mdna:58]
A total of $3.9 billion and $6.9 billion of our cash and cash equivalents was held outside of the U.S. as of December 30, 2016 and July 1, 2016, respectively. Our current plans anticipate we can meet our U.S. cash needs while continuing to permanently reinvest the undistributed earnings of our foreign subsidiaries. In the event the reinvested earnings of our foreign subsidiaries are distributed to the U.S., such a distribution could result in the accrual and payment of additional taxes.

[0000106040-17-000007:mdna:59]
[same as prior period, unchanged from 0000106040-16-000040:mdna:64]

[0000106040-17-000007:mdna:60]
Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by changes in working capital was $37 million for the six months ended December 30, 2016, as compared to $1 million for the six months ended January 1, 2016.

[0000106040-17-000007:mdna:61]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles for the six months ended December 30, 2016 and January 1, 2016 were as follows:

[0000106040-17-000007:mdna:62]
|  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |
|  | (in days) |
| Days sales outstanding | 38 |  |  | 47 |  |
| Days in inventory | 56 |  |  | 48 |  |
| Days payables outstanding | (59 | ) |  | (71 | ) |
| Cash conversion cycle | 35 |  |  | 24 |  |

[0000106040-17-000007:mdna:63]
For the six months ended December 30, 2016, our days sales outstanding (“DSOs”) decreased by 9 days, days in inventory (“DIOs”) increased by 8 days and days payables outstanding (“DPOs”) decreased by 12 days, as compared to the prior year. Changes in DSOs are generally due to the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-17-000007:mdna:64]
[same as prior period, unchanged from 0000106040-16-000040:mdna:70]

[0000106040-17-000007:mdna:65]
Net cash used in investing activities in the six months ended December 30, 2016 was $316 million, as compared to $454 million net cash used in investing activities in the six months ended January 1, 2016. During the six months ended December 30, 2016, net cash used in investing activities primarily consisted of $330 million of capital expenditures and a net $70 million increase in notes receivable to and investments in Flash Ventures, partially offset by a net $95 million decrease in our investments in marketable securities. During the six months ended January 1, 2016, net cash used in investing activities primarily consisted of $300 million of capital expenditures and a net $142 million increase in investments in marketable securities.

[0000106040-17-000007:mdna:66]
[same as prior period, unchanged from 0000106040-16-000040:mdna:72]

[0000106040-17-000007:mdna:67]
[same as prior period, unchanged from 0000106040-16-000040:mdna:73]

[0000106040-17-000007:mdna:68]
Net cash used in financing activities was $4.4 billion in the six months ended December 30, 2016, as compared to net cash used in financing activities of $350 million in the six months ended January 1, 2016. During the six months ended December 30, 2016, net cash used in financing activities consisted of $8.3 billion to repay debt and $284 million to pay dividends on our common stock, partially offset by $4.0 billion of proceeds from debt, net of issuance costs, $61 million of proceeds from call options and a net $106 million provided by employee stock plans. During the six months ended January 1, 2016, net cash used in financing activities primarily consisted of $231 million to pay dividends on our common stock, $60 million to repurchase shares of our common stock and $63 million to repay debt.

[0000106040-17-000007:mdna:69]
[same as prior period, unchanged from 0000106040-16-000040:mdna:75]

[0000106040-17-000007:mdna:70]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the condensed consolidated financial statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 8 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:71]
54

[0000106040-17-000007:mdna:72]
[same as prior period, unchanged from 0000106040-16-000040:mdna:77]

[0000106040-17-000007:mdna:73]
[same as prior period, unchanged from 0000106040-16-000040:mdna:78]

[0000106040-17-000007:mdna:74]
The following is a summary of our known contractual cash obligations and commercial commitments as of December 30, 2016:

[0000106040-17-000007:mdna:75]
|  | Total |  | 1 Year (Remaining 6 months of 2017) |  | 2-3 Years (2018-2019) |  | 4-5 Years (2020-2021) |  | More than 5 Years (Beyond 2021) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 13,299 |  |  | $ | 20 |  |  | $ | 595 |  |  | $ | 3,724 |  |  | $ | 8,960 |  |
| Interest on debt | 5,288 |  |  | 393 |  |  | 1,646 |  |  | 1,646 |  |  | 1,603 |  |
| Flash Ventures and other related commitments(1) | 6,336 |  |  | 769 |  |  | 3,412 |  |  | 1,479 |  |  | 676 |  |
| Operating leases | 181 |  |  | 33 |  |  | 78 |  |  | 47 |  |  | 23 |  |
| Purchase obligations | 700 |  |  | 693 |  |  | 7 |  |  | — |  |  | — |  |
| Total | $ | 25,804 |  |  | $ | 1,908 |  |  | $ | 5,738 |  |  | $ | 6,896 |  |  | $ | 11,262 |  |

[0000106040-17-000007:mdna:76]
[same as prior period, unchanged from 0000106040-16-000040:mdna:81]

[0000106040-17-000007:mdna:77]
Debt

[0000106040-17-000007:mdna:78]
The Credit Agreement (as defined in Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q) requires us to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of our outstanding debt, including the Credit Agreement, require us to comply with customary covenants that limit or restrict us and our subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.  As of December 30, 2016, we were in compliance with these covenants.

[0000106040-17-000007:mdna:79]
See Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our indebtedness.

[0000106040-17-000007:mdna:80]
[same as prior period, unchanged from 0000106040-16-000040:mdna:101]

[0000106040-17-000007:mdna:81]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of December 30, 2016, we were in compliance with all covenants under these Japanese lease facilities.

[0000106040-17-000007:mdna:82]
See Part I, Item 1, Note 8 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-17-000007:mdna:83]
[same as prior period, unchanged from 0000106040-16-000040:mdna:105]

[0000106040-17-000007:mdna:84]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 3, under the heading “Disclosure About Foreign Currency Risk,” and Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:85]
[same as prior period, unchanged from 0000106040-16-000040:mdna:107]

[0000106040-17-000007:mdna:86]
[same as prior period, unchanged from 0000106040-16-000040:mdna:108]

[0000106040-17-000007:mdna:87]
[same as prior period, unchanged from 0000106040-16-000040:mdna:109]

[0000106040-17-000007:mdna:88]
[same as prior period, unchanged from 0000106040-16-000040:mdna:110]

[0000106040-17-000007:mdna:89]
As of December 30, 2016, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $561 million, of which $445 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 10 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-17-000007:mdna:90]
[same as prior period, unchanged from 0000106040-16-000040:mdna:112]

[0000106040-17-000007:mdna:91]
Since the first quarter of 2014, we have issued a quarterly cash dividend. On November 3, 2016, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of December 30, 2016. The cash dividend of $144 million was paid on January 17, 2017. On February 1, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of March 31, 2017.  The cash dividend will be paid on April 17, 2017. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-17-000007:mdna:92]
[same as prior period, unchanged from 0000106040-16-000040:mdna:114]

[0000106040-17-000007:mdna:93]
[same as prior period, unchanged from 0000106040-16-000040:mdna:115]

[0000106040-17-000007:mdna:94]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for our fiscal year ended July 1, 2016. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 1, 2016 for a discussion of our critical accounting policies and estimates.

[0000106040-17-000007:mdna:95]
56

[0000106040-17-000007:mdna:96]
[same as prior period, unchanged from 0000106040-16-000040:mdna:117]

[0000106040-17-000007:mdna:97]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). The new standard removes the prohibition in the FASB Accounting Standards Codification (“ASC”) Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The ASU is intended to reduce the complexity of U.S. GAAP and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact ASU 2016-16 will have on our consolidated financial statements.

[0000106040-17-000007:mdna:98]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). The new standard addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which, among others, includes our disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2018. The adoption of this standard is not expected to have a material impact on our consolidated financial statements.

[0000106040-17-000007:mdna:99]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within those years, which for us is the first quarter of 2018. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2018. We are currently evaluating the impact ASU 2016-09 will have on our consolidated financial statements and related disclosures.

[0000106040-17-000007:mdna:100]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for us is the first quarter of 2020. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2020. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements and related disclosures.

[0000106040-17-000007:mdna:101]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”), which provides guidance related to accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. We are currently evaluating the impact ASU 2016-01 will have on our consolidated financial statements.

[0000106040-17-000007:mdna:102]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)”, which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued and amended, the standard is effective for public business entities applying U.S. GAAP, for annual periods commencing or after December 16, 2017 (with early adoption permitted for annual periods beginning on or after December 16, 2016). We intend to apply the new standard starting from the first quarter of fiscal 2019. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our preliminary plan, we intend to adopt the new standard using the modified retrospective method. However, we continue to assess this in connection with our entire project plan.

[0000106040-17-000007:mdna:103]
We expect the implementation of the new standard to impact the recognition of our revenue as follows:

[0000106040-17-000007:mdna:104]
| • | Substantially all of our current revenue is from the sale of hardware products. We do not expect any material changes to the timing or amount of revenue for these types of sales under the new standard. |

[0000106040-17-000007:mdna:105]
| • | For sales-based royalties, we will need to estimate and recognize revenue in the period the royalty-bearing sales occur as opposed to the existing treatment of recognizing revenue in the period the royalty report is received. This change will result in the acceleration of revenue recognition by one fiscal quarter as well as fluctuations between the estimated and actual reported sales-based royalties. |

[0000106040-17-000007:mdna:106]
| • | For software and intellectual property licenses, we are still assessing the impact and timing to revenue from the implementation of the new standard. However, we do not currently expect the new standard to have a material impact on our revenue for these types of arrangements. |

[0000106040-17-000007:mdna:107]
| • | Our revenue disclosures are expected to expand. |

[0000106040-17-000007:mdna:108]
We are still assessing the impact to our processes and systems configuration from the implementation of the new revenue standard and do not currently expect any significant changes to our other accounting policies from the adoption of the new revenue standard. Our implementation efforts are progressing as planned.

[0000106040-17-000007:mdna:109]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part I, Item 1, Note 2 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, which is incorporated by reference in response to this item.

[0000106040-17-000007:mdna:110]
58
