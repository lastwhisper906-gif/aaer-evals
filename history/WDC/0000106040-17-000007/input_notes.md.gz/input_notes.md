# WDC notes — 0000106040-17-000007


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-17-000007:notes:1]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of December 30, 2016, by remaining contractual maturity, were as follows:

[0000106040-17-000007:notes:2]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 161 |  |  | $ | 161 |  |
| Due in one to five years (included in other non-current assets) | 88 |  |  | 87 |  |
| Total | $ | 249 |  |  | $ | 248 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000106040-17-000007:notes:3]
[same as prior period, unchanged from 0000106040-16-000040:notes:4]

[0000106040-17-000007:notes:4]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 1, 2016 |
|  | (in millions, except per share amounts) |
| Revenue, net | $ | 4,860 |  |  | $ | 9,672 |  |
| Net income | 190 |  |  | 288 |  |
| Basic income per common share | $ | 0.68 |  |  | $ | 1.03 |  |
| Diluted income per common share | $ | 0.67 |  |  | $ | 1.01 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-17-000007:notes:5]
[same as prior period, unchanged from 0000106040-16-000040:notes:6]

[0000106040-17-000007:notes:6]
[same as prior period, unchanged from 0000106040-16-000040:notes:7]

[0000106040-17-000007:notes:7]
In May 2016, the Company acquired SanDisk, a global leader in NAND flash storage solutions primarily to deepen the Company’s expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-17-000007:notes:8]
[same as prior period, unchanged from 0000106040-16-000040:notes:9]

[0000106040-17-000007:notes:9]
During the six months ended December 30, 2016, the Company increased goodwill by $60 million due to an adjustment to the assessment of fair value for certain acquired intangible assets, inventory and property and equipment and a portion of the deferred tax liability. Management is continuing to assess the values assigned to the remaining assets acquired and liabilities assumed and may make further adjustments during the measurement period (through May 11, 2017) as further information becomes available. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in adjustments to goodwill.

[0000106040-17-000007:notes:10]
[same as prior period, unchanged from 0000106040-16-000040:notes:11]

[0000106040-17-000007:notes:11]
The financial information in the table below summarizes the combined results of operations for the Company and SanDisk, on a pro forma basis, as though the combination had occurred as of the beginning of 2016. The pro forma financial information for the periods presented includes the effects of adjustments related to amortization charges from acquired intangible assets, depreciation charges from acquired fixed assets, interest expenses from financing the acquisition, stock-based compensation expenses from the conversion of unvested equity awards and the elimination of certain expenses directly related to the transaction. The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of 2016.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-17-000007:notes:12]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan were as follows:

[0000106040-17-000007:notes:13]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Benefit obligations | $ | 281 |  |  | $ | 326 |  |
| Fair value of plan assets | 190 |  |  | 212 |  |
| Unfunded status | $ | 91 |  |  | $ | 114 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-17-000007:notes:14]
Commitments, Contingencies and Related Parties

[0000106040-17-000007:notes:15]
Flash Ventures

[0000106040-17-000007:notes:16]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, referred to as “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

[0000106040-17-000007:notes:17]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-17-000007:notes:18]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 30, 2016 and July 1, 2016:

[0000106040-17-000007:notes:19]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 138 |  |  | 235 |  |
| Notes receivable, Flash Forward | 248 |  |  | 263 |  |
| Investment in Flash Partners | 178 |  |  | 202 |  |
| Investment in Flash Alliance | 267 |  |  | 306 |  |
| Investment in Flash Forward | 106 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,082 |  |  | $ | 1,171 |  |

[0000106040-17-000007:notes:20]
During the three and six months ended December 30, 2016, the Company made net payments to Flash Ventures of $766 million and $1.5 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.

[0000106040-17-000007:notes:21]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-17-000007:notes:22]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-17-000007:notes:23]
As of December 30, 2016 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $175 million and $168 million, respectively.

[0000106040-17-000007:notes:24]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 30, 2016, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-17-000007:notes:25]
|  | December 30, 2016 |
|  | (in millions) |
| Notes receivable | $ | 531 |  |
| Equity investments | 551 |  |
| Operating lease guarantees | 1,102 |  |
| Prepayments | 26 |  |
| Maximum estimable loss exposure | $ | 2,210 |  |

[0000106040-17-000007:notes:26]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-17-000007:notes:27]
Off-Balance Sheet Liabilities

[0000106040-17-000007:notes:28]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-17-000007:notes:29]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016.

[0000106040-17-000007:notes:30]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 129 |  |  | $ | 1,102 |  |

[0000106040-17-000007:notes:31]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 30, 2016 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of December 30, 2016:

[0000106040-17-000007:notes:32]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 269 |  |  | $ | 47 |  |  | $ | 316 |  |
| Year 2 |  | 230 |  |  | — |  |  | 230 |  |
| Year 3 |  | 184 |  |  | 71 |  |  | 255 |  |
| Year 4 |  | 108 |  |  | 58 |  |  | 166 |  |
| Year 5 |  | 33 |  |  | 102 |  |  | 135 |  |
| Total guarantee obligations |  | $ | 824 |  |  | $ | 278 |  |  | $ | 1,102 |  |

[0000106040-17-000007:notes:33]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 30, 2016, no amounts have been accrued in the consolidated financial statements with respect to these indemnification guarantees.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-17-000007:notes:34]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 235 |  |  | $ | 184 |  |  | $ | 23 |  |  | $ | (207 | ) |  | $ | 235 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | (186 | ) |  | (186 | ) |  | (210 | ) |  | 396 |  |  | (186 | ) |
| Net unrealized loss on foreign exchange contracts | (136 | ) |  | (136 | ) |  | (132 | ) |  | 268 |  |  | (136 | ) |
| Total other comprehensive loss, before tax | (321 | ) |  | (321 | ) |  | (341 | ) |  | 662 |  |  | (321 | ) |
| Income tax benefit related to items of other comprehensive loss | 9 |  |  | 10 |  |  | 9 |  |  | (19 | ) |  | 9 |  |
| Other comprehensive loss, net of tax | (312 | ) |  | (311 | ) |  | (332 | ) |  | 643 |  |  | (312 | ) |
| Total comprehensive loss | $ | (77 | ) |  | $ | (127 | ) |  | $ | (309 | ) |  | $ | 436 |  |  | $ | (77 | ) |

[0000106040-17-000007:notes:35]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (131 | ) |  | $ | 169 |  |  | $ | (204 | ) |  | $ | 35 |  |  | $ | (131 | ) |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 6 |  |  | 6 |  |  | 6 |  |  | (12 | ) |  | 6 |  |
| Foreign currency translation adjustment | (169 | ) |  | (169 | ) |  | (192 | ) |  | 361 |  |  | (169 | ) |
| Net unrealized loss on foreign exchange contracts | (140 | ) |  | (140 | ) |  | (136 | ) |  | 276 |  |  | (140 | ) |
| Total other comprehensive loss, before tax | (303 | ) |  | (303 | ) |  | (322 | ) |  | 625 |  |  | (303 | ) |
| Income tax benefit related to items of other comprehensive loss | 3 |  |  | 3 |  |  | 1 |  |  | (4 | ) |  | 3 |  |
| Other comprehensive loss, net of tax | (300 | ) |  | (300 | ) |  | (321 | ) |  | 621 |  |  | (300 | ) |
| Total comprehensive loss | $ | (431 | ) |  | $ | (131 | ) |  | $ | (525 | ) |  | $ | 656 |  |  | $ | (431 | ) |

[0000106040-17-000007:notes:36]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended January 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 251 |  |  | $ | 258 |  |  | $ | 219 |  |  | $ | (477 | ) |  | $ | 251 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Net unrealized gain on foreign exchange contracts | 38 |  |  | 38 |  |  | 29 |  |  | (67 | ) |  | 38 |  |
| Net unrealized loss on available-for-sale securities | (2 | ) |  | (3 | ) |  | (3 | ) |  | 6 |  |  | (2 | ) |
| Total other comprehensive income, before tax | 36 |  |  | 35 |  |  | 26 |  |  | (61 | ) |  | 36 |  |
| Income tax benefit related to items of other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income, net of tax | 36 |  |  | 35 |  |  | 26 |  |  | (61 | ) |  | 36 |  |
| Total comprehensive income | $ | 287 |  |  | $ | 293 |  |  | $ | 245 |  |  | $ | (538 | ) |  | $ | 287 |  |

[0000106040-17-000007:notes:37]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended January 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 534 |  |  | $ | 548 |  |  | $ | 562 |  |  | $ | (1,110 | ) |  | $ | 534 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Net unrealized gain on foreign exchange contracts | 13 |  |  | 13 |  |  | 12 |  |  | (25 | ) |  | 13 |  |
| Net unrealized loss on available-for-sale securities | (1 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (1 | ) |
| Total other comprehensive income, before tax | 12 |  |  | 11 |  |  | 10 |  |  | (21 | ) |  | 12 |  |
| Income tax benefit related to items of other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income, net of tax | 12 |  |  | 11 |  |  | 10 |  |  | (21 | ) |  | 12 |  |
| Total comprehensive income | $ | 546 |  |  | $ | 559 |  |  | $ | 572 |  |  | $ | (1,131 | ) |  | $ | 546 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-17-000007:notes:38]
Debt

[0000106040-17-000007:notes:39]
Debt consisted of the following as of December 30, 2016 and July 1, 2016:

[0000106040-17-000007:notes:40]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-1 maturing 2023 | 2,985 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-1 maturing 2023(1) | 929 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,299 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (226 | ) |  | (532 | ) |
| Subtotal | 13,073 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (129 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,944 |  |  | $ | 13,660 |  |

[0000106040-17-000007:notes:41]
| (1) | Euro Term Loan B and Euro Term Loan B-1 outstanding principal amounts as of December 30, 2016 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

[0000106040-17-000007:notes:42]
Credit Agreement – Term Loans and Revolving Credit Facility

[0000106040-17-000007:notes:43]
On April 29, 2016, the Company entered into a credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. The revolving credit facility includes a $200 million sublimit for letters of credit.

[0000106040-17-000007:notes:44]
In the first quarter ended September 30, 2016, the Company settled in full the principal amounts of the $3.75 billion U.S. Term Loan B and the €885 million Euro Term Loan B, plus accrued interest. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

[0000106040-17-000007:notes:45]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. The U.S. Term Loan B-1 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 3.75% or a base rate plus 2.75% (4.52% as of December 30, 2016). Principal payments on U.S. Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The U.S. Term Loan B-1 issuance costs of $6 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $5 million remain unamortized.

[0000106040-17-000007:notes:46]
On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. The Euro Term Loan B-1 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 3.25% (4.00% as of December 30, 2016). Principal payments on Euro Term Loan B-1 of 0.25% are due quarterly and began on September 30, 2016 with the balance due on April 29, 2023. The Euro Term Loan B-1 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of December 30, 2016, issuance costs of $2 million remain unamortized.

[0000106040-17-000007:notes:47]
As of December 30, 2016, the revolving credit facility was not drawn upon, and there was no outstanding balance.

[0000106040-17-000007:notes:48]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of December 30, 2016, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.775%.

[0000106040-17-000007:notes:49]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-17-000007:notes:50]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-1 and the Euro Term Loan B-1 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before February 17, 2017, with respect to U.S. Term Loan B-1, and March 22, 2017, with respect to Euro Term Loan B-1.

[0000106040-17-000007:notes:51]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

[0000106040-17-000007:notes:52]
Additional Bridge Facility

[0000106040-17-000007:notes:53]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.0 billion aggregate principal amount outstanding, together with accrued interest.

[0000106040-17-000007:notes:54]
Senior Notes

[0000106040-17-000007:notes:55]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. On February 6, 2017, substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.

[0000106040-17-000007:notes:56]
The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

[0000106040-17-000007:notes:57]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

[0000106040-17-000007:notes:58]
Convertible Notes, Exchange Options and Call Options

[0000106040-17-000007:notes:59]
As of July 1, 2016, the Company had outstanding, through the acquisition of SanDisk, $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

[0000106040-17-000007:notes:60]
During the three months ended December 30, 2016, the Company repurchased Convertible Notes for $3 million of cash. During the six months ended December 30, 2016, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $493 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

[0000106040-17-000007:notes:61]
As of December 30, 2016, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

[0000106040-17-000007:notes:62]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and six months ended December 30, 2016, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial gain.

[0000106040-17-000007:notes:63]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the six months ended December 30, 2016, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and six months ended December 30, 2016, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of December 30, 2016 was immaterial.

[0000106040-17-000007:notes:64]
The exchange and repurchase of the Convertible Notes and related settlement of the call options during the three and six months ended December 30, 2016 resulted in an immaterial net loss.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-17-000007:notes:65]
[same as prior period, unchanged from 0000106040-16-000040:notes:65]

[0000106040-17-000007:notes:66]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange forward contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange forward contracts are for risk management purposes only. The Company does not purchase foreign exchange forward contracts for speculative or trading purposes. As of December 30, 2016, the Company had outstanding foreign exchange forward contracts with commercial banks for British pound sterling, Euro, Japanese yen, Malaysian ringgit, Philippine peso, Singapore dollar and Thai baht, which were designated as either cash flow or fair value hedges.

[0000106040-17-000007:notes:67]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in AOCI, net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange forward contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and six months ended December 30, 2016 and January 1, 2016.

[0000106040-17-000007:notes:68]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges were determined to be effective as of December 30, 2016 and July 1, 2016. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and six months ended December 30, 2016 and January 1, 2016.

[0000106040-17-000007:notes:69]
As of December 30, 2016, the net amount of unrealized gains with respect to the Company’s foreign exchange forward contracts that is expected to be reclassified into earnings within the next 12 months was $65 million. In addition, as of December 30, 2016, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-17-000007:notes:70]
See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair value of the Company’s foreign exchange forward contracts.

[0000106040-17-000007:notes:71]
[same as prior period, unchanged from 0000106040-16-000040:notes:71]

[0000106040-17-000007:notes:72]
[same as prior period, unchanged from 0000106040-16-000040:notes:72]

[0000106040-17-000007:notes:73]
|  | Derivative Assets Reported in |
|  | Other Current Assets |  | Other Non-current Assets |
|  | December 30, 2016 |  | July 1, 2016 |  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 2 |  |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 2 |  |  | 12 |  |  | — |  |  | — |  |
| Call options | — |  |  | 70 |  |  | — |  |  | 1 |  |
| Total derivatives | $ | 4 |  |  | $ | 196 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-17-000007:notes:74]
|  | Derivative Liabilities Reported in |
|  | Accrued Expenses |  | Other Liabilities |
|  | December 30, 2016 |  | July 1, 2016 |  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Foreign exchange forward contracts designated | $ | 167 |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange forward contracts not designated | 11 |  |  | — |  |  | — |  |  | — |  |
| Exchange option | 1 |  |  | 141 |  |  | — |  |  | 14 |  |
| Total derivatives | $ | 179 |  |  | $ | 164 |  |  | $ | — |  |  | $ | 14 |  |

[0000106040-17-000007:notes:75]
[same as prior period, unchanged from 0000106040-16-000040:notes:75]

[0000106040-17-000007:notes:76]
The following table presents the gross amounts of the Company’s derivative instruments, amounts offset due to master netting arrangements with the Company’s various counterparties and the net amounts recognized in the condensed consolidated balance sheet as of December 30, 2016:

[0000106040-17-000007:notes:77]
| Derivatives Designated as Hedging Instruments |  | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Gross Amounts Not Offset in the Balance Sheet |  | Net Amount |
|  |  |  |  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  |  | (in millions) |
| Foreign exchange forward contracts: |  |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Financial liabilities |  | (167 | ) |  | — |  |  | (167 | ) |  | — |  |  | — |  |  | (167 | ) |
| Total derivative instruments |  | $ | (165 | ) |  | $ | — |  |  | $ | (165 | ) |  | $ | — |  |  | $ | — |  |  | $ | (165 | ) |

[0000106040-17-000007:notes:78]
The Company had a gross and net asset of $118 million and $114 million, respectively, and a gross and net liability of $27 million and $23 million, respectively, related to its derivative instruments outstanding as of July 1, 2016.

[0000106040-17-000007:notes:79]
Effect of Foreign Exchange Forward Contracts on the Condensed Consolidated Statements of Operations

[0000106040-17-000007:notes:80]
The impact of foreign exchange forward contracts on the consolidated financial statements was as follows:

[0000106040-17-000007:notes:81]
|  |  | Three Months Ended |
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in AOCI on Derivatives |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  |  | (in millions) |
| Foreign exchange forward contracts |  | $ | (119 | ) |  | $ | 13 |  |  | $ | 16 |  |  | $ | (25 | ) |

[0000106040-17-000007:notes:82]
|  |  | Six Months Ended |
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain (Loss) Recognized in AOCI on Derivatives |  | Amount of Gain (Loss) Reclassified from AOCI into Earnings |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  |  | (in millions) |
| Foreign exchange forward contracts |  | $ | (97 | ) |  | $ | (40 | ) |  | $ | 42 |  |  | $ | (53 | ) |

[0000106040-17-000007:notes:83]
The total net realized transaction and foreign exchange forward contract currency gains and losses were not material to the condensed consolidated financial statements for the three and six months ended December 30, 2016 and January 1, 2016.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-17-000007:notes:84]
[same as prior period, unchanged from 0000106040-16-000040:notes:84]

[0000106040-17-000007:notes:85]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Options | $ | 11 |  |  | $ | 12 |  |  | $ | 23 |  |  | $ | 26 |  |
| Employee stock purchase plan | 1 |  |  | 1 |  |  | 9 |  |  | 6 |  |
| Restricted stock units (1) | 90 |  |  | 24 |  |  | 169 |  |  | 47 |  |
| Subtotal | 102 |  |  | 37 |  |  | 201 |  |  | 79 |  |
| Tax benefit | (29 | ) |  | (10 | ) |  | (54 | ) |  | (20 | ) |
| Total | $ | 73 |  |  | $ | 27 |  |  | $ | 147 |  |  | $ | 59 |  |

[0000106040-17-000007:notes:86]
[same as prior period, unchanged from 0000106040-16-000040:notes:86]

[0000106040-17-000007:notes:87]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Cost of revenue | $ | 11 |  |  | $ | 4 |  |  | $ | 24 |  |  | $ | 9 |  |
| Research and development | 43 |  |  | 15 |  |  | 87 |  |  | 30 |  |
| Selling, general and administrative | 43 |  |  | 18 |  |  | 85 |  |  | 40 |  |
| Restructuring | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Subtotal | 102 |  |  | 37 |  |  | 201 |  |  | 79 |  |
| Tax benefit | (29 | ) |  | (10 | ) |  | (54 | ) |  | (20 | ) |
| Total | $ | 73 |  |  | $ | 27 |  |  | $ | 147 |  |  | $ | 59 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-17-000007:notes:88]
[same as prior period, unchanged from 0000106040-16-000040:notes:88]

[0000106040-17-000007:notes:89]
[same as prior period, unchanged from 0000106040-16-000040:notes:89]

[0000106040-17-000007:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 235 |  |  | $ | 251 |  |  | $ | (131 | ) |  | $ | 534 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 286 |  |  | 232 |  |  | 285 |  |  | 231 |  |
| Employee stock options, RSUs, PSUs, ESPP | 8 |  |  | 2 |  |  | — |  |  | 3 |  |
| Diluted | 294 |  |  | 234 |  |  | 285 |  |  | 234 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.82 |  |  | $ | 1.08 |  |  | $ | (0.46 | ) |  | $ | 2.31 |  |
| Diluted | $ | 0.80 |  |  | $ | 1.07 |  |  | $ | (0.46 | ) |  | $ | 2.28 |  |
| Anti-dilutive potential common shares excluded(1) | 5 |  |  | 6 |  |  | 13 |  |  | 4 |  |

[0000106040-17-000007:notes:91]
[same as prior period, unchanged from 0000106040-16-000040:notes:91]

[0000106040-17-000007:notes:92]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s ESPP, awards of RSUs and PSUs, and exchange options related to the Company’s Convertible Notes.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000106040-17-000007:notes:93]
The following is a reconciliation of the call options reported in Other current assets and Other non-current assets in the Company’s condensed consolidated balance sheet as of December 30, 2016.

[0000106040-17-000007:notes:94]
|  | 2017 Call Options |  | 2020 Call Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 70 |  |  | $ | 1 |  |  | $ | 71 |  |
| Net realized loss | — |  |  | (1 | ) |  | (1 | ) |
| Redemptions | (70 | ) |  | — |  |  | (70 | ) |
| Fair value at December 30, 2016 | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-17-000007:notes:95]
Fair Value Measurements and Investments

[0000106040-17-000007:notes:96]
[same as prior period, unchanged from 0000106040-16-000040:notes:96]

[0000106040-17-000007:notes:97]
[same as prior period, unchanged from 0000106040-16-000040:notes:97]

[0000106040-17-000007:notes:98]
[same as prior period, unchanged from 0000106040-16-000040:notes:98]

[0000106040-17-000007:notes:99]
[same as prior period, unchanged from 0000106040-16-000040:notes:99]

[0000106040-17-000007:notes:100]
[same as prior period, unchanged from 0000106040-16-000040:notes:100]

[0000106040-17-000007:notes:101]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 30, 2016 and July 1, 2016, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-17-000007:notes:102]
|  | December 30, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,381 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,381 |  |
| Certificates of deposit | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total cash equivalents | 1,381 |  |  | 8 |  |  | — |  |  | 1,389 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 137 |  |  | — |  |  | 137 |  |
| Corporate notes and bonds | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total short-term investments | — |  |  | 161 |  |  | — |  |  | 161 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 64 |  |  | — |  |  | 64 |  |
| Asset-backed securities | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Municipal notes and bonds | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total long-term investments | 2 |  |  | 85 |  |  | — |  |  | 87 |  |
| Foreign exchange contracts | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets at fair value | $ | 1,383 |  |  | $ | 258 |  |  | $ | — |  |  | $ | 1,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 178 |  |  | $ | — |  |  | $ | 178 |  |
| Exchange option | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 178 |  |  | $ | 1 |  |  | $ | 179 |  |

[0000106040-17-000007:notes:103]
[same as prior period, unchanged from 0000106040-16-000040:notes:103]

[0000106040-17-000007:notes:104]
During the three and six months ended December 30, 2016 and January 1, 2016, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-17-000007:notes:105]
[same as prior period, unchanged from 0000106040-16-000040:notes:112]

[0000106040-17-000007:notes:106]
The fair value measurement of the call options and exchange options arising from the Company’s Convertible Notes (as defined in Note 6 to the condensed consolidated financial statements) which are not actively traded, is determined using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) the economic incentive for holders to exercise their exchange option. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-17-000007:notes:107]
There were no transfers of call options or exchange options out of Level 3 for the three and six months ended December 30, 2016.

[0000106040-17-000007:notes:108]
The following is a reconciliation of the exchange options reported in Accrued expenses and Other liabilities in the Company’s condensed consolidated balance sheet as of December 30, 2016.

[0000106040-17-000007:notes:109]
|  | 2017 Exchange Options |  | 2020 Exchange Options |  | Total |
|  | (in millions) |
| Fair value at July 1, 2016 | $ | 87 |  |  | $ | 68 |  |  | $ | 155 |  |
| Net realized gain | (3 | ) |  | (31 | ) |  | (34 | ) |
| Redemptions | (83 | ) |  | (46 | ) |  | (129 | ) |
| Net unrealized loss | — |  |  | 9 |  |  | 9 |  |
| Fair value at December 30, 2016 | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0000106040-17-000007:notes:110]
[same as prior period, unchanged from 0000106040-16-000040:notes:117]

[0000106040-17-000007:notes:111]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2017 and the fourth quarter of 2016, respectively.

[0000106040-17-000007:notes:112]
|  | December 30, 2016 |  | July 1, 2016 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Secured Notes | $ | 1,831 |  |  | $ | 2,093 |  |  | $ | 1,828 |  |  | $ | 2,044 |  |
| Unsecured Notes | 3,237 |  |  | 3,978 |  |  | 3,229 |  |  | 3,575 |  |
| Term Loan A | 4,068 |  |  | 4,120 |  |  | 4,061 |  |  | 4,161 |  |
| U.S. Term Loan B | — |  |  | — |  |  | 3,546 |  |  | 3,773 |  |
| U.S. Term Loan B-1 | 2,980 |  |  | 3,028 |  |  | — |  |  | — |  |
| Euro Term Loan B(1) | — |  |  | — |  |  | 960 |  |  | 981 |  |
| Euro Term Loan B-1(1) | 927 |  |  | 946 |  |  | — |  |  | — |  |
| Bridge Loan | — |  |  | — |  |  | 2,995 |  |  | 3,000 |  |
| Convertible Debt 2017 | — |  |  | — |  |  | 124 |  |  | 125 |  |
| Convertible Debt 2020 | 30 |  |  | 31 |  |  | 251 |  |  | 264 |  |
| Total | $ | 13,073 |  |  | $ | 14,196 |  |  | $ | 16,994 |  |  | $ | 17,923 |  |

[0000106040-17-000007:notes:113]
[same as prior period, unchanged from 0000106040-16-000040:notes:120]

[0000106040-17-000007:notes:114]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. As of December 30, 2016 and July 1, 2016, the Company had aggregate net investments under the cost method of accounting of $139 million and $135 million, respectively, and these investments consisted of privately-held equity securities without a readily determinable fair value. The Company has determined that it is not practicable to estimate the fair value of these investments. These privately-held equity investments are reported under Other non-current assets in the condensed consolidated balance sheets.

[0000106040-17-000007:notes:115]
Available-for-Sale Securities

[0000106040-17-000007:notes:116]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of December 30, 2016 and January 1, 2016.

[0000106040-17-000007:notes:117]
The Company determined available-for-sale securities had no material other-than-temporary impairments in the three and six months ended December 30, 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-17-000007:notes:118]
Income Tax Expense (Benefit)

[0000106040-17-000007:notes:119]
The following table presents the income tax expense (benefit) and the effective tax rate:

[0000106040-17-000007:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Income tax expense (benefit) | $ | 86 |  |  | $ | (7 | ) |  | $ | 181 |  |  | $ | 24 |  |
| Effective tax rate | 27 | % |  | (3 | )% |  | 362 | % |  | 4 | % |

[0000106040-17-000007:notes:121]
Income tax expense of $181 million for the six months ended December 30, 2016 is attributable primarily to discrete effects consisting of income tax expense from the integration of SanDisk of $90 million and a valuation allowance on acquired tax attributes of $109 million. Income tax expense related to the SanDisk integration is partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt refinancing of $96 million. These discrete items are the primary drivers of the effective tax rate for the six months ended December 30, 2016.

[0000106040-17-000007:notes:122]
The primary drivers for the difference between the effective tax rate for the three and six months ended December 30, 2016 and the U.S. Federal statutory rate of 35% are the current year generation of tax credits, tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029, for both periods, and the discrete items described above for the six months ended December 30, 2016. For the three and six months ended January 1, 2016, the difference between the effective tax rate and the U.S. Federal statutory rate of 35% is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2029.

[0000106040-17-000007:notes:123]
In the six months ended December 30, 2016, the Company recorded a net decrease of $14 million in its liability for unrecognized tax benefits. As of December 30, 2016, the Company’s liability for unrecognized tax benefits was approximately $477 million. Accrued interest and penalties related to unrecognized tax benefits as of December 30, 2016 was $84 million.

[0000106040-17-000007:notes:124]
[same as prior period, unchanged from 0000106040-16-000040:notes:128]

[0000106040-17-000007:notes:125]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 30, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-17-000007:notes:126]
Legal Proceedings

[0000106040-17-000007:notes:127]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-17-000007:notes:128]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and SanDisk refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-17-000007:notes:129]
Intellectual Property Litigation

[0000106040-17-000007:notes:130]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the District Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-17-000007:notes:131]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

[0000106040-17-000007:notes:132]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints – one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California – against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,452; RE45,486; 7,464,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The Company intends to defend itself vigorously in these matters.

[0000106040-17-000007:notes:133]
Antitrust

[0000106040-17-000007:notes:134]
In June 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint with the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. In February 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. In May 2015, the District Court granted in part plaintiffs’ motion for class certification. In April 2016, the District Court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk’s favor as to all of the plaintiffs’ claims. In May 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

[0000106040-17-000007:notes:135]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In August 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint in September 2011. In January 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. In April 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint in January 2015. In September 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. In October 2015, Samsung filed a fourth amended complaint. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.

[0000106040-17-000007:notes:136]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In May 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. In May 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. In February 2015, the plaintiffs filed a second amended complaint in the District Court. In September 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. In November 2015, the plaintiffs filed a third amended complaint. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000007:notes:137]
Securities

[0000106040-17-000007:notes:138]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss in April 2016. In June 2016, the District Court granted the motion and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. The defendants filed a motion to dismiss in August 2016. In January 2017, the District Court denied the motion to dismiss without prejudice to the defendants filing a renewed motion to dismiss, which the defendants filed soon thereafter. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000007:notes:139]
Other Matters

[0000106040-17-000007:notes:140]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue.  In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000007:notes:141]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000007:notes:142]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows. It is reasonably possible that the Company may incur losses totaling up to $133 million, including the amounts accrued.

[0000106040-17-000007:notes:143]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-17-000007:notes:144]
Accounting Changes and Recent Accounting Pronouncements

[0000106040-17-000007:notes:145]
Recently Adopted

[0000106040-17-000007:notes:146]
In April 2015, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-05, “Intangibles — Goodwill and Other — Internal-Use Software (Subtopic 350-40)” (“ASU 2015-05”), which provides guidance to customers about whether a cloud computing arrangement includes a software license. If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company’s adoption of ASU 2015-05 at the beginning of the current year did not have a material impact on its condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-17-000007:notes:147]
Basis of Presentation

[0000106040-17-000007:notes:148]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the needs of the information technology industry and the infrastructure that enables the storage of data. The Company also generates license and royalty revenue related to its intellectual property.

[0000106040-17-000007:notes:149]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-17-000007:notes:150]
Fiscal Year

[0000106040-17-000007:notes:151]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal year 2017, which ends on June 30, 2017, and fiscal year 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-17-000007:notes:152]
Reclassifications

[0000106040-17-000007:notes:153]
Certain prior year amounts have been reclassified in the condensed consolidated statements of operations and condensed consolidated statements of cash flows to conform to the current year presentation.

[0000106040-17-000007:notes:154]
Use of Estimates

[0000106040-17-000007:notes:155]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-17-000007:notes:156]
[same as prior period, unchanged from 0000106040-16-000040:notes:166]

[0000106040-17-000007:notes:157]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the "Japanese Plan") are immaterial to the Company’s condensed consolidated financial statements. The expected long-term rate of return on the Japanese Plan assets is 2.5%.

[0000106040-17-000007:notes:158]
[same as prior period, unchanged from 0000106040-16-000040:notes:168]

[0000106040-17-000007:notes:159]
The following table presents the unfunded amounts related to the Japanese Plan as recognized on the Company’s condensed consolidated balance sheets:

[0000106040-17-000007:notes:160]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Non-current liabilities | $ | 91 |  |  | $ | 114 |  |
| Net amount recognized | $ | 91 |  |  | $ | 114 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-17-000007:notes:161]
[same as prior period, unchanged from 0000106040-16-000040:notes:171]

[0000106040-17-000007:notes:162]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and buildings | $ | 1,871 |  |  | $ | 1,900 |  |
| Machinery and equipment | 7,064 |  |  | 6,915 |  |
| Software | 174 |  |  | 155 |  |
| Furniture and fixtures | 52 |  |  | 110 |  |
| Leasehold improvements | 314 |  |  | 307 |  |
| Construction-in-process | 119 |  |  | 245 |  |
| Property, plant and equipment, gross | 9,594 |  |  | 9,632 |  |
| Accumulated depreciation | (6,356 | ) |  | (6,129 | ) |
| Property, plant and equipment, net | $ | 3,238 |  |  | $ | 3,503 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-17-000007:notes:163]
The following table illustrates the significant amounts of each component reclassified out of AOCI to the condensed consolidated statements of operations:

[0000106040-17-000007:notes:164]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
| AOCI Component |  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on cash flow hedging activities: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 16 |  |  | $ | (25 | ) |  | $ | 40 |  |  | $ | (53 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | — |  |  | — |  |  | 2 |  |  | — |  |  | Research and development |
| Unrealized holding gain (loss) on cash flow hedging activities |  | 16 |  |  | (25 | ) |  | 42 |  |  | (53 | ) |  |  |
| Total reclassifications for the period |  | $ | 16 |  |  | $ | (25 | ) |  | $ | 42 |  |  | $ | (53 | ) |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-17-000007:notes:165]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-17-000007:notes:166]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Foreign Exchange Contracts |  | Total AOCI |
|  | (in millions) |
| Balance at July 1, 2016 | $ | (45 | ) |  | $ | 74 |  |  | $ | 74 |  |  | $ | 103 |  |
| OCI before reclassifications | 6 |  |  | (169 | ) |  | (98 | ) |  | (261 | ) |
| Amounts reclassified from AOCI | — |  |  | — |  |  | (42 | ) |  | (42 | ) |
| Income tax benefit (expense) related to items of OCI | (2 | ) |  | 5 |  |  | — |  |  | 3 |  |
| Net current-period OCI | 4 |  |  | (164 | ) |  | (140 | ) |  | (300 | ) |
| Balance at December 30, 2016 | $ | (41 | ) |  | $ | (90 | ) |  | $ | (66 | ) |  | $ | (197 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-17-000007:notes:167]
| Condensed Consolidating Balance Sheet |
| As of December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 46 |  |  | $ | 883 |  |  | $ | 4,011 |  |  | $ | — |  |  | $ | 4,940 |  |
| Short-term investments | — |  |  | — |  |  | 161 |  |  | — |  |  | 161 |  |
| Accounts receivable, net | — |  |  | 1,320 |  |  | 684 |  |  | — |  |  | 2,004 |  |
| Intercompany receivable | 813 |  |  | 1,878 |  |  | 2,923 |  |  | (5,614 | ) |  | — |  |
| Inventories | — |  |  | 828 |  |  | 1,455 |  |  | (198 | ) |  | 2,085 |  |
| Other current assets | 4 |  |  | 253 |  |  | 159 |  |  | — |  |  | 416 |  |
| Total current assets | 863 |  |  | 5,162 |  |  | 9,393 |  |  | (5,812 | ) |  | 9,606 |  |
| Property, plant and equipment, net | — |  |  | 1,207 |  |  | 2,031 |  |  | — |  |  | 3,238 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,082 |  |  | — |  |  | 1,082 |  |
| Goodwill | — |  |  | 325 |  |  | 9,680 |  |  | — |  |  | 10,005 |  |
| Other intangible assets, net | — |  |  | 19 |  |  | 4,450 |  |  | — |  |  | 4,469 |  |
| Investments in consolidated subsidiaries | 17,942 |  |  | 17,874 |  |  | — |  |  | (35,816 | ) |  | — |  |
| Loans due from consolidated affiliates | 5,230 |  |  | 15 |  |  | — |  |  | (5,245 | ) |  | — |  |
| Other non-current assets | 46 |  |  | 99 |  |  | 466 |  |  | (36 | ) |  | 575 |  |
| Total assets | $ | 24,081 |  |  | $ | 24,701 |  |  | $ | 27,102 |  |  | $ | (46,909 | ) |  | $ | 28,975 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 225 |  |  | $ | 1,787 |  |  | $ | — |  |  | $ | 2,012 |  |
| Intercompany payable | 180 |  |  | 4,823 |  |  | 611 |  |  | (5,614 | ) |  | — |  |
| Accounts payable to related parties | — |  |  | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Accrued expenses | 126 |  |  | 507 |  |  | 368 |  |  | — |  |  | 1,001 |  |
| Accrued compensation | — |  |  | 376 |  |  | 205 |  |  | — |  |  | 581 |  |
| Accrued warranty | — |  |  | 4 |  |  | 186 |  |  | — |  |  | 190 |  |
| Current portion of long-term debt | 129 |  |  | — |  |  | — |  |  | — |  |  | 129 |  |
| Total current liabilities | 435 |  |  | 5,935 |  |  | 3,332 |  |  | (5,614 | ) |  | 4,088 |  |
| Long-term debt | 12,915 |  |  | — |  |  | 29 |  |  | — |  |  | 12,944 |  |
| Loans due to consolidated affiliates | — |  |  | 34 |  |  | 5,211 |  |  | (5,245 | ) |  | — |  |
| Other liabilities | — |  |  | 670 |  |  | 578 |  |  | (37 | ) |  | 1,211 |  |
| Total liabilities | 13,350 |  |  | 6,639 |  |  | 9,150 |  |  | (10,896 | ) |  | 18,243 |  |
| Shareholders’ equity | 10,731 |  |  | 18,062 |  |  | 17,952 |  |  | (36,013 | ) |  | 10,732 |  |
| Total liabilities and shareholders’ equity | $ | 24,081 |  |  | $ | 24,701 |  |  | $ | 27,102 |  |  | $ | (46,909 | ) |  | $ | 28,975 |  |

[0000106040-17-000007:notes:168]
| Condensed Consolidating Balance Sheet |
| As of July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 1,206 |  |  | $ | 6,945 |  |  | $ | — |  |  | $ | 8,151 |  |
| Short-term investments | — |  |  | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Accounts receivable, net | — |  |  | 985 |  |  | 476 |  |  | — |  |  | 1,461 |  |
| Intercompany receivable | 934 |  |  | 886 |  |  | 2,546 |  |  | (4,366 | ) |  | — |  |
| Inventories | — |  |  | 896 |  |  | 1,450 |  |  | (217 | ) |  | 2,129 |  |
| Other current assets | 4 |  |  | 276 |  |  | 379 |  |  | (43 | ) |  | 616 |  |
| Total current assets | 938 |  |  | 4,249 |  |  | 12,023 |  |  | (4,626 | ) |  | 12,584 |  |
| Property, plant and equipment, net | — |  |  | 1,265 |  |  | 2,238 |  |  | — |  |  | 3,503 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,171 |  |  | — |  |  | 1,171 |  |
| Goodwill | — |  |  | 324 |  |  | 9,627 |  |  | — |  |  | 9,951 |  |
| Other intangible assets, net | — |  |  | 28 |  |  | 5,006 |  |  | — |  |  | 5,034 |  |
| Investments in consolidated subsidiaries | 18,009 |  |  | 27,020 |  |  | — |  |  | (45,029 | ) |  | — |  |
| Loans due from consolidated affiliates | 6,000 |  |  | 55 |  |  | — |  |  | (6,055 | ) |  | — |  |
| Other non-current assets | 50 |  |  | 33 |  |  | 702 |  |  | (166 | ) |  | 619 |  |
| Total assets | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 239 |  |  | $ | 1,649 |  |  | $ | — |  |  | $ | 1,888 |  |
| Intercompany payable | 119 |  |  | 4,043 |  |  | 204 |  |  | (4,366 | ) |  | — |  |
| Accounts payable to related parties | — |  |  | — |  |  | 168 |  |  | — |  |  | 168 |  |
| Accrued expenses | 109 |  |  | 462 |  |  | 404 |  |  | 20 |  |  | 995 |  |
| Accrued compensation | — |  |  | 222 |  |  | 170 |  |  | — |  |  | 392 |  |
| Accrued warranty | — |  |  | 4 |  |  | 168 |  |  | — |  |  | 172 |  |
| Bridge loan | — |  |  | 2,995 |  |  | — |  |  | — |  |  | 2,995 |  |
| Current portion of long-term debt | 14 |  |  | — |  |  | 325 |  |  | — |  |  | 339 |  |
| Total current liabilities | 242 |  |  | 7,965 |  |  | 3,088 |  |  | (4,346 | ) |  | 6,949 |  |
| Long-term debt | 13,610 |  |  | — |  |  | 50 |  |  | — |  |  | 13,660 |  |
| Loans due to consolidated affiliates | — |  |  | 6,000 |  |  | 55 |  |  | (6,055 | ) |  | — |  |
| Other liabilities | — |  |  | 862 |  |  | 475 |  |  | (229 | ) |  | 1,108 |  |
| Total liabilities | 13,852 |  |  | 14,827 |  |  | 3,668 |  |  | (10,630 | ) |  | 21,717 |  |
| Shareholders’ equity | 11,145 |  |  | 18,147 |  |  | 27,099 |  |  | (45,246 | ) |  | 11,145 |  |
| Total liabilities and shareholders’ equity | $ | 24,997 |  |  | $ | 32,974 |  |  | $ | 30,767 |  |  | $ | (55,876 | ) |  | $ | 32,862 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-17-000007:notes:169]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (256 | ) |  | $ | 211 |  |  | $ | 1,443 |  |  | $ | 102 |  |  | $ | 1,500 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (136 | ) |  | (194 | ) |  | — |  |  | (330 | ) |
| Proceeds from the sale of equipment | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Purchases of investments | — |  |  | — |  |  | (239 | ) |  | — |  |  | (239 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 279 |  |  | — |  |  | 279 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (309 | ) |  | — |  |  | (309 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Intercompany loans to consolidated affiliates | 770 |  |  | 40 |  |  | — |  |  | (810 | ) |  | — |  |
| Advances to consolidated affiliates | 293 |  |  | (285 | ) |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,063 |  |  | (381 | ) |  | (180 | ) |  | (818 | ) |  | (316 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 90 |  |  | — |  |  | — |  |  | — |  |  | 90 |  |
| Taxes paid on vested stock awards under employee stock plans | (40 | ) |  | — |  |  | — |  |  | — |  |  | (40 | ) |
| Excess tax benefits from employee stock plans | 56 |  |  | — |  |  | — |  |  | — |  |  | 56 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Dividends paid to shareholders | (284 | ) |  | — |  |  | — |  |  | — |  |  | (284 | ) |
| Repayment of debt | (4,767 | ) |  | (2,995 | ) |  | (492 | ) |  | — |  |  | (8,254 | ) |
| Proceeds from debt | 3,992 |  |  | — |  |  | — |  |  | — |  |  | 3,992 |  |
| Debt issuance costs | (7 | ) |  | — |  |  | — |  |  | — |  |  | (7 | ) |
| Intercompany loan from parent | — |  |  | (5,966 | ) |  | 5,156 |  |  | 810 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 199 |  |  | 8,808 |  |  | (8,913 | ) |  | (94 | ) |  | — |  |
| Net cash used in financing activities | (761 | ) |  | (153 | ) |  | (4,188 | ) |  | 716 |  |  | (4,386 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net increase (decrease) in cash and cash equivalents | 46 |  |  | (323 | ) |  | (2,934 | ) |  | — |  |  | (3,211 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of period | $ | 46 |  |  | $ | 883 |  |  | $ | 4,011 |  |  | $ | — |  |  | $ | 4,940 |  |

[0000106040-17-000007:notes:170]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended January 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 12 |  |  | $ | 266 |  |  | $ | 852 |  |  | $ | 13 |  |  | $ | 1,143 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (114 | ) |  | (186 | ) |  | — |  |  | (300 | ) |
| Purchases of investments | — |  |  | — |  |  | (408 | ) |  | — |  |  | (408 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | — |  |  | 266 |  |  | 266 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 266 |  |  | (266 | ) |  | — |  |
| Strategic investments and other, net | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Advances from (to) consolidated affiliates | 207 |  |  | (207 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 207 |  |  | (321 | ) |  | (340 | ) |  | — |  |  | (454 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 54 |  |  | — |  |  | — |  |  | — |  |  | 54 |  |
| Taxes paid on vested stock awards under employee stock plans | (44 | ) |  | — |  |  | — |  |  | — |  |  | (44 | ) |
| Excess tax benefits from employee stock plans | (6 | ) |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Repurchases of common stock | (60 | ) |  | — |  |  | — |  |  | — |  |  | (60 | ) |
| Dividends paid to shareholders | (231 | ) |  | — |  |  | — |  |  | — |  |  | (231 | ) |
| Repayment of debt | — |  |  | (63 | ) |  | — |  |  | — |  |  | (63 | ) |
| Change in investment in consolidated subsidiaries | 68 |  |  | (52 | ) |  | (3 | ) |  | (13 | ) |  | — |  |
| Net cash used in financing activities | (219 | ) |  | (115 | ) |  | (3 | ) |  | (13 | ) |  | (350 | ) |
| Net increase (decrease) in cash and cash equivalents | — |  |  | (170 | ) |  | 509 |  |  | — |  |  | 339 |  |
| Cash and cash equivalents, beginning of year | — |  |  | 661 |  |  | 4,363 |  |  | — |  |  | 5,024 |  |
| Cash and cash equivalents, end of period | $ | — |  |  | $ | 491 |  |  | $ | 4,872 |  |  | $ | — |  |  | $ | 5,363 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-17-000007:notes:171]
Separate Financial Information of Guarantor Subsidiaries

[0000106040-17-000007:notes:172]
The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The New Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by the WD Guarantors (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the designation of a Guarantor Subsidiary as an unrestricted subsidiary under the indenture governing the New Unsecured Notes, (ii) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the New Unsecured Notes, (iii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the New Unsecured Notes, (iv) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (v) the Company’s exercise of its defeasance options under the indenture governing the New Unsecured Notes, (vi) the dissolution or liquidation of a Guarantor Subsidiary or (vii) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the New Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-17-000007:notes:173]
For more information regarding the New Unsecured Notes, refer to Note 6 to the condensed consolidated financial statements.

[0000106040-17-000007:notes:174]
| Condensed Consolidating Statements of Operations |
| For the three months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,786 |  |  | $ | 4,245 |  |  | $ | (3,143 | ) |  | $ | 4,888 |  |
| Cost of revenue | — |  |  | 3,085 |  |  | 3,495 |  |  | (3,225 | ) |  | 3,355 |  |
| Gross profit | — |  |  | 701 |  |  | 750 |  |  | 82 |  |  | 1,533 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 372 |  |  | 213 |  |  | — |  |  | 585 |  |
| Selling, general and administrative | 3 |  |  | 252 |  |  | 103 |  |  | — |  |  | 358 |  |
| Intercompany operating expense (income) | — |  |  | (218 | ) |  | 218 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges | — |  |  | 9 |  |  | 36 |  |  | — |  |  | 45 |  |
| Total operating expenses | 3 |  |  | 415 |  |  | 570 |  |  | — |  |  | 988 |  |
| Operating income (loss) | (3 | ) |  | 286 |  |  | 180 |  |  | 82 |  |  | 545 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 86 |  |  | — |  |  | 2 |  |  | (83 | ) |  | 5 |  |
| Interest expense | (203 | ) |  | — |  |  | (85 | ) |  | 83 |  |  | (205 | ) |
| Other expense, net | (2 | ) |  | (5 | ) |  | (17 | ) |  | — |  |  | (24 | ) |
| Total interest and other expense, net | (119 | ) |  | (5 | ) |  | (100 | ) |  | — |  |  | (224 | ) |
| Income (loss) before taxes | (122 | ) |  | 281 |  |  | 80 |  |  | 82 |  |  | 321 |  |
| Income tax expense (benefit) | (87 | ) |  | 116 |  |  | 57 |  |  | — |  |  | 86 |  |
| Equity in earnings from subsidiaries | 270 |  |  | 19 |  |  | — |  |  | (289 | ) |  | — |  |
| Net income | $ | 235 |  |  | $ | 184 |  |  | $ | 23 |  |  | $ | (207 | ) |  | $ | 235 |  |

[0000106040-17-000007:notes:175]
| Condensed Consolidating Statements of Operations |
| For the six months ended December 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 7,484 |  |  | $ | 8,538 |  |  | $ | (6,420 | ) |  | $ | 9,602 |  |
| Cost of revenue | — |  |  | 6,150 |  |  | 7,048 |  |  | (6,464 | ) |  | 6,734 |  |
| Gross profit | — |  |  | 1,334 |  |  | 1,490 |  |  | 44 |  |  | 2,868 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 813 |  |  | 411 |  |  | — |  |  | 1,224 |  |
| Selling, general and administrative | 4 |  |  | 526 |  |  | 224 |  |  | — |  |  | 754 |  |
| Intercompany operating expense (income) | — |  |  | (569 | ) |  | 569 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges | — |  |  | 58 |  |  | 55 |  |  | — |  |  | 113 |  |
| Total operating expenses | 4 |  |  | 828 |  |  | 1,259 |  |  | — |  |  | 2,091 |  |
| Operating income (loss) | (4 | ) |  | 506 |  |  | 231 |  |  | 44 |  |  | 777 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 180 |  |  | 1 |  |  | 9 |  |  | (180 | ) |  | 10 |  |
| Interest expense | (431 | ) |  | (5 | ) |  | (185 | ) |  | 180 |  |  | (441 | ) |
| Other expense, net | (274 | ) |  | (4 | ) |  | (18 | ) |  | — |  |  | (296 | ) |
| Total interest and other expense, net | (525 | ) |  | (8 | ) |  | (194 | ) |  | — |  |  | (727 | ) |
| Income (loss) before taxes | (529 | ) |  | 498 |  |  | 37 |  |  | 44 |  |  | 50 |  |
| Income tax expense (benefit) | (181 | ) |  | 121 |  |  | 241 |  |  | — |  |  | 181 |  |
| Equity in earnings from subsidiaries | 217 |  |  | (208 | ) |  | — |  |  | (9 | ) |  | — |  |
| Net income (loss) | $ | (131 | ) |  | $ | 169 |  |  | $ | (204 | ) |  | $ | 35 |  |  | $ | (131 | ) |

[0000106040-17-000007:notes:176]
| Condensed Consolidating Statements of Operations |
| For the three months ended January 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,411 |  |  | $ | 3,611 |  |  | $ | (3,705 | ) |  | $ | 3,317 |  |
| Cost of revenue | — |  |  | 3,190 |  |  | 2,918 |  |  | (3,697 | ) |  | 2,411 |  |
| Gross profit | — |  |  | 221 |  |  | 693 |  |  | (8 | ) |  | 906 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 270 |  |  | 119 |  |  | — |  |  | 389 |  |
| Selling, general and administrative | 1 |  |  | 138 |  |  | 100 |  |  | — |  |  | 239 |  |
| Intercompany operating expense (income) | — |  |  | (278 | ) |  | 278 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges | — |  |  | 20 |  |  | 7 |  |  | — |  |  | 27 |  |
| Total operating expenses | 1 |  |  | 150 |  |  | 504 |  |  | — |  |  | 655 |  |
| Operating income (loss) | (1 | ) |  | 71 |  |  | 189 |  |  | (8 | ) |  | 251 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | — |  |  | 4 |  |  | 1 |  |  | 5 |  |
| Interest expense | — |  |  | (11 | ) |  | (2 | ) |  | — |  |  | (13 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | (1 | ) |  | 1 |  |
| Total interest and other income (expense), net | — |  |  | (11 | ) |  | 4 |  |  | — |  |  | (7 | ) |
| Income (loss) before taxes | (1 | ) |  | 60 |  |  | 193 |  |  | (8 | ) |  | 244 |  |
| Income tax expense (benefit) | — |  |  | 19 |  |  | (26 | ) |  | — |  |  | (7 | ) |
| Equity in earnings from subsidiaries | 252 |  |  | 217 |  |  | — |  |  | (469 | ) |  | — |  |
| Net income | $ | 251 |  |  | $ | 258 |  |  | $ | 219 |  |  | $ | (477 | ) |  | $ | 251 |  |

[0000106040-17-000007:notes:177]
| Condensed Consolidating Statements of Operations |
| For the six months ended January 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 6,837 |  |  | $ | 7,024 |  |  | $ | (7,184 | ) |  | $ | 6,677 |  |
| Cost of revenue | — |  |  | 6,410 |  |  | 5,578 |  |  | (7,172 | ) |  | 4,816 |  |
| Gross profit | — |  |  | 427 |  |  | 1,446 |  |  | (12 | ) |  | 1,861 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 579 |  |  | 195 |  |  | — |  |  | 774 |  |
| Selling, general and administrative | 2 |  |  | 309 |  |  | 120 |  |  | — |  |  | 431 |  |
| Intercompany operating expense (income) | — |  |  | (590 | ) |  | 590 |  |  | — |  |  | — |  |
| Employee termination, asset impairment and other charges | — |  |  | 70 |  |  | 13 |  |  | — |  |  | 83 |  |
| Total operating expenses | 2 |  |  | 368 |  |  | 918 |  |  | — |  |  | 1,288 |  |
| Operating income (loss) | (2 | ) |  | 59 |  |  | 528 |  |  | (12 | ) |  | 573 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 1 |  |  | 8 |  |  | — |  |  | 9 |  |
| Interest expense | — |  |  | (22 | ) |  | (4 | ) |  | — |  |  | (26 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total interest and other income (expense), net | — |  |  | (21 | ) |  | 6 |  |  | — |  |  | (15 | ) |
| Income (loss) before taxes | (2 | ) |  | 38 |  |  | 534 |  |  | (12 | ) |  | 558 |  |
| Income tax expense (benefit) | — |  |  | 52 |  |  | (28 | ) |  | — |  |  | 24 |  |
| Equity in earnings from subsidiaries | 536 |  |  | 562 |  |  | — |  |  | (1,098 | ) |  | — |  |
| Net income | $ | 534 |  |  | $ | 548 |  |  | $ | 562 |  |  | $ | (1,110 | ) |  | $ | 534 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-17-000007:notes:178]
Goodwill

[0000106040-17-000007:notes:179]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 1, 2016 | $ | 9,951 |  |
| Purchase price adjustments to goodwill | 60 |  |
| Foreign currency translation adjustment | (6 | ) |
| Balance at December 30, 2016 | $ | 10,005 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0000106040-17-000007:notes:180]
[same as prior period, unchanged from 0000106040-16-000040:notes:178]

[0000106040-17-000007:notes:181]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,203 |  |  | $ | 3,539 |  |
| In-process research and development | 695 |  |  | 2,435 |  |
| Accumulated amortization | (1,429 | ) |  | (940 | ) |
| Intangible assets, net | $ | 4,469 |  |  | $ | 5,034 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-17-000007:notes:182]
[same as prior period, unchanged from 0000106040-16-000040:notes:180]

[0000106040-17-000007:notes:183]
|  | December 30, 2016 |  | July 1, 2016 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 586 |  |  | $ | 569 |  |
| Work-in-process | 617 |  |  | 589 |  |
| Finished goods | 882 |  |  | 971 |  |
| Total inventories | $ | 2,085 |  |  | $ | 2,129 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-17-000007:notes:184]
[same as prior period, unchanged from 0000106040-16-000040:notes:182]

[0000106040-17-000007:notes:185]
[same as prior period, unchanged from 0000106040-16-000040:notes:183]

[0000106040-17-000007:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 277 |  |  | $ | 218 |  |  | $ | 279 |  |  | $ | 221 |  |
| Charges to operations | 44 |  |  | 43 |  |  | 91 |  |  | 88 |  |
| Utilization | (35 | ) |  | (40 | ) |  | (80 | ) |  | (94 | ) |
| Changes in estimate related to pre-existing warranties | 27 |  |  | 4 |  |  | 23 |  |  | 10 |  |
| Warranty accrual, end of period | $ | 313 |  |  | $ | 225 |  |  | $ | 313 |  |  | $ | 225 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-17-000007:notes:187]
The following table presents an analysis of the components of the activity against the reserve during the six months ended December 30, 2016:

[0000106040-17-000007:notes:188]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Charges | 2 |  |  | 4 |  |  | 6 |  |
| Cash payments | (15 | ) |  | (7 | ) |  | (22 | ) |
| Non-cash items and other | (1 | ) |  | 3 |  |  | 2 |  |
| Accrual balance at December 30, 2016 | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000106040-17-000007:notes:189]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| Charges | 12 |  |  | 34 |  |  | 46 |  |
| Cash payments | (30 | ) |  | (32 | ) |  | (62 | ) |
| Accrual balance at December 30, 2016 | $ | 8 |  |  | $ | 2 |  |  | $ | 10 |  |

[0000106040-17-000007:notes:190]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 1, 2016 | $ | 11 |  |  | $ | 3 |  |  | $ | 14 |  |
| Charges | 44 |  |  | — |  |  | 44 |  |
| Cash payments | (51 | ) |  | (1 | ) |  | (52 | ) |
| Non-cash items and other | 6 |  |  | — |  |  | 6 |  |
| Accrual balance at December 30, 2016 | $ | 10 |  |  | $ | 2 |  |  | $ | 12 |  |

[0000106040-17-000007:notes:191]
[same as prior period, unchanged from 0000106040-16-000040:notes:188]

[0000106040-17-000007:notes:192]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 19 |  |  | $ | — |  |  | $ | 46 |  |  | $ | — |  |
| Closure of Foreign Manufacturing Facility | 2 |  |  | — |  |  | 6 |  |  | — |  |
| Business Realignment | 7 |  |  | 27 |  |  | 44 |  |  | 75 |  |
| Total employee termination and other charges | 28 |  |  | 27 |  |  | 96 |  |  | 75 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | — |  |  | (1 | ) |  | — |  |
| Business Realignment | 4 |  |  | — |  |  | 5 |  |  | — |  |
| Total stock-based compensation accelerations and adjustments | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Asset impairment: |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facility | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Business Realignment | — |  |  | — |  |  | — |  |  | 8 |  |
| Total asset impairment | 13 |  |  | — |  |  | 13 |  |  | 8 |  |
| Total employee termination and other charges, stock-based compensation adjustments and asset impairments | $ | 45 |  |  | $ | 27 |  |  | $ | 113 |  |  | $ | 83 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-17-000007:notes:193]
[same as prior period, unchanged from 0000106040-16-000040:notes:192]

[0000106040-17-000007:notes:194]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 1, 2016 | 9.0 |  |  | $ | 55.74 |  |  | 3.9 |  |  | $ | 60 |  |
| Granted | 2.8 |  |  | 44.83 |  |  |  |  |  |
| Exercised | (1.5 | ) |  | 34.56 |  |  |  |  |  |
| Canceled or expired | (0.6 | ) |  | 69.91 |  |  |  |  |  |
| Options outstanding at December 30, 2016 | 9.7 |  |  | 54.86 |  |  | 4.4 |  |  | 187 |  |
| Exercisable at December 30, 2016 | 4.8 |  |  | 53.61 |  |  | 2.8 |  |  | 101 |  |
| Vested and expected to vest after December 30, 2016 | 9.4 |  |  | 55.00 |  |  | 4.3 |  |  | 180 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-17-000007:notes:195]
[same as prior period, unchanged from 0000106040-16-000040:notes:195]

[0000106040-17-000007:notes:196]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
|  | (in millions) |  |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | $ | 41.92 |  |
| Granted | 5.5 |  |  | 45.23 |  |
| Vested | (2.3 | ) |  | 62.49 |  |
| Forfeited | (1.4 | ) |  | 44.06 |  |
| RSUs and PSUs outstanding at December 30, 2016 | 17.5 |  |  | 42.82 |  |
| Expected to vest after December 30, 2016 | 16.3 |  |  | 42.83 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-17-000007:notes:197]
[same as prior period, unchanged from 0000106040-16-000040:notes:197]

[0000106040-17-000007:notes:198]
Stock-based Compensation Expense

[0000106040-17-000007:notes:199]
As of December 30, 2016, total compensation cost related to unvested stock options was $83 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.8 years. As of December 30, 2016, total compensation cost related to the Company’s Employee Stock Purchase Plan (“ESPP”) rights issued to employees but not yet recognized was $41 million and will be amortized on a straight-line basis over a weighted average service period of approximately 1.4 years.

[0000106040-17-000007:notes:200]
As of December 30, 2016, the aggregate unamortized fair value of all unvested RSUs and PSUs was $611 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 2.6 years, assuming the performance metrics are met for the PSUs.

[0000106040-17-000007:notes:201]
Stock Option Activity

[0000106040-17-000007:notes:202]
As of December 30, 2016, the Company had options outstanding to purchase an aggregate of 6.6 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $187 million at that date.

[0000106040-17-000007:notes:203]
RSU and PSU Activity

[0000106040-17-000007:notes:204]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The aggregate value of RSUs and PSUs that became fully-vested during the six months ended December 30, 2016 was $117 million, determined as of the vest date.

[0000106040-17-000007:notes:205]
[same as prior period, unchanged from 0000106040-16-000040:notes:202]

[0000106040-17-000007:notes:206]
As of December 30, 2016, all outstanding stock appreciation rights (“SARs”) issued to employees were fully vested and will be settled in cash upon exercise. The fair value of SARs is solely subject to market price fluctuations. The following table presents the adjustments to the fair market value of SARs for the three and six months ended December 30, 2016 and January 1, 2016:

[0000106040-17-000007:notes:207]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2016 |  | January 1, 2016 |  | December 30, 2016 |  | January 1, 2016 |
|  | (in millions) |
| SAR expense (benefit) | $ | 3 |  |  | $ | (10 | ) |  | $ | 8 |  |  | $ | (11 | ) |
| Tax expense (benefit) | (1 | ) |  | 1 |  |  | (2 | ) |  | 1 |  |
| Total SAR expense (benefit) | $ | 2 |  |  | $ | (9 | ) |  | $ | 6 |  |  | $ | (10 | ) |

[0000106040-17-000007:notes:208]
The Company had a total liability of $24 million and $20 million related to SARs included in Accrued expenses in the Company’s condensed consolidated balance sheet as of December 30, 2016 and July 1, 2016, respectively. As of December 30, 2016, 0.4 million SARs were outstanding with a weighted average exercise price of $7.99.

[0000106040-17-000007:notes:209]
[same as prior period, unchanged from 0000106040-16-000040:notes:206]

[0000106040-17-000007:notes:210]
The Company’s Board of Directors (the “Board”) has authorized $5.0 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares of common stock during the three and six months ended December 30, 2016. The remaining amount available to be purchased under the Company’s stock repurchase program as of December 30, 2016 was $2.1 billion.

[0000106040-17-000007:notes:211]
[same as prior period, unchanged from 0000106040-16-000040:notes:208]

[0000106040-17-000007:notes:212]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. The Company paid $142 million in cash of dividends on July 15, 2016 relating to dividends declared on May 3, 2016 and paid $143 million in cash of dividends on October 17, 2016 relating to dividends declared on August 3, 2016.

[0000106040-17-000007:notes:213]
On November 3, 2016, the Board declared a cash dividend for the quarter ended December 30, 2016 of $0.50 per share of the Company’s common stock, $0.01 par value per share. The cash dividend of $144 million was paid on January 17, 2017 to the Company’s shareholders of record as of December 30, 2016.

[0000106040-17-000007:notes:214]
On February 1, 2017, the Board declared a cash dividend for the quarter ending March 31, 2017 of $0.50 per share of the Company’s common stock, $0.01 par value per share. The cash dividend will be paid on April 17, 2017 to shareholders of record as of March 31, 2017.

[0000106040-17-000007:notes:215]
[same as prior period, unchanged from 0000106040-16-000040:notes:212]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-17-000007:notes:216]
[same as prior period, unchanged from 0000106040-16-000040:notes:213]

[0000106040-17-000007:notes:217]
[same as prior period, unchanged from 0000106040-16-000040:notes:214]

[0000106040-17-000007:notes:218]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three and six months ended December 30, 2016 and the three months ended January 1, 2016, the Company did not sell any trade accounts receivables. During the six months ended January 1, 2016, the Company sold trade accounts receivable and received cash proceeds of $200 million. The discounts on the trade accounts receivables sold during the six months ended January 1, 2016 were not material and were recorded within Other income (expense), net in the condensed consolidated statements of operations.

[0000106040-17-000007:notes:219]
The purchase price adjustments resulted from adjustments to the assessment of fair value for certain acquired intangible assets; inventory; property, plant and equipment; and a portion of the deferred tax liability related to the acquisition of SanDisk Corporation (“SanDisk”).

[0000106040-17-000007:notes:220]
Acquired in-process research and development (“IPR&D”) is accounted for as an indefinite-lived intangible asset. Upon completion of development, IPR&D is considered to be an amortizable finite-lived intangible asset. During the three months ended December 30, 2016, the Company reclassified $1.7 billion of acquired IPR&D to existing technology and commenced amortization over an estimated useful life of 4 years.

[0000106040-17-000007:notes:221]
The long-term portion of the warranty accrual classified in other liabilities was $123 million and $107 million as of December 30, 2016 and July 1, 2016, respectively.

[0000106040-17-000007:notes:222]
[same as prior period, unchanged from 0000106040-16-000040:notes:219]

[0000106040-17-000007:notes:223]
Other comprehensive income (loss) (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) (“AOCI”):


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-17-000007:notes:224]
[same as prior period, unchanged from 0000106040-16-000040:notes:220]

[0000106040-17-000007:notes:225]
[same as prior period, unchanged from 0000106040-16-000040:notes:221]

[0000106040-17-000007:notes:226]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 for employee termination, asset impairments and other charges, as presented above, the Company recognized $4 million and $30 million in the three and six months ended December 30, 2016, respectively, of accelerated depreciation on facility assets in cost of revenue.

[0000106040-17-000007:notes:227]
[same as prior period, unchanged from 0000106040-16-000040:notes:223]

[0000106040-17-000007:notes:228]
In January 2016, the Company announced the closing of its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. During the six months ended December 30, 2016, the Company recognized employee termination benefits and contract termination and other charges of $6 million related to this closure. In addition, during the three months ended December 30, 2016, the Company recognized asset impairment charges of $13 million related to this closure based on a current estimation of fair value. As of December 30, 2016, the Company substantially completed all activities related to the closure of the facility. The following table presents an analysis of the components of the activity against the reserve during the six months ended December 30, 2016:

[0000106040-17-000007:notes:229]
[same as prior period, unchanged from 0000106040-16-000040:notes:225]

[0000106040-17-000007:notes:230]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the six months ended December 30, 2016:
