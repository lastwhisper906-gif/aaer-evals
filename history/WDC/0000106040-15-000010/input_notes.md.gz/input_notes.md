# WDC notes — 0000106040-15-000010


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000106040-15-000010:notes:1]
Advertising Expense

[0000106040-15-000010:notes:2]
Advertising costs are expensed as incurred. Selling, general and administrative expenses of the Company included advertising costs of $71 million, $60 million and $61 million in 2015, 2014 and 2013, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-15-000010:notes:3]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments classified as available-for-sale as of June 27, 2014 (in millions):

[0000106040-15-000010:notes:4]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |
| U.S. Government agency securities | 88 |  |  | — |  |  | 88 |  |
| Commercial paper | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | 66 |  |  | — |  |  | 66 |  |
| Total | $ | 499 |  |  | $ | — |  |  | $ | 499 |  |

[0000106040-15-000010:notes:5]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments classified as available-for-sale as of July 3, 2015 (in millions):

[0000106040-15-000010:notes:6]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 287 |  |  | $ | — |  |  | $ | 287 |  |
| U.S. Government agency securities | 95 |  |  | — |  |  | 95 |  |
| Commercial paper | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-15-000010:notes:7]
Note 15. Acquisitions

[0000106040-15-000010:notes:8]
The consolidated financial statements include the results of operations of acquired companies commencing after their respective acquisition dates. Disclosed below are those acquisitions which have a significant impact to the Company's consolidated financial statements.

[0000106040-15-000010:notes:9]
Acquisition of Amplidata

[0000106040-15-000010:notes:10]
On March 9, 2015, the Company acquired Amplidata NV (“Amplidata”), a developer of object storage software for public and private cloud data centers. As a result of the acquisition, Amplidata was fully integrated into the Company's HGST subsidiary and became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition is expected to further HGST's strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers.

[0000106040-15-000010:notes:11]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $215 million to goodwill. The values assigned to the acquired assets and liabilities are based on preliminary estimates of fair value available as of the date of this Annual Report on Form 10-K, and may be adjusted during the measurement period of up to 12 months from the date of the acquisition as further information becomes available with any changes in the fair values potentially resulting in adjustments to goodwill. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's consolidated financial statements. In addition, pro forma financial information has not been presented as the acquisition did not have a material impact on the Company’s consolidated financial statements for 2015.

[0000106040-15-000010:notes:12]
The preliminary purchase price allocation for Amplidata is as follows (in millions):

[0000106040-15-000010:notes:13]
|  | March 9,2015 |
| Tangible assets acquired and liabilities assumed | $ | (24 | ) |
| Intangible assets | 76 |  |
| Goodwill | 215 |  |
| Total | $ | 267 |  |

[0000106040-15-000010:notes:14]
Since the date of acquisition, the Company recorded an increase of $42 million to goodwill which primarily related to an adjustment to the value of deferred taxes acquired, an adjustment to the value of intangible assets acquired, and an adjustment for the fair value of stock options assumed in the acquisition of Amplidata. The primary area of the preliminary purchase price allocation that is not yet finalized due to information that may become available subsequently is income taxes. Any changes in the fair value could potentially result in adjustments to goodwill. The Company expects to finalize the purchase price allocation in 2016.

[0000106040-15-000010:notes:15]
The $215 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create HDD storage solutions leveraging the core software acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Amplidata was immaterial to the Company’s consolidated financial statements.

[0000106040-15-000010:notes:16]
Prior to the acquisition date, the Company held a non-controlling interest in Amplidata accounted for under the cost method of accounting.  Upon acquiring the outstanding ownership stake in Amplidata, the Company remeasured its original equity interest to its fair value using the income approach, which utilizes estimates of discounted future cash flows, and recognized a $9 million gain during the year ended July 3, 2015, which was recorded within the employee termination benefits, asset impairments and other charges line item in the consolidated statements of income.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000106040-15-000010:notes:17]
Cash and Cash Equivalents

[0000106040-15-000010:notes:18]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as direct investments in bank acceptances with original maturities when purchased of three months or less. Cash equivalents are carried at cost, which approximates fair value.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-15-000010:notes:19]
The changes in the benefit obligations and plan assets for the Japanese defined benefit pension plans were as follows for 2015, 2014 and 2013 (in millions):

[0000106040-15-000010:notes:20]
|  | 2015 |  | 2014 |  | 2013 |
| Change in benefit obligation: |  |  |  |  |  |
| Benefit obligation at beginning of period | $ | 255 |  |  | $ | 234 |  |  | $ | 286 |  |
| Service cost | 9 |  |  | 10 |  |  | 11 |  |
| Interest cost | 4 |  |  | 4 |  |  | 5 |  |
| Actuarial gain | 16 |  |  | 13 |  |  | (4 | ) |
| Benefits paid | (8 | ) |  | (7 | ) |  | (6 | ) |
| Other(1) | — |  |  | 8 |  |  | — |  |
| Non-U.S. currency movement | (45 | ) |  | (7 | ) |  | (58 | ) |
| Benefit obligation at end of period | 231 |  |  | 255 |  |  | 234 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 191 |  |  | 167 |  |  | 167 |  |
| Actual return on plan assets | 22 |  |  | 15 |  |  | 29 |  |
| Employer contributions | 14 |  |  | 14 |  |  | 15 |  |
| Benefits paid | (8 | ) |  | (7 | ) |  | (6 | ) |
| Other(1) | — |  |  | 7 |  |  | — |  |
| Non-U.S. currency movement | (34 | ) |  | (5 | ) |  | (38 | ) |
| Fair value of plan assets at end of period | 185 |  |  | 191 |  |  | 167 |  |
| Unfunded status at end of year | $ | 46 |  |  | $ | 64 |  |  | $ | 67 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-15-000010:notes:21]
Note 4. Commitments and Contingencies

[0000106040-15-000010:notes:22]
Lease Commitments

[0000106040-15-000010:notes:23]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2025. Rental expense under these operating leases, including month-to-month rentals, was $60 million, $59 million and $64 million in 2015, 2014 and 2013, respectively. Future minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year at July 3, 2015 are as follows (in millions):

[0000106040-15-000010:notes:24]
| 2016 | $ | 40 |  |
| 2017 | 32 |  |
| 2018 | 26 |  |
| 2019 | 23 |  |
| 2020 | 19 |  |
| Thereafter | 45 |  |
| Total future minimum payments | $ | 185 |  |

[0000106040-15-000010:notes:25]
Product Warranty Liability

[0000106040-15-000010:notes:26]
Changes in the warranty accrual for 2015, 2014 and 2013 were as follows (in millions):

[0000106040-15-000010:notes:27]
|  | 2015 |  | 2014 |  | 2013 |
| Warranty accrual, beginning of period | $ | 182 |  |  | $ | 187 |  |  | $ | 260 |  |
| Warranty liabilities assumed as a result of acquisitions | 1 |  |  | 4 |  |  | — |  |
| Charges to operations | 187 |  |  | 170 |  |  | 178 |  |
| Utilization | (190 | ) |  | (207 | ) |  | (221 | ) |
| Changes in estimate related to pre-existing warranties | 41 |  |  | 28 |  |  | (30 | ) |
| Warranty accrual, end of period | $ | 221 |  |  | $ | 182 |  |  | $ | 187 |  |

[0000106040-15-000010:notes:28]
Accrued warranty also includes amounts classified in other liabilities in the consolidated balance sheets of $71 million at July 3, 2015 and $63 million at June 27, 2014.

[0000106040-15-000010:notes:29]
Long-term Purchase Agreements

[0000106040-15-000010:notes:30]
The Company has entered into long-term purchase agreements with various component suppliers. The commitments depend on specific products ordered and may be subject to minimum quality requirements and future price negotiations. The Company expects these commitments to total $117 million for 2016, $15 million for 2017, $5 million for 2018, $3 million for 2019 and no remaining commitments for 2020.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0000106040-15-000010:notes:31]
Note 11. Investments

[0000106040-15-000010:notes:32]
The fair value of the Company’s investments classified as available-for-sale securities at July 3, 2015, by remaining contractual maturity were as follows (in millions):

[0000106040-15-000010:notes:33]
|  | Cost Basis |  | Fair Value |
| Due in less than one year (short-term investments) | $ | 262 |  |  | $ | 262 |  |
| Due in one to five years (included in other non-current assets) | 328 |  |  | 328 |  |
| Total | $ | 590 |  |  | $ | 590 |  |

[0000106040-15-000010:notes:34]
The Company determined no available-for-sale securities were other-than-temporarily impaired in 2015 or 2014.


## us-gaap:DebtDisclosureTextBlock

[0000106040-15-000010:notes:35]
Note 3. Debt

[0000106040-15-000010:notes:36]
Long-term debt consisted of the following as of July 3, 2015 and June 27, 2014 (in millions):

[0000106040-15-000010:notes:37]
|  | July 3, 2015 |  | June 27, 2014 |
| Term loan | $ | 2,312 |  |  | $ | 2,438 |  |
| Less amounts due in one year | (156 | ) |  | (125 | ) |
| Long-term debt | $ | 2,156 |  |  | $ | 2,313 |  |

[0000106040-15-000010:notes:38]
On January 9, 2014, the Company, Western Digital Technologies, Inc. (“WDT”) and Western Digital Ireland, Inc. ("WDI") entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto, which was subsequently amended on February 25, 2015 (as amended, the "Credit Agreement") to add Western Digital International, Ltd. ("WD International") as an additional borrower. The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT, WDI and WD International (each, a "Borrower" and collectively, the “Borrowers”). The revolving credit facility includes a $100 million sublimit for letters of credit and a $50 million sublimit for swing line loans. Subject to certain conditions, a Borrower may elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. The loans under the Credit Agreement have a five-year term. The obligations of the Borrowers under the Credit Agreement are guaranteed by the Company and its material domestic subsidiaries, and the obligations of WDI and WD International under the Credit Agreement are also guaranteed by WDT.

[0000106040-15-000010:notes:39]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of July 3, 2015, the revolving credit facility had a variable interest rate of 1.7% and a remaining outstanding balance of $255 million. The revolving credit facility is classified within current liabilities as of July 3, 2015 due to the Company's intent to repay the borrowings in 2016. As of July 3, 2015, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-15-000010:notes:40]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-15-000010:notes:41]
Note 12. Foreign Exchange Contracts

[0000106040-15-000010:notes:42]
As of July 3, 2015, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $26 million. In addition, as of July 3, 2015, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $4.6 billion and $4.5 billion, and closed $4.8 billion and $4.9 billion, in foreign exchange contracts for the years ended July 3, 2015 and June 27, 2014, respectively. The fair value and balance sheet location of such contracts were as follows (in millions):

[0000106040-15-000010:notes:43]
|  |  | Asset Derivatives |  | Liability Derivatives |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Derivatives Designated asHedging Instruments |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Foreign exchange contracts |  | Other currentassets |  | $ | — |  |  | Other currentassets |  | $ | 7 |  |  | Accruedexpenses |  | $ | 31 |  |  | Accruedexpenses |  | $ | 2 |  |

[0000106040-15-000010:notes:44]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the consolidated balance sheet as of July 3, 2015 (in millions):

[0000106040-15-000010:notes:45]
|  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |
| Financial liabilities | (31 | ) |  | — |  |  | $ | (31 | ) |  | — |  |  | — |  |  | (31 | ) |
| Total derivative instruments | $ | (31 | ) |  | $ | — |  |  | $ | (31 | ) |  | $ | — |  |  | $ | — |  |  | $ | (31 | ) |

[0000106040-15-000010:notes:46]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the consolidated balance sheet as of June 27, 2014 (in millions):

[0000106040-15-000010:notes:47]
|  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 9 |  |  | $ | (2 | ) |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |
| Financial liabilities | (4 | ) |  | 2 |  |  | (2 | ) |  | — |  |  | — |  |  | (2 | ) |
| Total derivative instruments | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |

[0000106040-15-000010:notes:48]
The impact on the consolidated financial statements was as follows (in millions):

[0000106040-15-000010:notes:49]
| Derivatives in Cash Flow Hedging Relationships |  | Amount of Gain(Loss)Recognized inAccumulatedOther Comprehensive Incomeon Derivatives |  | Location of Gain (Loss)Reclassified fromAccumulatedOther Comprehensive Income into Income |  | Amount of Gain (Loss)ReclassifiedfromAccumulatedOther Comprehensive Income intoIncome |
|  | 2015 |  | 2014 |  |  |  | 2015 |  | 2014 |
| Foreign exchange contracts |  | $ | (74 | ) |  | $ | 13 |  |  | Cost of revenue |  | $ | (44 | ) |  | $ | (38 | ) |

[0000106040-15-000010:notes:50]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the consolidated financial statements during 2015, 2014 and 2013. See Notes 1 and 10 above for additional disclosures related to the Company’s foreign exchange contracts.


## us-gaap:DerivativesPolicyTextBlock

[0000106040-15-000010:notes:51]
Foreign Exchange Contracts

[0000106040-15-000010:notes:52]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. The contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for trading purposes. The Company had foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges and had an aggregate notional amount of $1.3 billion and $1.5 billion at July 3, 2015 and June 27, 2014, respectively.

[0000106040-15-000010:notes:53]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss). These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial for all years presented.

[0000106040-15-000010:notes:54]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of operating expenses. All fair value hedges were determined to be effective. The changes in fair value on these contracts were immaterial to the consolidated financial statements for all years presented. See Notes 10 and 12 below.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000106040-15-000010:notes:55]
Income per Common Share

[0000106040-15-000010:notes:56]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include certain dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and restricted stock unit awards (“RSUs”).

[0000106040-15-000010:notes:57]
The following table illustrates the computation of basic and diluted income per common share (in millions, except per share data):

[0000106040-15-000010:notes:58]
|  | Years Ended |
|  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Net income | $ | 1,465 |  |  | $ | 1,617 |  |  | $ | 980 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 232 |  |  | 235 |  |  | 241 |  |
| Employee stock options and other | 5 |  |  | 7 |  |  | 5 |  |
| Diluted | 237 |  |  | 242 |  |  | 246 |  |
| Income per common share: |  |  |  |  |  |
| Basic | $ | 6.31 |  |  | $ | 6.88 |  |  | $ | 4.07 |  |
| Diluted | $ | 6.18 |  |  | $ | 6.68 |  |  | $ | 3.98 |  |
| Anti-dilutive potential common shares excluded* | 1 |  |  | 2 |  |  | 3 |  |

[0000106040-15-000010:notes:59]
_______________

[0000106040-15-000010:notes:60]
| * | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-15-000010:notes:61]
Note 10. Fair Value Measurements

[0000106040-15-000010:notes:62]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-15-000010:notes:63]
Level 1. Quoted prices in active markets for identical assets or liabilities.

[0000106040-15-000010:notes:64]
Level 2. Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-15-000010:notes:65]
Level 3. Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-15-000010:notes:66]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of July 3, 2015, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-15-000010:notes:67]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 135 |  |  | $ | — |  |  | $ | — |  |  | $ | 135 |  |
| Total cash equivalents | 135 |  |  | — |  |  | — |  |  | 135 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| U.S. Government agency securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Commercial paper | — |  |  | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total short-term investments | — |  |  | 262 |  |  | — |  |  | 262 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 237 |  |  | — |  |  | 237 |  |
| U.S. Government agency securities | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Total long-term investments | — |  |  | 328 |  |  | — |  |  | 328 |  |
| Foreign exchange contracts | — |  |  | — |  |  | — |  |  | — |  |
| Total assets at fair value | $ | 135 |  |  | $ | 590 |  |  | $ | — |  |  | $ | 725 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000106040-15-000010:notes:68]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 27, 2014, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-15-000010:notes:69]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents |  |  |  |  |  |  |  |
| Money market funds | $ | 756 |  |  | $ | — |  |  | $ | — |  |  | $ | 756 |  |
| Bank acceptances | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 756 |  |  | 1 |  |  | — |  |  | 757 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Commercial paper | — |  |  | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Total short-term investments | — |  |  | 284 |  |  | — |  |  | 284 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 180 |  |  | — |  |  | 180 |  |
| U.S. Government agency securities | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total long-term investments | — |  |  | 215 |  |  | — |  |  | 215 |  |
| Foreign exchange contracts | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total assets at fair value | $ | 756 |  |  | $ | 507 |  |  | $ | — |  |  | $ | 1,263 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0000106040-15-000010:notes:70]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government Agency securities. Money market funds are valued based on quoted market prices.

[0000106040-15-000010:notes:71]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-15-000010:notes:72]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000010:notes:73]
U.S. Government Agency Securities. The Company’s U.S. Government agency securities are investments in fixed income securities sponsored by the U.S. Government and are held in custody by a third party. U.S. Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000010:notes:74]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government and are held in custody by a third party. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000010:notes:75]
Bank Acceptances. The Company’s bank acceptances are held in custody by a third party. Bank acceptances are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000010:notes:76]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are classified within other current assets and liabilities in the consolidated balance sheets. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the consolidated balance sheets. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company's foreign exchange contracts, see Note 12 below.

[0000106040-15-000010:notes:77]
In 2015 and 2014, there were no transfers between levels. In 2014 the Company sold its auction rate securities, which were Level 3 financial assets measured on a recurring basis, for total proceeds of $17 million and recorded a gain of $3 million within interest and other income in the consolidated statements of income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-15-000010:notes:78]
Note 13. Goodwill and Other Intangible Assets

[0000106040-15-000010:notes:79]
The following table summarizes the activity related to the carrying amount of goodwill:

[0000106040-15-000010:notes:80]
|  |  | Carrying Amount |
| Balance as of June 28, 2013 |  | $ | 1,954 |  |
| Goodwill recorded in connection with acquisitions |  | 605 |  |
| Balance as of June 27, 2014 |  | $ | 2,559 |  |
| Goodwill recorded in connection with acquisitions |  | 207 |  |
| Balance as of July 3, 2015 |  | $ | 2,766 |  |

[0000106040-15-000010:notes:81]
Intangible assets as of July 3, 2015 were as follows:

[0000106040-15-000010:notes:82]
|  |  | Weighted AverageAmortizationPeriod |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  |  | (in years) |  | (in millions) |  | (in millions) |  | (in millions) |
| Existing technology |  | 5 |  |  | $ | 638 |  |  | $ | 471 |  |  | $ | 167 |  |
| Customer relationships |  | 4 |  |  | 152 |  |  | 126 |  |  | 26 |  |
| Other |  | 3 |  |  | 74 |  |  | 68 |  |  | 6 |  |
| Leasehold interests |  | 31 |  |  | 39 |  |  | 11 |  |  | 28 |  |
| In-process research and development |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Total |  |  |  | $ | 1,008 |  |  | $ | 676 |  |  | $ | 332 |  |

[0000106040-15-000010:notes:83]
Intangible assets as of June 27, 2014 were as follows:

[0000106040-15-000010:notes:84]
|  |  | Weighted AverageAmortization Period |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
|  |  | (in years) |  | (in millions) |  | (in millions) |  | (in millions) |
| Existing technology |  | 5 |  |  | $ | 566 |  |  | $ | 368 |  |  | $ | 198 |  |
| Customer relationships |  | 4 |  |  | 148 |  |  | 97 |  |  | 51 |  |
| Other |  | 3 |  |  | 73 |  |  | 55 |  |  | 18 |  |
| Leasehold interests |  | 32 |  |  | 43 |  |  | 10 |  |  | 33 |  |
| In-process research and development |  | — |  |  | 154 |  |  | — |  |  | 154 |  |
| Total |  |  |  | $ | 984 |  |  | $ | 530 |  |  | $ | 454 |  |

[0000106040-15-000010:notes:85]
Other intangible assets are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization expense for intangible assets was $171 million, $213 million and $209 million for 2015, 2014 and 2013, respectively. During 2015 and 2014, the Company recorded $39 million and $53 million of impairment charges related to intangible assets, respectively, which are recorded in the employee termination, asset impairment and other charges within the Company's consolidated statements of income. The impairment charges primarily relate to acquired in-process research and development projects that were abandoned and resulted in full impairment in both 2015 and 2014. As of July 3, 2015, estimated future amortization expense for intangible assets currently subject to amortization is $95 million for 2016, $64 million for 2017, $20 million for 2018, $11 million for 2019 and $10 million for 2020.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000106040-15-000010:notes:86]
Goodwill and Other Long-Lived Assets

[0000106040-15-000010:notes:87]
The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with amounts exceeding the fair values being recognized as goodwill. Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs its annual impairment test as of the first day of its fiscal fourth quarter. The Company either uses qualitative factors to determine whether goodwill is more likely than not impaired or performs a two-step approach to quantify impairment. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, it is required to follow a two-step approach to quantify the impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment for each reporting unit. The Company did not record any impairment of goodwill during 2015, 2014, or 2013.

[0000106040-15-000010:notes:88]
Other intangible assets consist primarily of technology acquired in business combinations and in-process research and development. In-process research and development is not amortized until the point at which it reaches technological feasibility. Instead, it is instead tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. Acquired intangibles are amortized on a straight-line basis over their respective estimated useful lives. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The Company recorded impairments to certain long-lived assets in 2015, 2014 and 2013. See Notes 13 and 17 below.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-15-000010:notes:89]
Note 9. Income Taxes

[0000106040-15-000010:notes:90]
Pre-tax Income

[0000106040-15-000010:notes:91]
The domestic and foreign components of income before income taxes were as follows for the three years ended July 3, 2015 (in millions):

[0000106040-15-000010:notes:92]
|  | 2015 |  | 2014 |  | 2013 |
| Foreign | $ | 1,501 |  |  | $ | 1,664 |  |  | $ | 870 |  |
| Domestic | 76 |  |  | 88 |  |  | 352 |  |
| Income before income taxes | $ | 1,577 |  |  | $ | 1,752 |  |  | $ | 1,222 |  |

[0000106040-15-000010:notes:93]
Income Tax Provision

[0000106040-15-000010:notes:94]
The components of the provision for income taxes were as follows for the three years ended July 3, 2015 (in millions):

[0000106040-15-000010:notes:95]
|  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |
| Foreign | $ | 54 |  |  | $ | 47 |  |  | $ | 57 |  |
| Domestic-federal | 43 |  |  | 98 |  |  | 149 |  |
| Domestic-state | (13 | ) |  | 3 |  |  | 1 |  |
| Deferred: |  |  |  |  |  |
| Foreign | 12 |  |  | (3 | ) |  | (7 | ) |
| Domestic-federal | 11 |  |  | (14 | ) |  | (46 | ) |
| Domestic-state | 5 |  |  | 4 |  |  | 88 |  |
| Income tax provision | $ | 112 |  |  | $ | 135 |  |  | $ | 242 |  |

[0000106040-15-000010:notes:96]
The Company’s income tax provision for 2015 and 2013 reflects tax benefits of $27 million and $37 million, respectively, as a result of the retroactive extensions of the U.S. Federal research and development tax credit that were signed into law on December 19, 2014 and January 2, 2013. In addition, the Company recorded an $88 million charge to reduce its previously recognized California deferred tax assets in 2013 as a result of the enactment of California Proposition 39.

[0000106040-15-000010:notes:97]
Remaining net undistributed earnings from foreign subsidiaries at July 3, 2015 on which no U.S. tax has been provided amounted to $9.4 billion. The net undistributed earnings are intended to finance local operating requirements and capital investments. Accordingly, an additional U.S. tax provision has not been made on these earnings. The tax liability for these earnings would be $3.1 billion if the Company repatriated the $9.4 billion in undistributed earnings from the foreign subsidiaries.

[0000106040-15-000010:notes:98]
Deferred Taxes

[0000106040-15-000010:notes:99]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities as of July 3, 2015 and June 27, 2014 were as follows (in millions):

[0000106040-15-000010:notes:100]
|  | 2015 |  | 2014 |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 50 |  |  | $ | 38 |  |
| Accrued compensation and benefits not currently deductible | 138 |  |  | 190 |  |
| Domestic net operating loss carryforward | 137 |  |  | 130 |  |
| Business credit carryforward | 167 |  |  | 155 |  |
| Long-lived assets | 49 |  |  | 58 |  |
| Other | 65 |  |  | 65 |  |
| Total deferred tax assets | 606 |  |  | 636 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (126 | ) |  | (152 | ) |
| Other | (10 | ) |  | (11 | ) |
| Total deferred tax liabilities | (136 | ) |  | (163 | ) |
| Valuation allowances | (166 | ) |  | (128 | ) |
| Deferred tax assets, net | $ | 304 |  |  | $ | 345 |  |
| Deferred tax assets: |  |  |  |
| Current portion (included in other current assets) | $ | 167 |  |  | $ | 184 |  |
| Non-current portion (included in other non-current assets) | 273 |  |  | 324 |  |
| Total deferred tax assets | 440 |  |  | 508 |  |
| Deferred tax liabilities: |  |  |  |
| Current portion (included in other current assets) | (1 | ) |  | (2 | ) |
| Non-current portion (included in other non-current assets) | (135 | ) |  | (161 | ) |
| Total deferred tax liabilities | (136 | ) |  | (163 | ) |
| Deferred tax assets, net | $ | 304 |  |  | $ | 345 |  |

[0000106040-15-000010:notes:101]
The net deferred tax asset valuation allowance increased by $38 million in 2015 and decreased by $5 million in 2014. The valuation allowance is based on the Company’s assessment that it is more likely than not that certain deferred tax assets will not be realized in the foreseeable future.

[0000106040-15-000010:notes:102]
In addition to the deferred tax assets presented above, the Company had additional NOL benefits related to stock-based compensation deductions of $90 million and $11 million at July 3, 2015 and June 27, 2014, respectively. During 2015, the Company generated an additional $97 million of benefits related to stock-based compensation deductions, of which $19 million were utilized in 2015 and recorded to shareholders' equity.

[0000106040-15-000010:notes:103]
Effective Tax Rate

[0000106040-15-000010:notes:104]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows for the three years ended July 3, 2015:

[0000106040-15-000010:notes:105]
|  | 2015 |  | 2014 |  | 2013 |
| U.S. Federal statutory rate | 35 | % |  | 35 | % |  | 35 | % |
| Tax rate differential on international income | (29 | ) |  | (28 | ) |  | (19 | ) |
| Tax effect of U.S. permanent differences | 1 |  |  | 2 |  |  | — |  |
| State income tax, net of federal tax | — |  |  | — |  |  | 8 |  |
| Income tax credits | (2 | ) |  | (1 | ) |  | (4 | ) |
| Other | 2 |  |  | — |  |  | — |  |
| Effective tax rate | 7 | % |  | 8 | % |  | 20 | % |

[0000106040-15-000010:notes:106]
Tax Holidays and Carryforwards

[0000106040-15-000010:notes:107]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines, Singapore and Thailand operate under various tax holidays and tax incentive programs which will expire in whole or in part at various dates from 2016 through 2025. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was to increase the Company’s net earnings by $641 million ($2.70 per diluted share), $905 million ($3.74 per diluted share), and $899 million ($3.65 per diluted share) in 2015, 2014 and 2013, respectively.

[0000106040-15-000010:notes:108]
As of July 3, 2015, the Company had federal and state NOL carryforwards of $515 million and $422 million, respectively. In addition, as of July 3, 2015, the Company had various federal and state tax credit carryforwards of $417 million combined. The NOL carryforwards available to offset future federal and state taxable income expire at various dates from 2021 to 2035 and 2020 to 2035, respectively. Approximately $100 million of the credit carryforwards available to offset future taxable income expire at various dates from 2017 to 2035. The remaining amount is available indefinitely. NOLs and credits relating to Komag, Incorporated (“Komag”), HGST, sTec, Virident and Amplidata are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company does not expect these limitations to result in a reduction in the total amount of Komag, sTec, Virident or Amplidata's NOLs and credits ultimately realized. The Company expects the total amount of HGST’s NOLs and credits ultimately realized will be reduced by $39 million and $25 million, respectively.

[0000106040-15-000010:notes:109]
Uncertain Tax Positions

[0000106040-15-000010:notes:110]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Company’s balance sheet. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. As of July 3, 2015, such interest and penalties were not material. As of July 3, 2015, the Company had $350 million of unrecognized tax benefits.

[0000106040-15-000010:notes:111]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits for the years ended July 3, 2015, June 27, 2014 and June 28, 2013 (in millions):

[0000106040-15-000010:notes:112]
|  | 2015 |  | 2014 |  | 2013 |
| Unrecognized tax benefit at beginning of period | $ | 300 |  |  | $ | 240 |  |  | $ | 280 |  |
| Gross increases related to current year tax positions | 44 |  |  | 27 |  |  | 29 |  |
| Gross increases related to prior year tax positions | 6 |  |  | 26 |  |  | 10 |  |
| Gross decreases related to prior year tax positions | — |  |  | (5 | ) |  | (8 | ) |
| Settlements | — |  |  | — |  |  | (64 | ) |
| Lapse of statute of limitations | (3 | ) |  | — |  |  | (7 | ) |
| Acquisitions | 3 |  |  | 12 |  |  | — |  |
| Unrecognized tax benefit at end of period | $ | 350 |  |  | $ | 300 |  |  | $ | 240 |  |

[0000106040-15-000010:notes:113]
The Company’s unrecognized tax benefits are primarily included within long-term liabilities in the Company’s consolidated balance sheets. The entire balance of unrecognized tax benefits at July 3, 2015, June 27, 2014 and June 28, 2013, if recognized, would affect the effective tax rate, subject to certain future valuation allowance reversals.

[0000106040-15-000010:notes:114]
The Company files U.S. Federal, U.S. state, and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2008 through 2014. In foreign jurisdictions, with few exceptions, the Company is subject to examination for all years subsequent to fiscal 2008. The Company is no longer subject to examination by the IRS for periods prior to 2008, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period.

[0000106040-15-000010:notes:115]
The IRS previously completed its field examination of the Company's federal income tax returns for fiscal years 2006 and 2007, and the Company and the IRS reached agreement with respect to all matters except on the proposed adjustments to income before income taxes relating to intercompany payable balances. The proposed adjustments relating to intercompany payable balances for fiscal years 2006 and 2007 are addressed in conjunction with the IRS’s examination of the Company's fiscal years 2008 and 2009, which commenced in January 2012. The Company received a Notice of Proposed Adjustment ("NOPA") from the IRS for fiscal year 2009 relating to intercompany payable balances and two NOPAs from the IRS for fiscal years 2008 and 2009 relating to transfer pricing with the Company's foreign subsidiaries. The NOPAs relating to intercompany payable balances and transfer pricing with the Company's foreign subsidiaries propose to increase the Company's U.S. taxable income which would result in additional federal tax expense of approximately $72 million and $723 million, respectively, subject to interest. The Company disagrees with the proposed adjustments, believes that the tax positions are properly supported and will vigorously contest the position taken by the IRS. In January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag, which the Company acquired on September 5, 2007. The IRS examined calendar years 2010 and 2011 of HGST, which was acquired by the Company on March 8, 2012, and completed the examination with no material adjustments.

[0000106040-15-000010:notes:116]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of July 3, 2015, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0000106040-15-000010:notes:117]
Income Taxes

[0000106040-15-000010:notes:118]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized.

[0000106040-15-000010:notes:119]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.


## us-gaap:InventoryPolicyTextBlock

[0000106040-15-000010:notes:120]
Inventories

[0000106040-15-000010:notes:121]
The Company values inventories at the lower of cost (first-in, first out and weighted average methods) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories, while the weighted-average method is used to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by the Company. The Company has determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, precious metals are relieved from inventory based on the weighted-average cost of the inventory at the time the inventory is used in production. The weighted average method of valuing precious metals does not materially differ from the FIFO method. As of July 3, 2015 and June 27, 2014, 96% and 92%, respectively, of the inventory was valued using the FIFO method with the remainder valued using the weighted average method. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-15-000010:notes:122]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.


## us-gaap:InvestmentPolicyTextBlock

[0000106040-15-000010:notes:123]
Investments

[0000106040-15-000010:notes:124]
The Company's investments in U.S. Treasury securities, U.S. Government agency securities, commercial paper and certificates of deposit with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within short-term investments and other non-current assets in the consolidated balance sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of shareholders' equity. Gains and losses on available-for-sale securities are recorded based on the specific identification method. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in total other expense, net in the consolidated statements of income. In addition, realized gains and losses are included in total other expense, net in the consolidated statements of income.

[0000106040-15-000010:notes:125]
In addition, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the consolidated balance sheets and were not material to the consolidated financial statements as of July 3, 2015. They are also periodically analyzed to determine whether or not there are indicators of impairment.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-15-000010:notes:126]
Note 5. Legal Proceedings

[0000106040-15-000010:notes:127]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows.

[0000106040-15-000010:notes:128]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made.

[0000106040-15-000010:notes:129]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company's acquisition of HGST on March 8, 2012 (the "HGST Closing Date"). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-15-000010:notes:130]
Intellectual Property Litigation

[0000106040-15-000010:notes:131]
On June 18, 2008, plaintiff Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. On October 10, 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. A trial in the matter began on July 18, 2011 and concluded on July 26, 2011 with a verdict against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. WD and HGST filed post-trial motions challenging the verdict. On January 17, 2014 and February 11, 2015, the Court denied WD’s and HGST’s post-trial motions. On March 13, 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). On April 16, 2015, Convolve filed a motion for reconsideration of the final judgment. On May 5, 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-15-000010:notes:132]
On March 24, 2014, plaintiff Steven F. Reiber (“Reiber”) filed a complaint in the Eastern District of California against the Company, alleging infringement of U.S. Patent Nos. 7,124,927 and 7,389,905. On September 16, 2014, Reiber filed an amended complaint in the Eastern District of California against the Company alleging infringement of three additional patents-U.S. Patent Nos. 6,935,548, 6,651,864, and 6,354,479.  Reiber alleged that WD products (including HDD heads, head gimbal assemblies, head stack assemblies and SSDs) infringed these patents based on the allegation that the manufacturing of these products involves the use of certain bonding tools (e.g., wire-bonding tips, capillary tips, and flip-chip handling tools) that have electrically “dissipative” properties, and which are used when bonding components, such as leads, wires and flip chips. On June 4, 2015, the parties reached a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows. On July 17, 2015, the Court dismissed the action against the Company with prejudice. The matter is now resolved.

[0000106040-15-000010:notes:133]
Seagate Matter

[0000106040-15-000010:notes:134]
In October 2006, Seagate Technology LLC ("Seagate") brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, on October 8, 2014, the Minnesota Supreme Court upheld the arbitrator’s award. On October 14, 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 2014.  This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0000106040-15-000010:notes:135]
Seagate disputes the method the Company used for calculating post-award interest and contends that the Company owes Seagate approximately $29 million in additional interest.  The Company denies Seagate’s contention and believes it calculated interest properly in accordance with the arbitration award.  On November 12, 2014, the Company filed a motion with the District Court seeking an order declaring that WD has paid to Seagate all amounts due under the arbitration award, including all pre-award and post-award interest, and all costs and disbursements assessed by the Minnesota Court of Appeals and the Minnesota Supreme Court.  On December 23, 2014, Seagate filed a cross-motion seeking entry of judgment in the amount of $29 million, plus daily interest from October 15, 2014 until the date any judgment is paid. Both parties’ motions were fully briefed and, on January 9, 2015, the District Court heard oral argument on both motions. On April 7, 2015, the District Court granted the Company’s motion and declared that all amounts due and owing from the Company to Seagate have been paid, and a corresponding judgment was entered on April 8, 2015. On May 6, 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. The matter has been fully briefed before the Minnesota Court of Appeals but a date for oral argument has not been set. The Company will continue to defend itself vigorously in this matter.

[0000106040-15-000010:notes:136]
Other Matters

[0000106040-15-000010:notes:137]
On December 22, 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary ("WD Germany") before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  The CAB, which was required to issue a settlement proposal within one year of the initiation of the action, failed to do so and requested the parties consent to continue the deadline.  WD Germany declined to provide consent and, on February 1, 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives (collectively, "Covered Products") sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. On May 22, 2014, oral argument on the pleadings occurred.  On January 15, 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 1, 2008 and December 31, 2010. The judgment specifies levy amounts on certain WD products sold from 2008 to 2010 and directs WD Germany to provide applicable sales data to the ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice on February 18 and February 20, 2015. WD intends to defend itself vigorously in this matter.

[0000106040-15-000010:notes:138]
On December 11, 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 1, 2012 to December 31, 2013. WD intends to defend itself vigorously in this matter.

[0000106040-15-000010:notes:139]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows.  It is reasonably possible that the Company may incur losses totaling up to $95 million, including the amounts accrued.

[0000106040-15-000010:notes:140]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties and is therefore not predictable with assurance, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, there can be no assurance with respect to such result, and monetary liability or financial impact to the Company from these other matters could differ materially from those projected.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-15-000010:notes:141]
Note 1. Organization and Summary of Significant Accounting Policies

[0000106040-15-000010:notes:142]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. The Company's product portfolio includes hard disk drives (“HDDs”), solid-state drives ("SSDs"), direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are the Company's principal products and are today’s primary storage medium for the vast majority of digital content, with the use of solid-state storage products growing rapidly. The Company's products are marketed under the HGST, WD and G-Technology brand names.

[0000106040-15-000010:notes:143]
The Company has prepared its consolidated financial statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-15-000010:notes:144]
Fiscal Year

[0000106040-15-000010:notes:145]
The Company has a 53 or 52-week fiscal year. The 2015 fiscal year ended on July 3, 2015 and consisted of 53 weeks. The 2014 and 2013 fiscal years ended on June 27, 2014 and June 28, 2013, respectively, and both consisted of 52 weeks.

[0000106040-15-000010:notes:146]
Basis of Presentation

[0000106040-15-000010:notes:147]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. In fiscal 2015, 2014, and 2013, the accounts for all foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the consolidated financial statements.

[0000106040-15-000010:notes:148]
The Company acquired Amplidata NV ("Amplidata") on March 9, 2015, Virident Systems, Inc. ("Virident") on October 17, 2013, and sTec, Inc. (“sTec”) on September 12, 2013. In connection with the acquisitions, Amplidata, Virident, and sTec became indirect wholly-owned subsidiaries of the Company. The results of operations of Amplidata, Virident, and sTec since the respective dates of acquisition are included in the consolidated financial statements.

[0000106040-15-000010:notes:149]
Fair Value of Financial Instruments

[0000106040-15-000010:notes:150]
The carrying amounts of cash equivalents, accounts receivable, investments, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities or, in the case of investments, these are recorded using appropriate market information. The carrying amount of debt approximates fair value because of its variable interest rate.

[0000106040-15-000010:notes:151]
Concentration of Credit Risk

[0000106040-15-000010:notes:152]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. At July 3, 2015 and June 27, 2014, the Company had two customers that accounted for 30% and 29%, respectively, of the Company's net accounts receivable. At July 3, 2015 and June 27, 2014, the Company had reserves for potential credit losses of $7 million and $11 million, respectively, and net accounts receivable of $1.5 billion and $2.0 billion, respectively.

[0000106040-15-000010:notes:153]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-15-000010:notes:154]
Property, Plant and Equipment

[0000106040-15-000010:notes:155]
The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s equipment is depreciated over periods of two to seven years. Depreciation is computed on a straight-line basis. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-15-000010:notes:156]
Revenue and Accounts Receivable

[0000106040-15-000010:notes:157]
Revenue is recognized when the title and risk of loss have passed to the customer, there is persuasive evidence of an arrangement, delivery has occurred, or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured. The Company establishes provisions against revenue and cost of revenue for estimated sales returns in the same period that the related revenue is recognized based on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-15-000010:notes:158]
In accordance with standard industry practice, the Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions, and the Company provides resellers and original equipment manufacturers ("OEMs") with other sales incentive programs. At the time the Company recognizes revenue to resellers and OEMs, a reduction of revenue is recorded for estimated price protection until the resellers sell such inventory to their customers and the Company also records a reduction of revenue for the other programs in effect. The Company bases these adjustments on several factors including anticipated price decreases during the reseller holding period, reseller’s sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information and customer claim processing. If customer demand for the Company's products or market conditions differ from the Company’s expectations, the Company’s operating results could be materially affected. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. Customer sales incentive and marketing programs are recorded as a reduction of revenue.

[0000106040-15-000010:notes:159]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-15-000010:notes:160]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. The Company sold trade accounts receivable and received cash proceeds of $269 million, $187 million and $148 million during 2015, 2014 and 2013, respectively. The discounts on the sales of trade accounts receivables were not material and were recorded within interest and other expense in the consolidated statements of income.

[0000106040-15-000010:notes:161]
Warranty

[0000106040-15-000010:notes:162]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on hard drive reliability, such as factory test data, historical field return rates, and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected.

[0000106040-15-000010:notes:163]
Litigation and Other Contingencies

[0000106040-15-000010:notes:164]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 5 below.

[0000106040-15-000010:notes:165]
Stock-based Compensation

[0000106040-15-000010:notes:166]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. The Company accounts for stock appreciation rights ("SARs") as liability awards based upon management’s intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. The Company is required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and the results of operations could be materially affected.

[0000106040-15-000010:notes:167]
Other Comprehensive Income (Loss)

[0000106040-15-000010:notes:168]
Other comprehensive income (loss) refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss) is comprised of unrealized gains and losses on foreign exchange contracts, foreign currency translation gains and losses, and actuarial gains and losses related to pensions. The income tax impact on components of other comprehensive income is immaterial for all periods presented.

[0000106040-15-000010:notes:169]
The following table illustrates the changes in the balances of each component of accumulated comprehensive income for 2015, 2014 and 2013:

[0000106040-15-000010:notes:170]
|  | ActuarialPensionGains(Losses) |  | ForeignCurrencyTranslationGains(Losses) |  | UnrealizedGains(Losses)on ForeignExchangeContracts |  | AccumulatedOtherComprehensiveIncome (Loss) |
| Balance at June 29, 2012 | $ | (3 | ) |  | $ | 4 |  |  | $ | (16 | ) |  | $ | (15 | ) |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Amounts reclassified from accumulated other comprehensive income | 14 |  |  | (4 | ) |  | (43 | ) |  | (33 | ) |
| Net current-period other comprehensive income (loss) | 14 |  |  | (4 | ) |  | (30 | ) |  | (20 | ) |
| Balance at June 28, 2013 | $ | 11 |  |  | $ | — |  |  | $ | (46 | ) |  | $ | (35 | ) |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Amounts reclassified from accumulated other comprehensive income | (4 | ) |  | — |  |  | 38 |  |  | 34 |  |
| Net current-period other comprehensive income (loss) | (4 | ) |  | — |  |  | 51 |  |  | 47 |  |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 12 |  |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | (74 | ) |  | (74 | ) |
| Amounts reclassified from accumulated other comprehensive income | (2 | ) |  | — |  |  | 44 |  |  | 42 |  |
| Net current-period other comprehensive income (loss) | (2 | ) |  | — |  |  | (30 | ) |  | (32 | ) |
| Balance at July 3, 2015 | $ | 5 |  |  | $ | — |  |  | $ | (25 | ) |  | $ | (20 | ) |

[0000106040-15-000010:notes:171]
Pensions and Other Postretirement Benefit Plans

[0000106040-15-000010:notes:172]
The Company has defined benefit pension plans and other postretirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and postretirement plans in the consolidated balance sheets, with changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. See Note 14 below.

[0000106040-15-000010:notes:173]
Use of Estimates

[0000106040-15-000010:notes:174]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-15-000010:notes:175]
Recent Accounting Pronouncements

[0000106040-15-000010:notes:176]
In May 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2015-07, “Fair Value Measurement (Topic 820): Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)” ("ASU 2015-07"). This guidance eliminates the requirement to categorize investments within the fair value hierarchy if their fair value is measured using the net asset value ("NAV") per share practical expedient in the FASB’s fair value measurement guidance. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The Company does not expect the adoption of ASU 2015-07 to have a material effect on its consolidated financial statements.

[0000106040-15-000010:notes:177]
In April 2015, the FASB issued ASU 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs" ("ASU 2015-03"). The new standard requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The adoption of ASU 2015-03 will not have a material effect on the Company's consolidated financial statements.

[0000106040-15-000010:notes:178]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification Topic 605, "Revenue Recognition," to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. In July 2015, the FASB approved a one-year deferral of the effective date of this ASU. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.

[0000106040-15-000010:notes:179]
In July 2013, the FASB issued ASU 2013-11, "Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists." The new standard requires the presentation of certain unrecognized tax benefits as reductions to deferred tax assets rather than as liabilities in the consolidated balance sheets when a NOL carryforward, a similar tax loss, or a tax credit carryforward exists. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2013, which for the Company was the first quarter of fiscal 2015. The Company adopted this pronouncement in the first quarter of fiscal 2015, and it did not have a material effect on the Company's consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-15-000010:notes:180]
Note 14. Pensions and Other Post-retirement Benefit Plans

[0000106040-15-000010:notes:181]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans are immaterial to the Company’s consolidated financial statements.

[0000106040-15-000010:notes:182]
Obligations and Funded Status

[0000106040-15-000010:notes:183]
_____________________

[0000106040-15-000010:notes:184]
| (1) | During fiscal 2014 the Japan entity assumed benefit obligations and plan assets from Hitachi. These pension obligations related to former Hitachi employees who were hired into the HGST Japan entity during or soon after the 2012 acquisition of HGST by the Company. |

[0000106040-15-000010:notes:185]
The following table presents the unfunded amounts as recognized on the Company’s consolidated balance sheets as of July 3, 2015 and June 27, 2014 (in millions):

[0000106040-15-000010:notes:186]
|  | 2015 |  | 2014 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 45 |  |  | 63 |  |
| Net amount recognized | $ | 46 |  |  | $ | 64 |  |

[0000106040-15-000010:notes:187]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $231 million at July 3, 2015. As of July 3, 2015, net actuarial gains for the Japanese defined benefit pension plans of $5 million are included in accumulated other comprehensive income (loss) in the consolidated balance sheet. There were no prior service credits for the defined benefit pension plans recognized in accumulated other comprehensive income (loss) in the consolidated balance sheet as of July 3, 2015. The amount expected to be amortized into net periodic benefit cost in fiscal 2016 is immaterial to the consolidated financial statements.

[0000106040-15-000010:notes:188]
Assumptions

[0000106040-15-000010:notes:189]
Weighted-Average Assumptions

[0000106040-15-000010:notes:190]
The weighted-average actuarial assumptions used to determine benefit obligations for the Japanese defined benefit pension plans were as follows for 2015, 2014 and 2013:

[0000106040-15-000010:notes:191]
|  | 2015 |  | 2014 |  | 2013 |
| Discount rate | 1.3 | % |  | 1.6 | % |  | 1.6 | % |
| Rate of compensation increase | 0.9 | % |  | 1.0 | % |  | 0.9 | % |

[0000106040-15-000010:notes:192]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows for 2015, 2014 and 2013:

[0000106040-15-000010:notes:193]
|  | 2015 |  | 2014 |  | 2013 |
| Discount rate | 1.6 | % |  | 1.6 | % |  | 1.8 | % |
| Expected long-term rate of return on plan assets | 3.5 | % |  | 3.5 | % |  | 3.5 | % |
| Rate of compensation increase | 1.0 | % |  | 0.9 | % |  | 1.2 | % |

[0000106040-15-000010:notes:194]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to AA or higher bond ratings that match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-15-000010:notes:195]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. Management’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-15-000010:notes:196]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-15-000010:notes:197]
Plan Assets

[0000106040-15-000010:notes:198]
Investment Policies and Strategies

[0000106040-15-000010:notes:199]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks, and the current economic environment. The target asset allocation is 35% in equity securities, 62% in debt securities and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance, and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset, and the latest economic environment.

[0000106040-15-000010:notes:200]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions, and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts, and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-15-000010:notes:201]
Fair Value Measurements

[0000106040-15-000010:notes:202]
The following table presents the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of July 3, 2015 (in millions):

[0000106040-15-000010:notes:203]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds (1)(2) | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Fixed income: |  |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds (1)(3) | — |  |  | 112 |  |  | — |  |  | 112 |  |
| Cash and short-term investments | 6 |  |  | 2 |  |  | — |  |  | 8 |  |
| Fair value of plan assets | $ | 6 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 185 |  |

[0000106040-15-000010:notes:204]
The following table presents the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 27, 2014 (in millions):

[0000106040-15-000010:notes:205]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds (1)(2) | $ | — |  |  | $ | 69 |  |  | $ | — |  |  | $ | 69 |  |
| Fixed income: |  |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds (1)(3) | — |  |  | 111 |  |  | — |  |  | 111 |  |
| Cash and short-term investments | 8 |  |  | 3 |  |  | — |  |  | 11 |  |
| Fair value of plan assets | $ | 8 |  |  | $ | 183 |  |  | $ | — |  |  | $ | 191 |  |

[0000106040-15-000010:notes:206]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-15-000010:notes:207]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-15-000010:notes:208]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-15-000010:notes:209]
Assets held in defined benefit plans in the Philippines, Taiwan and Thailand were less than $1 million and are not presented in the above tables. There were no significant movements of assets between any level categories in 2015, 2014 or 2013.

[0000106040-15-000010:notes:210]
Fair Value Valuation Techniques

[0000106040-15-000010:notes:211]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the NAV provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-15-000010:notes:212]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-15-000010:notes:213]
Cash includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-15-000010:notes:214]
Cash Flows

[0000106040-15-000010:notes:215]
Contributions

[0000106040-15-000010:notes:216]
The Company’s expected employer contributions for 2016 are $9 million for its Japanese defined benefit pension plans.

[0000106040-15-000010:notes:217]
Estimated Future Benefits Payments

[0000106040-15-000010:notes:218]
Annual benefit payments from the Japanese defined benefit pension plans are estimated to range from $5 million to $9 million annually over the next five years.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-15-000010:notes:219]
Note 18. Quarterly Results of Operations (unaudited)

[0000106040-15-000010:notes:220]
|  | First |  | Second |  | Third |  | Fourth |
| 2015 (1) |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,943 |  |  | $ | 3,888 |  |  | $ | 3,550 |  |  | $ | 3,191 |  |
| Gross profit | 1,149 |  |  | 1,110 |  |  | 1,032 |  |  | 930 |  |
| Operating income | 469 |  |  | 466 |  |  | 421 |  |  | 255 |  |
| Net income | 423 |  |  | 438 |  |  | 384 |  |  | 220 |  |
| Basic income per common share | $ | 1.81 |  |  | $ | 1.88 |  |  | $ | 1.66 |  |  | $ | 0.95 |  |
| Diluted income per common share | $ | 1.76 |  |  | $ | 1.84 |  |  | $ | 1.63 |  |  | $ | 0.94 |  |
| 2014 (2) |  |  |  |  |  |  |  |
| Revenue, net | $ | 3,804 |  |  | $ | 3,972 |  |  | $ | 3,703 |  |  | $ | 3,651 |  |
| Gross profit | 1,099 |  |  | 1,156 |  |  | 1,076 |  |  | 1,029 |  |
| Operating income | 542 |  |  | 478 |  |  | 419 |  |  | 352 |  |
| Net income | 495 |  |  | 430 |  |  | 375 |  |  | 317 |  |
| Basic income per common share | $ | 2.10 |  |  | $ | 1.82 |  |  | $ | 1.60 |  |  | $ | 1.35 |  |
| Diluted income per common share | $ | 2.05 |  |  | $ | 1.77 |  |  | $ | 1.55 |  |  | $ | 1.32 |  |

[0000106040-15-000010:notes:221]
| (1) | The first, second, third, and fourth quarters of 2015 included $9 million, $53 million, $10 million, and $104 million, respectively, of employee termination, asset impairment, and other charges. The first and second quarters of 2015 included $14 million and $1 million, respectively, of charges related to interest on an arbitration award. The second quarter of 2015 included a $37 million gain on flood-related insurance recovery. |

[0000106040-15-000010:notes:222]
| (2) | The first, second, third and fourth quarters of 2014 included $11 million, $23 million, $25 million and $36 million, respectively, of employee termination, asset impairment and other charges. Each of the four quarters of 2014 included $13 million of charges related to interest on an arbitration award. The first quarter of 2014 included a $65 million gain on flood-related insurance recovery. |


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0000106040-15-000010:notes:223]
The following table provides those amounts recorded as liabilities within the Company's consolidated balance sheets:

[0000106040-15-000010:notes:224]
|  | June 28, 2013 |  | Accruals |  | Payments |  | June 27, 2014 |  | Accruals |  | Payments |  | July 3, 2015 |
| Employee termination benefits | $ | 37 |  |  | $ | 27 |  |  | $ | (64 | ) |  | $ | — |  |  | $ | 82 |  |  | $ | (72 | ) |  | $ | 10 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-15-000010:notes:225]
Employee termination, asset impairment and other charges within the Company's consolidated statements of income primarily relate to charges to realign the Company's operations with anticipated market demand and are as follows:

[0000106040-15-000010:notes:226]
|  |  | Years Ended |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Employee termination benefits |  | $ | 82 |  |  | $ | 27 |  |  | $ | 109 |  |
| Impairment of assets |  | 82 |  |  | 62 |  |  | 14 |  |
| Contract termination and other |  | 12 |  |  | 6 |  |  | 15 |  |
| Total |  | $ | 176 |  |  | $ | 95 |  |  | $ | 138 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000106040-15-000010:notes:227]
The following table summarizes the Company’s operations by geographic area for the three years ended July 3, 2015 (in millions):

[0000106040-15-000010:notes:228]
|  | 2015 |  | 2014 |  | 2013 |
| Net revenue(1): |  |  |  |  |  |
| United States | $ | 3,054 |  |  | $ | 3,013 |  |  | $ | 3,403 |  |
| China | 2,726 |  |  | 3,499 |  |  | 4,145 |  |
| Asia | 4,552 |  |  | 4,756 |  |  | 4,129 |  |
| Europe, Middle East and Africa | 3,169 |  |  | 3,117 |  |  | 3,056 |  |
| Other | 1,071 |  |  | 745 |  |  | 618 |  |
| Total | $ | 14,572 |  |  | $ | 15,130 |  |  | $ | 15,351 |  |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,465 |  |  | $ | 2,415 |  |  | $ | 1,517 |  |
| China | 218 |  |  | 279 |  |  | 348 |  |
| Asia | 3,655 |  |  | 4,002 |  |  | 4,434 |  |
| Europe, Middle East and Africa | 326 |  |  | 83 |  |  | 139 |  |
| Total | $ | 6,664 |  |  | $ | 6,779 |  |  | $ | 6,438 |  |

[0000106040-15-000010:notes:229]
| (1) | Net revenue is attributed to geographic regions based on the ship to location of the customer. |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0000106040-15-000010:notes:230]
The following table summarizes information about options outstanding and exercisable under the 2004 Performance Incentive Plan as of July 3, 2015 (in millions, except exercise price):

[0000106040-15-000010:notes:231]
|  | Options Outstanding |  | Options Exercisable |
| Range ofExercise Prices | Numberof Shares |  | Weighted AverageRemainingContractual Life(in years) |  | Weighted AverageExercise Price |  | Numberof Shares |  | Weighted AverageExercise Price |
| $2.99 – $16.85 | 1.1 |  |  | 4.7 |  | $ | 11.03 |  |  | 0.7 |  |  | $ | 10.57 |  |
| $17.52 – $29.60 | 1.3 |  |  | 2.5 |  | 27.51 |  |  | 1.2 |  |  | 27.35 |  |
| $30.06 – $41.75 | 0.5 |  |  | 2.6 |  | 36.56 |  |  | 0.4 |  |  | 35.57 |  |
| $43.11 – $43.11 | 1.4 |  |  | 4.0 |  | 43.11 |  |  | 0.7 |  |  | 43.11 |  |
| $48.01 – $68.49 | 1.1 |  |  | 5.0 |  | 66.27 |  |  | 0.3 |  |  | 65.87 |  |
| $69.29 – $388.77 | 1.4 |  |  | 6.0 |  | 102.96 |  |  | 0.1 |  |  | 148.95 |  |
|  | 6.8 |  |  | 4.3 |  | $ | 50.00 |  |  | 3.4 |  |  | 34.81 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-15-000010:notes:232]
The following table summarizes stock option activity under the 2004 Performance Incentive Plan over the last three fiscal years (in millions, except per share amounts and remaining contractual lives):

[0000106040-15-000010:notes:233]
|  | Numberof Shares |  | Weighted AverageExercise PricePer Share |  | Weighted AverageRemainingContractual Life(in years) |  | AggregateIntrinsicValue |
| Options outstanding at June 29, 2012 | 15.8 |  |  | $ | 21.89 |  |  |  |  |  |
| Granted | 3.4 |  |  | 43.51 |  |  |  |  |  |
| Exercised | (6.8 | ) |  | 18.53 |  |  |  |  |  |
| Forfeited or expired | (0.5 | ) |  | 32.72 |  |  |  |  |  |
| Options outstanding at June 28, 2013 | 11.9 |  |  | $ | 29.47 |  |  |  |  |  |
| Granted | 1.6 |  |  | 68.96 |  |  |  |  |  |
| Assumed | 1.7 |  |  | 38.18 |  |  |  |  |  |
| Exercised | (4.5 | ) |  | 25.22 |  |  |  |  |  |
| Forfeited or expired | (0.6 | ) |  | 67.23 |  |  |  |  |  |
| Options outstanding at June 27, 2014 | 10.1 |  |  | $ | 37.03 |  |  |  |  |  |
| Granted | 1.2 |  |  | 94.10 |  |  |  |  |  |
| Assumed | 0.1 |  |  | 3.49 |  |  |  |  |  |
| Exercised | (4.1 | ) |  | 31.90 |  |  |  |  |  |
| Forfeited or expired | (0.5 | ) |  | 56.41 |  |  |  |  |  |
| Options outstanding at July 3, 2015 | 6.8 |  |  | $ | 50.00 |  |  | 4.3 |  | $ | 242 |  |
| Exercisable at July 3, 2015 | 3.4 |  |  | $ | 34.81 |  |  | 3.2 |  | $ | 161 |  |
| Vested and expected to vest after July 3, 2015 | 6.7 |  |  | $ | 49.45 |  |  | 4.3 |  | $ | 241 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-15-000010:notes:234]
The following table summarizes RSU activity (in millions, except weighted average grant date fair value):

[0000106040-15-000010:notes:235]
|  | Numberof Shares |  | Weighted AverageGrant DateFair Value |
| RSUs outstanding at June 29, 2012 | 3.7 |  |  | $ | 33.19 |  |
| Granted | 1.7 |  |  | 43.14 |  |
| Vested | (1.4 | ) |  | 37.89 |  |
| Forfeited or expired | (0.4 | ) |  | 35.46 |  |
| RSUs outstanding at June 28, 2013 | 3.6 |  |  | $ | 35.82 |  |
| Granted | 1.4 |  |  | 69.08 |  |
| Assumed | 0.2 |  |  | 62.73 |  |
| Vested | (1.3 | ) |  | 33.61 |  |
| Forfeited or expired | (0.2 | ) |  | 47.62 |  |
| RSUs outstanding at June 27, 2014 | 3.7 |  |  | $ | 49.77 |  |
| Granted | 1.3 |  |  | 100.13 |  |
| Vested | (1.7 | ) |  | 42.24 |  |
| Forfeited or expired | (0.3 | ) |  | 67.31 |  |
| RSUs outstanding at July 3, 2015 | 3.0 |  |  | $ | 73.80 |  |
| Expected to vest after July 3, 2015 | 2.9 |  |  | $ | 73.28 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000106040-15-000010:notes:236]
WESTERN DIGITAL CORPORATION

[0000106040-15-000010:notes:237]
SCHEDULE II — CONSOLIDATED VALUATION AND QUALIFYING ACCOUNTS

[0000106040-15-000010:notes:238]
Three years ended July 3, 2015

[0000106040-15-000010:notes:239]
(in millions)

[0000106040-15-000010:notes:240]
|  | Allowance forDoubtfulAccounts |
| Balance at June 29, 2012 | $ | 9 |  |
| Additions charges to operations | 8 |  |
| Deductions | (10 | ) |
| Recovery | 2 |  |
| Balance at June 28, 2013 | $ | 9 |  |
| Additions charged to operations | 3 |  |
| Deductions | (1 | ) |
| Balance at June 27, 2014 | $ | 11 |  |
| Deductions | (4 | ) |
| Balance at July 3, 2015 | $ | 7 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-15-000010:notes:241]
Note 8. Shareholders’ Equity

[0000106040-15-000010:notes:242]
Stock Incentive Plans

[0000106040-15-000010:notes:243]
In addition to awards assumed in connection with acquisitions, the Company maintains the amended and restated 2004 Performance Incentive Plan.

[0000106040-15-000010:notes:244]
The types of awards that may be granted under the 2004 Performance Incentive Plan include stock options, SARs, RSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2004 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2004 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2004 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2004 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards or the exercise of employee stock options and ESPP.

[0000106040-15-000010:notes:245]
As of July 3, 2015, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2004 Performance Incentive Plan was 48.8 million shares. Shares issued in respect of stock options and SARs granted under the 2004 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas shares issued in respect of any other type of award granted through November 7, 2012 under the plan count against the plan’s share limit as 1.35 shares for every one share actually issued in connection with such award. Shares issued in respect of awards, other than options and SARs, granted on or after November 8, 2012 count against the plan’s share limit as 1.72 shares for every one share actually issued in connection with such award. The 2004 Performance Incentive Plan was extended in 2013 and will terminate on August 6, 2022 unless terminated earlier by the Company’s Board of Directors.

[0000106040-15-000010:notes:246]
Employee Stock Purchase Plan

[0000106040-15-000010:notes:247]
The Company maintains an ESPP. Under the ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock on either the first day of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-15-000010:notes:248]
Stock-based Compensation Expense

[0000106040-15-000010:notes:249]
The Company recognized in expense $74 million, $85 million and $88 million for stock-based compensation related to the vesting of options issued by the Company under the 2004 Performance Incentive Plan and the ESPP in 2015, 2014 and 2013, respectively. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $19 million, $22 million and $25 million in 2015, 2014 and 2013, respectively. As of July 3, 2015, total compensation cost related to unvested stock options granted under the 2004 Performance Incentive Plan and ESPP rights issued to employees but not yet recognized was $96 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.0 years.

[0000106040-15-000010:notes:250]
For purposes of this footnote, references to RSUs include performance stock unit awards (“PSUs”). The effect of the PSU activity was immaterial to the consolidated financial statements in 2015, 2014 and 2013. The Company recognized in expense $88 million, $71 million and $52 million related to RSUs granted under the 2004 Performance Incentive Plan that vested during 2015, 2014 and 2013, respectively. The tax benefit realized as a result of the aforementioned expense was $24 million, $18 million and $14 million in 2015, 2014 and 2013, respectively. As of July 3, 2015, the aggregate unamortized fair value of all unvested RSUs granted under the 2004 Performance Incentive Plan was $119 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.3 years.

[0000106040-15-000010:notes:251]
Stock Option Activity

[0000106040-15-000010:notes:252]
If an option has an exercise price that is less than the quoted price of the Company’s common stock at the particular time, the aggregate intrinsic value of that option at that time is calculated based on the difference between the exercise price of the underlying options and the quoted price of the Company’s common stock at that time. As of July 3, 2015, the Company had options outstanding to purchase an aggregate of 5.5 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $242 million at that date. During 2015, 2014 and 2013, the aggregate intrinsic value of options exercised under the 2004 Performance Incentive Plan was $283 million, $247 million and $211 million, respectively, determined as of the date of exercise.

[0000106040-15-000010:notes:253]
RSU Activity

[0000106040-15-000010:notes:254]
The fair value of each RSU is the market price of the Company’s stock on the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of the vesting of the units. The aggregate value of RSUs that became fully-vested during 2015, 2014 and 2013 was $170 million, $89 million and $71 million, respectively, determined as of the vest date. The fair value of the shares underlying the RSU awards at the date of grant or assumption was $125 million, $95 million and $74 million in 2015, 2014 and 2013, respectively. These amounts are being recognized to expense over the corresponding vesting periods.

[0000106040-15-000010:notes:255]
SARs Activity

[0000106040-15-000010:notes:256]
The Company recognized a benefit of $3 million in 2015, and $36 million and $46 million in expense related to adjustments to market value as well as the vesting of SARs in 2014 and 2013, respectively. No tax benefit was realized in 2015 as a result of the aforementioned SARs expense, as compared to tax benefits realized of $7 million and $4 million in 2014 and 2013, respectively. The SARs will be settled in cash upon exercise. The Company had a total liability of $41 million related to SARs included in accrued liabilities as of July 3, 2015 in the consolidated balance sheet.

[0000106040-15-000010:notes:257]
The share-based compensation liability for SARs is recognized for the portion of fair value for which service has been rendered at the reporting date. The share-based liability is remeasured at each reporting date, using a binomial option-pricing model, through the requisite service period. As of July 3, 2015, 0.6 million SARs were outstanding with a weighted average exercise price of $7.92. There were no SARs granted in 2015, 2014 and 2013, and all other SARs activity was immaterial to the consolidated financial statements for the year ended July 3, 2015.

[0000106040-15-000010:notes:258]
Fair Value Disclosure — Binomial Model

[0000106040-15-000010:notes:259]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of highly subjective assumptions. The Company uses historical data to estimate exercise, employee termination, and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. The fair value of stock options granted during the three years ended July 3, 2015 was estimated using the following weighted average assumptions:

[0000106040-15-000010:notes:260]
|  | 2015 |  | 2014 |  | 2013 |
| Suboptimal exercise factor | 2.52 |  | 2.07 |  | 1.90 |
| Range of risk-free interest rates | 0.11% to 2.16% |  | 0.10% to 2.44% |  | 0.14% to 1.96% |
| Range of expected stock price volatility | 0.23 to 0.47 |  | 0.27 to 0.50 |  | 0.36 to 0.53 |
| Weighted average expected volatility | 0.36 |  | 0.43 |  | 0.49 |
| Post-vesting termination rate | 1.25% |  | 3.10% |  | 2.16% |
| Dividend yield | 1.69% |  | 1.58% |  | 2.53% |
| Fair value | $32.19 |  | $24.14 |  | $15.75 |

[0000106040-15-000010:notes:261]
The weighted average expected term of the Company’s stock options granted during 2015, 2014 and 2013 was 5.8 years, 5.0 years and 4.0 years, respectively.

[0000106040-15-000010:notes:262]
Fair Value Disclosure — Black-Scholes-Merton Model

[0000106040-15-000010:notes:263]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are granted on either June 1st or December 1st of each year.

[0000106040-15-000010:notes:264]
The fair values of all ESPP purchase rights granted on or prior to July 3, 2015 have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-15-000010:notes:265]
|  | ESPP |
|  | 2015 |  | 2014 |  | 2013 |
| Option life (in years) | 1.26 |  | 1.24 |  | 1.24 |
| Risk-free interest rate | 0.45% |  | 0.26% |  | 0.23% |
| Stock price volatility | 0.26 |  | 0.31 |  | 0.42 |
| Dividend yield | 2.34% |  | 1.64% |  | 1.61% |
| Fair value | $14.50 |  | $14.62 |  | $10.36 |

[0000106040-15-000010:notes:266]
Stock Repurchase Program

[0000106040-15-000010:notes:267]
The Company's Board of Directors previously authorized $3.0 billion for the repurchase of the Company's common stock. On February 3, 2015, the Company's Board of Directors authorized an additional $2.0 billion for the repurchase of its common stock and approved the extension of its stock repurchase program to February 3, 2020. The Company repurchased 9.6 million shares for a total cost of $970 million during 2015. The remaining amount available to be purchased under the Company’s stock repurchase program as of July 3, 2015 was $2.2 billion. Subsequent to July 3, 2015 and through August 13, 2015, the Company repurchased an additional 0.7 million shares of its common stock for a total cost of $60 million. The Company may continue to repurchase its stock as it deems appropriate. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows and borrowings under the Credit Agreement.

[0000106040-15-000010:notes:268]
Stock Reserved for Issuance

[0000106040-15-000010:notes:269]
The following table summarizes all shares of common stock reserved for issuance at July 3, 2015 (in millions):

[0000106040-15-000010:notes:270]
|  | Numberof Shares |
| Maximum shares issuable in connection with: |  |
| Outstanding awards and shares available for award grants | 16.6 |  |
| ESPP | 4.8 |  |
| Total | 21.4 |  |

[0000106040-15-000010:notes:271]
Dividends to Shareholders

[0000106040-15-000010:notes:272]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In 2015, the Company declared aggregate cash dividends of $1.80 per share of the Company’s common stock, totaling $418 million, of which $302 million was paid during 2015. The Company also paid $94 million of dividends in 2015 related to dividends accrued in 2014. On August 4, 2015, the Company declared a cash dividend of $0.50 per share of its common stock to shareholders of record as of October 2, 2015, which will be paid on October 15, 2015. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-15-000010:notes:273]
Note 2. Supplemental Financial Statement Data

[0000106040-15-000010:notes:274]
|  | July 3, 2015 |  | June 27, 2014 |
|  | (In millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 168 |  |  | $ | 168 |  |
| Work-in-process | 500 |  |  | 493 |  |
| Finished goods | 700 |  |  | 565 |  |
| Total inventories | $ | 1,368 |  |  | $ | 1,226 |  |
| Property, plant and equipment: |  |  |  |
| Land and buildings | $ | 1,441 |  |  | $ | 1,364 |  |
| Machinery and equipment | 6,520 |  |  | 6,109 |  |
| Furniture and fixtures | 71 |  |  | 54 |  |
| Leasehold improvements | 276 |  |  | 254 |  |
| Construction-in-process | 296 |  |  | 342 |  |
| Total property, plant and equipment | 8,604 |  |  | 8,123 |  |
| Accumulated depreciation | (5,639 | ) |  | (4,830 | ) |
| Property, plant and equipment, net | $ | 2,965 |  |  | $ | 3,293 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000106040-15-000010:notes:275]
Note 16. Thailand Flooding

[0000106040-15-000010:notes:276]
In October 2011, severe flooding in Thailand inundated all of the Company’s Thailand manufacturing facilities and submerged certain equipment located there. The Company maintains insurance coverage that provides property and business interruption coverage in the event of losses arising from flooding. As a result, the Company recorded $37 million and $65 million of flood-related insurance recoveries in fiscal 2015 and 2014, respectively.  These flood-related insurance recoveries were included within the selling, general and administrative expenses within the Company's consolidated statements of income. All flood-related claims submitted by the Company to its insurers were closed as of July 3, 2015.


## wdc:BusinessSegmentGeographicInformationAndMajorCustomersTextBlock

[0000106040-15-000010:notes:277]
Note 6. Business Segment, Geographic Information and Major Customers

[0000106040-15-000010:notes:278]
Segment Information

[0000106040-15-000010:notes:279]
The Company is organized into two operating segments that have been aggregated into one reportable operating segment, the hard drive business.

[0000106040-15-000010:notes:280]
Geographic Information

[0000106040-15-000010:notes:281]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following table summarizes the Company’s operations by geographic area for the three years ended July 3, 2015 (in millions):

[0000106040-15-000010:notes:282]
Major Customers

[0000106040-15-000010:notes:283]
For 2015 and 2014, sales to Hewlett Packard Company accounted for 11% of the Company’s net revenue. For 2013, no single customer accounted for 10% or more of the Company’s net revenue. For 2015, 2014, and 2013, sales to the Company’s top ten customers accounted for 44% of the Company’s net revenue.


## wdc:DefinedContributionPlanDisclosureTextBlock

[0000106040-15-000010:notes:284]
Note 7. Western Digital Corporation 401(k) Plan

[0000106040-15-000010:notes:285]
The Company has adopted the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. The Company makes a basic matching contribution on behalf of each participating eligible employee equal to fifty percent (50%) of the eligible participant’s pre-tax contributions for the contribution cycle not to exceed 5% of the eligible participant’s compensation; provided, however, that each eligible participant shall receive a minimum annual basic matching contribution equal to fifty percent (50%) of the first $4,000 of pre-tax contributions for any calendar year. The Plan was amended effective January 1, 2013, to provide for a year-end true-up matching contribution such that participants who save at least 5% of their eligible compensation for the year receive a minimum annual matching contribution equal to 2.5% of eligible compensation (up to Internal Revenue Service (“IRS”) limitations). Company contributions vest over a 5-year period of employment. For 2015, 2014, and 2013, the Company made Plan contributions of $22 million, $21 million and $19 million, respectively.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-15-000010:notes:286]
Note 17. Employee Termination, Asset Impairment and Other Charges

[0000106040-15-000010:notes:287]
In 2015 and 2014, the impairment charges primarily relate to equipment and in-process research and development projects that were abandoned and resulted in full impairment.
