# WDC MD&A — 0000106040-15-000010


## mdna

[0000106040-15-000010:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-15-000010:mdna:2]
Forward-Looking Statements

[0000106040-15-000010:mdna:3]
Our Company

[0000106040-15-000010:mdna:4]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes HDDs, SSDs, direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for the vast majority of digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.

[0000106040-15-000010:mdna:5]
Acquisitions

[0000106040-15-000010:mdna:6]
Acquisition of Amplidata

[0000106040-15-000010:mdna:7]
On March 9, 2015, we acquired Amplidata, a developer of object storage software for public and private cloud data centers. The purchase price of the acquisition was approximately $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition is expected to further HGST's strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers. The acquisition of Amplidata did not have a material impact on our consolidated financial statements for fiscal 2015.

[0000106040-15-000010:mdna:8]
Acquisition of Virident

[0000106040-15-000010:mdna:9]
On October 17, 2013, we acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. Virident was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash and $15 million related to the fair value of stock options assumed. The acquisition furthered HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures.

[0000106040-15-000010:mdna:10]
Acquisition of sTec

[0000106040-15-000010:mdna:11]
On September 12, 2013, we acquired sTec, a provider of enterprise SSDs. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash and $11 million related to the fair value of stock options and restricted stock units ("RSUs") assumed.  The acquisition augmented HGST's existing solid-state storage capabilities.

[0000106040-15-000010:mdna:12]
For additional information on our acquisitions, see Part II, Item 8, Note 15 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:13]
Results of Operations

[0000106040-15-000010:mdna:14]
Fiscal 2015 Overview

[0000106040-15-000010:mdna:15]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for Amplidata, Virident, and sTec, which were acquired on March 9, 2015, October 17, 2013, and September 12, 2013, respectively, are included in our operating results only after the respective dates of acquisition.

[0000106040-15-000010:mdna:16]
The following is a summary of our financial performance for fiscal 2015:

[0000106040-15-000010:mdna:17]
| • | In 2015, our net revenue decreased by 4% to $14.6 billion on HDD shipments of 229 million units as compared to $15 billion on shipments of 249 million units in 2014. |

[0000106040-15-000010:mdna:18]
| • | Net revenue derived from enterprise SSDs was $811 million in 2015 as compared to $508 million in 2014. |

[0000106040-15-000010:mdna:19]
| • | HDD ASPs increased to $60 in 2015 from $58 in 2014. |

[0000106040-15-000010:mdna:20]
| • | Gross profit as a percentage of net revenue increased to 29.0% in 2015 from 28.8% in 2014. |

[0000106040-15-000010:mdna:21]
| • | Operating income decreased from $1.8 billion in 2014 to $1.6 billion in 2015. |

[0000106040-15-000010:mdna:22]
| • | Operating income in 2015 included $176 million of employee termination, asset impairment and other charges and $15 million of charges related to an arbitration award as compared to $95 million and $52 million, respectively, in 2014. |

[0000106040-15-000010:mdna:23]
| • | Net income in 2015 was $1.5 billion, or $6.18 per diluted share, compared to $1.6 billion, or $6.68 per diluted share, in 2014. |

[0000106040-15-000010:mdna:24]
39

[0000106040-15-000010:mdna:25]
Summary Comparison of 2015, 2014 and 2013

[0000106040-15-000010:mdna:26]
The following table sets forth, for the periods presented, selected summary information from our consolidated statements of income by dollars and percentage of net revenue (in millions, except percentages):

[0000106040-15-000010:mdna:27]
|  |  | Years Ended |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue |  | $ | 14,572 |  |  | 100.0 | % |  | $ | 15,130 |  |  | 100.0 | % |  | $ | 15,351 |  |  | 100.0 | % |
| Gross profit |  | 4,221 |  |  | 29.0 |  |  | 4,360 |  |  | 28.8 |  |  | 4,363 |  |  | 28.4 |  |
| Research and development |  | 1,646 |  |  | 11.3 |  |  | 1,661 |  |  | 11.0 |  |  | 1,572 |  |  | 10.2 |  |
| Selling, general and administrative |  | 773 |  |  | 5.3 |  |  | 761 |  |  | 5.0 |  |  | 706 |  |  | 4.6 |  |
| Charges related to arbitration award |  | 15 |  |  | 0.1 |  |  | 52 |  |  | 0.3 |  |  | 681 |  |  | 4.4 |  |
| Employee termination, asset impairment and other charges |  | 176 |  |  | 1.2 |  |  | 95 |  |  | 0.6 |  |  | 138 |  |  | 0.9 |  |
| Operating income |  | 1,611 |  |  | 11.1 |  |  | 1,791 |  |  | 11.8 |  |  | 1,266 |  |  | 8.2 |  |
| Other expense, net |  | (34 | ) |  | (0.2 | ) |  | (39 | ) |  | (0.3 | ) |  | (44 | ) |  | (0.3 | ) |
| Income before income taxes |  | 1,577 |  |  | 10.8 |  |  | 1,752 |  |  | 11.6 |  |  | 1,222 |  |  | 8.0 |  |
| Income tax provision |  | 112 |  |  | 0.8 |  |  | 135 |  |  | 0.9 |  |  | 242 |  |  | 1.6 |  |
| Net income |  | 1,465 |  |  | 10.1 |  |  | 1,617 |  |  | 10.7 |  |  | 980 |  |  | 6.4 |  |

[0000106040-15-000010:mdna:28]
The following table sets forth, for the periods presented, summary information regarding unit shipments, ASPs and net revenues by geography and channel (in millions, except percentages and ASPs):

[0000106040-15-000010:mdna:29]
|  |  | Years Ended |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue |  | $ | 14,572 |  |  | $ | 15,130 |  |  | $ | 15,351 |  |
| ASPs (per unit)* |  | $ | 60 |  |  | $ | 58 |  |  | $ | 61 |  |
| Revenues by Geography (%) |  |  |  |  |  |  |
| Americas |  | 28 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa |  | 22 |  |  | 21 |  |  | 20 |  |
| Asia |  | 50 |  |  | 54 |  |  | 54 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |
| Original Equipment Manufacturers ("OEM") |  | 64 | % |  | 63 | % |  | 63 | % |
| Distributors |  | 23 |  |  | 24 |  |  | 24 |  |
| Retailers |  | 13 |  |  | 13 |  |  | 13 |  |
| Unit Shipments* |  |  |  |  |  |  |
| PC |  | 136 |  |  | 157 |  |  | 162 |  |
| Non-PC |  | 93 |  |  | 92 |  |  | 80 |  |
| Total units shipped |  | 229 |  |  | 249 |  |  | 242 |  |

[0000106040-15-000010:mdna:30]
_______________

[0000106040-15-000010:mdna:31]
| * | Based on sales of HDD units only. |

[0000106040-15-000010:mdna:32]
Fiscal Year 2015 Compared to Fiscal Year 2014

[0000106040-15-000010:mdna:33]
Net Revenue. Net revenue was $14.6 billion for 2015, a decrease of 4% from 2014. The decrease was primarily due to a 8% decline in total HDD shipments, partially offset by an increase in ASPs. Total HDD shipments in 2015 decreased to 229 million units as compared to 249 million units for the prior year primarily due to a decrease in client PC demand. ASPs were $60 for 2015, an increase of $2 from 2014, primarily due to a change in product mix.

[0000106040-15-000010:mdna:34]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-15-000010:mdna:35]
40

[0000106040-15-000010:mdna:36]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2015 and 2014, these programs represented 10% and 8% of gross revenues, respectively. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of products.

[0000106040-15-000010:mdna:37]
Gross Profit. Gross profit for 2015 was $4.2 billion, a decrease of $139 million from the prior year. The decrease was primarily due to lower volume. Gross profit as a percentage of net revenue remained relatively flat at 29.0% in 2015 as compared to 28.8% in 2014.

[0000106040-15-000010:mdna:38]
Operating Expenses.

[0000106040-15-000010:mdna:39]
Research and development ("R&D") expense was $1.6 billion in 2015, a decrease of $15 million, or 1%, over the prior year. This slight decrease was primarily due to lower incentive compensation, partially offset by an additional week in fiscal 2015 and additional expenses related to our acquisitions.

[0000106040-15-000010:mdna:40]
Selling, general and administrative ("SG&A") expense was $773 million in 2015, an increase of $12 million, or 2%, as compared to 2014. Adjusting for a $37 million flood-related insurance recovery in 2015 compared to a $65 million flood-related insurance recovery in 2014, SG&A expense decreased $16 million, or 2% compared to 2014. This slight decrease was primarily due to lower incentive compensation, partially offset by an additional week in fiscal 2015 and additional expenses related to our acquisitions.

[0000106040-15-000010:mdna:41]
During 2015 and 2014, we recorded $15 million and $52 million, respectively, for charges related to the Seagate matter. For further details see, Part II, Item 8, Note 5 of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:42]
During 2015, we recorded $176 million of employee termination, asset impairment and other charges. These charges consisted of $82 million of employee termination costs, $82 million of asset impairment charges and $12 million of contract termination and other charges. During 2014, we recorded $95 million of employee termination, asset impairment and other charges. These charges consisted of $27 million of employee termination costs, $62 million of asset impairment charges and $6 million of contract termination and other charges.

[0000106040-15-000010:mdna:43]
Other Expense, net. Other expense, net was $34 million in 2015 compared to $39 million in 2014. Interest and other income decreased to $15 million in 2015 from $17 million in 2014, primarily due a $3 million gain on the sale of our auction-rate securities in 2014. Interest and other expense decreased to $49 million in 2015, from $56 million in 2014, primarily due to a $4 million write-off of debt issuance costs in 2014.

[0000106040-15-000010:mdna:44]
Income Tax Provision. Income tax expense was $112 million in 2015 as compared to $135 million in 2014. Tax expense as a percentage of income before taxes was 7.1% in 2015 compared to 7.7% in 2014. Our income tax provision for 2015 reflects a tax benefit of $27 million as a result of the retroactive extension of the U.S. Federal research and development tax credit (the "R&D credit") that was signed into law on December 19, 2014. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-15-000010:mdna:45]
As of July 3, 2015, we had a recorded liability for unrecognized tax benefits of $350 million. We recognized a net increase of $50 million in our liability for unrecognized tax benefits during 2015. Interest and penalties recognized on such amounts were not material.

[0000106040-15-000010:mdna:46]
The Internal Revenue Service (“IRS”) previously completed its field examination of our federal income tax returns for fiscal years 2006 and 2007, and we and the IRS reached agreement with respect to all matters except on the proposed adjustments to income before income taxes relating to intercompany payable balances. The proposed adjustments relating to intercompany payable balances for fiscal years 2006 and 2007 are addressed in conjunction with the IRS’s examination of our fiscal years 2008 and 2009, which commenced in January 2012. We received a Notice of Proposed Adjustment ("NOPA") from the IRS for fiscal year 2009 relating to intercompany payable balances and two NOPAs from the IRS for fiscal years 2008 and 2009 relating to transfer pricing with our foreign subsidiaries. The NOPAs relating to intercompany payable balances and transfer pricing with our foreign subsidiaries propose to increase our U.S. taxable income, which would result in additional federal tax expense of approximately $72 million and $723 million, respectively, subject to interest. We disagree with the proposed adjustments, believe that the tax positions are properly supported and will vigorously contest the position taken by the IRS. In January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag, Incorporated, which we acquired on September 5, 2007. The IRS examined calendar years 2010 and 2011 of HGST, which was acquired by us on March 8, 2012, and completed the examination with no material adjustments.

[0000106040-15-000010:mdna:47]
41

[0000106040-15-000010:mdna:48]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in our tax examinations are resolved in a manner not consistent with management's expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of July 3, 2015, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-15-000010:mdna:49]
Fiscal Year 2014 Compared to Fiscal Year 2013

[0000106040-15-000010:mdna:50]
Net Revenue. Net revenue was $15.1 billion for 2014, a decrease of 1% from 2013. ASPs were $58 for 2014, a decrease of $3 from 2013. These decreases were primarily due to modest price declines and a change in product mix, partially offset by an increase in unit shipments. Total hard drive shipments in 2014 increased to 249 million units as compared to 242 million units for the prior year primarily due to strength in our CE solutions, including gaming consoles.

[0000106040-15-000010:mdna:51]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-15-000010:mdna:52]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For each of 2014 and 2013, these programs represented 8% of gross revenues. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product.

[0000106040-15-000010:mdna:53]
Gross Profit. Gross profit for 2014 was $4.4 billion, a decrease of $3 million from the prior year. Gross profit as a percentage of net revenue increased to 28.8% in 2014 as compared to 28.4% in 2013. The increase in gross profit as a percentage of net revenue was primarily driven by higher volumes in 2014 as compared to 2013 as well as a continued focus on operational excellence.

[0000106040-15-000010:mdna:54]
Operating Expenses.

[0000106040-15-000010:mdna:55]
R&D expense was $1.7 billion in 2014, an increase of $89 million, or 6%, over the prior year. This increase was primarily due to the inclusion of Virident and sTec's R&D expenses from the dates of acquisition and the continued investment in product development. As a percentage of net revenue, R&D expense increased to 11.0% in 2014 compared to 10.2% in 2013.

[0000106040-15-000010:mdna:56]
SG&A expense was $761 million in 2014, an increase of $55 million, or 8%, as compared to 2013. This increase in SG&A expense was primarily due to the inclusion of Virident and sTec's SG&A expenses from the dates of acquisition and the expansion of sales and marketing to support new products and growing markets, partially offset by a $65 million gain on flood-related insurance recovery. SG&A expense as a percentage of net revenue increased to 5.0% in 2014 compared to 4.6% in 2013.

[0000106040-15-000010:mdna:57]
During 2014 and 2013, we recorded $52 million and $681 million, respectively, for charges related to the Seagate matter. For further detail see, Part II, Item 8, Note 5 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:58]
During 2014, we recorded $95 million of employee termination, asset impairment and other charges. These charges consisted of $27 million of employee termination costs, $62 million of asset impairment charges and $6 million of other charges. During 2013, we recorded $138 million of employee termination, asset impairment and other charges. These charges consisted of $109 million of employee termination costs, $14 million of asset impairment charges and $15 million of other charges.

[0000106040-15-000010:mdna:59]
Other Expense, net. Other expense, net was $39 million in 2014 compared to $44 million in 2013. Interest and other income increased from $11 million in 2013 to $17 million in 2014 primarily due to a $3 million gain on the sale of our auction-rate securities in 2014 and a higher average daily invested cash balance for the period. Interest and other expense increased from $55 million in 2013 to $56 million in 2014, primarily due to a $4 million write-off of debt issuance costs associated with lenders that extinguished or reduced their participation in our new credit agreement, offset by lower variable interest rates on our average debt balance in 2014.

[0000106040-15-000010:mdna:60]
Income Tax Provision. Income tax expense was $135 million in 2014 as compared to $242 million in 2013. Tax expense as a percentage of income before taxes was 7.7% in 2014 compared to 19.8% in 2013. We recorded an $88 million charge to reduce our previously recognized California deferred tax assets in fiscal 2013 as a result of the enactment of California Proposition 39. California Proposition 39, which was approved by California voters on November 6, 2012, affects California state income tax apportionment for most multi-state taxpayers for tax years beginning on or after January 1, 2013.

[0000106040-15-000010:mdna:61]
42

[0000106040-15-000010:mdna:62]
This proposition reduces our future income apportioned to California, making it less likely for us to realize certain California deferred tax assets. In addition, our income tax provision for 2013 also reflects a tax benefit of $37 million as a result of the retroactive extension of the R&D credit. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013 as part of the American Taxpayer Relief Act of 2012. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-15-000010:mdna:63]
As of June 27, 2014, we had a recorded liability for unrecognized tax benefits of $300 million. We recognized a net increase of $60 million in our liability for unrecognized tax benefits during 2014. Interest and penalties recognized on such amounts were not material.

[0000106040-15-000010:mdna:64]
Liquidity and Capital Resources

[0000106040-15-000010:mdna:65]
We ended 2015 with total cash and cash equivalents of $5.0 billion, an increase of $220 million from June 27, 2014. The following table summarizes our statements of cash flows for the three years ended July 3, 2015 (in millions):

[0000106040-15-000010:mdna:66]
|  |  | Years Ended |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Net cash flow provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 2,242 |  |  | $ | 2,816 |  |  | $ | 3,119 |  |
| Investing activities |  | (953 | ) |  | (1,936 | ) |  | (970 | ) |
| Financing activities |  | (1,069 | ) |  | (385 | ) |  | (1,048 | ) |
| Net increase in cash and cash equivalents |  | $ | 220 |  |  | $ | 495 |  |  | $ | 1,101 |  |

[0000106040-15-000010:mdna:67]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, stock repurchase and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:68]
A total of $4.3 billion and $3.5 billion of our cash and cash equivalents were held outside of the United States at July 3, 2015 and June 27, 2014, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. As described in Part II, Item 8, Note 5 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, we paid $773 million to Seagate in 2015 from one of our foreign subsidiaries using cash and cash equivalents held outside of the United States. Our Board of Directors previously approved a capital allocation plan that includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-15-000010:mdna:69]
Operating Activities

[0000106040-15-000010:mdna:70]
Net cash provided by operating activities was $2.2 billion in 2015 as compared to $2.8 billion and $3.1 billion in 2014 and 2013, respectively. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used in working capital changes was $593 million for 2015 as compared to net cash used in working capital changes of $234 million in 2014 and net cash provided by working capital changes of $715 million for 2013.

[0000106040-15-000010:mdna:71]
Our working capital requirements primarily depend on the effective management of our cash conversion cycle, which measures how quickly we can convert our products into cash through sales. The cash conversion cycles for the three years ended 2015 were as follows:

[0000106040-15-000010:mdna:72]
43

[0000106040-15-000010:mdna:73]
|  |  | Years Ended |
|  |  | July 3, 2015 |  | June 27, 2014 |  | June 28, 2013 |
| Days sales outstanding |  | 39 |  |  | 48 |  |  | 43 |  |
| Days in inventory |  | 49 |  |  | 41 |  |  | 39 |  |
| Days payables outstanding |  | (67 | ) |  | (67 | ) |  | (66 | ) |
| Cash conversion cycle |  | 21 |  |  | 22 |  |  | 16 |  |

[0000106040-15-000010:mdna:74]
In 2015, our days sales outstanding (“DSOs”) decreased by 9 days, days in inventory (“DIOs”) increased by 8 days, and days payables outstanding (“DPOs”) remained flat compared to 2014. Changes in DSOs are generally related to the linearity of shipments. For 2015, the decrease in DSOs was due to both the linearity of shipments and the sale of trade receivables in connection with our factoring agreement. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-15-000010:mdna:75]
Investing Activities

[0000106040-15-000010:mdna:76]
Net cash used in investing activities in 2015 was $1.0 billion as compared to $1.9 billion for 2014 and $1.0 billion for 2013. During 2015, cash used in investing activities consisted primarily of $257 million related to acquisitions, net of cash acquired, $612 million of capital expenditures, $857 million related to the purchase of investments, offset by $5 million of other investing activities, net, and $768 million of proceeds from the sales and maturities of investments. In 2014, cash used in investing activities consisted primarily of $823 million related to acquisitions, net of cash acquired, $628 million of capital expenditures, $561 million related to the purchase of investments, offset by $4 million of other investing activities, net, and $72 million of proceeds from the sales and maturities of investments.

[0000106040-15-000010:mdna:77]
Our cash equivalents are invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government Agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. Government Agency securities, commercial paper and certificates of deposit.

[0000106040-15-000010:mdna:78]
Financing Activities

[0000106040-15-000010:mdna:79]
Net cash used in financing activities was $1.1 billion in 2015 as compared to $385 million and $1.0 billion for 2014 and 2013, respectively. Net cash used in financing activities in 2015 consisted of $125 million to repay debt, $970 million to repurchase shares of our common stock and $396 million to pay dividends on our common stock, offset by $255 million of proceeds related to our revolving credit facility and net $167 million provided by employee stock plans. Net cash used in financing activities in 2014 consisted of $2.5 billion of proceeds related to our term loan facility, net of issuance costs, $500 million of debt proceeds related to our revolving credit facility and a net $215 million provided by employee stock plans, offset by $2.5 billion used to repay our term loan facility, as well as $816 million used to repurchase shares of our common stock and $259 million used to pay dividends on our common stock.

[0000106040-15-000010:mdna:80]
Off-Balance Sheet Arrangements

[0000106040-15-000010:mdna:81]
Other than facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the consolidated financial statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities.

[0000106040-15-000010:mdna:82]
Contractual Obligations and Commitments

[0000106040-15-000010:mdna:83]
The following is a summary of our known contractual cash obligations and commercial commitments as of July 3, 2015 (in millions):

[0000106040-15-000010:mdna:84]
|  |  | Total |  | Less than1 Year |  | 1-3 Years |  | 3-5 Years |  | More than5 Years |
| Revolving credit facility* |  | $ | 255 |  |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Long-term debt, including current portion* |  | $ | 2,312 |  |  | $ | 156 |  |  | $ | 469 |  |  | $ | 1,687 |  |  | $ | — |  |
| Operating leases |  | 185 |  |  | 40 |  |  | 58 |  |  | 42 |  |  | 45 |  |
| Purchase obligations |  | 2,844 |  |  | 2,809 |  |  | 28 |  |  | 6 |  |  | 1 |  |
| Total |  | $ | 5,596 |  |  | $ | 3,260 |  |  | $ | 555 |  |  | $ | 1,735 |  |  | $ | 46 |  |

[0000106040-15-000010:mdna:85]
_______________

[0000106040-15-000010:mdna:86]
| * | Included within our consolidated balance sheet |

[0000106040-15-000010:mdna:87]
Debt

[0000106040-15-000010:mdna:88]
As of July 3, 2015, we had $255 million outstanding on our revolving credit facility and $2.3 billion outstanding on our term loan facility. The revolving credit facility is classified within current liabilities on our consolidated balance sheet as of July 3, 2015 due to our intent to repay the borrowings in 2016.  We are required to make quarterly principal payments on the term loan facility totaling $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. As of July 3, 2015, we were in compliance with all covenants under our credit agreement. For additional information, see Part II, Item 8, Note 3 in the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:89]
Purchase Orders

[0000106040-15-000010:mdna:90]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into purchase orders with suppliers for capital equipment that are recorded as a liability upon receipt of the equipment. Our ability to change or cancel a capital equipment purchase order without penalty depends on the nature of the equipment being ordered. In some cases, we may be obligated to pay for certain costs related to changes to, or cancellation of, a purchase order, such as costs incurred for raw materials or work in process of components or capital equipment.

[0000106040-15-000010:mdna:91]
We have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. The estimated related minimum purchase requirements are included in “Purchase obligations” in the table above. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-15-000010:mdna:92]
We enter into, from time to time, other long-term purchase agreements for components with certain vendors. Generally, future purchases under these agreements are not fixed and determinable as they depend on our overall unit volume requirements and are contingent upon the prices, technology and quality of the supplier’s products remaining competitive. These arrangements are not included under “Purchase obligations” in the table above. Please see Part I, Item 1A of this Annual Report on Form 10-K for a discussion of risks related to commitments.

[0000106040-15-000010:mdna:93]
Foreign Exchange Contracts

[0000106040-15-000010:mdna:94]
We purchase short-term, foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. See Part II, Item 7A, under the heading “Disclosure About Foreign Currency Risk,” for a description of our current foreign exchange contract commitments and Part II, Item 8, Notes 1 and 12 of the Notes to Consolidated Financial Statements, included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:95]
45

[0000106040-15-000010:mdna:96]
Indemnifications

[0000106040-15-000010:mdna:97]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-15-000010:mdna:98]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-15-000010:mdna:99]
Unrecognized Tax Benefits

[0000106040-15-000010:mdna:100]
As of July 3, 2015, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $350 million, of which $291 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-15-000010:mdna:101]
See Part II, Item 8, Note 9 in the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-15-000010:mdna:102]
Stock Repurchase Program

[0000106040-15-000010:mdna:103]
Our Board of Directors previously authorized $3.0 billion for the repurchase of our common stock. On February 3, 2015, our Board of Directors authorized an additional $2.0 billion for the repurchase of our common stock and approved the extension of our stock repurchase program to February 3, 2020. We repurchased 9.6 million shares of our common stock for a total cost of $970 million in 2015. The remaining amount available to be purchased under our stock repurchase program as of July 3, 2015 was $2.2 billion. Subsequent to July 3, 2015 and through August 13, 2015, we repurchased an additional 0.7 million shares of our common stock for a total cost of $60 million. We may continue to repurchase our common stock as we deem appropriate. Repurchases under our stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows and borrowings under our credit agreement.

[0000106040-15-000010:mdna:104]
Cash Dividend Policy

[0000106040-15-000010:mdna:105]
On September 13, 2012, we announced that our Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of our common stock receive dividends when and as declared by our Board of Directors. In 2015, we declared aggregate cash dividends of $1.80 per share of our common stock, totaling $418 million, of which $302 million was paid during 2015. We also paid $94 million of dividends in 2015 related to dividends accrued in 2014. On August 4, 2015, we declared a cash dividend of $0.50 per share of our common stock to shareholders of record as of October 2, 2015, which will be paid on October 15, 2015. We may modify, suspend or cancel our cash dividend policy in any manner and at any time. See Part II, Item 5 included in this Annual Report on Form 10-K for further information.

[0000106040-15-000010:mdna:106]
Critical Accounting Policies and Estimates

[0000106040-15-000010:mdna:107]
We have prepared the accompanying consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to the consolidated financial statements may be material.

[0000106040-15-000010:mdna:108]
46

[0000106040-15-000010:mdna:109]
Revenue and Accounts Receivable

[0000106040-15-000010:mdna:110]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions, and we provide resellers and OEMs with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information and customer claim processing. If customer demand for hard drives or market conditions differs from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Generally, total sales incentive and marketing programs range from 7% to 11% of gross revenues per quarter. For 2015, sales incentive and marketing programs were 10% of gross revenues. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.7% of quarterly gross revenue since the first quarter of fiscal 2013. Customer sales incentive and marketing programs are recorded as a reduction of revenue.

[0000106040-15-000010:mdna:111]
We record an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, we routinely analyze the different receivable aging categories and establish reserves based on a combination of past due receivables and expected future losses based primarily on our historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if our overall loss history changes significantly, an adjustment in our allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-15-000010:mdna:112]
We establish provisions against revenue and cost of revenue for sales returns in the same period that the related revenue is recognized. We base these provisions on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-15-000010:mdna:113]
Warranty

[0000106040-15-000010:mdna:114]
We record an accrual for estimated warranty costs when revenue is recognized. We generally warrant our products for a period of one to five years. Our warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. We use a statistical warranty tracking model to help prepare our estimates and assist us in exercising judgment in determining the underlying estimates. Our statistical tracking model captures specific detail on hard drive reliability, such as factory test data, historical field return rates, and costs to repair by product type. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base our warranty estimates. We review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from our estimates, our future results of operations could be materially affected. For a summary of historical changes in estimates related to pre-existing warranty provisions, refer to Part II, Item 8, Note 4 of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:115]
Inventories

[0000106040-15-000010:mdna:116]
We value inventories at the lower of cost (first-in, first-out and weighted average methods) or net realizable value. We use the first-in, first-out (“FIFO”) method to value the cost of the majority of our inventories, while we use the weighted-average method to value precious metal inventories. Weighted-average cost is calculated based upon the cost of precious metals at the time they are received by us. We have determined that it is not practicable to assign specific costs to individual units of precious metals and, as such, we relieve our precious metals inventory based on the weighted-average cost of the inventory at the time the inventory is used in production. The weighted-average method of valuing precious metals does not materially differ from a FIFO method. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-15-000010:mdna:117]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-15-000010:mdna:118]
Litigation and Other Contingencies

[0000106040-15-000010:mdna:119]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. Refer to Part II, Item 8, Note 5 in the Notes to Consolidated Financial Statements, included in this Annual Report on Form 10-K.

[0000106040-15-000010:mdna:120]
Income Taxes

[0000106040-15-000010:mdna:121]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized.

[0000106040-15-000010:mdna:122]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-15-000010:mdna:123]
48

[0000106040-15-000010:mdna:124]
Stock-based Compensation

[0000106040-15-000010:mdna:125]
We account for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial model, and the fair values of all Employee Stock Purchase Plan purchase rights are estimated using the Black-Scholes-Merton option-pricing model. We account for stock appreciation rights (“SARs”) as liability awards based upon our intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton models require the input of highly subjective assumptions. We are required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and our results of operations could be materially affected.

[0000106040-15-000010:mdna:126]
Goodwill and Other Long-Lived Assets

[0000106040-15-000010:mdna:127]
The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with amounts exceeding the fair values being recognized as goodwill. Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We either use qualitative factors to determine whether goodwill is more likely than not impaired or we perform a two-step approach to quantify impairment. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to follow a two-step approach to quantify the impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit.

[0000106040-15-000010:mdna:128]
Other intangible assets consist primarily of technology acquired in business combinations and in-process research and development. In-process research and development is not amortized until the point at which it reaches technological feasibility. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that it may be impaired. Acquired intangibles are amortized on a straight-line basis over their respective estimated useful lives. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-15-000010:mdna:129]
Recent Accounting Pronouncements

[0000106040-15-000010:mdna:130]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, refer to Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, which is incorporated by reference in response to this item.
