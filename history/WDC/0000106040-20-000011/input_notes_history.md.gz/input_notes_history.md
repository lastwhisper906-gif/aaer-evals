# WDC note change history — 0000106040-19-000075 → 0000106040-20-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:1]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.
  (was, 2019-11-12, similarity 0.9182):
[0000106040-19-000075:note_history:1]
The Company’s business ventures with Kioxia Corporation (formerly known as Toshiba Memory Corporation) (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- changed (2020-02-11):
[0000106040-20-000011:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 3, 2020 and June 28, 2019:
  (was, 2019-11-12, similarity 0.9535):
[0000106040-19-000075:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 4, 2019 and June 28, 2019:

- changed (2020-02-11):
[0000106040-20-000011:note_history:3]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 412 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 625 |  |  | 878 |  |
| Notes receivable, Flash Forward | 663 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,321 |  |  | $ | 2,791 |  |
  (was, 2019-11-12, similarity 0.9838):
[0000106040-19-000075:note_history:3]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 482 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 905 |  |  | 878 |  |
| Notes receivable, Flash Forward | 617 |  |  | 743 |  |
| Investment in Flash Partners | 202 |  |  | 200 |  |
| Investment in Flash Alliance | 299 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,629 |  |  | $ | 2,791 |  |

- added (2020-02-11):
[0000106040-20-000011:note_history:4]
During the three and six months ended January 3, 2020 and during the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $648 million and $1.33 billion, and $1.12 billion and $1.86 billion respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2020-02-11):
[0000106040-20-000011:note_history:5]
As of January 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $364 million and $331 million, respectively.
  (was, 2019-11-12, similarity 0.9565):
[0000106040-19-000075:note_history:5]
As of October 4, 2019 and June 28, 2019, the Company had accounts payable balances due to Flash Ventures of $507 million and $331 million, respectively.

- added (2020-02-11):
[0000106040-20-000011:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2020-02-11):
[0000106040-20-000011:note_history:7]
|  | January 3, 2020 |
| Notes receivable | $ | 1,700 |  |
| Equity investments | 621 |  |
| Operating lease guarantees | 1,746 |  |
| Inventory and prepayments | 462 |  |
| Maximum estimable loss exposure | $ | 4,529 |  |
  (was, 2019-11-12, similarity 0.9694):
[0000106040-19-000075:note_history:7]
|  | October 4, 2019 |
| Notes receivable | $ | 2,004 |  |
| Equity investments | 625 |  |
| Operating lease guarantees | 1,694 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 4,682 |  |

- changed (2020-02-11):
[0000106040-20-000011:note_history:8]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.
  (was, 2019-11-12, similarity 0.9988):
[0000106040-19-000075:note_history:8]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- added (2020-02-11):
[0000106040-20-000011:note_history:9]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

- added (2020-02-11):
[0000106040-20-000011:note_history:10]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the second half of fiscal year 2020, although meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the second half of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 3, 2020, remaining committed prepayments totaled $265 million.

- changed (2020-02-11):
[0000106040-20-000011:note_history:11]
Research and Development Activities. The Company participates in common Research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.
  (was, 2019-11-12, similarity 0.943):
[0000106040-19-000075:note_history:11]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

- changed (2020-02-11):
[0000106040-20-000011:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020.
  (was, 2019-11-12, similarity 0.9727):
[0000106040-19-000075:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019.

- changed (2020-02-11):
[0000106040-20-000011:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of January 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020:
  (was, 2019-11-12, similarity 0.8255):
[0000106040-19-000075:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 4, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 4, 2019:

- changed (2020-02-11):
[0000106040-20-000011:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2020 |  | $ | 239 |  |  | $ | 35 |  |  | $ | 274 |  |
| 2021 |  | 406 |  |  | 108 |  |  | 514 |  |
| 2022 |  | 323 |  |  | 49 |  |  | 372 |  |
| 2023 |  | 215 |  |  | 67 |  |  | 282 |  |
| 2024 |  | 98 |  |  | 120 |  |  | 218 |  |
| Thereafter |  | 12 |  |  | 74 |  |  | 86 |  |
| Total guarantee obligations |  | $ | 1,293 |  |  | $ | 453 |  |  | $ | 1,746 |  |
  (was, 2019-11-12, similarity 0.9923):
[0000106040-19-000075:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2020 |  | $ | 343 |  |  | $ | 56 |  |  | $ | 399 |  |
| 2021 |  | 369 |  |  | 110 |  |  | 479 |  |
| 2022 |  | 284 |  |  | 50 |  |  | 334 |  |
| 2023 |  | 177 |  |  | 67 |  |  | 244 |  |
| 2024 |  | 74 |  |  | 121 |  |  | 195 |  |
| Thereafter |  | 4 |  |  | 39 |  |  | 43 |  |
| Total guarantee obligations |  | $ | 1,251 |  |  | $ | 443 |  |  | $ | 1,694 |  |

- changed (2020-02-11):
[0000106040-20-000011:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of January 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2019-11-12, similarity 0.9864):
[0000106040-19-000075:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 4, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2020-02-11):
[0000106040-20-000011:note_history:16]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended January 3, 2020 and December 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of January 3, 2020 or June 28, 2019.
  (was, 2019-11-12, similarity 0.631):
[0000106040-19-000075:note_history:16]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three months ended October 4, 2019 and September 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of October 4, 2019 or June 28, 2019.

- removed (2020-02-11):
[0000106040-19-000075:note_history:17]
During the three months ended October 4, 2019 and September 28, 2018, the Company made net payments to Flash Ventures of $682 million and $744 million, respectively, for purchased flash-based memory wafers and net loans and investments.

- removed (2020-02-11):
[0000106040-19-000075:note_history:18]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 4, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2020-02-11):
[0000106040-19-000075:note_history:19]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. For the three months ended October 4, 2019, the Company incurred charges of $68 million recorded in cost of revenue as a result of this incident, which amount primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

- removed (2020-02-11):
[0000106040-19-000075:note_history:20]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 is expected in the second half of fiscal year 2020. Meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company committed to pay, among other items, future building depreciation prepayments of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:21]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
  (was, 2019-11-12, similarity 0.9862):
[0000106040-19-000075:note_history:21]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.

- removed (2020-02-11):
[0000106040-19-000075:note_history:22]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

- removed (2020-02-11):
[0000106040-19-000075:note_history:23]
Intellectual Property Litigation

- removed (2020-02-11):
[0000106040-19-000075:note_history:24]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. Mediation in this matter was held on August 16, 2019, and the parties reached an agreement in principle to settle the case for an immaterial amount, a portion of which was previously accrued in the Company’s financial statements. The parties formalized the settlement and filed a joint stipulation of dismissal with prejudice in October 2019. The matter is now closed.

- removed (2020-02-11):
[0000106040-19-000075:note_history:25]
Securities

- removed (2020-02-11):
[0000106040-19-000075:note_history:26]
Beginning in March 2015, SanDisk Corporation (“SanDisk”), which was acquired by the Company in May 2016, and two of SanDisk’s former officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015. The Institutional Investor Group alleged artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter. In May 2019, the court granted the motion for preliminary approval, and in October 2019, the court issued its final order and judgment approving the settlement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:27]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.
  (was, 2019-11-12, similarity 0.9804):
[0000106040-19-000075:note_history:27]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. It also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:28]
Debt consisted of the following as of January 3, 2020 and June 28, 2019:
  (was, 2019-11-12, similarity 0.9048):
[0000106040-19-000075:note_history:28]
Debt consisted of the following as of October 4, 2019 and June 28, 2019:

- changed (2020-02-11):
[0000106040-20-000011:note_history:29]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,708 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,986 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (153 | ) |  | (172 | ) |
| Subtotal | 9,833 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286 | ) |  | (276 | ) |
| Long-term debt | $ | 9,547 |  |  | $ | 10,246 |  |
  (was, 2019-11-12, similarity 0.7847):
[0000106040-19-000075:note_history:29]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | — |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,771 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,374 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (162 | ) |  | (172 | ) |
| Subtotal | 10,212 |  |  | 10,522 |  |
| Less current portion of long-term debt | (251 | ) |  | (276 | ) |
| Long-term debt | $ | 9,961 |  |  | $ | 10,246 |  |

- changed (2020-02-11):
[0000106040-20-000011:note_history:30]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 3, 2020, the Company was in compliance with these financial covenants.
  (was, 2019-11-12, similarity 0.9755):
[0000106040-19-000075:note_history:30]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 4, 2019, the Company was in compliance with these financial covenants.

- changed (2020-02-11):
[0000106040-20-000011:note_history:31]
On October 4, 2019 and January 3, 2020, the Company made voluntary prepayments of $250 million and $325 million, respectively, on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of January 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023. On January 31, 2020, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.
  (was, 2019-11-12, similarity 0.7359):
[0000106040-19-000075:note_history:31]
During the three months ended October 4, 2019, the Company made a voluntary prepayment of $250 million on its U.S. Term Loan B-4, which was applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of October 4, 2019, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:32]
Debt consisted of the following as of January 3, 2020 and June 28, 2019:
  (was, 2019-11-12, similarity 0.9048):
[0000106040-19-000075:note_history:32]
Debt consisted of the following as of October 4, 2019 and June 28, 2019:

- changed (2020-02-11):
[0000106040-20-000011:note_history:33]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,708 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,986 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (153 | ) |  | (172 | ) |
| Subtotal | 9,833 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286 | ) |  | (276 | ) |
| Long-term debt | $ | 9,547 |  |  | $ | 10,246 |  |
  (was, 2019-11-12, similarity 0.7847):
[0000106040-19-000075:note_history:33]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | — |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,771 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,168 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,374 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (162 | ) |  | (172 | ) |
| Subtotal | 10,212 |  |  | 10,522 |  |
| Less current portion of long-term debt | (251 | ) |  | (276 | ) |
| Long-term debt | $ | 9,961 |  |  | $ | 10,246 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:34]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 3, 2020 and June 28, 2019:
  (was, 2019-11-12, similarity 0.9535):
[0000106040-19-000075:note_history:34]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 4, 2019 and June 28, 2019:

- changed (2020-02-11):
[0000106040-20-000011:note_history:35]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 412 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 625 |  |  | 878 |  |
| Notes receivable, Flash Forward | 663 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,321 |  |  | $ | 2,791 |  |
  (was, 2019-11-12, similarity 0.9838):
[0000106040-19-000075:note_history:35]
|  | October 4, 2019 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 482 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 905 |  |  | 878 |  |
| Notes receivable, Flash Forward | 617 |  |  | 743 |  |
| Investment in Flash Partners | 202 |  |  | 200 |  |
| Investment in Flash Alliance | 299 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,629 |  |  | $ | 2,791 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-11):
[0000106040-20-000011:note_history:36]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |

- removed (2020-02-11):
[0000106040-19-000075:note_history:37]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except percentages) |
| Revenue by Product |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,408 |  |  | $ | 2,494 |  |
| Flash-based | 1,632 |  |  | 2,534 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 1,616 |  |  | $ | 2,650 |  |
| Data Center Devices & Solutions | 1,532 |  |  | 1,446 |  |
| Client Solutions | 892 |  |  | 932 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by Geography |  |  |  |
| Americas | $ | 1,313 |  |  | $ | 1,281 |  |
| Europe, Middle East and Africa | 779 |  |  | 884 |  |
| Asia | 1,948 |  |  | 2,863 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-11):
[0000106040-20-000011:note_history:38]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either January 3, 2020 or June 28, 2019.
  (was, 2019-11-12, similarity 0.9209):
[0000106040-19-000075:note_history:38]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 4, 2019 or June 28, 2019.

- changed (2020-02-11):
[0000106040-20-000011:note_history:39]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of January 3, 2020 and June 28, 2019 as well as the related amortization for the three and six months ended January 3, 2020 and December 28, 2018 were not material.
  (was, 2019-11-12, similarity 0.9587):
[0000106040-19-000075:note_history:39]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 4, 2019 and June 28, 2019 as well as the related amortization for the three months ended October 4, 2019 and September 28, 2018 were not material.

- changed (2020-02-11):
[0000106040-20-000011:note_history:40]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of January 3, 2020 and June 28, 2019, contract liabilities were not material.
  (was, 2019-11-12, similarity 0.9396):
[0000106040-19-000075:note_history:40]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 4, 2019 and June 28, 2019, contract liabilities were not material.

- changed (2020-02-11):
[0000106040-20-000011:note_history:41]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of January 3, 2020 was $140 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $24 million during the remainder of fiscal 2020, $43 million in fiscal 2021, $40 million in fiscal 2022 and $33 million thereafter.
  (was, 2019-11-12, similarity 0.9931):
[0000106040-19-000075:note_history:41]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 4, 2019 was $182 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $50 million during the remainder of fiscal 2020, $50 million in fiscal 2021, $45 million in fiscal 2022 and $37 million thereafter.

- added (2020-02-11):
[0000106040-20-000011:note_history:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |

- added (2020-02-11):
[0000106040-20-000011:note_history:43]
The Company’s top 10 customers accounted for 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively, and 47% of its net revenue for both the three and six months ended December 28, 2018.  For the three and six months ended January 3, 2020 and December 28, 2018, no single customer accounted for 10% or more of the Company’s net revenue.

- removed (2020-02-11):
[0000106040-19-000075:note_history:44]
|  | Three Months Ended |
|  | October 4, 2019 |  | September 28, 2018 |
|  | (in millions, except percentages) |
| Revenue by Product |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,408 |  |  | $ | 2,494 |  |
| Flash-based | 1,632 |  |  | 2,534 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 1,616 |  |  | $ | 2,650 |  |
| Data Center Devices & Solutions | 1,532 |  |  | 1,446 |  |
| Client Solutions | 892 |  |  | 932 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |
| Revenue by Geography |  |  |  |
| Americas | $ | 1,313 |  |  | $ | 1,281 |  |
| Europe, Middle East and Africa | 779 |  |  | 884 |  |
| Asia | 1,948 |  |  | 2,863 |  |
| Total Revenue | $ | 4,040 |  |  | $ | 5,028 |  |

- removed (2020-02-11):
[0000106040-19-000075:note_history:45]
For the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue and for the three months ended September 28, 2018, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended October 4, 2019 and September 28, 2018, the Company’s top 10 customers accounted for 43% and 48% of its net revenue, respectively.
