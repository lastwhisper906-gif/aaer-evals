# WDC notes — 0000106040-20-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-20-000011:notes:1]
[same as prior period, unchanged from 0000106040-19-000075:notes:1]

[0000106040-20-000011:notes:2]
[same as prior period, unchanged from 0000106040-19-000075:notes:2]

[0000106040-20-000011:notes:3]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.

[0000106040-20-000011:notes:4]
[same as prior period, unchanged from 0000106040-19-000075:notes:4]

[0000106040-20-000011:notes:5]
[same as prior period, unchanged from 0000106040-19-000075:notes:5]

[0000106040-20-000011:notes:6]
[same as prior period, unchanged from 0000106040-19-000075:notes:6]

[0000106040-20-000011:notes:7]
[same as prior period, unchanged from 0000106040-19-000075:notes:7]

[0000106040-20-000011:notes:8]
[same as prior period, unchanged from 0000106040-19-000075:notes:8]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-20-000011:notes:9]
Recent Accounting Pronouncements

[0000106040-20-000011:notes:10]
Accounting Pronouncements Recently Adopted

[0000106040-20-000011:notes:11]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The Company adopted this standard effective June 29, 2019, the first day of the fiscal year ending July 3, 2020, and has elected the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company has elected the package of practical expedients and did not reassess prior conclusions including (a) whether its contracts are or contain a lease, (b) lease classification and (c) capitalization of initial direct costs. The adoption of Topic 842 resulted in an increase in lease assets and a corresponding increase in lease liabilities on the Condensed Consolidated Balance Sheet of $221 million as of June 29, 2019. The cumulative effect of adopting Topic 842 also included an after-tax decrease to opening retained earnings of $5 million as of June 29, 2019, which was primarily related to previously recorded sublease proceed assumptions on lease exit liabilities for which there was no expected future economic benefit at transition. See Note 10, Leases and Other Commitments, for additional disclosures related to this standard.

[0000106040-20-000011:notes:12]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. The Company adopted this standard in the first quarter of 2020. The Company’s adoption of ASU 2018-16 did not have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000011:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-20-000011:notes:14]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000011:notes:15]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-20-000011:notes:16]
[same as prior period, unchanged from 0000106040-19-000075:notes:16]

[0000106040-20-000011:notes:17]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either January 3, 2020 or June 28, 2019.

[0000106040-20-000011:notes:18]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of January 3, 2020 and June 28, 2019 as well as the related amortization for the three and six months ended January 3, 2020 and December 28, 2018 were not material.

[0000106040-20-000011:notes:19]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of January 3, 2020 and June 28, 2019, contract liabilities were not material.

[0000106040-20-000011:notes:20]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of January 3, 2020 was $140 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $24 million during the remainder of fiscal 2020, $43 million in fiscal 2021, $40 million in fiscal 2022 and $33 million thereafter.

[0000106040-20-000011:notes:21]
[same as prior period, unchanged from 0000106040-19-000075:notes:21]

[0000106040-20-000011:notes:22]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |

[0000106040-20-000011:notes:23]
The Company’s top 10 customers accounted for 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively, and 47% of its net revenue for both the three and six months ended December 28, 2018.  For the three and six months ended January 3, 2020 and December 28, 2018, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-20-000011:notes:24]
[same as prior period, unchanged from 0000106040-19-000075:notes:24]

[0000106040-20-000011:notes:25]
[same as prior period, unchanged from 0000106040-19-000075:notes:25]

[0000106040-20-000011:notes:26]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the six months ended January 3, 2020 and December 28, 2018, the Company sold trade accounts receivable and received cash proceeds of $198 million and $370 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of January 3, 2020 and June 28, 2019, the amount of factored receivables that remained outstanding was $113 million and $318 million, respectively.

[0000106040-20-000011:notes:27]
[same as prior period, unchanged from 0000106040-19-000075:notes:27]

[0000106040-20-000011:notes:28]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,334 |  |  | $ | 1,142 |  |
| Work-in-process | 847 |  |  | 968 |  |
| Finished goods | 941 |  |  | 1,173 |  |
| Total inventories | $ | 3,122 |  |  | $ | 3,283 |  |

[0000106040-20-000011:notes:29]
[same as prior period, unchanged from 0000106040-19-000075:notes:29]

[0000106040-20-000011:notes:30]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 294 |  |  | $ | 294 |  |
| Buildings and improvements | 1,806 |  |  | 1,743 |  |
| Machinery and equipment | 7,171 |  |  | 7,267 |  |
| Computer equipment and software | 447 |  |  | 441 |  |
| Furniture and fixtures | 55 |  |  | 56 |  |
| Construction-in-process | 184 |  |  | 202 |  |
| Property, plant and equipment, gross | 9,957 |  |  | 10,003 |  |
| Accumulated depreciation | (7,235 | ) |  | (7,160 | ) |
| Property, plant and equipment, net | $ | 2,722 |  |  | $ | 2,843 |  |

[0000106040-20-000011:notes:31]
[same as prior period, unchanged from 0000106040-19-000075:notes:31]

[0000106040-20-000011:notes:32]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 28, 2019 | $ | 10,076 |  |
| Goodwill recorded in connection with an acquisition | 14 |  |
| Reduction in goodwill in connection with disposition of business | (20 | ) |
| Foreign currency translation adjustment | (1 | ) |
| Balance at January 3, 2020 | $ | 10,069 |  |

[0000106040-20-000011:notes:33]
Acquisition

[0000106040-20-000011:notes:34]
On September 10, 2019, the Company acquired substantially all the assets of Kazan Networks, Inc., an innovator in high-performance networking and non-volatile memory express over fabrics technology ("NVMe-oF"), and an industry leader in application-specific integrated circuit and adapter solutions to connect storage platforms and systems over ethernet fabrics. The purchase price of this acquisition was $22 million in cash, with net assets acquired primarily consisting of in-process research and development (“IPR&D”) of $8 million and $14 million allocated to Goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings in its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. The expenses incurred by the Company related to the acquisition as well as the revenues and earnings related to the acquisition were not material to the Condensed Consolidated Financial Statements.

[0000106040-20-000011:notes:35]
Dispositions

[0000106040-20-000011:notes:36]
In September 2019, the Company announced the sale of its IntelliFlash business and intention to exit Storage Systems, which consists of IntelliFlash and ActiveScale. These actions will allow the Company to redirect investments to other high value priorities. In November 2019, the Company completed its sale of IntelliFlash for a price of $28 million, to be collected over the next three years. The sale of the IntelliFlash business included an immaterial amount of inventory, other tangible and intangible assets, and goodwill and resulted in a gain of approximately $17 million recorded in Employee termination, asset impairment, and other charges in the Condensed Consolidated Statements of Operations for both the three and six months ended January 3, 2020. Additionally, in February 2020, the Company entered into an agreement for the sale of ActiveScale. The net assets sold and the proceeds from the sale of ActiveScale were not material. The revenues and expenses related to these businesses were not material to the Condensed Consolidated Financial Statements and did not qualify to be reported as discontinued operations. The operating results of these businesses have and will be reflected in the Company’s results from continuing operations in the Condensed Consolidated Statements of Operations for all periods presented through the date of disposition.

[0000106040-20-000011:notes:37]
[same as prior period, unchanged from 0000106040-19-000075:notes:34]

[0000106040-20-000011:notes:38]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,798 |  |  | $ | 5,824 |  |
| In-process research and development | 80 |  |  | 72 |  |
| Accumulated amortization | (4,567 | ) |  | (4,185 | ) |
| Intangible assets, net | $ | 1,311 |  |  | $ | 1,711 |  |

[0000106040-20-000011:notes:39]
[same as prior period, unchanged from 0000106040-19-000075:notes:36]

[0000106040-20-000011:notes:40]
[same as prior period, unchanged from 0000106040-19-000075:notes:37]

[0000106040-20-000011:notes:41]
[same as prior period, unchanged from 0000106040-19-000075:notes:38]

[0000106040-20-000011:notes:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 357 |  |  | $ | 323 |  |  | $ | 350 |  |  | $ | 318 |  |
| Charges to operations | 50 |  |  | 47 |  |  | 99 |  |  | 81 |  |
| Utilization | (35 | ) |  | (42 | ) |  | (83 | ) |  | (68 | ) |
| Changes in estimate related to pre-existing warranties | 6 |  |  | 9 |  |  | 12 |  |  | 6 |  |
| Warranty accrual, end of period | $ | 378 |  |  | $ | 337 |  |  | $ | 378 |  |  | $ | 337 |  |

[0000106040-20-000011:notes:43]
[same as prior period, unchanged from 0000106040-19-000075:notes:40]

[0000106040-20-000011:notes:44]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion (included in Accrued expenses) | $ | 193 |  |  | $ | 188 |  |
| Long-term portion (included in Other liabilities) | 185 |  |  | 162 |  |
| Total warranty accrual | $ | 378 |  |  | $ | 350 |  |

[0000106040-20-000011:notes:45]
[same as prior period, unchanged from 0000106040-19-000075:notes:42]

[0000106040-20-000011:notes:46]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 839 |  |  | $ | 928 |  |
| Payables related to unrecognized tax benefits | 708 |  |  | 699 |  |
| Other non-current liabilities | 905 |  |  | 713 |  |
| Total other liabilities | $ | 2,452 |  |  | $ | 2,340 |  |

[0000106040-20-000011:notes:47]
[same as prior period, unchanged from 0000106040-19-000075:notes:44]

[0000106040-20-000011:notes:48]
[same as prior period, unchanged from 0000106040-19-000075:notes:45]

[0000106040-20-000011:notes:49]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 28, 2019 | $ | (53 | ) |  | $ | 4 |  |  | $ | (19 | ) |  | $ | (68 | ) |
| Other comprehensive income (loss) before reclassifications | 3 |  |  | (10 | ) |  | (20 | ) |  | (27 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (19 | ) |  | (19 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (1 | ) |  | 1 |  |  | 4 |  |  | 4 |  |
| Net current-period other comprehensive income (loss) | 2 |  |  | (9 | ) |  | (35 | ) |  | (42 | ) |
| Balance at January 3, 2020 | $ | (51 | ) |  | $ | (5 | ) |  | $ | (54 | ) |  | $ | (110 | ) |

[0000106040-20-000011:notes:50]
During the three and six months ended January 3, 2020 and December 28, 2018, the amounts reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-20-000011:notes:51]
[same as prior period, unchanged from 0000106040-19-000075:notes:48]

[0000106040-20-000011:notes:52]
[same as prior period, unchanged from 0000106040-19-000075:notes:49]

[0000106040-20-000011:notes:53]
[same as prior period, unchanged from 0000106040-19-000075:notes:50]

[0000106040-20-000011:notes:54]
[same as prior period, unchanged from 0000106040-19-000075:notes:51]

[0000106040-20-000011:notes:55]
[same as prior period, unchanged from 0000106040-19-000075:notes:52]

[0000106040-20-000011:notes:56]
[same as prior period, unchanged from 0000106040-19-000075:notes:53]

[0000106040-20-000011:notes:57]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of January 3, 2020 and June 28, 2019, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-20-000011:notes:58]
|  | January 3, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,051 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,051 |  |
| Foreign exchange contracts | — |  |  | 31 |  |  | — |  |  | 31 |  |
| Total assets at fair value | $ | 1,051 |  |  | $ | 31 |  |  | $ | — |  |  | $ | 1,082 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Interest rate swap contract | — |  |  | 69 |  |  | — |  |  | 69 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 83 |  |  | $ | — |  |  | $ | 83 |  |

[0000106040-20-000011:notes:59]
[same as prior period, unchanged from 0000106040-19-000075:notes:56]

[0000106040-20-000011:notes:60]
During the three and six months ended January 3, 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-20-000011:notes:61]
[same as prior period, unchanged from 0000106040-19-000075:notes:58]

[0000106040-20-000011:notes:62]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2020 and the fourth quarter of 2019, respectively.

[0000106040-20-000011:notes:63]
|  | January 3, 2020 |  | June 28, 2019 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 33 |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | 31 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,700 |  |  | 4,720 |  |  | 4,824 |  |  | 4,780 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 1,857 |  |  | 2,424 |  |  | 2,370 |  |
| 1.50% convertible notes due 2024 | 973 |  |  | 1,085 |  |  | 958 |  |  | 986 |  |
| 4.75% senior unsecured notes due 2026 | 2,284 |  |  | 2,419 |  |  | 2,283 |  |  | 2,263 |  |
| Total | $ | 9,833 |  |  | $ | 10,115 |  |  | $ | 10,522 |  |  | $ | 10,430 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-20-000011:notes:64]
[same as prior period, unchanged from 0000106040-19-000075:notes:61]

[0000106040-20-000011:notes:65]
As of January 3, 2020, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-20-000011:notes:66]
As of January 3, 2020, the amount of existing net losses related to cash flow hedges recorded in AOCI included $51 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of January 3, 2020, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-20-000011:notes:67]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and six months ended January 3, 2020 and December 28, 2018, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-20-000011:notes:68]
[same as prior period, unchanged from 0000106040-19-000075:notes:65]

[0000106040-20-000011:notes:69]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of January 3, 2020 and June 28, 2019, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-20-000011:notes:70]
Debt

[0000106040-20-000011:notes:71]
Debt consisted of the following as of January 3, 2020 and June 28, 2019:

[0000106040-20-000011:notes:72]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,708 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,843 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,986 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (153 | ) |  | (172 | ) |
| Subtotal | 9,833 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286 | ) |  | (276 | ) |
| Long-term debt | $ | 9,547 |  |  | $ | 10,246 |  |

[0000106040-20-000011:notes:73]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 3, 2020, the Company was in compliance with these financial covenants.

[0000106040-20-000011:notes:74]
On October 4, 2019 and January 3, 2020, the Company made voluntary prepayments of $250 million and $325 million, respectively, on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of January 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023. On January 31, 2020, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-20-000011:notes:75]
[same as prior period, unchanged from 0000106040-19-000075:notes:72]

[0000106040-20-000011:notes:76]
[same as prior period, unchanged from 0000106040-19-000075:notes:73]

[0000106040-20-000011:notes:77]
[same as prior period, unchanged from 0000106040-19-000075:notes:74]

[0000106040-20-000011:notes:78]
[same as prior period, unchanged from 0000106040-19-000075:notes:75]

[0000106040-20-000011:notes:79]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Benefit obligation at end of period | $ | 278 |  |  | $ | 280 |  |
| Fair value of plan assets at end of period | 210 |  |  | 208 |  |
| Unfunded status | $ | 68 |  |  | $ | 72 |  |

[0000106040-20-000011:notes:80]
[same as prior period, unchanged from 0000106040-19-000075:notes:77]

[0000106040-20-000011:notes:81]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 67 |  |  | 71 |  |
| Net amount recognized | $ | 68 |  |  | $ | 72 |  |

[0000106040-20-000011:notes:82]
Net periodic benefit costs were not material for either the three or six months ended January 3, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-20-000011:notes:83]
Related Parties and Related Commitments and Contingencies

[0000106040-20-000011:notes:84]
Flash Ventures

[0000106040-20-000011:notes:85]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-20-000011:notes:86]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 3, 2020 and June 28, 2019:

[0000106040-20-000011:notes:87]
|  | January 3, 2020 |  | June 28, 2019 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 412 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 625 |  |  | 878 |  |
| Notes receivable, Flash Forward | 663 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 124 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,321 |  |  | $ | 2,791 |  |

[0000106040-20-000011:notes:88]
During the three and six months ended January 3, 2020 and during the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $648 million and $1.33 billion, and $1.12 billion and $1.86 billion respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-20-000011:notes:89]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-20-000011:notes:90]
As of January 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $364 million and $331 million, respectively.

[0000106040-20-000011:notes:91]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-20-000011:notes:92]
|  | January 3, 2020 |
| Notes receivable | $ | 1,700 |  |
| Equity investments | 621 |  |
| Operating lease guarantees | 1,746 |  |
| Inventory and prepayments | 462 |  |
| Maximum estimable loss exposure | $ | 4,529 |  |

[0000106040-20-000011:notes:93]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-20-000011:notes:94]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

[0000106040-20-000011:notes:95]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the second half of fiscal year 2020, although meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the second half of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 3, 2020, remaining committed prepayments totaled $265 million.

[0000106040-20-000011:notes:96]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-20-000011:notes:97]
Research and Development Activities. The Company participates in common Research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-20-000011:notes:98]
Off-Balance Sheet Liabilities

[0000106040-20-000011:notes:99]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-20-000011:notes:100]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020.

[0000106040-20-000011:notes:101]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 189 |  |  | $ | 1,746 |  |

[0000106040-20-000011:notes:102]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of January 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 3, 2020:

[0000106040-20-000011:notes:103]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2020 |  | $ | 239 |  |  | $ | 35 |  |  | $ | 274 |  |
| 2021 |  | 406 |  |  | 108 |  |  | 514 |  |
| 2022 |  | 323 |  |  | 49 |  |  | 372 |  |
| 2023 |  | 215 |  |  | 67 |  |  | 282 |  |
| 2024 |  | 98 |  |  | 120 |  |  | 218 |  |
| Thereafter |  | 12 |  |  | 74 |  |  | 86 |  |
| Total guarantee obligations |  | $ | 1,293 |  |  | $ | 453 |  |  | $ | 1,746 |  |

[0000106040-20-000011:notes:104]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of January 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-20-000011:notes:105]
Unis Venture

[0000106040-20-000011:notes:106]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended January 3, 2020 and December 28, 2018, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of January 3, 2020 or June 28, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-20-000011:notes:107]
[same as prior period, unchanged from 0000106040-19-000075:notes:104]

[0000106040-20-000011:notes:108]
[same as prior period, unchanged from 0000106040-19-000075:notes:105]

[0000106040-20-000011:notes:109]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of January 3, 2020:

[0000106040-20-000011:notes:110]
|  | Lease Amounts |
| Minimum lease payments by fiscal year: | (in millions) |
| Remaining six months of 2020 | $ | 26 |  |
| 2021 | 45 |  |
| 2022 | 30 |  |
| 2023 | 25 |  |
| 2024 | 27 |  |
| Thereafter | 168 |  |
| Total future minimum lease payments | 321 |  |
| Less: Imputed Interest | (63 | ) |
| Present value of lease liabilities | 258 |  |
| Less: Current portion (included in Accrued expenses) | 41 |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 217 |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 242 |  |
| Weighted average remaining lease term in years | 9.4 |  |
| Weighted average discount rate | 4.2 | % |

[0000106040-20-000011:notes:111]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases for the three and six months ended January 3, 2020:

[0000106040-20-000011:notes:112]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | January 3, 2020 |
|  | (in millions) |
| Cost of operating leases | $ | 18 |  |  | $ | 30 |  |
| Cash paid for operating leases | 13 |  |  | 29 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 1 |  |  | 50 |  |

[0000106040-20-000011:notes:113]
[same as prior period, unchanged from 0000106040-19-000075:notes:110]

[0000106040-20-000011:notes:114]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of January 3, 2020, the Company had the following minimum long-term commitments:

[0000106040-20-000011:notes:115]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining six months of 2020 |  | $ | 123 |  |
| 2021 |  | 304 |  |
| 2022 |  | 390 |  |
| 2023 |  | 407 |  |
| 2024 |  | 180 |  |
| Thereafter |  | 338 |  |
| Total |  | $ | 1,742 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-20-000011:notes:116]
[same as prior period, unchanged from 0000106040-19-000075:notes:113]

[0000106040-20-000011:notes:117]
[same as prior period, unchanged from 0000106040-19-000075:notes:114]

[0000106040-20-000011:notes:118]
[same as prior period, unchanged from 0000106040-19-000075:notes:115]

[0000106040-20-000011:notes:119]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Options | $ | 2 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 9 |  |
| Restricted and performance stock units | 70 |  |  | 70 |  |  | 136 |  |  | 137 |  |
| Employee stock purchase plan | 5 |  |  | 5 |  |  | 14 |  |  | 12 |  |
| Total | $ | 77 |  |  | $ | 79 |  |  | $ | 154 |  |  | $ | 158 |  |

[0000106040-20-000011:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 13 |  |  | $ | 25 |  |  | $ | 24 |  |
| Research and development | 41 |  |  | 42 |  |  | 82 |  |  | 81 |  |
| Selling, general and administrative | 23 |  |  | 24 |  |  | 47 |  |  | 53 |  |
| Subtotal | 77 |  |  | 79 |  |  | 154 |  |  | 158 |  |
| Tax benefit | (11 | ) |  | (14 | ) |  | (23 | ) |  | (25 | ) |
| Total | $ | 66 |  |  | $ | 65 |  |  | $ | 131 |  |  | $ | 133 |  |

[0000106040-20-000011:notes:121]
Windfall tax benefits related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were immaterial for the periods presented.

[0000106040-20-000011:notes:122]
Compensation cost related to unvested stock options, restricted stock units (“RSUs”), performance-based stock units (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of January 3, 2020:

[0000106040-20-000011:notes:123]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 3 |  |  | 0.6 |
| RSUs and PSUs (1) | 640 |  |  | 2.7 |
| ESPP | 50 |  |  | 1.4 |
| Total unamortized compensation cost | $ | 693 |  |  |  |

[0000106040-20-000011:notes:124]
[same as prior period, unchanged from 0000106040-19-000075:notes:120]

[0000106040-20-000011:notes:125]
[same as prior period, unchanged from 0000106040-19-000075:notes:121]

[0000106040-20-000011:notes:126]
[same as prior period, unchanged from 0000106040-19-000075:notes:122]

[0000106040-20-000011:notes:127]
[same as prior period, unchanged from 0000106040-19-000075:notes:123]

[0000106040-20-000011:notes:128]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 28, 2019 | 3.9 |  |  | $ | 65.72 |  |  |  |  |  |
| Exercised | (0.6 | ) |  | 43.48 |  |  |  |  | $ | 8 |  |
| Canceled or expired | (0.3 | ) |  | 93.23 |  |  |  |  |  |
| Options outstanding at January 3, 2020 | 3.0 |  |  | 67.85 |  |  | 2.6 |  | $ | 28 |  |
| Exercisable at January 3, 2020 | 2.7 |  |  | 70.60 |  |  | 2.5 |  | $ | 22 |  |

[0000106040-20-000011:notes:129]
[same as prior period, unchanged from 0000106040-19-000075:notes:125]

[0000106040-20-000011:notes:130]
[same as prior period, unchanged from 0000106040-19-000075:notes:126]

[0000106040-20-000011:notes:131]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2019 | 11.6 |  |  | $ | 62.07 |  |  |  |
| Granted | 5.8 |  |  | 58.13 |  |  |  |
| Vested | (3.3 | ) |  | 63.15 |  |  | $ | 186 |  |
| Forfeited | (0.8 | ) |  | 63.37 |  |  |  |
| RSUs and PSUs outstanding at January 3, 2020 | 13.3 |  |  | 60.88 |  |  |  |

[0000106040-20-000011:notes:132]
[same as prior period, unchanged from 0000106040-19-000075:notes:128]

[0000106040-20-000011:notes:133]
[same as prior period, unchanged from 0000106040-19-000075:notes:129]

[0000106040-20-000011:notes:134]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of the Company’s common stock, which authorization is effective through July 25, 2023. For the six months ended January 3, 2020, the Company did not make any stock repurchases. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of January 3, 2020 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-20-000011:notes:135]
[same as prior period, unchanged from 0000106040-19-000075:notes:131]

[0000106040-20-000011:notes:136]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the six months ended January 3, 2020, the Company declared aggregate cash dividends of $1.00 per share on its outstanding common stock totaling $298 million, of which $149 million was paid on January 21, 2020. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-20-000011:notes:137]
[same as prior period, unchanged from 0000106040-19-000075:notes:133]

[0000106040-20-000011:notes:138]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-20-000011:notes:139]
The following table presents the Company’s Income tax expense and the effective tax rate:

[0000106040-20-000011:notes:140]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Income (loss) before taxes | $ | (40 | ) |  | $ | 81 |  |  | $ | (277 | ) |  | $ | 664 |  |
| Income tax expense | 99 |  |  | 568 |  |  | 138 |  |  | 640 |  |
| Effective tax rate | (248 | )% |  | 701 | % |  | (50 | )% |  | 96 | % |

[0000106040-20-000011:notes:141]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2020 through 2030.  In addition, the effective tax rate for the six months ended January 3, 2020 includes the discrete effect of a de-recognition of $33 million for certain deferred tax assets associated with the Company’s creditable foreign withholding taxes due to the issuance of final regulatory guidance. The regulatory guidance does not preclude the Company from potentially claiming these creditable taxes as a period benefit when paid.

[0000106040-20-000011:notes:142]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act.  For the three months ended December 28, 2018, these discrete effects consist of $230 million related to the mandatory deemed repatriation tax and $134 million related to the Company’s decision to change its indefinite reinvestment assertion. For the six months ended December 28, 2018, these discrete effects consist of $178 million related to the mandatory deemed repatriation tax and $144 million related to the Company’s decision to change its indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to the changes in the relative mix of our U.S. earnings compared to foreign earnings.

[0000106040-20-000011:notes:143]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-20-000011:notes:144]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of January 3, 2020, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-20-000011:notes:145]
As of January 3, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $696 million. Accrued interest and penalties related to unrecognized tax benefits as of January 3, 2020 was approximately $131 million. Of these amounts, approximately $708 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-20-000011:notes:146]
[same as prior period, unchanged from 0000106040-19-000075:notes:144]

[0000106040-20-000011:notes:147]
[same as prior period, unchanged from 0000106040-19-000075:notes:145]

[0000106040-20-000011:notes:148]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (139 | ) |  | $ | (487 | ) |  | $ | (415 | ) |  | $ | 24 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 298 |  |  | 290 |  |  | 297 |  |  | 291 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | — |  |  | — |  |  | 5 |  |
| Diluted | 298 |  |  | 290 |  |  | 297 |  |  | 296 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (0.47 | ) |  | $ | (1.68 | ) |  | $ | (1.40 | ) |  | $ | 0.08 |  |
| Diluted | $ | (0.47 | ) |  | $ | (1.68 | ) |  | $ | (1.40 | ) |  | $ | 0.08 |  |
| Anti-dilutive potential common shares excluded | 15 |  |  | 19 |  |  | 15 |  |  | 8 |  |

[0000106040-20-000011:notes:149]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the six months ended December 28, 2018, the Company excluded common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For the three and six months ended January 3, 2020, and the three months ended December 28, 2018, the Company recorded net losses, and all shares subject to outstanding equity awards have been excluded for those periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-20-000011:notes:150]
[same as prior period, unchanged from 0000106040-19-000075:notes:148]

[0000106040-20-000011:notes:151]
[same as prior period, unchanged from 0000106040-19-000075:notes:149]

[0000106040-20-000011:notes:152]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | — |  |  | $ | 7 |  |  | $ | 4 |  |  | $ | 11 |  |
| Business Realignment | 26 |  |  | 13 |  |  | 30 |  |  | 55 |  |
| Total employee termination and other charges | 26 |  |  | 20 |  |  | 34 |  |  | 66 |  |
| Gain on disposition of assets: |  |  |  |  |  |  |  |
| Business Realignment | (17 | ) |  | — |  |  | (17 | ) |  | — |  |
| Total gain on disposition of assets | (17 | ) |  | — |  |  | (17 | ) |  | — |  |
| Total employee termination, asset impairment, and other charges | $ | 9 |  |  | $ | 20 |  |  | $ | 17 |  |  | $ | 66 |  |

[0000106040-20-000011:notes:153]
[same as prior period, unchanged from 0000106040-19-000075:notes:151]

[0000106040-20-000011:notes:154]
[same as prior period, unchanged from 0000106040-19-000075:notes:152]

[0000106040-20-000011:notes:155]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the six months ended January 3, 2020:

[0000106040-20-000011:notes:156]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 28, 2019 | $ | 30 |  |  | $ | 2 |  |  | $ | 32 |  |
| Charges | 2 |  |  | 2 |  |  | 4 |  |
| Cash payments | (21 | ) |  | (4 | ) |  | (25 | ) |
| Accrual balance at January 3, 2020 | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0000106040-20-000011:notes:157]
[same as prior period, unchanged from 0000106040-19-000075:notes:155]

[0000106040-20-000011:notes:158]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. In addition to the amounts recognized under Business Realignment as presented above, the Company recognized $5 million of accelerated depreciation on facility assets in Cost of revenue and Operating expenses in the Condensed Consolidated Statements of Operations for the six months ended January 3, 2020.

[0000106040-20-000011:notes:159]
The following table presents an analysis of the components of the activity against the reserve during the six months ended January 3, 2020:

[0000106040-20-000011:notes:160]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 28, 2019 | $ | 37 |  |  | $ | 8 |  |  | $ | 45 |  |
| Charges | 26 |  |  | 4 |  |  | 30 |  |
| Cash payments | (35 | ) |  | (11 | ) |  | (46 | ) |
| Accrual balance at January 3, 2020 | $ | 28 |  |  | $ | 1 |  |  | $ | 29 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-20-000011:notes:161]
Legal Proceedings

[0000106040-20-000011:notes:162]
Tax

[0000106040-20-000011:notes:163]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 12, Income Tax Expense.

[0000106040-20-000011:notes:164]
Other Matters

[0000106040-20-000011:notes:165]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## srt:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-20-000011:notes:166]
[same as prior period, unchanged from 0000106040-19-000075:notes:169]

[0000106040-20-000011:notes:167]
The Company’s 4.750% senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the credit agreement governing the revolving credit facility and term loans or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-20-000011:notes:168]
| Condensed Consolidating Balance Sheet |
| As of January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 11 |  |  | $ | 786 |  |  | $ | 2,340 |  |  | $ | — |  |  | $ | 3,137 |  |
| Accounts receivable, net | — |  |  | 1,172 |  |  | 619 |  |  | — |  |  | 1,791 |  |
| Intercompany receivables | 2,617 |  |  | 7,840 |  |  | 2,839 |  |  | (13,296 | ) |  | — |  |
| Inventories | — |  |  | 716 |  |  | 2,472 |  |  | (66 | ) |  | 3,122 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 258 |  |  | (258 | ) |  | — |  |
| Other current assets | — |  |  | 364 |  |  | 213 |  |  | — |  |  | 577 |  |
| Total current assets | 2,628 |  |  | 10,878 |  |  | 8,741 |  |  | (13,620 | ) |  | 8,627 |  |
| Property, plant and equipment, net | — |  |  | 820 |  |  | 1,902 |  |  | — |  |  | 2,722 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,321 |  |  | — |  |  | 2,321 |  |
| Goodwill | — |  |  | 374 |  |  | 9,695 |  |  | — |  |  | 10,069 |  |
| Other intangible assets, net | — |  |  | 10 |  |  | 1,301 |  |  | — |  |  | 1,311 |  |
| Investments in consolidated subsidiaries | 20,637 |  |  | 15,471 |  |  | — |  |  | (36,108 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 1,626 |  |  | — |  |  | (1,626 | ) |  | — |  |
| Other non-current assets | 56 |  |  | 255 |  |  | 499 |  |  | — |  |  | 810 |  |
| Total assets | $ | 23,321 |  |  | $ | 29,434 |  |  | $ | 24,459 |  |  | $ | (51,354 | ) |  | $ | 25,860 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 153 |  |  | $ | 1,583 |  |  | $ | — |  |  | $ | 1,736 |  |
| Accounts payable to related parties | — |  |  | 364 |  |  | — |  |  | — |  |  | 364 |  |
| Intercompany payables | 2,285 |  |  | 4,953 |  |  | 6,058 |  |  | (13,296 | ) |  | — |  |
| Accrued expenses | 206 |  |  | 837 |  |  | 516 |  |  | — |  |  | 1,559 |  |
| Accrued compensation | — |  |  | 356 |  |  | 181 |  |  | — |  |  | 537 |  |
| Loans due to consolidated affiliates | — |  |  | 258 |  |  | — |  |  | (258 | ) |  | — |  |
| Current portion of long-term debt | 251 |  |  | — |  |  | 35 |  |  | — |  |  | 286 |  |
| Total current liabilities | 2,742 |  |  | 6,921 |  |  | 8,373 |  |  | (13,554 | ) |  | 4,482 |  |
| Long-term debt | 9,547 |  |  | — |  |  | — |  |  | — |  |  | 9,547 |  |
| Loans due to consolidated affiliates | 1,603 |  |  | — |  |  | 23 |  |  | (1,626 | ) |  | — |  |
| Other liabilities | 50 |  |  | 1,843 |  |  | 559 |  |  | — |  |  | 2,452 |  |
| Total liabilities | 13,942 |  |  | 8,764 |  |  | 8,955 |  |  | (15,180 | ) |  | 16,481 |  |
| Total shareholders’ equity | 9,379 |  |  | 20,670 |  |  | 15,504 |  |  | (36,174 | ) |  | 9,379 |  |
| Total liabilities and shareholders’ equity | $ | 23,321 |  |  | $ | 29,434 |  |  | $ | 24,459 |  |  | $ | (51,354 | ) |  | $ | 25,860 |  |

[0000106040-20-000011:notes:169]
| Condensed Consolidating Balance Sheet |
| As of June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 8 |  |  | $ | 985 |  |  | $ | 2,462 |  |  | $ | — |  |  | $ | 3,455 |  |
| Accounts receivable, net | — |  |  | 779 |  |  | 425 |  |  | — |  |  | 1,204 |  |
| Intercompany receivables | 2,409 |  |  | 5,808 |  |  | 1,581 |  |  | (9,798 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,438 |  |  | (145 | ) |  | 3,283 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 50 |  |  | (50 | ) |  | — |  |
| Other current assets | 2 |  |  | 251 |  |  | 282 |  |  | — |  |  | 535 |  |
| Total current assets | 2,419 |  |  | 8,813 |  |  | 7,238 |  |  | (9,993 | ) |  | 8,477 |  |
| Property, plant and equipment, net | — |  |  | 873 |  |  | 1,970 |  |  | — |  |  | 2,843 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,791 |  |  | — |  |  | 2,791 |  |
| Goodwill | — |  |  | 388 |  |  | 9,688 |  |  | — |  |  | 10,076 |  |
| Other intangible assets, net | — |  |  | 23 |  |  | 1,688 |  |  | — |  |  | 1,711 |  |
| Investments in consolidated subsidiaries | 20,772 |  |  | 16,355 |  |  | — |  |  | (37,127 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 674 |  |  | — |  |  | (674 | ) |  | — |  |
| Other non-current assets | 60 |  |  | 51 |  |  | 361 |  |  | — |  |  | 472 |  |
| Total assets | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 195 |  |  | $ | 1,372 |  |  | $ | — |  |  | $ | 1,567 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 331 |  |  | — |  |  | 331 |  |
| Intercompany payables | 1,871 |  |  | 3,515 |  |  | 4,412 |  |  | (9,798 | ) |  | — |  |
| Accrued expenses | 195 |  |  | 522 |  |  | 579 |  |  | — |  |  | 1,296 |  |
| Accrued compensation | — |  |  | 214 |  |  | 133 |  |  | — |  |  | 347 |  |
| Loans due to consolidated affiliates | — |  |  | 50 |  |  | — |  |  | (50 | ) |  | — |  |
| Current portion of long-term debt | 276 |  |  | — |  |  | — |  |  | — |  |  | 276 |  |
| Total current liabilities | 2,342 |  |  | 4,496 |  |  | 6,827 |  |  | (9,848 | ) |  | 3,817 |  |
| Long-term debt | 10,213 |  |  | — |  |  | 33 |  |  | — |  |  | 10,246 |  |
| Loans due to consolidated affiliates | 674 |  |  | — |  |  | — |  |  | (674 | ) |  | — |  |
| Other liabilities | 55 |  |  | 1,795 |  |  | 490 |  |  | — |  |  | 2,340 |  |
| Total liabilities | 13,284 |  |  | 6,291 |  |  | 7,350 |  |  | (10,522 | ) |  | 16,403 |  |
| Total shareholders’ equity | 9,967 |  |  | 20,886 |  |  | 16,386 |  |  | (37,272 | ) |  | 9,967 |  |
| Total liabilities and shareholders’ equity | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |

[0000106040-20-000011:notes:170]
| Condensed Consolidating Statement of Operations |
| For the three months ended January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,304 |  |  | $ | 4,041 |  |  | $ | (3,111 | ) |  | $ | 4,234 |  |
| Cost of revenue | — |  |  | 2,881 |  |  | 3,643 |  |  | (3,225 | ) |  | 3,299 |  |
| Gross profit | — |  |  | 423 |  |  | 398 |  |  | 114 |  |  | 935 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 362 |  |  | 216 |  |  | — |  |  | 578 |  |
| Selling, general and administrative | — |  |  | 196 |  |  | 102 |  |  | — |  |  | 298 |  |
| Intercompany operating expense (income) | 4 |  |  | (397 | ) |  | 393 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | (5 | ) |  | 14 |  |  | — |  |  | 9 |  |
| Total operating expenses | 4 |  |  | 156 |  |  | 725 |  |  | — |  |  | 885 |  |
| Operating income (loss) | (4 | ) |  | 267 |  |  | (327 | ) |  | 114 |  |  | 50 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 16 |  |  | 5 |  |  | (13 | ) |  | 8 |  |
| Interest expense | (118 | ) |  | — |  |  | — |  |  | 13 |  |  | (105 | ) |
| Other income, net | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total interest and other income (expense), net | (118 | ) |  | 16 |  |  | 12 |  |  | — |  |  | (90 | ) |
| Income (loss) before taxes | (122 | ) |  | 283 |  |  | (315 | ) |  | 114 |  |  | (40 | ) |
| Equity in earnings from subsidiaries | (42 | ) |  | (384 | ) |  | — |  |  | 426 |  |  | — |  |
| Income tax expense (benefit) | (25 | ) |  | 55 |  |  | 69 |  |  | — |  |  | 99 |  |
| Net loss | $ | (139 | ) |  | $ | (156 | ) |  | $ | (384 | ) |  | $ | 540 |  |  | $ | (139 | ) |

[0000106040-20-000011:notes:171]
| Condensed Consolidating Statement of Operations |
| For the six months ended January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 6,665 |  |  | $ | 8,025 |  |  | $ | (6,416 | ) |  | $ | 8,274 |  |
| Cost of revenue | — |  |  | 5,833 |  |  | 7,333 |  |  | (6,585 | ) |  | 6,581 |  |
| Gross profit | — |  |  | 832 |  |  | 692 |  |  | 169 |  |  | 1,693 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 726 |  |  | 426 |  |  | — |  |  | 1,152 |  |
| Selling, general and administrative | 1 |  |  | 399 |  |  | 203 |  |  | — |  |  | 603 |  |
| Intercompany operating expense (income) | 7 |  |  | (822 | ) |  | 815 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | (5 | ) |  | 22 |  |  | — |  |  | 17 |  |
| Total operating expenses | 8 |  |  | 298 |  |  | 1,466 |  |  | — |  |  | 1,772 |  |
| Operating income (loss) | (8 | ) |  | 534 |  |  | (774 | ) |  | 169 |  |  | (79 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 28 |  |  | 15 |  |  | (23 | ) |  | 20 |  |
| Interest expense | (249 | ) |  | — |  |  | (1 | ) |  | 23 |  |  | (227 | ) |
| Other income, net | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total interest and other income (expense), net | (249 | ) |  | 28 |  |  | 23 |  |  | — |  |  | (198 | ) |
| Income (loss) before taxes | (257 | ) |  | 562 |  |  | (751 | ) |  | 169 |  |  | (277 | ) |
| Equity in earnings from subsidiaries | (206 | ) |  | (844 | ) |  | — |  |  | 1,050 |  |  | — |  |
| Income tax expense (benefit) | (48 | ) |  | 94 |  |  | 92 |  |  | — |  |  | 138 |  |
| Net loss | $ | (415 | ) |  | $ | (376 | ) |  | $ | (843 | ) |  | $ | 1,219 |  |  | $ | (415 | ) |

[0000106040-20-000011:notes:172]
| Condensed Consolidating Statement of Operations |
| For the three months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,392 |  |  | $ | 4,857 |  |  | $ | (4,016 | ) |  | $ | 4,233 |  |
| Cost of revenue | — |  |  | 2,942 |  |  | 4,215 |  |  | (3,968 | ) |  | 3,189 |  |
| Gross profit | — |  |  | 450 |  |  | 642 |  |  | (48 | ) |  | 1,044 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 334 |  |  | 205 |  |  | — |  |  | 539 |  |
| Selling, general and administrative | — |  |  | 214 |  |  | 95 |  |  | — |  |  | 309 |  |
| Intercompany operating expense (income) | — |  |  | (347 | ) |  | 347 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 6 |  |  | 14 |  |  | — |  |  | 20 |  |
| Total operating expenses | — |  |  | 207 |  |  | 661 |  |  | — |  |  | 868 |  |
| Operating income (loss) | — |  |  | 243 |  |  | (19 | ) |  | (48 | ) |  | 176 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | 4 |  |  | 12 |  |  | (3 | ) |  | 15 |  |
| Interest expense | (118 | ) |  | (2 | ) |  | (1 | ) |  | 3 |  |  | (118 | ) |
| Other income (expense), net | — |  |  | (2 | ) |  | 8 |  |  | 2 |  |  | 8 |  |
| Total interest and other income (expense), net | (116 | ) |  | — |  |  | 19 |  |  | 2 |  |  | (95 | ) |
| Income (loss) before taxes | (116 | ) |  | 243 |  |  | — |  |  | (46 | ) |  | 81 |  |
| Equity in earnings from subsidiaries | (468 | ) |  | (133 | ) |  | — |  |  | 601 |  |  | — |  |
| Income tax expense (benefit) | (97 | ) |  | 532 |  |  | 133 |  |  | — |  |  | 568 |  |
| Net loss | $ | (487 | ) |  | $ | (422 | ) |  | $ | (133 | ) |  | $ | 555 |  |  | $ | (487 | ) |

[0000106040-20-000011:notes:173]
| Condensed Consolidating Statement of Operations |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 6,877 |  |  | $ | 9,853 |  |  | $ | (7,469 | ) |  | $ | 9,261 |  |
| Cost of revenue | — |  |  | 5,947 |  |  | 8,039 |  |  | (7,433 | ) |  | 6,553 |  |
| Gross profit | — |  |  | 930 |  |  | 1,814 |  |  | (36 | ) |  | 2,708 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 697 |  |  | 418 |  |  | — |  |  | 1,115 |  |
| Selling, general and administrative | 1 |  |  | 465 |  |  | 199 |  |  | — |  |  | 665 |  |
| Intercompany operating expense (income) | — |  |  | (754 | ) |  | 754 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 38 |  |  | 28 |  |  | — |  |  | 66 |  |
| Total operating expenses | 1 |  |  | 446 |  |  | 1,399 |  |  | — |  |  | 1,846 |  |
| Operating income (loss) | (1 | ) |  | 484 |  |  | 415 |  |  | (36 | ) |  | 862 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 7 |  |  | 24 |  |  | (11 | ) |  | 30 |  |
| Interest expense | (234 | ) |  | (8 | ) |  | (3 | ) |  | 11 |  |  | (234 | ) |
| Other income (expense), net | 1 |  |  | (2 | ) |  | 7 |  |  | — |  |  | 6 |  |
| Total interest and other income (expense), net | (223 | ) |  | (3 | ) |  | 28 |  |  | — |  |  | (198 | ) |
| Income (loss) before taxes | (224 | ) |  | 481 |  |  | 443 |  |  | (36 | ) |  | 664 |  |
| Equity in earnings from subsidiaries | 7 |  |  | 212 |  |  | — |  |  | (219 | ) |  | — |  |
| Income tax expense (benefit) | (241 | ) |  | 650 |  |  | 231 |  |  | — |  |  | 640 |  |
| Net income | $ | 24 |  |  | $ | 43 |  |  | $ | 212 |  |  | $ | (255 | ) |  | $ | 24 |  |

[0000106040-20-000011:notes:174]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (139 | ) |  | $ | (156 | ) |  | $ | (384 | ) |  | $ | 540 |  |  | $ | (139 | ) |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 2 |  |  | 2 |  |  | 2 |  |  | (4 | ) |  | 2 |  |
| Foreign currency translation adjustment | (15 | ) |  | (13 | ) |  | (13 | ) |  | 26 |  |  | (15 | ) |
| Net unrealized loss, on derivative contracts and available-for-sale securities | (6 | ) |  | (26 | ) |  | (14 | ) |  | 40 |  |  | (6 | ) |
| Total other comprehensive loss, before tax | (19 | ) |  | (37 | ) |  | (25 | ) |  | 62 |  |  | (19 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | (1 | ) |  | 4 |  |  | 1 |  |  | (5 | ) |  | (1 | ) |
| Other comprehensive loss, net of tax | (20 | ) |  | (33 | ) |  | (24 | ) |  | 57 |  |  | (20 | ) |
| Total comprehensive loss | $ | (159 | ) |  | $ | (189 | ) |  | $ | (408 | ) |  | $ | 597 |  |  | $ | (159 | ) |

[0000106040-20-000011:notes:175]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (415 | ) |  | $ | (376 | ) |  | $ | (843 | ) |  | $ | 1,219 |  |  | $ | (415 | ) |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 3 |  |  | 3 |  |  | 3 |  |  | (6 | ) |  | 3 |  |
| Foreign currency translation adjustment | (10 | ) |  | (8 | ) |  | (8 | ) |  | 16 |  |  | (10 | ) |
| Net unrealized loss, on derivative contracts and available-for-sale securities | (39 | ) |  | (34 | ) |  | (23 | ) |  | 57 |  |  | (39 | ) |
| Total other comprehensive loss, before tax | (46 | ) |  | (39 | ) |  | (28 | ) |  | 67 |  |  | (46 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | 4 |  |  | 3 |  |  | — |  |  | (3 | ) |  | 4 |  |
| Other comprehensive loss, net of tax | (42 | ) |  | (36 | ) |  | (28 | ) |  | 64 |  |  | (42 | ) |
| Total comprehensive loss | $ | (457 | ) |  | $ | (412 | ) |  | $ | (871 | ) |  | $ | 1,283 |  |  | $ | (457 | ) |

[0000106040-20-000011:notes:176]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | (487 | ) |  | $ | (422 | ) |  | $ | (133 | ) |  | $ | 555 |  |  | $ | (487 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 31 |  |  | 32 |  |  | 32 |  |  | (64 | ) |  | 31 |  |
| Net unrealized gain, on derivative contracts and available-for-sale securities | 7 |  |  | 30 |  |  | 30 |  |  | (60 | ) |  | 7 |  |
| Total other comprehensive income, before tax | 39 |  |  | 63 |  |  | 63 |  |  | (126 | ) |  | 39 |  |
| Income tax benefit (expense) related to items of other comprehensive income | 3 |  |  | (2 | ) |  | (2 | ) |  | 3 |  |  | 2 |  |
| Other comprehensive income, net of tax | 42 |  |  | 61 |  |  | 61 |  |  | (123 | ) |  | 41 |  |
| Total comprehensive loss | $ | (445 | ) |  | $ | (361 | ) |  | $ | (72 | ) |  | $ | 432 |  |  | $ | (446 | ) |

[0000106040-20-000011:notes:177]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 24 |  |  | $ | 43 |  |  | $ | 212 |  |  | $ | (255 | ) |  | $ | 24 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | (6 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (6 | ) |
| Net unrealized gain, on derivative contracts and available-for-sale securities | 6 |  |  | 22 |  |  | 20 |  |  | (42 | ) |  | 6 |  |
| Total other comprehensive income, before tax | 1 |  |  | 21 |  |  | 19 |  |  | (40 | ) |  | 1 |  |
| Income tax benefit (expense) related to items of other comprehensive income | 4 |  |  | (2 | ) |  | (1 | ) |  | 2 |  |  | 3 |  |
| Other comprehensive income, net of tax | 5 |  |  | 19 |  |  | 18 |  |  | (38 | ) |  | 4 |  |
| Total comprehensive income | $ | 29 |  |  | $ | 62 |  |  | $ | 230 |  |  | $ | (293 | ) |  | $ | 28 |  |

[0000106040-20-000011:notes:178]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended January 3, 2020 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (24 | ) |  | $ | 499 |  |  | $ | (125 | ) |  | $ | 160 |  |  | $ | 510 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (84 | ) |  | (221 | ) |  | — |  |  | (305 | ) |
| Acquisitions, net of cash acquired | — |  |  | (2 | ) |  | (20 | ) |  | — |  |  | (22 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (224 | ) |  | — |  |  | (224 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 690 |  |  | — |  |  | 690 |  |
| Strategic investments and other, net | — |  |  | 6 |  |  | 15 |  |  | — |  |  | 21 |  |
| Intercompany loan from (to) consolidated affiliates | — |  |  | (952 | ) |  | (208 | ) |  | 1,160 |  |  | — |  |
| Advances from (to) parent and consolidated affiliates | (71 | ) |  | 71 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | (71 | ) |  | (961 | ) |  | 32 |  |  | 1,160 |  |  | 160 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 72 |  |  | — |  |  | — |  |  | — |  |  | 72 |  |
| Taxes paid on vested stock awards under employee stock plans | (54 | ) |  | — |  |  | — |  |  | — |  |  | (54 | ) |
| Dividends paid to shareholders | (296 | ) |  | — |  |  | — |  |  | — |  |  | (296 | ) |
| Repayment of debt | (707 | ) |  | — |  |  | — |  |  | — |  |  | (707 | ) |
| Intercompany loan from (to) consolidated affiliates | 929 |  |  | 208 |  |  | 23 |  |  | (1,160 | ) |  | — |  |
| Change in investment in consolidated subsidiaries | 154 |  |  | 55 |  |  | (49 | ) |  | (160 | ) |  | — |  |
| Net cash provided by (used in) financing activities | 98 |  |  | 263 |  |  | (26 | ) |  | (1,320 | ) |  | (985 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | 3 |  |  | (199 | ) |  | (122 | ) |  | — |  |  | (318 | ) |
| Cash and cash equivalents, beginning of year | 8 |  |  | 985 |  |  | 2,462 |  |  | — |  |  | 3,455 |  |
| Cash and cash equivalents, end of period | $ | 11 |  |  | $ | 786 |  |  | $ | 2,340 |  |  | $ | — |  |  | $ | 3,137 |  |

[0000106040-20-000011:notes:179]
| Condensed Consolidating Statement of Cash Flows |
| For the six months ended December 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 103 |  |  | $ | (819 | ) |  | $ | 1,934 |  |  | $ | (44 | ) |  | $ | 1,174 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (129 | ) |  | (371 | ) |  | — |  |  | (500 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Purchases of investments | — |  |  | (11 | ) |  | (22 | ) |  | — |  |  | (33 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (508 | ) |  | — |  |  | (508 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 312 |  |  | — |  |  | 312 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | (18 | ) |  | — |  |  | (19 | ) |
| Intercompany loan from (to) consolidated affiliates | 943 |  |  | (370 | ) |  | — |  |  | (573 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (215 | ) |  | 215 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 728 |  |  | (296 | ) |  | (584 | ) |  | (573 | ) |  | (725 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |
| Taxes paid on vested stock awards under employee stock plans | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Dividends paid to shareholders | (292 | ) |  | — |  |  | — |  |  | — |  |  | (292 | ) |
| Repayment of debt | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Proceeds from (repayment of) revolving credit facility | (500 | ) |  | — |  |  | — |  |  | — |  |  | (500 | ) |
| Intercompany loan from (to) consolidated affiliates | 370 |  |  | (387 | ) |  | (556 | ) |  | 573 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 214 |  |  | 1,997 |  |  | (2,255 | ) |  | 44 |  |  | — |  |
| Net cash provided by (used in) financing activities | (854 | ) |  | 1,610 |  |  | (2,811 | ) |  | 617 |  |  | (1,438 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | (23 | ) |  | 495 |  |  | (1,464 | ) |  | — |  |  | (992 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | $ | 17 |  |  | $ | 1,163 |  |  | $ | 2,833 |  |  | $ | — |  |  | $ | 4,013 |  |
