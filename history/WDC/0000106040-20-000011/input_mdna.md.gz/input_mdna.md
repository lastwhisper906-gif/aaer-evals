# WDC MD&A — 0000106040-20-000011


## mdna

[0000106040-20-000011:mdna:1]
[same as prior period, unchanged from 0000106040-19-000075:mdna:1]

[0000106040-20-000011:mdna:2]
[same as prior period, unchanged from 0000106040-19-000075:mdna:2]

[0000106040-20-000011:mdna:3]
[same as prior period, unchanged from 0000106040-19-000075:mdna:3]

[0000106040-20-000011:mdna:4]
[same as prior period, unchanged from 0000106040-19-000075:mdna:4]

[0000106040-20-000011:mdna:5]
[same as prior period, unchanged from 0000106040-19-000075:mdna:5]

[0000106040-20-000011:mdna:6]
[same as prior period, unchanged from 0000106040-19-000075:mdna:6]

[0000106040-20-000011:mdna:7]
[same as prior period, unchanged from 0000106040-19-000075:mdna:7]

[0000106040-20-000011:mdna:8]
[same as prior period, unchanged from 0000106040-19-000075:mdna:8]

[0000106040-20-000011:mdna:9]
Through our three business ventures with Kioxia Corporation (“Kioxia”), referred to as “Flash Ventures”, we and Kioxia operate flash-based memory wafer manufacturing facilities in Japan. We are obligated to pay for variable costs incurred in producing our share of Flash Ventures’ flash-based memory wafer supply, based on our three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, we are obligated to pay for half of Flash Ventures’ fixed costs regardless of the output we choose to purchase. We are also obligated to fund 49.9% to 50% of Flash Ventures’ capital investments to the extent that Flash Ventures’ operating cash flow is insufficient to fund these investments.

[0000106040-20-000011:mdna:10]
Since its inception, Flash Ventures has been based in a manufacturing site in Yokkaichi, Japan, which currently includes five wafer fabrication facilities. Production levels at the Yokkaichi site were temporarily reduced as a result of an unexpected power outage incident that occurred in the Yokkaichi region on June 15, 2019. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production. The incident resulted in a reduction of our flash wafer availability by approximately 4 exabytes, the majority of which was contained in the first quarter of fiscal year 2020. As a result of this power outage incident, we incurred aggregate charges of $68 million and $145 million recorded in Cost of revenue in the quarters ended October 4, 2019 and June 28, 2019, respectively, which primarily consisted of the write-off of damaged inventory and unabsorbed manufacturing overhead costs. We are pursuing recovery of our losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

[0000106040-20-000011:mdna:11]
In May 2019, we entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the second half of fiscal year 2020, although meaningful output from K1 is not expected to begin until the first half of fiscal year 2021. Our share of the initial commitment for K1 is expected to result in equipment investments, relocation costs and start-up costs totaling approximately $660 million, of which $500 million is still expected to be incurred primarily through the second half of fiscal year 2020. We also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 3, 2020, remaining committed prepayments totaled $265 million.

[0000106040-20-000011:mdna:12]
[same as prior period, unchanged from 0000106040-19-000075:mdna:12]

[0000106040-20-000011:mdna:13]
In September 2019, we announced the sale of our IntelliFlash business and our strategic intention to exit Storage Systems, which consists of IntelliFlash and ActiveScale. These actions will allow us to redirect investments to other higher value priorities. In November 2019, the Company completed its sale of IntelliFlash for a price of $28 million, to be collected over the next three years. The sale of our IntelliFlash business included an immaterial amount of inventory, other tangible and intangible assets, and goodwill and resulted in a gain of approximately $17 million recorded in Employee termination, asset impairment, and other charges in the Condensed Consolidated Statements of Operations for both the three and six months ended January 3, 2020. Additionally, in February 2020, we entered into an agreement for the sale of ActiveScale.  The net assets sold and the proceeds from the sale of ActiveScale were not material.

[0000106040-20-000011:mdna:14]
[same as prior period, unchanged from 0000106040-19-000075:mdna:14]

[0000106040-20-000011:mdna:15]
Second Quarter and First Half Overview

[0000106040-20-000011:mdna:16]
[same as prior period, unchanged from 0000106040-19-000075:mdna:16]

[0000106040-20-000011:mdna:17]
|  | Three Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | $ Change |  | % Change |
|  | ($ in millions) |
| Revenue, net | $ | 4,234 |  |  | 100.0 | % |  | $ | 4,233 |  |  | 100.0 | % |  | $ | 1 |  |  | — | % |
| Cost of revenue | 3,299 |  |  | 77.9 |  |  | 3,189 |  |  | 75.3 |  |  | 110 |  |  | 3 |  |
| Gross profit | 935 |  |  | 22.1 |  |  | 1,044 |  |  | 24.7 |  |  | (109 | ) |  | (10 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 578 |  |  | 13.7 |  |  | 539 |  |  | 12.7 |  |  | 39 |  |  | 7 |  |
| Selling, general and administrative | 298 |  |  | 7.0 |  |  | 309 |  |  | 7.3 |  |  | (11 | ) |  | (4 | ) |
| Employee termination, asset impairment, and other charges | 9 |  |  | 0.2 |  |  | 20 |  |  | 0.5 |  |  | (11 | ) |  | (55 | ) |
| Total operating expenses | 885 |  |  | 20.9 |  |  | 868 |  |  | 20.5 |  |  | 17 |  |  | 2 |  |
| Operating income (loss) | 50 |  |  | 1.2 |  |  | 176 |  |  | 4.2 |  |  | (126 | ) |  | (72 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 8 |  |  | 0.2 |  |  | 15 |  |  | 0.4 |  |  | (7 | ) |  | (47 | ) |
| Interest expense | (105 | ) |  | (2.5 | ) |  | (118 | ) |  | (2.8 | ) |  | 13 |  |  | (11 | ) |
| Other income (expense), net | 7 |  |  | 0.2 |  |  | 8 |  |  | 0.2 |  |  | (1 | ) |  | (13 | ) |
| Total interest and other expense, net | (90 | ) |  | (2.1 | ) |  | (95 | ) |  | (2.2 | ) |  | 5 |  |  | (5 | ) |
| Income (loss) before taxes | (40 | ) |  | (0.9 | ) |  | 81 |  |  | 1.9 |  |  | (121 | ) |  | (149 | ) |
| Income tax expense | 99 |  |  | 2.3 |  |  | 568 |  |  | 13.4 |  |  | (469 | ) |  | (83 | ) |
| Net income (loss) | $ | (139 | ) |  | (3.3 | ) |  | $ | (487 | ) |  | (11.5 | ) |  | 348 |  |  | (71 | ) |

[0000106040-20-000011:mdna:18]
[same as prior period, unchanged from 0000106040-19-000075:mdna:18]

[0000106040-20-000011:mdna:19]
|  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | $ Change |  | % Change |
|  | ($ in millions) |
| Revenue, net | $ | 8,274 |  |  | 100.0 | % |  | $ | 9,261 |  |  | 100.0 | % |  | $ | (987 | ) |  | (11 | )% |
| Cost of revenue | 6,581 |  |  | 79.5 |  |  | 6,553 |  |  | 70.8 |  |  | 28 |  |  | — |  |
| Gross profit | 1,693 |  |  | 20.5 |  |  | 2,708 |  |  | 29.2 |  |  | (1,015 | ) |  | (37 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,152 |  |  | 13.9 |  |  | 1,115 |  |  | 12.0 |  |  | 37 |  |  | 3 |  |
| Selling, general and administrative | 603 |  |  | 7.3 |  |  | 665 |  |  | 7.2 |  |  | (62 | ) |  | (9 | ) |
| Employee termination, asset impairment, and other charges | 17 |  |  | 0.2 |  |  | 66 |  |  | 0.7 |  |  | (49 | ) |  | (74 | ) |
| Total operating expenses | 1,772 |  |  | 21.4 |  |  | 1,846 |  |  | 19.9 |  |  | (74 | ) |  | (4 | ) |
| Operating income (loss) | (79 | ) |  | (1.0 | ) |  | 862 |  |  | 9.3 |  |  | (941 | ) |  | (109 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 20 |  |  | 0.2 |  |  | 30 |  |  | 0.3 |  |  | (10 | ) |  | (33 | ) |
| Interest expense | (227 | ) |  | (2.7 | ) |  | (234 | ) |  | (2.5 | ) |  | 7 |  |  | (3 | ) |
| Other income (expense), net | 9 |  |  | 0.1 |  |  | 6 |  |  | 0.1 |  |  | 3 |  |  | 50 |  |
| Total interest and other expense, net | (198 | ) |  | (2.4 | ) |  | (198 | ) |  | (2.1 | ) |  | — |  |  | — |  |
| Income (loss) before taxes | (277 | ) |  | (3.3 | ) |  | 664 |  |  | 7.2 |  |  | (941 | ) |  | (142 | ) |
| Income tax expense | 138 |  |  | 1.7 |  |  | 640 |  |  | 6.9 |  |  | (502 | ) |  | (78 | ) |
| Net income (loss) | $ | (415 | ) |  | (5.0 | ) |  | $ | 24 |  |  | 0.3 |  |  | (439 | ) |  | (1,829 | ) |

[0000106040-20-000011:mdna:20]
| (1) | Percentages may not total due to rounding. |

[0000106040-20-000011:mdna:21]
[same as prior period, unchanged from 0000106040-19-000075:mdna:20]

[0000106040-20-000011:mdna:22]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,396 |  |  | $ | 2,060 |  |  | $ | 4,804 |  |  | $ | 4,554 |  |
| Flash-based | 1,838 |  |  | 2,173 |  |  | 3,470 |  |  | 4,707 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,797 |  |  | $ | 2,214 |  |  | $ | 3,413 |  |  | $ | 4,864 |  |
| Data Center Devices & Solutions | 1,489 |  |  | 1,074 |  |  | 3,021 |  |  | 2,520 |  |
| Client Solutions | 948 |  |  | 945 |  |  | 1,840 |  |  | 1,877 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Americas | $ | 1,296 |  |  | $ | 1,015 |  |  | $ | 2,609 |  |  | $ | 2,296 |  |
| Europe, Middle East and Africa | 811 |  |  | 817 |  |  | 1,590 |  |  | 1,701 |  |
| Asia | 2,127 |  |  | 2,401 |  |  | 4,075 |  |  | 5,264 |  |
| Total Revenue | $ | 4,234 |  |  | $ | 4,233 |  |  | $ | 8,274 |  |  | $ | 9,261 |  |

[0000106040-20-000011:mdna:23]
50

[0000106040-20-000011:mdna:24]
[same as prior period, unchanged from 0000106040-19-000075:mdna:22]

[0000106040-20-000011:mdna:25]
Net revenue was essentially flat in the three months ended January 3, 2020 from the comparable period in the prior year. Higher volumes of memory for HDD and flash products contributed approximately 20 and 9 percentage points of growth, respectively, which were largely offset by lower average selling prices. Client Devices revenue decreased 19% year over year, due to lower average selling prices, predominantly in flash products, which drove 33 percentage points of the decrease. The decrease in Client Devices revenue was partially offset by higher volumes of flash and HDD memory, which contributed approximately 10 and 4 percentage points of growth, respectively.  Our revenue for Data Center Devices and Solutions increased 39% year over year, with volumes essentially doubling due to strength in both capacity enterprise HDD and SSD, partially offset by lower average selling prices with more efficient form factors. Client Solutions revenue was relatively flat year over year, with higher volumes of HDD and flash products contributing approximately 7 and 19 percentage points of growth, respectively, which were largely offset by lower average selling prices. While pricing for flash products remains down compared to the prior year, pricing has stabilized compared to last quarter and we expect flash pricing to improve during fiscal 2020, if supply and demand become more closely aligned as expected.

[0000106040-20-000011:mdna:26]
Net revenue decreased $987 million, or 11%, in the six months ended January 3, 2020 from the comparable period in the prior year.  Lower average selling prices generated approximately 32 percentage points of the year-over-year decline, with the majority of that decline attributed to flash-based products. This decline was partially offset by growth in HDD and flash products volumes, with higher HDD volumes contributing approximately 15 percentage points of growth and higher volumes of flash products contributing approximately 5 percentage points of growth. Client Devices revenue decreased 30% year over year, with approximately 32 percentage points due to lower average selling prices, predominantly related to flash products, partially offset by slightly higher volumes for flash products. Our revenue for Data Center Devices and Solutions increased 20% year over year, resulting from an approximately 27 percentage points of growth in volume of memory, primarily driven by strength in capacity enterprise HDD, partially offset by lower average selling prices in flash products. Client Solutions revenue decreased 2% year over year, which predominantly reflects lower prices on retail products.

[0000106040-20-000011:mdna:27]
The changes in net revenue by geography reflect a decrease in Asia primarily driven by our decision to limit our participation in the mobile market resulting in lower sales to manufacturers in the Asia region and a slight increase in the Americas driven by increased sales of capacity enterprise HDD.

[0000106040-20-000011:mdna:28]
The Company’s top 10 customers accounted for 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively, and 47% of its net revenue for both the three and six months ended December 28, 2018.  For the three and six months ended January 3, 2020 and December 28, 2018, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-20-000011:mdna:29]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and six months ended January 3, 2020, these programs represented 17% and 16%, respectively, of gross revenues. For the three and six months ended December 28, 2018, these programs represented 16% and 14%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-20-000011:mdna:30]
[same as prior period, unchanged from 0000106040-19-000075:mdna:27]

[0000106040-20-000011:mdna:31]
Substantially all of the decrease in Gross profit for both the three and six months ended January 3, 2020 from the comparable periods in the prior year was due to the lower average selling prices noted above, partially offset by lower aggregate charges for amortization expense on acquired intangible assets, manufacturing underutilization charges, and charges related to the power outage incident. These charges aggregated $157 million and $264 million for the three-month periods ended January 3, 2020 and December 28, 2018, respectively, and $389 million and $499 million, respectively, for the six-month periods then ended. Gross margin declined 3 and 9 percentage points for the three and six months ended January 3, 2020, respectively, from the comparable periods in the prior year, with substantially all of the decline attributable to the lower average selling prices noted above, partially offset by cost reductions in our manufacturing processes.

[0000106040-20-000011:mdna:32]
[same as prior period, unchanged from 0000106040-19-000075:mdna:29]

[0000106040-20-000011:mdna:33]
Research and development (“R&D”) expense increased $39 million for the three months ended January 3, 2020 from the comparable period in the prior year primarily due to increased variable compensation, partially offset by savings from our cost reduction actions. R&D expense increased $37 million for the six months ended January 3, 2020 from the comparable period in the prior year primarily due to approximately $30 million of additional expense related to the additional week in the current year.

[0000106040-20-000011:mdna:34]
Selling, general and administrative (“SG&A”) expense decreased $11 million for the three months ended January 3, 2020 from the comparable period in the prior year primarily due to savings realized from our cost reduction actions. SG&A expense decreased $62 million for the six months ended January 3, 2020 from the comparable period in the prior year primarily due to savings realized from our cost reduction actions, partially offset by approximately $10 million of additional expense related to the additional week in the current year.

[0000106040-20-000011:mdna:35]
Employee termination, asset impairment and other charges decreased from the comparable periods in the prior year as many of the actions initiated in the prior year have been substantially completed. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000011:mdna:36]
[same as prior period, unchanged from 0000106040-19-000075:mdna:33]

[0000106040-20-000011:mdna:37]
The decreases in total interest and other expense, net for both the three and six months ended January 3, 2020 primarily reflect decreases in interest expense resulting from the pay-down of principal on our debt and lower index rates, partially offset by decreases in Interest income resulting from lower invested cash.

[0000106040-20-000011:mdna:38]
[same as prior period, unchanged from 0000106040-19-000075:mdna:35]

[0000106040-20-000011:mdna:39]
The Tax Cuts and Jobs Act (the “2017 Act”) includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-20-000011:mdna:40]
[same as prior period, unchanged from 0000106040-19-000075:mdna:37]

[0000106040-20-000011:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions, except percentages) |  | (in millions, except percentages) |
| Income (loss) before taxes | $ | (40 | ) |  | $ | 81 |  |  | $ | (277 | ) |  | $ | 664 |  |
| Income tax expense (benefit) | 99 |  |  | 568 |  |  | 138 |  |  | 640 |  |
| Effective tax rate | (248 | )% |  | 701 | % |  | (50 | )% |  | 96 | % |

[0000106040-20-000011:mdna:42]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2020 through 2030. In addition, the effective tax rate for the six months ended January 3, 2020 includes the discrete effect of a de-recognition of $33 million for certain deferred tax assets associated with creditable foreign withholding taxes due to the issuance of final regulatory guidance. The regulatory guidance does not preclude us from potentially claiming these creditable taxes as a period benefit when paid.

[0000106040-20-000011:mdna:43]
52

[0000106040-20-000011:mdna:44]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended December 28, 2018, these discrete effects consist of $230 million related to the mandatory deemed repatriation tax and $134 million related to the decision to change our indefinite reinvestment assertion. For the six months ended December 28, 2018, these discrete effects consist of $178 million related to the mandatory deemed repatriation tax and $144 million related to the decision to change our indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to the changes in the relative mix of our U.S. earnings compared to foreign earnings.

[0000106040-20-000011:mdna:45]
[same as prior period, unchanged from 0000106040-19-000075:mdna:41]

[0000106040-20-000011:mdna:46]
For additional information regarding Income tax expense (benefit), see Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000011:mdna:47]
[same as prior period, unchanged from 0000106040-19-000075:mdna:43]

[0000106040-20-000011:mdna:48]
[same as prior period, unchanged from 0000106040-19-000075:mdna:44]

[0000106040-20-000011:mdna:49]
|  | Six Months Ended |
|  | January 3, 2020 |  | December 28, 2018 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 510 |  |  | $ | 1,174 |  |
| Investing activities | 160 |  |  | (725 | ) |
| Financing activities | (985 | ) |  | (1,438 | ) |
| Effect of exchange rate changes on cash | (3 | ) |  | (3 | ) |
| Net decrease in cash and cash equivalents | $ | (318 | ) |  | $ | (992 | ) |

[0000106040-20-000011:mdna:50]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q.

[0000106040-20-000011:mdna:51]
During fiscal 2020, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate between $2.0 billion and $2.5 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and cash flow from operations, we expect the Flash Ventures to continue to return cash to our company through net payments on our notes receivable during the remainder of fiscal 2020. As such, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be close to zero. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-20-000011:mdna:52]
A total of $2.28 billion and $2.37 billion of our Cash and cash equivalents was held outside of the U.S. as of January 3, 2020 and June 28, 2019, respectively. During fiscal 2019, the IRS issued interpretative guidance affecting the taxation of a certain portion of our foreign undistributed earnings, which could result in additional federal taxes. After consideration of this interpretative guidance, we made the determination that we do not intend to repatriate this portion of our foreign undistributed earnings and did not establish an accrual for this liability.

[0000106040-20-000011:mdna:53]
[same as prior period, unchanged from 0000106040-19-000075:mdna:49]

[0000106040-20-000011:mdna:54]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash provided by changes in operating assets and liabilities was $20 million for the six months ended January 3, 2020, as compared to $298 million net cash used for changes in operating assets and liabilities for the six months ended December 28, 2018. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-20-000011:mdna:55]
|  | Three Months Ended |
|  | January 3,2020 |  | December 28,2018 |
|  | (in days) |
| Days sales outstanding | 38 |  |  | 37 |  |
| Days in inventory | 86 |  |  | 98 |  |
| Days payables outstanding | (58 | ) |  | (64 | ) |
| Cash conversion cycle | 66 |  |  | 71 |  |

[0000106040-20-000011:mdna:56]
[same as prior period, unchanged from 0000106040-19-000075:mdna:52]

[0000106040-20-000011:mdna:57]
For the three months ended January 3, 2020, DSOs increased by 1 day over the prior year, primarily reflecting the timing of shipments and customer collections. DIOs decreased by 12 days over the prior year, primarily reflecting reduced levels of HDD inventory. DPOs decreased by 6 days over the prior year, primarily reflecting resumptions of normal flash production volumes as well as routine variations in the timing of purchases and payments during the period.

[0000106040-20-000011:mdna:58]
[same as prior period, unchanged from 0000106040-19-000075:mdna:54]

[0000106040-20-000011:mdna:59]
Net cash provided by investing activities for the six months ended January 3, 2020 primarily consisted of a $466 million net decrease in notes receivable issuances to Flash Ventures, partially offset by $305 million of capital expenditures and $22 million for acquisitions. Net cash used in investing activities for the six months ended December 28, 2018 primarily consisted of $500 million of capital expenditures and a net $196 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion.

[0000106040-20-000011:mdna:60]
[same as prior period, unchanged from 0000106040-19-000075:mdna:56]

[0000106040-20-000011:mdna:61]
[same as prior period, unchanged from 0000106040-19-000075:mdna:57]

[0000106040-20-000011:mdna:62]
During the six months ended January 3, 2020, net cash used in financing activities primarily consisted of $707 million for repayment of debt, $296 million to pay dividends on our common stock and $54 million for taxes paid on vested stock awards under employee stock plans.  Net cash used in financing activities for the six months ended December 28, 2018 primarily consisted of $575 million for the repayment of our revolving credit facility and other debt, $563 million for share repurchases and $292 million to pay dividends on our common stock. In the near term, we may use available cash on hand and cash from operations to further reduce our debt.  In this regard, on January 31, 2020, we made an incremental voluntary prepayment of $150 million on our Term Loan B-4.

[0000106040-20-000011:mdna:63]
[same as prior period, unchanged from 0000106040-19-000075:mdna:59]

[0000106040-20-000011:mdna:64]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000011:mdna:65]
[same as prior period, unchanged from 0000106040-19-000075:mdna:61]

[0000106040-20-000011:mdna:66]
[same as prior period, unchanged from 0000106040-19-000075:mdna:62]

[0000106040-20-000011:mdna:67]
The following is a summary of our known contractual cash obligations and commercial commitments as of January 3, 2020:

[0000106040-20-000011:mdna:68]
|  | Total |  | 1 Year (Remaining 6 months of 2020) |  | 2-3 Years (2021-2022) |  | 4-5 Years (2023-2024) |  | More than 5 Years (Beyond 2024) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 9,986 |  |  | $ | 126 |  |  | $ | 537 |  |  | $ | 7,023 |  |  | $ | 2,300 |  |
| Interest on debt | 1,526 |  |  | 182 |  |  | 716 |  |  | 409 |  |  | 219 |  |
| Flash Ventures related commitments(2) | 5,939 |  |  | 1,542 |  |  | 2,963 |  |  | 1,222 |  |  | 212 |  |
| Operating leases | 321 |  |  | 26 |  |  | 75 |  |  | 52 |  |  | 168 |  |
| Purchase obligations and other commitments | 3,278 |  |  | 1,604 |  |  | 748 |  |  | 588 |  |  | 338 |  |
| Mandatory Deemed Repatriation Tax | 1,056 |  |  | 14 |  |  | 199 |  |  | 285 |  |  | 558 |  |
| Total | $ | 22,106 |  |  | $ | 3,494 |  |  | $ | 5,238 |  |  | $ | 9,579 |  |  | $ | 3,795 |  |

[0000106040-20-000011:mdna:69]
[same as prior period, unchanged from 0000106040-19-000075:mdna:65]

[0000106040-20-000011:mdna:70]
[same as prior period, unchanged from 0000106040-19-000075:mdna:66]

[0000106040-20-000011:mdna:71]
[same as prior period, unchanged from 0000106040-19-000075:mdna:67]

[0000106040-20-000011:mdna:72]
Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2019.  The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio.  As of January 3, 2020, we were in compliance with these financial covenants.

[0000106040-20-000011:mdna:73]
[same as prior period, unchanged from 0000106040-19-000075:mdna:69]

[0000106040-20-000011:mdna:74]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of January 3, 2020, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-20-000011:mdna:75]
[same as prior period, unchanged from 0000106040-19-000075:mdna:71]

[0000106040-20-000011:mdna:76]
[same as prior period, unchanged from 0000106040-19-000075:mdna:72]

[0000106040-20-000011:mdna:77]
[same as prior period, unchanged from 0000106040-19-000075:mdna:74]

[0000106040-20-000011:mdna:78]
[same as prior period, unchanged from 0000106040-19-000075:mdna:75]

[0000106040-20-000011:mdna:79]
|  |  | January 3, 2020 |
| Remaining six months of 2020 |  | $ | 14 |  |
| 2021 |  | 99 |  |
| 2022 |  | 100 |  |
| 2023 |  | 99 |  |
| 2024 |  | 186 |  |
| 2025 |  | 248 |  |
| 2026 |  | 310 |  |
| Total |  | $ | 1,056 |  |

[0000106040-20-000011:mdna:80]
[same as prior period, unchanged from 0000106040-19-000075:mdna:77]

[0000106040-20-000011:mdna:81]
[same as prior period, unchanged from 0000106040-19-000075:mdna:78]

[0000106040-20-000011:mdna:82]
As of January 3, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $696 million. Accrued interest and penalties related to unrecognized tax benefits as of January 3, 2020 was approximately $131 million. Of these amounts, approximately $708 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-20-000011:mdna:83]
[same as prior period, unchanged from 0000106040-19-000075:mdna:80]

[0000106040-20-000011:mdna:84]
We have generally held a balance of fixed and variable rate debt. At January 3, 2020, we had $6.55 billion of variable rate debt, comprising 66% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $4.55 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual expense by $46 million.

[0000106040-20-000011:mdna:85]
[same as prior period, unchanged from 0000106040-19-000075:mdna:82]

[0000106040-20-000011:mdna:86]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 1, Note 6, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000011:mdna:87]
[same as prior period, unchanged from 0000106040-19-000075:mdna:84]

[0000106040-20-000011:mdna:88]
[same as prior period, unchanged from 0000106040-19-000075:mdna:85]

[0000106040-20-000011:mdna:89]
[same as prior period, unchanged from 0000106040-19-000075:mdna:86]

[0000106040-20-000011:mdna:90]
[same as prior period, unchanged from 0000106040-19-000075:mdna:87]

[0000106040-20-000011:mdna:91]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of our common stock, which authorization is effective through July 25, 2023. For the six months ended January 3, 2020, we did not make any stock repurchases. The remaining amount available to be repurchased under our current stock repurchase program as of January 3, 2020 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows.

[0000106040-20-000011:mdna:92]
[same as prior period, unchanged from 0000106040-19-000075:mdna:89]

[0000106040-20-000011:mdna:93]
Since the first quarter of 2013, we have issued a quarterly cash dividend. During the six months ended January 3, 2020, we declared aggregate cash dividends of $1.00 per share on our outstanding common stock totaling $298 million, of which $149 million was paid on January 21, 2020. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-20-000011:mdna:94]
[same as prior period, unchanged from 0000106040-19-000075:mdna:91]

[0000106040-20-000011:mdna:95]
[same as prior period, unchanged from 0000106040-19-000075:mdna:92]

[0000106040-20-000011:mdna:96]
[same as prior period, unchanged from 0000106040-19-000075:mdna:93]

[0000106040-20-000011:mdna:97]
[same as prior period, unchanged from 0000106040-19-000075:mdna:94]

[0000106040-20-000011:mdna:98]
See Part I, Item 1, Note 2, Recent Accounting Pronouncements, and Note 10, Leases and Other Commitments, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for a discussion of a recently adopted accounting pronouncement that affects our accounting for lease obligations. There have been no other material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the fiscal year ended June 28, 2019 for a discussion of our critical accounting policies and estimates.
