# WDC 8-K — 0000106040-19-000050 filed 2019-07-31

## item codes, every 8-K on or before 2019-08-27

- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2019-08-27

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-19-000050:8k_2_02:1]
EX-99.1
2
ex991-pressreleaseq4.htm
EXHIBIT 99.1

[0000106040-19-000050:8k_2_02:2]
Exhibit

[0000106040-19-000050:8k_2_02:3]
Exhibit 99.1

[0000106040-19-000050:8k_2_02:4]
FOR IMMEDIATE RELEASE:

[0000106040-19-000050:8k_2_02:5]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0000106040-19-000050:8k_2_02:6]
FOURTH QUARTER AND FISCAL YEAR 2019

[0000106040-19-000050:8k_2_02:7]
SAN JOSE, Calif. — July 31, 2019 — Western Digital Corp. (NASDAQ: WDC) today reported revenue of $3.6 billion for its fourth fiscal quarter ended June 28, 2019. The operating loss was $381 million with a net loss of $197 million, or ($0.67) per share. Excluding certain non-GAAP adjustments, the company achieved non-GAAP operating income of $158 million and non-GAAP net income of $50 million, or $0.17 per share.

[0000106040-19-000050:8k_2_02:8]
In the year-ago quarter, the company reported revenue of $5.1 billion, operating income of $843 million and net income of $756 million, or $2.46 per share. Non-GAAP operating income in the year-ago quarter was $1.3 billion and non-GAAP net income was $1.1 billion, or $3.61 per share.

[0000106040-19-000050:8k_2_02:9]
The company generated $169 million in cash from operations during the fourth fiscal quarter of 2019, and ended the quarter with $3.5 billion of total cash and cash equivalents. The company returned $146 million to shareholders through dividends. On May 2, 2019, the company declared a cash dividend of $0.50 per share of its common stock, which was paid to shareholders on July 15, 2019.

[0000106040-19-000050:8k_2_02:10]
For fiscal 2019, the company achieved revenue of $16.6 billion, operating income of $87 million and net loss of $754 million, or ($2.58) per share, compared to fiscal 2018 revenue of $20.6 billion, operating income of $3.6 billion and net income of $675 million, or $2.20 per share. On a non-GAAP basis, fiscal 2019 operating income was $2.0 billion and net income was $1.4 billion, or $4.84 per share, compared to fiscal 2018 operating income of $5.4 billion and net income of $4.5 billion, or $14.73 per share. The company generated $1.5 billion in cash from operations during fiscal year 2019 and returned $1.1 billion to shareholders through share repurchases and dividends.

[0000106040-19-000050:8k_2_02:11]
“We ended a challenging fiscal 2019 with leadership positions in capacity enterprise hard drives, 3D flash technology and branded retail products while achieving significant gains in client solid state drives,” said Steve Milligan, chief executive officer, Western Digital.  “Momentum for our NVMe enterprise solid state drives is picking up, setting the stage for further gains across our portfolio in the new fiscal year and beyond.”

[0000106040-19-000050:8k_2_02:12]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2019

[0000106040-19-000050:8k_2_02:13]
Milligan continued, “We are seeing signs of improving conditions in the flash market and believe that it has reached a cyclical trough.  With continuing expectations for a positive demand environment, a robust product portfolio and expanding customer engagements, we expect to deliver improving financial results as we move through fiscal 2020.”

[0000106040-19-000050:8k_2_02:14]
Business Outlook for First Fiscal Quarter of 2020

[0000106040-19-000050:8k_2_02:15]
The company's first fiscal quarter of 2020 will be a 14-week fiscal quarter.

[0000106040-19-000050:8k_2_02:16]
|  | Three Months EndingOct. 4, 2019 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($ in billions) | $3.8 - $4.0 |  | $3.8 - $4.0 |
| Gross margin | ~ 15% - 16% |  | ~ 24% - 25% |
| Operating expenses ($ in millions) | $870 - $890 |  | $750 - $770 |
| Interest and other expense, net ($ in millions) | ~ $100 |  | ~ $95 |
| Tax rate | N/A |  | ~ 25% - 29%(2) |
| Diluted earnings per share | N/A |  | $0.15 - $0.35 |
| Diluted shares outstanding (in millions) | ~ 300 |  | ~ 300 |

[0000106040-19-000050:8k_2_02:17]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2019

[0000106040-19-000050:8k_2_02:18]
(1) Non-GAAP gross margin guidance excludes temporary power outage charges totaling approximately $170 million to $190 million; and amortization of acquired intangible assets, stock-based compensation expense, and charges related to cost saving initiatives totaling approximately $170 million. The company’s non-GAAP operating expenses guidance excludes amortization of acquired intangible assets; stock-based compensation expense; employee termination, asset impairment and other charges; and charges related to cost saving initiatives totaling approximately $110 million to $130 million. The company's non-GAAP interest and other expense guidance excludes approximately $5 million of convertible debt activity. In the aggregate, non-GAAP diluted earnings per share guidance excludes these items totaling $455 million to $495 million. The timing and amount of these charges excluded from non-GAAP gross margin, non-GAAP operating expenses, non-GAAP interest and other expense and non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the company excludes from its non-GAAP tax rate and non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of non-GAAP gross margin, non-GAAP operating expenses, non-GAAP interest and other expense, non-GAAP tax rate and non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, interest and other expense, tax rate and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-19-000050:8k_2_02:19]
(2) The non-GAAP tax rates provided are based on a percentage of non-GAAP pre-tax income.

[0000106040-19-000050:8k_2_02:20]
Investor Communications

[0000106040-19-000050:8k_2_02:21]
The investment community conference call to discuss these results and the company’s guidance for the first fiscal quarter of 2020 will be broadcast live online today at 2:30 p.m. Pacific/5:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-19-000050:8k_2_02:22]
About Western Digital

[0000106040-19-000050:8k_2_02:23]
Western Digital creates environments for data to thrive. The company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, our industry-leading solutions deliver the possibilities of data. Western Digital data-centric solutions are comprised of the Western Digital®, G-Technology™, SanDisk® and WD® brands. Financial and investor information is available on the company's Investor Relations website at investor.wdc.com.

[0000106040-19-000050:8k_2_02:24]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2019

[0000106040-19-000050:8k_2_02:25]
Forward-Looking Statements

[0000106040-19-000050:8k_2_02:26]
###

[0000106040-19-000050:8k_2_02:27]
Western Digital, the Western Digital logo, G-Technology, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-19-000050:8k_2_02:28]
WESTERN DIGITAL CORPORATION

[0000106040-19-000050:8k_2_02:29]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-19-000050:8k_2_02:30]
(in millions; unaudited; on a US GAAP basis)

[0000106040-19-000050:8k_2_02:31]
|  | June 28, 2019 |  | June 29, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,455 |  |  | $ | 5,005 |  |
| Accounts receivable, net | 1,204 |  |  | 2,197 |  |
| Inventories | 3,283 |  |  | 2,944 |  |
| Other current assets | 535 |  |  | 492 |  |
| Total current assets | 8,477 |  |  | 10,638 |  |
| Property, plant and equipment, net | 2,843 |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | 2,791 |  |  | 2,105 |  |
| Goodwill | 10,076 |  |  | 10,075 |  |
| Other intangible assets, net | 1,711 |  |  | 2,680 |  |
| Other non-current assets | 472 |  |  | 642 |  |
| Total assets | $ | 26,370 |  |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,567 |  |  | $ | 2,265 |  |
| Accounts payable to related parties | 331 |  |  | 259 |  |
| Accrued expenses | 1,296 |  |  | 1,274 |  |
| Accrued compensation | 347 |  |  | 479 |  |
| Current portion of long-term debt | 276 |  |  | 179 |  |
| Total current liabilities | 3,817 |  |  | 4,456 |  |
| Long-term debt | 10,246 |  |  | 10,993 |  |
| Other liabilities | 2,340 |  |  | 2,255 |  |
| Total liabilities | 16,403 |  |  | 17,704 |  |
| Total shareholders’ equity | 9,967 |  |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 26,370 |  |  | $ | 29,235 |  |

[0000106040-19-000050:8k_2_02:32]
WESTERN DIGITAL CORPORATION

[0000106040-19-000050:8k_2_02:33]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-19-000050:8k_2_02:34]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-19-000050:8k_2_02:35]
|  | Three Months Ended |  | Year Ended |
|  | June 28, 2019 |  | June 29, 2018 |  | June 28, 2019 |  | June 29, 2018 |
| Revenue, net | $ | 3,634 |  |  | $ | 5,117 |  |  | $ | 16,569 |  |  | $ | 20,647 |  |
| Cost of revenue | 3,169 |  |  | 3,265 |  |  | 12,817 |  |  | 12,942 |  |
| Gross profit | 465 |  |  | 1,852 |  |  | 3,752 |  |  | 7,705 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 523 |  |  | 577 |  |  | 2,182 |  |  | 2,400 |  |
| Selling, general and administrative | 299 |  |  | 352 |  |  | 1,317 |  |  | 1,473 |  |
| Employee termination, asset impairment and other charges | 24 |  |  | 80 |  |  | 166 |  |  | 215 |  |
| Total operating expenses | 846 |  |  | 1,009 |  |  | 3,665 |  |  | 4,088 |  |
| Operating income (loss) | (381 | ) |  | 843 |  |  | 87 |  |  | 3,617 |  |
| Interest and other expense, net | (93 | ) |  | (114 | ) |  | (374 | ) |  | (1,532 | ) |
| Income (loss) before taxes | (474 | ) |  | 729 |  |  | (287 | ) |  | 2,085 |  |
| Income tax expense (benefit) | (277 | ) |  | (27 | ) |  | 467 |  |  | 1,410 |  |
| Net income (loss) | $ | (197 | ) |  | $ | 756 |  |  | $ | (754 | ) |  | $ | 675 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (0.67 | ) |  | $ | 2.53 |  |  | $ | (2.58 | ) |  | $ | 2.27 |  |
| Diluted | $ | (0.67 | ) |  | $ | 2.46 |  |  | $ | (2.58 | ) |  | $ | 2.20 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 294 |  |  | 299 |  |  | 292 |  |  | 297 |  |
| Diluted | 294 |  |  | 307 |  |  | 292 |  |  | 307 |  |

[0000106040-19-000050:8k_2_02:36]
WESTERN DIGITAL CORPORATION

[0000106040-19-000050:8k_2_02:37]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-19-000050:8k_2_02:38]
(in millions; unaudited; on a US GAAP basis)

[0000106040-19-000050:8k_2_02:39]
|  | Three Months Ended |  | Year Ended |
|  | June 28,2019 |  | June 29,2018 |  | June 28, 2019 |  | June 29, 2018 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | (197 | ) |  | $ | 756 |  |  | $ | (754 | ) |  | $ | 675 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 416 |  |  | 489 |  |  | 1,812 |  |  | 2,056 |  |
| Stock-based compensation | 64 |  |  | 78 |  |  | 306 |  |  | 377 |  |
| Deferred income taxes | 121 |  |  | (12 | ) |  | 374 |  |  | (348 | ) |
| Loss on disposal of assets | 35 |  |  | 5 |  |  | 39 |  |  | 21 |  |
| Write-off of issuance costs and amortization of debt discounts | 10 |  |  | 13 |  |  | 38 |  |  | 221 |  |
| Cash premium on extinguishment of debt | — |  |  | — |  |  | — |  |  | 720 |  |
| Non-cash portion of employee termination, asset impairment and other charges | — |  |  | — |  |  | — |  |  | 16 |  |
| Other non-cash operating activities, net | (27 | ) |  | (4 | ) |  | (8 | ) |  | (19 | ) |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | 18 |  |  | (186 | ) |  | 993 |  |  | (244 | ) |
| Inventories | 157 |  |  | (274 | ) |  | (339 | ) |  | (598 | ) |
| Accounts payable | (39 | ) |  | 26 |  |  | (588 | ) |  | (15 | ) |
| Accounts payable to related parties | 19 |  |  | (23 | ) |  | 72 |  |  | 53 |  |
| Accrued expenses | (415 | ) |  | 72 |  |  | (42 | ) |  | (17 | ) |
| Accrued compensation | (57 | ) |  | (28 | ) |  | (135 | ) |  | (26 | ) |
| Other assets and liabilities, net | 64 |  |  | (49 | ) |  | (221 | ) |  | 1,333 |  |
| Net cash provided by operating activities | 169 |  |  | 863 |  |  | 1,547 |  |  | 4,205 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (38 | ) |  | (190 | ) |  | (757 | ) |  | (809 | ) |
| Activity related to Flash Ventures, net | (310 | ) |  | (35 | ) |  | (598 | ) |  | (742 | ) |
| Acquisitions, net of cash acquired | — |  |  | (1 | ) |  | — |  |  | (100 | ) |
| Investment activity, net | 116 |  |  | (11 | ) |  | 103 |  |  | (22 | ) |
| Strategic Investments and Other, net | 2 |  |  | (12 | ) |  | (20 | ) |  | 18 |  |
| Net cash used in investing activities | (230 | ) |  | (249 | ) |  | (1,272 | ) |  | (1,655 | ) |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | 46 |  |  | 67 |  |  | 3 |  |  | 49 |  |
| Repurchases of common stock | — |  |  | (436 | ) |  | (563 | ) |  | (591 | ) |
| Dividends paid to shareholders | (146 | ) |  | (150 | ) |  | (584 | ) |  | (593 | ) |
| Settlement of debt hedge contracts | — |  |  | — |  |  | — |  |  | 28 |  |
| Proceeds from (repayment of) revolving credit facility | — |  |  | — |  |  | (500 | ) |  | 500 |  |
| Proceeds from debt, net of issuance costs | (4 | ) |  | 2,449 |  |  | (4 | ) |  | 13,781 |  |
| Repayment of debt | (68 | ) |  | (2,493 | ) |  | (181 | ) |  | (17,074 | ) |
| Net cash used in financing activities | (172 | ) |  | (563 | ) |  | (1,829 | ) |  | (3,900 | ) |
| Effect of exchange rate changes on cash | 6 |  |  | (9 | ) |  | 4 |  |  | 1 |  |
| Net Increase (Decrease) in cash and cash equivalents | (227 | ) |  | 42 |  |  | (1,550 | ) |  | (1,349 | ) |
| Cash and cash equivalents, beginning of period | 3,682 |  |  | 4,963 |  |  | 5,005 |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 3,455 |  |  | $ | 5,005 |  |  | $ | 3,455 |  |  | $ | 5,005 |  |

[0000106040-19-000050:8k_2_02:40]
WESTERN DIGITAL CORPORATION

[0000106040-19-000050:8k_2_02:41]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-19-000050:8k_2_02:42]
(in millions; unaudited)

[0000106040-19-000050:8k_2_02:43]
|  | Three Months Ended |  | Year Ended |
|  | June 28,2019 |  | June 29,2018 |  | June 28,2019 |  | June 29,2018 |
| GAAP cost of revenue | $ | 3,169 |  |  | $ | 3,265 |  |  | $ | 12,817 |  |  | $ | 12,942 |  |
| Amortization of acquired intangible assets | (166 | ) |  | (234 | ) |  | (804 | ) |  | (1,022 | ) |
| Stock-based compensation expense | (11 | ) |  | (12 | ) |  | (48 | ) |  | (49 | ) |
| Charges related to cost saving initiatives | (4 | ) |  | 1 |  |  | (11 | ) |  | 7 |  |
| Manufacturing underutilization charges | (67 | ) |  | — |  |  | (264 | ) |  | — |  |
| Power outage charges | (145 | ) |  | — |  |  | (145 | ) |  | — |  |
| Other | (22 | ) |  | — |  |  | (22 | ) |  | — |  |
| Non-GAAP cost of revenue | $ | 2,754 |  |  | $ | 3,020 |  |  | $ | 11,523 |  |  | $ | 11,878 |  |
| GAAP gross profit | $ | 465 |  |  | $ | 1,852 |  |  | $ | 3,752 |  |  | $ | 7,705 |  |
| Amortization of acquired intangible assets | 166 |  |  | 234 |  |  | 804 |  |  | 1,022 |  |
| Stock-based compensation expense | 11 |  |  | 12 |  |  | 48 |  |  | 49 |  |
| Charges related to cost saving initiatives | 4 |  |  | (1 | ) |  | 11 |  |  | (7 | ) |
| Manufacturing underutilization charges | 67 |  |  | — |  |  | 264 |  |  | — |  |
| Power outage charges | 145 |  |  | — |  |  | 145 |  |  | — |  |
| Other | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Non-GAAP gross profit | $ | 880 |  |  | $ | 2,097 |  |  | $ | 5,046 |  |  | $ | 8,769 |  |
| GAAP operating expenses | $ | 846 |  |  | $ | 1,009 |  |  | $ | 3,665 |  |  | $ | 4,088 |  |
| Amortization of acquired intangible assets | (41 | ) |  | (41 | ) |  | (164 | ) |  | (163 | ) |
| Stock-based compensation expense | (53 | ) |  | (66 | ) |  | (258 | ) |  | (327 | ) |
| Employee termination, asset impairment and other charges | (24 | ) |  | (80 | ) |  | (166 | ) |  | (215 | ) |
| Acquisition-related charges | — |  |  | (1 | ) |  | — |  |  | (13 | ) |
| Charges related to cost saving initiatives | (3 | ) |  | (1 | ) |  | (11 | ) |  | (19 | ) |
| Other | (3 | ) |  | — |  |  | (44 | ) |  | 3 |  |
| Non-GAAP operating expenses | $ | 722 |  |  | $ | 820 |  |  | $ | 3,022 |  |  | $ | 3,354 |  |
| GAAP operating income (loss) | $ | (381 | ) |  | $ | 843 |  |  | $ | 87 |  |  | $ | 3,617 |  |
| Cost of revenue adjustments | 415 |  |  | 245 |  |  | 1,294 |  |  | 1,064 |  |
| Operating expense adjustments | 124 |  |  | 189 |  |  | 643 |  |  | 734 |  |
| Non-GAAP operating income | $ | 158 |  |  | $ | 1,277 |  |  | $ | 2,024 |  |  | $ | 5,415 |  |
| GAAP interest and other expense, net | $ | (93 | ) |  | $ | (114 | ) |  | $ | (374 | ) |  | $ | (1,532 | ) |
| Convertible debt activity | 7 |  |  | 7 |  |  | 27 |  |  | 10 |  |
| Debt extinguishment costs | — |  |  | 3 |  |  | — |  |  | 899 |  |
| Other | (1 | ) |  | 3 |  |  | (20 | ) |  | 5 |  |
| Non-GAAP interest and other expense, net | $ | (87 | ) |  | $ | (101 | ) |  | $ | (367 | ) |  | $ | (618 | ) |
| GAAP income tax expense (benefit) | $ | (277 | ) |  | $ | (27 | ) |  | $ | 467 |  |  | $ | 1,410 |  |
| Income tax adjustments | 298 |  |  | 94 |  |  | (239 | ) |  | (1,136 | ) |
| Non-GAAP income tax expense | $ | 21 |  |  | $ | 67 |  |  | $ | 228 |  |  | $ | 274 |  |

[0000106040-19-000050:8k_2_02:44]
WESTERN DIGITAL CORPORATION

[0000106040-19-000050:8k_2_02:45]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-19-000050:8k_2_02:46]
(in millions, except per share amounts; unaudited)

[0000106040-19-000050:8k_2_02:47]
|  | Three Months Ended |  | Year Ended |
|  | June 28,2019 |  | June 29,2018 |  | June 28,2019 |  | June 29,2018 |
| GAAP net income (loss) | $ | (197 | ) |  | $ | 756 |  |  | $ | (754 | ) |  | $ | 675 |  |
| Amortization of acquired intangible assets | 207 |  |  | 275 |  |  | 968 |  |  | 1,185 |  |
| Stock-based compensation expense | 64 |  |  | 78 |  |  | 306 |  |  | 376 |  |
| Employee termination, asset impairment and other charges | 24 |  |  | 80 |  |  | 166 |  |  | 215 |  |
| Acquisition-related charges | — |  |  | 1 |  |  | — |  |  | 13 |  |
| Charges related to cost saving initiatives | 7 |  |  | — |  |  | 22 |  |  | 12 |  |
| Manufacturing underutilization charges | 67 |  |  | — |  |  | 264 |  |  | — |  |
| Power outage charges | 145 |  |  | — |  |  | 145 |  |  | — |  |
| Convertible debt activity | 7 |  |  | 7 |  |  | 27 |  |  | 10 |  |
| Debt extinguishment costs | — |  |  | 3 |  |  | — |  |  | 899 |  |
| Other | 24 |  |  | 3 |  |  | 46 |  |  | 2 |  |
| Income tax adjustments | (298 | ) |  | (94 | ) |  | 239 |  |  | 1,136 |  |
| Non-GAAP net income | $ | 50 |  |  | $ | 1,109 |  |  | $ | 1,429 |  |  | $ | 4,523 |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |
| GAAP | $ | (0.67 | ) |  | $ | 2.46 |  |  | $ | (2.58 | ) |  | $ | 2.20 |  |
| Non-GAAP | $ | 0.17 |  |  | $ | 3.61 |  |  | $ | 4.84 |  |  | $ | 14.73 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |
| GAAP | 294 |  |  | 307 |  |  | 292 |  |  | 307 |  |
| Non-GAAP | 295 |  |  | 307 |  |  | 295 |  |  | 307 |  |

[0000106040-19-000050:8k_2_02:48]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth non-GAAP cost of revenue; non-GAAP gross profit; non-GAAP operating expenses; non-GAAP operating income; non-GAAP interest and other expense, net; non-GAAP income tax expense; non-GAAP net income; and non-GAAP diluted income per common share (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude the amortization of acquired intangible assets, stock-based compensation expense, employee termination, asset impairment and other charges, acquisition-related charges, charges related to cost saving initiatives, manufacturing underutilization charges, power outage charges, convertible debt activity, debt extinguishment costs, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company's results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company's performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-19-000050:8k_2_02:49]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-19-000050:8k_2_02:50]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company's acquisitions and any related impairment charges.

[0000106040-19-000050:8k_2_02:51]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company's control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company's peers, a majority of whom also exclude stock-based compensation expense from their non-GAAP results.

[0000106040-19-000050:8k_2_02:52]
Employee termination, asset impairment and other charges.  From time-to-time, in order to realign the company's operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. These charges (including any reversals of charges recorded in prior periods) are inconsistent in amount and frequency, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000050:8k_2_02:53]
Acquisition-related charges.  In connection with the company's business combinations, the company incurs expenses which it would not have otherwise incurred as part of its business operations.  These expenses include third-party professional service and legal fees, third-party integration services, severance costs, non-cash adjustments to the fair value of acquired inventory, contract termination costs, and retention bonuses.  The company may also experience other accounting impacts in connection with these transactions.  These charges and impacts are related to acquisitions, are inconsistent in amount and frequency, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000050:8k_2_02:54]
Charges related to cost saving initiatives.  In connection with the transformation of the company's business, the company has incurred charges related to cost saving initiatives which do not qualify for special accounting treatment as exit or disposal activities. These charges, which the company believes are not indicative of the underlying performance of its business, primarily relate to costs associated with rationalizing the company's channel partners or vendors, transforming the company's information systems infrastructure, integrating the company's product roadmap, and accelerated depreciation of assets.

[0000106040-19-000050:8k_2_02:55]
Manufacturing underutilization charges.  In response to flash business conditions, the company reduced its wafer starts at its flash-based memory manufacturing facilities operated through its strategic partnership with Toshiba Memory Corporation (TMC).  The temporary abnormal reduction in output resulted in flash manufacturing underutilization charges which are expensed as incurred.  These charges are inconsistent in amount and frequency, and the company believes these charges are not part of the ongoing operation of its business.

[0000106040-19-000050:8k_2_02:56]
Power outage charges. In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated through the company's strategic partnership with TMC in Yokkaichi, Japan. The power outage incident resulted in the write-off of damaged inventory and unabsorbed manufacturing overhead costs which are expensed as incurred. These charges are inconsistent in amount and frequency, and the company believes these charges are not part of the ongoing production operation of its business.

[0000106040-19-000050:8k_2_02:57]
Convertible debt activity. The company excludes non-cash economic interest expense associated with its convertible notes. These charges do not reflect the company's operating results, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000050:8k_2_02:58]
Debt extinguishment costs. From time-to-time, the company replaces its existing debt with new financing at more favorable interest rates or utilizes available capital to settle debt early, both of which generate interest savings in future periods. The company incurs debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off of any related unamortized debt issuance costs. These charges do not reflect the company’s operating results, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000050:8k_2_02:59]
Other adjustments. From time-to-time, the company sells or impairs investments or other assets which are not considered necessary to its business operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business.  The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-19-000050:8k_2_02:60]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments. The income tax adjustments include the company’s final adjustments for the tax effects of the Tax Cuts and Jobs Act allowed within the one-year measurement period that ended on December 22, 2018, as well as estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act. These adjustments are excluded because they are infrequent and the company believes that they are not indicative of the underlying performance of its business.

[0000106040-19-000050:8k_2_02:61]
___________________

[0000106040-19-000050:8k_2_02:62]
Company contacts:

[0000106040-19-000050:8k_2_02:63]
Western Digital Corp.

[0000106040-19-000050:8k_2_02:64]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Jim Pascoe |
| 949.672.9655 |  | 408.717.6999 |
| peter.andrew@wdc.com |  | jim.pascoe@wdc.com |
| investor@wdc.com |  |  |
