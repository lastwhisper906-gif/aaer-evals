# WDC note change history — 0000106040-19-000009 → 0000106040-19-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 29, 2019 and June 29, 2018:
  (was, 2019-02-05, similarity 0.965):
[0000106040-19-000009:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 28, 2018 and June 29, 2018:

- changed (2019-05-07):
[0000106040-19-000028:note_history:2]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 620 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 599 |  |  | 48 |  |
| Notes receivable, Flash Forward | 584 |  |  | 700 |  |
| Investment in Flash Partners | 194 |  |  | 191 |  |
| Investment in Flash Alliance | 287 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,403 |  |  | $ | 2,105 |  |
  (was, 2019-02-05, similarity 0.985):
[0000106040-19-000009:note_history:2]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 695 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 418 |  |  | 48 |  |
| Notes receivable, Flash Forward | 607 |  |  | 700 |  |
| Investment in Flash Partners | 193 |  |  | 191 |  |
| Investment in Flash Alliance | 286 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,318 |  |  | $ | 2,105 |  |

- changed (2019-05-07):
[0000106040-19-000028:note_history:3]
During the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $1.0 billion and $2.9 billion, respectively, for purchased flash-based memory wafers and net loans and investments.
  (was, 2019-02-05, similarity 0.8868):
[0000106040-19-000009:note_history:3]
During the three and six months ended December 28, 2018, the Company made net payments to Flash Ventures of $1.12 billion and $1.86 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2019-05-07):
[0000106040-19-000028:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and nine months ended March 29, 2019 or March 30, 2018.
  (was, 2019-02-05, similarity 0.9074):
[0000106040-19-000009:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and six months ended December 28, 2018 or December 29, 2017.

- changed (2019-05-07):
[0000106040-19-000028:note_history:5]
As of March 29, 2019 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $312 million and $259 million, respectively.
  (was, 2019-02-05, similarity 0.9673):
[0000106040-19-000009:note_history:5]
As of December 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $310 million and $259 million, respectively.

- changed (2019-05-07):
[0000106040-19-000028:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2019-02-05, similarity 0.9851):
[0000106040-19-000009:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2019-05-07):
[0000106040-19-000028:note_history:7]
|  | March 29, 2019 |
| Notes receivable | $ | 1,803 |  |
| Equity investments | 600 |  |
| Operating lease guarantees | 1,421 |  |
| Inventory | 274 |  |
| Maximum estimable loss exposure | $ | 4,098 |  |
  (was, 2019-02-05, similarity 0.9333):
[0000106040-19-000009:note_history:7]
|  | December 28, 2018 |
| Notes receivable | $ | 1,720 |  |
| Equity investments | 598 |  |
| Operating lease guarantees | 1,313 |  |
| Inventory and prepayments | 243 |  |
| Maximum estimable loss exposure | $ | 3,874 |  |

- changed (2019-05-07):
[0000106040-19-000028:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of current supply/demand imbalance for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $148 million and $197 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three and nine months ended March 29, 2019, respectively.
  (was, 2019-02-05, similarity 0.6949):
[0000106040-19-000009:note_history:8]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of reduced demand for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $49 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three months ended December 28, 2018.

- changed (2019-05-07):
[0000106040-19-000028:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019.
  (was, 2019-02-05, similarity 0.9785):
[0000106040-19-000009:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018.

- changed (2019-05-07):
[0000106040-19-000028:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019:
  (was, 2019-02-05, similarity 0.9639):
[0000106040-19-000009:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 28, 2018:

- changed (2019-05-07):
[0000106040-19-000028:note_history:11]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2019 |  | $ | 106 |  |  | $ | 9 |  |  | $ | 115 |  |
| 2020 |  | 360 |  |  | 64 |  |  | 424 |  |
| 2021 |  | 271 |  |  | 106 |  |  | 377 |  |
| 2022 |  | 185 |  |  | 48 |  |  | 233 |  |
| 2023 |  | 81 |  |  | 28 |  |  | 109 |  |
| Thereafter |  | 45 |  |  | 118 |  |  | 163 |  |
| Total guarantee obligations |  | $ | 1,048 |  |  | $ | 373 |  |  | $ | 1,421 |  |
  (was, 2019-02-05, similarity 0.9912):
[0000106040-19-000009:note_history:11]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2019 |  | $ | 294 |  |  | $ | 34 |  |  | $ | 328 |  |
| 2020 |  | 294 |  |  | 67 |  |  | 361 |  |
| 2021 |  | 207 |  |  | 121 |  |  | 328 |  |
| 2022 |  | 112 |  |  | 22 |  |  | 134 |  |
| 2023 |  | 49 |  |  | 88 |  |  | 137 |  |
| Thereafter |  | 4 |  |  | 21 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 960 |  |  | $ | 353 |  |  | $ | 1,313 |  |

- changed (2019-05-07):
[0000106040-19-000028:note_history:12]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2019-02-05, similarity 0.9872):
[0000106040-19-000009:note_history:12]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2019-05-07):
[0000106040-19-000028:note_history:13]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and nine months ended March 29, 2019 and March 30, 2018, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of March 29, 2019 or June 29, 2018.
  (was, 2019-02-05, similarity 0.8712):
[0000106040-19-000009:note_history:13]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and six months ended December 28, 2018 and December 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of December 28, 2018 or June 29, 2018.

- changed (2019-05-07):
[0000106040-19-000028:note_history:14]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of March 29, 2019, the Company had the following minimum long-term purchase commitments:
  (was, 2019-02-05, similarity 0.9918):
[0000106040-19-000009:note_history:14]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of December 28, 2018, the Company had the following minimum long-term purchase commitments:

- added (2019-05-07):
[0000106040-19-000028:note_history:15]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining three months of 2019 |  | $ | 15 |  |
| 2020 |  | 192 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 892 |  |

- removed (2019-05-07):
[0000106040-19-000009:note_history:16]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining six months of 2019 |  | $ | 34 |  |
| 2020 |  | 193 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 912 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:17]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter, subject to formal ratification by party representatives and approval by the court, and a hearing on the parties’ motion for preliminary approval is set for May 16, 2019. The charge related to the settlement was recorded in Selling, general and administrative expense.
  (was, 2019-02-05, similarity 0.9176):
[0000106040-19-000009:note_history:17]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015.  The Company believes the allegations to be without merit and intends to defend itself vigorously in this matter.

- changed (2019-05-07):
[0000106040-19-000028:note_history:18]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 11, Income Tax Expense.
  (was, 2019-02-05, similarity 0.9281):
[0000106040-19-000009:note_history:18]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.

- removed (2019-05-07):
[0000106040-19-000009:note_history:19]
Antitrust

- removed (2019-05-07):
[0000106040-19-000009:note_history:20]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. In December 2018, the remaining three plaintiffs stipulated to dismiss their claims against the defendants.

- removed (2019-05-07):
[0000106040-19-000009:note_history:21]
Copyright

- removed (2019-05-07):
[0000106040-19-000009:note_history:22]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts.

- removed (2019-05-07):
[0000106040-19-000009:note_history:23]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013.

- removed (2019-05-07):
[0000106040-19-000009:note_history:24]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, all court proceedings have been terminated. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:25]
Debt consisted of the following as of March 29, 2019 and June 29, 2018:
  (was, 2019-02-05, similarity 0.928):
[0000106040-19-000009:note_history:25]
Debt consisted of the following as of December 28, 2018 and June 29, 2018:

- changed (2019-05-07):
[0000106040-19-000028:note_history:26]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,896 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,431 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,762 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (177 | ) |  | (203 | ) |
| Subtotal | 10,585 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,309 |  |  | $ | 10,993 |  |
  (was, 2019-02-05, similarity 0.9894):
[0000106040-19-000009:note_history:26]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,928 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,437 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,800 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (186 | ) |  | (203 | ) |
| Subtotal | 10,614 |  |  | 11,172 |  |
| Less current portion of long-term debt | (244 | ) |  | (179 | ) |
| Long-term debt | $ | 10,370 |  |  | $ | 10,993 |  |

- changed (2019-05-07):
[0000106040-19-000028:note_history:27]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At March 29, 2019, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.
  (was, 2019-02-05, similarity 0.9685):
[0000106040-19-000009:note_history:27]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At December 28, 2018, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

- changed (2019-05-07):
[0000106040-19-000028:note_history:28]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement. As of March 29, 2019, the Company was in compliance with all financial covenants under the Credit Agreement.
  (was, 2019-02-05, similarity 0.9308):
[0000106040-19-000009:note_history:28]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement.

- added (2019-05-07):
[0000106040-19-000028:note_history:29]
In April 2019, the Company amended the Credit Agreement for the purposes of providing additional flexibility by adjusting the leverage ratio maintenance covenant levels applicable to the term A loan and revolving facilities thereunder and amending the definition of Consolidated Adjusted EBITDA under the financial maintenance covenants to include an addback for certain depreciation related payments with respect to the Company’s Flash Ventures. As amended, the Company is now required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 2, 2020, 4.00 to 1.00 through the quarter ending July 2, 2021, 3.75 to 1.00 through the quarter ending December 31, 2021, 3.50 to 1.00 through the quarter ending July 1, 2022, and 3.25 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00.

- removed (2019-05-07):
[0000106040-19-000009:note_history:30]
Pursuant to the Credit Agreement, the Company is required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 4, 2019, 4.00 to 1.00 through the quarter ending October 2, 2020, and 3.75 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00. As of December 28, 2018, the Company was in compliance with all financial covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:31]
Debt consisted of the following as of March 29, 2019 and June 29, 2018:
  (was, 2019-02-05, similarity 0.928):
[0000106040-19-000009:note_history:31]
Debt consisted of the following as of December 28, 2018 and June 29, 2018:

- changed (2019-05-07):
[0000106040-19-000028:note_history:32]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,896 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,431 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,762 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (177 | ) |  | (203 | ) |
| Subtotal | 10,585 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,309 |  |  | $ | 10,993 |  |
  (was, 2019-02-05, similarity 0.9894):
[0000106040-19-000009:note_history:32]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,928 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,437 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,800 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (186 | ) |  | (203 | ) |
| Subtotal | 10,614 |  |  | 11,172 |  |
| Less current portion of long-term debt | (244 | ) |  | (179 | ) |
| Long-term debt | $ | 10,370 |  |  | $ | 10,993 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:33]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 29, 2019 and June 29, 2018:
  (was, 2019-02-05, similarity 0.965):
[0000106040-19-000009:note_history:33]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 28, 2018 and June 29, 2018:

- changed (2019-05-07):
[0000106040-19-000028:note_history:34]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 620 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 599 |  |  | 48 |  |
| Notes receivable, Flash Forward | 584 |  |  | 700 |  |
| Investment in Flash Partners | 194 |  |  | 191 |  |
| Investment in Flash Alliance | 287 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,403 |  |  | $ | 2,105 |  |
  (was, 2019-02-05, similarity 0.985):
[0000106040-19-000009:note_history:34]
|  | December 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 695 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 418 |  |  | 48 |  |
| Notes receivable, Flash Forward | 607 |  |  | 700 |  |
| Investment in Flash Partners | 193 |  |  | 191 |  |
| Investment in Flash Alliance | 286 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,318 |  |  | $ | 2,105 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,064 |  |  | $ | 2,640 |  |  | $ | 6,618 |  |  | $ | 7,944 |  |
| Flash-based | 1,610 |  |  | 2,373 |  |  | 6,317 |  |  | 7,586 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |
  (was, 2019-02-05, similarity 0.9326):
[0000106040-19-000009:note_history:35]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,060 |  |  | $ | 2,694 |  |  | $ | 4,554 |  |  | $ | 5,304 |  |
| Flash-based | 2,173 |  |  | 2,642 |  |  | 4,707 |  |  | 5,213 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0000106040-19-000028:note_history:36]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 29, 2019 or the date of adoption of Topic 606.
  (was, 2019-02-05, similarity 0.9784):
[0000106040-19-000009:note_history:36]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 28, 2018 or the date of adoption of Topic 606.

- changed (2019-05-07):
[0000106040-19-000028:note_history:37]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and nine months ended March 29, 2019 were not material.
  (was, 2019-02-05, similarity 0.9742):
[0000106040-19-000009:note_history:37]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and six months ended December 28, 2018 were not material.

- changed (2019-05-07):
[0000106040-19-000028:note_history:38]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of March 29, 2019 and the date of adoption of Topic 606, contract liabilities were $46 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the nine months ended March 29, 2019 include $93 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.
  (was, 2019-02-05, similarity 0.9554):
[0000106040-19-000009:note_history:38]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 28, 2018 and the date of adoption of Topic 606, contract liabilities were $53 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the six months ended December 28, 2018 include $80 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

- changed (2019-05-07):
[0000106040-19-000028:note_history:39]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 29, 2019 was $204 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2019, $62 million in fiscal 2020, $47 million in fiscal 2021 and $75 million thereafter.
  (was, 2019-02-05, similarity 0.9936):
[0000106040-19-000009:note_history:39]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 28, 2018 was $220 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $40 million during the remainder of fiscal 2019, $60 million in fiscal 2020, $46 million in fiscal 2021 and $74 million thereafter.

- changed (2019-05-07):
[0000106040-19-000028:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,064 |  |  | $ | 2,640 |  |  | $ | 6,618 |  |  | $ | 7,944 |  |
| Flash-based | 1,610 |  |  | 2,373 |  |  | 6,317 |  |  | 7,586 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |
  (was, 2019-02-05, similarity 0.9326):
[0000106040-19-000009:note_history:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 2,214 |  |  | $ | 2,647 |  |  | $ | 4,864 |  |  | $ | 5,323 |  |
| Data Center Devices & Solutions | 1,074 |  |  | 1,434 |  |  | 2,520 |  |  | 2,803 |  |
| Client Solutions | 945 |  |  | 1,255 |  |  | 1,877 |  |  | 2,391 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,060 |  |  | $ | 2,694 |  |  | $ | 4,554 |  |  | $ | 5,304 |  |
| Flash-based | 2,173 |  |  | 2,642 |  |  | 4,707 |  |  | 5,213 |  |
| Total Revenue | $ | 4,233 |  |  | $ | 5,336 |  |  | $ | 9,261 |  |  | $ | 10,517 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 24 | % |  | 25 | % |  | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 19 |  |  | 19 |  |  | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |  | 57 |  |  | 56 |  |

- added (2019-05-07):
[0000106040-19-000028:note_history:41]
The Company’s top 10 customers accounted for 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively, and 44% and 42% of its net revenue for the three and nine months ended March 30, 2018, respectively. For the three and nine months ended March 29, 2019 and March 30, 2018, no single customer accounted for 10% or more of the Company’s net revenue.

- removed (2019-05-07):
[0000106040-19-000009:note_history:42]
The Company’s top 10 customers accounted for 47% of its net revenue for both the three and six months ended December 28, 2018, and 42% and 41% of its net revenue for the three and six months ended December 29, 2017, respectively. For the three and six months ended December 28, 2018 and December 29, 2017, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-05-07):
[0000106040-19-000028:note_history:43]
Subsequent Events

- added (2019-05-07):
[0000106040-19-000028:note_history:44]
In April 2019, the Company completed a sale and leaseback of its manufacturing facility in Fremont, California. The Company received proceeds from the sale of $115 million and expects to recognize an approximate loss of $25 million. The property is being leased back over a term of 15 years at an annual lease rate of $7 million for the first year and increasing by 3% per year thereafter. The lease includes four 5-year renewal options for the ability to extend up to 20 years.
