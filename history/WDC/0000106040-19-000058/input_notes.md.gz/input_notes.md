# WDC notes — 0000106040-19-000058


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-19-000058:notes:1]
Organization and Basis of Presentation

[0000106040-19-000058:notes:2]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

[0000106040-19-000058:notes:3]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. It also generates license and royalty revenue from its extensive intellectual property (“IP”), which is included in each of these three end market categories.

[0000106040-19-000058:notes:4]
Basis of Presentation

[0000106040-19-000058:notes:5]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-19-000058:notes:6]
Fiscal Year

[0000106040-19-000058:notes:7]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2019, which ended on June 28, 2019, 2018, which ended on June 29, 2018, and 2017, which ended on June 30, 2017, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-19-000058:notes:8]
Basis of Consolidation

[0000106040-19-000058:notes:9]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in accumulated other comprehensive income, a component of shareholders’ equity.

[0000106040-19-000058:notes:10]
Use of Estimates

[0000106040-19-000058:notes:11]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-19-000058:notes:12]
Cash Equivalents

[0000106040-19-000058:notes:13]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.

[0000106040-19-000058:notes:14]
Available-for-Sale Securities

[0000106040-19-000058:notes:15]
From time to time, the Company invests in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds, with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within other non-current assets in the Consolidated Balance Sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of shareholders’ equity. Gains and losses on available-for-sale securities are recorded based on the specific identification method. The Company evaluates the available-for-sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in Other income (expense), net in the Consolidated Statements of Operations. In addition, realized gains and losses are included in Other income (expense), net in the Consolidated Statements of Operations.

[0000106040-19-000058:notes:16]
Equity Investments

[0000106040-19-000058:notes:17]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. Marketable equity securities previously classified as available-for-sale equity investments are now measured and recorded at fair value with changes in fair value recorded within Other income (expense), net in the Consolidated Statements of Operations rather than as a component of Other comprehensive income as in prior years. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:18]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income (expense), net, in the Consolidated Statements of Operations.

[0000106040-19-000058:notes:19]
If the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee, the Company accounts for these investments at fair value, or if these equity securities do not have a readily determinable fair value (“RDFV”), these securities are measured and recorded using the measurement alternative under ASU 2016-01, which is cost minus impairment, if any, plus or minus changes resulting from observable price changes. Previously, these investments were accounted for under the cost method of accounting. These investments are recorded within Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-19-000058:notes:20]
Variable Interest Entities

[0000106040-19-000058:notes:21]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-19-000058:notes:22]
Fair Value of Financial Instruments

[0000106040-19-000058:notes:23]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-19-000058:notes:24]
Inventories

[0000106040-19-000058:notes:25]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-19-000058:notes:26]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.

[0000106040-19-000058:notes:27]
Property, Plant and Equipment

[0000106040-19-000058:notes:28]
Property and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty-five years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-19-000058:notes:29]
Business Combinations

[0000106040-19-000058:notes:30]
The application of acquisition accounting to a business combination requires that the Company identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date using a combination of valuation techniques, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the excess purchase price are based upon preliminary estimates and assumptions and subject to revision when the Company receives final information, including appraisals and other analyses. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. The Company will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-19-000058:notes:31]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. The Company recognizes the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). The Company’s assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-19-000058:notes:32]
Goodwill and Other Long-Lived Assets

[0000106040-19-000058:notes:33]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fiscal fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company’s assessment resulted in no impairment of goodwill in 2019, 2018, or 2017.

[0000106040-19-000058:notes:34]
The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-19-000058:notes:35]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-19-000058:notes:36]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow. See Note 7, Goodwill and Other Intangible Assets, for additional disclosures related to the Company’s other intangible assets.

[0000106040-19-000058:notes:37]
Revenue and Accounts Receivable

[0000106040-19-000058:notes:38]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which superseded the requirements in Accounting Standards Codification (“ASC”) 605 “Revenue Recognition” (Topic 605). Topic 606 outlines a comprehensive five-step revenue recognition model based on the principle that an entity should recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. Topic 606 also requires more detailed disclosures to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted Topic 606 effective June 30, 2018, using the modified retrospective method to all contracts that were not completed contracts as of the beginning of the fiscal year. Results for reporting periods beginning with fiscal year 2019 are presented under Topic 606, while prior period information presented on the financial statements or elsewhere in this Annual Report on Form 10-K is reported under the Company’s historic accounting policies under Topic 605 in effect for those periods and is not adjusted to reflect the retrospective effect of the adoption of Topic 606. The cumulative effect of adopting Topic 606 was a post-tax increase to the opening retained earnings of $56 million as of June 30, 2018, which was primarily related to our license and royalty revenue arrangements. These arrangements had no remaining performance obligations but were previously recognized under Topic 605 when they were reported to the Company by its licensees, which was generally one quarter in arrears from the licensees’ sales of the licensed products. Adoption of the standard did not have a material impact on the Company’s financial position, results of operations, and cash flows for the year ended June 28, 2019, and the Company expects that the impact of the adoption of the new standard will not be material to its results of operations prospectively.

[0000106040-19-000058:notes:39]
The Company offers a broad range of data storage products that include Client Devices, Data Center Devices and Solutions, and Client Solutions. Client Devices consist of hard disk drives (“HDDs”) and solid state drives (“SSDs”) for computing devices; flash-based embedded storage products; and flash-based memory wafers. Data Center Devices and Solutions consist of high-capacity enterprise HDDs and high-performance enterprise SSDs, data center software and system solutions. Client Solutions consist of HDDs and SSDs embedded into external storage products and removable flash-based products. The Company also generates license and royalty revenue related to its IP patent licenses.

[0000106040-19-000058:notes:40]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and that uncertainties are resolved in a fairly short period of time.

[0000106040-19-000058:notes:41]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-19-000058:notes:42]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-19-000058:notes:43]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company believes the estimate of variable consideration is not constrained and that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics. The Company’s methodology for the estimates is based on several factors, including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are typically recorded as a reduction of the transaction price and, therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-19-000058:notes:44]
An immaterial amount of the Company’s revenue arrangements include contracts that contain more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the standalone selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

[0000106040-19-000058:notes:45]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either June 28, 2019 or the date of adoption of Topic 606.

[0000106040-19-000058:notes:46]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the year ended June 28, 2019 were not material.

[0000106040-19-000058:notes:47]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of June 28, 2019 and the date of adoption of Topic 606, contract liabilities were $43 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the year ended June 28, 2019 include $104 million of revenue recognized during the period, of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

[0000106040-19-000058:notes:48]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of June 28, 2019 was $191 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $65 million in fiscal 2020, $48 million in fiscal 2021, $44 million in fiscal 2022, and $34 million thereafter.

[0000106040-19-000058:notes:49]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-19-000058:notes:50]
Warranty

[0000106040-19-000058:notes:51]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0000106040-19-000058:notes:52]
Litigation and Other Contingencies

[0000106040-19-000058:notes:53]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 16, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-19-000058:notes:54]
Advertising Expense

[0000106040-19-000058:notes:55]
Advertising costs are expensed as incurred and amounted to $107 million, $112 million and $89 million in 2019, 2018 and 2017, respectively. These expenses are included in Selling, general and administrative (“SG&A”) in the Consolidated Statements of Operations.

[0000106040-19-000058:notes:56]
Research and Development Expense

[0000106040-19-000058:notes:57]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-19-000058:notes:58]
Income Taxes

[0000106040-19-000058:notes:59]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-19-000058:notes:60]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.

[0000106040-19-000058:notes:61]
Income per Common Share

[0000106040-19-000058:notes:62]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and shares issuable in connection with convertible debt.

[0000106040-19-000058:notes:63]
Stock-based Compensation

[0000106040-19-000058:notes:64]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics. Once the performance metrics are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period.

[0000106040-19-000058:notes:65]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-19-000058:notes:66]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, available-for-sale securities, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-19-000058:notes:67]
Derivative Contracts

[0000106040-19-000058:notes:68]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. Substantially all of these contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Singapore dollar and Thai baht, which had an aggregate notional amount of $5.71 billion and $4.37 billion at June 28, 2019 and June 29, 2018, respectively.

[0000106040-19-000058:notes:69]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in cost of revenue and operating expenses, and presented within cash flows from operating activities. The Company accounts for its interest rate swaps as designated cash flow hedges to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. The Company pays interest monthly at a fixed rate and receives interest monthly at the LIBOR rate on the notional amount of the contract with realized gains or losses recognized in interest expense. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-19-000058:notes:70]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income (expense), net.

[0000106040-19-000058:notes:71]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-19-000058:notes:72]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with actuarial changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur.

[0000106040-19-000058:notes:73]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that the Company report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period with application applied retrospectively. In addition, the other components of net benefit cost are now presented prospectively in Other income (expense), net in the Consolidated Statements of Operations. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-19-000058:notes:74]
Recent Accounting Pronouncements

[0000106040-19-000058:notes:75]
Accounting Pronouncements Recently Adopted

[0000106040-19-000058:notes:76]
On August 29, 2018, the FASB issued ASU No. 2018-15, “Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” (“ASU 2018-15”), to reduce diversity in practice in accounting for the costs of implementing cloud computing arrangements that are service contracts. ASU 2018-15 allows entities to apply the guidance in the FASB ASC 350-40 to determine which implementation costs are eligible to be capitalized as assets in a cloud computing arrangement that is considered a service contract. The Company adopted this standard on a prospective basis effective June 30, 2018, the beginning of fiscal year 2019, as allowed by the standard. The adoption of this standard and the costs capitalized for the year ended June 28, 2019 were not material to the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:77]
In February 2018, the FASB issued ASU No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act enacted on December 22, 2017 (the “2017 Act”). Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. Because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. For tax effects that are unrelated to the 2017 Act, the Company’s policy to release these from Accumulated other comprehensive loss on an individual item basis rather than a portfolio basis remains unchanged. The Company early adopted this standard effective June 30, 2018 and elected to reclassify stranded tax effects resulting from the 2017 Act from Accumulated other comprehensive loss to Retained earnings. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:78]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness with the entire change in fair value of designated hedge reported in the results of operations in the same line item as the hedged item. The Company early adopted this standard effective June 30, 2018, using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:79]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. The Company adopted this standard on a prospective basis effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:80]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business.” This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective June 30, 2018 and will apply it prospectively to transactions occurring thereafter. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:81]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property (“IP”). The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:82]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-19-000058:notes:83]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company does not expect this update to have a material impact on its Consolidated Financial Statements.

[0000106040-19-000058:notes:84]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. For public entities who have adopted ASU 2017-12, the amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, which for the Company is the first quarter of fiscal 2020. The Company does not expect this update to have a material impact on its Consolidated Financial Statements.

[0000106040-19-000058:notes:85]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-19-000058:notes:86]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018 and provides a package of practical expedients to simplify transition. The Company will adopt this standard in the first quarter of fiscal 2020 and will elect the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company will elect the package of practical expedients and will not reassess prior conclusions including (a) whether its contracts are or contain a lease, (b) lease classification and (c) capitalization of initial direct costs. The Company currently expects the adoption of Topic 842 to result in an increase in lease assets and a corresponding increase in lease liabilities on our Consolidated Balance Sheet of approximately $220 million to $240 million. Upon adoption, the Company will provide expanded financial statement disclosures related to leases.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-19-000058:notes:87]
Supplemental Financial Statement Data

[0000106040-19-000058:notes:88]
Accounts receivable, net

[0000106040-19-000058:notes:89]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During 2019 and 2018, the Company sold trade accounts receivable and received cash proceeds of $1.02 billion and $57 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income (expense), net in the Consolidated Financial Statements. As of June 28, 2019 and June 29, 2018, the amount of factored receivables that remained outstanding was $318 million and $57 million, respectively.

[0000106040-19-000058:notes:90]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,142 |  |  | $ | 1,048 |  |
| Work-in-process | 968 |  |  | 878 |  |
| Finished goods | 1,173 |  |  | 1,018 |  |
| Total inventories | $ | 3,283 |  |  | $ | 2,944 |  |

[0000106040-19-000058:notes:91]
Property, plant and equipment, net

[0000106040-19-000058:notes:92]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land | $ | 294 |  |  | $ | 306 |  |
| Buildings and improvements | 1,743 |  |  | 1,949 |  |
| Machinery and equipment | 7,267 |  |  | 7,209 |  |
| Computer equipment and software | 441 |  |  | 440 |  |
| Furniture and fixtures | 56 |  |  | 48 |  |
| Construction-in-process | 202 |  |  | 234 |  |
| Property, plant and equipment, gross | 10,003 |  |  | 10,186 |  |
| Accumulated depreciation | (7,160 | ) |  | (7,091 | ) |
| Property, plant, and equipment, net | $ | 2,843 |  |  | $ | 3,095 |  |

[0000106040-19-000058:notes:93]
Depreciation expense of property, plant and equipment totaled $844 million, $871 million and $960 million in 2019, 2018 and 2017, respectively.

[0000106040-19-000058:notes:94]
Product warranty liability

[0000106040-19-000058:notes:95]
Changes in the warranty accrual were as follows:

[0000106040-19-000058:notes:96]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 318 |  |  | $ | 311 |  |  | $ | 279 |  |
| Charges to operations | 162 |  |  | 176 |  |  | 177 |  |
| Utilization | (142 | ) |  | (151 | ) |  | (151 | ) |
| Changes in estimate related to pre-existing warranties | 12 |  |  | (18 | ) |  | 6 |  |
| Warranty accrual, end of period | $ | 350 |  |  | $ | 318 |  |  | $ | 311 |  |

[0000106040-19-000058:notes:97]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-19-000058:notes:98]
|  | 2019 |  | 2018 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion | $ | 188 |  |  | $ | 168 |  |
| Long-term portion | 162 |  |  | 150 |  |
| Total warranty accrual | $ | 350 |  |  | $ | 318 |  |

[0000106040-19-000058:notes:99]
Other liabilities

[0000106040-19-000058:notes:100]
|  | 2019 |  | 2018 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 928 |  |  | $ | 1,315 |  |
| Payables related to unrecognized tax benefits | 699 |  |  | 508 |  |
| Other non-current liabilities | 713 |  |  | 432 |  |
| Total other non-current liabilities | $ | 2,340 |  |  | $ | 2,255 |  |

[0000106040-19-000058:notes:101]
Accumulated other comprehensive income (loss)

[0000106040-19-000058:notes:102]
Other comprehensive income (loss) (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-19-000058:notes:103]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  | Unrealized Gains (Losses) on Derivative Contracts and available-for-sale securities |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 1, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (2 | ) |  | 18 |  |  | 25 |  |  | 41 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (18 | ) |  | (18 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | 1 |  |  | — |  |  | (5 | ) |  | (4 | ) |
| Net current-period other comprehensive income (loss) | (1 | ) |  | 18 |  |  | 2 |  |  | 19 |  |
| Balance at June 29, 2018 | (19 | ) |  | (21 | ) |  | 1 |  |  | (39 | ) |
| Other comprehensive income (loss) before reclassifications | (39 | ) |  | 28 |  |  | (48 | ) |  | (59 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | 5 |  |  | (3 | ) |  | 19 |  |  | 21 |  |
| Net current-period other comprehensive loss | (34 | ) |  | 25 |  |  | (20 | ) |  | (29 | ) |
| Balance at June 28, 2019 | $ | (53 | ) |  | $ | 4 |  |  | $ | (19 | ) |  | $ | (68 | ) |

[0000106040-19-000058:notes:104]
During 2019, 2018 and 2017, the amounts reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-19-000058:notes:105]
Fair Value Measurements and Investments

[0000106040-19-000058:notes:106]
The Company’s total cash, cash equivalents and available-for-sale securities was as follows:

[0000106040-19-000058:notes:107]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 3,455 |  |  | $ | 5,005 |  |
| Short-term available-for-sale securities (included within Other current assets) | — |  |  | 23 |  |
| Long-term available-for-sale securities (included within Other non-current assets) | — |  |  | 93 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 3,455 |  |  | $ | 5,121 |  |

[0000106040-19-000058:notes:108]
Financial Instruments Carried at Fair Value

[0000106040-19-000058:notes:109]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-19-000058:notes:110]
| Level 1. | Quoted prices in active markets for identical assets or liabilities. |

[0000106040-19-000058:notes:111]
| Level 2. | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000106040-19-000058:notes:112]
| Level 3. | Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities. |

[0000106040-19-000058:notes:113]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 28, 2019 and June 29, 2018, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-19-000058:notes:114]
|  | June 28, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,388 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,388 |  |
| Certificates of deposit | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Total cash equivalents | 1,388 |  |  | 17 |  |  | — |  |  | 1,405 |  |
| Foreign exchange contracts | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Interest rate swap contracts | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total assets at fair value | $ | 1,388 |  |  | $ | 63 |  |  | $ | — |  |  | $ | 1,451 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |
| Interest rate swap contract | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |

[0000106040-19-000058:notes:115]
|  | June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,554 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,554 |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total cash equivalents | 2,554 |  |  | 4 |  |  | — |  |  | 2,558 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Total short-term available-for-sale securities | 5 |  |  | 18 |  |  | — |  |  | 23 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Asset-backed securities | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Municipal notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total long-term available-for-sale securities | 3 |  |  | 90 |  |  | — |  |  | 93 |  |
| Foreign exchange contracts | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Interest rate swap contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,562 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 2,741 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |

[0000106040-19-000058:notes:116]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-19-000058:notes:117]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-19-000058:notes:118]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 5, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheet under Other current assets and Accrued expenses, respectively.

[0000106040-19-000058:notes:119]
Interest Rate Swaps. The Company’s interest rate swaps are long-term contracts to hedge the Company’s variable rate debt risk. Interest rate swaps are valued based on estimated present value of future cash flows model. The market-based observable inputs for the model include interest rate curves and credit valuation adjustments.

[0000106040-19-000058:notes:120]
During 2019 and 2018, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-19-000058:notes:121]
The Company sold substantially all of its available-for-sale securities during fiscal 2019. The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of June 29, 2018.

[0000106040-19-000058:notes:122]
Financial Instruments Not Carried at Fair Value

[0000106040-19-000058:notes:123]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2019 and the fourth quarter of 2018, respectively.

[0000106040-19-000058:notes:124]
|  | June 28, 2019 |  | June 29, 2018 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 33 |  |  | $ | 31 |  |  | $ | 31 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,824 |  |  | 4,780 |  |  | 4,982 |  |  | 5,013 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,424 |  |  | 2,370 |  |  | 2,448 |  |  | 2,452 |  |
| 1.50% convertible notes due 2024 | 958 |  |  | 986 |  |  | 931 |  |  | 1,114 |  |
| 4.750% senior unsecured notes due 2026 | 2,283 |  |  | 2,263 |  |  | 2,280 |  |  | 2,238 |  |
| Total | $ | 10,522 |  |  | $ | 10,430 |  |  | $ | 10,672 |  |  | $ | 10,851 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-19-000058:notes:125]
Derivative Instruments and Hedging Activities

[0000106040-19-000058:notes:126]
As of June 28, 2019, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-19-000058:notes:127]
As of June 28, 2019, the amount of existing net losses related to cash flow hedges recorded in AOCI included $54 million related to its interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of June 28, 2019, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-19-000058:notes:128]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. During 2019, 2018 and 2017, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-19-000058:notes:129]
See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair value of the Company’s derivative contracts.

[0000106040-19-000058:notes:130]
Netting Arrangements

[0000106040-19-000058:notes:131]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 28, 2019 and June 29, 2018, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-19-000058:notes:132]
Debt

[0000106040-19-000058:notes:133]
Debt consisted of the following as of June 28, 2019 and June 29, 2018:

[0000106040-19-000058:notes:134]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,834 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,425 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,694 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (172 | ) |  | (203 | ) |
| Subtotal | 10,522 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,246 |  |  | $ | 10,993 |  |

[0000106040-19-000058:notes:135]
The Company has a credit agreement originally entered into on April 29, 2016 and most recently amended in April 2019 (as amended, the “Credit Agreement”), that provides for, among other things, (i) a $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), (ii) a term loan A-1 due 2023 (the “Term Loan A-1”), and (iii) a term loan B-4 due April 29, 2023 (the “Term Loan B-4”).

[0000106040-19-000058:notes:136]
Borrowings under the revolving credit facility bear interest at a rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. During 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At June 28, 2019, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

[0000106040-19-000058:notes:137]
The Term Loan A-1 bears interest at a rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable rate was 3.90% as of June 28, 2019. Principal payments are due in quarterly installments of 1.250% per quarter through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of June 28, 2019, issuance costs of $10 million remained unamortized.

[0000106040-19-000058:notes:138]
The U.S. Term Loan B-4 bears interest at a rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 1.75% or a base rate plus 0.75%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 4.15% as of June 28, 2019. Principal payments on U.S. Term Loan B-4 of 0.25% are due quarterly with the balance due on April 29, 2023. The U.S. Term Loan B-4 issuance costs are amortized to interest expense over the term of the loan and as of June 28, 2019, issuance costs of $1 million remained unamortized.

[0000106040-19-000058:notes:139]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company.

[0000106040-19-000058:notes:140]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of approximately $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events. On or after February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

[0000106040-19-000058:notes:141]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of June 28, 2019, debt discount and issuance cost of $142 million remained unamortized.

[0000106040-19-000058:notes:142]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of June 28, 2019, issuance costs of $17 million remained unamortized.

[0000106040-19-000058:notes:143]
The Company assumed the 0.5% convertible senior notes due November 15, 2020 (the “2020 Convertible Notes”) in connection with its acquisition of SanDisk Corporation (“SanDisk”), pursuant to an Agreement and Plan of Merger (the “Merger”), on May 12, 2016 (the “SanDisk Closing Date”). As of June 28, 2019, $35 million principal amount of the 2020 Convertible Notes was outstanding and had a conversion rate of 10.9006 units of reference property per $1,000 principal amount of the 2020 Convertible Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Convertible Notes are not currently exchangeable into reference property. The 2020 Convertible Notes issuance costs are amortized to interest expense over the term of the 2020 Convertible Notes and as of June 28, 2019, issuance costs of $2 million remained unamortized.

[0000106040-19-000058:notes:144]
The Revolving Facility, Term Loan A-1 and Term Loan B-4 are unconditionally guaranteed by each of the guarantors under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantees will be automatically suspended upon certain conditions.

[0000106040-19-000058:notes:145]
The Credit Agreement requires the Company to comply with certain financial covenants with respect to the Revolving Facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement.

[0000106040-19-000058:notes:146]
In April 2019, the Company amended the Credit Agreement for the purposes of providing additional flexibility by adjusting the leverage ratio maintenance covenant levels applicable to the Term Loan A-1 and Revolving Facility thereunder and amending the definition of Consolidated Adjusted EBITDA under the financial maintenance covenants to include an addback for certain depreciation related payments with respect to the Company’s Flash Ventures. As amended, the Company is now required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 2, 2020, 4.00 to 1.00 through the quarter ending July 2, 2021, 3.75 to 1.00 through the quarter ending December 31, 2021, 3.50 to 1.00 through the quarter ending July 1, 2022, and 3.25 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00. As of June 28, 2019, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-19-000058:notes:147]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.

[0000106040-19-000058:notes:148]
Future Debt Payments

[0000106040-19-000058:notes:149]
As of June 28, 2019, annual future debt payments were as follows:

[0000106040-19-000058:notes:150]
|  |  | Future Debt Payments |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2020 |  | $ | 276 |  |
| 2021 |  | 311 |  |
| 2022 |  | 276 |  |
| 2023 |  | 6,431 |  |
| 2024 |  | 1,100 |  |
| 2025 and thereafter |  | 2,300 |  |
| Total debt maturities |  | 10,694 |  |
| Issuance costs and debt discounts |  | (172 | ) |
| Net carrying value |  | $ | 10,522 |  |


## srt:ContractualObligationFiscalYearMaturityScheduleTableTextBlock

[0000106040-19-000058:notes:151]
As of June 28, 2019, the Company had the following minimum long-term commitments:

[0000106040-19-000058:notes:152]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2020 |  | $ | 136 |  |
| 2021 |  | 244 |  |
| 2022 |  | 263 |  |
| 2023 |  | 154 |  |
| 2024 |  | 40 |  |
| Thereafter |  | 210 |  |
| Total |  | $ | 1,047 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-19-000058:notes:153]
Goodwill and Other Intangible Assets

[0000106040-19-000058:notes:154]
The following table summarizes the activity related to the carrying amount of goodwill:

[0000106040-19-000058:notes:155]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 30, 2017 | $ | 10,014 |  |
| Goodwill recorded in connection with acquisitions | 61 |  |
| Balance at June 29, 2018 | 10,075 |  |
| Foreign currency translation adjustment | 1 |  |
| Balance at June 28, 2019 | $ | 10,076 |  |

[0000106040-19-000058:notes:156]
The following tables present intangible assets as of June 28, 2019 and June 29, 2018:

[0000106040-19-000058:notes:157]
|  | June 28, 2019 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,332 |  |  | $ | (3,316 | ) |  | $ | 1,016 |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (310 | ) |  | 338 |  |
| Customer relationships | 6 |  | 635 |  |  | (372 | ) |  | 263 |  |
| Other | 2 |  | 180 |  |  | (180 | ) |  | — |  |
| Leasehold interests | 31 |  | 29 |  |  | (7 | ) |  | 22 |  |
| Total finite intangible assets |  |  | 5,824 |  |  | (4,185 | ) |  | 1,639 |  |
| In-process research and development |  |  | 72 |  |  | — |  |  | 72 |  |
| Total intangible assets |  |  | $ | 5,896 |  |  | $ | (4,185 | ) |  | $ | 1,711 |  |

[0000106040-19-000058:notes:158]
|  | June 29, 2018 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,323 |  |  | $ | (2,528 | ) |  | $ | 1,795 |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (222 | ) |  | 426 |  |
| Customer relationships | 6 |  | 635 |  |  | (299 | ) |  | 336 |  |
| Other | 2 |  | 180 |  |  | (161 | ) |  | 19 |  |
| Leasehold interests | 31 |  | 32 |  |  | (8 | ) |  | 24 |  |
| Total finite intangible assets |  |  | 5,818 |  |  | (3,218 | ) |  | 2,600 |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |
| Total intangible assets |  |  | $ | 5,898 |  |  | $ | (3,218 | ) |  | $ | 2,680 |  |

[0000106040-19-000058:notes:159]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During 2019, the Company reclassified $8 million of acquired IPR&D to existing technology and commenced amortization over its estimated useful life of 2 years.

[0000106040-19-000058:notes:160]
During 2019, 2018 and 2017, the Company did not record any impairment charges related to intangible assets.

[0000106040-19-000058:notes:161]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Intangible asset amortization was as follows:

[0000106040-19-000058:notes:162]
|  | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| Intangible asset amortization | $ | 968 |  |  | $ | 1,185 |  |  | $ | 1,169 |  |

[0000106040-19-000058:notes:163]
The following table presents estimated future amortization expense for intangible assets currently subject to amortization as of June 28, 2019:

[0000106040-19-000058:notes:164]
|  | Future Intangible Asset Amortization Expense |
|  | (in millions) |
| Fiscal year |  |
| 2020 | $ | 758 |  |
| 2021 | 503 |  |
| 2022 | 226 |  |
| 2023 | 134 |  |
| 2024 and thereafter | 18 |  |
| Total future amortization expense | $ | 1,639 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-19-000058:notes:165]
Pension and Other Post-Retirement Benefit Plans

[0000106040-19-000058:notes:166]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Consolidated Financial Statements.

[0000106040-19-000058:notes:167]
Obligations and Funded Status

[0000106040-19-000058:notes:168]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan:

[0000106040-19-000058:notes:169]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 260 |  |  | $ | 249 |  |  | $ | 326 |  |
| Service cost | 6 |  |  | 6 |  |  | 8 |  |
| Interest cost | 2 |  |  | 2 |  |  | 1 |  |
| Actuarial loss (gain) | 13 |  |  | 9 |  |  | (22 | ) |
| Benefits paid | (9 | ) |  | (9 | ) |  | (30 | ) |
| Settlement/Curtailment | — |  |  | — |  |  | (6 | ) |
| Non-U.S. currency movement | 8 |  |  | 3 |  |  | (28 | ) |
| Projected benefit obligation at end of period | 280 |  |  | 260 |  |  | 249 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 200 |  |  | 189 |  |  | 212 |  |
| Actual return on plan assets | 2 |  |  | 8 |  |  | 15 |  |
| Employer contributions | 10 |  |  | 10 |  |  | 10 |  |
| Benefits paid | (9 | ) |  | (9 | ) |  | (30 | ) |
| Non-U.S. currency movement | 5 |  |  | 2 |  |  | (18 | ) |
| Fair value of plan assets at end of period | 208 |  |  | 200 |  |  | 189 |  |
| Unfunded status | $ | 72 |  |  | $ | 60 |  |  | $ | 60 |  |

[0000106040-19-000058:notes:170]
The following table presents the unfunded amounts related to the Japanese Plan as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-19-000058:notes:171]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 71 |  |  | 59 |  |
| Net amount recognized | $ | 72 |  |  | $ | 60 |  |

[0000106040-19-000058:notes:172]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $280 million at June 28, 2019. As of June 28, 2019, actuarial losses for the Japanese defined benefit pension plans of $35 million are included in Accumulated other comprehensive loss in the Consolidated Balance Sheet. There were no prior service credits for the defined benefit pension plans recognized in Accumulated other comprehensive loss in the Consolidated Balance Sheet as of June 28, 2019.

[0000106040-19-000058:notes:173]
Net periodic benefit costs were not material for 2019, 2018, and 2017.

[0000106040-19-000058:notes:174]
Assumptions

[0000106040-19-000058:notes:175]
Weighted-Average Assumptions

[0000106040-19-000058:notes:176]
The weighted-average actuarial assumptions used to determine the projected benefit obligations for the Japanese defined benefit pension plans were as follows:

[0000106040-19-000058:notes:177]
|  | 2019 |  | 2018 |  | 2017 |
| Discount rate | 0.4 | % |  | 0.7 | % |  | 0.8 | % |
| Rate of compensation increase | 0.6 | % |  | 0.7 | % |  | 0.8 | % |

[0000106040-19-000058:notes:178]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows:

[0000106040-19-000058:notes:179]
|  | 2019 |  | 2018 |  | 2017 |
| Discount rate | 0.7 | % |  | 0.8 | % |  | 0.4 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 0.7 | % |  | 0.8 | % |  | 0.8 | % |

[0000106040-19-000058:notes:180]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to bond ratings that are “AA” or higher which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-19-000058:notes:181]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-19-000058:notes:182]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-19-000058:notes:183]
Plan Assets

[0000106040-19-000058:notes:184]
Investment Policies and Strategies

[0000106040-19-000058:notes:185]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 62% in debt securities, 35% in equity securities, and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-19-000058:notes:186]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-19-000058:notes:187]
Fair Value Measurements

[0000106040-19-000058:notes:188]
The following tables present the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 28, 2019 and June 29, 2018:

[0000106040-19-000058:notes:189]
|  | June 28, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 131 |  |  | — |  |  | 131 |  |
| Cash equivalents and short-term investments | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Fair value of plan assets | $ | 9 |  |  | $ | 199 |  |  | $ | — |  |  | $ | 208 |  |

[0000106040-19-000058:notes:190]
|  | June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 125 |  |  | — |  |  | 125 |  |
| Cash equivalents and short-term investments | 3 |  |  | 4 |  |  | — |  |  | 7 |  |
| Fair value of plan assets | $ | 3 |  |  | $ | 197 |  |  | $ | — |  |  | $ | 200 |  |

[0000106040-19-000058:notes:191]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-19-000058:notes:192]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-19-000058:notes:193]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-19-000058:notes:194]
There were no significant movements of assets between any level categories in 2019, 2018 or 2017.

[0000106040-19-000058:notes:195]
Fair Value Valuation Techniques

[0000106040-19-000058:notes:196]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-19-000058:notes:197]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-19-000058:notes:198]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-19-000058:notes:199]
Cash Flows

[0000106040-19-000058:notes:200]
The Company’s expected employer contributions for 2020 and annual benefit payments over the next 5 years for its Japanese defined benefit pension plans are not expected to be material.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-19-000058:notes:201]
Commitments, Contingencies and Related Parties

[0000106040-19-000058:notes:202]
Flash Ventures

[0000106040-19-000058:notes:203]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Toshiba Memory Corporation (“TMC”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and TMC has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and TMC collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by TMC at its wafer fabrication facilities located in Japan using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from TMC at cost and then resells those wafers to the Company and TMC at cost plus a markup.

[0000106040-19-000058:notes:204]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of TMC’s “Y3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-19-000058:notes:205]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of TMC’s “Y4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-19-000058:notes:206]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of TMC’s “Y5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Y5 was built in two phases of approximately equal size.

[0000106040-19-000058:notes:207]
New Y2. The Company has a facility agreement with TMC related to the construction and operation of TMC’s “New Y2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Y2 primarily provided additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Y2 started in 2016.

[0000106040-19-000058:notes:208]
Y6. The Company also has a facility agreement with TMC related to the construction and operation of TMC’s “Y6” 300-millimeter wafer fabrication facility in Yokkaichi, Japan. Y6 is primarily intended to provide clean room space to continue the transition of existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. Production of flash-based wafers in Y6 started for Flash Ventures started in 2018.

[0000106040-19-000058:notes:209]
K1. In May 2019, the Company entered into additional agreements to extend Flash Ventures to a new wafer fabrication facility, referred to as “K1.” K1 is currently under construction at a site in Kitakami, Iwate, Japan. The Company is committed to pay, among other items, future building depreciation prepayments of $358 million as follows: $156 million in fiscal year 2020, $124 million in fiscal year 2021 and $78 million in fiscal 2022, to be credited against future wafer charges. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. Output from the initial production line at K1 is expected in the second half of fiscal year 2020. Meaningful output from K1 is not expected to begin until the first half of fiscal year 2021.

[0000106040-19-000058:notes:210]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-19-000058:notes:211]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of June 28, 2019 and June 29, 2018:

[0000106040-19-000058:notes:212]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 551 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 878 |  |  | 48 |  |
| Notes receivable, Flash Forward | 743 |  |  | 700 |  |
| Investment in Flash Partners | 200 |  |  | 191 |  |
| Investment in Flash Alliance | 296 |  |  | 283 |  |
| Investment in Flash Forward | 123 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,791 |  |  | $ | 2,105 |  |

[0000106040-19-000058:notes:213]
During 2019 and 2018, the Company made net payments to Flash Ventures of $4.13 billion and $3.79 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-19-000058:notes:214]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-19-000058:notes:215]
As of June 28, 2019 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $331 million and $259 million, respectively.

[0000106040-19-000058:notes:216]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 28, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-19-000058:notes:217]
|  | June 28, 2019 |
| Notes receivable | $ | 2,172 |  |
| Equity investments | 619 |  |
| Operating lease guarantees | 1,575 |  |
| Inventory | 197 |  |
| Maximum estimable loss exposure | $ | 4,563 |  |

[0000106040-19-000058:notes:218]
As of June 28, 2019 and June 29, 2018, the Company’s retained earnings included undistributed earnings of Flash Ventures of $14 million and $8 million, respectively.

[0000106040-19-000058:notes:219]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-19-000058:notes:220]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash business conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. In 2019, the Company incurred costs of $264 million associated with the reduction in utilization, which was recorded as a charge to cost of revenue.

[0000106040-19-000058:notes:221]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production. As a result of the incident, the Company incurred charges of $145 million recorded in cost of revenue for the year ended June 28, 2019, which primarily consisted of the write-off of damaged inventory and unabsorbed manufacturing overhead costs. The Company is pursuing recovery of its losses associated with this event; however, the amount of any recovery cannot be estimated at this time.

[0000106040-19-000058:notes:222]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-19-000058:notes:223]
Research and Development Activities. The Company participates in common R&D activities with TMC and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-19-000058:notes:224]
Off-Balance Sheet Liabilities

[0000106040-19-000058:notes:225]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-19-000058:notes:226]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 28, 2019.

[0000106040-19-000058:notes:227]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 170 |  |  | $ | 1,575 |  |

[0000106040-19-000058:notes:228]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of June 28, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 28, 2019:

[0000106040-19-000058:notes:229]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| 2020 |  | $ | 419 |  |  | $ | 66 |  |  | $ | 485 |  |
| 2021 |  | 321 |  |  | 109 |  |  | 430 |  |
| 2022 |  | 235 |  |  | 50 |  |  | 285 |  |
| 2023 |  | 137 |  |  | 67 |  |  | 204 |  |
| 2024 |  | 51 |  |  | 120 |  |  | 171 |  |
| Thereafter |  | — |  |  | — |  |  | — |  |
| Total guarantee obligations |  | $ | 1,163 |  |  | $ | 412 |  |  | $ | 1,575 |  |

[0000106040-19-000058:notes:230]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of June 28, 2019, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-19-000058:notes:231]
Unis Venture

[0000106040-19-000058:notes:232]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the years ended June 28, 2019 and June 29, 2018, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Consolidated Financial Statements as of June 28, 2019 or June 29, 2018.

[0000106040-19-000058:notes:233]
Sale-Leaseback

[0000106040-19-000058:notes:234]
In April 2019, the Company completed a sale and leaseback of its manufacturing facility in Fremont, California. The Company received proceeds from the sale of $115 million and recognized a loss of $25 million. The property is being leased back over a term of 15 years at an annual lease rate of $7 million for the first year and increasing by 3% per year thereafter. The lease includes four 5-year renewal options for the ability to extend up to 20 years.

[0000106040-19-000058:notes:235]
Lease Commitments

[0000106040-19-000058:notes:236]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2034. Future minimum lease payments under operating leases that have initial non-cancelable lease terms in excess of one year at June 28, 2019 are as follows:

[0000106040-19-000058:notes:237]
|  |  | Lease Amounts |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2020 |  | $ | 59 |  |
| 2021 |  | 45 |  |
| 2022 |  | 33 |  |
| 2023 |  | 22 |  |
| 2024 |  | 16 |  |
| Thereafter |  | 116 |  |
| Total future minimum lease payments |  | $ | 291 |  |

[0000106040-19-000058:notes:238]
Net rent expense was as follows:

[0000106040-19-000058:notes:239]
|  | 2019 |  | 2018 |  | 2017 |
|  | (In millions) |
| Rent expense, net | $ | 47 |  |  | $ | 49 |  |  | $ | 56 |  |

[0000106040-19-000058:notes:240]
Purchase Agreements and Other Commitments

[0000106040-19-000058:notes:241]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of June 28, 2019, the Company had the following minimum long-term commitments:


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-19-000058:notes:242]
Business Segment, Revenue Information, Geographic Information and Concentration of Risk

[0000106040-19-000058:notes:243]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Based upon the management structure under the current operating model, the Company determined that the Company’s Chief Operating Decision Maker, its Chief Executive Officer, evaluates performance of the Company and makes decisions regarding allocation of resources based on total Company results. As a result, the Company concluded it operates in one segment, data storage devices and solutions.

[0000106040-19-000058:notes:244]
The following table summarizes the Company’s revenue by end market product category, between Client Devices (mobile, desktop, gaming and digital video hard drives, SSDs, embedded products and wafers); Data Center Devices and Solutions (capacity and performance enterprise HDDs, enterprise SSDs, data center software and system solutions); and Client Solutions (removable products, hard drive content solutions and flash content solutions):

[0000106040-19-000058:notes:245]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Client Devices | $ | 8,095 |  |  | $ | 10,108 |  |  | $ | 9,520 |  |
| Data Center Devices & Solutions | 5,038 |  |  | 6,075 |  |  | 5,505 |  |
| Client Solutions | 3,436 |  |  | 4,464 |  |  | 4,068 |  |
| Total revenue | $ | 16,569 |  |  | $ | 20,647 |  |  | $ | 19,093 |  |

[0000106040-19-000058:notes:246]
The following table summarizes the Company’s revenue by form factor category, between HDD and flash-based products:

[0000106040-19-000058:notes:247]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| HDD | $ | 8,746 |  |  | $ | 10,698 |  |  | $ | 10,640 |  |
| Flash-based | 7,823 |  |  | 9,949 |  |  | 8,453 |  |
| Total revenue | $ | 16,569 |  |  | $ | 20,647 |  |  | $ | 19,093 |  |

[0000106040-19-000058:notes:248]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0000106040-19-000058:notes:249]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Net revenue(1) |  |  |  |  |  |
| United States | $ | 3,602 |  |  | $ | 4,640 |  |  | $ | 3,881 |  |
| China | 3,861 |  |  | 4,393 |  |  | 4,271 |  |
| Hong Kong | 3,122 |  |  | 4,022 |  |  | 3,257 |  |
| Rest of Asia | 2,116 |  |  | 2,752 |  |  | 3,181 |  |
| Europe, Middle East and Africa | 3,109 |  |  | 3,858 |  |  | 3,276 |  |
| Other | 759 |  |  | 982 |  |  | 1,227 |  |
| Total | $ | 16,569 |  |  | $ | 20,647 |  |  | $ | 19,093 |  |

[0000106040-19-000058:notes:250]
| (1) | Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee. |

[0000106040-19-000058:notes:251]
| (2) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material |

[0000106040-19-000058:notes:252]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Long-lived assets(1) |  |  |  |
| United States | $ | 962 |  |  | $ | 1,187 |  |
| Malaysia | 667 |  |  | 737 |  |
| China | 420 |  |  | 427 |  |
| Thailand | 405 |  |  | 349 |  |
| Rest of Asia | 335 |  |  | 336 |  |
| Europe, Middle East and Africa | 54 |  |  | 59 |  |
| Total | $ | 2,843 |  |  | $ | 3,095 |  |

[0000106040-19-000058:notes:253]
| (1) | Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located. |

[0000106040-19-000058:notes:254]
Customer Concentration and Credit Risk

[0000106040-19-000058:notes:255]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. For each of 2019, 2018 and 2017, no customer accounted for 10% or more of the Company’s net revenue. For 2019, 2018 and 2017, the Company’s top 10 customers accounted for 45%, 42%, and 36%, respectively, of the Company’s net revenue.

[0000106040-19-000058:notes:256]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of June 28, 2019, two customers, Dell Technologies Inc. and Huawei Investment & Holding Co., accounted for 14% and 10%, respectively, of the Company’s net accounts receivable. As of June 29, 2018, two customers, Apple, Inc. and Dell Inc., accounted for 13% and 10%, respectively, of the Company’s net accounts receivable. As of June 28, 2019 and June 29, 2018, the Company had net accounts receivable of $1.20 billion and $2.20 billion, respectively, and reserves for potential credit losses were not material as of each period end.

[0000106040-19-000058:notes:257]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-19-000058:notes:258]
Supplier Concentration

[0000106040-19-000058:notes:259]
All of the Company’s flash memory system products require silicon wafers for the memory and controller components. The Company’s flash memory wafers are currently supplied almost entirely from Flash Ventures and the controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-19-000058:notes:260]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-19-000058:notes:261]
Western Digital Corporation 401(k) Plan

[0000106040-19-000058:notes:262]
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire unless the individual is covered by a collective bargaining agreement, provides services as a consultant, intern, independent contractor, leased or temporary employee, or otherwise is not treated as a common-law employee.

[0000106040-19-000058:notes:263]
Eligible employees are generally able to contribute up to 30% of their eligible compensation on a pre-tax basis or 10% of their eligible compensation on an after-tax basis subject to Internal Revenue Service (“IRS”) limitations. The Company makes a basic matching contribution equal to 50% of the each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. The Company’s employer matching contributions vest over a two-year graded period. The Company may suspend matching contributions at any time at its discretion. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-19-000058:notes:264]
For 2019, 2018 and 2017, the Company made Plan contributions of $34 million, $35 million and $36 million, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-19-000058:notes:265]
Shareholders’ Equity

[0000106040-19-000058:notes:266]
2017 Performance Incentive Plan

[0000106040-19-000058:notes:267]
The types of awards that may be granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (“2017 Performance Incentive Plan”) include stock options, stock appreciation rights (“SARs”) , RSUs, PSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2017 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2017 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2017 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2017 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics and completion of requisite service periods. Once the performance metrics are met, vesting of PSUs is generally subject to continued service by the employee. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-19-000058:notes:268]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-19-000058:notes:269]
As of June 28, 2019, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2017 Performance Incentive Plan was 88.7 million shares. Shares issued in respect of stock options and SARs granted under the 2017 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas currently, shares issued in respect of any other type of award granted count against the plan’s share limit as 1.72 shares for every one share issued in connection with such award. The 2017 Performance Incentive Plan was extended in 2013 and will terminate on August 4, 2025 unless terminated earlier by the Company’s Board of Directors (the “Board”).

[0000106040-19-000058:notes:270]
Employee Stock Purchase Plan

[0000106040-19-000058:notes:271]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock either at the beginning of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-19-000058:notes:272]
During 2019, 2018 and 2017, the Company issued 2.6 million, 2.5 million, and 2.3 million shares, respectively, for aggregate purchase amounts of $102 million, $119 million and $105 million, respectively.

[0000106040-19-000058:notes:273]
Stock-based Compensation Expense

[0000106040-19-000058:notes:274]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-19-000058:notes:275]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Options | $ | 16 |  |  | $ | 25 |  |  | $ | 41 |  |
| Restricted and performance stock units | 263 |  |  | 325 |  |  | 330 |  |
| Employee stock purchase plan | 27 |  |  | 27 |  |  | 23 |  |
| Total | $ | 306 |  |  | $ | 377 |  |  | $ | 394 |  |

[0000106040-19-000058:notes:276]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Cost of revenue | $ | 48 |  |  | $ | 49 |  |  | $ | 49 |  |
| Research and development | 155 |  |  | 170 |  |  | 173 |  |
| Selling, general and administrative | 103 |  |  | 157 |  |  | 161 |  |
| Employee termination, asset impairment, and other charges | — |  |  | 1 |  |  | 11 |  |
| Subtotal | 306 |  |  | 377 |  |  | 394 |  |
| Tax benefit | (50 | ) |  | (66 | ) |  | (105 | ) |
| Total | $ | 256 |  |  | $ | 311 |  |  | $ | 289 |  |

[0000106040-19-000058:notes:277]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the Company’s ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 28, 2019:

[0000106040-19-000058:notes:278]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 7 |  |  | 1.0 |
| RSUs and PSUs (1) | 485 |  |  | 2.4 |
| ESPP | 65 |  |  | 1.9 |
| Total unamortized compensation cost | $ | 557 |  |  |  |

[0000106040-19-000058:notes:279]
| (1) | Weighted average service period assumes the performance metrics are met for the PSUs. |

[0000106040-19-000058:notes:280]
Plan Activities

[0000106040-19-000058:notes:281]
Stock Options

[0000106040-19-000058:notes:282]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-19-000058:notes:283]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 1, 2016 | 9.0 |  |  | $ | 55.74 |  |  |  |  |  |
| Granted | 2.8 |  |  | 44.83 |  |  |  |  |  |
| Exercised | (3.5 | ) |  | 37.72 |  |  |  |  | $ | 120 |  |
| Canceled or expired | (0.9 | ) |  | 71.31 |  |  |  |  |  |
| Options outstanding at June 30, 2017 | 7.4 |  |  | 58.14 |  |  |  |  |  |
| Exercised | (2.2 | ) |  | 44.52 |  |  |  |  | $ | 99 |  |
| Canceled or expired | (0.4 | ) |  | 60.85 |  |  |  |  |  |
| Options outstanding at June 29, 2018 | 4.8 |  |  | 64.23 |  |  |  |  |  |
| Exercised | (0.4 | ) |  | 39.58 |  |  |  |  | $ | 8 |  |
| Canceled or expired | (0.5 | ) |  | 74.79 |  |  |  |  |  |
| Options outstanding at June 28, 2019 | 3.9 |  |  | $ | 65.72 |  |  | 2.6 |  | $ | 8 |  |
| Exercisable at June 28, 2019 | 3.3 |  |  | $ | 68.97 |  |  | 2.3 |  | $ | 6 |  |

[0000106040-19-000058:notes:284]
RSUs and PSUs

[0000106040-19-000058:notes:285]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-19-000058:notes:286]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | $ | 41.92 |  |  |  |
| Granted | 6.0 |  |  | 44.13 |  |  |  |
| Vested | (5.9 | ) |  | 46.98 |  |  | $ | 399 |  |
| Forfeited | (2.1 | ) |  | 43.89 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | 45.01 |  |  |  |
| Granted | 6.3 |  |  | 74.68 |  |  |  |
| Vested | (6.3 | ) |  | 45.20 |  |  | $ | 552 |  |
| Forfeited | (1.1 | ) |  | 50.35 |  |  |  |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | 58.31 |  |  |  |
| Granted | 7.3 |  |  | 54.82 |  |  |  |
| Vested | (6.3 | ) |  | 53.21 |  |  | $ | 360 |  |
| Forfeited | (2.0 | ) |  | 58.63 |  |  |  |
| RSUs and PSUs outstanding at June 28, 2019 | 11.6 |  |  | $ | 62.07 |  |  |  |

[0000106040-19-000058:notes:287]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-19-000058:notes:288]
Fair Value Valuation Assumptions

[0000106040-19-000058:notes:289]
Stock Option Grants — Binomial Model

[0000106040-19-000058:notes:290]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of assumptions. The Company uses historical data to estimate exercise, employee termination and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. No options were granted in 2019 or 2018. The fair value of stock options granted in 2017 was estimated using the following weighted average assumptions:

[0000106040-19-000058:notes:291]
|  | 2017 |
| Suboptimal exercise factor | 2.69 |
| Range of risk-free interest rates | 0.59% to 1.42% |
| Range of expected stock price volatility | 0.35 to 0.49 |
| Weighted-average expected volatility | 0.40 |
| Post-vesting termination rate | 1.71% |
| Dividend yield | 3.42% |
| Fair value | $13.72 |
| Weighted-average expected term (in years) | 3.6 |

[0000106040-19-000058:notes:292]
RSU and PSU Grants

[0000106040-19-000058:notes:293]
The fair value of the Company’s RSU and PSU awards granted, excluding unvested RSU awards assumed through acquisitions, was based upon the closing price of the Company’s stock price on the date of grant.

[0000106040-19-000058:notes:294]
ESPP — Black-Scholes-Merton Model

[0000106040-19-000058:notes:295]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-19-000058:notes:296]
The fair values of all outstanding ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-19-000058:notes:297]
|  | 2019 |  | 2018 |  | 2017 |
| Weighted-average expected term (in years) | 1.26 |  | 1.24 |  | 1.26 |
| Risk-free interest rate | 2.39% |  | 2.25% |  | 0.81% |
| Stock price volatility | 0.41 |  | 0.35 |  | 0.42 |
| Dividend yield | 4.92% |  | 2.42% |  | 4.02% |
| Fair value | $8.28 |  | $16.89 |  | $10.06 |

[0000106040-19-000058:notes:298]
Stock Repurchase Program

[0000106040-19-000058:notes:299]
The Company’s Board of Directors previously authorized $5.00 billion for the repurchase of the Company’s common stock. On July 25, 2018, the Company’s Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. For the three months ended June 28, 2019, the Company did not make any stock repurchases. For the year ended June 28, 2019, the Company repurchased 0.8 million shares for a total cost of $61 million under the previous authorization and 7.6 million shares for a total cost of $502 million under the new authorization. Therefore, the Company’s stock repurchases under all stock repurchase authorizations in effect for the year ended June 28, 2019 totaled $563 million. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of June 28, 2019 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000058:notes:300]
Stock Reserved for Issuance

[0000106040-19-000058:notes:301]
The following table summarizes all common stock reserved for issuance at June 28, 2019:

[0000106040-19-000058:notes:302]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 33 |  |
| ESPP | 12 |  |
| Total | 45 |  |

[0000106040-19-000058:notes:303]
Dividends to Shareholders

[0000106040-19-000058:notes:304]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the twelve months ended June 28, 2019, the Company declared aggregate cash dividends of $2.00 per share on its outstanding common stock totaling $583 million, including $147 million that was paid on July 15, 2019.

[0000106040-19-000058:notes:305]
On August 7, 2019, the Board declared a cash dividend of $0.50 per share to shareholders of record as of October 4, 2019, which will be paid on October 22, 2019. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time. The amount of future dividends under the Company’s cash dividend policy, and the declaration and payment thereof, will be based upon all relevant factors, including the Company’s financial position, results of operations, cash flows, capital requirements and restrictions under the Company’s Credit Agreement and other financing agreements, and shall be in compliance with applicable law.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-19-000058:notes:306]
Income Tax Expense

[0000106040-19-000058:notes:307]
Income (loss) Before Taxes

[0000106040-19-000058:notes:308]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0000106040-19-000058:notes:309]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Foreign | $ | (642 | ) |  | $ | 2,398 |  |  | $ | 560 |  |
| Domestic | 355 |  |  | (313 | ) |  | 209 |  |
| Income (loss) before taxes | $ | (287 | ) |  | $ | 2,085 |  |  | $ | 769 |  |

[0000106040-19-000058:notes:310]
Income Tax Expense (Benefit)

[0000106040-19-000058:notes:311]
The components of the income tax expense (benefit) were as follows:

[0000106040-19-000058:notes:312]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 181 |  |  | $ | 166 |  |  | $ | 127 |  |
| Domestic - Federal | (91 | ) |  | 1,597 |  |  | 229 |  |
| Domestic - State | 3 |  |  | (5 | ) |  | 4 |  |
|  | 93 |  |  | 1,758 |  |  | 360 |  |
| Deferred: |  |  |  |  |  |
| Foreign | 226 |  |  | (39 | ) |  | 56 |  |
| Domestic - Federal | 141 |  |  | (300 | ) |  | (44 | ) |
| Domestic - State | 7 |  |  | (9 | ) |  | — |  |
|  | 374 |  |  | (348 | ) |  | 12 |  |
| Income tax expense | $ | 467 |  |  | $ | 1,410 |  |  | $ | 372 |  |

[0000106040-19-000058:notes:313]
The 2017 Act includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21% effective January 1, 2018, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign earnings.

[0000106040-19-000058:notes:314]
When initially accounting for the tax effects of the enactment of the 2017 Act, the Company applied the applicable SEC guidance and made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. As the Company finalized the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, the Company reflected adjustments to the recorded provisional amounts. During the second quarter of fiscal 2019, the Company completed its accounting for the tax effects of the enactment of the 2017 Act. Although the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the law along with any available guidance in finalizing its accounting for the tax effects of the 2017 Act. However, any additional regulatory or interpretive guidance would constitute new information which may require further refinements to its estimates in future periods.

[0000106040-19-000058:notes:315]
Additional information regarding the significant provisions of the 2017 Act that impacted the Company is provided below.

[0000106040-19-000058:notes:316]
Re-measurement of deferred taxes

[0000106040-19-000058:notes:317]
The Company recorded a provisional income tax benefit of $65 million for the year ended June 29, 2018, which related to the re-measurements of the Company’s deferred tax balances and was based primarily on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which were generally 29% and 22%, respectively. As of December 28, 2018, the Company had finalized the accounting for the tax effects related to the re-measurements of the Company’s deferred tax balances with no material change. During the third quarter of fiscal 2019, the Company finalized the filing of its U.S. federal income tax return for the year ended June 29, 2018, which resulted in an additional income tax benefit of $5 million for the re-measurement of the Company’s deferred tax assets and liabilities that are expected to reverse at 22%.

[0000106040-19-000058:notes:318]
Mandatory deemed repatriation tax

[0000106040-19-000058:notes:319]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. For the year ended June 29, 2018, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.57 billion for foreign subsidiaries. The calculation of the mandatory deemed repatriation tax liability is based upon post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on the amount of foreign earnings held in cash and other specified assets, which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period.

[0000106040-19-000058:notes:320]
The Company had finalized the accounting for the tax effects of the mandatory deemed repatriation tax during the one-year measurement period permitted by applicable SEC guidance. During the first half of fiscal 2019, the Company reduced its mandatory deemed repatriation tax liability by $302 million, of which $250 million was for the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets was a reclassification that did not have an impact on the Company’s income tax provision for the year ended June 28, 2019. The remaining $52 million reduction to the mandatory deemed repatriation tax primarily related to the Company’s decision to no longer carry forward its 2018 operating loss and, instead, apply it against the mandatory deemed repatriation tax. The $52 million benefit resulted from utilizing the fiscal year 2018 operating losses at a 28% tax rate on the Company’s 2018 tax return as compared to the carryforward tax rate of 21%. The Company also finalized its post-1986 earnings and profits calculation along with the amount of earnings held in cash and other specified assets and increased its mandatory deemed repatriation tax liability by $95 million.

[0000106040-19-000058:notes:321]
Subsequent to the one-year measurement period, the Company finalized the filing of its U.S. federal income tax return for the year ended June 29, 2018, which resulted in a decrease to its mandatory repatriation tax liability by $105 million, of which $41 million related to the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets resulted in an income tax benefit of $19 million for the third quarter of fiscal 2019 with the remaining amount being a reclassification that did not have an impact on the Company’s income tax provision. The remaining $64 million benefit is attributable primarily to the issuance by the IRS of final regulations on January 15, 2019 with respect to the mandatory deemed repatriation tax liability. These regulations favorably impacted certain positions previously taken with respect to amounts recorded in the Company’s Consolidated Financial Statements. The Company’s estimate of the mandatory deemed repatriation tax liability after these refinements was $1.25 billion, excluding a $146 million liability for unrecognized tax benefits.

[0000106040-19-000058:notes:322]
During the one-year measurement period, the Company evaluated the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This required the Company to re-evaluate its existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax of repatriating cash to the U.S. The provisional tax expense recorded by the Company as of June 28, 2018 was based upon an assumption at the time that all of its foreign undistributed earnings would be indefinitely reinvested.

[0000106040-19-000058:notes:323]
During the second quarter of fiscal 2019, the Company finalized the accounting for the tax effects of the mandatory deemed repatriation tax on its indefinite reinvestment assertion. At that time, the Company removed its indefinite reinvestment assertion with the intention to repatriate all of its foreign undistributed earnings. As a result, the Company recorded a foreign income tax expense of $253 million related to foreign withholding taxes partially offset by foreign tax credits of $55 million. In addition, a state income tax expense of $30 million was recorded, partially offset by a decrease to the Company’s valuation allowance of $21 million. The Company’s decision to change its indefinite reinvestment assertion was based on interpretative guidance issued by the IRS at the time related to the ordering and taxation of a repatriation of the Company’s foreign undistributed earnings. During the fourth quarter of fiscal 2019, the IRS issued additional interpretative guidance affecting the taxation of a certain portion of the Company’s foreign undistributed earnings, which could result in additional federal tax. After consideration of this additional interpretative guidance, the Company made the determination that it no longer intends to repatriate this portion of its foreign undistributed earnings and did not establish an accrual for the potential related federal tax liability of $1.25 billion.

[0000106040-19-000058:notes:324]
Deferred taxes on foreign earnings

[0000106040-19-000058:notes:325]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision became effective for the Company with the fiscal year ended June 28, 2019. During the one-year measurement period permitted by applicable SEC guidance, the Company evaluated its accounting policy regarding whether to make an election to account for the effects of this provision either as a component of future income tax expense in the period in which the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities were established for timing differences between foreign U.S. GAAP income and U.S. taxable income that would be expected to reverse under the new minimum tax in future years for the year ended June 29, 2018.

[0000106040-19-000058:notes:326]
Subsequent to June 29, 2018, the Company made the election to account for the effects of the global intangible low-tax income provision as a component of future income tax expense in the period in which the tax arises. There was no change in the Company’s accounting as a result of this election.

[0000106040-19-000058:notes:327]
Deferred Taxes

[0000106040-19-000058:notes:328]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-19-000058:notes:329]
|  | June 28, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 48 |  |  | $ | 53 |  |
| Accrued compensation and benefits not currently deductible | 124 |  |  | 145 |  |
| Net operating loss carryforward | 285 |  |  | 443 |  |
| Business credit carryforward | 410 |  |  | 448 |  |
| Long-lived assets | 144 |  |  | 161 |  |
| Other | 135 |  |  | 118 |  |
| Total deferred tax assets | 1,146 |  |  | 1,368 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (413 | ) |  | (491 | ) |
| Unremitted earnings of certain non-U.S. entities | (220 | ) |  | (5 | ) |
| Other | (32 | ) |  | (43 | ) |
| Total deferred tax liabilities | (665 | ) |  | (539 | ) |
| Valuation allowances | (619 | ) |  | (614 | ) |
| Deferred tax assets (liabilities), net | $ | (138 | ) |  | $ | 215 |  |

[0000106040-19-000058:notes:330]
The change from a net deferred tax asset to a net deferred tax liability is primarily due to a decrease in the deferred tax asset for the utilization of U.S. net operating losses and business credits of $250 million. These assets were utilized to reduce the mandatory repatriation tax liability. In addition, there was an increase in the deferred tax liability with respect to the decision to change the Company’s indefinite reinvestment assertion on its foreign undistributed earnings of $228 million. These amounts are offset in part by the 2019 reversal of the deferred tax liability associated with purchase accounting intangibles of $78 million.

[0000106040-19-000058:notes:331]
The net deferred tax asset valuation allowance increased by $5 million and $96 million in 2019 and 2018, respectively. The valuation allowance increase in 2019 is primarily attributable to the current year generation of state tax credits, net of current year utilization of $23 million, which the Company does not anticipate being able to utilize in future periods. This increase is partially offset by a valuation allowance decrease attributable to a change in the indefinite reinvestment assertion of $21 million for state tax credits, which the Company now anticipates being able to utilize in future periods. The valuation allowance increase in 2018 is primarily attributable to the 2018 generation of foreign net operating loss carryforwards of $54 million and state tax credits of $33 million, which the Company does not anticipate being able to utilize in future periods. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-19-000058:notes:332]
Effective Tax Rate

[0000106040-19-000058:notes:333]
Under the 2017 Act, the reduction of the U.S. federal corporate tax rate from 35% to 21% is effective January 1, 2018, requiring companies to use a blended rate for their fiscal 2018 tax year by applying a pro-rated percentage of the number of days before and after the January 1, 2018 effective date. This results in the use of an estimated annual effective tax rate of approximately 21% for the Company’s U.S. federal corporate tax rate for fiscal year 2018. For fiscal year 2019 and beyond, the Company will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-19-000058:notes:334]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-19-000058:notes:335]
|  | 2019 |  | 2018 |  | 2017 |
| U.S. Federal statutory rate | 21 | % |  | 28 | % |  | 35 | % |
| Tax rate differential on international income | (75 | ) |  | (34 | ) |  | (27 | ) |
| Tax effect of U.S. foreign income inclusion | (7 | ) |  | 1 |  |  | 4 |  |
| Tax effect of U.S. foreign minimum tax | (38 | ) |  | — |  |  | — |  |
| Tax effect of U.S. foreign derived intangible income | 11 |  |  | — |  |  | — |  |
| Tax effect of U.S. non-deductible stock-based compensation | (1 | ) |  | 1 |  |  | 1 |  |
| Tax effect of U.S. permanent differences | (3 | ) |  | (1 | ) |  | (1 | ) |
| State income tax, net of federal tax | — |  |  | — |  |  | 1 |  |
| Impact of 2017 Act: |  |  |  |  |  |
| One-time mandatory deemed repatriation tax | (41 | ) |  | 75 |  |  | — |  |
| Re-measurement of deferred taxes | 2 |  |  | (3 | ) |  | — |  |
| Change in valuation allowance | (2 | ) |  | 5 |  |  | 29 |  |
| Unremitted earnings of certain non-U.S. entities | (79 | ) |  | — |  |  | 5 |  |
| Tax related to SanDisk integration | — |  |  | — |  |  | 12 |  |
| Foreign income tax credits | 23 |  |  | — |  |  | — |  |
| Federal R&D credits | 24 |  |  | (4 | ) |  | (12 | ) |
| Other | 2 |  |  | — |  |  | 1 |  |
| Effective tax rate | (163 | )% |  | 68 | % |  | 48 | % |

[0000106040-19-000058:notes:336]
Tax Holidays and Carryforwards

[0000106040-19-000058:notes:337]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines and Thailand operate under various tax holidays and tax incentive programs which expired or will expire in whole or in part at various dates during fiscal years 2020 through 2030. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $393 million, or $1.33 per diluted share, $519 million, or $1.69 per diluted share, and $467 million, or $1.58 per diluted share, in 2019, 2018, and 2017, respectively.

[0000106040-19-000058:notes:338]
As of June 28, 2019, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-19-000058:notes:339]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 700 |  |  | 2021 to 2037 |
| Federal NOL (Post 2017 Act Generation) | — |  |  | No expiration |
| State NOL | 619 |  |  | 2021 to 2038 |
| Federal tax credits | 59 |  |  | 2020 to 2034 |
| State tax credits | 578 |  |  | No expiration |

[0000106040-19-000058:notes:340]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal and state NOLs ultimately realized will be reduced as a result of these provisions by $128 million and $361 million, respectively. The Company expects the total amount of federal and state credits ultimately realized will be reduced as a result of these provisions by $28 million and $2 million, respectively.

[0000106040-19-000058:notes:341]
As of June 28, 2019, the Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-19-000058:notes:342]
| Jurisdiction |  | NOL Carryforward Amount |  | Expiration |
|  |  | (in millions) |  |  |
| Japan |  | $ | 132 |  |  | 2024 to 2026 |
| Belgium |  | 105 |  |  | No expiration |
| China |  | 133 |  |  | 2023 to 2024 |
| Spain |  | 52 |  |  | No expiration |

[0000106040-19-000058:notes:343]
Uncertain Tax Positions

[0000106040-19-000058:notes:344]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 28, 2019, June 29, 2018 and June 30, 2017 was $123 million, $110 million and $89 million, respectively.

[0000106040-19-000058:notes:345]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-19-000058:notes:346]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 551 |  |  | $ | 522 |  |  | $ | 491 |  |
| Gross increases related to current year tax positions | 172 |  |  | 38 |  |  | 35 |  |
| Gross increases related to prior year tax positions | 8 |  |  | 30 |  |  | 3 |  |
| Gross decreases related to prior year tax positions | (24 | ) |  | (9 | ) |  | (8 | ) |
| Settlements | (1 | ) |  | (19 | ) |  | (8 | ) |
| Lapse of statute of limitations | (11 | ) |  | (11 | ) |  | (19 | ) |
| Acquisitions | — |  |  | — |  |  | 28 |  |
| Unrecognized tax benefit, ending balance | $ | 695 |  |  | $ | 551 |  |  | $ | 522 |  |

[0000106040-19-000058:notes:347]
Included within long-term liabilities in the Consolidated Balance Sheets are the Company’s payable related to unrecognized tax benefits including accrued interest and penalties of $699 million, $508 million, and $493 million as of June 28, 2019, June 29, 2018 and June 30, 2017, respectively. The entire balance of the gross unrecognized tax benefits as of June 28, 2019, June 29, 2018 and June 30, 2017, if recognized, would affect the effective tax rate.

[0000106040-19-000058:notes:348]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2013 through 2018. The Company is no longer subject to examination by the IRS for periods prior to 2012, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the major foreign jurisdictions, the Company could be subject to examination in China for calendar years 2009 through 2018, in Ireland for calendar years 2014 through 2018, in India for fiscal years 2014 through 2018, in Israel for fiscal years 2014 through 2018 and in Japan for fiscal years 2012 through 2018.

[0000106040-19-000058:notes:349]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-19-000058:notes:350]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 28, 2019, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-19-000058:notes:351]
Net Income (Loss) Per Common Share

[0000106040-19-000058:notes:352]
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-19-000058:notes:353]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (754 | ) |  | $ | 675 |  |  | $ | 397 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 292 |  |  | 297 |  |  | 288 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | 10 |  |  | 8 |  |
| Diluted | 292 |  |  | 307 |  |  | 296 |  |
| Income (loss) per common share |  |  |  |  |  |
| Basic | $ | (2.58 | ) |  | $ | 2.27 |  |  | $ | 1.38 |  |
| Diluted | $ | (2.58 | ) |  | $ | 2.20 |  |  | $ | 1.34 |  |

[0000106040-19-000058:notes:354]
The Company computes basic income (loss) per common share using net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For 2018 and 2017, the Company excluded 2 million and 3 million common shares, respectively, subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For 2019, the Company reported a net loss, and all outstanding equity awards have been excluded from such periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-19-000058:notes:355]
Employee Termination, Asset Impairment and Other Charges

[0000106040-19-000058:notes:356]
The Company recorded the following charges related to employee terminations benefits, asset impairment, and other charges:

[0000106040-19-000058:notes:357]
|  | 2019 |  | 2018 |  | 2017 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | 22 |  |  | $ | 56 |  |  | $ | 10 |  |
| Business Realignment | 144 |  |  | 50 |  |  | 72 |  |
| Restructuring Plan 2016 | — |  |  | 92 |  |  | 128 |  |
| Total employee termination and other charges | 166 |  |  | 198 |  |  | 210 |  |
| Asset impairment: |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | 16 |  |  | — |  |
| Closure of Foreign Manufacturing Facility | — |  |  | — |  |  | 11 |  |
| Total asset impairment | — |  |  | 16 |  |  | 11 |  |
| Stock-based compensation accelerations and adjustments: |  |  |  |  |  |
| Business Realignment | — |  |  | 1 |  |  | 11 |  |
| Total stock-based compensation accelerations and adjustments | — |  |  | 1 |  |  | 11 |  |
| Total employee termination, asset impairment, and other charges | $ | 166 |  |  | $ | 215 |  |  | $ | 232 |  |

[0000106040-19-000058:notes:358]
Closure of Foreign Manufacturing Facilities

[0000106040-19-000058:notes:359]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company substantially completed the closure as of June 28, 2019. The Company incurred charges of $10 million in employee termination benefits and $12 million in contract termination and other charges in the year ended June 28, 2019 and $56 million of employee termination benefits in the year ended June 29, 2018.

[0000106040-19-000058:notes:360]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the year ended June 28, 2019:

[0000106040-19-000058:notes:361]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 56 |  |  | $ | — |  |  | $ | 56 |  |
| Charges | 10 |  |  | 12 |  |  | 22 |  |
| Cash payments | (36 | ) |  | (10 | ) |  | (46 | ) |
| Accrual balance at June 28, 2019 | $ | 30 |  |  | $ | 2 |  |  | $ | 32 |  |

[0000106040-19-000058:notes:362]
Business Realignment

[0000106040-19-000058:notes:363]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting organization rationalization designed to streamline our business, reduce our cost structure and focus our resources.

[0000106040-19-000058:notes:364]
The following table presents an analysis of the components of the activity against the reserve during the year ended June 28, 2019:

[0000106040-19-000058:notes:365]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |
| Charges | 131 |  |  | 13 |  |  | 144 |  |
| Cash payments | (125 | ) |  | (10 | ) |  | (135 | ) |
| Accrual balance at June 28, 2019 | $ | 37 |  |  | $ | 8 |  |  | $ | 45 |  |

[0000106040-19-000058:notes:366]
Restructuring Plan 2016

[0000106040-19-000058:notes:367]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consisted of asset and footprint reductions, product road map consolidation and organization rationalization. These actions were substantially completed in fiscal year 2018.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-19-000058:notes:368]
Legal Proceedings

[0000106040-19-000058:notes:369]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-19-000058:notes:370]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-19-000058:notes:371]
Intellectual Property Litigation

[0000106040-19-000058:notes:372]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. Mediation in this matter was held on August 16, 2019, and the parties reached an agreement in principle to settle the case for an immaterial amount, a portion of which has been previously accrued in the Company’s financial statements. The parties expect to formalize the settlement and obtain court dismissal of the litigation during the first half of fiscal 2020. In the event the settlement is not formalized and the agreement in principle is deemed not enforceable, the Company intends to continue to defend itself vigorously in this matter.

[0000106040-19-000058:notes:373]
Securities

[0000106040-19-000058:notes:374]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015. The Institutional Investor Group alleged artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter, subject to formal ratification by party representatives and approval by the court. In May 2019, the court granted the motion for preliminary approval and scheduled a hearing on the final approval for September 2019. The charge related to the settlement was recorded in Selling, general and administrative expense.

[0000106040-19-000058:notes:375]
Tax

[0000106040-19-000058:notes:376]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 13, Income Tax Expense.

[0000106040-19-000058:notes:377]
Other Matters

[0000106040-19-000058:notes:378]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## srt:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-19-000058:notes:379]
Separate Financial Information of Guarantor Subsidiaries

[0000106040-19-000058:notes:380]
The Company’s 2026 Senior Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-19-000058:notes:381]
| Condensed Consolidating Balance Sheet |
| As of June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 8 |  |  | $ | 985 |  |  | $ | 2,462 |  |  | $ | — |  |  | $ | 3,455 |  |
| Accounts receivable, net | — |  |  | 779 |  |  | 425 |  |  | — |  |  | 1,204 |  |
| Intercompany receivables | 2,409 |  |  | 5,808 |  |  | 1,581 |  |  | (9,798 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,438 |  |  | (145 | ) |  | 3,283 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 50 |  |  | (50 | ) |  | — |  |
| Other current assets | 2 |  |  | 251 |  |  | 282 |  |  | — |  |  | 535 |  |
| Total current assets | 2,419 |  |  | 8,813 |  |  | 7,238 |  |  | (9,993 | ) |  | 8,477 |  |
| Property, plant and equipment, net | — |  |  | 873 |  |  | 1,970 |  |  | — |  |  | 2,843 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,791 |  |  | — |  |  | 2,791 |  |
| Goodwill | — |  |  | 388 |  |  | 9,688 |  |  | — |  |  | 10,076 |  |
| Other intangible assets, net | — |  |  | 23 |  |  | 1,688 |  |  | — |  |  | 1,711 |  |
| Investments in consolidated subsidiaries | 20,772 |  |  | 16,355 |  |  | — |  |  | (37,127 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 674 |  |  | — |  |  | (674 | ) |  | — |  |
| Other non-current assets | 60 |  |  | 51 |  |  | 361 |  |  | — |  |  | 472 |  |
| Total assets | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 195 |  |  | $ | 1,372 |  |  | $ | — |  |  | $ | 1,567 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 331 |  |  | — |  |  | 331 |  |
| Intercompany payables | 1,871 |  |  | 3,515 |  |  | 4,412 |  |  | (9,798 | ) |  | — |  |
| Accrued expenses | 195 |  |  | 522 |  |  | 579 |  |  | — |  |  | 1,296 |  |
| Accrued compensation | — |  |  | 214 |  |  | 133 |  |  | — |  |  | 347 |  |
| Loans due to consolidated affiliates | — |  |  | 50 |  |  | — |  |  | (50 | ) |  | — |  |
| Current portion of long-term debt | 276 |  |  | — |  |  | — |  |  | — |  |  | 276 |  |
| Total current liabilities | 2,342 |  |  | 4,496 |  |  | 6,827 |  |  | (9,848 | ) |  | 3,817 |  |
| Long-term debt | 10,213 |  |  | — |  |  | 33 |  |  | — |  |  | 10,246 |  |
| Loans due to consolidated affiliates | 674 |  |  | — |  |  | — |  |  | (674 | ) |  | — |  |
| Other liabilities | 55 |  |  | 1,795 |  |  | 490 |  |  | — |  |  | 2,340 |  |
| Total liabilities | 13,284 |  |  | 6,291 |  |  | 7,350 |  |  | (10,522 | ) |  | 16,403 |  |
| Total shareholders’ equity | 9,967 |  |  | 20,886 |  |  | 16,386 |  |  | (37,272 | ) |  | 9,967 |  |
| Total liabilities and shareholders’ equity | $ | 23,251 |  |  | $ | 27,177 |  |  | $ | 23,736 |  |  | $ | (47,794 | ) |  | $ | 26,370 |  |

[0000106040-19-000058:notes:382]
| Condensed Consolidating Balance Sheet |
| As of June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |
| Accounts receivable, net | — |  |  | 1,358 |  |  | 839 |  |  | — |  |  | 2,197 |  |
| Intercompany receivables | 1,903 |  |  | 4,256 |  |  | 2,674 |  |  | (8,833 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,159 |  |  | (205 | ) |  | 2,944 |  |
| Other current assets | 20 |  |  | 195 |  |  | 277 |  |  | — |  |  | 492 |  |
| Total current assets | 1,963 |  |  | 7,467 |  |  | 10,246 |  |  | (9,038 | ) |  | 10,638 |  |
| Property, plant and equipment, net | — |  |  | 1,092 |  |  | 2,003 |  |  | — |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,105 |  |  | — |  |  | 2,105 |  |
| Goodwill | — |  |  | 387 |  |  | 9,688 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 38 |  |  | 2,642 |  |  | — |  |  | 2,680 |  |
| Investments in consolidated subsidiaries | 20,847 |  |  | 19,893 |  |  | — |  |  | (40,740 | ) |  | — |  |
| Loans due from consolidated affiliates | 943 |  |  | 16 |  |  | — |  |  | (959 | ) |  | — |  |
| Other non-current assets | 182 |  |  | 29 |  |  | 431 |  |  | — |  |  | 642 |  |
| Total assets | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 279 |  |  | $ | 1,986 |  |  | $ | — |  |  | $ | 2,265 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Intercompany payables | 1,066 |  |  | 4,648 |  |  | 3,119 |  |  | (8,833 | ) |  | — |  |
| Accrued expenses | 198 |  |  | 505 |  |  | 571 |  |  | — |  |  | 1,274 |  |
| Accrued compensation | — |  |  | 297 |  |  | 182 |  |  | — |  |  | 479 |  |
| Current portion of long-term debt | 179 |  |  | — |  |  | — |  |  | — |  |  | 179 |  |
| Total current liabilities | 1,443 |  |  | 5,729 |  |  | 6,117 |  |  | (8,833 | ) |  | 4,456 |  |
| Long-term debt | 10,962 |  |  | — |  |  | 31 |  |  | — |  |  | 10,993 |  |
| Loans due to consolidated affiliates | — |  |  | 427 |  |  | 532 |  |  | (959 | ) |  | — |  |
| Other liabilities | (1 | ) |  | 1,768 |  |  | 488 |  |  | — |  |  | 2,255 |  |
| Total liabilities | 12,404 |  |  | 7,924 |  |  | 7,168 |  |  | (9,792 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,531 |  |  | 20,998 |  |  | 19,947 |  |  | (40,945 | ) |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |

[0000106040-19-000058:notes:383]
| Condensed Consolidating Statement of Operations |
| For the year ended June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 12,860 |  |  | $ | 17,189 |  |  | $ | (13,480 | ) |  | $ | 16,569 |  |
| Cost of revenue | — |  |  | 11,237 |  |  | 15,138 |  |  | (13,558 | ) |  | 12,817 |  |
| Gross profit | — |  |  | 1,623 |  |  | 2,051 |  |  | 78 |  |  | 3,752 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,376 |  |  | 806 |  |  | — |  |  | 2,182 |  |
| Selling, general and administrative | 2 |  |  | 865 |  |  | 450 |  |  | — |  |  | 1,317 |  |
| Intercompany operating expense (income) | 16 |  |  | (1,523 | ) |  | 1,507 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 85 |  |  | 81 |  |  | — |  |  | 166 |  |
| Total operating expenses | 18 |  |  | 803 |  |  | 2,844 |  |  | — |  |  | 3,665 |  |
| Operating income (loss) | (18 | ) |  | 820 |  |  | (793 | ) |  | 78 |  |  | 87 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 25 |  |  | 46 |  |  | (24 | ) |  | 57 |  |
| Interest expense | (478 | ) |  | (9 | ) |  | (6 | ) |  | 24 |  |  | (469 | ) |
| Other income (expense), net | 1 |  |  | (6 | ) |  | 43 |  |  | — |  |  | 38 |  |
| Total interest and other income (expense), net | (467 | ) |  | 10 |  |  | 83 |  |  | — |  |  | (374 | ) |
| Income (loss) before taxes | (485 | ) |  | 830 |  |  | (710 | ) |  | 78 |  |  | (287 | ) |
| Equity in earnings from subsidiaries | (418 | ) |  | (867 | ) |  | — |  |  | 1,285 |  |  | — |  |
| Income tax expense (benefit) | (149 | ) |  | 457 |  |  | 159 |  |  | — |  |  | 467 |  |
| Net loss | $ | (754 | ) |  | $ | (494 | ) |  | $ | (869 | ) |  | $ | 1,363 |  |  | $ | (754 | ) |

[0000106040-19-000058:notes:384]
| Condensed Consolidating Statement of Operations |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,913 |  |  | $ | 20,155 |  |  | $ | (14,421 | ) |  | $ | 20,647 |  |
| Cost of revenue | — |  |  | 12,913 |  |  | 14,573 |  |  | (14,544 | ) |  | 12,942 |  |
| Gross profit | — |  |  | 2,000 |  |  | 5,582 |  |  | 123 |  |  | 7,705 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,551 |  |  | 849 |  |  | — |  |  | 2,400 |  |
| Selling, general and administrative | 8 |  |  | 1,044 |  |  | 421 |  |  | — |  |  | 1,473 |  |
| Intercompany operating expense (income) | — |  |  | (1,626 | ) |  | 1,626 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 47 |  |  | 167 |  |  | — |  |  | 215 |  |
| Total operating expenses | 9 |  |  | 1,016 |  |  | 3,063 |  |  | — |  |  | 4,088 |  |
| Operating income (loss) | (9 | ) |  | 984 |  |  | 2,519 |  |  | 123 |  |  | 3,617 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 211 |  |  | 8 |  |  | 51 |  |  | (210 | ) |  | 60 |  |
| Interest expense | (674 | ) |  | (21 | ) |  | (191 | ) |  | 210 |  |  | (676 | ) |
| Other expense, net | (905 | ) |  | (9 | ) |  | (2 | ) |  | — |  |  | (916 | ) |
| Total interest and other expense, net | (1,368 | ) |  | (22 | ) |  | (142 | ) |  | — |  |  | (1,532 | ) |
| Income (loss) before taxes | (1,377 | ) |  | 962 |  |  | 2,377 |  |  | 123 |  |  | 2,085 |  |
| Equity in earnings from subsidiaries | 1,698 |  |  | 2,223 |  |  | — |  |  | (3,921 | ) |  | — |  |
| Income tax expense (benefit) | (354 | ) |  | 1,633 |  |  | 131 |  |  | — |  |  | 1,410 |  |
| Net income | $ | 675 |  |  | $ | 1,552 |  |  | $ | 2,246 |  |  | $ | (3,798 | ) |  | $ | 675 |  |

[0000106040-19-000058:notes:385]
| Condensed Consolidating Statement of Operations |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,732 |  |  | $ | 16,381 |  |  | $ | (12,020 | ) |  | $ | 19,093 |  |
| Cost of revenue | — |  |  | 12,786 |  |  | 12,203 |  |  | (11,968 | ) |  | 13,021 |  |
| Gross profit | — |  |  | 1,946 |  |  | 4,178 |  |  | (52 | ) |  | 6,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,619 |  |  | 822 |  |  | — |  |  | 2,441 |  |
| Selling, general and administrative | 6 |  |  | 1,006 |  |  | 433 |  |  | — |  |  | 1,445 |  |
| Intercompany operating expense (income) | — |  |  | (1,736 | ) |  | 1,736 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 88 |  |  | 144 |  |  | — |  |  | 232 |  |
| Total operating expenses | 6 |  |  | 977 |  |  | 3,135 |  |  | — |  |  | 4,118 |  |
| Operating income (loss) | (6 | ) |  | 969 |  |  | 1,043 |  |  | (52 | ) |  | 1,954 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 347 |  |  | 11 |  |  | 22 |  |  | (354 | ) |  | 26 |  |
| Interest expense | (843 | ) |  | (10 | ) |  | (348 | ) |  | 354 |  |  | (847 | ) |
| Other income (expense), net | (290 | ) |  | 49 |  |  | (61 | ) |  | (62 | ) |  | (364 | ) |
| Total interest and other income (expense), net | (786 | ) |  | 50 |  |  | (387 | ) |  | (62 | ) |  | (1,185 | ) |
| Income (loss) before taxes | (792 | ) |  | 1,019 |  |  | 656 |  |  | (114 | ) |  | 769 |  |
| Equity in earnings from subsidiaries | 907 |  |  | 287 |  |  | — |  |  | (1,194 | ) |  | — |  |
| Income tax expense (benefit) | (282 | ) |  | 259 |  |  | 395 |  |  | — |  |  | 372 |  |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |

[0000106040-19-000058:notes:386]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (754 | ) |  | $ | (494 | ) |  | $ | (869 | ) |  | $ | 1,363 |  |  | $ | (754 | ) |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (39 | ) |  | (39 | ) |  | (39 | ) |  | 78 |  |  | (39 | ) |
| Foreign currency translation adjustment | 28 |  |  | 31 |  |  | 31 |  |  | (62 | ) |  | 28 |  |
| Net unrealized gain (loss), on derivative contracts and available-for-sale securities | (39 | ) |  | 40 |  |  | 38 |  |  | (78 | ) |  | (39 | ) |
| Total other comprehensive income (loss), before tax | (50 | ) |  | 32 |  |  | 30 |  |  | (62 | ) |  | (50 | ) |
| Income tax benefit related to items of other comprehensive income (loss) | 21 |  |  | 1 |  |  | 2 |  |  | (3 | ) |  | 21 |  |
| Other comprehensive income (loss), net of tax | (29 | ) |  | 33 |  |  | 32 |  |  | (65 | ) |  | (29 | ) |
| Total comprehensive loss | $ | (783 | ) |  | $ | (461 | ) |  | $ | (837 | ) |  | $ | 1,298 |  |  | $ | (783 | ) |

[0000106040-19-000058:notes:387]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 675 |  |  | $ | 1,552 |  |  | $ | 2,246 |  |  | $ | (3,798 | ) |  | $ | 675 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (2 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (2 | ) |
| Foreign currency translation adjustment | 18 |  |  | 15 |  |  | 15 |  |  | (30 | ) |  | 18 |  |
| Net unrealized gain on derivative contracts and available-for-sale securities | 7 |  |  | (10 | ) |  | (6 | ) |  | 16 |  |  | 7 |  |
| Total other comprehensive income, before tax | 23 |  |  | 3 |  |  | 7 |  |  | (10 | ) |  | 23 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (4 | ) |  | 1 |  |  | (1 | ) |  | — |  |  | (4 | ) |
| Other comprehensive income, net of tax | 19 |  |  | 4 |  |  | 6 |  |  | (10 | ) |  | 19 |  |
| Total comprehensive income | $ | 694 |  |  | $ | 1,556 |  |  | $ | 2,252 |  |  | $ | (3,808 | ) |  | $ | 694 |  |

[0000106040-19-000058:notes:388]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  | — |  |
| Actuarial pension gain | 39 |  |  | 39 |  |  | 39 |  |  | (78 | ) |  | 39 |  |
| Foreign currency translation adjustment | (115 | ) |  | (113 | ) |  | (136 | ) |  | 249 |  |  | (115 | ) |
| Net unrealized loss on derivative contracts and available-for-sale securities | (75 | ) |  | (75 | ) |  | (73 | ) |  | 148 |  |  | (75 | ) |
| Total other comprehensive loss, before tax | (151 | ) |  | (149 | ) |  | (170 | ) |  | 319 |  |  | (151 | ) |
| Income tax expense related to items of other comprehensive loss | (10 | ) |  | (10 | ) |  | (8 | ) |  | 18 |  |  | (10 | ) |
| Other comprehensive loss, net of tax | (161 | ) |  | (159 | ) |  | (178 | ) |  | 337 |  |  | (161 | ) |
| Total comprehensive income | $ | 236 |  |  | $ | 888 |  |  | $ | 83 |  |  | $ | (971 | ) |  | $ | 236 |  |

[0000106040-19-000058:notes:389]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 28, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 160 |  |  | $ | (1,286 | ) |  | $ | 2,723 |  |  | $ | (50 | ) |  | $ | 1,547 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (250 | ) |  | (626 | ) |  | — |  |  | (876 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | 116 |  |  | 3 |  |  | — |  |  | 119 |  |
| Purchases of investments | — |  |  | (11 | ) |  | (68 | ) |  | — |  |  | (79 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (1,364 | ) |  | — |  |  | (1,364 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 766 |  |  | — |  |  | 766 |  |
| Strategic investments and other, net | — |  |  | 2 |  |  | (22 | ) |  | — |  |  | (20 | ) |
| Intercompany loan from (to) consolidated affiliates | 943 |  |  | (659 | ) |  | 1 |  |  | (285 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (342 | ) |  | 342 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 601 |  |  | (460 | ) |  | (1,128 | ) |  | (285 | ) |  | (1,272 | ) |
| Cash flows from financing activities |  |  |  |  |  |  | — |  |  |  |
| Issuance of stock under employee stock plans | 118 |  |  | — |  |  | — |  |  | — |  |  | 118 |  |
| Taxes paid on vested stock awards under employee stock plans | (115 | ) |  | — |  |  | — |  |  | — |  |  | (115 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Dividends paid to shareholders | (584 | ) |  | — |  |  | — |  |  | — |  |  | (584 | ) |
| Repayment of debt | (181 | ) |  | — |  |  | — |  |  | — |  |  | (181 | ) |
| Repayment of revolving credit facility | (500 | ) |  | — |  |  | — |  |  | — |  |  | (500 | ) |
| Debt issuance costs | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Intercompany loan from (to) consolidated affiliates | 674 |  |  | (377 | ) |  | (582 | ) |  | 285 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 362 |  |  | 2,440 |  |  | (2,852 | ) |  | 50 |  |  | — |  |
| Net cash provided by (used in) financing activities | (793 | ) |  | 2,063 |  |  | (3,434 | ) |  | 335 |  |  | (1,829 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net increase (decrease) in cash and cash equivalents | (32 | ) |  | 317 |  |  | (1,835 | ) |  | — |  |  | (1,550 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | $ | 8 |  |  | $ | 985 |  |  | $ | 2,462 |  |  | $ | — |  |  | $ | 3,455 |  |

[0000106040-19-000058:notes:390]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (144 | ) |  | $ | 211 |  |  | $ | 4,158 |  |  | $ | (20 | ) |  | $ | 4,205 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (220 | ) |  | (615 | ) |  | — |  |  | (835 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Acquisitions, net of cash acquired | — |  |  | (94 | ) |  | (6 | ) |  | — |  |  | (100 | ) |
| Purchases of investments | — |  |  | (21 | ) |  | (68 | ) |  | — |  |  | (89 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (1,313 | ) |  | — |  |  | (1,313 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 571 |  |  | — |  |  | 571 |  |
| Strategic investments and other, net | — |  |  | (2 | ) |  | 20 |  |  | — |  |  | 18 |  |
| Intercompany loan from consolidated affiliates | 3,757 |  |  | — |  |  | — |  |  | (3,757 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (86 | ) |  | 86 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 3,671 |  |  | (251 | ) |  | (1,318 | ) |  | (3,757 | ) |  | (1,655 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 220 |  |  | — |  |  | — |  |  | — |  |  | 220 |  |
| Taxes paid on vested stock awards under employee stock plans | (171 | ) |  | — |  |  | — |  |  | — |  |  | (171 | ) |
| Repurchases of common stock | (591 | ) |  | — |  |  | — |  |  | — |  |  | (591 | ) |
| Dividends paid to shareholders | (593 | ) |  | — |  |  | — |  |  | — |  |  | (593 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt | (17,074 | ) |  | — |  |  | — |  |  | — |  |  | (17,074 | ) |
| Proceeds from debt | 13,840 |  |  | — |  |  | — |  |  | — |  |  | 13,840 |  |
| Proceeds from revolving credit facility | 500 |  |  | — |  |  | — |  |  | — |  |  | 500 |  |
| Debt issuance costs | (59 | ) |  | — |  |  | — |  |  | — |  |  | (59 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (119 | ) |  | (3,638 | ) |  | 3,757 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 395 |  |  | (385 | ) |  | (30 | ) |  | 20 |  |  | — |  |
| Net cash used in financing activities | (3,505 | ) |  | (504 | ) |  | (3,668 | ) |  | 3,777 |  |  | (3,900 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 22 |  |  | (544 | ) |  | (827 | ) |  | — |  |  | (1,349 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of year | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |

[0000106040-19-000058:notes:391]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (360 | ) |  | $ | (836 | ) |  | $ | 4,593 |  |  | $ | 40 |  |  | $ | 3,437 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (240 | ) |  | (338 | ) |  | — |  |  | (578 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Purchases of investments | — |  |  | — |  |  | (281 | ) |  | — |  |  | (281 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 94 |  |  | — |  |  | 94 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 417 |  |  | — |  |  | 417 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (549 | ) |  | — |  |  | (549 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 292 |  |  | — |  |  | 292 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | (31 | ) |  | — |  |  | (32 | ) |
| Intercompany loans from consolidated affiliates | 1,300 |  |  | 39 |  |  | — |  |  | (1,339 | ) |  | — |  |
| Advances from (to) consolidated affiliates | (158 | ) |  | 166 |  |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,142 |  |  | (36 | ) |  | (395 | ) |  | (1,347 | ) |  | (636 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 235 |  |  | — |  |  | — |  |  | — |  |  | 235 |  |
| Taxes paid on vested stock awards under employee stock plans | (124 | ) |  | — |  |  | — |  |  | — |  |  | (124 | ) |
| Excess tax benefits from employee stock plans | 119 |  |  | — |  |  | — |  |  | — |  |  | 119 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Settlement of convertible debt | — |  |  | — |  |  | (492 | ) |  | — |  |  | (492 | ) |
| Dividends paid to shareholders | (574 | ) |  | — |  |  | — |  |  | — |  |  | (574 | ) |
| Settlement of debt hedge contracts | — |  |  | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Repayment of debt | (8,702 | ) |  | (2,995 | ) |  | — |  |  | — |  |  | (11,697 | ) |
| Proceeds from debt | 7,908 |  |  | — |  |  | — |  |  | — |  |  | 7,908 |  |
| Debt issuance costs | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (5,454 | ) |  | 4,115 |  |  | 1,339 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 384 |  |  | 9,348 |  |  | (9,700 | ) |  | (32 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (764 | ) |  | 878 |  |  | (6,016 | ) |  | 1,307 |  |  | (4,595 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | 18 |  |  | 6 |  |  | (1,821 | ) |  | — |  |  | (1,797 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-19-000058:notes:392]
Quarterly Results of Operations (unaudited)

[0000106040-19-000058:notes:393]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2019 |  |  |  |  |  |  |  |
| Revenue, net | $ | 5,028 |  |  | $ | 4,233 |  |  | $ | 3,674 |  |  | $ | 3,634 |  |
| Gross profit | 1,664 |  |  | 1,044 |  |  | 579 |  |  | 465 |  |
| Operating income (loss) | 686 |  |  | 176 |  |  | (394 | ) |  | (381 | ) |
| Net income (loss) | 511 |  |  | (487 | ) |  | (581 | ) |  | (197 | ) |
| Basic income (loss) per common share | $ | 1.75 |  |  | $ | (1.68 | ) |  | $ | (1.99 | ) |  | $ | (0.67 | ) |
| Diluted income (loss) per common share | $ | 1.71 |  |  | $ | (1.68 | ) |  | $ | (1.99 | ) |  | $ | (0.67 | ) |

[0000106040-19-000058:notes:394]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2018 |  |  |  |  |  |  |  |
| Revenue, net | $ | 5,181 |  |  | $ | 5,336 |  |  | $ | 5,013 |  |  | $ | 5,117 |  |
| Gross profit | 1,913 |  |  | 2,013 |  |  | 1,927 |  |  | 1,852 |  |
| Operating income (loss) | 905 |  |  | 955 |  |  | 914 |  |  | 843 |  |
| Net income (loss) | 681 |  |  | (823 | ) |  | 61 |  |  | 756 |  |
| Basic income (loss) per common share | $ | 2.31 |  |  | $ | (2.78 | ) |  | $ | 0.20 |  |  | $ | 2.53 |  |
| Diluted income (loss) per common share | $ | 2.23 |  |  | $ | (2.78 | ) |  | $ | 0.20 |  |  | $ | 2.46 |  |
