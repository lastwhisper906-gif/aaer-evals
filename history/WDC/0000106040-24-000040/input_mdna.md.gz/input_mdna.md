# WDC MD&A — 0000106040-24-000040


## mdna

[0000106040-24-000040:mdna:1]
[same as prior period, unchanged from 0000106040-24-000022:mdna:1]

[0000106040-24-000040:mdna:2]
[same as prior period, unchanged from 0000106040-24-000022:mdna:2]

[0000106040-24-000040:mdna:3]
[same as prior period, unchanged from 0000106040-24-000022:mdna:3]

[0000106040-24-000040:mdna:4]
We are a leading developer, manufacturer, and provider of data storage devices based on both hard disk drive and NAND flash technologies. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful HDD and Flash storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-24-000040:mdna:5]
Our broad portfolio of technology and products addresses our multiple end markets: “Cloud,” “Client,” and “Consumer”. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our original equipment manufacturer “OEM” and channel customers a broad array of high-performance HDD and Flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-24-000040:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-24-000040:mdna:7]
[same as prior period, unchanged from 0000106040-24-000022:mdna:7]

[0000106040-24-000040:mdna:8]
[same as prior period, unchanged from 0000106040-24-000022:mdna:8]

[0000106040-24-000040:mdna:9]
On October 30, 2023, we announced that our Board of Directors had completed its strategic review of our business and, after evaluating a comprehensive range of alternatives, authorized us to pursue a plan to separate our HDD and Flash business units to create two independent, public companies. We believe the separation will better position each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, and operate more efficiently with distinct capital structures. The completion of the planned separation is subject to certain conditions, including final approval by our Board of Directors. At the beginning of our second quarter of fiscal 2025, we entered the soft-spin phase of our separation plan. The soft-spin phase represents the period when we begin testing critical processes and systems for each future HDD and Flash company to ensure that both are ready to operate independently at legal separation. We continue to make progress on the work required to execute the separation, which we expect will occur after we close the second quarter of fiscal 2025.

[0000106040-24-000040:mdna:10]
[same as prior period, unchanged from 0000106040-24-000022:mdna:10]

[0000106040-24-000040:mdna:11]
Macroeconomic factors such as inflation, changes in interest rates, and recession concerns softened demand for our products during 2023 and the first half of 2024. As a result, we and our industry experienced a supply-demand imbalance, which resulted in reduced shipments and negatively impacted pricing during those periods. To adapt to these conditions, since the beginning of 2023, we implemented measures to reduce operating expenses and proactively manage supply and inventory to align with demand and improve our capital efficiency while continuing to deploy innovative products. These actions enabled us to scale back on capital expenditures, consolidate production lines, and reduce production. During the first quarter of 2024, these actions resulted in incremental charges for employee termination, asset impairment, and charges for unabsorbed manufacturing overhead costs in HDD and Flash due to the underutilization of facilities as we temporarily scaled back production.

[0000106040-24-000040:mdna:12]
We are now seeing an improvement in the supply and demand dynamic, leading to improved revenues. The increase in demand resulted in increased revenue and gross margin across our segments in the first quarter of 2025 from the comparable period in the prior year. We anticipate that digital transformation, including the AI data-cycle, will continue to drive improved market conditions in the near- and long-term for data storage, encompassing HDD and Flash technologies. Leveraging our expertise and innovation in both areas, we believe we are well-positioned to capitalize on this improved market condition.

[0000106040-24-000040:mdna:13]
[same as prior period, unchanged from 0000106040-24-000022:mdna:12]

[0000106040-24-000040:mdna:14]
Sale of a Majority Interest in a Subsidiary

[0000106040-24-000040:mdna:15]
As discussed in Part I, Item 1, Note 4, Supplemental Financial Statement Data, of the Notes to Condensed Consolidated Financial Statements, in March 2024, we entered into an agreement to sell 80% of the equity interest in one of our Flash manufacturing subsidiaries to JCET, a third-party contract manufacturing company. Subsequent to the first quarter of fiscal 2025, on September 28, 2024, the transaction closed. In connection with this transaction, we entered into a 5-year supply agreement with JCET to purchase wafers with a minimum annual commitment of $550 million.

[0000106040-24-000040:mdna:16]
As a result of this transaction, we expect to incur a modest reduction in annual operating expenses and a reduction in annual capital expenditures related to assembly and testing of Flash-based products. We also anticipate that the transition to a contract manufacturing model through SDSS will result in a small increase in our annual cost of revenue for Flash-based products.

[0000106040-24-000040:mdna:17]
[same as prior period, unchanged from 0000106040-24-000022:mdna:26]

[0000106040-24-000040:mdna:18]
As previously disclosed, we had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 27, 2024, we made payments aggregating $153 million for tax and interest with respect to all years 2008 through 2015 and have a remaining liability of $10 million as of September 27, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our “Results of Operations” below, as well as in Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements, and in the “Short- and Long-term Liquidity – Unrecognized Tax Benefits” section below.

[0000106040-24-000040:mdna:19]
40

[0000106040-24-000040:mdna:20]
[same as prior period, unchanged from 0000106040-24-000022:mdna:29]

[0000106040-24-000040:mdna:21]
First Quarter Overview

[0000106040-24-000040:mdna:22]
[same as prior period, unchanged from 0000106040-24-000022:mdna:31]

[0000106040-24-000040:mdna:23]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 4,095 |  |  | 100.0 | % |  | $ | 2,750 |  |  | 100.0 | % |  | $ | 1,345 |  |  | 49 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,544 |  |  | 62.1 |  |  | 2,651 |  |  | 96.4 |  |  | (107) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,551 |  |  | 37.9 |  |  | 99 |  |  | 3.6 |  |  | 1,452 |  |  | 1,467 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 519 |  |  | 12.7 |  |  | 431 |  |  | 15.7 |  |  | 88 |  |  | 20 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 242 |  |  | 5.9 |  |  | 207 |  |  | 7.5 |  |  | 35 |  |  | 17 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Litigation matter | 3 |  |  | 0.1 |  |  | — |  |  | — |  |  | 3 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment and other | 2 |  |  | — |  |  | 57 |  |  | 2.1 |  |  | (55) |  |  | (96) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business separation costs | 43 |  |  | 1.1 |  |  | — |  |  | — |  |  | 43 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 809 |  |  | 19.8 |  |  | 695 |  |  | 25.3 |  |  | 114 |  |  | 16 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 742 |  |  | 18.1 |  |  | (596) |  |  | (21.7) |  |  | 1,338 |  |  | 224 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 9 |  |  | 0.2 |  |  | 8 |  |  | 0.3 |  |  | 1 |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (99) |  |  | (2.4) |  |  | (98) |  |  | (3.6) |  |  | (1) |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (24) |  |  | (0.6) |  |  | 4 |  |  | 0.1 |  |  | (28) |  |  | (700) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (114) |  |  | (2.8) |  |  | (86) |  |  | (3.1) |  |  | (28) |  |  | 33 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 628 |  |  | 15.3 |  |  | (682) |  |  | (24.8) |  |  | 1,310 |  |  | 192 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 135 |  |  | 3.3 |  |  | 3 |  |  | 0.1 |  |  | 132 |  |  | 4,400 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 493 |  |  | 12.0 |  |  | (685) |  |  | (24.9) |  |  | 1,178 |  |  | 172 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  | 0.1 |  |  | 15 |  |  | 0.5 |  |  | (11) |  |  | (73) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: income attributable to preferred shareholders | 8 |  |  | 0.2 |  |  | — |  |  | — |  |  | 8 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 481 |  |  | 11.7 | % |  | $ | (700) |  |  | (25.5) | % |  | $ | 1,181 |  |  | 169 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-24-000040:mdna:24]
[same as prior period, unchanged from 0000106040-24-000022:mdna:33]

[0000106040-24-000040:mdna:25]
41

[0000106040-24-000040:mdna:26]
[same as prior period, unchanged from 0000106040-24-000022:mdna:38]

[0000106040-24-000040:mdna:27]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,211 |  |  | $ | 1,194 |  |  |  |  |  |
| Flash | 1,884 |  |  | 1,556 |  |  |  |  |  |
| Total net revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 843 |  |  | $ | 273 |  |  |  |  |  |
| Flash | 732 |  |  | (161) |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (14) |  |  | (13) |  |  |  |  |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  |  |  |  |
| Amortization of licenses related to a litigation matter | (9) |  |  | — |  |  |  |  |  |
| Total unallocated corporate items | (24) |  |  | (13) |  |  |  |  |  |
| Consolidated gross profit | $ | 1,551 |  |  | $ | 99 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 38.1 | % |  | 22.9 | % |  |  |  |  |
| Flash | 38.9 | % |  | (10.3) | % |  |  |  |  |
| Consolidated gross margin | 37.9 | % |  | 3.6 | % |  |  |  |  |

[0000106040-24-000040:mdna:28]
[same as prior period, unchanged from 0000106040-24-000022:mdna:41]

[0000106040-24-000040:mdna:29]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,208 |  |  | $ | 872 |  |  |  |  |  |
| Client | 1,209 |  |  | 1,147 |  |  |  |  |  |
| Consumer | 678 |  |  | 731 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,837 |  |  | $ | 1,551 |  |  |  |  |  |
| Americas | 1,690 |  |  | 662 |  |  |  |  |  |
| Europe, Middle East and Africa | 568 |  |  | 537 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |

[0000106040-24-000040:mdna:30]
[same as prior period, unchanged from 0000106040-24-000022:mdna:43]

[0000106040-24-000040:mdna:31]
Comparison of Three Months Ended September 27, 2024 to Three Months Ended September 29, 2023

[0000106040-24-000040:mdna:32]
The increase in consolidated net revenue for the three months ended September 27, 2024 from the comparable period in the prior year reflected increases in both HDD and Flash revenue as discussed in more detail below.

[0000106040-24-000040:mdna:33]
HDD revenue increased by 85% for the three months ended September 27, 2024 from the comparable period in the prior year, as a result of a 107% increase in exabytes sold, primarily from higher shipments of our high capacity enterprise drives, partially offset by a 10% decline in average selling prices per gigabyte primarily due to a shift in the product mix to larger capacity drives.

[0000106040-24-000040:mdna:34]
Flash revenue increased by 21% for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting a 39% increase in average selling prices per gigabyte primarily due to improved pricing as the supply-demand balance improved, partially offset by a 12% decrease in exabytes sold. The decrease in exabytes sold was primarily due to the near-term drop in demand in the Client and Consumer end markets, partially offset by increased demand in the Cloud end market.

[0000106040-24-000040:mdna:35]
Cloud revenue increased by 153% for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting a 140% increase in exabytes sold and a 7% increase in average selling prices per gigabyte. The increase in exabytes sold was driven by higher shipments of our high capacity enterprise HDD products stemming from new data center builds. The increase in average selling prices per gigabyte was primarily due to improved pricing in Flash as the supply-demand balance improved.

[0000106040-24-000040:mdna:36]
Client revenue increased by 5% for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting a 33% increase in average selling prices per gigabyte, partially offset by a 20% decrease in exabytes sold. The increase in average selling prices per gigabyte over the prior year period was primarily due to improved pricing in Flash. The decline in exabytes sold reflected the near-term drop in demand for Flash products.

[0000106040-24-000040:mdna:37]
Consumer revenue declined 7% for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting a 15% decrease in exabytes sold, partially offset by a 10% increase in average selling prices per gigabyte. The decrease in exabytes sold was due to lower shipments of both HDD and Flash products. The increase in average selling prices per gigabyte was driven by improved pricing in both HDD and Flash .

[0000106040-24-000040:mdna:38]
The changes in net revenue by geography for the three months ended September 27, 2024 from the comparable period in the prior year reflected higher revenue in the Americas region from Cloud customers as noted above.

[0000106040-24-000040:mdna:39]
Our top 10 customers accounted for 51% of our net revenue for the three months ended September 27, 2024, compared to 44% of our net revenue for the three months ended September 29, 2023. For the three months ended September 27, 2024, one customer accounted for 14% of our net revenue. No customer accounted for 10% or more of the Company’s net revenue for the three months ended September 29, 2023.

[0000106040-24-000040:mdna:40]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 13% and 20% of gross revenue for the three months ended September 27, 2024 and September 29, 2023, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix, and overall availability of products. The decrease in program amounts in the current period reflects the improved demand and pricing environment. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-24-000040:mdna:41]
[same as prior period, unchanged from 0000106040-24-000022:mdna:55]

[0000106040-24-000040:mdna:42]
Consolidated gross profit increased by $1.45 billion for the three months ended September 27, 2024 from the comparable period in the prior year, primarily due to higher product shipments, improved pricing, and favorable product mix. In addition, the prior year period included charges for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity of $225 million ($83 million in HDD and $142 million in Flash), which were not incurred in the current period. Consolidated gross margin increased by 34 percentage points year over year, mainly due to improved pricing and favorable product mix with approximately 8 percentage points of the increase due to the underutilization charges incurred in the prior year period but not incurred in the current period.

[0000106040-24-000040:mdna:43]
HDD gross margin increased by 15 percentage points year over year, primarily due to higher product shipments with approximately 7 percentage points of the increase due to the manufacturing underutilization charges incurred in the prior year period but not incurred in the current period.

[0000106040-24-000040:mdna:44]
Flash gross margin increased by 49 percentage points year over year, primarily due to improved pricing and favorable product mix with approximately 9 percentage points of the increase due to the underutilization charges incurred in the prior year period but not incurred in the current period.

[0000106040-24-000040:mdna:45]
[same as prior period, unchanged from 0000106040-24-000022:mdna:23]

[0000106040-24-000040:mdna:46]
[same as prior period, unchanged from 0000106040-24-000022:mdna:58]

[0000106040-24-000040:mdna:47]
Research and development (“R&D”) expense increased by $88 million for the three months ended September 27, 2024 from the comparable period in the prior year. The increase was driven by a $56 million increase in compensation and benefits due to higher variable compensation and increased headcount, a $10 million increase in material purchases, and modest increases in spending for R&D projects as we continue to invest in innovation.

[0000106040-24-000040:mdna:48]
Selling, general and administrative (“SG&A”) expense increased by $35 million for the three months ended September 27, 2024 from the comparable period in the prior year. The increase was primarily driven by a $26 million increase in compensation and benefits due to higher variable compensation and increased headcount, a $10 million increase in legal fees, and an $8 million increase in dis-synergy costs as we prepare for the business separation, partially offset by a $17 million decrease in strategic review costs.

[0000106040-24-000040:mdna:49]
Employee termination, asset impairment and other charges decreased by $55 million for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting fewer restructuring actions taken in the current period. For information regarding Employee termination, asset impairment and other, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment, and Other of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000040:mdna:50]
Business separation costs were $43 million for the three months ended September 27, 2024, primarily reflecting outside service fees to support the planned separation of our HDD and Flash businesses.

[0000106040-24-000040:mdna:51]
[same as prior period, unchanged from 0000106040-24-000022:mdna:63]

[0000106040-24-000040:mdna:52]
Total interest and other expense, net increased by $28 million for the three months ended September 27, 2024 from the comparable period in the prior year, reflecting an increase in other expense, net of $28 million, driven by a loss on our equity investments.

[0000106040-24-000040:mdna:53]
[same as prior period, unchanged from 0000106040-24-000022:mdna:65]

[0000106040-24-000040:mdna:54]
Beginning in 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in our effective tax rate for the three months ended September 27, 2024 and September 29, 2023. The tax effects related to the capitalization of R&D expenses had a material impact on our effective tax rate for the three months ended September 27, 2024 but did not have a material impact on the effective tax rate for the three months ended September 29, 2023.

[0000106040-24-000040:mdna:55]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant legal changes related to tax, climate, energy, and health care. The tax measures include, among other things, a Corporate Alternative Minimum Tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The CAMT is effective for us beginning with fiscal year 2024. We do not expect to be subject to the CAMT of 15% for fiscal year 2025 as our annual average AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-24-000040:mdna:56]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-US jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of the Pillar Two, some which are effective for us in fiscal year 2025. For fiscal year 2025, we currently expect to be able to meet certain transitional safe harbors and do not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in fiscal year 2026, there may be material increases in our future tax obligations in certain jurisdictions.

[0000106040-24-000040:mdna:57]
[same as prior period, unchanged from 0000106040-24-000022:mdna:28]

[0000106040-24-000040:mdna:58]
[same as prior period, unchanged from 0000106040-24-000022:mdna:68]

[0000106040-24-000040:mdna:59]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | $ in millions |
| Income (loss) before taxes | $ | 628 |  | $ | (682) |  |  |  |  |
| Income tax expense | 135 |  | 3 |  |  |  |  |
| Effective tax rate | 21% |  | —% |  |  |  |  |

[0000106040-24-000040:mdna:60]
The relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that have or will expire at various dates during years 2025 through 2031 resulted in decreases to our effective tax rate below the U.S. Federal statutory rate three months ended September 27, 2024. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in our effective tax rate being closer to the U.S. Federal statutory rate for the three months ended September 27, 2024.

[0000106040-24-000040:mdna:61]
The primary drivers of the difference between the effective tax rate for the three months ended September 29, 2023 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for the three months ended September 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000040:mdna:62]
[same as prior period, unchanged from 0000106040-24-000022:mdna:73]

[0000106040-24-000040:mdna:63]
[same as prior period, unchanged from 0000106040-24-000022:mdna:34]

[0000106040-24-000040:mdna:64]
[same as prior period, unchanged from 0000106040-24-000022:mdna:75]

[0000106040-24-000040:mdna:65]
[same as prior period, unchanged from 0000106040-24-000022:mdna:76]

[0000106040-24-000040:mdna:66]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 34 |  |  | $ | (626) |  |  |  |
| Investing activities | (45) |  |  | 84 |  |  |  |
| Financing activities | (102) |  |  | 554 |  |  |  |
| Effect of exchange rate changes on cash | 10 |  |  | (3) |  |  |  |
| Cash and cash equivalents reclassified to assets held for sale | (71) |  |  | — |  |  |  |
| Net increase (decrease) in cash and cash equivalents | $ | (174) |  |  | $ | 9 |  |  |  |

[0000106040-24-000040:mdna:67]
We had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 27, 2024, the Company made payments of $130 million for interest with respect to years 2008 through 2012 and $23 million for tax and interest with respect to years 2013 through 2015, resulting in a remaining liability of $10 million as of September 27, 2024, related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000040:mdna:68]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $162 million. Of this amount, $31 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules. See Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-24-000040:mdna:69]
In August 2024, we filed a shelf registration statement (the “Shelf Registration Statement”) with the Securities and Exchange Commission that expires in August 2027. The Shelf Registration Statement allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-24-000040:mdna:70]
In 2024, we reduced our expenditures for property, plant and equipment and our portion of the Flash Ventures’ capital expenditures for its operations to approximately $825 million from approximately $2.22 billion in 2023. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we reduced our net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to $53 million in 2024 from $794 million in 2023. We continue to be disciplined with our capital investments and expect our cash capital expenditures in 2025 to be higher than in 2024, but remain below 2023 expenditures.

[0000106040-24-000040:mdna:71]
We believe our cash and cash equivalents and our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended June 28, 2024.

[0000106040-24-000040:mdna:72]
A total of $1.43 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of September 27, 2024 and June 28, 2024, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-24-000040:mdna:73]
[same as prior period, unchanged from 0000106040-24-000022:mdna:84]

[0000106040-24-000040:mdna:74]
[same as prior period, unchanged from 0000106040-24-000022:mdna:37]

[0000106040-24-000040:mdna:75]
[same as prior period, unchanged from 0000106040-24-000022:mdna:86]

[0000106040-24-000040:mdna:76]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $753 million for the three months ended September 27, 2024, as compared to $132 million for the three months ended September 29, 2023, which largely reflects an increase in the volume of our business, as discussed above.

[0000106040-24-000040:mdna:77]
Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as the timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-24-000040:mdna:78]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
| Days sales outstanding | 55 |  |  | 48 |  |  |  |  |  |
| Days in inventory | 121 |  |  | 120 |  |  |  |  |  |
| Days payable outstanding | (69) |  |  | (54) |  |  |  |  |  |
| Cash conversion cycle | 107 |  |  | 114 |  |  |  |  |  |

[0000106040-24-000040:mdna:79]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments to and collections from customers. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds and shipments to customers. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we make payment term modifications with vendors through negotiations with them or by granting to, or receiving from, our vendors payment term accommodations. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances.

[0000106040-24-000040:mdna:80]
For the three months ended September 27, 2024, DSO increased by 7 days from the comparable period in the prior year, of which 5 days reflected an increase from lower trade accounts receivable factoring and the remainder reflected the timing of shipments and customer collections. DIO increased by 1 day from the comparable period in the prior year, primarily reflecting higher production volume in the current period. DPO increased by 15 days from the comparable period in the prior year primarily due to more favorable payment terms and routine variations in the timing of purchases and payments during the period.

[0000106040-24-000040:mdna:81]
[same as prior period, unchanged from 0000106040-24-000022:mdna:91]

[0000106040-24-000040:mdna:82]
Net cash used in investing activities for the three months ended September 27, 2024 primarily consisted of $96 million in capital expenditures, partially offset by $47 million in net proceeds from activity related to Flash Ventures. Net cash provided by investing activities for the three months ended September 29, 2023 primarily consisted of $193 million in proceeds from disposals of assets, which includes the proceeds from our sale-leaseback of our Milpitas, California facility and $13 million in net proceeds from activity related to Flash Ventures, partially offset by $124 million in capital expenditures.

[0000106040-24-000040:mdna:83]
[same as prior period, unchanged from 0000106040-24-000022:mdna:16]

[0000106040-24-000040:mdna:84]
During the three months ended September 27, 2024, net cash used in financing activities primarily consisted of $188 million for repayment of amounts borrowed under the revolving credit facility and scheduled repayments on the Term Loan A-2, and $64 million for taxes paid on vested stock awards under employee stock plans, partially offset by $150 million of proceeds from drawing on the revolving credit facility. During the three months ended September 29, 2023, net cash provided by financing activities primarily consisted of $600 million of proceeds from the drawdown of our delayed draw term loan, partially offset by $43 million used for taxes paid on vested stock awards under employee stock plans.

[0000106040-24-000040:mdna:85]
[same as prior period, unchanged from 0000106040-24-000022:mdna:96]

[0000106040-24-000040:mdna:86]
Other than the Flash Ventures related commitments incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity – Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000040:mdna:87]
48

[0000106040-24-000040:mdna:88]
[same as prior period, unchanged from 0000106040-24-000022:mdna:99]

[0000106040-24-000040:mdna:89]
[same as prior period, unchanged from 0000106040-24-000022:mdna:100]

[0000106040-24-000040:mdna:90]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of September 27, 2024. In addition, see the discussions further below related to unrecognized tax benefits, litigation matters, dividend rights with respect to the Series A Preferred Stock, foreign exchange contracts and indemnifications.

[0000106040-24-000040:mdna:91]
|  | Total |  | 1 Year (Remaining Nine Months of 2025) |  | 2-3 Years (2026-2027) |  | 4-5 Years (2028-2029) |  | More than 5 Years (Beyond 2029) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,450 |  |  | $ | 1,713 |  |  | $ | 4,737 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 947 |  |  | 250 |  |  | 519 |  |  | 132 |  |  | 46 |  |
| Flash Ventures related commitments(2) | 5,643 |  |  | 2,281 |  |  | 2,378 |  |  | 790 |  |  | 194 |  |
| Operating leases | 495 |  |  | 45 |  |  | 114 |  |  | 82 |  |  | 254 |  |
| Purchase obligations and other commitments | 455 |  |  | 140 |  |  | 165 |  |  | 40 |  |  | 110 |  |
| Mandatory deemed repatriation tax | 331 |  |  | — |  |  | 331 |  |  | — |  |  | — |  |
| Total | $ | 15,321 |  |  | $ | 4,429 |  |  | $ | 8,244 |  |  | $ | 1,544 |  |  | $ | 1,104 |  |

[0000106040-24-000040:mdna:92]
[same as prior period, unchanged from 0000106040-24-000022:mdna:103]

[0000106040-24-000040:mdna:93]
[same as prior period, unchanged from 0000106040-24-000022:mdna:104]

[0000106040-24-000040:mdna:94]
[same as prior period, unchanged from 0000106040-24-000022:mdna:119]

[0000106040-24-000040:mdna:95]
As of September 27, 2024, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $692 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of September 27, 2024 was $70 million. Of these amounts, approximately $597 million could result in potential cash payments. As of September 27, 2024, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-24-000040:mdna:96]
As noted above, we had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 27, 2024, we made payments of $130 million for interest with respect to years 2008 through 2012 and $23 million for tax and interest with respect to years 2013 through 2015, resulting in a remaining liability of $10 million as of September 27, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000040:mdna:97]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $162 million. Of this amount, $31 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-24-000040:mdna:98]
[same as prior period, unchanged from 0000106040-24-000022:mdna:54]

[0000106040-24-000040:mdna:99]
Litigation Matters

[0000106040-24-000040:mdna:100]
For additional information on the litigation matters, see Part I, Item 1, Note 16, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-24-000040:mdna:101]
[same as prior period, unchanged from 0000106040-24-000022:mdna:105]

[0000106040-24-000040:mdna:102]
As of September 27, 2024, 235,000 shares of our Series A Preferred Stock remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended June 28, 2024 and Part I, Item 1, Note 11, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0000106040-24-000040:mdna:103]
[same as prior period, unchanged from 0000106040-24-000022:mdna:107]

[0000106040-24-000040:mdna:104]
As described in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, the Company issued $1.60 billion aggregate principal amount of convertible senior notes in November 2023, which bear interest at an annual rate of 3.00% and mature on November 15, 2028 (the “2028 Convertible Note”). The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000040:mdna:105]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the notes mentioned above was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the calendar quarter ended September 30, 2024. Consequently, we classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of September 27, 2024. During the calendar quarter ended September 30, 2024, the sale price conditional conversion feature of the notes mentioned above was not triggered. As a result, the 2028 Convertible Notes are not convertible from October 1, 2024 through December 31, 2024. We will re-evaluate in each subsequent calendar quarter to determine if the 2028 Convertible Notes have become convertible.

[0000106040-24-000040:mdna:106]
In addition to our existing debt, as of September 27, 2024, we had $2.20 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Debt, of the Notes to the Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 28, 2024 and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-24-000040:mdna:107]
The loan agreements governing our revolving credit facility and our Term Loan A-2 maturing 2027 require us to comply with certain financial covenants, consisting of a leverage ratio, and a minimum liquidity requirement. As of September 27, 2024, we were in compliance with these financial covenants.

[0000106040-24-000040:mdna:108]
We may issue additional debt securities in the future that may be guaranteed by our 100% owned domestic subsidiary, Western Digital Technologies, Inc. (“Guarantor” and, together with Western Digital Corporation, the “Obligor Group”). Such guarantees may be full and unconditional, joint and several, on a secured or unsecured, subordinated or unsubordinated basis, and may be subject to certain customary guarantor release conditions. We conduct operations almost entirely through our subsidiaries. Accordingly, the Obligor Group’s cash flow and ability to service any guaranteed registered debt securities will depend on the earnings of our subsidiaries and the distribution of those earnings to the Obligor Group, including the earnings of the non-guarantor subsidiaries, whether by dividends, loans or otherwise. Holders of such guaranteed registered debt securities would have a direct claim only against the Obligor Group.

[0000106040-24-000040:mdna:109]
The following tables include summarized financial information for the Obligor Group. The financial information for the Obligor Group is presented on combined basis, excluding intercompany balances and transactions between the Company and the Guarantor, excluding net intercompany balances between the Obligor Group and non-guarantor subsidiaries, and excluding investments in and equity in the earnings of non-guarantor subsidiaries. The Obligor Group’s amounts due from, amounts due to, and transactions with non-guarantor subsidiaries have been presented in separate line items in the tables below.

[0000106040-24-000040:mdna:110]
The assets and liabilities of the Obligor Group include the following:

[0000106040-24-000040:mdna:111]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Current assets | $ | 2,143 |  |  | $ | 2,149 |  |
| Non-current assets | 2,285 |  |  | 2,208 |  |
| Net intercompany receivables to non-guarantor subsidiaries | 2,098 |  |  | 2,473 |  |
| Current liabilities | 3,501 |  |  | 3,758 |  |
| Non-current liabilities | 6,416 |  |  | 6,626 |  |

[0000106040-24-000040:mdna:112]
The operating results of the Obligor Group include the following:

[0000106040-24-000040:mdna:113]
|  | Three Months Ended |  | Year Ended |
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Net sales | $ | 1,722 |  |  | $ | 4,066 |  |
| Gross profit | 660 |  |  | 1,002 |  |
| Operating income (loss) | 100 |  |  | (927) |  |
| Net loss | (33) |  |  | (1,211) |  |

[0000106040-24-000040:mdna:114]
Results for the Obligor Group include the following transactions with non-guarantor subsidiaries:

[0000106040-24-000040:mdna:115]
|  | Three Months Ended |  | Year Ended |
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Intercompany revenue | $ | 580 |  |  | $ | 1,416 |  |
| Net intercompany interest expense | 1 |  |  | 8 |  |
| Intercompany dividend income | 44 |  |  | 567 |  |

[0000106040-24-000040:mdna:116]
[same as prior period, unchanged from 0000106040-24-000022:mdna:112]

[0000106040-24-000040:mdna:117]
Flash Ventures sells to, and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of September 27, 2024, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-24-000040:mdna:118]
[same as prior period, unchanged from 0000106040-24-000022:mdna:114]

[0000106040-24-000040:mdna:119]
[same as prior period, unchanged from 0000106040-24-000022:mdna:115]

[0000106040-24-000040:mdna:120]
[same as prior period, unchanged from 0000106040-24-000022:mdna:116]

[0000106040-24-000040:mdna:121]
The following is a summary of our estimated mandatory deemed repatriation tax obligations that are payable in the following year:

[0000106040-24-000040:mdna:122]
|  | September 27,2024 |
|  | (in millions) |
| 2026 | $ | 331 |  |

[0000106040-24-000040:mdna:123]
[same as prior period, unchanged from 0000106040-24-000022:mdna:123]

[0000106040-24-000040:mdna:124]
Since the beginning of 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred, which is expected to result in higher cash tax payments in future profitable periods, if not repealed or otherwise modified.

[0000106040-24-000040:mdna:125]
[same as prior period, unchanged from 0000106040-24-000022:mdna:125]

[0000106040-24-000040:mdna:126]
[same as prior period, unchanged from 0000106040-24-000022:mdna:126]

[0000106040-24-000040:mdna:127]
[same as prior period, unchanged from 0000106040-24-000022:mdna:127]

[0000106040-24-000040:mdna:128]
[same as prior period, unchanged from 0000106040-24-000022:mdna:128]

[0000106040-24-000040:mdna:129]
[same as prior period, unchanged from 0000106040-24-000022:mdna:129]

[0000106040-24-000040:mdna:130]
[same as prior period, unchanged from 0000106040-24-000022:mdna:130]

[0000106040-24-000040:mdna:131]
[same as prior period, unchanged from 0000106040-24-000022:mdna:131]

[0000106040-24-000040:mdna:132]
[same as prior period, unchanged from 0000106040-24-000022:mdna:132]

[0000106040-24-000040:mdna:133]
[same as prior period, unchanged from 0000106040-24-000022:mdna:133]

[0000106040-24-000040:mdna:134]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the year ended June 28, 2024. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the year ended June 28, 2024 for a discussion of our critical accounting policies and estimates.

[0000106040-24-000040:mdna:135]
[same as prior period, unchanged from 0000106040-24-000022:mdna:85]
