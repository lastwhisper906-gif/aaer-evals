# WDC notes — 0000106040-24-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-24-000040:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both hard disk drive and NAND flash technologies.

[0000106040-24-000040:notes:2]
The Company’s broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

[0000106040-24-000040:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-24-000040:notes:4]
[same as prior period, unchanged from 0000106040-24-000022:notes:4]

[0000106040-24-000040:notes:5]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-24-000040:notes:6]
[same as prior period, unchanged from 0000106040-24-000022:notes:6]

[0000106040-24-000040:notes:7]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: hard disk drives (“HDD”) and Flash-based products (“Flash”).

[0000106040-24-000040:notes:8]
[same as prior period, unchanged from 0000106040-24-000022:notes:8]

[0000106040-24-000040:notes:9]
[same as prior period, unchanged from 0000106040-24-000022:notes:9]

[0000106040-24-000040:notes:10]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company has incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

[0000106040-24-000040:notes:11]
[same as prior period, unchanged from 0000106040-24-000022:notes:11]

[0000106040-24-000040:notes:12]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-24-000040:notes:13]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-24-000040:notes:14]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. As required by the ASU, the Company began to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024. The ASU also requires the Company to provide certain annual rollforward information related to those obligations, which will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company will provide this disclosure in its Annual Report on Form 10-K for the year ended June 27, 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. See Note 15, Supplier Finance Program, of the Notes to the Condensed Consolidated Financial Statements for information regarding the supplier finance program.

[0000106040-24-000040:notes:15]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-24-000040:notes:16]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures”, which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. The ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity's CODM, a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.

[0000106040-24-000040:notes:17]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures”. The ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 26, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-24-000040:notes:18]
Business Segments, Geographic Information, and Concentrations of Risk
The following table summarizes the operating performance of the Company’s reportable segments for the periods presented:

[0000106040-24-000040:notes:19]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,211 |  |  | $ | 1,194 |  |  |  |  |  |
| Flash | 1,884 |  |  | 1,556 |  |  |  |  |  |
| Total net revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 843 |  |  | $ | 273 |  |  |  |  |  |
| Flash | 732 |  |  | (161) |  |  |  |  |  |
| Total gross profit for segments | 1,575 |  |  | 112 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (14) |  |  | (13) |  |  |  |  |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  |  |  |  |
| Amortization of licenses related to a litigation matter | (9) |  |  | — |  |  |  |  |  |
| Total unallocated corporate items | (24) |  |  | (13) |  |  |  |  |  |
| Consolidated gross profit | $ | 1,551 |  |  | $ | 99 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 38.1 | % |  | 22.9 | % |  |  |  |  |
| Flash | 38.9 | % |  | (10.3) | % |  |  |  |  |
| Consolidated gross margin | 37.9 | % |  | 3.6 | % |  |  |  |  |

[0000106040-24-000040:notes:20]
[same as prior period, unchanged from 0000106040-24-000022:notes:23]

[0000106040-24-000040:notes:21]
The Company’s broad portfolio of technology and products addresses multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD and Flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-24-000040:notes:22]
The Company’s disaggregated revenue information was as follows:

[0000106040-24-000040:notes:23]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,208 |  |  | $ | 872 |  |  |  |  |  |
| Client | 1,209 |  |  | 1,147 |  |  |  |  |  |
| Consumer | 678 |  |  | 731 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,837 |  |  | $ | 1,551 |  |  |  |  |  |
| Americas | 1,690 |  |  | 662 |  |  |  |  |  |
| Europe, Middle East and Africa | 568 |  |  | 537 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |

[0000106040-24-000040:notes:24]
The Company’s top 10 customers accounted for 51% and 44% of its net revenue for the three months ended September 27, 2024 and September 29, 2023, respectively. For the three months ended September 27, 2024, one customer accounted for 14% of the Company’s net revenue. No customer accounted for 10% or more of the Company’s net revenue for the three months ended September 29, 2023.

[0000106040-24-000040:notes:25]
[same as prior period, unchanged from 0000106040-24-000022:notes:28]

[0000106040-24-000040:notes:26]
[same as prior period, unchanged from 0000106040-24-000022:notes:29]

[0000106040-24-000040:notes:27]
|  | HDD |  | Flash |  | Total |
|  | (in millions) |
| Balance at June 28, 2024 | $ | 4,319 |  |  | $ | 5,713 |  |  | $ | 10,032 |  |
| Foreign currency translation adjustment | 2 |  |  | 3 |  |  | 5 |  |
| Goodwill reclassified to assets held for sale (1) | — |  |  | (225) |  |  | (225) |  |
| Balance at September 27, 2024 | $ | 4,321 |  |  | $ | 5,491 |  |  | $ | 9,812 |  |

[0000106040-24-000040:notes:28]
(1)     As of September 27, 2024, $225 million of Goodwill was reclassified to assets held for sale due to the sale of a majority interest in a subsidiary. See further discussion in Note 4, Supplemental Financial Statement Data.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-24-000040:notes:29]
[same as prior period, unchanged from 0000106040-24-000022:notes:31]

[0000106040-24-000040:notes:30]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. There were no trade accounts receivable sold during the three months ended September 27, 2024. During the three months ended September 29, 2023, the Company sold trade accounts receivable aggregating $150 million. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no factored receivables outstanding as of September 27, 2024 and June 28, 2024.

[0000106040-24-000040:notes:31]
[same as prior period, unchanged from 0000106040-24-000022:notes:33]

[0000106040-24-000040:notes:32]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,897 |  |  | $ | 1,727 |  |
| Work-in-process | 979 |  |  | 1,066 |  |
| Finished goods | 508 |  |  | 549 |  |
| Total inventories | $ | 3,384 |  |  | $ | 3,342 |  |

[0000106040-24-000040:notes:33]
[same as prior period, unchanged from 0000106040-24-000022:notes:35]

[0000106040-24-000040:notes:34]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 235 |  |  | $ | 235 |  |
| Buildings and improvements | 1,706 |  |  | 1,820 |  |
| Machinery and equipment | 7,783 |  |  | 8,646 |  |
| Computer equipment and software | 452 |  |  | 471 |  |
| Furniture and fixtures | 51 |  |  | 54 |  |
| Construction-in-process | 798 |  |  | 797 |  |
| Property, plant and equipment, gross | 11,025 |  |  | 12,023 |  |
| Accumulated depreciation | (8,108) |  |  | (8,856) |  |
| Property, plant and equipment, net | $ | 2,917 |  |  | $ | 3,167 |  |

[0000106040-24-000040:notes:35]
[same as prior period, unchanged from 0000106040-24-000022:notes:37]

[0000106040-24-000040:notes:36]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of September 27, 2024 and June 28, 2024, IPR&D included in intangible assets, net was $72 million. During the three months ended September 27, 2024 and September 29, 2023, the Company did not record any impairment charges related to IPR&D.

[0000106040-24-000040:notes:37]
[same as prior period, unchanged from 0000106040-24-000022:notes:39]

[0000106040-24-000040:notes:38]
[same as prior period, unchanged from 0000106040-24-000022:notes:40]

[0000106040-24-000040:notes:39]
|  | Three Months Ended |  |  |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 189 |  |  | $ | 244 |  |  |  |  |  |  |  |
| Charges to operations | 25 |  |  | 22 |  |  |  |  |  |  |  |
| Utilization | (37) |  |  | (43) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | (17) |  |  | (5) |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 160 |  |  | $ | 218 |  |  |  |  |  |  |  |

[0000106040-24-000040:notes:40]
The current portion of the warranty accrual was classified in Accrued expenses and the long-term portion was classified in Other liabilities as noted below:

[0000106040-24-000040:notes:41]
|  | September 27,2024 |  | June 28,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 58 |  |  | $ | 36 |  |  |  |  |  |  |  |
| Long-term portion | 102 |  |  | 153 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 160 |  |  | $ | 189 |  |  |  |  |  |  |  |

[0000106040-24-000040:notes:42]
[same as prior period, unchanged from 0000106040-24-000022:notes:44]

[0000106040-24-000040:notes:43]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | — |  |  | $ | 201 |  |
| Non-current portion of unrecognized tax benefits | 595 |  |  | 565 |  |
| Other non-current liabilities | 563 |  |  | 604 |  |
| Total other liabilities | $ | 1,158 |  |  | $ | 1,370 |  |

[0000106040-24-000040:notes:44]
[same as prior period, unchanged from 0000106040-24-000022:notes:46]

[0000106040-24-000040:notes:45]
Accumulated other comprehensive loss (“AOCL”), net of tax, refers to expenses, gains, and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The components of AOCL were as follows:

[0000106040-24-000040:notes:46]
|  | Actuarial Pension Gains |  | Foreign Currency Translation Adjustment |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 28, 2024 | $ | 14 |  |  | $ | (505) |  |  |  |  | $ | (221) |  |  | $ | (712) |  |
| Other comprehensive income before reclassifications | — |  |  | 121 |  |  |  |  | 182 |  |  | 303 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  | 61 |  |  | 61 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | — |  |  |  |  | (52) |  |  | (52) |  |
| Net current-period other comprehensive income | — |  |  | 121 |  |  |  |  | 191 |  |  | 312 |  |
| Balance at September 27, 2024 | $ | 14 |  |  | $ | (384) |  |  |  |  | $ | (30) |  |  | $ | (400) |  |

[0000106040-24-000040:notes:47]
During the three months ended September 27, 2024, the amounts reclassified out of AOCL were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0000106040-24-000040:notes:48]
As of September 27, 2024, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.

[0000106040-24-000040:notes:49]
Sale of a Majority Interest in a Subsidiary

[0000106040-24-000040:notes:50]
In March 2024, the Company’s wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), the Company’s indirect wholly-owned subsidiary in its Flash business, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). Subsequent to the first quarter of fiscal 2025, on September 28, 2024, the Transaction closed. Proceeds from the sale, subject to certain working capital adjustments and payment of withholding taxes, are expected to be approximately $624 million. Following the closing of the Transaction, SanDisk China’s remaining 20% ownership interest in the venture will be reported as an equity method investment.

[0000106040-24-000040:notes:51]
Because the divestiture of SDSS does not represent a strategic shift that would have a major effect on the Company’s operations or financial results, it is not reported as discontinued operations. Instead, the assets and liabilities of SDSS subject to the Transaction as listed below have been reclassified to held for sale as of September 27, 2024, and will be derecognized in the second quarter of fiscal 2025 in connection with the closing of the Transaction.

[0000106040-24-000040:notes:52]
|  | September 27,2024 |
|  | (in millions) |
| Cash and cash equivalents | $ | 71 |  |
| Inventories | 35 |  |
| Other current assets | 6 |  |
| Property, plant and equipment, net | 236 |  |
| Goodwill (1) | 225 |  |
| Other non-current assets | 24 |  |
| Total assets held for sale (2) | $ | 597 |  |
| Accounts payable | $ | 73 |  |
| Accrued expenses | 17 |  |
| Accrued compensation | 15 |  |
| Other liabilities | 5 |  |
| Total liabilities held for sale | $ | 110 |  |

[0000106040-24-000040:notes:53]
(1)     Goodwill was preliminarily allocated to SDSS based on the indicated fair value of the SDSS business relative to the total estimated fair value of the Flash business unit. This preliminary allocation of goodwill may be revised based on finalization of working capital adjustments and valuations of SDSS and the Flash business unit in connection with the derecognition of SDSS during the second quarter of fiscal 2025.

[0000106040-24-000040:notes:54]
(2)     An intercompany account receivable and intercompany account payable totaling $110 million between SDSS and another subsidiary of the Company are eliminated in the Company’s Condensed Consolidated Financial Statements and have been excluded from the assets reclassified to held for sale. The intercompany account receivable was sold as part of the Transaction, and thus will be considered when determining the expected gain to be recognized upon the derecognition of SDSS. As a result, during the second quarter of fiscal 2025, the Company will reclassify this intercompany account payable to the applicable liability line item in the Condensed Consolidated Balance Sheets as it will represent a liability to an external third party.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-24-000040:notes:55]
[same as prior period, unchanged from 0000106040-24-000022:notes:50]

[0000106040-24-000040:notes:56]
[same as prior period, unchanged from 0000106040-24-000022:notes:51]

[0000106040-24-000040:notes:57]
[same as prior period, unchanged from 0000106040-24-000022:notes:52]

[0000106040-24-000040:notes:58]
[same as prior period, unchanged from 0000106040-24-000022:notes:53]

[0000106040-24-000040:notes:59]
[same as prior period, unchanged from 0000106040-24-000022:notes:54]

[0000106040-24-000040:notes:60]
The following tables present information about the Company’s financial instruments that were measured at fair value on a recurring basis for the periods presented, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-24-000040:notes:61]
|  | September 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 269 |  |  | $ | — |  |  | $ | — |  |  | $ | 269 |  |
| Foreign exchange contracts | — |  |  | 106 |  |  | — |  |  | 106 |  |
| Total assets at fair value | $ | 269 |  |  | $ | 106 |  |  | $ | — |  |  | $ | 375 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |

[0000106040-24-000040:notes:62]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 416 |  |  | $ | — |  |  | $ | — |  |  | $ | 416 |  |
| Foreign exchange contracts | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total assets at fair value | $ | 416 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 424 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |

[0000106040-24-000040:notes:63]
During the periods presented, the Company had no transfers of financial instruments between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-24-000040:notes:64]
[same as prior period, unchanged from 0000106040-24-000022:notes:59]

[0000106040-24-000040:notes:65]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2025 and the fourth quarter of 2024, respectively.

[0000106040-24-000040:notes:66]
|  | September 27, 2024 |  | June 28, 2024 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,569 |  |  | $ | 2,402 |  |  | $ | 1,568 |  |  | $ | 2,556 |  |
| 4.75% senior unsecured notes due 2026 | 2,296 |  |  | 2,285 |  |  | 2,296 |  |  | 2,253 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,542 |  |  | 2,505 |  |  | 2,578 |  |  | 2,539 |  |
| 2.85% senior notes due 2029 | 497 |  |  | 456 |  |  | 496 |  |  | 434 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 430 |  |  | 496 |  |  | 407 |  |
| Total | $ | 7,400 |  |  | $ | 8,078 |  |  | $ | 7,434 |  |  | $ | 8,189 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-24-000040:notes:67]
Derivative Instruments and Hedging Activities
As of September 27, 2024, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of September 27, 2024, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-24-000040:notes:68]
Changes in fair values of the non-designated foreign exchange contracts were recognized in Other income (expense), net and were largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three months ended September 27, 2024 and September 29, 2023, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-24-000040:notes:69]
Unrealized gains or losses on designated cash flow hedges were recognized in AOCL. For more information regarding cash flow hedges, see Note 4, Supplemental Financial Statement Data – Accumulated other comprehensive loss.

[0000106040-24-000040:notes:70]
[same as prior period, unchanged from 0000106040-24-000022:notes:65]

[0000106040-24-000040:notes:71]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of September 27, 2024 and June 28, 2024, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-24-000040:notes:72]
Debt
Debt consisted of the following:

[0000106040-24-000040:notes:73]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,600 |  |  | $ | 1,600 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,550 |  |  | 2,588 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,450 |  |  | 7,488 |  |
| Issuance costs | (50) |  |  | (54) |  |
| Subtotal | 7,400 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,750) |  |
| Long-term debt | $ | 5,650 |  |  | $ | 5,684 |  |

[0000106040-24-000040:notes:74]
During the three months ended September 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of September 27, 2024 was 6.696%.

[0000106040-24-000040:notes:75]
During the three months ended September 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

[0000106040-24-000040:notes:76]
The Company had issued an outstanding standby letters of credit of $52 million as of September 27, 2024, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.20 billion as of that date.

[0000106040-24-000040:notes:77]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with certain financial covenants, consisting of a leverage ratio and a minimum liquidity requirement. As of September 27, 2024, the Company was in compliance with these financial covenants.

[0000106040-24-000040:notes:78]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

[0000106040-24-000040:notes:79]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000040:notes:80]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the notes mentioned above was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the calendar quarter ended September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of September 27, 2024. During the calendar quarter ended September 30, 2024, the sale price conditional conversion feature of the notes mentioned above was not triggered. As a result, the 2028 Convertible Notes are not convertible from October 1, 2024 through December 31, 2024. The Company will re-evaluate in each subsequent calendar quarter to determine if the 2028 Convertible Notes have become convertible.

[0000106040-24-000040:notes:81]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-24-000040:notes:82]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand, and the Philippines. All pension and other post-retirement benefit plans outside of the Company’s Japan, Thailand, and the Philippines defined benefit pension plans (the “Pension Plans”) are immaterial to the Condensed Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans’ assets is 2.5%.

[0000106040-24-000040:notes:83]
[same as prior period, unchanged from 0000106040-24-000022:notes:82]

[0000106040-24-000040:notes:84]
[same as prior period, unchanged from 0000106040-24-000022:notes:83]

[0000106040-24-000040:notes:85]
|  | September 27,2024 |  | June 28,2024 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 267 |  |  | $ | 244 |  |  |  |
| Fair value of plan assets at end of period | 198 |  |  | 184 |  |  |  |
| Unfunded status | $ | 69 |  |  | $ | 60 |  |  |  |

[0000106040-24-000040:notes:86]
[same as prior period, unchanged from 0000106040-24-000022:notes:85]

[0000106040-24-000040:notes:87]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Current liabilities (included in Accrued expenses) | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities (included in Other liabilities) | 68 |  |  | 59 |  |
| Net amount recognized | $ | 69 |  |  | $ | 60 |  |

[0000106040-24-000040:notes:88]
Net periodic benefit costs were immaterial for the three months ended September 27, 2024 and September 29, 2023.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-24-000040:notes:89]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-24-000040:notes:90]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-24-000040:notes:91]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-24-000040:notes:92]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 5 |  |
| Notes receivable, Flash Forward | 498 |  |  | 485 |  |
| Investment in Flash Partners | 169 |  |  | 149 |  |
| Investment in Flash Alliance | 236 |  |  | 216 |  |
| Investment in Flash Forward | 143 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,051 |  |  | $ | 991 |  |

[0000106040-24-000040:notes:93]
During the three months ended September 27, 2024 and September 29, 2023, the Company made net payments to Flash Ventures of $889 million and $939 million, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-24-000040:notes:94]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-24-000040:notes:95]
As of September 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $352 million and $313 million, respectively.

[0000106040-24-000040:notes:96]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-24-000040:notes:97]
|  | September 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 503 |  |
| Equity investments | 548 |  |
| Operating lease guarantees | 1,558 |  |
| Inventory and prepayments | 1,166 |  |
| Maximum estimable loss exposure | $ | 3,775 |  |

[0000106040-24-000040:notes:98]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-24-000040:notes:99]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 27, 2024.

[0000106040-24-000040:notes:100]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of September 27, 2024, $722 million remains to be credited against future building depreciation charges. As of September 27, 2024, the Company is also committed to make additional building depreciation prepayments of $605 million, based on the Japanese yen to U.S. dollars exchange rate of 142.56 as of such date, payable as follows: $337 million for the remainder of fiscal year 2025, $33 million in fiscal year 2026, $123 million in fiscal year 2027, $98 million in fiscal year 2028 and $14 million in fiscal year 2029. As of September 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $315 million at varying dates through fiscal year 2035.

[0000106040-24-000040:notes:101]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-24-000040:notes:102]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-24-000040:notes:103]
Off-Balance Sheet Liabilities

[0000106040-24-000040:notes:104]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-24-000040:notes:105]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024.

[0000106040-24-000040:notes:106]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 222 |  |  | $ | 1,558 |  |

[0000106040-24-000040:notes:107]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024:

[0000106040-24-000040:notes:108]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2025 |  | $ | 331 |  |  | $ | 83 |  |  | $ | 414 |  |
| 2026 |  | 428 |  |  | 126 |  |  | 554 |  |
| 2027 |  | 203 |  |  | 107 |  |  | 310 |  |
| 2028 |  | 81 |  |  | 103 |  |  | 184 |  |
| 2029 |  | 22 |  |  | 56 |  |  | 78 |  |
| 2030 |  | 2 |  |  | 16 |  |  | 18 |  |
| Total guarantee obligations |  | $ | 1,067 |  |  | $ | 491 |  |  | $ | 1,558 |  |

[0000106040-24-000040:notes:109]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-24-000040:notes:110]
Unis Venture

[0000106040-24-000040:notes:111]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 27, 2024 and September 29, 2023, the Company recognized approximately 2% and 6% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both September 27, 2024 and June 28, 2024, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-24-000040:notes:112]
[same as prior period, unchanged from 0000106040-24-000022:notes:112]

[0000106040-24-000040:notes:113]
[same as prior period, unchanged from 0000106040-24-000022:notes:113]

[0000106040-24-000040:notes:114]
The following table presents right-of-use lease assets and lease liabilities included in the Company’s Condensed Consolidated Balance Sheets:

[0000106040-24-000040:notes:115]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 327 |  |  | $ | 326 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 44 |  |  | 42 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 305 |  |  | 307 |  |
| Total operating lease liabilities | $ | 349 |  |  | $ | 349 |  |

[0000106040-24-000040:notes:116]
[same as prior period, unchanged from 0000106040-24-000022:notes:116]

[0000106040-24-000040:notes:117]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions) |
| Cost of operating leases | $ | 16 |  |  | $ | 14 |  |  |  |  |  |
| Cash paid for operating leases | 17 |  |  | 15 |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 11 |  |  | 168 |  |  |  |  |  |

[0000106040-24-000040:notes:118]
The weighted average remaining lease term and discount rate for the Company’s operating leases were as follows:

[0000106040-24-000040:notes:119]
|  | September 27,2024 |  | June 28,2024 |  |  |
| Weighted average remaining lease term in years | 10.2 |  | 10.4 |  |  |
| Weighted average discount rate | 6.6 | % |  | 6.6 | % |  |  |

[0000106040-24-000040:notes:120]
As of September 27, 2024, minimum lease payments were as follows:

[0000106040-24-000040:notes:121]
|  | Lease Amounts |
|  | (in millions) |
| Remaining nine months of 2025 | $ | 45 |  |
| 2026 | 61 |  |
| 2027 | 53 |  |
| 2028 | 44 |  |
| 2029 | 38 |  |
| Thereafter | 254 |  |
| Total future minimum lease payments | 495 |  |
| Less: imputed interest | 146 |  |
| Present value of lease liabilities | $ | 349 |  |

[0000106040-24-000040:notes:122]
[same as prior period, unchanged from 0000106040-24-000022:notes:118]

[0000106040-24-000040:notes:123]
[same as prior period, unchanged from 0000106040-24-000022:notes:119]

[0000106040-24-000040:notes:124]
[same as prior period, unchanged from 0000106040-24-000022:notes:120]

[0000106040-24-000040:notes:125]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of September 27, 2024, the Company had the following minimum long-term commitments:

[0000106040-24-000040:notes:126]
|  | Long-Term Commitments |
|  | (in millions) |
| Remaining nine months of 2025 | $ | 140 |  |
| 2026 | 102 |  |
| 2027 | 63 |  |
| 2028 | 20 |  |
| 2029 | 20 |  |
| Thereafter | 110 |  |
| Total | $ | 455 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-24-000040:notes:127]
[same as prior period, unchanged from 0000106040-24-000022:notes:123]

[0000106040-24-000040:notes:128]
The following tables present the Company’s stock-based compensation for equity-settled awards by type (i.e., restricted stock units (“RSUs”), restricted stock unit awards with performance conditions or market conditions (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”)) and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-24-000040:notes:129]
|  | Three Months Ended |  |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 72 |  |  | $ | 65 |  |  |  |  |  |  |
| ESPP | 12 |  |  | 12 |  |  |  |  |  |  |
| Total | $ | 84 |  |  | $ | 77 |  |  |  |  |  |  |

[0000106040-24-000040:notes:130]
|  | Three Months Ended |  |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |  |
|  | (in millions) |
| Cost of revenue | $ | 14 |  |  | $ | 13 |  |  |  |  |  |  |
| Research and development | 39 |  |  | 34 |  |  |  |  |  |  |
| Selling, general and administrative | 31 |  |  | 30 |  |  |  |  |  |  |
| Subtotal | 84 |  |  | 77 |  |  |  |  |  |  |
| Tax benefit | (10) |  |  | (10) |  |  |  |  |  |  |
| Total | $ | 74 |  |  | $ | 67 |  |  |  |  |  |  |

[0000106040-24-000040:notes:131]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were immaterial for the periods presented.

[0000106040-24-000040:notes:132]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of September 27, 2024:

[0000106040-24-000040:notes:133]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 635 |  |  | 2.6 |
| ESPP | 11 |  |  | 0.3 |
| Total unamortized compensation cost | $ | 646 |  |  |  |

[0000106040-24-000040:notes:134]
[same as prior period, unchanged from 0000106040-24-000022:notes:130]

[0000106040-24-000040:notes:135]
[same as prior period, unchanged from 0000106040-24-000022:notes:131]

[0000106040-24-000040:notes:136]
[same as prior period, unchanged from 0000106040-24-000022:notes:135]

[0000106040-24-000040:notes:137]
[same as prior period, unchanged from 0000106040-24-000022:notes:136]

[0000106040-24-000040:notes:138]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2024 | 13.0 |  |  | $ | 44.42 |  |  |  |
| Granted | 3.9 |  |  | 62.58 |  |  |  |
| Vested | (3.3) |  |  | 44.31 |  |  | $ | 209 |  |
| Forfeited | (0.1) |  |  | 51.36 |  |  |  |
| RSUs and PSUs outstanding at September 27, 2024 | 13.5 |  |  | $ | 51.20 |  |  |  |

[0000106040-24-000040:notes:139]
[same as prior period, unchanged from 0000106040-24-000022:notes:138]

[0000106040-24-000040:notes:140]
[same as prior period, unchanged from 0000106040-24-000022:notes:139]

[0000106040-24-000040:notes:141]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement. As of September 27, 2024 and June 28, 2024, 235,000 of the Preferred Shares were outstanding.

[0000106040-24-000040:notes:142]
The Preferred Shares have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of September 27, 2024 and June 28, 2024, unpaid and cumulative dividends payable with respect to the Preferred Shares were $26 million and $22 million, respectively.

[0000106040-24-000040:notes:143]
The Preferred Shares are convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate sum of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of the Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately prior to the Company’s conversion notice.

[0000106040-24-000040:notes:144]
As of September 27, 2024 and June 28, 2024, the Preferred Shares outstanding had an aggregate liquidation preference of $261 million and $257 million, respectively, and would have been convertible, if otherwise permitted, into approximately 5 million shares of common stock on each such date.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-24-000040:notes:145]
Income Tax Expense 
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act (the “2017 Act”) requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three months ended September 27, 2024 and September 29, 2023.

[0000106040-24-000040:notes:146]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The CAMT was effective for the Company beginning with fiscal year 2024. The Company does not expect to be subject to CAMT for fiscal year 2025 as its average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-24-000040:notes:147]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two Model Rules”). Several non-US jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of the Pillar Two, some which are effective for the Company in fiscal year 2025. For fiscal year 2025, the Company currently expects to be able to meet certain transitional safe harbors and does not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in fiscal year 2026, there may be material increases in the Company’s future tax obligations in certain jurisdictions.

[0000106040-24-000040:notes:148]
[same as prior period, unchanged from 0000106040-24-000022:notes:144]

[0000106040-24-000040:notes:149]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 628 |  | $ | (682) |  |  |  |  |
| Income tax expense | 135 |  | 3 |  |  |  |  |
| Effective tax rate | 21 | % |  | — | % |  |  |  |  |

[0000106040-24-000040:notes:150]
The relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines, and Thailand that have or will expire at various dates during years 2025 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the three months ended September 27, 2024. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in the effective tax rate being closer to the U.S. Federal statutory rate for the three months ended September 27, 2024.

[0000106040-24-000040:notes:151]
The primary drivers of the difference between the effective tax rate for the three months ended September 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines, and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for the three months ended September 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-24-000040:notes:152]
[same as prior period, unchanged from 0000106040-24-000022:notes:149]

[0000106040-24-000040:notes:153]
[same as prior period, unchanged from 0000106040-24-000022:notes:150]

[0000106040-24-000040:notes:154]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 27, 2024 (in millions):

[0000106040-24-000040:notes:155]
| Accrual balance at June 28, 2024 | $ | 721 |  |
| Gross increases related to current year tax positions | 4 |  |
| Gross increases related to prior year tax positions | 9 |  |
| Gross decreases related to prior year tax positions | (2) |  |
| Settlements | (39) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at September 27, 2024 | $ | 692 |  |

[0000106040-24-000040:notes:156]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of September 27, 2024 were $70 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of September 27, 2024, approximately $597 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-24-000040:notes:157]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 27, 2024, the Company made a payment of $130 million for interest with respect to years 2008 through 2012 and $23 million for tax and interest with respects to years 2013 through 2015, resulting in a remaining liability of $10 million as of September 27, 2024 related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000040:notes:158]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $162 million. Of this amount, $31 million of the interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-24-000040:notes:159]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of September 27, 2024, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-24-000040:notes:160]
Net Income (Loss) Per Common Share
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-24-000040:notes:161]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  |  | September 29,2023 |  |  |  |  |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 493 |  |  |  | $ | (685) |  |  |  |  |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  |  | 15 |  |  |  |  |  |
| Less: income attributable to participating securities(1) | 8 |  |  |  | — |  |  |  |  |  |
| Net income (loss) attributable to common stockholders | $ | 481 |  |  |  | $ | (700) |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 344 |  |  |  | 323 |  |  |  |  |  |
| RSUs, PSUs, ESPP, and the convertible notes | 13 |  |  |  | — |  |  |  |  |  |
| Diluted | 357 |  |  |  | 323 |  |  |  |  |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic | $ | 1.40 |  |  |  | $ | (2.17) |  |  |  |  |  |
| Diluted | $ | 1.35 |  |  |  | $ | (2.17) |  |  |  |  |  |
| Anti-dilutive potential common shares excluded | — |  |  |  | 15 |  |  |  |  |  |

[0000106040-24-000040:notes:162]
(1)     Preferred stock represents participating securities because they participate in any dividends on shares of common stock on a pari passu, pro rata basis. Preferred stock does not participate in undistributed net losses.

[0000106040-24-000040:notes:163]
Basic net income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends allocated to preferred shareholders less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the convertible notes and the preferred shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-24-000040:notes:164]
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and the preferred shares. For the three months ended September 27, 2024, all common shares subject to outstanding equity awards are included in the calculation of diluted shares based on the Company’s average stock price during the period. For the three months ended September 29, 2023, the Company recorded a net loss, and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-24-000040:notes:165]
[same as prior period, unchanged from 0000106040-24-000022:notes:162]

[0000106040-24-000040:notes:166]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure, and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. In this regard, for the three months ended September 29, 2023, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress, other assets and the recognition of a liability for certain contract termination costs. The Company also took actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in September 2023.

[0000106040-24-000040:notes:167]
The Company recorded the following net charges related to these actions for the periods presented:

[0000106040-24-000040:notes:168]
|  | Three Months Ended |  |  |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination benefits | $ | — |  |  | $ | 19 |  |  |  |  |  |  |  |
| Asset impairments | — |  |  | 94 |  |  |  |  |  |  |  |
| Other charges (gains): |  |  |  |  |  |  |  |  |  |
| Contract termination and other | 2 |  |  | 29 |  |  |  |  |  |  |  |
| Gain on sale-leaseback of facility | — |  |  | (85) |  |  |  |  |  |  |  |
| Total employee termination, asset impairment, and other | $ | 2 |  |  | $ | 57 |  |  |  |  |  |  |  |

[0000106040-24-000040:notes:169]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the three months ended September 27, 2024:

[0000106040-24-000040:notes:170]
|  |  |  | Contract Termination and Other |  |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |  |
| Accrual balance at June 28, 2024 |  |  | $ | 28 |  |  |  |  |  |  |  |
| Charges |  |  | 2 |  |  |  |  |  |  |  |
| Cash payments |  |  | (3) |  |  |  |  |  |  |  |
| Accrual balance at September 27, 2024 |  |  | $ | 27 |  |  |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-24-000040:notes:171]
[same as prior period, unchanged from 0000106040-24-000022:notes:167]

[0000106040-24-000040:notes:172]
[same as prior period, unchanged from 0000106040-24-000022:notes:168]

[0000106040-24-000040:notes:173]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $41 million and $37 million as of September 27, 2024 and June 28, 2024, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-24-000040:notes:174]
Legal Proceedings
Tax

[0000106040-24-000040:notes:175]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

[0000106040-24-000040:notes:176]
Intellectual Property Litigation

[0000106040-24-000040:notes:177]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

[0000106040-24-000040:notes:178]
In the fourth quarter of fiscal 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the first quarter of fiscal 2025, the Company recognized incremental charges of $3 million related to plaintiff’s attorney’s fees in Operating expense under Litigation matter, $2 million of post-judgment interest in Other income (expense), net, and $9 million in Cost of revenue from the subsequent amortization of licenses related to this matter. The Company believes it has meritorious defenses, plans to file post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

[0000106040-24-000040:notes:179]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim of U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. SPEX has also requested the court to award it prejudgment interest of $233 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and any prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore, believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the request for prejudgment interest and legal costs in its financial statements as of September 27, 2024.

[0000106040-24-000040:notes:180]
The ability to predict the ultimate outcome of these matters involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.

[0000106040-24-000040:notes:181]
Other Matters

[0000106040-24-000040:notes:182]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.
