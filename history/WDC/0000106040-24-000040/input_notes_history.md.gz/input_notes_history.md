# WDC note change history — 0000106040-24-000022 → 0000106040-24-000040


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2024-10-31):
[0000106040-24-000040:note_history:1]
Intellectual Property Litigation

- added (2024-10-31):
[0000106040-24-000040:note_history:2]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

- added (2024-10-31):
[0000106040-24-000040:note_history:3]
In the fourth quarter of fiscal 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the first quarter of fiscal 2025, the Company recognized incremental charges of $3 million related to plaintiff’s attorney’s fees in Operating expense under Litigation matter, $2 million of post-judgment interest in Other income (expense), net, and $9 million in Cost of revenue from the subsequent amortization of licenses related to this matter. The Company believes it has meritorious defenses, plans to file post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

- added (2024-10-31):
[0000106040-24-000040:note_history:4]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim of U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. SPEX has also requested the court to award it prejudgment interest of $233 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and any prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore, believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the request for prejudgment interest and legal costs in its financial statements as of September 27, 2024.

- added (2024-10-31):
[0000106040-24-000040:note_history:5]
The ability to predict the ultimate outcome of these matters involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.

- changed (2024-10-31):
[0000106040-24-000040:note_history:6]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.
  (was, 2024-04-30, similarity 0.9837):
[0000106040-24-000022:note_history:6]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2024-10-31):
[0000106040-24-000022:note_history:7]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended March 29, 2024 (in millions):

- removed (2024-10-31):
[0000106040-24-000022:note_history:8]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 23 |  |
| Gross increases related to prior year tax positions | 56 |  |
| Gross decreases related to prior year tax positions | (28) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance at March 29, 2024 | $ | 708 |  |


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:9]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 5 |  |
| Notes receivable, Flash Forward | 498 |  |  | 485 |  |
| Investment in Flash Partners | 169 |  |  | 149 |  |
| Investment in Flash Alliance | 236 |  |  | 216 |  |
| Investment in Flash Forward | 143 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,051 |  |  | $ | 991 |  |
  (was, 2024-04-30, similarity 0.9814):
[0000106040-24-000022:note_history:9]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | — |  |  | 48 |  |
| Notes receivable, Flash Forward | 556 |  |  | 709 |  |
| Investment in Flash Partners | 157 |  |  | 161 |  |
| Investment in Flash Alliance | 234 |  |  | 276 |  |
| Investment in Flash Forward | 152 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,099 |  |  | $ | 1,410 |  |

- changed (2024-10-31):
[0000106040-24-000040:note_history:10]
During the three months ended September 27, 2024 and September 29, 2023, the Company made net payments to Flash Ventures of $889 million and $939 million, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2024-04-30, similarity 0.6786):
[0000106040-24-000022:note_history:10]
During the three and nine months ended March 29, 2024 and March 31, 2023, the Company made net payments to Flash Ventures of $0.7 billion and $2.5 billion, and $1.2 billion and $3.2 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2024-10-31):
[0000106040-24-000040:note_history:11]
As of September 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $352 million and $313 million, respectively.
  (was, 2024-04-30, similarity 0.9638):
[0000106040-24-000022:note_history:11]
As of March 29, 2024 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $310 million and $292 million, respectively.

- added (2024-10-31):
[0000106040-24-000040:note_history:12]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2024-10-31):
[0000106040-24-000040:note_history:13]
|  | September 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 503 |  |
| Equity investments | 548 |  |
| Operating lease guarantees | 1,558 |  |
| Inventory and prepayments | 1,166 |  |
| Maximum estimable loss exposure | $ | 3,775 |  |

- added (2024-10-31):
[0000106040-24-000040:note_history:14]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 27, 2024.

- added (2024-10-31):
[0000106040-24-000040:note_history:15]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of September 27, 2024, $722 million remains to be credited against future building depreciation charges. As of September 27, 2024, the Company is also committed to make additional building depreciation prepayments of $605 million, based on the Japanese yen to U.S. dollars exchange rate of 142.56 as of such date, payable as follows: $337 million for the remainder of fiscal year 2025, $33 million in fiscal year 2026, $123 million in fiscal year 2027, $98 million in fiscal year 2028 and $14 million in fiscal year 2029. As of September 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $315 million at varying dates through fiscal year 2035.

- changed (2024-10-31):
[0000106040-24-000040:note_history:16]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024.
  (was, 2024-04-30, similarity 0.9766):
[0000106040-24-000022:note_history:16]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024.

- changed (2024-10-31):
[0000106040-24-000040:note_history:17]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 27, 2024:
  (was, 2024-04-30, similarity 0.9612):
[0000106040-24-000022:note_history:17]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2024:

- changed (2024-10-31):
[0000106040-24-000040:note_history:18]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2025 |  | $ | 331 |  |  | $ | 83 |  |  | $ | 414 |  |
| 2026 |  | 428 |  |  | 126 |  |  | 554 |  |
| 2027 |  | 203 |  |  | 107 |  |  | 310 |  |
| 2028 |  | 81 |  |  | 103 |  |  | 184 |  |
| 2029 |  | 22 |  |  | 56 |  |  | 78 |  |
| 2030 |  | 2 |  |  | 16 |  |  | 18 |  |
| Total guarantee obligations |  | $ | 1,067 |  |  | $ | 491 |  |  | $ | 1,558 |  |
  (was, 2024-04-30, similarity 0.9921):
[0000106040-24-000022:note_history:18]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2024 |  | $ | 110 |  |  | $ | 27 |  |  | $ | 137 |  |
| 2025 |  | 290 |  |  | 79 |  |  | 369 |  |
| 2026 |  | 359 |  |  | 119 |  |  | 478 |  |
| 2027 |  | 154 |  |  | 101 |  |  | 255 |  |
| 2028 |  | 50 |  |  | 97 |  |  | 147 |  |
| 2029 |  | 6 |  |  | 39 |  |  | 45 |  |
| Total guarantee obligations |  | $ | 969 |  |  | $ | 462 |  |  | $ | 1,431 |  |

- changed (2024-10-31):
[0000106040-24-000040:note_history:19]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2024-04-30, similarity 0.8059):
[0000106040-24-000022:note_history:19]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2024, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2024-10-31):
[0000106040-24-000040:note_history:20]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 27, 2024 and September 29, 2023, the Company recognized approximately 2% and 6% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both September 27, 2024 and June 28, 2024, respectively.
  (was, 2024-04-30, similarity 0.7103):
[0000106040-24-000022:note_history:20]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 29, 2024, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 10% and 8% of Accounts receivable, net as of both March 29, 2024 and June 30, 2023, respectively.

- removed (2024-10-31):
[0000106040-24-000022:note_history:21]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2024-10-31):
[0000106040-24-000022:note_history:22]
|  | March 29,2024 |
|  | (in millions) |
| Notes receivable | $ | 556 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,431 |  |
| Inventory and prepayments | 1,046 |  |
| Maximum estimable loss exposure | $ | 3,576 |  |

- removed (2024-10-31):
[0000106040-24-000022:note_history:23]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of flash market conditions, during the second half of 2023 and the first two quarters of 2024, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level during that period to more closely align the Company’s flash-based wafer supply with projected demand. During the nine months ended March 29, 2024, the Company incurred costs of $249 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended March 29, 2024 nor the three and nine months ended March 31, 2023.

- removed (2024-10-31):
[0000106040-24-000022:note_history:24]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, as well as charges for under absorption of overhead costs. During the three months ended December 29, 2023, the Company received a recovery of $36 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its remaining losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

- removed (2024-10-31):
[0000106040-24-000022:note_history:25]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of March 29, 2024, such prepayments aggregated $496 million and will be credited against future wafer charges.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:26]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both hard disk drive and NAND flash technologies.
  (was, 2024-04-30, similarity 0.9402):
[0000106040-24-000022:note_history:26]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both NAND flash and hard disk drive technologies.

- added (2024-10-31):
[0000106040-24-000040:note_history:27]
The Company’s broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- changed (2024-10-31):
[0000106040-24-000040:note_history:28]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2024-04-30, similarity 0.9771):
[0000106040-24-000022:note_history:28]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature as well as the revisions discussed further below. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2024-10-31):
[0000106040-24-000040:note_history:29]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: hard disk drives (“HDD”) and Flash-based products (“Flash”).
  (was, 2024-04-30, similarity 0.9145):
[0000106040-24-000022:note_history:29]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”).

- changed (2024-10-31):
[0000106040-24-000040:note_history:30]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company has incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.
  (was, 2024-04-30, similarity 0.7099):
[0000106040-24-000022:note_history:30]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its Flash and HDD business units to create two independent, public companies. As a result of the plan, the Company incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses, which the Company targets in the second half of calendar year 2024. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

- changed (2024-10-31):
[0000106040-24-000040:note_history:31]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.
  (was, 2024-04-30, similarity 0.8868):
[0000106040-24-000022:note_history:31]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of current macroeconomic conditions. However, actual results could differ materially from these estimates.

- removed (2024-10-31):
[0000106040-24-000022:note_history:32]
The Company’s broad portfolio of technology and products address the following key end markets: Cloud, Client and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- removed (2024-10-31):
[0000106040-24-000022:note_history:33]
Revision of Previously Issued Financial Statements

- removed (2024-10-31):
[0000106040-24-000022:note_history:34]
As previously disclosed in the Company’s Quarterly Report on Form 10-Q for the period ended December 28, 2023, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, “Flash Ventures”). The errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.

- removed (2024-10-31):
[0000106040-24-000022:note_history:35]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 17, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the period detected would have been material to the Company's results of operations for that period. Accordingly, the Company has revised previously reported financial information presented herein for such immaterial errors. A summary of revisions to the Condensed Consolidated Financial Statements presented herein is included for comparative purposes in Note 17, Revision of Previously Issued Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:36]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,600 |  |  | $ | 1,600 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,550 |  |  | 2,588 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,450 |  |  | 7,488 |  |
| Issuance costs | (50) |  |  | (54) |  |
| Subtotal | 7,400 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,750) |  |
| Long-term debt | $ | 5,650 |  |  | $ | 5,684 |  |
  (was, 2024-04-30, similarity 0.8266):
[0000106040-24-000022:note_history:36]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,625 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,825 |  |  | 7,100 |  |
| Issuance costs | (57) |  |  | (30) |  |
| Subtotal | 7,768 |  |  | 7,070 |  |
| Less current portion of long-term debt | (450) |  |  | (1,213) |  |
| Long-term debt | $ | 7,318 |  |  | $ | 5,857 |  |

- changed (2024-10-31):
[0000106040-24-000040:note_history:37]
During the three months ended September 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of September 27, 2024 was 6.696%.
  (was, 2024-04-30, similarity 0.9044):
[0000106040-24-000022:note_history:37]
During the three and nine months ended March 29, 2024, the Company made scheduled repayments of the Term Loan A-2 of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of March 29, 2024 was 6.930%.

- changed (2024-10-31):
[0000106040-24-000040:note_history:38]
During the three months ended September 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).
  (was, 2024-04-30, similarity 0.9446):
[0000106040-24-000022:note_history:38]
During the three and nine months ended March 29, 2024, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- changed (2024-10-31):
[0000106040-24-000040:note_history:39]
The Company had issued an outstanding standby letters of credit of $52 million as of September 27, 2024, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.20 billion as of that date.
  (was, 2024-04-30, similarity 0.8337):
[0000106040-24-000022:note_history:39]
On March 25, 2024, the Company issued a standby letter of credit of $15 million, which reduced the Company’s 2027 Revolving Credit Facility’s capacity by the same amount to $2.24 billion as of March 29, 2024.

- changed (2024-10-31):
[0000106040-24-000040:note_history:40]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with certain financial covenants, consisting of a leverage ratio and a minimum liquidity requirement. As of September 27, 2024, the Company was in compliance with these financial covenants.
  (was, 2024-04-30, similarity 0.9034):
[0000106040-24-000022:note_history:40]
The loan agreements governing the Company’s 2027 Revolving Credit Facility, Term Loan A-2 maturing 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, and a minimum liquidity requirement. As of March 29, 2024, the Company was in compliance with these financial covenants.

- changed (2024-10-31):
[0000106040-24-000040:note_history:41]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).
  (was, 2024-04-30, similarity 0.6075):
[0000106040-24-000022:note_history:41]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 4.75% senior unsecured notes due 2026 (currently, Western Digital Technologies, Inc.).

- added (2024-10-31):
[0000106040-24-000040:note_history:42]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the notes mentioned above was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the calendar quarter ended September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of September 27, 2024. During the calendar quarter ended September 30, 2024, the sale price conditional conversion feature of the notes mentioned above was not triggered. As a result, the 2028 Convertible Notes are not convertible from October 1, 2024 through December 31, 2024. The Company will re-evaluate in each subsequent calendar quarter to determine if the 2028 Convertible Notes have become convertible.

- changed (2024-10-31):
[0000106040-24-000040:note_history:43]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives.
  (was, 2024-04-30, similarity 0.8364):
[0000106040-24-000022:note_history:43]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Company has the option to settle the Capped Calls in either shares, cash or a combination thereof. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would nevertheless be dilution and/or there would not be an offset of such cash payments, in each case, to the extent that such market price exceeds the cap price of the Capped Calls. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to Additional paid-in capital on the Company’s Condensed Consolidated Balance Sheets as of March 29, 2024.

- removed (2024-10-31):
[0000106040-24-000022:note_history:44]
In August 2023, the Company drew $600 million of principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024. The Company repaid $300 million principal amount of the Delayed Draw Term Loan during the nine months ended March 29, 2024.

- removed (2024-10-31):
[0000106040-24-000022:note_history:45]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of March 29, 2024 was 7.550%.

- removed (2024-10-31):
[0000106040-24-000022:note_history:46]
Net proceeds from the 2028 Convertible Notes were approximately $1,563 million after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes.

- removed (2024-10-31):
[0000106040-24-000022:note_history:47]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.

- removed (2024-10-31):
[0000106040-24-000022:note_history:48]
On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:49]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 3.00% convertible notes due 2028 | $ | 1,600 |  |  | $ | 1,600 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,550 |  |  | 2,588 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,450 |  |  | 7,488 |  |
| Issuance costs | (50) |  |  | (54) |  |
| Subtotal | 7,400 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,750) |  |
| Long-term debt | $ | 5,650 |  |  | $ | 5,684 |  |
  (was, 2024-04-30, similarity 0.8266):
[0000106040-24-000022:note_history:49]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 300 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,625 |  |  | 2,700 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,825 |  |  | 7,100 |  |
| Issuance costs | (57) |  |  | (30) |  |
| Subtotal | 7,768 |  |  | 7,070 |  |
| Less current portion of long-term debt | (450) |  |  | (1,213) |  |
| Long-term debt | $ | 7,318 |  |  | $ | 5,857 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:50]
|  | September 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 5 |  |
| Notes receivable, Flash Forward | 498 |  |  | 485 |  |
| Investment in Flash Partners | 169 |  |  | 149 |  |
| Investment in Flash Alliance | 236 |  |  | 216 |  |
| Investment in Flash Forward | 143 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,051 |  |  | $ | 991 |  |
  (was, 2024-04-30, similarity 0.9814):
[0000106040-24-000022:note_history:50]
|  | March 29,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | — |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | — |  |  | 48 |  |
| Notes receivable, Flash Forward | 556 |  |  | 709 |  |
| Investment in Flash Partners | 157 |  |  | 161 |  |
| Investment in Flash Alliance | 234 |  |  | 276 |  |
| Investment in Flash Forward | 152 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,099 |  |  | $ | 1,410 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000106040-24-000040:note_history:51]
The Company’s disaggregated revenue information was as follows:
  (was, 2024-04-30, similarity 0.976):
[0000106040-24-000022:note_history:51]
The Company’s disaggregated revenue information is as follows:

- changed (2024-10-31):
[0000106040-24-000040:note_history:52]
|  | Three Months Ended |  |  |
|  | September 27,2024 |  | September 29,2023 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,208 |  |  | $ | 872 |  |  |  |  |  |
| Client | 1,209 |  |  | 1,147 |  |  |  |  |  |
| Consumer | 678 |  |  | 731 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,837 |  |  | $ | 1,551 |  |  |  |  |  |
| Americas | 1,690 |  |  | 662 |  |  |  |  |  |
| Europe, Middle East and Africa | 568 |  |  | 537 |  |  |  |  |  |
| Total revenue | $ | 4,095 |  |  | $ | 2,750 |  |  |  |  |  |
  (was, 2024-04-30, similarity 0.8):
[0000106040-24-000022:note_history:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 1,553 |  |  | $ | 1,205 |  |  | $ | 3,496 |  |  | $ | 4,258 |  |
| Client | 1,174 |  |  | 975 |  |  | 3,443 |  |  | 3,293 |  |
| Consumer | 730 |  |  | 623 |  |  | 2,300 |  |  | 2,095 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,740 |  |  | $ | 1,353 |  |  | $ | 4,990 |  |  | $ | 4,533 |  |
| Americas | 1,154 |  |  | 935 |  |  | 2,620 |  |  | 3,448 |  |
| Europe, Middle East and Africa | 563 |  |  | 515 |  |  | 1,629 |  |  | 1,665 |  |
| Total revenue | $ | 3,457 |  |  | $ | 2,803 |  |  | $ | 9,239 |  |  | $ | 9,646 |  |
