# WDC note change history — 0000106040-20-000061 → 0000106040-21-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 1, 2021 and July 3, 2020:
  (was, 2020-11-06, similarity 0.9535):
[0000106040-20-000061:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 2, 2020 and July 3, 2020:

- changed (2021-02-09):
[0000106040-21-000011:note_history:2]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 330 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 197 |  |  | 301 |  |
| Notes receivable, Flash Forward | 666 |  |  | 670 |  |
| Investment in Flash Partners | 214 |  |  | 203 |  |
| Investment in Flash Alliance | 315 |  |  | 300 |  |
| Investment in Flash Forward | 136 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,858 |  |  | $ | 1,875 |  |
  (was, 2020-11-06, similarity 0.9837):
[0000106040-20-000061:note_history:2]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 271 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 231 |  |  | 301 |  |
| Notes receivable, Flash Forward | 597 |  |  | 670 |  |
| Investment in Flash Partners | 208 |  |  | 203 |  |
| Investment in Flash Alliance | 307 |  |  | 300 |  |
| Investment in Flash Forward | 132 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,746 |  |  | $ | 1,875 |  |

- added (2021-02-09):
[0000106040-21-000011:note_history:3]
During the three and six months ended January 1, 2021 and during the three and six months ended January 3, 2020, the Company made net payments to Flash Ventures of $1.21 billion and $2.19 billion, and $648 million and $1.33 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2021-02-09):
[0000106040-21-000011:note_history:4]
As of January 1, 2021 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $393 million and $407 million, respectively.
  (was, 2020-11-06, similarity 0.9565):
[0000106040-20-000061:note_history:4]
As of October 2, 2020 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $404 million and $407 million, respectively.

- added (2021-02-09):
[0000106040-21-000011:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 1, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2021-02-09):
[0000106040-21-000011:note_history:6]
|  | January 1,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,193 |  |
| Equity investments | 665 |  |
| Operating lease guarantees | 2,107 |  |
| Inventory and prepayments | 662 |  |
| Maximum estimable loss exposure | $ | 4,627 |  |

- changed (2021-02-09):
[0000106040-21-000011:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the six months ended January 3, 2020, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the six months ended January 1, 2021, the Company recovered $75 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.
  (was, 2020-11-06, similarity 0.8214):
[0000106040-20-000061:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the three months ended October 2, 2020, the Company received a recovery of $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

- added (2021-02-09):
[0000106040-21-000011:note_history:8]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 1, 2021, remaining committed prepayments totaled $149 million.

- changed (2021-02-09):
[0000106040-21-000011:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 1, 2021.
  (was, 2020-11-06, similarity 0.9727):
[0000106040-20-000061:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020.

- changed (2021-02-09):
[0000106040-21-000011:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of January 1, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 1, 2021:
  (was, 2020-11-06, similarity 0.8255):
[0000106040-20-000061:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 2, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020:

- changed (2021-02-09):
[0000106040-21-000011:note_history:11]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2021 |  | $ | 294 |  |  | $ | 63 |  |  | $ | 357 |  |
| 2022 |  | 524 |  |  | 52 |  |  | 576 |  |
| 2023 |  | 409 |  |  | 70 |  |  | 479 |  |
| 2024 |  | 238 |  |  | 126 |  |  | 364 |  |
| 2025 |  | 77 |  |  | 116 |  |  | 193 |  |
| Thereafter |  | 28 |  |  | 110 |  |  | 138 |  |
| Total guarantee obligations |  | $ | 1,570 |  |  | $ | 537 |  |  | $ | 2,107 |  |
  (was, 2020-11-06, similarity 0.9923):
[0000106040-20-000061:note_history:11]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2021 |  | $ | 407 |  |  | $ | 80 |  |  | $ | 487 |  |
| 2022 |  | 469 |  |  | 51 |  |  | 520 |  |
| 2023 |  | 356 |  |  | 69 |  |  | 425 |  |
| 2024 |  | 194 |  |  | 123 |  |  | 317 |  |
| 2025 |  | 55 |  |  | 113 |  |  | 168 |  |
| Thereafter |  | 15 |  |  | 72 |  |  | 87 |  |
| Total guarantee obligations |  | $ | 1,496 |  |  | $ | 508 |  |  | $ | 2,004 |  |

- changed (2021-02-09):
[0000106040-21-000011:note_history:12]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of January 1, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2020-11-06, similarity 0.9864):
[0000106040-20-000061:note_history:12]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 2, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2021-02-09):
[0000106040-21-000011:note_history:13]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended January 1, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended January 3, 2020, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 7% and 4% of Accounts receivable, net as of January 1, 2021 and July 3, 2020, respectively.

- removed (2021-02-09):
[0000106040-20-000061:note_history:14]
During the three months ended October 2, 2020 and October 4, 2019, the Company made net payments to Flash Ventures of $981 million and $682 million, respectively, for purchased flash-based memory wafers and net loans and investments.

- removed (2021-02-09):
[0000106040-20-000061:note_history:15]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 2, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2021-02-09):
[0000106040-20-000061:note_history:16]
|  | October 2,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,099 |  |
| Equity investments | 647 |  |
| Operating lease guarantees | 2,004 |  |
| Inventory and prepayments | 575 |  |
| Maximum estimable loss exposure | $ | 4,325 |  |

- removed (2021-02-09):
[0000106040-20-000061:note_history:17]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company has paid for most of its share of initial K1 equipment investments and relocation costs. Other period expenses associated with the initial production ramp at K1 are expected to begin trailing off toward the end of calendar year 2020 as output increases. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of October 2, 2020, remaining committed prepayments totaled $178 million.

- removed (2021-02-09):
[0000106040-20-000061:note_history:18]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 2, 2020 and October 4, 2019, the Company recognized approximately 2% and 1%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 6% and 4% of Accounts receivable, net as of October 2, 2020 and July 3, 2020, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:19]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, including the effects of ongoing vaccination efforts, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.
  (was, 2020-11-06, similarity 0.7895):
[0000106040-20-000061:note_history:19]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.

- changed (2021-02-09):
[0000106040-21-000011:note_history:20]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). The Company is in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. Management expects to finalize its assessment of its operating segments when the transition is completed, which is expected to be by the end of fiscal 2021.
  (was, 2020-11-06, similarity 0.9781):
[0000106040-20-000061:note_history:20]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). Beginning in the second fiscal quarter, the Company is in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. Management expects to finalize its assessment of its operating segments when the transition is completed, which is expected to be by the end of fiscal 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:21]
Debt
Debt consisted of the following as of January 1, 2021 and July 3, 2020:
  (was, 2020-11-06, similarity 0.9118):
[0000106040-20-000061:note_history:21]
Debt
Debt consisted of the following as of October 2, 2020 and July 3, 2020:

- changed (2021-02-09):
[0000106040-21-000011:note_history:22]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,457 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,393 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,250 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (117) |  |  | (136) |  |
| Subtotal | 9,133 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,882 |  |  | $ | 9,289 |  |
  (was, 2020-11-06, similarity 0.9689):
[0000106040-20-000061:note_history:22]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,520 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,498 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (126) |  |  | (136) |  |
| Subtotal | 9,372 |  |  | 9,575 |  |
| Less current portion of long-term debt | (286) |  |  | (286) |  |
| Long-term debt | $ | 9,086 |  |  | $ | 9,289 |  |

- changed (2021-02-09):
[0000106040-21-000011:note_history:23]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 1, 2021, the Company was in compliance with these financial covenants.
During the six months ended January 1, 2021, the Company made voluntary prepayments totaling $300 million on its Term Loan B-4. In October 2020, the 0.50% convertible senior notes due 2020 were settled in full in accordance with their terms
  (was, 2020-11-06, similarity 0.8031):
[0000106040-20-000061:note_history:23]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 2, 2020, the Company was in compliance with these financial covenants.
During the three months ended October 2, 2020, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. Subsequent to October 2, 2020, the 0.50% convertible notes due 2020 were settled in full in accordance with their terms


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:24]
Debt consisted of the following as of January 1, 2021 and July 3, 2020:
  (was, 2020-11-06, similarity 0.9048):
[0000106040-20-000061:note_history:24]
Debt consisted of the following as of October 2, 2020 and July 3, 2020:

- changed (2021-02-09):
[0000106040-21-000011:note_history:25]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,457 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,393 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,250 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (117) |  |  | (136) |  |
| Subtotal | 9,133 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,882 |  |  | $ | 9,289 |  |
  (was, 2020-11-06, similarity 0.9689):
[0000106040-20-000061:note_history:25]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,520 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,498 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (126) |  |  | (136) |  |
| Subtotal | 9,372 |  |  | 9,575 |  |
| Less current portion of long-term debt | (286) |  |  | (286) |  |
| Long-term debt | $ | 9,086 |  |  | $ | 9,289 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:26]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 1, 2021 and July 3, 2020:
  (was, 2020-11-06, similarity 0.9535):
[0000106040-20-000061:note_history:26]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 2, 2020 and July 3, 2020:

- changed (2021-02-09):
[0000106040-21-000011:note_history:27]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 330 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 197 |  |  | 301 |  |
| Notes receivable, Flash Forward | 666 |  |  | 670 |  |
| Investment in Flash Partners | 214 |  |  | 203 |  |
| Investment in Flash Alliance | 315 |  |  | 300 |  |
| Investment in Flash Forward | 136 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,858 |  |  | $ | 1,875 |  |
  (was, 2020-11-06, similarity 0.9837):
[0000106040-20-000061:note_history:27]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 271 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 231 |  |  | 301 |  |
| Notes receivable, Flash Forward | 597 |  |  | 670 |  |
| Investment in Flash Partners | 208 |  |  | 203 |  |
| Investment in Flash Alliance | 307 |  |  | 300 |  |
| Investment in Flash Forward | 132 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,746 |  |  | $ | 1,875 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-02-09):
[0000106040-21-000011:note_history:28]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,909 |  |  | $ | 2,396 |  |  | $ | 3,753 |  |  | $ | 4,804 |  |  |  |
| Flash-based | 2,034 |  |  | 1,838 |  |  | 4,112 |  |  | 3,470 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,131 |  |  | $ | 1,797 |  |  | $ | 4,077 |  |  | $ | 3,413 |  |  |  |
| Data Center Devices & Solutions | 807 |  |  | 1,489 |  |  | 1,936 |  |  | 3,021 |  |  |  |
| Client Solutions | 1,005 |  |  | 948 |  |  | 1,852 |  |  | 1,840 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 945 |  |  | $ | 1,296 |  |  | $ | 2,024 |  |  | $ | 2,609 |  |  |  |
| Europe, Middle East and Africa | 725 |  |  | 811 |  |  | 1,354 |  |  | 1,590 |  |  |  |
| Asia | 2,273 |  |  | 2,127 |  |  | 4,487 |  |  | 4,075 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |

- removed (2021-02-09):
[0000106040-20-000061:note_history:29]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0000106040-21-000011:note_history:30]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either January 1, 2021 or July 3, 2020.
  (was, 2020-11-06, similarity 0.9233):
[0000106040-20-000061:note_history:30]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 2, 2020 or July 3, 2020.

- changed (2021-02-09):
[0000106040-21-000011:note_history:31]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of January 1, 2021 and July 3, 2020 as well as the related amortization for the three and six months ended January 1, 2021 and January 3, 2020 were not material.
  (was, 2020-11-06, similarity 0.9547):
[0000106040-20-000061:note_history:31]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 2, 2020 and July 3, 2020 as well as the related amortization for the three months ended October 2, 2020 and October 4, 2019 were not material.

- changed (2021-02-09):
[0000106040-21-000011:note_history:32]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of January 1, 2021 and July 3, 2020, contract liabilities were not material.
  (was, 2020-11-06, similarity 0.9321):
[0000106040-20-000061:note_history:32]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 2, 2020 and July 3, 2020, contract liabilities were not material.

- changed (2021-02-09):
[0000106040-21-000011:note_history:33]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of January 1, 2021 was $91 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.
  (was, 2020-11-06, similarity 0.993):
[0000106040-20-000061:note_history:33]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 2, 2020 was $102 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $31 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.

- added (2021-02-09):
[0000106040-21-000011:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,909 |  |  | $ | 2,396 |  |  | $ | 3,753 |  |  | $ | 4,804 |  |  |  |
| Flash-based | 2,034 |  |  | 1,838 |  |  | 4,112 |  |  | 3,470 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,131 |  |  | $ | 1,797 |  |  | $ | 4,077 |  |  | $ | 3,413 |  |  |  |
| Data Center Devices & Solutions | 807 |  |  | 1,489 |  |  | 1,936 |  |  | 3,021 |  |  |  |
| Client Solutions | 1,005 |  |  | 948 |  |  | 1,852 |  |  | 1,840 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 945 |  |  | $ | 1,296 |  |  | $ | 2,024 |  |  | $ | 2,609 |  |  |  |
| Europe, Middle East and Africa | 725 |  |  | 811 |  |  | 1,354 |  |  | 1,590 |  |  |  |
| Asia | 2,273 |  |  | 2,127 |  |  | 4,487 |  |  | 4,075 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |

- added (2021-02-09):
[0000106040-21-000011:note_history:35]
The Company’s top 10 customers accounted for 43% and 41% of its net revenue for the three and six months ended January 1, 2021, respectively, and 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively. For the three and six months ended January 1, 2021 and January 3, 2020, no single customer accounted for 10% or more of the Company’s net revenue.

- removed (2021-02-09):
[0000106040-20-000061:note_history:36]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |

- removed (2021-02-09):
[0000106040-20-000061:note_history:37]
The Company’s top 10 customers accounted for 44% of its net revenue for the three months ended October 2, 2020, and 43% of its net revenue for the three months ended October 4, 2019. For the three months ended October 2, 2020, no single customer accounted for 10% of the Company’s net revenue, and for the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue.
