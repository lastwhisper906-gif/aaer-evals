# WDC notes — 0000106040-21-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-21-000011:notes:1]
[same as prior period, unchanged from 0000106040-20-000061:notes:1]

[0000106040-21-000011:notes:2]
[same as prior period, unchanged from 0000106040-20-000061:notes:2]

[0000106040-21-000011:notes:3]
[same as prior period, unchanged from 0000106040-20-000061:notes:3]

[0000106040-21-000011:notes:4]
[same as prior period, unchanged from 0000106040-20-000061:notes:4]

[0000106040-21-000011:notes:5]
[same as prior period, unchanged from 0000106040-20-000061:notes:5]

[0000106040-21-000011:notes:6]
[same as prior period, unchanged from 0000106040-20-000061:notes:6]

[0000106040-21-000011:notes:7]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, including the effects of ongoing vaccination efforts, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.

[0000106040-21-000011:notes:8]
[same as prior period, unchanged from 0000106040-20-000061:notes:8]

[0000106040-21-000011:notes:9]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). The Company is in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. Management expects to finalize its assessment of its operating segments when the transition is completed, which is expected to be by the end of fiscal 2021.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-21-000011:notes:10]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-21-000011:notes:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Updates (“ASU”) No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-21-000011:notes:12]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted Accounting Standards Codification (ASC) 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-21-000011:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-21-000011:notes:14]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2020, which for the Company is the first quarter of fiscal 2022. Early adoption is permitted. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-21-000011:notes:15]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either January 1, 2021 or July 3, 2020.

[0000106040-21-000011:notes:16]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of January 1, 2021 and July 3, 2020 as well as the related amortization for the three and six months ended January 1, 2021 and January 3, 2020 were not material.

[0000106040-21-000011:notes:17]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of January 1, 2021 and July 3, 2020, contract liabilities were not material.

[0000106040-21-000011:notes:18]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of January 1, 2021 was $91 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.

[0000106040-21-000011:notes:19]
[same as prior period, unchanged from 0000106040-20-000061:notes:19]

[0000106040-21-000011:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,909 |  |  | $ | 2,396 |  |  | $ | 3,753 |  |  | $ | 4,804 |  |  |  |
| Flash-based | 2,034 |  |  | 1,838 |  |  | 4,112 |  |  | 3,470 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,131 |  |  | $ | 1,797 |  |  | $ | 4,077 |  |  | $ | 3,413 |  |  |  |
| Data Center Devices & Solutions | 807 |  |  | 1,489 |  |  | 1,936 |  |  | 3,021 |  |  |  |
| Client Solutions | 1,005 |  |  | 948 |  |  | 1,852 |  |  | 1,840 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 945 |  |  | $ | 1,296 |  |  | $ | 2,024 |  |  | $ | 2,609 |  |  |  |
| Europe, Middle East and Africa | 725 |  |  | 811 |  |  | 1,354 |  |  | 1,590 |  |  |  |
| Asia | 2,273 |  |  | 2,127 |  |  | 4,487 |  |  | 4,075 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |

[0000106040-21-000011:notes:21]
The Company’s top 10 customers accounted for 43% and 41% of its net revenue for the three and six months ended January 1, 2021, respectively, and 44% and 43% of its net revenue for the three and six months ended January 3, 2020, respectively. For the three and six months ended January 1, 2021 and January 3, 2020, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-21-000011:notes:22]
[same as prior period, unchanged from 0000106040-20-000061:notes:22]

[0000106040-21-000011:notes:23]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the six months ended January 1, 2021 and January 3, 2020, the Company sold trade accounts receivable and received cash proceeds of $173 million and $198 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of January 1, 2021 and July 3, 2020, the amount of factored receivables that remained outstanding was $45 million and $113 million, respectively.

[0000106040-21-000011:notes:24]
[same as prior period, unchanged from 0000106040-20-000061:notes:24]

[0000106040-21-000011:notes:25]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,466 |  |  | $ | 1,306 |  |
| Work-in-process | 1,110 |  |  | 956 |  |
| Finished goods | 1,000 |  |  | 808 |  |
| Total inventories | $ | 3,576 |  |  | $ | 3,070 |  |

[0000106040-21-000011:notes:26]
[same as prior period, unchanged from 0000106040-20-000061:notes:26]

[0000106040-21-000011:notes:27]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 278 |  |  | $ | 294 |  |
| Buildings and improvements | 1,793 |  |  | 1,837 |  |
| Machinery and equipment | 7,684 |  |  | 7,391 |  |
| Computer equipment and software | 436 |  |  | 429 |  |
| Furniture and fixtures | 52 |  |  | 52 |  |
| Construction-in-process | 321 |  |  | 297 |  |
| Property, plant and equipment, gross | 10,564 |  |  | 10,300 |  |
| Accumulated depreciation | (7,646) |  |  | (7,446) |  |
| Property, plant and equipment, net | $ | 2,918 |  |  | $ | 2,854 |  |

[0000106040-21-000011:notes:28]
[same as prior period, unchanged from 0000106040-20-000061:notes:28]

[0000106040-21-000011:notes:29]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 3, 2020 | $ | 10,067 |  |
| Foreign currency translation adjustment | 4 |  |
| Balance at January 1, 2021 | $ | 10,071 |  |

[0000106040-21-000011:notes:30]
[same as prior period, unchanged from 0000106040-20-000061:notes:30]

[0000106040-21-000011:notes:31]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,526 |  |  | $ | 5,541 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,010) |  |  | (4,680) |  |
| Intangible assets, net | $ | 596 |  |  | $ | 941 |  |

[0000106040-21-000011:notes:32]
[same as prior period, unchanged from 0000106040-20-000061:notes:32]

[0000106040-21-000011:notes:33]
[same as prior period, unchanged from 0000106040-20-000061:notes:33]

[0000106040-21-000011:notes:34]
[same as prior period, unchanged from 0000106040-20-000061:notes:34]

[0000106040-21-000011:notes:35]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 391 |  |  | $ | 357 |  |  | $ | 408 |  |  | $ | 350 |  |  |  |
| Charges to operations | 24 |  |  | 50 |  |  | 59 |  |  | 99 |  |  |  |
| Utilization | (24) |  |  | (35) |  |  | (55) |  |  | (83) |  |  |  |
| Changes in estimate related to pre-existing warranties | (25) |  |  | 6 |  |  | (46) |  |  | 12 |  |  |  |
| Warranty accrual, end of period | $ | 366 |  |  | $ | 378 |  |  | $ | 366 |  |  | $ | 378 |  |  |  |

[0000106040-21-000011:notes:36]
[same as prior period, unchanged from 0000106040-20-000061:notes:36]

[0000106040-21-000011:notes:37]
|  | January 1,2021 |  | July 3,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 166 |  |  | $ | 205 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 200 |  |  | 203 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 366 |  |  | $ | 408 |  |  |  |  |  |  |  |

[0000106040-21-000011:notes:38]
[same as prior period, unchanged from 0000106040-20-000061:notes:38]

[0000106040-21-000011:notes:39]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 698 |  |  | $ | 815 |  |
| Payables related to unrecognized tax benefits | 724 |  |  | 720 |  |
| Other non-current liabilities | 893 |  |  | 881 |  |
| Total other liabilities | $ | 2,315 |  |  | $ | 2,416 |  |

[0000106040-21-000011:notes:40]
[same as prior period, unchanged from 0000106040-20-000061:notes:40]

[0000106040-21-000011:notes:41]
[same as prior period, unchanged from 0000106040-20-000061:notes:41]

[0000106040-21-000011:notes:42]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 3, 2020 | $ | (58) |  |  | $ | (2) |  |  |  |  |  |  | $ | (97) |  |  | $ | (157) |  |
| Other comprehensive loss before reclassifications | 2 |  |  | 66 |  |  |  |  |  |  | 43 |  |  | 111 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 7 |  |  | 7 |  |
| Income tax expense related to items of other comprehensive loss | — |  |  | — |  |  |  |  |  |  | (11) |  |  | (11) |  |
| Net current-period other comprehensive loss | 2 |  |  | 66 |  |  |  |  |  |  | 39 |  |  | 107 |  |
| Balance at January 1, 2021 | $ | (56) |  |  | $ | 64 |  |  |  |  |  |  | $ | (58) |  |  | $ | (50) |  |

[0000106040-21-000011:notes:43]
During the three and six months ended January 1, 2021 and January 3, 2020, the amounts reclassified out of AOCI related to derivative contracts were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-21-000011:notes:44]
[same as prior period, unchanged from 0000106040-20-000061:notes:44]

[0000106040-21-000011:notes:45]
[same as prior period, unchanged from 0000106040-20-000061:notes:45]

[0000106040-21-000011:notes:46]
[same as prior period, unchanged from 0000106040-20-000061:notes:46]

[0000106040-21-000011:notes:47]
[same as prior period, unchanged from 0000106040-20-000061:notes:47]

[0000106040-21-000011:notes:48]
[same as prior period, unchanged from 0000106040-20-000061:notes:48]

[0000106040-21-000011:notes:49]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of January 1, 2021 and July 3, 2020, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-21-000011:notes:50]
|  | January 1, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 806 |  |  | $ | — |  |  | $ | — |  |  | $ | 806 |  |
| Foreign exchange contracts | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Total assets at fair value | $ | 806 |  |  | $ | 33 |  |  | $ | — |  |  | $ | 839 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Interest rate swap contract | — |  |  | 109 |  |  | — |  |  | 109 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 125 |  |  | $ | — |  |  | $ | 125 |  |

[0000106040-21-000011:notes:51]
[same as prior period, unchanged from 0000106040-20-000061:notes:51]

[0000106040-21-000011:notes:52]
During the three and six months ended January 1, 2021 and January 3, 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-21-000011:notes:53]
[same as prior period, unchanged from 0000106040-20-000061:notes:53]

[0000106040-21-000011:notes:54]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2021 and the fourth quarter of 2020, respectively.

[0000106040-21-000011:notes:55]
|  | January 1, 2021 |  | July 3, 2020 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | 30 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,451 |  |  | 4,443 |  |  | 4,576 |  |  | 4,474 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,393 |  |  | 1,393 |  |  | 1,692 |  |  | 1,656 |  |
| 1.50% convertible notes due 2024 | 1,002 |  |  | 1,095 |  |  | 987 |  |  | 1,036 |  |
| 4.75% senior unsecured notes due 2026 | 2,287 |  |  | 2,553 |  |  | 2,286 |  |  | 2,428 |  |
| Total | $ | 9,133 |  |  | $ | 9,484 |  |  | $ | 9,575 |  |  | $ | 9,624 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-21-000011:notes:56]
Derivative Instruments and Hedging Activities
As of January 1, 2021, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-21-000011:notes:57]
As of January 1, 2021, the amount of existing net losses related to cash flow hedges recorded in AOCI included $57 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of January 1, 2021, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-21-000011:notes:58]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and six months ended January 1, 2021 and January 3, 2020, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-21-000011:notes:59]
[same as prior period, unchanged from 0000106040-20-000061:notes:59]

[0000106040-21-000011:notes:60]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of January 1, 2021 and July 3, 2020, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-21-000011:notes:61]
Debt
Debt consisted of the following as of January 1, 2021 and July 3, 2020:

[0000106040-21-000011:notes:62]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,457 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,393 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,250 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (117) |  |  | (136) |  |
| Subtotal | 9,133 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,882 |  |  | $ | 9,289 |  |

[0000106040-21-000011:notes:63]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 1, 2021, the Company was in compliance with these financial covenants.
During the six months ended January 1, 2021, the Company made voluntary prepayments totaling $300 million on its Term Loan B-4. In October 2020, the 0.50% convertible senior notes due 2020 were settled in full in accordance with their terms


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-21-000011:notes:64]
[same as prior period, unchanged from 0000106040-20-000061:notes:64]

[0000106040-21-000011:notes:65]
[same as prior period, unchanged from 0000106040-20-000061:notes:65]

[0000106040-21-000011:notes:66]
[same as prior period, unchanged from 0000106040-20-000061:notes:66]

[0000106040-21-000011:notes:67]
|  | January 1,2021 |  | July 3,2020 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 387 |  |  | $ | 366 |  |  |  |
| Fair value of plan assets at end of period | 227 |  |  | 215 |  |  |  |
| Unfunded status | $ | 160 |  |  | $ | 151 |  |  |  |

[0000106040-21-000011:notes:68]
[same as prior period, unchanged from 0000106040-20-000061:notes:68]

[0000106040-21-000011:notes:69]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 159 |  |  | 150 |  |
| Net amount recognized | $ | 160 |  |  | $ | 151 |  |

[0000106040-21-000011:notes:70]
Net periodic benefit costs were not material for the three and six months ended January 1, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-21-000011:notes:71]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-21-000011:notes:72]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-21-000011:notes:73]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of January 1, 2021 and July 3, 2020:

[0000106040-21-000011:notes:74]
|  | January 1,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 330 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 197 |  |  | 301 |  |
| Notes receivable, Flash Forward | 666 |  |  | 670 |  |
| Investment in Flash Partners | 214 |  |  | 203 |  |
| Investment in Flash Alliance | 315 |  |  | 300 |  |
| Investment in Flash Forward | 136 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,858 |  |  | $ | 1,875 |  |

[0000106040-21-000011:notes:75]
During the three and six months ended January 1, 2021 and during the three and six months ended January 3, 2020, the Company made net payments to Flash Ventures of $1.21 billion and $2.19 billion, and $648 million and $1.33 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-21-000011:notes:76]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-21-000011:notes:77]
As of January 1, 2021 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $393 million and $407 million, respectively.

[0000106040-21-000011:notes:78]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 1, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-21-000011:notes:79]
|  | January 1,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,193 |  |
| Equity investments | 665 |  |
| Operating lease guarantees | 2,107 |  |
| Inventory and prepayments | 662 |  |
| Maximum estimable loss exposure | $ | 4,627 |  |

[0000106040-21-000011:notes:80]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-21-000011:notes:81]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the six months ended January 3, 2020, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the six months ended January 1, 2021, the Company recovered $75 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000011:notes:82]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 1, 2021, remaining committed prepayments totaled $149 million.

[0000106040-21-000011:notes:83]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-21-000011:notes:84]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-21-000011:notes:85]
Off-Balance Sheet Liabilities

[0000106040-21-000011:notes:86]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-21-000011:notes:87]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 1, 2021.

[0000106040-21-000011:notes:88]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 217 |  |  | $ | 2,107 |  |

[0000106040-21-000011:notes:89]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of January 1, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 1, 2021:

[0000106040-21-000011:notes:90]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2021 |  | $ | 294 |  |  | $ | 63 |  |  | $ | 357 |  |
| 2022 |  | 524 |  |  | 52 |  |  | 576 |  |
| 2023 |  | 409 |  |  | 70 |  |  | 479 |  |
| 2024 |  | 238 |  |  | 126 |  |  | 364 |  |
| 2025 |  | 77 |  |  | 116 |  |  | 193 |  |
| Thereafter |  | 28 |  |  | 110 |  |  | 138 |  |
| Total guarantee obligations |  | $ | 1,570 |  |  | $ | 537 |  |  | $ | 2,107 |  |

[0000106040-21-000011:notes:91]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of January 1, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-21-000011:notes:92]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended January 1, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended January 3, 2020, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 7% and 4% of Accounts receivable, net as of January 1, 2021 and July 3, 2020, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-21-000011:notes:93]
[same as prior period, unchanged from 0000106040-20-000061:notes:93]

[0000106040-21-000011:notes:94]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of January 1, 2021:

[0000106040-21-000011:notes:95]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | ($ in millions) |  |  |  |  |  |  |  |  |
| Remaining six months of 2021 | $ | 25 |  |  |  |  |  |  |  |  |  |
| 2022 | 40 |  |  |  |  |  |  |  |  |  |
| 2023 | 33 |  |  |  |  |  |  |  |  |  |
| 2024 | 33 |  |  |  |  |  |  |  |  |  |
| 2025 | 31 |  |  |  |  |  |  |  |  |  |
| Thereafter | 147 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 309 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | (55) |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 254 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 38 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 216 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 239 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.8 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.2 | % |  |  |  |  |  |  |  |  |

[0000106040-21-000011:notes:96]
[same as prior period, unchanged from 0000106040-20-000061:notes:96]

[0000106040-21-000011:notes:97]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
|  | (in millions) |
| Cost of operating leases | $ | 12 |  |  | $ | 18 |  |  | $ | 25 |  |  | $ | 30 |  |
| Cash paid for operating leases | 14 |  |  | 13 |  |  | 26 |  |  | 29 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 20 |  |  | 1 |  |  | 27 |  |  | 50 |  |

[0000106040-21-000011:notes:98]
[same as prior period, unchanged from 0000106040-20-000061:notes:98]

[0000106040-21-000011:notes:99]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of January 1, 2021, the Company had the following minimum long-term commitments:

[0000106040-21-000011:notes:100]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining six months of 2021 |  | $ | 226 |  |
| 2022 |  | 613 |  |
| 2023 |  | 562 |  |
| 2024 |  | 350 |  |
| 2025 |  | 148 |  |
| Thereafter |  | 190 |  |
| Total |  | $ | 2,089 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-21-000011:notes:101]
[same as prior period, unchanged from 0000106040-20-000061:notes:101]

[0000106040-21-000011:notes:102]
[same as prior period, unchanged from 0000106040-20-000061:notes:102]

[0000106040-21-000011:notes:103]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Options | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4 |  |  |  |
| RSUs and PSUs | 72 |  |  | 70 |  |  | 139 |  |  | 136 |  |  |  |
| ESPP | 8 |  |  | 5 |  |  | 17 |  |  | 14 |  |  |  |
| Total | $ | 80 |  |  | $ | 77 |  |  | $ | 156 |  |  | $ | 154 |  |  |  |

[0000106040-21-000011:notes:104]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 15 |  |  | $ | 13 |  |  | $ | 27 |  |  | $ | 25 |  |  |  |
| Research and development | 40 |  |  | 41 |  |  | 79 |  |  | 82 |  |  |  |
| Selling, general and administrative | 25 |  |  | 23 |  |  | 50 |  |  | 47 |  |  |  |
| Subtotal | 80 |  |  | 77 |  |  | 156 |  |  | 154 |  |  |  |
| Tax benefit | (9) |  |  | (11) |  |  | (20) |  |  | (23) |  |  |  |
| Total | $ | 71 |  |  | $ | 66 |  |  | $ | 136 |  |  | $ | 131 |  |  |  |

[0000106040-21-000011:notes:105]
[same as prior period, unchanged from 0000106040-20-000061:notes:105]

[0000106040-21-000011:notes:106]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of January 1, 2021:

[0000106040-21-000011:notes:107]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 663 |  |  | 2.8 |
| ESPP | 22 |  |  | 0.7 |
| Total unamortized compensation cost | $ | 685 |  |  |  |

[0000106040-21-000011:notes:108]
[same as prior period, unchanged from 0000106040-20-000061:notes:108]

[0000106040-21-000011:notes:109]
[same as prior period, unchanged from 0000106040-20-000061:notes:109]

[0000106040-21-000011:notes:110]
[same as prior period, unchanged from 0000106040-20-000061:notes:110]

[0000106040-21-000011:notes:111]
[same as prior period, unchanged from 0000106040-20-000061:notes:111]

[0000106040-21-000011:notes:112]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 3, 2020 | 2.7 |  |  | $ | 69.16 |  |  | 2.1 |  | $ | — |  |
| Exercised | (0.2) |  |  | 44.09 |  |  |  |  | $ | 2 |  |
| Canceled or expired | (0.7) |  |  | 74.66 |  |  |  |  |  |
| Options outstanding at January 1, 2021 | 1.8 |  |  | 69.75 |  |  | 1.74 |  | $ | 9 |  |
| Exercisable at January 1, 2021 | 1.8 |  |  | $ | 69.75 |  |  | 1.74 |  | $ | 9 |  |

[0000106040-21-000011:notes:113]
[same as prior period, unchanged from 0000106040-20-000061:notes:113]

[0000106040-21-000011:notes:114]
[same as prior period, unchanged from 0000106040-20-000061:notes:114]

[0000106040-21-000011:notes:115]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 3, 2020 | 13.3 |  |  | $ | 60.92 |  |  |  |
| Granted | 8.1 |  |  | 37.97 |  |  |  |
| Vested | (3.9) |  |  | 61.33 |  |  | $ | 158 |  |
| Forfeited | (0.9) |  |  | 60.23 |  |  |  |
| RSUs and PSUs outstanding at January 1, 2021 | 16.6 |  |  | 49.45 |  |  |  |

[0000106040-21-000011:notes:116]
[same as prior period, unchanged from 0000106040-20-000061:notes:116]

[0000106040-21-000011:notes:117]
[same as prior period, unchanged from 0000106040-20-000061:notes:117]

[0000106040-21-000011:notes:118]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the six months ended January 1, 2021 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of January 1, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-21-000011:notes:119]
[same as prior period, unchanged from 0000106040-20-000061:notes:119]

[0000106040-21-000011:notes:120]
[same as prior period, unchanged from 0000106040-20-000061:notes:120]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-21-000011:notes:121]
Income Tax Expense
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted in response to the COVID-19 pandemic in the U.S. The CARES Act, among other things, allows net operating losses arising in tax years 2018, 2019, and 2020 to be carried back to each of the five preceding taxable years to generate a refund of previously paid income taxes and increases the business interest expense limitation from 30% to 50% of adjusted taxable income for tax years 2019 and 2020. Additionally, countries around the world continue to implement emergency tax measures to provide relief similar to the CARES Act. The Company at present does not expect that any of the provisions of the CARES Act or the emergency tax measures around the world would result in a material cash benefit.

[0000106040-21-000011:notes:122]
On December 27, 2020, the Consolidated Appropriations Act (the “Appropriations Act”) was enacted to fund the federal government through their fiscal year, extend certain expiring tax provisions and provide additional emergency relief to individuals and businesses related to the COVID-19 pandemic in the U.S. The Company at present does not expect any of the provisions of the Appropriations Act to have a material impact on its financial statements. The Company continues to monitor and evaluate the regulatory and interpretive guidance related to the CARES Act and the Appropriations Act, as well as legislation in other jurisdictions.

[0000106040-21-000011:notes:123]
[same as prior period, unchanged from 0000106040-20-000061:notes:122]

[0000106040-21-000011:notes:124]
[same as prior period, unchanged from 0000106040-20-000061:notes:123]

[0000106040-21-000011:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 85 |  |  | $ | (40) |  |  | $ | 82 |  |  | $ | (277) |  |
| Income tax expense | 23 |  |  | 99 |  |  | 80 |  |  | 138 |  |
| Effective tax rate | 27 | % |  | (248) | % |  | 98 | % |  | (50) | % |

[0000106040-21-000011:notes:126]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the three and six months ended January 1, 2021 includes the discrete effects of favorable adjustments proposed by tax authorities of $8 million. The effective tax rate for the six months ended January 1, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $12 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes paid by the Company.

[0000106040-21-000011:notes:127]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-21-000011:notes:128]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest and penalties. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest and penalties. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. On May 4, 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2009 and fiscal years 2010 through 2012. In September 2020 and December 2020, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2013 through 2015 that, if sustained, would result in additional federal tax totaling approximately $343 million. The Company disagrees with the proposed adjustments and continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-21-000011:notes:129]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of January 1, 2021, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-21-000011:notes:130]
As of January 1, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $715 million. Accrued interest and penalties related to unrecognized tax benefits as of January 1, 2021 was approximately $146 million. Of these amounts, approximately $724 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-21-000011:notes:131]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-21-000011:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 62 |  |  | $ | (139) |  |  | $ | 2 |  |  | $ | (415) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 305 |  |  | 298 |  |  | 304 |  |  | 297 |  |
| Employee stock options, RSUs, PSUs and ESPP | 2 |  |  | — |  |  | 1 |  |  | — |  |
| Basic and diluted | 307 |  |  | 298 |  |  | 305 |  |  | 297 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.20 |  |  | $ | (0.47) |  |  | $ | 0.01 |  |  | $ | (1.40) |  |
| Diluted | $ | 0.20 |  |  | $ | (0.47) |  |  | $ | 0.01 |  |  | $ | (1.40) |  |
| Anti-dilutive potential common shares excluded | 8 |  |  | 15 |  |  | 10 |  |  | 15 |  |

[0000106040-21-000011:notes:133]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three and six months ended January 3, 2020, the Company recorded net loss, and all shares subject to outstanding equity awards have been excluded for those periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-21-000011:notes:134]
[same as prior period, unchanged from 0000106040-20-000061:notes:133]

[0000106040-21-000011:notes:135]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |  |  |
| Business Realignment | 2 |  |  | 26 |  |  | 25 |  |  | 30 |  |  |  |
| Total employee termination and other charges | 2 |  |  | 26 |  |  | 25 |  |  | 34 |  |  |  |
| Business Realignment | — |  |  | (17) |  |  | — |  |  | (17) |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 2 |  |  | $ | 9 |  |  | $ | 25 |  |  | $ | 17 |  |  |  |

[0000106040-21-000011:notes:136]
[same as prior period, unchanged from 0000106040-20-000061:notes:135]

[0000106040-21-000011:notes:137]
[same as prior period, unchanged from 0000106040-20-000061:notes:136]

[0000106040-21-000011:notes:138]
The following table presents an analysis of the components of the activity against the reserve during the six months ended January 1, 2021:

[0000106040-21-000011:notes:139]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 3, 2020 | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Charges | 22 |  |  | 3 |  |  | 25 |  |
| Cash payments | (28) |  |  | (3) |  |  | (31) |  |
| Accrual balance at January 1, 2021 | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-21-000011:notes:140]
[same as prior period, unchanged from 0000106040-20-000061:notes:139]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-21-000011:notes:141]
Legal Proceedings
Tax

[0000106040-21-000011:notes:142]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 12, Income Tax Expense.

[0000106040-21-000011:notes:143]
Other Matters

[0000106040-21-000011:notes:144]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
