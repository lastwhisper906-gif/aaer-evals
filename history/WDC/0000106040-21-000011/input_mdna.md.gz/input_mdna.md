# WDC MD&A — 0000106040-21-000011


## mdna

[0000106040-21-000011:mdna:1]
[same as prior period, unchanged from 0000106040-20-000061:mdna:1]

[0000106040-21-000011:mdna:2]
[same as prior period, unchanged from 0000106040-20-000061:mdna:2]

[0000106040-21-000011:mdna:3]
[same as prior period, unchanged from 0000106040-20-000061:mdna:3]

[0000106040-21-000011:mdna:4]
[same as prior period, unchanged from 0000106040-20-000061:mdna:4]

[0000106040-21-000011:mdna:5]
[same as prior period, unchanged from 0000106040-20-000061:mdna:5]

[0000106040-21-000011:mdna:6]
[same as prior period, unchanged from 0000106040-20-000061:mdna:6]

[0000106040-21-000011:mdna:7]
[same as prior period, unchanged from 0000106040-20-000061:mdna:7]

[0000106040-21-000011:mdna:8]
[same as prior period, unchanged from 0000106040-20-000061:mdna:8]

[0000106040-21-000011:mdna:9]
Late in the first quarter of fiscal 2021, we announced a decision to reorganize our business by forming two separate product business units: flash-based products and hard disk drive (“HDD”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. Beginning in the second fiscal quarter, we are in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. We are developing new reporting processes to support the new business structure and evaluating the impact of these changes on our discussion and analysis of our financial condition and results of operations in the future.

[0000106040-21-000011:mdna:10]
[same as prior period, unchanged from 0000106040-20-000061:mdna:10]

[0000106040-21-000011:mdna:11]
As a result of the ongoing COVID-19 pandemic, governments and other authorities around the world, including federal, state and local authorities in the United States, have imposed measures intended to reduce its spread, including restrictions on freedom of movement and business operations such as travel bans, border closings, business limitations and closures (subject to exceptions for essential operations and businesses), quarantines and shelter-in-place orders. Although some of these governmental restrictions have since been lifted or scaled back, periodic surges of COVID-19 infections have resulted in the re-imposition of certain restrictions and may lead to other restrictions being re-implemented in response to efforts to reduce the spread of COVID-19. These measures may remain in place for a significant amount of time, and the effects of ongoing vaccination efforts and the emergence of new strains of the virus remain uncertain. In light of these events, we have taken actions to protect the health and safety of our employees while continuing to serve our global customers as an essential business. We have implemented more thorough sanitation practices as outlined by health organizations and instituted social distancing policies at our locations around the world, including working from home, limiting the number of employees attending meetings, reducing the number of people in our sites at any one time, and suspending employee travel. In addition, the responses to COVID-19 taken by others in the supply chain have impacted our operations. As a result, we have incurred

[0000106040-21-000011:mdna:12]
charges of approximately $61 million during the six months ended January 1, 2021, primarily related to higher logistics costs, which were recorded in cost of revenue.

[0000106040-21-000011:mdna:13]
As an essential business, we continue to provide products and solutions that enable the proliferation of data and facilitate the sharing of information remotely, which has become more critical as much of the world is interacting from areas of self-isolation. Generally, demand for our products remains solid. During the six months ended January 1, 2021, we experienced lower sales in some of our capacity enterprise and Client Devices products as customers absorbed purchases made in recent quarters, but we also experienced increased sales in retail as COVID-19 restrictions eased, more brick and mortar businesses resumed operations, the work and learn from home trend increased hard drive demand for desktops and notebooks, and gaming increased. Looking forward, we see positive indications of the progression of 5G ramp and the growth of gaming. We also currently expect retail demand to be solid in the near term and HDD to improve as customers absorb recent purchases and we ramp sales of new products. However, the COVID-19 environment remains dynamic and we cannot predict the duration of the pandemic and how demand may change as it develops.

[0000106040-21-000011:mdna:14]
[same as prior period, unchanged from 0000106040-20-000061:mdna:15]

[0000106040-21-000011:mdna:15]
[same as prior period, unchanged from 0000106040-20-000061:mdna:16]

[0000106040-21-000011:mdna:16]
[same as prior period, unchanged from 0000106040-20-000061:mdna:17]

[0000106040-21-000011:mdna:17]
Since its inception, Flash Ventures’ primary manufacturing site has been located in Yokkaichi, Japan, which currently includes five wafer fabrication facilities. Production levels at the Yokkaichi site were temporarily reduced as a result of an unexpected power outage incident that occurred in the Yokkaichi region on June 15, 2019. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production. The incident resulted in a reduction of our flash wafer availability by approximately 4 exabytes. As a result of this power outage incident, we incurred aggregate charges of $68 million recorded in Cost of revenue in the six months ended January 3, 2020, which primarily consisted of unabsorbed manufacturing overhead costs. During the six months ended January 1, 2021, we recovered $75 million related to this incident from our insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000011:mdna:18]
In May 2019, we entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, we agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of January 1, 2021, remaining committed prepayments totaled $149 million.

[0000106040-21-000011:mdna:19]
[same as prior period, unchanged from 0000106040-20-000061:mdna:20]

[0000106040-21-000011:mdna:20]
[same as prior period, unchanged from 0000106040-20-000061:mdna:21]

[0000106040-21-000011:mdna:21]
Second Quarter and First Half Overview

[0000106040-21-000011:mdna:22]
[same as prior period, unchanged from 0000106040-20-000061:mdna:23]

[0000106040-21-000011:mdna:23]
|  | Three Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 3,943 |  |  | 100.0 | % |  | $ | 4,234 |  |  | 100.0 | % |  | $ | (291) |  |  | (7) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,983 |  |  | 75.7 |  |  | 3,299 |  |  | 77.9 |  |  | (316) |  |  | (10) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 960 |  |  | 24.3 |  |  | 935 |  |  | 22.1 |  |  | 25 |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 535 |  |  | 13.6 |  |  | 578 |  |  | 13.7 |  |  | (43) |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 265 |  |  | 6.7 |  |  | 298 |  |  | 7.0 |  |  | (33) |  |  | (11) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 2 |  |  | 0.1 |  |  | 9 |  |  | 0.2 |  |  | (7) |  |  | (78) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 802 |  |  | 20.3 |  |  | 885 |  |  | 20.9 |  |  | (83) |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 158 |  |  | 4.0 |  |  | 50 |  |  | 1.2 |  |  | 108 |  |  | 216 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | 0.1 |  |  | 8 |  |  | 0.2 |  |  | (6) |  |  | (75) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (81) |  |  | (2.1) |  |  | (105) |  |  | (2.5) |  |  | 24 |  |  | (23) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 6 |  |  | 0.2 |  |  | 7 |  |  | 0.2 |  |  | (1) |  |  | (14) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (73) |  |  | (1.9) |  |  | (90) |  |  | (2.1) |  |  | 17 |  |  | (19) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 85 |  |  | 2.2 |  |  | (40) |  |  | (0.9) |  |  | 125 |  |  | (313) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 23 |  |  | 0.6 |  |  | 99 |  |  | 2.3 |  |  | (76) |  |  | (77) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 62 |  |  | 1.6 |  |  | $ | (139) |  |  | (3.3) |  |  | 201 |  |  | (145) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000011:mdna:24]
[same as prior period, unchanged from 0000106040-20-000061:mdna:25]

[0000106040-21-000011:mdna:25]
[same as prior period, unchanged from 0000106040-20-000061:mdna:33]

[0000106040-21-000011:mdna:26]
|  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 7,865 |  |  | 100.0 | % |  | $ | 8,274 |  |  | 100.0 | % |  | $ | (409) |  |  | (5) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 6,001 |  |  | 76.3 |  |  | 6,581 |  |  | 79.5 |  |  | (580) |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,864 |  |  | 23.7 |  |  | 1,693 |  |  | 20.5 |  |  | 171 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,090 |  |  | 13.9 |  |  | 1,152 |  |  | 13.9 |  |  | (62) |  |  | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 521 |  |  | 6.6 |  |  | 603 |  |  | 7.3 |  |  | (82) |  |  | (14) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 25 |  |  | 0.3 |  |  | 17 |  |  | 0.2 |  |  | 8 |  |  | 47 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 1,636 |  |  | 20.8 |  |  | 1,772 |  |  | 21.4 |  |  | (136) |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 228 |  |  | 2.9 |  |  | (79) |  |  | (1.0) |  |  | 307 |  |  | (389) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 4 |  |  | 0.1 |  |  | 20 |  |  | 0.2 |  |  | (16) |  |  | (80) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (165) |  |  | (2.1) |  |  | (227) |  |  | (2.7) |  |  | 62 |  |  | (27) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net | 15 |  |  | 0.2 |  |  | 9 |  |  | 0.1 |  |  | 6 |  |  | 67 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (146) |  |  | (1.9) |  |  | (198) |  |  | (2.4) |  |  | 52 |  |  | (26) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 82 |  |  | 1.0 |  |  | (277) |  |  | (3.3) |  |  | 359 |  |  | (130) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 80 |  |  | 1.0 |  |  | 138 |  |  | 1.7 |  |  | (58) |  |  | (42) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 2 |  |  | — |  |  | $ | (415) |  |  | (5.0) |  |  | 417 |  |  | (100) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000011:mdna:27]
[same as prior period, unchanged from 0000106040-20-000061:mdna:27]

[0000106040-21-000011:mdna:28]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,909 |  |  | $ | 2,396 |  |  | $ | 3,753 |  |  | $ | 4,804 |  |  |  |
| Flash-based | 2,034 |  |  | 1,838 |  |  | 4,112 |  |  | 3,470 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,131 |  |  | $ | 1,797 |  |  | $ | 4,077 |  |  | $ | 3,413 |  |  |  |
| Data Center Devices & Solutions | 807 |  |  | 1,489 |  |  | 1,936 |  |  | 3,021 |  |  |  |
| Client Solutions | 1,005 |  |  | 948 |  |  | 1,852 |  |  | 1,840 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 945 |  |  | $ | 1,296 |  |  | $ | 2,024 |  |  | $ | 2,609 |  |  |  |
| Europe, Middle East and Africa | 725 |  |  | 811 |  |  | 1,354 |  |  | 1,590 |  |  |  |
| Asia | 2,273 |  |  | 2,127 |  |  | 4,487 |  |  | 4,075 |  |  |  |
| Total Revenue | $ | 3,943 |  |  | $ | 4,234 |  |  | $ | 7,865 |  |  | $ | 8,274 |  |  |  |

[0000106040-21-000011:mdna:29]
[same as prior period, unchanged from 0000106040-20-000061:mdna:29]

[0000106040-21-000011:mdna:30]
Net revenue decreased 7% for the three months ended January 1, 2021 compared to the three months ended January 3, 2020, which reflects an approximate 11 percentage point decline in revenue related to pricing per gigabyte of memory for both HDD and flash products and an approximate 6 percentage point decline in exabyte volume of HDD memory sold, primarily in Data Center Devices and Solutions as discussed further below. These declines were largely offset by higher volumes of flash memory sold.

[0000106040-21-000011:mdna:31]
Client Devices revenue increased 19% year over year. Higher volumes of flash memory contributed 28 percentage points of growth, as work-, school- and game-from-home trends continued to drive demand for our solutions for notebook and desktop applications. Western Digital’s industry leading NVMe-based client SSDs and strong relationships with major PC OEMs drove a record level of exabyte shipments. These increases were slightly offset, in relatively equal portions, by lower average pricing per gigabyte of memory on both HDD and flash products and lower volumes of HDD.

[0000106040-21-000011:mdna:32]
Data Center Devices and Solutions revenue declined 46% year over year due to ongoing cloud digestion, one ongoing qualification delay and China shipment restrictions. Revenue from both capacity enterprise hard drives and enterprise SSDs were down year over year. We believe cloud digestion is abating and are seeing stabilization of OEM demand. Should these demand trends continue, we believe capacity enterprise hard drive revenue bottomed in the second quarter and anticipate a rebound in the third quarter. Within our enterprise SSD product line, we completed the qualification process at a cloud titan for our second-generation product and began shipping to this customer in the third quarter.

[0000106040-21-000011:mdna:33]
Client Solutions revenue increased 6% year over year with approximately 12 percentage points driven by volume growth. The work-, school- and gaming-from-home trends benefited both hard drive and flash-based products. This growth was partially offset by more competitive pricing.

[0000106040-21-000011:mdna:34]
Net revenue decreased 5% for the six months ended January 1, 2021 from the comparable period in the prior year, reflecting an approximate 11 percentage point decline related to pricing per gigabyte of memory for both HDD and flash products and an approximate 8 percentage point decline in HDD memory sold, primarily in Data Center Devices and Solutions. These declines were largely offset by higher volumes of memory, predominantly in flash products. Client Devices revenue increased 19% year over year, with approximately 25 percentage points of growth coming from higher volumes of memory, driven by growth in flash products for the same reasons noted above for the quarter. This increase was partially offset by lower average selling prices per gigabyte of memory in both flash and HDD products. Revenue for Data Center Devices and Solutions declined 36% year over year, which also reflects the drivers noted for the quarter above. Client Solutions revenue was essentially flat year over year, with relatively stable retail demand and pricing in both HDD and flash products.

[0000106040-21-000011:mdna:35]
The changes in net revenue by geography reflect an increase in Asia due to our increased sales of mobility products to manufacturers in the Asia region, and a decrease in the Americas driven by lower sales of capacity enterprise products.

[0000106040-21-000011:mdna:36]
Our top 10 customers accounted for 43% and 41% of our net revenue for the three and six months ended January 1, 2021, respectively, and 44% and 43% for the three and six months ended January 3, 2020, respectively. For the three and six months ended January 1, 2021 and January 3, 2020, no single customer accounted for 10% or more of our net revenue.

[0000106040-21-000011:mdna:37]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and six months ended January 1, 2021 and January 3, 2020, these programs represented 20% and 19% and 17% and 16%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The increase in adjustments year over year reflects the current competitive environment. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-21-000011:mdna:38]
[same as prior period, unchanged from 0000106040-20-000061:mdna:35]

[0000106040-21-000011:mdna:39]
Gross profit increased by $25 million for the three months ended January 1, 2021 from the comparable period in the prior year, which reflects a $48 million decrease in charges in the current year related to amortization expense on acquired intangible assets and the $45 million insurance recovery in the current year related to the power outage incident, partially offset by lower revenues.

[0000106040-21-000011:mdna:40]
Gross margin increased approximately 3 percentage points for the three months ended January 1, 2021 from the comparable period in the prior year, substantially all of which is attributed to the impacts of the lower charges for amortization of acquired intangible assets and the insurance recovery noted above.

[0000106040-21-000011:mdna:41]
Gross profit increased by $171 million for the six months ended January 1, 2021 from the comparable period in the prior year, which reflects the power outage charges of $68 million incurred in the prior year compared to the $75 million partial recovery in the current year, a $67 million decrease in charges in the current year related to amortization expense on acquired intangible assets and reduced manufacturing costs.

[0000106040-21-000011:mdna:42]
Gross margin increased approximately 10 percentage points for the six months ended January 1, 2021 from the comparable period in the prior year, substantially all of which is attributed to the impacts of the charges related to the power outage incident in the prior year, the insurance recovery in the current year and the lower charges for amortization of acquired intangible assets noted above. Over the near term, we expect flash gross margin to benefit from improved pricing and cost reductions while HDD gross margin is expected to be constrained by the pricing environment for 16-terabyte drives, but we expect improved gross margins over the longer term as we ramp production on higher capacity drives.

[0000106040-21-000011:mdna:43]
[same as prior period, unchanged from 0000106040-20-000061:mdna:38]

[0000106040-21-000011:mdna:44]
Research and development (“R&D”) expense decreased $43 million for the three months ended January 1, 2021 from the comparable period in the prior year. The decrease was driven, in comparable amounts, by lower compensation costs, lower travel and entertainment expenses due to the COVID-19 restrictions, and a decline in outside services. R&D expense decreased $62 million for the six months ended January 1, 2021 from the comparable period in the prior year, reflecting the drivers noted above for the quarter, as well as the impact of additional expense in the prior year for the additional week in the prior year.

[0000106040-21-000011:mdna:45]
Selling, general and administrative (“SG&A”) expense decreased $33 million for the three months ended January 1, 2021 from the comparable period in the prior year. The decrease was driven, in comparable amounts, by lower compensation costs, lower travel and entertainment as a result of COVID-19 restrictions and lower consulting and marketing expenses due to event cancellations. SG&A expense decreased $82 million for the six months ended January 1, 2021 from the comparable period in the prior year. Similar to the quarter, the decline was driven, in comparable amounts, by lower compensation costs, lower travel and entertainment as a result of COVID-19 restrictions and lower consulting and marketing expenses due to event cancellations, as well as approximately $10 million of additional expense in the prior year related to the additional week.

[0000106040-21-000011:mdna:46]
[same as prior period, unchanged from 0000106040-20-000061:mdna:41]

[0000106040-21-000011:mdna:47]
[same as prior period, unchanged from 0000106040-20-000061:mdna:42]

[0000106040-21-000011:mdna:48]
The decreases in total interest and other expense, net for the three and six months ended January 1, 2021 reflect lower interest expense resulting from lower index rates and the pay-down of principal on our debt.

[0000106040-21-000011:mdna:49]
[same as prior period, unchanged from 0000106040-20-000061:mdna:45]

[0000106040-21-000011:mdna:50]
[same as prior period, unchanged from 0000106040-20-000061:mdna:46]

[0000106040-21-000011:mdna:51]
[same as prior period, unchanged from 0000106040-20-000061:mdna:47]

[0000106040-21-000011:mdna:52]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |  |
|  | ($ in millions) |  |
| Income (loss) before taxes | $ | 85 |  |  | $ | (40) |  |  | $ | 82 |  |  | $ | (277) |  |  |
| Income tax expense | 23 |  |  | 99 |  |  | 80 |  |  | 138 |  |  |
| Effective tax rate | 27 | % |  | (248) | % |  | 98 | % |  | (50) | % |  |

[0000106040-21-000011:mdna:53]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the three and six months ended January 1, 2021 includes the discrete effects of favorable adjustments proposed by tax authorities of $8 million. The effective tax rate for the six months ended January 1, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $12 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes paid by us.

[0000106040-21-000011:mdna:54]
The primary driver of the difference between the effective tax rate for the three and six months ended January 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-21-000011:mdna:55]
[same as prior period, unchanged from 0000106040-20-000061:mdna:51]

[0000106040-21-000011:mdna:56]
[same as prior period, unchanged from 0000106040-20-000061:mdna:52]

[0000106040-21-000011:mdna:57]
[same as prior period, unchanged from 0000106040-20-000061:mdna:53]

[0000106040-21-000011:mdna:58]
[same as prior period, unchanged from 0000106040-20-000061:mdna:54]

[0000106040-21-000011:mdna:59]
|  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 788 |  |  | $ | 510 |  |  |  |
| Investing activities | (436) |  |  | 160 |  |  |  |
| Financing activities | (450) |  |  | (985) |  |  |  |
| Effect of exchange rate changes on cash | 6 |  |  | (3) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (92) |  |  | $ | (318) |  |  |  |

[0000106040-21-000011:mdna:60]
42

[0000106040-21-000011:mdna:61]
[same as prior period, unchanged from 0000106040-20-000061:mdna:56]

[0000106040-21-000011:mdna:62]
During fiscal 2021, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $3.1 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.0 billion during fiscal 2021. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-21-000011:mdna:63]
[same as prior period, unchanged from 0000106040-20-000061:mdna:58]

[0000106040-21-000011:mdna:64]
A total of $1.91 billion and $2.28 billion of our Cash and cash equivalents was held outside of the U.S. as of January 1, 2021 and January 3, 2020, respectively. As a result of the change in our permanent reinvestment assertion, there are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-21-000011:mdna:65]
[same as prior period, unchanged from 0000106040-20-000061:mdna:60]

[0000106040-21-000011:mdna:66]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $78 million for the six months ended January 1, 2021, as compared to $20 million of net cash used for changes in operating assets and liabilities for the six months ended January 3, 2020. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-21-000011:mdna:67]
|  | Six Months Ended |  |  |
|  | January 1,2021 |  | January 3,2020 |  |  |  |  |
|  | (in days) |
| Days sales outstanding | 42 |  |  | 38 |  |  |  |  |  |
| Days in inventory | 109 |  |  | 86 |  |  |  |  |  |
| Days payables outstanding | (71) |  |  | (58) |  |  |  |  |  |
| Cash conversion cycle | 80 |  |  | 66 |  |  |  |  |  |

[0000106040-21-000011:mdna:68]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-21-000011:mdna:69]
For the three months ended January 1, 2021, DSO increased by 4 days over the prior year, primarily reflecting the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO increased by 23 days over the prior year, primarily reflecting higher stocking levels of HDD inventory and delays in new product qualifications. With supply chains experiencing disruptions as a result of COVID-19, we are taking actions to ensure that we have the components we need to build products and are stocking higher levels of inventory so that we can ship by ocean and reduce higher cost air freight. DPO increased by 13 days over the prior year, primarily reflecting resumptions of flash production volumes as well as routine variations in the timing of purchases and payments during the period.

[0000106040-21-000011:mdna:70]
[same as prior period, unchanged from 0000106040-20-000061:mdna:65]

[0000106040-21-000011:mdna:71]
Net cash used in investing activities for the six months ended January 1, 2021 primarily consisted of $576 million in capital expenditures, partially offset by a $94 million net decrease in notes receivable issuances to Flash Ventures. Net cash provided by investing activities for the six months ended January 3, 2020 primarily consisted of a $466 million net decrease in notes receivable issuances to Flash Ventures to fund its capital expansion, partially offset by $305 million of capital expenditures.

[0000106040-21-000011:mdna:72]
[same as prior period, unchanged from 0000106040-20-000061:mdna:67]

[0000106040-21-000011:mdna:73]
[same as prior period, unchanged from 0000106040-20-000061:mdna:68]

[0000106040-21-000011:mdna:74]
During the six months ended January 1, 2021, net cash used in financing activities primarily consisted of $461 million for repayment of debt, which included a $300 million voluntary prepayment on our Term Loan B-4. Net cash used in financing activities for the six months ended January 3, 2020 primarily consisted of $707 million for the repayment of our debt and $296 million to pay dividends on our common stock.

[0000106040-21-000011:mdna:75]
[same as prior period, unchanged from 0000106040-20-000061:mdna:70]

[0000106040-21-000011:mdna:76]
[same as prior period, unchanged from 0000106040-20-000061:mdna:71]

[0000106040-21-000011:mdna:77]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000011:mdna:78]
45

[0000106040-21-000011:mdna:79]
[same as prior period, unchanged from 0000106040-20-000061:mdna:74]

[0000106040-21-000011:mdna:80]
[same as prior period, unchanged from 0000106040-20-000061:mdna:75]

[0000106040-21-000011:mdna:81]
The following is a summary of our known contractual cash obligations and commercial commitments as of January 1, 2021:

[0000106040-21-000011:mdna:82]
|  | Total |  | Remaining six months of 2021 |  | 2022-2023 |  | 2024-2025 |  | Beyond 2025 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 9,250 |  |  | $ | 126 |  |  | $ | 5,724 |  |  | $ | 1,100 |  |  | $ | 2,300 |  |
| Interest on debt | 992 |  |  | 141 |  |  | 507 |  |  | 235 |  |  | 109 |  |
| Flash Ventures related commitments(2) | 6,189 |  |  | 1,839 |  |  | 2,950 |  |  | 1,166 |  |  | 234 |  |
| Operating leases | 309 |  |  | 25 |  |  | 73 |  |  | 64 |  |  | 147 |  |
| Purchase obligations and other commitments | 4,513 |  |  | 2,426 |  |  | 1,356 |  |  | 541 |  |  | 190 |  |
| Mandatory Deemed Repatriation Tax | 925 |  |  | — |  |  | 210 |  |  | 417 |  |  | 298 |  |
| Total | $ | 22,178 |  |  | $ | 4,557 |  |  | $ | 10,820 |  |  | $ | 3,523 |  |  | $ | 3,278 |  |

[0000106040-21-000011:mdna:83]
[same as prior period, unchanged from 0000106040-20-000061:mdna:78]

[0000106040-21-000011:mdna:84]
[same as prior period, unchanged from 0000106040-20-000061:mdna:79]

[0000106040-21-000011:mdna:85]
[same as prior period, unchanged from 0000106040-20-000061:mdna:80]

[0000106040-21-000011:mdna:86]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020. The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of January 1, 2021, we were in compliance with these financial covenants.

[0000106040-21-000011:mdna:87]
[same as prior period, unchanged from 0000106040-20-000061:mdna:82]

[0000106040-21-000011:mdna:88]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of January 1, 2021, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-21-000011:mdna:89]
[same as prior period, unchanged from 0000106040-20-000061:mdna:84]

[0000106040-21-000011:mdna:90]
[same as prior period, unchanged from 0000106040-20-000061:mdna:85]

[0000106040-21-000011:mdna:91]
[same as prior period, unchanged from 0000106040-20-000061:mdna:86]

[0000106040-21-000011:mdna:92]
[same as prior period, unchanged from 0000106040-20-000061:mdna:87]

[0000106040-21-000011:mdna:93]
|  |  | January 1,2021 |
| 2022 |  | $ | 106 |  |
| 2023 |  | 104 |  |
| 2024 |  | 179 |  |
| 2025 |  | 238 |  |
| 2026 |  | 298 |  |
| Total |  | $ | 925 |  |

[0000106040-21-000011:mdna:94]
[same as prior period, unchanged from 0000106040-20-000061:mdna:89]

[0000106040-21-000011:mdna:95]
[same as prior period, unchanged from 0000106040-20-000061:mdna:90]

[0000106040-21-000011:mdna:96]
As of January 1, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $715 million. Accrued interest and penalties related to unrecognized tax benefits as of January 1, 2021 was approximately $146 million. Of these amounts, approximately $724 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-21-000011:mdna:97]
[same as prior period, unchanged from 0000106040-20-000061:mdna:92]

[0000106040-21-000011:mdna:98]
We have generally held a balance of fixed and variable rate debt. At January 1, 2021, we had $5.85 billion of variable rate debt, comprising 63% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $3.85 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual interest expense by $39 million.

[0000106040-21-000011:mdna:99]
[same as prior period, unchanged from 0000106040-20-000061:mdna:94]

[0000106040-21-000011:mdna:100]
[same as prior period, unchanged from 0000106040-20-000061:mdna:95]

[0000106040-21-000011:mdna:101]
[same as prior period, unchanged from 0000106040-20-000061:mdna:96]

[0000106040-21-000011:mdna:102]
[same as prior period, unchanged from 0000106040-20-000061:mdna:97]

[0000106040-21-000011:mdna:103]
[same as prior period, unchanged from 0000106040-20-000061:mdna:98]

[0000106040-21-000011:mdna:104]
47

[0000106040-21-000011:mdna:105]
[same as prior period, unchanged from 0000106040-20-000061:mdna:99]

[0000106040-21-000011:mdna:106]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the six months ended January 1, 2021 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of January 1, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-21-000011:mdna:107]
[same as prior period, unchanged from 0000106040-20-000061:mdna:101]

[0000106040-21-000011:mdna:108]
[same as prior period, unchanged from 0000106040-20-000061:mdna:102]

[0000106040-21-000011:mdna:109]
[same as prior period, unchanged from 0000106040-20-000061:mdna:103]

[0000106040-21-000011:mdna:110]
[same as prior period, unchanged from 0000106040-20-000061:mdna:104]

[0000106040-21-000011:mdna:111]
[same as prior period, unchanged from 0000106040-20-000061:mdna:105]

[0000106040-21-000011:mdna:112]
[same as prior period, unchanged from 0000106040-20-000061:mdna:106]

[0000106040-21-000011:mdna:113]
[same as prior period, unchanged from 0000106040-20-000061:mdna:107]
