# WDC notes — 0000106040-16-000019


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-16-000019:notes:1]
[same as prior period, unchanged from 0000106040-15-000014:notes:1]

[0000106040-16-000019:notes:2]
|  | January 1, 2016 |
|  | Cost Basis |  | Unrealized Losses |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 306 |  |  | $ | (1 | ) |  | $ | 305 |  |
| U.S. Government agency securities | 116 |  |  | — |  |  | 116 |  |
| Commercial paper | 50 |  |  | — |  |  | 50 |  |
| Certificates of deposit | 260 |  |  | — |  |  | 260 |  |
| Total | $ | 732 |  |  | $ | (1 | ) |  | $ | 731 |  |

[0000106040-16-000019:notes:3]
|  | July 3, 2015 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 287 |  |  | $ | — |  |  | $ | 287 |  |
| U.S. Government agency securities | 95 |  |  | — |  |  | 95 |  |
| Commercial paper | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-16-000019:notes:4]
[same as prior period, unchanged from 0000106040-15-000014:notes:4]

[0000106040-16-000019:notes:5]
Planned SanDisk Merger

[0000106040-16-000019:notes:6]
On October 21, 2015, the Company entered into the Merger Agreement with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of the Company will merge with and into SanDisk, with SanDisk surviving as a wholly owned subsidiary of the Company. The merger is primarily intended to deepen the Company's expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000019:notes:7]
The Merger Agreement values SanDisk’s outstanding common stock at a value of $86.50 per share, or a total equity value of approximately $18.9 billion, based on the volume weighted average price of the Company’s common stock for the five trading days ending on October 20, 2015. If the Unis Investment closes prior to the merger, the Company will pay $85.10 per share in cash and issue 0.0176 shares of its common stock per share of SanDisk’s common stock; and if the Unis Investment has not occurred or has been terminated, the Company will pay $67.50 per share in cash and issue 0.2387 shares of its common stock per share of SanDisk’s common stock. The above allocation between cash and shares of the Company’s common stock is subject to reallocation, at the Company’s election, if the amount of cash that SanDisk has available at the closing of the merger falls below certain thresholds.

[0000106040-16-000019:notes:8]
The merger consideration will be financed by a mix of cash, new debt financing and issuance of the Company’s common stock. In connection with the merger, the Company expects to enter into new debt facilities totaling $18.1 billion. The Company has received commitments for a $1.0 billion revolving credit facility, $3.0 billion in amortizing term loans, $6.0 billion in other term loans and $8.1 billion in secured and unsecured bridge facilities.  The Company expects to issue approximately $5.1 billion in secured and unsecured notes in lieu of drawing the bridge facilities at close, with the balance of the bridge facilities to be repaid with available cash. The proceeds from the new debt facilities are expected to be used to pay part of the purchase price, refinance existing debt of both the Company and SanDisk and pay transaction related fees and expenses.

[0000106040-16-000019:notes:9]
Consummation of the merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and, if the Unis Investment has not occurred or has been terminated, approval by the Company’s shareholders; (ii) the expiration or early termination of the waiting period applicable to the consummation of the merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended (the "HSR Act"), which expired on January 15, 2016, and the receipt of regulatory clearance under the foreign antitrust laws of the People's Republic of China, the European Union, Japan, South Africa, South Korea, Taiwan and Turkey; and (iii) if the Unis Investment has not been terminated and is a “covered transaction” for CFIUS purposes, or if CFIUS otherwise requests or requires a filing with respect to the merger, the approval of CFIUS. Clearance was obtained in Japan on January 22, 2016, in Taiwan on February 1, 2016 and in the European Union on February 4, 2016. Clearance was obtained in Singapore on January 19, 2016. In certain circumstances, a termination fee of up to $1.06 billion may be payable by the Company or a termination fee of up to $553.3 million may be payable by SanDisk, upon termination of the transaction as more fully described in the Merger Agreement.

[0000106040-16-000019:notes:10]
Acquisition of Amplidata NV ("Amplidata")

[0000106040-16-000019:notes:11]
On March 9, 2015, the Company acquired Amplidata, a developer of object storage software for public and private cloud data centers. As a result of the acquisition, Amplidata was fully integrated and became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition furthers the Company's strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers.

[0000106040-16-000019:notes:12]
[same as prior period, unchanged from 0000106040-15-000014:notes:8]

[0000106040-16-000019:notes:13]
[same as prior period, unchanged from 0000106040-15-000014:notes:9]

[0000106040-16-000019:notes:14]
[same as prior period, unchanged from 0000106040-15-000014:notes:10]

[0000106040-16-000019:notes:15]
[same as prior period, unchanged from 0000106040-15-000014:notes:11]

[0000106040-16-000019:notes:16]
The $215 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create hard disk drive storage solutions leveraging the core software acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Amplidata was immaterial to the Company’s condensed consolidated financial statements for the three and six months ended January 1, 2016.


## us-gaap:DebtDisclosureTextBlock

[0000106040-16-000019:notes:17]
4. Debt

[0000106040-16-000019:notes:18]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the "Credit Agreement"), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.

[0000106040-16-000019:notes:19]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of January 1, 2016, the revolving credit facility had a variable interest rate of 1.7% and an outstanding balance of $255 million. The revolving credit facility was classified within current liabilities as of January 1, 2016 as the Company intended to repay the borrowings within the next 12 months. The Company repaid the $255 million outstanding balance under the revolving credit facility on January 15, 2016. As of January 1, 2016, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-16-000019:notes:20]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-16-000019:notes:21]
[same as prior period, unchanged from 0000106040-15-000014:notes:17]

[0000106040-16-000019:notes:22]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. As of January 1, 2016, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-16-000019:notes:23]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and six months ended January 1, 2016 and January 2, 2015.

[0000106040-16-000019:notes:24]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges were determined to be effective as of January 1, 2016 and July 3, 2015. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and six months ended January 1, 2016 and January 2, 2015.

[0000106040-16-000019:notes:25]
As of January 1, 2016, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next twelve months was $12 million. In addition, as of January 1, 2016, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $992 million and $1.9 billion, and closed $1.1 billion and $2.1 billion, in foreign exchange contracts during the three and six months ended January 1, 2016, respectively. The Company opened $1.0 billion and $2.0 billion, and closed $1.1 billion and $2.1 billion, in foreign exchange contracts during the three and six months ended January 2, 2015, respectively. The fair value and balance sheet location of the Company's foreign exchange contracts as of January 1, 2016 and July 3, 2015 were as follows (in millions):

[0000106040-16-000019:notes:26]
|  | Asset Derivatives | Liability Derivatives |
|  | January 1, 2016 | July 3, 2015 | January 1, 2016 | July 3, 2015 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | 3 |  | Other current assets | $ | — |  | Accrued expenses | $ | 22 |  | Accrued expenses | $ | 31 |  |

[0000106040-16-000019:notes:27]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of January 1, 2016 (in millions):

[0000106040-16-000019:notes:28]
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 5 |  |  | $ | (2 | ) |  | $ | 3 |  |
| Financial liabilities | (24 | ) |  | 2 |  |  | (22 | ) |
| Total derivative instruments | $ | (19 | ) |  | $ | — |  |  | $ | (19 | ) |

[0000106040-16-000019:notes:29]
[same as prior period, unchanged from 0000106040-15-000014:notes:25]

[0000106040-16-000019:notes:30]
The impact of foreign exchange contracts on the condensed consolidated financial statements was as follows (in millions):

[0000106040-16-000019:notes:31]
|  | Amount of Gain (Loss) Recognized inAccumulated OCI on Derivatives | Location ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome | Amount of Loss ReclassifiedFrom Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | Three Months Ended |  | Six Months Ended |  | Three Months Ended |  | Six Months Ended | Three Months Ended |  | Six Months Ended |  | Three Months Ended |  | Six Months Ended |
| January 1, 2016 |  | January 2, 2015 | January 1, 2016 |  | January 2, 2015 |
| Foreign exchange contracts | $ | 13 |  |  | $ | (40 | ) |  | $ | (35 | ) |  | $ | (57 | ) | Cost of revenue | $ | 25 |  |  | $ | 53 |  |  | $ | 17 |  |  | $ | 13 |  |

[0000106040-16-000019:notes:32]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three and six months ended January 1, 2016 and January 2, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000106040-16-000019:notes:33]
[same as prior period, unchanged from 0000106040-15-000014:notes:29]

[0000106040-16-000019:notes:34]
[same as prior period, unchanged from 0000106040-15-000014:notes:30]

[0000106040-16-000019:notes:35]
The following table presents the Company's stock-based compensation and related tax benefit for the three and six months ended January 1, 2016 and January 2, 2015 (in millions):

[0000106040-16-000019:notes:36]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |
|  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |
| Options and ESPP | $ | 13 |  |  | $ | 4 |  |  | $ | 18 |  |  | $ | 7 |  |  | $ | 32 |  |  | $ | 8 |  |  | $ | 37 |  |  | $ | 12 |  |
| RSUs | 24 |  |  | 6 |  |  | 23 |  |  | 6 |  |  | 47 |  |  | 12 |  |  | 43 |  |  | 11 |  |
| Total | $ | 37 |  |  | $ | 10 |  |  | $ | 41 |  |  | $ | 13 |  |  | $ | 79 |  |  | $ | 20 |  |  | $ | 80 |  |  | $ | 23 |  |

[0000106040-16-000019:notes:37]
As of January 1, 2016, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $118 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.4 years.

[0000106040-16-000019:notes:38]
For purposes of this footnote, references to RSUs include performance stock unit awards. As of January 1, 2016, the aggregate unamortized fair value of all unvested RSUs was $158 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.8 years.

[0000106040-16-000019:notes:39]
[same as prior period, unchanged from 0000106040-15-000014:notes:35]

[0000106040-16-000019:notes:40]
[same as prior period, unchanged from 0000106040-15-000014:notes:36]

[0000106040-16-000019:notes:41]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| Options outstanding at July 3, 2015 | 6.8 |  |  | $ | 50.00 |  |  |  |  |  |
| Granted | 1.6 |  |  | 84.41 |  |  |  |  |  |
| Exercised | (0.5 | ) |  | 29.49 |  |  |  |  |  |
| Forfeited or expired | (0.1 | ) |  | 49.08 |  |  |  |  |  |
| Options outstanding at October 2, 2015 | 7.8 |  |  | 58.58 |  |  |  |  |  |
| Exercised | (0.2 | ) |  | 23.25 |  |  |  |  |  |
| Forfeited or expired | (0.1 | ) |  | 68.75 |  |  |  |  |  |
| Options outstanding at January 1, 2016 | 7.5 |  |  | $ | 59.54 |  |  | 4.5 |  | $ | 107 |  |
| Exercisable at January 1, 2016 | 3.8 |  |  | $ | 43.58 |  |  | 3.3 |  | $ | 88 |  |
| Vested and expected to vest after January 1, 2016 | 7.4 |  |  | $ | 58.92 |  |  | 4.4 |  | $ | 107 |  |

[0000106040-16-000019:notes:42]
Options granted during the three and six months ended January 1, 2016 had a weighted average fair value per share of $17.74 and $22.87, respectively. As of January 1, 2016, the Company had options outstanding to purchase an aggregate of 3.7 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $107 million at that date. During the three and six months ended January 1, 2016, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $9 million and $36 million, respectively, determined as of the date of exercise, as compared to $76 million and $163 million in the respective prior-year periods.

[0000106040-16-000019:notes:43]
[same as prior period, unchanged from 0000106040-15-000014:notes:39]

[0000106040-16-000019:notes:44]
[same as prior period, unchanged from 0000106040-15-000014:notes:40]

[0000106040-16-000019:notes:45]
|  | Number ofShares |  | Weighted AverageGrant-DateFair Value |
| RSUs outstanding at July 3, 2015 | 3.0 |  |  | $ | 73.80 |  |
| Granted | 1.2 |  |  | 84.39 |  |
| Vested | (1.5 | ) |  | 62.14 |  |
| Forfeited | (0.1 | ) |  | 81.55 |  |
| RSUs outstanding at October 2, 2015 | 2.6 |  |  | 84.43 |  |
| Granted | 0.1 |  |  | 68.31 |  |
| Vested | (0.1 | ) |  | 61.61 |  |
| Forfeited | (0.1 | ) |  | 85.31 |  |
| RSUs outstanding at January 1, 2016 | 2.5 |  |  | 84.71 |  |
| Expected to vest after January 1, 2016 | 2.4 |  |  | $ | 84.57 |  |

[0000106040-16-000019:notes:46]
RSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The fair value of the shares underlying the RSU awards at the date of grant or assumption was $10 million and $109 million for awards granted in the three and six months ended January 1, 2016. These amounts are being recognized to expense over the corresponding vesting periods.

[0000106040-16-000019:notes:47]
[same as prior period, unchanged from 0000106040-15-000014:notes:43]

[0000106040-16-000019:notes:48]
During the three and six months ended January 1, 2016, the Company recognized a $10 million and $11 million benefit, respectively, related to adjustments to fair market value of stock appreciation rights ("SARs"), as compared to $8 million and $12 million of expense in the respective prior-year periods. The tax expense realized as a result of the aforementioned SARs benefit was $1 million and $1 million during the three and six months ended January 1, 2016, as compared to $2 million and $3 million of tax benefits during the three and six months ended January 2, 2015, respectively. The Company's SARs will be settled in cash upon exercise. The Company had a total liability of $29 million and $41 million related to SARs included in accrued expenses in the condensed consolidated balance sheet as of January 1, 2016 and July 3, 2015, respectively. As of January 1, 2016, all SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. As of January 1, 2016, 0.5 million SARs were outstanding with a weighted average exercise price of $7.86. There were no SARs granted during the three and six months ended January 1, 2016.

[0000106040-16-000019:notes:49]
[same as prior period, unchanged from 0000106040-15-000014:notes:45]

[0000106040-16-000019:notes:50]
The Company's Board of Directors previously authorized $5.0 billion for the repurchase of the Company's common stock and approved the extension of its stock repurchase program to February 3, 2020. Effective October 21, 2015, in connection with the Company's planned SanDisk merger, the stock repurchase program was suspended. The Company did not repurchase any shares during the three months ended January 1, 2016. The Company repurchased 0.7 million shares for a total cost of $60 million during the six months ended January 1, 2016. The remaining amount available to be purchased under the Company’s stock repurchase program as of January 1, 2016 was $2.1 billion.

[0000106040-16-000019:notes:51]
[same as prior period, unchanged from 0000106040-15-000014:notes:47]

[0000106040-16-000019:notes:52]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In the three months ended January 1, 2016, the Company declared a cash dividend of $0.50 per share to shareholders of record as of January 1, 2016, totaling $116 million, which was paid on January 15, 2016. In addition, in the three months ended October 2, 2015, the Company declared a cash dividend of $0.50 per share to shareholders of record as of October 2, 2015, totaling $116 million, which was paid on October 15, 2015. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.

[0000106040-16-000019:notes:53]
Investment by Unis

[0000106040-16-000019:notes:54]
On September 30, 2015, the Company announced that it had entered into an agreement with Unis and Unis Union Information System Ltd., a subsidiary of Unis ("Investor"), pursuant to which Investor will make a $3.8 billion equity investment in the Company (the "Unis Investment"). Under the terms of the agreement for the Unis Investment, Investor has agreed to purchase 40,814,802 shares of newly issued common stock of the Company at a price of $92.50 per share and has agreed to a five-year position standstill, voting restrictions, and a five-year lock-up on its shares, with a limited number becoming available for transfer each year. Following the closing of the investment, Unis will have the right to nominate one representative for election to the Company's Board of Directors, so long as Unis holds more than 10% of the issued and outstanding shares of the Company's common stock. The performance of Investor’s obligations pursuant to the agreement, including payment of the purchase price for the shares, is guaranteed by Unis. The closing of the Unis Investment is subject to clearance by the U.S. Committee on Foreign Investment in the United States ("CFIUS"), the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, approval of the transaction by shareholders of Unis and other customary closing conditions. In November 2015, the Company and Unis withdrew from the CFIUS clearance process and refiled the notice with CFIUS in January 2016. The Company expects to receive a determination from CFIUS in February 2016. Although approval from Unis shareholders and approval from some of the Chinese regulatory authorities have been received, the Company cannot provide assurance that CFIUS clearance will be received or the other conditions to the completion of the Unis Investment will be satisfied in a timely manner or at all.


## us-gaap:EarningsPerShareTextBlock

[0000106040-16-000019:notes:55]
[same as prior period, unchanged from 0000106040-15-000014:notes:51]

[0000106040-16-000019:notes:56]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and pursuant to awards of restricted stock units (“RSUs”).

[0000106040-16-000019:notes:57]
[same as prior period, unchanged from 0000106040-15-000014:notes:53]

[0000106040-16-000019:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |
| Net income | $ | 251 |  |  | $ | 438 |  |  | $ | 534 |  |  | $ | 861 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 232 |  |  | 233 |  |  | 231 |  |  | 233 |  |
| Employee stock options and other | 2 |  |  | 5 |  |  | 3 |  |  | 6 |  |
| Diluted | 234 |  |  | 238 |  |  | 234 |  |  | 239 |  |
| Income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.08 |  |  | $ | 1.88 |  |  | $ | 2.31 |  |  | $ | 3.70 |  |
| Diluted | $ | 1.07 |  |  | $ | 1.84 |  |  | $ | 2.28 |  |  | $ | 3.60 |  |
| Anti-dilutive potential common shares excluded* | 6 |  |  | 1 |  |  | 4 |  |  | 2 |  |

[0000106040-16-000019:notes:59]
[same as prior period, unchanged from 0000106040-15-000014:notes:55]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-16-000019:notes:60]
[same as prior period, unchanged from 0000106040-15-000014:notes:56]

[0000106040-16-000019:notes:61]
[same as prior period, unchanged from 0000106040-15-000014:notes:57]

[0000106040-16-000019:notes:62]
[same as prior period, unchanged from 0000106040-15-000014:notes:58]

[0000106040-16-000019:notes:63]
[same as prior period, unchanged from 0000106040-15-000014:notes:59]

[0000106040-16-000019:notes:64]
[same as prior period, unchanged from 0000106040-15-000014:notes:60]

[0000106040-16-000019:notes:65]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of January 1, 2016 and July 3, 2015, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values (in millions):

[0000106040-16-000019:notes:66]
|  | Fair Value Measurements at |  |  |
|  | January 1, 2016 |  |  |
|  | Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 392 |  |  | $ | — |  |  | $ | — |  |  | $ | 392 |  |
| Total cash equivalents | 392 |  |  | — |  |  | — |  |  | 392 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 121 |  |  | — |  |  | 121 |  |
| U.S. Government agency securities | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Commercial paper | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Certificates of deposit | — |  |  | 260 |  |  | — |  |  | 260 |  |
| Total short-term investments | — |  |  | 497 |  |  | — |  |  | 497 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 184 |  |  | — |  |  | 184 |  |
| U.S. Government agency securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Total long-term investments | — |  |  | 234 |  |  | — |  |  | 234 |  |
| Foreign exchange contracts | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets at fair value | $ | 392 |  |  | $ | 734 |  |  | $ | — |  |  | $ | 1,126 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |

[0000106040-16-000019:notes:67]
[same as prior period, unchanged from 0000106040-15-000014:notes:63]

[0000106040-16-000019:notes:68]
[same as prior period, unchanged from 0000106040-15-000014:notes:64]

[0000106040-16-000019:notes:69]
[same as prior period, unchanged from 0000106040-15-000014:notes:65]

[0000106040-16-000019:notes:70]
[same as prior period, unchanged from 0000106040-15-000014:notes:66]

[0000106040-16-000019:notes:71]
[same as prior period, unchanged from 0000106040-15-000014:notes:67]

[0000106040-16-000019:notes:72]
[same as prior period, unchanged from 0000106040-15-000014:notes:68]

[0000106040-16-000019:notes:73]
[same as prior period, unchanged from 0000106040-15-000014:notes:69]

[0000106040-16-000019:notes:74]
In the three and six months ended January 1, 2016, there were no transfers between levels. The carrying amounts of cash, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The carrying amount of debt approximates fair value because of its variable interest rate.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-16-000019:notes:75]
[same as prior period, unchanged from 0000106040-15-000014:notes:71]

[0000106040-16-000019:notes:76]
The Company had an income tax benefit of $7 million and income tax expense of $24 million in the three and six months ended January 1, 2016, respectively. The Company's income tax expense for the three and six months ended January 2, 2015 was $20 million and $57 million, respectively. The Company's tax provision for both the three and six months ended January 1, 2016 reflects a tax benefit of $30 million for the retroactive extension of the U.S. Federal research and development tax credit that was permanently signed into law on December 19, 2015 and a tax benefit of $34 million from restructuring activities. The remaining differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-16-000019:notes:77]
In the three and six months ended January 1, 2016, the Company recorded a net increase of $15 million and $25 million, respectively, in its liability for unrecognized tax benefits. As of January 1, 2016, the Company's liability for unrecognized tax benefits was approximately $375 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three and six months ended January 1, 2016.

[0000106040-16-000019:notes:78]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company's federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company has received Revenue Agent Reports (“RARs”) from the IRS that seek to increase the Company's U.S. taxable income which would result in additional federal tax expense totaling approximately $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012. During the six months ended January 1, 2016, the IRS completed the examination of the fiscal period ended September 5, 2007 of Komag, Incorporated, which the Company acquired on September 5, 2007, with no material adjustments.

[0000106040-16-000019:notes:79]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of January 1, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000106040-16-000019:notes:80]
The fair value of the Company’s investments classified as available-for-sale securities at January 1, 2016, by remaining contractual maturity, were as follows (in millions):

[0000106040-16-000019:notes:81]
|  | Cost Basis |  | Fair Value |
| Due in less than one year (short-term investments): | $ | 497 |  |  | $ | 497 |  |
| Due in one to five years (included in other non-current assets): | 235 |  |  | 234 |  |
| Total | $ | 732 |  |  | $ | 731 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-16-000019:notes:82]
5. Legal Proceedings

[0000106040-16-000019:notes:83]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows.

[0000106040-16-000019:notes:84]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-16-000019:notes:85]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company's acquisition of HGST on March 8, 2012 (the “HGST Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-16-000019:notes:86]
Intellectual Property Litigation

[0000106040-16-000019:notes:87]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-16-000019:notes:88]
Seagate Matter

[0000106040-16-000019:notes:89]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the final arbitration award and interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0000106040-16-000019:notes:90]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company has no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. The Company and Seagate have signed and filed with the court a stipulation of dismissal with prejudice resolving this matter.

[0000106040-16-000019:notes:91]
SanDisk Matters

[0000106040-16-000019:notes:92]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk Corporation (“SanDisk”) on October 21, 2015 (the “Merger Agreement”).  The complaints allege, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also allege that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs seek injunctive relief to prevent the merger from closing.  The plaintiffs also seek, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  The Company intends to defend itself vigorously in this matter.

[0000106040-16-000019:notes:93]
Other Matters

[0000106040-16-000019:notes:94]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to the ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.

[0000106040-16-000019:notes:95]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. WD intends to defend itself vigorously in this matter.

[0000106040-16-000019:notes:96]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows.  It is reasonably possible that the Company may incur losses totaling up to $109 million, including the amounts accrued.

[0000106040-16-000019:notes:97]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company's expectations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-16-000019:notes:98]
13. Recent Accounting Pronouncements

[0000106040-16-000019:notes:99]
Recently Adopted

[0000106040-16-000019:notes:100]
In November 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-17, "Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes" ("ASU 2015-17"), which requires that deferred tax liabilities and assets for each tax-paying jurisdiction within each tax-paying component to be classified as noncurrent in a classified statement of financial position. The Company early adopted ASU 2015-17 during the second quarter of fiscal 2016 on a prospective basis, which resulted in the reclassification of approximately $165 million of net deferred tax assets as of January 1, 2016 from current assets to noncurrent assets. Since the Company adopted this standard on a prospective basis, no adjustments were made to prior-period balance sheets.

[0000106040-16-000019:notes:101]
Recently Issued

[0000106040-16-000019:notes:102]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities" ("ASU 2016-01"). The new standard requires equity investments to be measured at fair value with changes in fair value recognized in net income, simplifies the impairment assessment of equity investments without readily determinable fair values, eliminates the requirement to disclose the methods and significant assumptions used to estimate fair value, requires use of the exit price notion when measuring fair value, requires separate presentation in certain financial statements, and requires an evaluation of the need for a valuation allowance on a deferred tax asset related to available-for-sale securities. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019. The Company is currently evaluating the impact ASU 2016-01 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000019:notes:103]
In September 2015, the FASB issued ASU No. 2015-16, "Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments" ("ASU 2015-16"), which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Acquirers must recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. The new standard is effective for fiscal years beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. Earlier adoption is permitted for any interim and annual financial statements that have not yet been issued. The Company is currently evaluating the impact ASU 2015-16 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000019:notes:104]
In April 2015, the FASB issued ASU 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs" ("ASU 2015-03"). The new standard requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The Company is currently evaluating the impact ASU 2015-03 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000019:notes:105]
In February 2015, the FASB issued ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" ("ASU 2015-02"). The new standard eliminates the presumption that a general partner should consolidate a limited partnership, requires that a reporting entity determine whether it has a variable interest in the entity being evaluated for consolidation, eliminates the requirement to consolidate variable interest entities ("VIEs") caused by certain fees paid to decision makers, and eliminates the indefinite deferral of FASB Statement No. 167 included in ASU 2010-10. The new standard is effective for fiscal years beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. Early adoption is permitted. The Company is currently evaluating the impact ASU 2015-02 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000019:notes:106]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification Topic 605, "Revenue Recognition," to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of this ASU by one year. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years and interim periods within those years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019, and early adoption is permitted beginning after December 15, 2016. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-16-000019:notes:107]
[same as prior period, unchanged from 0000106040-15-000014:notes:96]

[0000106040-16-000019:notes:108]
[same as prior period, unchanged from 0000106040-15-000014:notes:97]

[0000106040-16-000019:notes:109]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal second quarters ended January 1, 2016 and January 2, 2015 both consisted of 13 weeks. The six months ended January 1, 2016 and January 2, 2015 consisted of 26 and 27 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.

[0000106040-16-000019:notes:110]
[same as prior period, unchanged from 0000106040-15-000014:notes:99]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-16-000019:notes:111]
[same as prior period, unchanged from 0000106040-15-000014:notes:100]

[0000106040-16-000019:notes:112]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three and six months ended January 1, 2016 and January 2, 2015. The expected long-term rate of return on the Japanese plan assets is 2.5%.

[0000106040-16-000019:notes:113]
[same as prior period, unchanged from 0000106040-15-000014:notes:102]

[0000106040-16-000019:notes:114]
|  | January 1, 2016 |  | July 3, 2015 |
| Benefit obligation | $ | 240 |  |  | $ | 231 |  |
| Fair value of plan assets | (195 | ) |  | (185 | ) |
| Unfunded status | $ | 45 |  |  | $ | 46 |  |

[0000106040-16-000019:notes:115]
[same as prior period, unchanged from 0000106040-15-000014:notes:104]

[0000106040-16-000019:notes:116]
|  | January 1, 2016 |  | July 3, 2015 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 44 |  |  | 45 |  |
| Net amount recognized | $ | 45 |  |  | $ | 46 |  |

[0000106040-16-000019:notes:117]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three and six months ended January 1, 2016 and January 2, 2015. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $10 million in fiscal 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000106040-16-000019:notes:118]
[same as prior period, unchanged from 0000106040-15-000014:notes:107]

[0000106040-16-000019:notes:119]
The Company periodically incurs charges to realign its operations with anticipated market demand. The employee termination, asset impairment and other charges line item within the Company's condensed consolidated statements of income consisted of the following (in millions):

[0000106040-16-000019:notes:120]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |
| Employee termination benefits | $ | 18 |  |  | $ | 34 |  |  | $ | 56 |  |  | $ | 42 |  |
| Impairment of assets | — |  |  | 19 |  |  | 8 |  |  | 20 |  |
| Contract termination and other | 9 |  |  | — |  |  | 19 |  |  | — |  |
| Total | $ | 27 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 62 |  |

[0000106040-16-000019:notes:121]
There were no impairment charges during the three months ended January 1, 2016. Impairment charges during the six months ended January 1, 2016 and January 2, 2015 relate to equipment and other long-lived assets.

[0000106040-16-000019:notes:122]
[same as prior period, unchanged from 0000106040-15-000014:notes:111]

[0000106040-16-000019:notes:123]
|  | July 3, 2015 |  | Accruals |  | Payments |  | October 2, 2015 |  | Accruals |  | Payments |  | January 1, 2016 |
| Employee termination benefits | $ | 10 |  |  | $ | 38 |  |  | $ | (12 | ) |  | $ | 36 |  |  | $ | 18 |  |  | $ | (30 | ) |  | $ | 24 |  |

[0000106040-16-000019:notes:124]
Closure of Foreign Manufacturing Facility

[0000106040-16-000019:notes:125]
On January 18, 2016, the Company announced it will be closing its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. The Company expects the closure to be substantially completed by the end of the third quarter of fiscal 2016 and it is expected to result in total pre-tax charges of approximately $200 million. These charges are expected to consist of approximately $90 million in asset charges, $90 million in employee termination costs and $20 million in contract termination and other costs. Approximately $110 million of these charges are expected to be cash expenditures. In the three months ended January 1, 2016, the Company recorded a $20 million charge related to the acceleration of depreciation on assets held at the Odawara facility as a result of the planned closure of the facility. This charge was recorded within cost of revenue in the condensed consolidated statements of income. The remaining charges are expected to be primarily incurred in the third quarter of fiscal 2016.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-16-000019:notes:126]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the six months ended January 1, 2016 (in millions):

[0000106040-16-000019:notes:127]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Unrealized Loss on Available for Sale Securities |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 3, 2015 | $ | 5 |  |  | $ | (25 | ) |  | $ | — |  |  | $ | (20 | ) |
| Other comprehensive loss before reclassifications | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 53 |  |  | (1 | ) |  | 52 |  |
| Net current-period other comprehensive income (loss) | — |  |  | 13 |  |  | (1 | ) |  | 12 |  |
| Balance at January 1, 2016 | $ | 5 |  |  | $ | (12 | ) |  | $ | (1 | ) |  | $ | (8 | ) |

[0000106040-16-000019:notes:128]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the six months ended January 2, 2015 (in millions):

[0000106040-16-000019:notes:129]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Unrealized Gain (Loss) on Available for Sale Securities |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | 5 |  |  | $ | — |  |  | $ | 12 |  |
| Other comprehensive loss before reclassifications | — |  |  | (57 | ) |  | — |  |  | (57 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Net current-period other comprehensive loss | — |  |  | (44 | ) |  | — |  |  | (44 | ) |
| Balance at January 2, 2015 | $ | 7 |  |  | $ | (39 | ) |  | $ | — |  |  | $ | (32 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-16-000019:notes:130]
[same as prior period, unchanged from 0000106040-15-000014:notes:117]

[0000106040-16-000019:notes:131]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |
| Warranty accrual, beginning of period | $ | 218 |  |  | $ | 201 |  |  | $ | 221 |  |  | $ | 182 |  |
| Charges to operations | 43 |  |  | 50 |  |  | 88 |  |  | 99 |  |
| Utilization | (40 | ) |  | (44 | ) |  | (94 | ) |  | (93 | ) |
| Changes in estimate related to pre-existing warranties | 4 |  |  | 16 |  |  | 10 |  |  | 35 |  |
| Warranty accrual, end of period | $ | 225 |  |  | $ | 223 |  |  | $ | 225 |  |  | $ | 223 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-16-000019:notes:132]
[same as prior period, unchanged from 0000106040-15-000014:notes:129]

[0000106040-16-000019:notes:133]
[same as prior period, unchanged from 0000106040-15-000014:notes:130]

[0000106040-16-000019:notes:134]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. The Company did not sell trade accounts receivable during the three months ended January 1, 2016. During the six months ended January 1, 2016, the Company sold trade accounts receivable and received cash proceeds of $200 million. The Company did not sell trade accounts receivable during the three and six months ended January 2, 2015. The discounts on the sales of trade accounts receivable were not material and were recorded within interest and other expense in the condensed consolidated statements of income.

[0000106040-16-000019:notes:135]
[same as prior period, unchanged from 0000106040-15-000014:notes:132]

[0000106040-16-000019:notes:136]
|  | January 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 130 |  |  | $ | 168 |  |
| Work-in-process | 474 |  |  | 500 |  |
| Finished goods | 634 |  |  | 700 |  |
| Total inventories | $ | 1,238 |  |  | $ | 1,368 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 8,716 |  |  | $ | 8,604 |  |
| Accumulated depreciation | (5,915 | ) |  | (5,639 | ) |
| Property, plant and equipment, net | $ | 2,801 |  |  | $ | 2,965 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 1,018 |  |  | $ | 1,008 |  |
| Accumulated amortization | (726 | ) |  | (676 | ) |
| Other intangible assets, net | $ | 292 |  |  | $ | 332 |  |

[0000106040-16-000019:notes:137]
[same as prior period, unchanged from 0000106040-15-000014:notes:134]

[0000106040-16-000019:notes:138]
[same as prior period, unchanged from 0000106040-15-000014:notes:135]

[0000106040-16-000019:notes:139]
The long-term portion of the warranty accrual classified in other liabilities was $81 million as of January 1, 2016 and $71 million as of July 3, 2015.

[0000106040-16-000019:notes:140]
[same as prior period, unchanged from 0000106040-15-000014:notes:137]

[0000106040-16-000019:notes:141]
The Company determined no available-for-sale securities were other-than-temporarily impaired during the three and six months ended January 1, 2016 and January 2, 2015. For more information on the Company's available-for-sale securities, see Note 7 to these condensed consolidated financial statements.

[0000106040-16-000019:notes:142]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the condensed consolidated balance sheets and were not material to the condensed consolidated financial statements as of January 1, 2016 and July 3, 2015.

[0000106040-16-000019:notes:143]
Joint Venture

[0000106040-16-000019:notes:144]
In November 2015, the Company entered into an agreement to form a joint venture with Unisplendour Corporation Limited ("Unis") to market and sell the Company's current data center storage systems in China and to develop data storage systems for the Chinese market in the future.  The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by the Company.

[0000106040-16-000019:notes:145]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-16-000019:notes:146]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The income tax impact on components of other comprehensive income is immaterial for all periods presented.
