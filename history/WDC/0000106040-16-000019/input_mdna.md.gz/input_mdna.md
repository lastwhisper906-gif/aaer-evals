# WDC MD&A — 0000106040-16-000019


## mdna

[0000106040-16-000019:mdna:1]
[same as prior period, unchanged from 0000106040-15-000014:mdna:1]

[0000106040-16-000019:mdna:2]
[same as prior period, unchanged from 0000106040-15-000014:mdna:2]

[0000106040-16-000019:mdna:3]
[same as prior period, unchanged from 0000106040-15-000014:mdna:3]

[0000106040-16-000019:mdna:4]
[same as prior period, unchanged from 0000106040-15-000014:mdna:29]

[0000106040-16-000019:mdna:5]
[same as prior period, unchanged from 0000106040-15-000014:mdna:4]

[0000106040-16-000019:mdna:6]
| • | expectations concerning the planned SanDisk Corporation (“SanDisk”) merger; |

[0000106040-16-000019:mdna:7]
[same as prior period, unchanged from 0000106040-15-000014:mdna:6]

[0000106040-16-000019:mdna:8]
[same as prior period, unchanged from 0000106040-15-000014:mdna:7]

[0000106040-16-000019:mdna:9]
[same as prior period, unchanged from 0000106040-15-000014:mdna:8]

[0000106040-16-000019:mdna:10]
[same as prior period, unchanged from 0000106040-15-000014:mdna:9]

[0000106040-16-000019:mdna:11]
[same as prior period, unchanged from 0000106040-15-000014:mdna:10]

[0000106040-16-000019:mdna:12]
| • | expectations regarding the amount and timing of charges and cash expenditures associated with our restructuring activities; |

[0000106040-16-000019:mdna:13]
[same as prior period, unchanged from 0000106040-15-000014:mdna:11]

[0000106040-16-000019:mdna:14]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0000106040-16-000019:mdna:15]
[same as prior period, unchanged from 0000106040-15-000014:mdna:13]

[0000106040-16-000019:mdna:16]
[same as prior period, unchanged from 0000106040-15-000014:mdna:14]

[0000106040-16-000019:mdna:17]
[same as prior period, unchanged from 0000106040-15-000014:mdna:15]

[0000106040-16-000019:mdna:18]
[same as prior period, unchanged from 0000106040-15-000014:mdna:16]

[0000106040-16-000019:mdna:19]
[same as prior period, unchanged from 0000106040-15-000014:mdna:17]

[0000106040-16-000019:mdna:20]
[same as prior period, unchanged from 0000106040-15-000014:mdna:18]

[0000106040-16-000019:mdna:21]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal second quarters ended January 1, 2016 and January 2, 2015 both consisted of 13 weeks. The six months ended January 1, 2016 and January 2, 2015 consisted of 26 and 27 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.

[0000106040-16-000019:mdna:22]
[same as prior period, unchanged from 0000106040-15-000014:mdna:44]

[0000106040-16-000019:mdna:23]
[same as prior period, unchanged from 0000106040-15-000014:mdna:21]

[0000106040-16-000019:mdna:24]
Closure of Foreign Manufacturing Facility

[0000106040-16-000019:mdna:25]
On January 18, 2016, we announced that we will be closing our head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. We expect the closure to be substantially completed by the end of the third quarter of fiscal 2016 and it is expected to result in total pre-tax charges of approximately $200 million. These charges are expected to consist of approximately $90 million in asset charges, $90 million in employee termination costs and $20 million in contract termination and other costs. Approximately $110 million of these charges are expected to be cash expenditures. In the three months ended January 1, 2016, we recorded a $20 million charge related to the acceleration of depreciation on assets held at the Odawara facility as a result of the planned closure of the facility. This charge was recorded within cost of revenue in the condensed consolidated statements of income. The remaining charges are expected to be primarily incurred in the third quarter of fiscal 2016.

[0000106040-16-000019:mdna:26]
[same as prior period, unchanged from 0000106040-15-000014:mdna:22]

[0000106040-16-000019:mdna:27]
In November 2015, we entered into an agreement to form a joint venture with Unis to market and sell our current data center storage systems in China and to develop data storage systems for the Chinese market in the future. The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by us. The joint venture is expected to become operational by the fourth quarter of fiscal 2016, pending regulatory approvals.

[0000106040-16-000019:mdna:28]
Planned SanDisk Merger

[0000106040-16-000019:mdna:29]
On October 21, 2015, we entered into an Agreement and Plan of Merger with SanDisk (the "Merger Agreement"), a global leader in NAND flash storage solutions, pursuant to which a subsidiary of our company will merge with and into SanDisk, with SanDisk surviving as a wholly owned subsidiary of our company. The merger is primarily intended to deepen our expertise in non-volatile memory and enable us to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000019:mdna:30]
The Merger Agreement values SanDisk's outstanding common stock at a value of $86.50 per share, or a total equity value of approximately $18.9 billion, based on the volume weighted average price of our common stock for the five trading days ending on October 20, 2015. If the Unis Investment (see "Investment by Unis" below) closes prior to the merger, we will pay $85.10 per share in cash and issue 0.0176 shares of our common stock per share of SanDisk’s common stock; and if the Unis Investment has not occurred or has been terminated, we will pay $67.50 per share in cash and issue 0.2387 shares of our common stock per share of SanDisk’s common stock. The above allocation between cash and shares of our common stock is subject to reallocation, at our election, if the amount of cash that SanDisk has available at the closing of the merger falls below certain thresholds.

[0000106040-16-000019:mdna:31]
The merger consideration will be financed by a mix of cash, new debt financing and issuance of our common stock. In connection with the merger, we expect to enter into new debt facilities totaling $18.1 billion. The proceeds from the new debt facilities are expected to be used to pay part of the purchase price, refinance existing debt of both our company and SanDisk and pay transaction related fees and expenses.

[0000106040-16-000019:mdna:32]
Consummation of the merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and, if the Unis Investment has not occurred or has been terminated, approval by our shareholders; (ii) the expiration or early termination of the waiting period applicable to the consummation of the merger under the Hart Scott Rodino Antitrust Improvements Act of 1976, as amended (“HSR Act”), which expired on January 15, 2016, and the receipt of regulatory clearance under the foreign antitrust laws of the People's Republic of China, the European Union, Japan, South Africa, South Korea, Taiwan and Turkey; and (iii) if the Unis Investment has not been terminated and is a “covered transaction” for U.S. Committee on Foreign Investment in the United States ("CFIUS") purposes, or if CFIUS otherwise requests or requires a filing with respect to the merger, the approval of CFIUS. Clearance was obtained in Japan on January 22, 2016, in Taiwan on February 1, 2016 and in the European Union on February 4, 2016. Clearance was obtained in Singapore on January 19, 2016. In certain circumstances, a termination fee of up to $1.06 billion may be payable by the Company or a termination fee of up to $553.3 million may be payable by SanDisk, upon termination of the transaction as more fully described in the Merger Agreement. The merger is expected to close in the fourth quarter of fiscal 2016.

[0000106040-16-000019:mdna:33]
[same as prior period, unchanged from 0000106040-15-000014:mdna:54]

[0000106040-16-000019:mdna:34]
[same as prior period, unchanged from 0000106040-15-000014:mdna:31]

[0000106040-16-000019:mdna:35]
In connection with the regulatory approval process of the Hitachi Global Storage Technologies Holdings Pte. Ltd. ("HGST") acquisition, which closed on March 8, 2012, we agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, we have operated our global business through two independent subsidiaries — HGST and WD. In March 2014, we submitted an application to MOFCOM to lift the condition it imposed on us to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to our application that permits us to integrate our HGST and WD subsidiaries, except that we committed to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision. We began integration planning activities immediately following the MOFCOM decision and integration is expected to occur through the end of calendar year 2017.

[0000106040-16-000019:mdna:36]
[same as prior period, unchanged from 0000106040-15-000014:mdna:33]

[0000106040-16-000019:mdna:37]
On September 30, 2015, we announced that we had entered into an agreement with Unis and Unis Union Information System Ltd., a subsidiary of Unis ("Investor"), pursuant to which Investor will make a $3.8 billion equity investment in our company (the "Unis Investment"). Under the terms of the agreement for the Unis Investment, Investor has agreed to purchase 40,814,802 shares of newly issued common stock at a price of $92.50 per share and has agreed to a five-year position standstill, voting restrictions, and a five-year lock-up on its shares, with a limited number becoming available for transfer each year. Following the closing of the investment, Unis will have the right to nominate one representative for election to our Board of Directors, so long as Unis holds more than 10% of the issued and outstanding shares of our common stock. The performance of Investor’s obligations pursuant to the agreement, including payment of the purchase price for the shares, is guaranteed by Unis. The closing of the Unis Investment is subject to clearance by CFIUS, the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, approval of the transaction by shareholders of Unis and other customary closing conditions. In November 2015, we and Unis withdrew from the CFIUS clearance process and refiled the notice with CFIUS in January 2016. We expect to receive a determination from CFIUS in February 2016. Although approval from Unis shareholders and approval from some of the Chinese regulatory authorities have been received, we cannot provide assurance that CFIUS clearance will be received or the other conditions to the completion of the Unis Investment will be satisfied in a timely manner or at all.

[0000106040-16-000019:mdna:38]
Second Quarter Overview

[0000106040-16-000019:mdna:39]
For the quarter ended January 1, 2016, we believe that overall HDD industry shipments totaled approximately 115 million units, down 18% from the prior-year period and down 3% from the quarter ended October 2, 2015. These decreases are the result of a softer demand environment largely driven by a challenging global economic environment.

[0000106040-16-000019:mdna:40]
[same as prior period, unchanged from 0000106040-15-000014:mdna:37]

[0000106040-16-000019:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |
| Net revenue | $ | 3,317 |  |  | 100.0 | % |  | $ | 3,888 |  |  | 100.0 | % |  | $ | 6,677 |  |  | 100.0 | % |  | $ | 7,831 |  |  | 100.0 | % |
| Gross profit | 906 |  |  | 27.3 |  |  | 1,110 |  |  | 28.5 |  |  | 1,861 |  |  | 27.9 |  |  | 2,259 |  |  | 28.8 |  |
| Total operating expenses | 655 |  |  | 19.7 |  |  | 644 |  |  | 16.6 |  |  | 1,288 |  |  | 19.3 |  |  | 1,324 |  |  | 16.9 |  |
| Operating income | 251 |  |  | 7.6 |  |  | 466 |  |  | 12.0 |  |  | 573 |  |  | 8.6 |  |  | 935 |  |  | 11.9 |  |
| Net income | 251 |  |  | 7.6 |  |  | 438 |  |  | 11.3 |  |  | 534 |  |  | 8.0 |  |  | 861 |  |  | 11.0 |  |

[0000106040-16-000019:mdna:42]
The following is a summary of our financial performance for the second quarter of fiscal 2016:

[0000106040-16-000019:mdna:43]
| • | Consolidated net revenue totaled $3.3 billion. |

[0000106040-16-000019:mdna:44]
| • | Net revenue derived from enterprise SSDs was $270 million as compared to $187 million in the prior-year period. |

[0000106040-16-000019:mdna:45]
| • | HDD shipments decreased 19% from the prior-year period to 49.7 million units. |

[0000106040-16-000019:mdna:46]
| • | Gross margin decreased to 27.3% as compared to 28.5% in the prior-year period. |

[0000106040-16-000019:mdna:47]
| • | Operating income decreased to $251 million as compared to $466 million in the prior-year period. |

[0000106040-16-000019:mdna:48]
| • | We generated $598 million in cash flow from operations and ended the quarter with $5.4 billion in cash and cash equivalents. |

[0000106040-16-000019:mdna:49]
[same as prior period, unchanged from 0000106040-15-000014:mdna:68]

[0000106040-16-000019:mdna:50]
[same as prior period, unchanged from 0000106040-15-000014:mdna:47]

[0000106040-16-000019:mdna:51]
[same as prior period, unchanged from 0000106040-15-000014:mdna:48]

[0000106040-16-000019:mdna:52]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in millions, except percentages andaverage selling price) | January 1, 2016 |  | January 2, 2015 |  | Percentage Change |  | January 1, 2016 |  | January 2, 2015 |  | PercentageChange |
| Net revenue | $ | 3,317 |  |  | $ | 3,888 |  |  | (15 | )% |  | $ | 6,677 |  |  | $ | 7,831 |  |  | (15 | )% |
| Average selling price (per unit)* | $ | 61 |  |  | $ | 60 |  |  | 2 | % |  | $ | 61 |  |  | $ | 59 |  |  | 3 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas | 31 | % |  | 27 | % |  |  |  | 31 | % |  | 27 | % |  |  |
| Europe, Middle East and Africa | 23 |  |  | 24 |  |  |  |  | 22 |  |  | 23 |  |  |  |
| Asia | 46 |  |  | 49 |  |  |  |  | 47 |  |  | 50 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEM | 65 | % |  | 63 | % |  |  |  | 66 | % |  | 63 | % |  |  |
| Distributors | 21 |  |  | 23 |  |  |  |  | 21 |  |  | 24 |  |  |  |
| Retailers | 14 |  |  | 14 |  |  |  |  | 13 |  |  | 13 |  |  |  |
| Unit Shipments* |  |  |  |  |  |  |  |  |  |  |  |
| PC | 27.8 |  |  | 36.6 |  |  |  |  | 55.3 |  |  | 76.3 |  |  |  |
| Non-PC | 21.9 |  |  | 24.4 |  |  |  |  | 46.1 |  |  | 49.5 |  |  |  |
| Total units shipped | 49.7 |  |  | 61.0 |  |  | (19 | )% |  | 101.4 |  |  | 125.8 |  |  | (19 | )% |

[0000106040-16-000019:mdna:53]
[same as prior period, unchanged from 0000106040-15-000014:mdna:50]

[0000106040-16-000019:mdna:54]
For the quarter ended January 1, 2016, net revenue was $3.3 billion, a decrease of 15% from the prior-year period. Total hard drive shipments decreased to 49.7 million units for the quarter ended January 1, 2016 as compared to 61.0 million units in the prior-year period. For the six months ended January 1, 2016, net revenue was $6.7 billion, a decrease of 15% from the prior-year period. Total hard drive shipments decreased to 101.4 million units for the six months ended January 1, 2016 as compared to 125.8 million units in the prior-year period. These decreases in revenue were primarily the result of a softer demand environment largely driven by a challenging global economic environment, partially offset by an increase in the average selling price ("ASP") for HDDs due to changes in product mix. Additionally, the first fiscal quarter of the prior year included an additional week of revenue due to a 14-week quarter. For the quarter ended January 1, 2016, the ASP for HDDs increased to $61 compared to the prior-year period ASP for HDDs of $60. For the six months ended January 1, 2016, the ASP for HDDs increased to $61 compared to the prior-year period ASP for HDDs of $59.

[0000106040-16-000019:mdna:55]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For both the three and six months ended January 1, 2016, no one company accounted for 10% or more of our net revenue. For both the three and six months ended January 2, 2015, Hewlett-Packard Company accounted for approximately 11% of our net revenue.

[0000106040-16-000019:mdna:56]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Total sales incentive and marketing programs have ranged from 7% to 13% of gross revenues per quarter since the first quarter of fiscal 2014. For the three and six months ended January 1, 2016, these programs represented 13% and 12% of gross revenues, respectively, as compared to 10% and 9% in the respective prior-year periods. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.6% of quarterly gross revenue since the first quarter of fiscal 2014.

[0000106040-16-000019:mdna:57]
25

[0000106040-16-000019:mdna:58]
[same as prior period, unchanged from 0000106040-15-000014:mdna:55]

[0000106040-16-000019:mdna:59]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in millions, except percentages) | January 1, 2016 |  | January 2, 2015 |  | Percentage Change |  | January 1, 2016 |  | January 2, 2015 |  | PercentageChange |
| Net revenue | $ | 3,317 |  |  | $ | 3,888 |  |  | (15 | )% |  | $ | 6,677 |  |  | $ | 7,831 |  |  | (15 | )% |
| Gross profit | 906 |  |  | 1,110 |  |  | (18 | )% |  | 1,861 |  |  | 2,259 |  |  | (18 | )% |
| Gross margin | 27.3 | % |  | 28.5 | % |  |  |  | 27.9 | % |  | 28.8 | % |  |  |

[0000106040-16-000019:mdna:60]
For the three months ended January 1, 2016, gross margin decreased to 27.3%, as compared to 28.5% for the prior-year period. For the six months ended January 1, 2016, gross margin decreased to 27.9%, as compared to 28.8% for the prior-year period. These decreases in gross margin were primarily the result of a change in product mix and the absorption impact due to lower volume.

[0000106040-16-000019:mdna:61]
[same as prior period, unchanged from 0000106040-15-000014:mdna:58]

[0000106040-16-000019:mdna:62]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in millions, except percentages) | January 1, 2016 |  | January 2, 2015 |  | Percentage Change |  | January 1, 2016 |  | January 2, 2015 |  | PercentageChange |
| R&D expense | $ | 389 |  |  | $ | 426 |  |  | (9 | )% |  | $ | 774 |  |  | $ | 863 |  |  | (10 | )% |
| SG&A expense | 207 |  |  | 164 |  |  | 26 | % |  | 399 |  |  | 384 |  |  | 4 | % |
| Charges related to arbitration award | 32 |  |  | 1 |  |  | 3,100 | % |  | 32 |  |  | 15 |  |  | 113 | % |
| Employee termination, asset impairment and other charges | 27 |  |  | 53 |  |  | (49 | )% |  | 83 |  |  | 62 |  |  | 34 | % |
| Total operating expenses | $ | 655 |  |  | $ | 644 |  |  |  |  | $ | 1,288 |  |  | $ | 1,324 |  |  |  |

[0000106040-16-000019:mdna:63]
Research and development (“R&D”) expense was $389 million for the three months ended January 1, 2016, a decrease of $37 million from the prior-year period. This decrease was primarily the result of reductions in our R&D costs as a result of our business realignment initiatives from the prior-year period. R&D expense was $774 million for the six months ended January 1, 2016, a decrease of $89 million from the prior-year period. This decrease was primarily the result of an additional week of operating expenses during the first fiscal quarter of the prior year and reductions in our R&D costs as a result of our business realignment initiatives from the prior-year period. As a percentage of net revenue, R&D expense was 11.7% and 11.6% in the three and six months ended January 1, 2016, as compared to 11.0% in both the respective prior-year periods.

[0000106040-16-000019:mdna:64]
Selling, general and administrative (“SG&A”) expense was $207 million for the three months ended January 1, 2016, an increase of $43 million from the prior-year period. This increase was primarily the result of acquisition-related expenses and charges incurred as part of cost-saving initiatives. SG&A expense was $399 million for the six months ended January 1, 2016, an increase of $15 million from the prior-year period. This increase was primarily the result of acquisition-related expenses and charges incurred as part of cost-saving initiatives, partially offset by an additional week of operating expenses during the first fiscal quarter of the prior year. SG&A expense as a percentage of net revenue was 6.2% and 6.0% in the three and six months ended January 1, 2016, respectively, as compared to 4.2% and 4.9% in the respective prior-year periods.

[0000106040-16-000019:mdna:65]
During both the three and six months ended January 1, 2016, we recorded $32 million of additional interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC, as compared to $1 million and $15 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:66]
During the three and six months ended January 1, 2016, we recorded employee termination, asset impairment and other charges of $27 million and $83 million, respectively, in order to realign our operations with anticipated market demand, as compared to $53 million and $62 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:67]
[same as prior period, unchanged from 0000106040-15-000014:mdna:64]

[0000106040-16-000019:mdna:68]
Other expense, net for the three and six months ended January 1, 2016 was $7 million and $15 million, respectively, as compared to $8 million and $17 million in the respective prior-year periods. Interest and other income for the three and six months ended January 1, 2016 increased $2 million and $3 million, respectively, as compared to the prior-year periods due to a higher average daily invested cash balance. Interest and other expense for both the three and six months ended January 1, 2016 increased $1 million, as compared to both the prior-year periods due to interest on a higher debt balance.

[0000106040-16-000019:mdna:69]
26

[0000106040-16-000019:mdna:70]
[same as prior period, unchanged from 0000106040-15-000014:mdna:66]

[0000106040-16-000019:mdna:71]
We had an income tax benefit of $7 million and income tax expense of $24 million in the three and six months ended January 1, 2016, respectively. Our income tax expense for the three and six months ended January 2, 2015 was $20 million and $57 million, respectively. Our tax provision for both the three and six months ended January 1, 2016 reflects a tax benefit of $30 million for the retroactive extension of the U.S. Federal R&D tax credit that was permanently signed into law on December 19, 2015 and a tax benefit of $34 million from restructuring activities. The remaining differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:72]
[same as prior period, unchanged from 0000106040-15-000014:mdna:70]

[0000106040-16-000019:mdna:73]
We ended the second quarter of fiscal 2016 with total cash and cash equivalents of $5.4 billion. The following table summarizes our statements of cash flows (in millions):

[0000106040-16-000019:mdna:74]
|  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 1,143 |  |  | $ | 1,070 |  |
| Investing activities | (454 | ) |  | (254 | ) |
| Financing activities | (350 | ) |  | (718 | ) |
| Net increase in cash and cash equivalents | $ | 339 |  |  | $ | 98 |  |

[0000106040-16-000019:mdna:75]
[same as prior period, unchanged from 0000106040-15-000014:mdna:73]

[0000106040-16-000019:mdna:76]
As discussed above under Recent Developments, in connection with the planned SanDisk merger, we expect to enter into new debt facilities totaling $18.1 billion. We have received commitments for a $1.0 billion revolving credit facility, $3.0 billion in amortizing term loans, $6.0 billion in other term loans and $8.1 billion in secured and unsecured bridge facilities. We expect to issue approximately $5.1 billion in secured and unsecured notes in lieu of drawing the bridge facilities at close, with the balance of the bridge facilities to be repaid with available cash. The proceeds from the new debt facilities are expected to be used to pay a portion of the SanDisk merger consideration, refinance existing debt of both our company and SanDisk and pay transaction related fees and expenses. Also as discussed above under Recent Developments, on September 29, 2015, we entered into an agreement with Unis under which a subsidiary of Unis will make a $3.8 billion equity investment in our company. The closing of the Unis Investment is subject to clearance by CFIUS, the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, approval of the transaction by shareholders of Unis and other customary closing conditions.

[0000106040-16-000019:mdna:77]
A total of $4.9 billion and $4.3 billion of our cash and cash equivalents was held outside of the United States as of January 1, 2016 and July 3, 2015, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or dividends to our shareholders pursuant to our quarterly cash dividend policy. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-16-000019:mdna:78]
[same as prior period, unchanged from 0000106040-15-000014:mdna:76]

[0000106040-16-000019:mdna:79]
Net cash provided by operating activities was $1.1 billion during both the six months ended January 1, 2016 and January 2, 2015. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used for working capital changes was $3 million for the six months ended January 1, 2016, as compared to $475 million used for working capital changes in the prior-year period. The decline in net cash used for working capital changes compared to the prior-year period was primarily attributable to the payment of the Seagate arbitration award in the six months ended January 2, 2015.

[0000106040-16-000019:mdna:80]
[same as prior period, unchanged from 0000106040-15-000014:mdna:97]

[0000106040-16-000019:mdna:81]
[same as prior period, unchanged from 0000106040-15-000014:mdna:78]

[0000106040-16-000019:mdna:82]
|  | Six Months Ended |
|  | January 1, 2016 |  | January 2, 2015 |
| Days sales outstanding | 47 |  |  | 45 |  |
| Days in inventory | 48 |  |  | 44 |  |
| Days payables outstanding | (71 | ) |  | (70 | ) |
| Cash conversion cycle | 24 |  |  | 19 |  |

[0000106040-16-000019:mdna:83]
For the six months ended January 1, 2016, our days sales outstanding (“DSOs”) increased by 2 days, days in inventory (“DIOs”) increased by 4 days, and days payable outstanding (“DPOs”) increased by 1 day compared to the prior year period. Changes in DSOs are generally due to the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-16-000019:mdna:84]
[same as prior period, unchanged from 0000106040-15-000014:mdna:81]

[0000106040-16-000019:mdna:85]
Net cash used in investing activities for the six months ended January 1, 2016 was $454 million as compared to $254 million used in investing activities in the prior-year period. Net cash used in investing activities for the six months ended January 1, 2016 consisted of $408 million related to the purchase of investments, $300 million of capital expenditures and a net $12 million of other investing activities, partially offset by $266 million of proceeds from sales and maturities of investments. Net cash used in investing activities for the six months ended January 2, 2015 consisted of $595 million related to the purchase of investments, $306 million of capital expenditures and $6 million related to an immaterial acquisition, net of cash acquired, partially offset by $630 million of proceeds from sales and maturities of investments, $7 million of proceeds from the sale of property, plant and equipment and $16 million, net for other investing activities.

[0000106040-16-000019:mdna:86]
[same as prior period, unchanged from 0000106040-15-000014:mdna:83]

[0000106040-16-000019:mdna:87]
Net cash used in financing activities for the six months ended January 1, 2016 was $350 million as compared to $718 million used in financing activities in the prior-year period. Net cash used in financing activities for the six months ended January 1, 2016 consisted of $231 million used to pay dividends on our common stock, $63 million used to make principal payments on the term loan facility, $60 million used to repurchase shares of our common stock, partially offset by a net $4 million provided by employee stock plans. Net cash used in financing activities for the six months ended January 2, 2015 consisted of $532 million used to repurchase shares of our common stock, $187 million used to pay dividends on our common stock and $63 million used to make principal payments on the term loan facility, partially offset by a net $64 million provided by employee stock plans.

[0000106040-16-000019:mdna:88]
[same as prior period, unchanged from 0000106040-15-000014:mdna:85]

[0000106040-16-000019:mdna:89]
[same as prior period, unchanged from 0000106040-15-000014:mdna:86]

[0000106040-16-000019:mdna:90]
[same as prior period, unchanged from 0000106040-15-000014:mdna:87]

[0000106040-16-000019:mdna:91]
Debt — As of January 1, 2016, we had $255 million outstanding on our revolving credit facility and $2.3 billion outstanding on our term loan facility. On January 15, 2016, we repaid the outstanding balance of $255 million under the revolving credit facility. We are required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. As of January 1, 2016, under our credit agreement, we were in compliance with all covenants. In connection with the planned SanDisk merger, we expect to enter into debt facilities totaling $18.1 billion, including a $1.0 billion revolving credit facility. The proceeds from the debt facilities are expected to be used to pay a portion of the SanDisk merger consideration, refinance existing debt of both our company and SanDisk and pay transaction-related fees and expenses. For additional information on our outstanding debt, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:92]
[same as prior period, unchanged from 0000106040-15-000014:mdna:89]

[0000106040-16-000019:mdna:93]
[same as prior period, unchanged from 0000106040-15-000014:mdna:90]

[0000106040-16-000019:mdna:94]
[same as prior period, unchanged from 0000106040-15-000014:mdna:91]

[0000106040-16-000019:mdna:95]
[same as prior period, unchanged from 0000106040-15-000014:mdna:92]

[0000106040-16-000019:mdna:96]
[same as prior period, unchanged from 0000106040-15-000014:mdna:93]

[0000106040-16-000019:mdna:97]
[same as prior period, unchanged from 0000106040-15-000014:mdna:94]

[0000106040-16-000019:mdna:98]
[same as prior period, unchanged from 0000106040-15-000014:mdna:95]

[0000106040-16-000019:mdna:99]
Unrecognized Tax Benefits — As of January 1, 2016, the amount of unrecognized tax benefits was $375 million, of which $272 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. See Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-16-000019:mdna:100]
Stock Repurchase Program — Our Board of Directors previously authorized a stock repurchase program. Effective October 21, 2015, in connection with the planned SanDisk merger, we suspended this stock repurchase program. For additional information, refer to Part II, Item 2, Issuer Purchases of Equity Securities in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:101]
Cash Dividend Policy — Since the first quarter of fiscal 2014, we have issued a quarterly cash dividend. We may modify, suspend or cancel our cash dividend policy in any manner and at any time. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000019:mdna:102]
[same as prior period, unchanged from 0000106040-15-000014:mdna:100]

[0000106040-16-000019:mdna:103]
We have prepared the unaudited condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. For example, we test goodwill for impairment annually as of the first day of our fourth fiscal quarter and at other times if events have occurred or circumstances exist that indicate the carrying value of goodwill may no longer be recoverable. Given the recent volatility of our market capitalization, it is possible that our goodwill could become impaired in the near term which could result in a material charge and adversely affect our results of operations.

[0000106040-16-000019:mdna:104]
There have been no material changes in our critical accounting policies and estimates since our fiscal year ended July 3, 2015. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 3, 2015 for a discussion of our critical accounting policies and estimates.

[0000106040-16-000019:mdna:105]
[same as prior period, unchanged from 0000106040-15-000014:mdna:102]

[0000106040-16-000019:mdna:106]
[same as prior period, unchanged from 0000106040-15-000014:mdna:103]
