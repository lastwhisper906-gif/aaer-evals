# WDC note change history — 0000106040-15-000014 → 0000106040-16-000019


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-10):
[0000106040-16-000019:note_history:1]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the final arbitration award and interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.
  (was, 2015-11-10, similarity 0.98):
[0000106040-15-000014:note_history:1]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

- added (2016-02-10):
[0000106040-16-000019:note_history:2]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company has no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. The Company and Seagate have signed and filed with the court a stipulation of dismissal with prejudice resolving this matter.

- added (2016-02-10):
[0000106040-16-000019:note_history:3]
SanDisk Matters

- added (2016-02-10):
[0000106040-16-000019:note_history:4]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk Corporation (“SanDisk”) on October 21, 2015 (the “Merger Agreement”).  The complaints allege, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also allege that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs seek injunctive relief to prevent the merger from closing.  The plaintiffs also seek, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  The Company intends to defend itself vigorously in this matter.

- removed (2016-02-10):
[0000106040-15-000014:note_history:5]
Seagate disputes the method the Company used for calculating post-award interest and contends that the Company owes Seagate approximately $29 million in additional interest.  The Company denies Seagate’s contention and believes it calculated interest properly in accordance with the arbitration award.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate have been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals, where the matter remains pending. The Company intends to continue to defend itself vigorously in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-10):
[0000106040-16-000019:note_history:6]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal second quarters ended January 1, 2016 and January 2, 2015 both consisted of 13 weeks. The six months ended January 1, 2016 and January 2, 2015 consisted of 26 and 27 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.
  (was, 2015-11-10, similarity 0.6983):
[0000106040-15-000014:note_history:6]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal first quarters ended October 2, 2015 and October 3, 2014 consisted of 13 and 14 weeks, respectively. Fiscal 2015 was comprised of 53 weeks and ended on July 3, 2015. Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-10):
[0000106040-16-000019:note_history:7]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of January 1, 2016, the revolving credit facility had a variable interest rate of 1.7% and an outstanding balance of $255 million. The revolving credit facility was classified within current liabilities as of January 1, 2016 as the Company intended to repay the borrowings within the next 12 months. The Company repaid the $255 million outstanding balance under the revolving credit facility on January 15, 2016. As of January 1, 2016, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.
  (was, 2015-11-10, similarity 0.6355):
[0000106040-15-000014:note_history:7]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of October 2, 2015, the revolving credit facility had a variable interest rate of 1.7% and an outstanding balance of $255 million. The revolving credit facility is classified within current liabilities as of October 2, 2015 due to the Company's intent to repay the borrowings within the next 12 months. As of October 2, 2015, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $125 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-02-10):
[0000106040-15-000014:note_history:8]
14. Subsequent Events

- removed (2016-02-10):
[0000106040-15-000014:note_history:9]
Joint Venture

- removed (2016-02-10):
[0000106040-15-000014:note_history:10]
On November 9, 2015, the Company announced an agreement to form a joint venture with Unis to market and sell the Company's current data center storage systems in China and to develop data storage systems for the Chinese market in the future.  The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by the Company.  The joint venture is expected to become operational by the fourth quarter of fiscal 2016, pending regulatory approvals.

- removed (2016-02-10):
[0000106040-15-000014:note_history:11]
Planned Acquisition of SanDisk

- removed (2016-02-10):
[0000106040-15-000014:note_history:12]
On October 21, 2015, the Company entered into an Agreement and Plan of Merger with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of the Company will merge with and into SanDisk, with SanDisk surviving as a wholly owned subsidiary of the Company. The planned acquisition is primarily intended to deepen the Company's expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

- removed (2016-02-10):
[0000106040-15-000014:note_history:13]
The merger agreement values SanDisk’s outstanding common stock at a value of $86.50 per share, or a total equity value of approximately $18.9 billion, based on the volume weighted average price of the Company’s common stock for the five trading days ending on October 20, 2015. If the Unis Investment closes prior to the acquisition, the Company will pay $85.10 per share in cash and issue 0.0176 shares of its common stock per share of SanDisk’s common stock; and if the Unis Investment has not occurred or has been terminated, the Company will pay $67.50 per share in cash and issue 0.2387 shares of its common stock per share of SanDisk’s common stock. The above allocation between cash and shares of the Company’s common stock is subject to reallocation, at the Company’s election, if the amount of cash that SanDisk has available at the closing of the planned merger falls below certain thresholds.

- removed (2016-02-10):
[0000106040-15-000014:note_history:14]
The planned acquisition will be financed by a mix of cash, new debt financing and issuance of the Company’s common stock. In connection with the planned acquisition, the Company expects to enter into new debt facilities totaling $18.1 billion. The Company has received commitments for a $1 billion revolving credit facility, $3 billion in amortizing term loans, $6 billion in other term loans and $8.1 billion in secured and unsecured bridge facilities.  The Company expects to issue approximately $5.1 billion in secured and unsecured notes in lieu of drawing the bridge facilities at close, with the balance of the bridge facilities to be repaid with available cash. The proceeds from the new debt facilities are expected to be used to pay part of the purchase price, refinance existing debt of both the Company and SanDisk and pay transaction related fees and expenses.

- removed (2016-02-10):
[0000106040-15-000014:note_history:15]
Consummation of the merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and, if the Unis Investment has not occurred or has been terminated, approval by the Company’s shareholders; (ii) the expiration or early termination of the waiting period applicable to the consummation of the merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the receipt of regulatory clearance under certain foreign antitrust laws, including the European Union and China; and (iii) if the Unis Investment has not been terminated and is a “covered transaction” for CFIUS purposes, or if CFIUS otherwise requests or requires a filing with respect to the merger, the approval of CFIUS. In certain circumstances, a termination fee may be payable by either the Company or SanDisk upon termination of the transaction as more fully described in the merger agreement.

- removed (2016-02-10):
[0000106040-15-000014:note_history:16]
Ministry of Commerce of the People’s Republic of China (“MOFCOM”) Decision

- removed (2016-02-10):
[0000106040-15-000014:note_history:17]
In connection with the regulatory approval process of the Hitachi Global Storage Technologies Holdings Pte. Ltd. ("HGST") acquisition, which closed on March 8, 2012, the Company agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, the Company has operated its global business through two independent subsidiaries — HGST and WD.  In March 2014, the Company submitted an application to MOFCOM to lift the condition it imposed on the Company to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to the Company’s application that permits the Company to integrate its HGST and WD subsidiaries, except that the Company committed to continue to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision.
