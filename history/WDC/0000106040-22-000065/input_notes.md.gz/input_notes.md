# WDC notes — 0000106040-22-000065


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-22-000065:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in memory technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-22-000065:notes:2]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-22-000065:notes:3]
[same as prior period, unchanged from 0000106040-22-000040:notes:3]

[0000106040-22-000065:notes:4]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, which ends on June 30, 2023, and 2022, which ended on July 1, 2022, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-22-000065:notes:5]
Segment Reporting

[0000106040-22-000065:notes:6]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.

[0000106040-22-000065:notes:7]
The Company’s Chief Operating Decision Maker (“CODM”) evaluates performance of the Company and makes decisions regarding allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are not available or reviewed by the CODM to evaluate the performance of or to allocate resources to the segments.

[0000106040-22-000065:notes:8]
[same as prior period, unchanged from 0000106040-22-000040:notes:5]

[0000106040-22-000065:notes:9]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of current macroeconomic conditions. However, actual results could differ materially from these estimates.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-22-000065:notes:10]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-22-000065:notes:11]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with prior standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. The Company adopted the new standard effective July 2, 2022, the first day of the year ending June 30, 2023, using the modified retrospective method. On the date of adoption, the Company recorded a reduction in Additional Paid-In Capital of $128 million, a reduction of unamortized debt discount of $48 million, a reduction of deferred income tax liabilities of $11 million, and an increase to retained earnings of $91 million for the after-tax impact of previously recognized amortization of the debt discount associated with the Company’s convertible senior notes.

[0000106040-22-000065:notes:12]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of 2023. The Company adopted this ASU on July 2, 2022, the first day of the year ending June 30, 2023, and the adoption did not have a material impact on its Condensed Consolidated Financial Statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-22-000065:notes:13]
Business Segments, Geographic Information, and Concentrations of Risk
The following table summarizes the operating performance of the Company’s reportable segments:

[0000106040-22-000065:notes:14]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
|  | (in millions, except percentages) |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,722 |  |  | $ | 2,490 |  |  |  |  |  |
| HDD | 2,014 |  |  | 2,561 |  |  |  |  |  |
| Total net revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 422 |  |  | $ | 921 |  |  |  |  |  |
| HDD | 574 |  |  | 792 |  |  |  |  |  |
| Total gross profit for segments | 996 |  |  | 1,713 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (14) |  |  | (9) |  |  |  |  |  |
| Amortization of acquired intangible assets | (1) |  |  | (39) |  |  |  |  |  |
| Total unallocated corporate items | (15) |  |  | (48) |  |  |  |  |  |
| Consolidated gross profit | $ | 981 |  |  | $ | 1,665 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 24.5 | % |  | 37.0 | % |  |  |  |  |
| HDD | 28.5 | % |  | 30.9 | % |  |  |  |  |
| Consolidated gross margin | 26.3 | % |  | 33.0 | % |  |  |  |  |

[0000106040-22-000065:notes:15]
[same as prior period, unchanged from 0000106040-22-000040:notes:16]

[0000106040-22-000065:notes:16]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-22-000065:notes:17]
[same as prior period, unchanged from 0000106040-22-000040:notes:18]

[0000106040-22-000065:notes:18]
|  | Three Months Ended |  |
|  | September 30,2022 |  | October 1,2021 |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |
| Cloud | $ | 1,829 |  |  | $ | 2,225 |  |  |
| Client | 1,229 |  |  | 1,853 |  |  |
| Consumer | 678 |  |  | 973 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |
| Revenue by Geography |  |  |  |  |
| Asia | $ | 1,686 |  |  | $ | 2,675 |  |  |
| Americas | 1,423 |  |  | 1,614 |  |  |
| Europe, Middle East and Africa | 627 |  |  | 762 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |

[0000106040-22-000065:notes:19]
The Company’s top 10 customers accounted for 52% of its net revenue for the three months ended September 30, 2022, and 43% of its net revenue for the three months ended October 1, 2021. For the three months ended September 30, 2022 and October 1, 2021, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-22-000065:notes:20]
[same as prior period, unchanged from 0000106040-22-000040:notes:21]

[0000106040-22-000065:notes:21]
The following table provides a summary of goodwill activity for the period:

[0000106040-22-000065:notes:22]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at July 1, 2022 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |
| Foreign currency translation adjustment | (2) |  |  | (2) |  |  | (4) |  |
| Balance at September 30, 2022 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |

[0000106040-22-000065:notes:23]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment

[0000106040-22-000065:notes:24]
As of September 30, 2022, management identified several factors, including changes in macroeconomic conditions and a recent decline of the Company’s market stock price, that warranted a quantitative analysis of impairment for both the Flash and HDD reporting units as of that date. The fair value of each operating segment was based on a weighting of two valuation methodologies: an income approach and a market approach.

[0000106040-22-000065:notes:25]
The income approach was based on the present value of the projected discounted cash flows (“DCF”) expected to be generated by the operating segment. Those projections required the use of significant estimates and assumptions specific to the reporting unit as well as those based on general economic conditions, which included, among other factors, revenue growth rates, gross margins, operating costs, capital expenditures, assumed tax rates and other assumptions deemed reasonable by management. The present value was based on applying a weighted average cost of capital (“WACC”) which considered long-term interest rates and cost of equity based on the Company’s risk profile.

[0000106040-22-000065:notes:26]
The market approach was based on a guideline company method, which analyzed market multiples of revenue and earnings before interest, taxes, depreciation and amortization (“EBITDA”) for a group of comparable public companies.

[0000106040-22-000065:notes:27]
We reconciled the aggregated estimated fair value of both operating segments to the Company’s market capitalization, including consideration of a control premium representing the estimated amount a market participant would pay to obtain a controlling interest in the Company.

[0000106040-22-000065:notes:28]
As of September 30, 2022, the fair value derived from those valuation methodologies exceeded the carrying value by 7% and 32% for Flash and HDD, respectively, and no impairment was recognized.

[0000106040-22-000065:notes:29]
The Company is required to use judgment when applying the goodwill impairment test, including the assignment of assets and liabilities to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on future changes in the Company’s results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen or the Company’s stock price decreases for a sustained period of time, goodwill could become impaired, which could result in an impairment charge and materially adversely affect the Company’s financial condition results of operations.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-22-000065:notes:30]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of September 30, 2022 and July 1, 2022 and changes in contract liabilities for the three months ended September 30, 2022 and October 1, 2021 were not material.

[0000106040-22-000065:notes:31]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

[0000106040-22-000065:notes:32]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of September 30, 2022 was $26 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize substantially all of this amount as revenue within the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-22-000065:notes:33]
[same as prior period, unchanged from 0000106040-22-000040:notes:28]

[0000106040-22-000065:notes:34]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three months ended September 30, 2022, the Company sold trade accounts receivable aggregating $291 million. The Company did not sell any trade accounts receivable during the three months ended October 1, 2021. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. As of September 30, 2022 and July 1, 2022, the amount of factored receivables that remained outstanding was $291 million and $300 million, respectively.

[0000106040-22-000065:notes:35]
[same as prior period, unchanged from 0000106040-22-000040:notes:30]

[0000106040-22-000065:notes:36]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,809 |  |  | $ | 1,603 |  |
| Work-in-process | 1,130 |  |  | 1,162 |  |
| Finished goods | 923 |  |  | 873 |  |
| Total inventories | $ | 3,862 |  |  | $ | 3,638 |  |

[0000106040-22-000065:notes:37]
[same as prior period, unchanged from 0000106040-22-000040:notes:32]

[0000106040-22-000065:notes:38]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 269 |  |  | $ | 269 |  |
| Buildings and improvements | 1,945 |  |  | 1,920 |  |
| Machinery and equipment | 8,734 |  |  | 8,642 |  |
| Computer equipment and software | 499 |  |  | 494 |  |
| Furniture and fixtures | 54 |  |  | 54 |  |
| Construction-in-process | 642 |  |  | 591 |  |
| Property, plant and equipment, gross | 12,143 |  |  | 11,970 |  |
| Accumulated depreciation | (8,425) |  |  | (8,300) |  |
| Property, plant and equipment, net | $ | 3,718 |  |  | $ | 3,670 |  |

[0000106040-22-000065:notes:39]
Other Intangible assets

[0000106040-22-000065:notes:40]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Other Intangible assets: |  |  |  |
| Finite-lived intangible assets | $ | 5,715 |  |  | $ | 5,493 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,621) |  |  | (5,360) |  |
| Other Intangible assets, net | $ | 174 |  |  | $ | 213 |  |

[0000106040-22-000065:notes:41]
[same as prior period, unchanged from 0000106040-22-000040:notes:36]

[0000106040-22-000065:notes:42]
[same as prior period, unchanged from 0000106040-22-000040:notes:37]

[0000106040-22-000065:notes:43]
[same as prior period, unchanged from 0000106040-22-000040:notes:38]

[0000106040-22-000065:notes:44]
|  | Three Months Ended |  |  |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 345 |  |  | $ | 363 |  |  |  |  |  |  |  |
| Charges to operations | 32 |  |  | 40 |  |  |  |  |  |  |  |
| Utilization | (34) |  |  | (23) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | (3) |  |  | (10) |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 340 |  |  | $ | 370 |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:45]
[same as prior period, unchanged from 0000106040-22-000040:notes:40]

[0000106040-22-000065:notes:46]
|  | September 30,2022 |  | July 1,2022 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 144 |  |  | $ | 162 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 196 |  |  | 183 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 340 |  |  | $ | 345 |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:47]
[same as prior period, unchanged from 0000106040-22-000040:notes:42]

[0000106040-22-000065:notes:48]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 460 |  |  | $ | 659 |  |
| Non-current portion of unrecognized tax benefits | 453 |  |  | 477 |  |
| Other non-current liabilities | 629 |  |  | 643 |  |
| Total other liabilities | $ | 1,542 |  |  | $ | 1,779 |  |

[0000106040-22-000065:notes:49]
Accumulated other comprehensive loss

[0000106040-22-000065:notes:50]
Accumulated other comprehensive loss (“AOCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCI:

[0000106040-22-000065:notes:51]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at July 1, 2022 | $ | (11) |  |  | $ | (277) |  |  |  |  |  |  | $ | (266) |  |  | $ | (554) |  |
| Other comprehensive loss before reclassifications | — |  |  | (80) |  |  |  |  |  |  | (140) |  |  | (220) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 64 |  |  | 64 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 16 |  |  | 16 |  |
| Net current-period other comprehensive loss | — |  |  | (80) |  |  |  |  |  |  | (60) |  |  | (140) |  |
| Balance at September 30, 2022 | $ | (11) |  |  | $ | (357) |  |  |  |  |  |  | $ | (326) |  |  | $ | (694) |  |

[0000106040-22-000065:notes:52]
During the three months ended September 30, 2022, the amounts reclassified out of AOCI were losses related to foreign exchange contracts and interest rate swap contracts. Losses reclassified out of AOCI related to foreign exchange contracts were $62 million for the three months ended September 30, 2022 that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. Losses reclassified out of AOCI related to interest rate swap contracts were $2 million for the three months ended September 30, 2022 that were charged to Interest expense in the Condensed Consolidated Statements of Operations.
As of September 30, 2022, substantially all of existing net losses related to cash flow hedges recorded in AOCI are expected to be reclassified to earnings within the next twelve months. In addition, as of September 30, 2022, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-22-000065:notes:53]
[same as prior period, unchanged from 0000106040-22-000040:notes:48]

[0000106040-22-000065:notes:54]
[same as prior period, unchanged from 0000106040-22-000040:notes:49]

[0000106040-22-000065:notes:55]
[same as prior period, unchanged from 0000106040-22-000040:notes:50]

[0000106040-22-000065:notes:56]
[same as prior period, unchanged from 0000106040-22-000040:notes:51]

[0000106040-22-000065:notes:57]
[same as prior period, unchanged from 0000106040-22-000040:notes:52]

[0000106040-22-000065:notes:58]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of September 30, 2022 and July 1, 2022, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-22-000065:notes:59]
|  | September 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 322 |  |  | $ | — |  |  | $ | — |  |  | $ | 322 |  |
| Foreign exchange contracts | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Interest rate swap contracts | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total assets at fair value | $ | 322 |  |  | $ | 59 |  |  | $ | — |  |  | $ | 381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 329 |  |  | $ | — |  |  | $ | 329 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 329 |  |  | $ | — |  |  | $ | 329 |  |

[0000106040-22-000065:notes:60]
|  | July 1, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 266 |  |  | $ | — |  |  | $ | — |  |  | $ | 266 |  |
| Foreign exchange contracts | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Interest rate swap contracts | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets at fair value | $ | 266 |  |  | $ | 64 |  |  | $ | — |  |  | $ | 330 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 316 |  |  | $ | — |  |  | $ | 316 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 316 |  |  | $ | — |  |  | $ | 316 |  |

[0000106040-22-000065:notes:61]
[same as prior period, unchanged from 0000106040-22-000040:notes:56]

[0000106040-22-000065:notes:62]
[same as prior period, unchanged from 0000106040-22-000040:notes:57]

[0000106040-22-000065:notes:63]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2023 and the fourth quarter of 2022, respectively.

[0000106040-22-000065:notes:64]
|  | September 30, 2022 |  | July 1, 2022 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,097 |  |  | $ | 1,047 |  |  | $ | 1,048 |  |  | $ | 1,040 |  |
| 4.75% senior unsecured notes due 2026 | 2,291 |  |  | 2,134 |  |  | 2,291 |  |  | 2,205 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,693 |  |  | 2,634 |  |  | 2,693 |  |  | 2,621 |  |
| 2.85% senior unsecured notes due 2029 | 495 |  |  | 389 |  |  | 495 |  |  | 412 |  |
| 3.10% senior unsecured notes due 2032 | 495 |  |  | 342 |  |  | 495 |  |  | 389 |  |
| Total | $ | 7,071 |  |  | $ | 6,546 |  |  | $ | 7,022 |  |  | $ | 6,667 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-22-000065:notes:65]
Derivative Instruments and Hedging Activities
As of September 30, 2022, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments through February 2023, on a portion of its term loans.

[0000106040-22-000065:notes:66]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three months ended September 30, 2022 and October 1, 2021, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-22-000065:notes:67]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCI. For more information regarding cash flow hedges, see Part I, Item 1, Note 5, Supplemental Financial Statement Data - Accumulated other comprehensive loss, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000065:notes:68]
[same as prior period, unchanged from 0000106040-22-000040:notes:63]

[0000106040-22-000065:notes:69]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of September 30, 2022 and July 1, 2022, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-22-000065:notes:70]
Debt
Debt consisted of the following:

[0000106040-22-000065:notes:71]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Long-term debt | $ | 7,071 |  |  | $ | 7,022 |  |

[0000106040-22-000065:notes:72]
During the three months ended September 30, 2022, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). The terms of the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 requires the Company to comply with a leverage ratio financial covenant. As of September 30, 2022, the Company was in compliance with this financial covenant.

[0000106040-22-000065:notes:73]
As described in Note 2, Recent Accounting Pronouncements the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-22-000065:notes:74]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand and the Philippines. All pension and other post-retirement benefit plans outside of the Company’s Japan, Thailand and the Philippines defined benefit pension plans (the “Pension Plans”) are immaterial to the Condensed Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans assets is 2.5%.

[0000106040-22-000065:notes:75]
[same as prior period, unchanged from 0000106040-22-000040:notes:74]

[0000106040-22-000065:notes:76]
[same as prior period, unchanged from 0000106040-22-000040:notes:75]

[0000106040-22-000065:notes:77]
|  | September 30,2022 |  | July 1,2022 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 275 |  |  | $ | 294 |  |  |  |
| Fair value of plan assets at end of period | 177 |  |  | 189 |  |  |  |
| Unfunded status | $ | 98 |  |  | $ | 105 |  |  |  |

[0000106040-22-000065:notes:78]
[same as prior period, unchanged from 0000106040-22-000040:notes:77]

[0000106040-22-000065:notes:79]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 97 |  |  | 104 |  |
| Net amount recognized | $ | 98 |  |  | $ | 105 |  |

[0000106040-22-000065:notes:80]
Net periodic benefit costs were not material for the three months ended September 30, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-22-000065:notes:81]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-22-000065:notes:82]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-22-000065:notes:83]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-22-000065:notes:84]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 658 |  |  | 793 |  |
| Investment in Flash Partners | 158 |  |  | 166 |  |
| Investment in Flash Alliance | 229 |  |  | 243 |  |
| Investment in Flash Forward | 106 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,219 |  |  | $ | 1,396 |  |

[0000106040-22-000065:notes:85]
During the three months ended September 30, 2022 and October 1, 2021, the Company made net payments to Flash Ventures of $1.0 billion, and $1.2 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-22-000065:notes:86]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-22-000065:notes:87]
As of September 30, 2022 and July 1, 2022, the Company had account payable balances due to Flash Ventures of $295 million and $320 million, respectively.

[0000106040-22-000065:notes:88]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-22-000065:notes:89]
|  | September 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 493 |  |
| Operating lease guarantees | 1,684 |  |
| Inventory and prepayments | 1,022 |  |
| Maximum estimable loss exposure | $ | 3,925 |  |

[0000106040-22-000065:notes:90]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-22-000065:notes:91]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $203 million as follows: $182 million for the remaining nine months of 2023 and $21 million in 2024, to be credited against future wafer charges.

[0000106040-22-000065:notes:92]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-22-000065:notes:93]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-22-000065:notes:94]
Off-Balance Sheet Liabilities

[0000106040-22-000065:notes:95]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-22-000065:notes:96]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022.

[0000106040-22-000065:notes:97]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 243 |  |  | $ | 1,684 |  |

[0000106040-22-000065:notes:98]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022:

[0000106040-22-000065:notes:99]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2023 |  | $ | 371 |  |  | $ | 50 |  |  | $ | 421 |  |
| 2024 |  | 376 |  |  | 90 |  |  | 466 |  |
| 2025 |  | 203 |  |  | 82 |  |  | 285 |  |
| 2026 |  | 199 |  |  | 124 |  |  | 323 |  |
| 2027 |  | 53 |  |  | 106 |  |  | 159 |  |
| 2028 and thereafter |  | 3 |  |  | 27 |  |  | 30 |  |
| Total guarantee obligations |  | $ | 1,205 |  |  | $ | 479 |  |  | $ | 1,684 |  |

[0000106040-22-000065:notes:100]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-22-000065:notes:101]
Unis Venture

[0000106040-22-000065:notes:102]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three months ended October 1, 2021, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for September 30, 2022 and July 1, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-22-000065:notes:103]
[same as prior period, unchanged from 0000106040-22-000040:notes:104]

[0000106040-22-000065:notes:104]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of September 30, 2022:

[0000106040-22-000065:notes:105]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining nine months of 2023 | $ | 36 |  |  |  |  |  |  |  |  |  |
| 2024 | 46 |  |  |  |  |  |  |  |  |  |
| 2025 | 44 |  |  |  |  |  |  |  |  |  |
| 2026 | 44 |  |  |  |  |  |  |  |  |  |
| 2027 | 39 |  |  |  |  |  |  |  |  |  |
| Thereafter | 147 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 356 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 51 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 305 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 40 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 265 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 288 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.2 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.4 | % |  |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:106]
[same as prior period, unchanged from 0000106040-22-000040:notes:107]

[0000106040-22-000065:notes:107]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
|  | (in millions) |
| Cost of operating leases | $ | 14 |  |  | $ | 13 |  |  |  |  |  |
| Cash paid for operating leases | 14 |  |  | 12 |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 4 |  |  | 112 |  |  |  |  |  |

[0000106040-22-000065:notes:108]
[same as prior period, unchanged from 0000106040-22-000040:notes:109]

[0000106040-22-000065:notes:109]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of September 30, 2022, the Company had the following minimum long-term commitments:

[0000106040-22-000065:notes:110]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining nine months of 2023 |  | $ | 385 |  |
| 2024 |  | 325 |  |
| 2025 |  | 180 |  |
| 2026 |  | 53 |  |
| 2027 |  | 46 |  |
| Thereafter |  | 150 |  |
| Total |  | $ | 1,139 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-22-000065:notes:111]
[same as prior period, unchanged from 0000106040-22-000040:notes:112]

[0000106040-22-000065:notes:112]
[same as prior period, unchanged from 0000106040-22-000040:notes:113]

[0000106040-22-000065:notes:113]
|  | Three Months Ended |  |  |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 75 |  |  | $ | 67 |  |  |  |  |  |  |  |
| ESPP | 11 |  |  | 9 |  |  |  |  |  |  |  |
| Total | $ | 86 |  |  | $ | 76 |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:114]
|  | Three Months Ended |  |  |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Cost of revenue | $ | 14 |  |  | $ | 9 |  |  |  |  |  |  |  |
| Research and development | 39 |  |  | 40 |  |  |  |  |  |  |  |
| Selling, general and administrative | 33 |  |  | 27 |  |  |  |  |  |  |  |
| Subtotal | 86 |  |  | 76 |  |  |  |  |  |  |  |
| Tax benefit | (13) |  |  | (15) |  |  |  |  |  |  |  |
| Total | $ | 73 |  |  | $ | 61 |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:115]
[same as prior period, unchanged from 0000106040-22-000040:notes:116]

[0000106040-22-000065:notes:116]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of September 30, 2022:

[0000106040-22-000065:notes:117]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 655 |  |  | 2.6 |
| ESPP | 51 |  |  | 1.0 |
| Total unamortized compensation cost | $ | 706 |  |  |  |

[0000106040-22-000065:notes:118]
[same as prior period, unchanged from 0000106040-22-000040:notes:119]

[0000106040-22-000065:notes:119]
[same as prior period, unchanged from 0000106040-22-000040:notes:120]

[0000106040-22-000065:notes:120]
[same as prior period, unchanged from 0000106040-22-000040:notes:121]

[0000106040-22-000065:notes:121]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at September 30, 2022:

[0000106040-22-000065:notes:122]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at July 1, 2022 | 0.9 |  |  | $ | 66.76 |  |  | 0.54 |  |  |
| Canceled or expired | (0.5) |  |  | 84.39 |  |  |  |  |  |
| Options outstanding at September 30, 2022 | 0.4 |  |  | $ | 45.08 |  |  | 0.81 |  |  |

[0000106040-22-000065:notes:123]
[same as prior period, unchanged from 0000106040-22-000040:notes:124]

[0000106040-22-000065:notes:124]
[same as prior period, unchanged from 0000106040-22-000040:notes:125]

[0000106040-22-000065:notes:125]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | 52.89 |  |  |  |
| Granted | 4.5 |  |  | 43.79 |  |  |  |
| Vested | (4.3) |  |  | 53.28 |  |  | $ | 186 |  |
| Forfeited | (0.6) |  |  | 62.12 |  |  |  |
| RSUs and PSUs outstanding at September 30, 2022 | 15.0 |  |  | 49.71 |  |  |  |

[0000106040-22-000065:notes:126]
[same as prior period, unchanged from 0000106040-22-000040:notes:127]

[0000106040-22-000065:notes:127]
Stock Repurchase Program

[0000106040-22-000065:notes:128]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the three months ended September 30, 2022 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. Although the Company will reevaluate the repurchasing of common stock when appropriate, there can be no assurance if, when or at what level the Company may resume such activity. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of September 30, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-22-000065:notes:129]
[same as prior period, unchanged from 0000106040-22-000040:notes:129]

[0000106040-22-000065:notes:130]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax of 15% on corporations with three-year average annual adjusted financial statement income exceeding $1 billion. The corporate alternative minimum tax will not be effective for the Company until fiscal year 2024 and the Company is currently evaluating the potential effects of these legislative changes.

[0000106040-22-000065:notes:131]
[same as prior period, unchanged from 0000106040-22-000040:notes:130]

[0000106040-22-000065:notes:132]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
|  | ($ in millions) |
| Income before taxes | $ | 84 |  |  | $ | 704 |  |  |  |  |  |
| Income tax expense | 57 |  |  | 94 |  |  |  |  |  |
| Effective tax rate | 68 | % |  | 13 | % |  |  |  |  |

[0000106040-22-000065:notes:133]
Beginning in fiscal year 2023, the 2017 Act requires the Company to capitalize and amortize research and development expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of research and development expenses are included in the effective tax rate for the three months ended September 30, 2022. This impact, together with the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031 are the primary drivers of the difference between the effective tax rate for the three months ended September 30, 2022 and the U.S. Federal statutory rate of 21%.

[0000106040-22-000065:notes:134]
The primary drivers of the difference between the effective tax rate for the three months ended October 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand. In addition, the effective tax rate for the three months ended October 1, 2021 included the discrete effect of an increase to unrecognized tax benefits of $16 million as a result of ongoing discussions with various taxing authorities.

[0000106040-22-000065:notes:135]
[same as prior period, unchanged from 0000106040-22-000040:notes:135]

[0000106040-22-000065:notes:136]
[same as prior period, unchanged from 0000106040-22-000040:notes:136]

[0000106040-22-000065:notes:137]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 30, 2022 (in millions):

[0000106040-22-000065:notes:138]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross decreases related to prior year tax positions | (18) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at September 30, 2022 | $ | 1,026 |  |

[0000106040-22-000065:notes:139]
As of September 30, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.03 billion. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of September 30, 2022 was $264 million. Of these amounts, approximately $1.15 billion could result in potential cash payments.

[0000106040-22-000065:notes:140]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for years 2008 through 2015. In September 2018 and March 2019, the Company filed petitions with the U.S. Tax Court covering years 2008 through 2012, for which it had received statutory notices of deficiency, while years 2013 through 2015 remain in the jurisdiction of the IRS’s Examination function. The IRS has filed various Amendments to Answer with the U.S. Tax Court which, together with the notices of proposed adjustments, would result in additional federal income tax liabilities totaling approximately $1.6 billion and penalties totaling $449 million with respect to years 2008 through 2015. In May 2022, the Company and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. Based on the tentative settlement for resolution, the Company expects to pay tax and interest totaling approximately $600 million to $700 million, which the Company expects to be partially offset by future reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 million to $150 million. While the Company continues to work with the IRS to come to a final agreement on the federal tax and interest calculations, the Company is uncertain as to when a final agreement will be reached and the exact timing of when any payments will be made. However, the Company believes it is reasonably likely that these payments may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest in Income taxes payable on its Condensed Consolidated Balance Sheets as of September 30, 2022. This classification and amount may be subject to change in the next twelve months depending on when the Company is able to reach a final agreement with the IRS.

[0000106040-22-000065:notes:141]
[same as prior period, unchanged from 0000106040-22-000040:notes:141]


## us-gaap:EarningsPerShareTextBlock

[0000106040-22-000065:notes:142]
Net Income Per Common Share 
The following table presents the computation of basic and diluted income per common share:

[0000106040-22-000065:notes:143]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  |  | October 1,2021 |  |  |  |  |
|  | (in millions, except per share data) |
| Net income | $ | 27 |  |  |  | $ | 610 |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 316 |  |  |  | 310 |  |  |  |  |  |
| Employee stock options, RSUs, PSUs, and ESPP | 3 |  |  |  | 6 |  |  |  |  |  |
| Diluted | 319 |  |  |  | 316 |  |  |  |  |  |
| Income per common share |  |  |  |  |  |  |  |  |
| Basic | $ | 0.09 |  |  |  | $ | 1.97 |  |  |  |  |  |
| Diluted | $ | 0.08 |  |  |  | $ | 1.93 |  |  |  |  |  |
| Anti-dilutive potential common shares excluded | 8 |  |  |  | 1 |  |  |  |  |  |

[0000106040-22-000065:notes:144]
The Company computes basic income per common share using Net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using Net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended September 30, 2022 and October 1, 2021, the Company excluded common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-22-000065:notes:145]
[same as prior period, unchanged from 0000106040-22-000040:notes:145]

[0000106040-22-000065:notes:146]
[same as prior period, unchanged from 0000106040-22-000040:notes:146]

[0000106040-22-000065:notes:147]
|  | Three Months Ended |  |  |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 24 |  |  | $ | 15 |  |  |  |  |  |  |  |
| Asset impairments and losses on disposal of assets | — |  |  | 3 |  |  |  |  |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 24 |  |  | $ | 18 |  |  |  |  |  |  |  |

[0000106040-22-000065:notes:148]
The following table presents an analysis of the components of these activities against the reserve during the three months ended September 30, 2022:

[0000106040-22-000065:notes:149]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 1, 2022 | $ | 17 |  |  |  |  |  |
| Charges | 24 |  |  |  |  |  |
| Cash payments | (28) |  |  |  |  |  |
| Accrual balance at September 30, 2022 | $ | 13 |  |  |  |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-22-000065:notes:150]
Legal Proceedings
Tax

[0000106040-22-000065:notes:151]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-22-000065:notes:152]
Other Matters

[0000106040-22-000065:notes:153]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
