# WDC note change history — 0000106040-22-000040 → 0000106040-22-000065


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:
  (was, 2022-05-04, similarity 0.8711):
[0000106040-22-000040:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 1, 2022 and July 2, 2021:

- changed (2022-11-02):
[0000106040-22-000065:note_history:2]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 658 |  |  | 793 |  |
| Investment in Flash Partners | 158 |  |  | 166 |  |
| Investment in Flash Alliance | 229 |  |  | 243 |  |
| Investment in Flash Forward | 106 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,219 |  |  | $ | 1,396 |  |
  (was, 2022-05-04, similarity 0.986):
[0000106040-22-000040:note_history:2]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 51 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 130 |  |  | 213 |  |
| Notes receivable, Flash Forward | 666 |  |  | 561 |  |
| Investment in Flash Partners | 182 |  |  | 199 |  |
| Investment in Flash Alliance | 266 |  |  | 293 |  |
| Investment in Flash Forward | 122 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,417 |  |  | $ | 1,586 |  |

- added (2022-11-02):
[0000106040-22-000065:note_history:3]
During the three months ended September 30, 2022 and October 1, 2021, the Company made net payments to Flash Ventures of $1.0 billion, and $1.2 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2022-11-02):
[0000106040-22-000065:note_history:4]
As of September 30, 2022 and July 1, 2022, the Company had account payable balances due to Flash Ventures of $295 million and $320 million, respectively.
  (was, 2022-05-04, similarity 0.96):
[0000106040-22-000040:note_history:4]
As of April 1, 2022 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $396 million and $398 million, respectively.

- added (2022-11-02):
[0000106040-22-000065:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 30, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2022-11-02):
[0000106040-22-000065:note_history:6]
|  | September 30,2022 |
|  | (in millions) |
| Notes receivable | $ | 726 |  |
| Equity investments | 493 |  |
| Operating lease guarantees | 1,684 |  |
| Inventory and prepayments | 1,022 |  |
| Maximum estimable loss exposure | $ | 3,925 |  |

- changed (2022-11-02):
[0000106040-22-000065:note_history:7]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $203 million as follows: $182 million for the remaining nine months of 2023 and $21 million in 2024, to be credited against future wafer charges.
  (was, 2022-05-04, similarity 0.8978):
[0000106040-22-000040:note_history:7]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments of $482 million as follows: $142 million in fiscal year 2022, $314 million in fiscal year 2023 and $26 million in fiscal year 2024, to be credited against future wafer charges.

- changed (2022-11-02):
[0000106040-22-000065:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022.
  (was, 2022-05-04, similarity 0.9727):
[0000106040-22-000040:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022.

- changed (2022-11-02):
[0000106040-22-000065:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 30, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 30, 2022:
  (was, 2022-05-04, similarity 0.9612):
[0000106040-22-000040:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 1, 2022 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 1, 2022:

- changed (2022-11-02):
[0000106040-22-000065:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2023 |  | $ | 371 |  |  | $ | 50 |  |  | $ | 421 |  |
| 2024 |  | 376 |  |  | 90 |  |  | 466 |  |
| 2025 |  | 203 |  |  | 82 |  |  | 285 |  |
| 2026 |  | 199 |  |  | 124 |  |  | 323 |  |
| 2027 |  | 53 |  |  | 106 |  |  | 159 |  |
| 2028 and thereafter |  | 3 |  |  | 27 |  |  | 30 |  |
| Total guarantee obligations |  | $ | 1,205 |  |  | $ | 479 |  |  | $ | 1,684 |  |
  (was, 2022-05-04, similarity 0.671):
[0000106040-22-000040:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2022 |  | $ | 150 |  |  | $ | — |  |  | $ | 150 |  |
| 2023 |  | 516 |  |  | 59 |  |  | 575 |  |
| 2024 |  | 369 |  |  | 106 |  |  | 475 |  |
| 2025 |  | 181 |  |  | 97 |  |  | 278 |  |
| 2026 |  | 153 |  |  | 146 |  |  | 299 |  |
| Thereafter |  | 27 |  |  | 93 |  |  | 120 |  |
| Total guarantee obligations |  | $ | 1,396 |  |  | $ | 501 |  |  | $ | 1,897 |  |

- changed (2022-11-02):
[0000106040-22-000065:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 30, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2022-05-04, similarity 0.9474):
[0000106040-22-000040:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 1, 2022, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2022-11-02):
[0000106040-22-000065:note_history:12]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 30, 2022, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three months ended October 1, 2021, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for September 30, 2022 and July 1, 2022, respectively.
  (was, 2022-05-04, similarity 0.9211):
[0000106040-22-000040:note_history:12]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 2, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 5% of Accounts receivable, net for April 1, 2022 and July 2, 2021, respectively.

- removed (2022-11-02):
[0000106040-22-000040:note_history:13]
During the three and nine months ended April 1, 2022 and during the three and nine months ended April 2, 2021, the Company made net payments to Flash Ventures of $1.1 billion and $3.4 billion, and $1.1 billion and $3.3 billion, respectively, for purchased flash-based memory wafers and net loans.

- removed (2022-11-02):
[0000106040-22-000040:note_history:14]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 1, 2022, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2022-11-02):
[0000106040-22-000040:note_history:15]
|  | April 1,2022 |
|  | (in millions) |
| Notes receivable | $ | 847 |  |
| Equity investments | 570 |  |
| Operating lease guarantees | 1,897 |  |
| Inventory and prepayments | 983 |  |
| Maximum estimable loss exposure | $ | 4,297 |  |

- removed (2022-11-02):
[0000106040-22-000040:note_history:16]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company recovered $7 million related to this incident from insurance carriers. During the three and nine months ended April 2, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from insurance carriers. Recoveries related to the incident were recorded in Cost of revenue.

- removed (2022-11-02):
[0000106040-22-000040:note_history:17]
In February 2022, contamination of certain material used in manufacturing processes occurred at both the Yokkaichi and Kitakami, Japan fabrication facilities, resulting in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During the three and nine months ended April 1, 2022, the Company incurred charges of $203 million related to this contamination incident that were recorded in Cost of revenue, which primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs. The Company is evaluating potential options for recovery.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:18]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.
  (was, 2022-05-04, similarity 0.9627):
[0000106040-22-000040:note_history:18]
For disclosures regarding statutory notices of deficiency issued by the IRS in June 2018 and December 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:19]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 30, 2022 (in millions):
  (was, 2022-05-04, similarity 0.9542):
[0000106040-22-000040:note_history:19]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended April 1, 2022 (in millions):

- changed (2022-11-02):
[0000106040-22-000065:note_history:20]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross decreases related to prior year tax positions | (18) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at September 30, 2022 | $ | 1,026 |  |
  (was, 2022-05-04, similarity 0.8307):
[0000106040-22-000040:note_history:20]
| Accrual balance at July 2, 2021 | $ | 748 |  |
| Gross increases related to current year tax positions | 7 |  |
| Gross increases related to prior year tax positions | 216 |  |
| Gross decreases related to prior year tax positions | (57) |  |
| Settlements | (2) |  |
| Lapse of statute of limitations | (5) |  |
| Accrual balance at April 1, 2022 | $ | 907 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-11-02):
[0000106040-22-000065:note_history:21]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in memory technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

- changed (2022-11-02):
[0000106040-22-000065:note_history:22]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2022-05-04, similarity 0.9938):
[0000106040-22-000040:note_history:22]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 2, 2021. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 2, 2021. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2022-11-02):
[0000106040-22-000065:note_history:23]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, which ends on June 30, 2023, and 2022, which ended on July 1, 2022, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2022-05-04, similarity 0.9947):
[0000106040-22-000040:note_history:23]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2022, which ends on July 1, 2022, and 2021, which ended on July 2, 2021, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- added (2022-11-02):
[0000106040-22-000065:note_history:24]
Segment Reporting

- added (2022-11-02):
[0000106040-22-000065:note_history:25]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.

- added (2022-11-02):
[0000106040-22-000065:note_history:26]
The Company’s Chief Operating Decision Maker (“CODM”) evaluates performance of the Company and makes decisions regarding allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are not available or reviewed by the CODM to evaluate the performance of or to allocate resources to the segments.

- changed (2022-11-02):
[0000106040-22-000065:note_history:27]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of current macroeconomic conditions. However, actual results could differ materially from these estimates.
  (was, 2022-05-04, similarity 0.6241):
[0000106040-22-000040:note_history:27]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activities can resume.

- removed (2022-11-02):
[0000106040-22-000040:note_history:28]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:29]
Debt
Debt consisted of the following:
  (was, 2022-05-04, similarity 0.7184):
[0000106040-22-000040:note_history:29]
Debt
Debt consisted of the following as of April 1, 2022 and July 2, 2021:

- changed (2022-11-02):
[0000106040-22-000065:note_history:30]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Long-term debt | $ | 7,071 |  |  | $ | 7,022 |  |
  (was, 2022-05-04, similarity 0.7604):
[0000106040-22-000040:note_history:30]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,850 |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,250 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (88) |  |  | (100) |  |
| Subtotal | 7,162 |  |  | 8,725 |  |
| Less current portion of long-term debt | (75) |  |  | (251) |  |
| Long-term debt | $ | 7,087 |  |  | $ | 8,474 |  |

- added (2022-11-02):
[0000106040-22-000065:note_history:31]
During the three months ended September 30, 2022, the Company drew and repaid $300 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). The terms of the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 requires the Company to comply with a leverage ratio financial covenant. As of September 30, 2022, the Company was in compliance with this financial covenant.

- added (2022-11-02):
[0000106040-22-000065:note_history:32]
As described in Note 2, Recent Accounting Pronouncements the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.

- removed (2022-11-02):
[0000106040-22-000040:note_history:33]
In October 2021, the Company voluntarily prepaid the remaining principal balance of its Term Loan B-4 in accordance with its terms.

- removed (2022-11-02):
[0000106040-22-000040:note_history:34]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates.

- removed (2022-11-02):
[0000106040-22-000040:note_history:35]
During the six months ended December 31, 2021, the Company made scheduled principal payments of $126 million and voluntary prepayments of  $1.21 billion on the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.00 billion. Payments were made using proceeds from the issuance of the 2029 Notes and the 2032 Notes and available cash on hand. On January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.00 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace its previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace its previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement are the senior unsecured obligations of the Company and do not benefit from any collateral or subsidiary guarantees.

- removed (2022-11-02):
[0000106040-22-000040:note_history:36]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 amortizes in quarterly installments of $19 million for each of the first four quarters beginning the quarter ending July 1, 2022 through the quarter ending March 31, 2023; $38 million per quarter thereafter; and the remaining balance payable January 7, 2027.

- removed (2022-11-02):
[0000106040-22-000040:note_history:37]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

- removed (2022-11-02):
[0000106040-22-000040:note_history:38]
Issuance costs and discounts are amortized to interest expense over their respective terms, and as of April 1, 2022, unamortized issuance costs and discounts were $5 million for the 2029 Notes, $6 million for the 2032 Notes, and $7 million for the Term Loan A-2.
In accordance with the Loan Agreement, the Company is required to comply with a leverage ratio financial covenant. As of April 1, 2022, the Company was in compliance with this financial covenant.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:39]
Debt consisted of the following:
  (was, 2022-05-04, similarity 0.6882):
[0000106040-22-000040:note_history:39]
Debt consisted of the following as of April 1, 2022 and July 2, 2021:

- changed (2022-11-02):
[0000106040-22-000065:note_history:40]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (29) |  |  | (78) |  |
| Long-term debt | $ | 7,071 |  |  | $ | 7,022 |  |
  (was, 2022-05-04, similarity 0.7604):
[0000106040-22-000040:note_history:40]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | — |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,850 |  |  | — |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,250 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (88) |  |  | (100) |  |
| Subtotal | 7,162 |  |  | 8,725 |  |
| Less current portion of long-term debt | (75) |  |  | (251) |  |
| Long-term debt | $ | 7,087 |  |  | $ | 8,474 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:41]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:
  (was, 2022-05-04, similarity 0.8711):
[0000106040-22-000040:note_history:41]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 1, 2022 and July 2, 2021:

- changed (2022-11-02):
[0000106040-22-000065:note_history:42]
|  | September 30,2022 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 658 |  |  | 793 |  |
| Investment in Flash Partners | 158 |  |  | 166 |  |
| Investment in Flash Alliance | 229 |  |  | 243 |  |
| Investment in Flash Forward | 106 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,219 |  |  | $ | 1,396 |  |
  (was, 2022-05-04, similarity 0.986):
[0000106040-22-000040:note_history:42]
|  | April 1,2022 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 51 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 130 |  |  | 213 |  |
| Notes receivable, Flash Forward | 666 |  |  | 561 |  |
| Investment in Flash Partners | 182 |  |  | 199 |  |
| Investment in Flash Alliance | 266 |  |  | 293 |  |
| Investment in Flash Forward | 122 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,417 |  |  | $ | 1,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000106040-22-000065:note_history:43]
|  | Three Months Ended |  |
|  | September 30,2022 |  | October 1,2021 |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |
| Cloud | $ | 1,829 |  |  | $ | 2,225 |  |  |
| Client | 1,229 |  |  | 1,853 |  |  |
| Consumer | 678 |  |  | 973 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |
| Revenue by Geography |  |  |  |  |
| Asia | $ | 1,686 |  |  | $ | 2,675 |  |  |
| Americas | 1,423 |  |  | 1,614 |  |  |
| Europe, Middle East and Africa | 627 |  |  | 762 |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |
  (was, 2022-05-04, similarity 0.7373):
[0000106040-22-000040:note_history:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,774 |  |  | $ | 1,423 |  |  | $ | 5,919 |  |  | $ | 3,728 |  |  |  |
| Client | 1,732 |  |  | 1,767 |  |  | 5,439 |  |  | 5,386 |  |  |  |
| Consumer | 875 |  |  | 947 |  |  | 2,907 |  |  | 2,888 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Asia | $ | 2,400 |  |  | $ | 2,215 |  |  | $ | 7,685 |  |  | $ | 6,702 |  |  |  |
| Americas | 1,377 |  |  | 1,009 |  |  | 4,398 |  |  | 3,033 |  |  |  |
| Europe, Middle East and Africa | 604 |  |  | 913 |  |  | 2,182 |  |  | 2,267 |  |  |  |
| Total Revenue | $ | 4,381 |  |  | $ | 4,137 |  |  | $ | 14,265 |  |  | $ | 12,002 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-02):
[0000106040-22-000065:note_history:44]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 30, 2022 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of September 30, 2022 and July 1, 2022 and changes in contract liabilities for the three months ended September 30, 2022 and October 1, 2021 were not material.

- changed (2022-11-02):
[0000106040-22-000065:note_history:45]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.
  (was, 2022-05-04, similarity 0.6217):
[0000106040-22-000040:note_history:45]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 1, 2022 and July 2, 2021 as well as the related amortization for the three and nine months ended April 1, 2022 and April 2, 2021 were not material.

- changed (2022-11-02):
[0000106040-22-000065:note_history:46]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of September 30, 2022 was $26 million, which is mainly attributable to the functional IP license and professional service arrangements. The Company expects to recognize substantially all of this amount as revenue within the next twelve months.
  (was, 2022-05-04, similarity 0.7188):
[0000106040-22-000040:note_history:46]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 1, 2022 was $42 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $10 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $2 million in fiscal 2024 and thereafter.

- removed (2022-11-02):
[0000106040-22-000040:note_history:47]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 1, 2022 or July 2, 2021.

- removed (2022-11-02):
[0000106040-22-000040:note_history:48]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 1, 2022 and July 2, 2021, contract liabilities were not material.
