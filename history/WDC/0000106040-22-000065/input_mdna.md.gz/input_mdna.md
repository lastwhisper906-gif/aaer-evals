# WDC MD&A — 0000106040-22-000065


## mdna

[0000106040-22-000065:mdna:1]
[same as prior period, unchanged from 0000106040-22-000040:mdna:1]

[0000106040-22-000065:mdna:2]
[same as prior period, unchanged from 0000106040-22-000040:mdna:2]

[0000106040-22-000065:mdna:3]
[same as prior period, unchanged from 0000106040-22-000040:mdna:3]

[0000106040-22-000065:mdna:4]
We are on a mission to unlock the potential of data by harnessing the possibility to use it. We are a leading developer, manufacturer, and provider of data storage devices based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated business units driving advancements in NAND flash and magnetic recording technologies, we create and drive innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-22-000065:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, which ends on June 30, 2023, and 2022, which ended on July 1, 2022, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-22-000065:mdna:6]
[same as prior period, unchanged from 0000106040-22-000040:mdna:6]

[0000106040-22-000065:mdna:7]
Strategic Alternatives

[0000106040-22-000065:mdna:8]
In June 2022, we announced that we are reviewing potential strategic alternatives aimed at further optimizing long-term value for stockholders. The Executive Committee of our Board of Directors is overseeing the assessment process and evaluating a range of alternatives, including options for separating our Flash and HDD business units. In conjunction with that review process, we announced that we had entered into a letter agreement with Elliott Investment Management L.P., which had disclosed in May 2022 a $1 billion investment in our Company and called for a full strategic review of our business. As of September 30, 2022, we are still actively working with financial advisors and our legal counsel in this strategic review process.

[0000106040-22-000065:mdna:9]
[same as prior period, unchanged from 0000106040-22-000040:mdna:9]

[0000106040-22-000065:mdna:10]
As previously disclosed, we have received statutory notices of deficiency and notices of proposed adjustments from the Internal Revenue Service (“IRS”) with respect to 2008 through 2015. During 2022, new information became available which required us to re-measure our unrecognized tax benefits for this IRS matter. Additionally, during 2022, we and the IRS tentatively reached a settlement for resolving this matter. Additional information is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 13, Income Tax Expense, of the Notes to the Condensed Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity-Unrecognized Tax Benefits” section below.

[0000106040-22-000065:mdna:11]
Operational and COVID-19 Pandemic Update

[0000106040-22-000065:mdna:12]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry are experiencing a supply-demand imbalance, which has negatively impacted pricing, particularly in Flash and is expected to result in reduced shipments and increased absorption charges in HDD in future quarters. However, we believe digital transformation will continue to drive long-term growth for data storage across all three of our end markets.

[0000106040-22-000065:mdna:13]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. Our BiCS5 based products continue to play a significant role in driving top line results across our end markets. Additionally, hard drive products utilizing OptiNAND and shingled magnetic recording (“SMR”) technologies have

[0000106040-22-000065:mdna:14]
commenced commercial shipments and our latest 26-terabyte SMR drives are undergoing qualifications at multiple cloud and OEM customers. We continued commercial shipment of consumer flash devices based on our next generation 3D-flash technology, but are pushing out our BiCS6 transition as compared to prior targets to reduce our capital expenditures for 2023 in light of market conditions. We are also aware of the ongoing trends in the HDD Client market as PCs shift from using HDD to Flash technology and as a result, we have and are still undergoing actions to restructure our HDD manufacturing footprint to reflect this market dynamic, including a sharp reduction in our client hard drive production capacity of approximately 40%.

[0000106040-22-000065:mdna:15]
The COVID-19 environment remains dynamic with outbreaks in various geographies. The responses to COVID-19 taken by ourselves and others in the supply chain have contributed to increases in the costs of their services which in turn impacted our operations, but these costs have now been normalized in our operating results.

[0000106040-22-000065:mdna:16]
We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “Adverse global or regional conditions could harm our business,” “The COVID-19 pandemic could negatively affect our business” and “We are dependent on a limited number of qualified suppliers who provide critical services, materials or components, and a disruption in our supply chain could negatively affect our business” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended July 1, 2022 for more information regarding the risks we face as a result of macroeconomic conditions, the COVID-19 pandemic and supply chain disruptions.

[0000106040-22-000065:mdna:17]
[same as prior period, unchanged from 0000106040-22-000040:mdna:25]

[0000106040-22-000065:mdna:18]
[same as prior period, unchanged from 0000106040-22-000040:mdna:26]

[0000106040-22-000065:mdna:19]
38

[0000106040-22-000065:mdna:20]
[same as prior period, unchanged from 0000106040-22-000040:mdna:27]

[0000106040-22-000065:mdna:21]
First Quarter Overview

[0000106040-22-000065:mdna:22]
[same as prior period, unchanged from 0000106040-22-000040:mdna:29]

[0000106040-22-000065:mdna:23]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 3,736 |  |  | 100.0 | % |  | $ | 5,051 |  |  | 100.0 | % |  | $ | (1,315) |  |  | (26) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,755 |  |  | 73.7 |  |  | 3,386 |  |  | 67.0 |  |  | (631) |  |  | (19) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 981 |  |  | 26.3 |  |  | 1,665 |  |  | 33.0 |  |  | (684) |  |  | (41) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 552 |  |  | 14.8 |  |  | 578 |  |  | 11.4 |  |  | (26) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 247 |  |  | 6.6 |  |  | 291 |  |  | 5.8 |  |  | (44) |  |  | (15) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 24 |  |  | 0.6 |  |  | 18 |  |  | 0.4 |  |  | 6 |  |  | 33 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 823 |  |  | 22.0 |  |  | 887 |  |  | 17.6 |  |  | (64) |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 158 |  |  | 4.2 |  |  | 778 |  |  | 15.4 |  |  | (620) |  |  | (80) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | 0.1 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (70) |  |  | (1.9) |  |  | (78) |  |  | (1.5) |  |  | 8 |  |  | (10) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (6) |  |  | (0.2) |  |  | 2 |  |  | — |  |  | (8) |  |  | (400) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (74) |  |  | (2.0) |  |  | (74) |  |  | (1.5) |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 84 |  |  | 2.2 |  |  | 704 |  |  | 13.9 |  |  | (620) |  |  | (88) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 57 |  |  | 1.5 |  |  | 94 |  |  | 1.9 |  |  | (37) |  |  | (39) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 27 |  |  | 0.7 | % |  | $ | 610 |  |  | 12.1 | % |  | $ | (583) |  |  | (96) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-22-000065:mdna:24]
[same as prior period, unchanged from 0000106040-22-000040:mdna:31]

[0000106040-22-000065:mdna:25]
[same as prior period, unchanged from 0000106040-22-000040:mdna:35]

[0000106040-22-000065:mdna:26]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
|  | ($ in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,722 |  |  | $ | 2,490 |  |  |  |  |  |
| HDD | 2,014 |  |  | 2,561 |  |  |  |  |  |
| Total net revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 422 |  |  | $ | 921 |  |  |  |  |  |
| HDD | 574 |  |  | 792 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (14) |  |  | (9) |  |  |  |  |  |
| Amortization of acquired intangible assets | (1) |  |  | (39) |  |  |  |  |  |
| Total unallocated corporate items | (15) |  |  | (48) |  |  |  |  |  |
| Consolidated gross profit | $ | 981 |  |  | $ | 1,665 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 24.5 | % |  | 37.0 | % |  |  |  |  |
| HDD | 28.5 | % |  | 30.9 | % |  |  |  |  |
| Consolidated gross margin | 26.3 | % |  | 33.0 | % |  |  |  |  |

[0000106040-22-000065:mdna:27]
[same as prior period, unchanged from 0000106040-22-000040:mdna:34]

[0000106040-22-000065:mdna:28]
The following table sets forth for the periods presented, summary information regarding our disaggregated revenue:

[0000106040-22-000065:mdna:29]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |
|  | (in millions) |  |  |
| Revenue by End Market |  |  |  |  |  |
| Cloud | $ | 1,829 |  |  | $ | 2,225 |  |  |  |
| Client | 1,229 |  |  | 1,853 |  |  |  |
| Consumer | 678 |  |  | 973 |  |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |  |
| Revenue by Geography |  |  |  |  |  |
| Asia | $ | 1,686 |  |  | $ | 2,675 |  |  |  |
| Americas | 1,423 |  |  | 1,614 |  |  |  |
| Europe, Middle East and Africa | 627 |  |  | 762 |  |  |  |
| Total Revenue | $ | 3,736 |  |  | $ | 5,051 |  |  |  |

[0000106040-22-000065:mdna:30]
[same as prior period, unchanged from 0000106040-22-000040:mdna:40]

[0000106040-22-000065:mdna:31]
Comparison of Three Months Ended September 30, 2022 to Three Months Ended October 1, 2021

[0000106040-22-000065:mdna:32]
The decrease in consolidated net revenue for the three months ended September 30, 2022 from the comparable period in the prior year reflects decreases in exabytes shipments of Flash and HDD sold as certain customers reduced purchases as they adjusted their production levels and right-sized their inventories. Revenue also declined as a result of lower average selling prices. These items are further discussed below in our discussion by segment.

[0000106040-22-000065:mdna:33]
Flash revenue decreased 31% for the three months ended September 30, 2022 from the comparable period in the prior year, primarily driven by a 26% decline in the average selling price with the remainder driven by a decrease in exabytes sold. The decline in average selling price was primarily due to pricing pressure caused by macroeconomic headwinds and a supply-demand imbalance in the current period. The decrease in exabytes sold reflected customers reducing purchases as they adjusted their production levels and right-sized their inventories.

[0000106040-22-000065:mdna:34]
HDD revenue decreased 21% for the three months ended September 30, 2022 from the comparable period in the prior year, primarily driven by a 12% decrease in exabytes sold with the remainder driven by a decline in the average selling price. The decline in exabytes sold was spread evenly across customers in our cloud, client, and consumer end markets due to the macroeconomic pressures noted earlier and our end customers right-sizing their inventories. The decline in the average selling price largely reflected the shift in mix to higher capacity drives.

[0000106040-22-000065:mdna:35]
The decrease in Cloud revenue for the three months ended September 30, 2022 from the comparable period in the prior year reflected declines in both Flash and HDD capacity enterprise drives as customers reduced purchases to right-size their inventories. In Client, the decrease in revenue for the three months ended September 30, 2022 from the comparable period in the prior year resulted primarily from a decline in Flash revenue as a result of lower pricing, while a reduction in purchases by PC OEMs to adjust their inventories to current production levels also contributed to the revenue decline. In Consumer, the decrease in revenue for the three months ended September 30, 2022 from the comparable period in the prior year reflected lower Flash pricing and lower retail HDD shipments.

[0000106040-22-000065:mdna:36]
The changes in net revenue by geography for the three months ended September 30, 2022 from the comparable period in the prior year reflected a larger decline in Asia from lower Client revenue from OEMs in this region as well as routine variations in the mix of business.

[0000106040-22-000065:mdna:37]
Our top 10 customers accounted for 52% of our net revenue for the three months ended September 30, 2022, compared to 43% of our net revenue for the three months ended October 1, 2021. For each of the three months ended September 30, 2022 and October 1, 2021, no single customer accounted for 10% or more of our net revenue.

[0000106040-22-000065:mdna:38]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 19% of gross revenue for the three months ended September 30, 2022, and 18% of gross revenue for the three months ended October 1, 2021. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-22-000065:mdna:39]
[same as prior period, unchanged from 0000106040-22-000040:mdna:52]

[0000106040-22-000065:mdna:40]
Consolidated gross profit decreased by $684 million for the three months ended September 30, 2022 from the comparable period in the prior year, which reflects the decrease in revenue in both Flash and HDD. Consolidated gross margin decreased 6.7 percentage points for the three months ended September 30, 2022 from the comparable period in the prior year, which primarily reflects lower average price per gigabyte in Flash and HDD, partially offset by cost reductions as mix shifted to higher capacity drives. Flash and HDD gross margin decreased by 12.5 and 2.4 percentage points year over year, respectively, each reflecting the lower average price per gigabyte, partially offset by cost reductions as mix shifted to higher capacity drives.

[0000106040-22-000065:mdna:41]
[same as prior period, unchanged from 0000106040-22-000040:mdna:55]

[0000106040-22-000065:mdna:42]
Research and development (“R&D”) expense decreased $26 million for the three months ended September 30, 2022 from the comparable period in the prior year. The decrease was primarily due to a reduction in variable compensation expenses.

[0000106040-22-000065:mdna:43]
Selling, general and administrative (“SG&A”) expense decreased $44 million for the three months ended September 30, 2022 from the comparable period in the prior year. The decline was primarily driven by a reduction in expenses related to outside services, compensation and benefits, and material use as we took actions to reduce expenses in the current environment.

[0000106040-22-000065:mdna:44]
Employee termination, asset impairment and other charges of $24 million for the three months ended September 30, 2022 reflects restructuring actions initiated in the current year to adjust our cost structure to align with the current demand environment. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment, and Other Charges of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000065:mdna:45]
[same as prior period, unchanged from 0000106040-22-000040:mdna:59]

[0000106040-22-000065:mdna:46]
Total interest and other expense, net for the three months ended September 30, 2022 was flat compared to the prior year due to lower interest expense primarily resulting from the pay-down of principal on our debt, offset by higher losses on foreign currency transactions.

[0000106040-22-000065:mdna:47]
[same as prior period, unchanged from 0000106040-22-000040:mdna:62]

[0000106040-22-000065:mdna:48]
[same as prior period, unchanged from 0000106040-22-000040:mdna:63]

[0000106040-22-000065:mdna:49]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax of 15% on corporations with three-year average annual adjusted financial statement income exceeding $1 billion. The corporate alternative minimum tax will not be effective for us until fiscal year 2024. We are currently evaluating the potential effects of these legislative changes.

[0000106040-22-000065:mdna:50]
[same as prior period, unchanged from 0000106040-22-000040:mdna:64]

[0000106040-22-000065:mdna:51]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
|  | ($ in millions) |
| Income before taxes | $ | 84 |  |  | $ | 704 |  |  |  |  |  |
| Income tax expense | 57 |  |  | 94 |  |  |  |  |  |
| Effective tax rate | 68 | % |  | 13 | % |  |  |  |  |

[0000106040-22-000065:mdna:52]
Beginning in fiscal year 2023, the 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of research and development expenses are included in the effective tax rate for the three months ended September 30, 2022. This impact, together with the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031 are the primary drivers of the difference between the effective tax rate for the three months ended September 30, 2022 and the U.S. Federal statutory rate of 21%.

[0000106040-22-000065:mdna:53]
The primary drivers of the difference between the effective tax rate for the three months ended October 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand. In addition, the effective tax rate for the three months ended October 1, 2021 included the discrete effect of an increase to unrecognized tax benefits of $16 million as a result of ongoing discussions with various taxing authorities.

[0000106040-22-000065:mdna:54]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in the year incurred, which, as described above, increased our effective tax rate for the three months ended September 30, 2022 and is expected to materially increase our effective tax rate and taxes paid, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-22-000065:mdna:55]
[same as prior period, unchanged from 0000106040-22-000040:mdna:70]

[0000106040-22-000065:mdna:56]
[same as prior period, unchanged from 0000106040-22-000040:mdna:71]

[0000106040-22-000065:mdna:57]
[same as prior period, unchanged from 0000106040-22-000040:mdna:72]

[0000106040-22-000065:mdna:58]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 6 |  |  | $ | 521 |  |  |  |
| Investing activities | (224) |  |  | (312) |  |  |  |
| Financing activities | (50) |  |  | (289) |  |  |  |
| Effect of exchange rate changes on cash | (10) |  |  | — |  |  |  |
| Net decrease in cash and cash equivalents | $ | (278) |  |  | $ | (80) |  |  |  |

[0000106040-22-000065:mdna:59]
We and the IRS tentatively reached a basis for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to fiscal years 2008 through 2015. We expect to pay tax and interest totaling approximately $600 million to $700 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 to $150 million. See Part I, Item 1, Note 13, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-22-000065:mdna:60]
We have an existing shelf registration statement (the “Shelf Registration Statement”) filed with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-22-000065:mdna:61]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to satisfy our IRS obligation and meet our working capital, debt and capital expenditure needs for at least the next twelve months. We believe we can also access the various debt capital markets to further to supplement our liquidity position. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended July 1, 2022.

[0000106040-22-000065:mdna:62]
During 2023, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate to $2.7 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.3 billion during 2023. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-22-000065:mdna:63]
A total of $1.53 billion and $2.41 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of September 30, 2022 and October 1, 2021, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-22-000065:mdna:64]
[same as prior period, unchanged from 0000106040-22-000040:mdna:85]

[0000106040-22-000065:mdna:65]
44

[0000106040-22-000065:mdna:66]
[same as prior period, unchanged from 0000106040-22-000040:mdna:78]

[0000106040-22-000065:mdna:67]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $329 million for the three months ended September 30, 2022, as compared to $440 million for the three months ended October 1, 2021. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-22-000065:mdna:68]
|  | Three Months Ended |  |  |
|  | September 30,2022 |  | October 1,2021 |  |  |  |  |
| Days sales outstanding | 59 |  |  | 44 |  |  |  |  |  |
| Days in inventory | 128 |  |  | 95 |  |  |  |  |  |
| Days payables outstanding | (65) |  |  | (61) |  |  |  |  |  |
| Cash conversion cycle | 122 |  |  | 78 |  |  |  |  |  |

[0000106040-22-000065:mdna:69]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds, including staging of inventory to meet expected future demand. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-22-000065:mdna:70]
For the three months ended September 30, 2022, DSO increased by 15 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO increased by 33 days from the comparable period in the prior year primarily reflecting a decline in products shipped. DPO increased by 4 days from the comparable period in the prior year primarily due to routine variations in the timing of purchases and payments during the period. We have seen no significant deterioration in our receivables as a result of COVID-19 or other market conditions.

[0000106040-22-000065:mdna:71]
[same as prior period, unchanged from 0000106040-22-000040:mdna:83]

[0000106040-22-000065:mdna:72]
Net cash used in investing activities for the three months ended September 30, 2022 primarily consisted of $320 million in capital expenditures partially offset by a $99 million net decrease in notes receivable issuances to Flash Ventures. Net cash used in investing activities for the three months ended October 1, 2021 primarily consisted of $245 million in capital expenditures, partially offset by a $52 million net increase in notes receivable issuances to Flash Ventures.-

[0000106040-22-000065:mdna:73]
[same as prior period, unchanged from 0000106040-22-000040:mdna:11]

[0000106040-22-000065:mdna:74]
During the three months ended September 30, 2022, cash flows from financing activities primarily consisted of $50 million used for taxes paid on vested stock awards under employee stock plans, while we drew and repaid $300 million under our revolving credit facility within the period. Net cash used in financing activities for the three months ended October 1, 2021 primarily consisted of $213 million for the repayment of our debt, which included a $150 million voluntary prepayment on our Term Loan B-4, and $78 million for taxes paid on vested stock awards under employee stock plans.

[0000106040-22-000065:mdna:75]
[same as prior period, unchanged from 0000106040-22-000040:mdna:88]

[0000106040-22-000065:mdna:76]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000065:mdna:77]
46

[0000106040-22-000065:mdna:78]
[same as prior period, unchanged from 0000106040-22-000040:mdna:91]

[0000106040-22-000065:mdna:79]
Material Cash Commitments

[0000106040-22-000065:mdna:80]
The following is a summary of our known material cash commitments, including those for capital expenditures, as of September 30, 2022:

[0000106040-22-000065:mdna:81]
|  | Total |  | 1 Year (Remaining Nine Months of 2023) |  | 2-3 Years (2024-2025) |  | 4-5 Years (2026-2027) |  | More than 5 Years (Beyond 2027) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,100 |  |  | $ | — |  |  | $ | 1,363 |  |  | $ | 4,738 |  |  | $ | 999 |  |
| Interest on debt | 1,157 |  |  | 169 |  |  | 541 |  |  | 341 |  |  | 106 |  |
| Flash Ventures related commitments(2) | 5,048 |  |  | 2,311 |  |  | 1,980 |  |  | 847 |  |  | (90) |  |
| Operating leases | 356 |  |  | 36 |  |  | 90 |  |  | 83 |  |  | 147 |  |
| Purchase obligations and other commitments | 3,588 |  |  | 2,380 |  |  | 959 |  |  | 99 |  |  | 150 |  |
| Mandatory Deemed Repatriation Tax | 659 |  |  | — |  |  | 404 |  |  | 255 |  |  | — |  |
| Total | $ | 17,908 |  |  | $ | 4,896 |  |  | $ | 5,337 |  |  | $ | 6,363 |  |  | $ | 1,312 |  |

[0000106040-22-000065:mdna:82]
[same as prior period, unchanged from 0000106040-22-000040:mdna:95]

[0000106040-22-000065:mdna:83]
[same as prior period, unchanged from 0000106040-22-000040:mdna:96]

[0000106040-22-000065:mdna:84]
[same as prior period, unchanged from 0000106040-22-000040:mdna:97]

[0000106040-22-000065:mdna:85]
In addition to our existing debt, as of September 30, 2022, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Additional information regarding our indebtedness, including information about principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended July 1, 2022. The loan agreement governing our revolving credit facility and our Term Loan A-2 due 2027 requires us to comply with a leverage ratio financial covenant. As of September 30, 2022, we were in compliance with this financial covenant.

[0000106040-22-000065:mdna:86]
[same as prior period, unchanged from 0000106040-22-000040:mdna:15]

[0000106040-22-000065:mdna:87]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of September 30, 2022, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-22-000065:mdna:88]
[same as prior period, unchanged from 0000106040-22-000040:mdna:108]

[0000106040-22-000065:mdna:89]
[same as prior period, unchanged from 0000106040-22-000040:mdna:109]

[0000106040-22-000065:mdna:90]
[same as prior period, unchanged from 0000106040-22-000040:mdna:110]

[0000106040-22-000065:mdna:91]
The following is a summary of our estimated mandatory deemed repatriation tax obligations that are payable in the following years:

[0000106040-22-000065:mdna:92]
|  |  | September 30,2022 |
|  |  | (in millions) |
| 2024 |  | $ | 199 |  |
| 2025 |  | 205 |  |
| 2026 |  | 255 |  |
| Total |  | $ | 659 |  |

[0000106040-22-000065:mdna:93]
For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part II, Item 8, Note 13, Income Tax Expense, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 28, 2019.

[0000106040-22-000065:mdna:94]
[same as prior period, unchanged from 0000106040-22-000040:mdna:114]

[0000106040-22-000065:mdna:95]
As of September 30, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $1.03 billion. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of September 30, 2022 was $264 million. Of these amounts, approximately $1.15 billion could result in potential cash payments.

[0000106040-22-000065:mdna:96]
As previously disclosed, the IRS issued statutory notices of deficiency and notices of proposed adjustments with respect to transfer pricing with our foreign subsidiaries and intercompany payable balances for years 2008 through 2015. In September 2018 and March 2019, we filed petitions with the U.S. Tax Court covering years 2008 through 2012, for which we had received statutory notices of deficiency, while years 2013 through 2015 remain in the jurisdiction of the IRS’s Examination function. The IRS has filed various Amendments to Answer with the U.S. Tax Court which, together with the notices of proposed adjustments, would result in additional federal income tax liabilities totaling approximately $1.6 billion and penalties totaling $449 million with respect to years 2008 through 2015. In May 2022, we and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. Based on the tentative settlement for resolution, we expect to pay tax and interest totaling approximately $600 million to $700 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 to $150 million. While we continue to work with the IRS to come to a final agreement on the federal tax and interest calculations, we are uncertain as to when a final agreement will be reached and the exact timing of when any payments will be made. However, we believe it is reasonably likely that these payments may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest in Income taxes payable on our Condensed Consolidated Balance Sheets as of September 30, 2022. This classification and amount may be subject to change in the next twelve months depending on when we are able to reach a final agreement with the IRS.

[0000106040-22-000065:mdna:97]
Mandatory Research and Development Expense Capitalization

[0000106040-22-000065:mdna:98]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments, if not repealed or otherwise modified.

[0000106040-22-000065:mdna:99]
Interest Rate Swap

[0000106040-22-000065:mdna:100]
We have generally held a balance of fixed and variable rate debt and periodically have used interest rate swaps to hedge a portion of our fixed rate debt. As of September 30, 2022, our only variable rate debt outstanding was our Term Loan A-2 on which we had pay-fixed interest rate swaps of $2 billion notional amount that would mitigate the impact of fluctuations in variable interest rates on this loan through February 2023. See Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risks included in this in this Quarterly Report on Form 10-Q for additional information.

[0000106040-22-000065:mdna:101]
[same as prior period, unchanged from 0000106040-22-000040:mdna:117]

[0000106040-22-000065:mdna:102]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. See Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risks included in this Quarterly Report on Form 10-Q for additional information.

[0000106040-22-000065:mdna:103]
[same as prior period, unchanged from 0000106040-22-000040:mdna:120]

[0000106040-22-000065:mdna:104]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property (“IP”) infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-22-000065:mdna:105]
[same as prior period, unchanged from 0000106040-22-000040:mdna:122]

[0000106040-22-000065:mdna:106]
[same as prior period, unchanged from 0000106040-22-000040:mdna:123]

[0000106040-22-000065:mdna:107]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the three months ended September 30, 2022 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of September 30, 2022 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-22-000065:mdna:108]
[same as prior period, unchanged from 0000106040-22-000040:mdna:125]

[0000106040-22-000065:mdna:109]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recent Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form    10-Q.

[0000106040-22-000065:mdna:110]
[same as prior period, unchanged from 0000106040-22-000040:mdna:127]

[0000106040-22-000065:mdna:111]
[same as prior period, unchanged from 0000106040-22-000040:mdna:128]

[0000106040-22-000065:mdna:112]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the year ended July 1, 2022. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the year ended July 1, 2022 for a discussion of our critical accounting policies and estimates. In addition, as disclosed in Part I, Item 1, Note 3, Business Segments, Geographic Information, and Concentrations of Risk, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, as of September 30, 2022, our management identified several factors that warranted a quantitative analysis of impairment for both the Flash and HDD reporting units as of that date. Please refer to that disclosure for additional information on the estimates included in our assessment.
