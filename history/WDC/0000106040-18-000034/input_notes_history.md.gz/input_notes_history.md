# WDC note change history — 0000106040-18-000016 → 0000106040-18-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 28, 2018 and June 29, 2018:
  (was, 2018-05-08, similarity 0.9612):
[0000106040-18-000016:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 30, 2018 and June 30, 2017:

- changed (2018-11-06):
[0000106040-18-000034:note_history:2]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 94 |  |  | 48 |  |
| Notes receivable, Flash Forward | 619 |  |  | 700 |  |
| Investment in Flash Partners | 187 |  |  | 191 |  |
| Investment in Flash Alliance | 277 |  |  | 283 |  |
| Investment in Flash Forward | 114 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,028 |  |  | $ | 2,105 |  |
  (was, 2018-05-08, similarity 0.9838):
[0000106040-18-000016:note_history:2]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 838 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 76 |  |  | 119 |  |
| Notes receivable, Flash Forward | 633 |  |  | 379 |  |
| Investment in Flash Partners | 198 |  |  | 187 |  |
| Investment in Flash Alliance | 295 |  |  | 279 |  |
| Investment in Flash Forward | 120 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,160 |  |  | $ | 1,340 |  |

- changed (2018-11-06):
[0000106040-18-000034:note_history:3]
During the three months ended September 28, 2018, the Company made net payments to Flash Ventures of $744 million for purchased flash-based memory wafers and net loans and investments.
  (was, 2018-05-08, similarity 0.8194):
[0000106040-18-000016:note_history:3]
During the three and nine months ended March 30, 2018, the Company made net payments to Flash Ventures of $1.00 billion and $3.0 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2018-11-06):
[0000106040-18-000034:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three months ended September 28, 2018 or September 29, 2017.
  (was, 2018-05-08, similarity 0.8254):
[0000106040-18-000016:note_history:4]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments for credit worthiness in the three and nine months ended March 30, 2018 and March 31, 2017.

- changed (2018-11-06):
[0000106040-18-000034:note_history:5]
As of September 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $286 million and $259 million, respectively.
  (was, 2018-05-08, similarity 0.9638):
[0000106040-18-000016:note_history:5]
As of March 30, 2018 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $282 million and $206 million, respectively.

- added (2018-11-06):
[0000106040-18-000034:note_history:6]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2018-11-06):
[0000106040-18-000034:note_history:7]
|  | September 28, 2018 |
| Notes receivable | $ | 1,450 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 1,236 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 3,623 |  |
  (was, 2018-05-08, similarity 0.9745):
[0000106040-18-000016:note_history:7]
|  | March 30, 2018 |
| Notes receivable | $ | 1,547 |  |
| Equity investments | 613 |  |
| Operating lease guarantees | 1,109 |  |
| Inventory and prepayments | 319 |  |
| Maximum estimable loss exposure | $ | 3,588 |  |

- changed (2018-11-06):
[0000106040-18-000034:note_history:8]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. The Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.
  (was, 2018-05-08, similarity 0.8943):
[0000106040-18-000016:note_history:8]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- changed (2018-11-06):
[0000106040-18-000034:note_history:9]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.
  (was, 2018-05-08, similarity 0.9976):
[0000106040-18-000016:note_history:9]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

- changed (2018-11-06):
[0000106040-18-000034:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018.
  (was, 2018-05-08, similarity 0.9766):
[0000106040-18-000016:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018.

- changed (2018-11-06):
[0000106040-18-000034:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018:
  (was, 2018-05-08, similarity 0.9612):
[0000106040-18-000016:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 30, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018:

- added (2018-11-06):
[0000106040-18-000034:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2019 |  | $ | 280 |  |  | $ | 33 |  |  | $ | 313 |  |
| 2020 |  | 282 |  |  | 61 |  |  | 343 |  |
| 2021 |  | 197 |  |  | 95 |  |  | 292 |  |
| 2022 |  | 110 |  |  | 47 |  |  | 157 |  |
| 2023 |  | 42 |  |  | 64 |  |  | 106 |  |
| Thereafter |  | 3 |  |  | 22 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 914 |  |  | $ | 322 |  |  | $ | 1,236 |  |

- changed (2018-11-06):
[0000106040-18-000034:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2018-05-08, similarity 0.8039):
[0000106040-18-000016:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 30, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2018-11-06):
[0000106040-18-000034:note_history:14]
Unis Venture

- added (2018-11-06):
[0000106040-18-000034:note_history:15]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis “) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture are recognized upon sell through to third-party customers. For the three-month periods ended September 28, 2018 and September 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of September 28, 2018 or June 29, 2018.

- added (2018-11-06):
[0000106040-18-000034:note_history:16]
Purchase Agreements

- added (2018-11-06):
[0000106040-18-000034:note_history:17]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of September 28, 2018, the Company had the following minimum long-term purchase commitments:

- added (2018-11-06):
[0000106040-18-000034:note_history:18]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining nine months of 2019 |  | $ | 14 |  |
| 2020 |  | 144 |  |
| 2021 |  | 141 |  |
| 2022 |  | 150 |  |
| 2023 and thereafter |  | 170 |  |
| Total |  | $ | 619 |  |

- removed (2018-11-06):
[0000106040-18-000016:note_history:19]
In connection with a settlement agreement with Toshiba in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of the parties’ existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6.

- removed (2018-11-06):
[0000106040-18-000016:note_history:20]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 30, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2018-11-06):
[0000106040-18-000016:note_history:21]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 307 |  |  | $ | 15 |  |  | $ | 322 |  |
| Year 2 |  | 212 |  |  | 40 |  |  | 252 |  |
| Year 3 |  | 188 |  |  | 116 |  |  | 304 |  |
| Year 4 |  | 94 |  |  | 81 |  |  | 175 |  |
| Year 5 |  | 24 |  |  | — |  |  | 24 |  |
| Year 6 |  | 3 |  |  | 29 |  |  | 32 |  |
| Total guarantee obligations |  | $ | 828 |  |  | $ | 281 |  |  | $ | 1,109 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:22]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.
  (was, 2018-05-08, similarity 0.9894):
[0000106040-18-000016:note_history:22]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

- changed (2018-11-06):
[0000106040-18-000034:note_history:23]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. Counsel for the remaining named plaintiffs are engaged in settlement discussions with counsel for the defendants. The case has been stayed pending these settlement discussions. The Company intends to defend itself vigorously in this matter.
  (was, 2018-05-08, similarity 0.7584):
[0000106040-18-000016:note_history:23]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

- changed (2018-11-06):
[0000106040-18-000034:note_history:24]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015.  The Company believes the allegations to be without merit and intends to defend itself vigorously in this matter.
  (was, 2018-05-08, similarity 0.813):
[0000106040-18-000016:note_history:24]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

- changed (2018-11-06):
[0000106040-18-000034:note_history:25]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts.
  (was, 2018-05-08, similarity 0.9837):
[0000106040-18-000016:note_history:25]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

- changed (2018-11-06):
[0000106040-18-000034:note_history:26]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013.
  (was, 2018-05-08, similarity 0.8815):
[0000106040-18-000016:note_history:26]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

- added (2018-11-06):
[0000106040-18-000034:note_history:27]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, the Company and ZPÜ intend to dismiss the actions against each other following an accounting and payment of past liabilities. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.

- added (2018-11-06):
[0000106040-18-000034:note_history:28]
Tax

- added (2018-11-06):
[0000106040-18-000034:note_history:29]
For disclosures regarding a statutory notice of deficiency issued by the IRS on June 28, 2018 and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.

- removed (2018-11-06):
[0000106040-18-000016:note_history:30]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision. In April 2018, Samsung voluntarily dismissed its case against Panasonic and SD-3C with prejudice.

- removed (2018-11-06):
[0000106040-18-000016:note_history:31]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $189 million, inclusive of amounts accrued, if it does not prevail in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:32]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.
  (was, 2018-05-08, similarity 0.9898):
[0000106040-18-000016:note_history:32]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.

- changed (2018-11-06):
[0000106040-18-000034:note_history:33]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 29, 2018. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 29, 2018. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2018-05-08, similarity 0.9821):
[0000106040-18-000016:note_history:33]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2018-11-06):
[0000106040-18-000034:note_history:34]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2018-05-08, similarity 0.9879):
[0000106040-18-000016:note_history:34]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2018, which ends on June 29, 2018, and 2017, which ended on June 30, 2017, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:35]
Debt consisted of the following as of September 28, 2018 and June 29, 2018:
  (was, 2018-05-08, similarity 0.9206):
[0000106040-18-000016:note_history:35]
Debt consisted of the following as of March 30, 2018 and June 30, 2017:

- changed (2018-11-06):
[0000106040-18-000034:note_history:36]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,959 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,443 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 11,337 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (194 | ) |  | (203 | ) |
| Subtotal | 11,143 |  |  | 11,172 |  |
| Less current portion of long-term debt | (213 | ) |  | (179 | ) |
| Long-term debt | $ | 10,930 |  |  | $ | 10,993 |  |
  (was, 2018-05-08, similarity 0.7742):
[0000106040-18-000016:note_history:36]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,022 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,455 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,412 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (212 | ) |  | (205 | ) |
| Subtotal | 11,200 |  |  | 13,151 |  |
| Less current portion of long-term debt | (124 | ) |  | (233 | ) |
| Long-term debt | $ | 11,076 |  |  | $ | 12,918 |  |

- added (2018-11-06):
[0000106040-18-000034:note_history:37]
The Company is required to comply with certain financial covenants underlying its debt facilities, such as a leverage ratio and an interest coverage ratio. As of September 28, 2018, the Company was in compliance with all financial covenants.

- removed (2018-11-06):
[0000106040-18-000016:note_history:38]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |

- removed (2018-11-06):
[0000106040-18-000016:note_history:39]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of March 30, 2018, issuance costs of $20 million remained unamortized.

- removed (2018-11-06):
[0000106040-18-000016:note_history:40]
In February 2018, the Company also issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company.

- removed (2018-11-06):
[0000106040-18-000016:note_history:41]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of approximately $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events.

- removed (2018-11-06):
[0000106040-18-000016:note_history:42]
On or after February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

- removed (2018-11-06):
[0000106040-18-000016:note_history:43]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of March 30, 2018, debt discount and issuance cost of $176 million remained unamortized.

- removed (2018-11-06):
[0000106040-18-000016:note_history:44]
In February 2018, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced the Company’s prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on the Company’s corporate credit ratings as described in the indenture, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. The Company used a portion of the proceeds of the Term Loan A-1 to repay in full its previous variable interest rate Term Loan A in the principal amount of $4.02 billion.

- removed (2018-11-06):
[0000106040-18-000016:note_history:45]
The Term Loan A-1 bears interest at a per annum rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings.  Currently the Company has selected the LIBOR rate option, and the applicable rate was 3.38% as of March 30, 2018. Principal payments are due in quarterly installments of (i) 0.625% per quarter from June 2018 through March 2019 and (ii) 1.25% per quarter from June 2019 through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of March 30, 2018, issuance costs of $9 million remained unamortized.

- removed (2018-11-06):
[0000106040-18-000016:note_history:46]
Proceeds of $500 million were drawn under the Revolving Facility and were used to fund a voluntary partial prepayment of the Company’s existing U.S. Dollar denominated term B-3 loans (“U.S. Term Loan B-3”). Loans under the Revolving Facility bear interest, at the Company’s option, at either LIBOR plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.38% as of March 30, 2018. The Company will also pay an unused commitment fee on the Revolving Facility ranging from 0.120% to 0.350% based on the Company’s corporate credit ratings as described in the indenture, with an initial fee of 0.250%.

- removed (2018-11-06):
[0000106040-18-000016:note_history:47]
The Term Loan A-1 and the Revolving Facility are unconditionally guaranteed by each of the guarantors under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantees will be automatically suspended upon certain conditions.

- removed (2018-11-06):
[0000106040-18-000016:note_history:48]
During the three months ended March 30, 2018, the Company completed the redemption of all of its outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of its outstanding 10.50% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Redeemed Notes”), including an aggregate of $720 million of “make-whole” and tender premiums required for the tender offer of the 2024 Notes and the optional redemption of the Redeemed Notes in accordance with the applicable indentures and accrued interest through the applicable redemption dates.

- removed (2018-11-06):
[0000106040-18-000016:note_history:49]
In November 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. Additionally, in November 2017, the Company borrowed $2.96 billion under U.S. Term Loan B-3 under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.88% as of March 30, 2018. Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. During the three months ended March 30, 2018, the Company funded a voluntary partial prepayment of $500 million, which was allocated towards principal payments. As a result, the Company is not required to make principal payments on the U.S. Term Loan B-3 prior to its maturity date. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of March 30, 2018, issuance costs of $3 million remained unamortized.

- removed (2018-11-06):
[0000106040-18-000016:note_history:50]
In connection with the settlements of the various debt instruments described above, the Company recognized an aggregate loss on debt extinguishment of $896 million for the nine months ended March 30, 2018, consisting of $720 million of “make-whole” and tender premiums and $176 million of unamortized issuance costs, of which $894 million was incurred in the three months ended March 30, 2018. In the three and nine months ended March 31, 2017, the Company incurred losses on the extinguishment of debt of $7 million and $274 million, respectively.

- removed (2018-11-06):
[0000106040-18-000016:note_history:51]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of March 30, 2018, the Company was in compliance with all financial covenants. In addition, the Credit Agreement requires the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. In addition, the indentures governing the 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:52]
Debt consisted of the following as of September 28, 2018 and June 29, 2018:
  (was, 2018-05-08, similarity 0.9206):
[0000106040-18-000016:note_history:52]
Debt consisted of the following as of March 30, 2018 and June 30, 2017:

- changed (2018-11-06):
[0000106040-18-000034:note_history:53]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,959 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,443 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 11,337 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (194 | ) |  | (203 | ) |
| Subtotal | 11,143 |  |  | 11,172 |  |
| Less current portion of long-term debt | (213 | ) |  | (179 | ) |
| Long-term debt | $ | 10,930 |  |  | $ | 10,993 |  |
  (was, 2018-05-08, similarity 0.7742):
[0000106040-18-000016:note_history:53]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,022 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,455 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,412 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (212 | ) |  | (205 | ) |
| Subtotal | 11,200 |  |  | 13,151 |  |
| Less current portion of long-term debt | (124 | ) |  | (233 | ) |
| Long-term debt | $ | 11,076 |  |  | $ | 12,918 |  |

- removed (2018-11-06):
[0000106040-18-000016:note_history:54]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0000106040-18-000034:note_history:55]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 28, 2018 and June 29, 2018:
  (was, 2018-05-08, similarity 0.9612):
[0000106040-18-000016:note_history:55]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 30, 2018 and June 30, 2017:

- changed (2018-11-06):
[0000106040-18-000034:note_history:56]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 94 |  |  | 48 |  |
| Notes receivable, Flash Forward | 619 |  |  | 700 |  |
| Investment in Flash Partners | 187 |  |  | 191 |  |
| Investment in Flash Alliance | 277 |  |  | 283 |  |
| Investment in Flash Forward | 114 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,028 |  |  | $ | 2,105 |  |
  (was, 2018-05-08, similarity 0.9838):
[0000106040-18-000016:note_history:56]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 838 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 76 |  |  | 119 |  |
| Notes receivable, Flash Forward | 633 |  |  | 379 |  |
| Investment in Flash Partners | 198 |  |  | 187 |  |
| Investment in Flash Alliance | 295 |  |  | 279 |  |
| Investment in Flash Forward | 120 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,160 |  |  | $ | 1,340 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-06):
[0000106040-18-000034:note_history:57]
The Company’s disaggregated revenue information is as follows(1):

- added (2018-11-06):
[0000106040-18-000034:note_history:58]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | 5,028 |  |  | 5,181 |  |
| Revenue by Form Factor |  |  |  |
| HDD | $ | 2,494 |  |  | $ | 2,610 |  |
| Flash-based | 2,534 |  |  | 2,571 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |

- added (2018-11-06):
[0000106040-18-000034:note_history:59]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-06):
[0000106040-18-000034:note_history:60]
Revenues

- added (2018-11-06):
[0000106040-18-000034:note_history:61]
The Company offers a broad range of data storage products that include Client Devices, Data Center Devices and Solutions, and Client Solutions. Client Devices consist of hard disk drives (“HDDs”) and solid state drives (“SSDs”) for computing devices; flash-based embedded storage products; and flash-based memory wafers. Data Center Devices and Solutions consist of high-capacity enterprise HDDs and high-performance enterprise SSDs, data center software and system solutions. Client Solutions consist of HDDs and SSDs embedded into external storage products and removable flash-based products. The Company also generates license and royalty revenues related to its IP patent licenses which are not material.

- added (2018-11-06):
[0000106040-18-000034:note_history:62]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and that uncertainties are resolved in a fairly short period of time.

- added (2018-11-06):
[0000106040-18-000034:note_history:63]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts.  The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

- added (2018-11-06):
[0000106040-18-000034:note_history:64]
The Company’s customer payment terms are typically less than three months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

- added (2018-11-06):
[0000106040-18-000034:note_history:65]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company believes the estimate of variable consideration is not constrained and that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics. The Company’s methodology for the estimates is based on several factors, including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing.  The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are typically recorded as a reduction of the transaction price and, therefore, of revenue.

- added (2018-11-06):
[0000106040-18-000034:note_history:66]
Some of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

- added (2018-11-06):
[0000106040-18-000034:note_history:67]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 28, 2018 or the date of adoption of Topic 606.

- added (2018-11-06):
[0000106040-18-000034:note_history:68]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three months ended September 28, 2018 were not material.

- added (2018-11-06):
[0000106040-18-000034:note_history:69]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of September 28, 2018 and the date of adoption of Topic 606, contract liabilities were $86 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the three months ended September 28, 2018 were primarily the result of $41 million of revenue recognized during the period that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

- added (2018-11-06):
[0000106040-18-000034:note_history:70]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to unearned revenue and multi-year contracts with future installment payments at the end of any given period. The transaction price allocated to the other remaining performance obligations as of September 28, 2018 was $263 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $87 million during the remainder of fiscal 2019, $58 million in fiscal 2020, $45 million in fiscal 2021 and $73 million thereafter.

- added (2018-11-06):
[0000106040-18-000034:note_history:71]
The Company’s disaggregated revenue information is as follows(1):

- added (2018-11-06):
[0000106040-18-000034:note_history:72]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | 5,028 |  |  | 5,181 |  |
| Revenue by Form Factor |  |  |  |
| HDD | $ | 2,494 |  |  | $ | 2,610 |  |
| Flash-based | 2,534 |  |  | 2,571 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |

- added (2018-11-06):
[0000106040-18-000034:note_history:73]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material. |

- added (2018-11-06):
[0000106040-18-000034:note_history:74]
For the three months ended September 28, 2018 and September 29, 2017, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended September 28, 2018 and September 29, 2017, the Company’s top 10 customers accounted for 48% and 42% of the Company’s net revenue, respectively.
