# WDC MD&A — 0000106040-18-000034


## mdna

[0000106040-18-000034:mdna:1]
[same as prior period, unchanged from 0000106040-18-000016:mdna:1]

[0000106040-18-000034:mdna:2]
[same as prior period, unchanged from 0000106040-18-000016:mdna:2]

[0000106040-18-000034:mdna:3]
[same as prior period, unchanged from 0000106040-18-000016:mdna:3]

[0000106040-18-000034:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology industry and the infrastructure that enables the proliferation of data in virtually every other industry. Our broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. We also generate license and royalty revenue related to our intellectual property (“IP”), which is included in each of these three categories.

[0000106040-18-000034:mdna:5]
[same as prior period, unchanged from 0000106040-18-000016:mdna:6]

[0000106040-18-000034:mdna:6]
[same as prior period, unchanged from 0000106040-18-000016:mdna:92]

[0000106040-18-000034:mdna:7]
The flash industry is characterized by cyclicality as it responds to variations in customers’ demand for products and manages production capacity to meet that demand. The favorable demand environment for flash-based products during the last several quarters has begun to normalize as technology conversions are maturing and manufacturing yields are improving, thus increasing flash supply relative to demand. As a result, average selling price per gigabyte of flash-based products has declined.

[0000106040-18-000034:mdna:8]
Through our strategic partnership with Toshiba Memory Corporation (“TMC”) referred to as “Flash Ventures”, we and TMC operate flash-based memory wafer manufacturing facilities in Yokkaichi, Japan. We are obligated to purchase half of Flash Ventures’ flash-based memory wafer supply or pay for half of Flash Ventures’ fixed costs regardless of the output we choose to purchase. We are also obligated to fund 49.9% to 50% of Flash Ventures’ investments to the extent that Flash Ventures’ operating cash flow is insufficient to fund these investments.

[0000106040-18-000034:mdna:9]
In response to the current flash business conditions, we expect to reduce wafer starts and delay deployment of capital equipment for flash production. We expect these actions to reduce our planned flash output by approximately 10% to 15% for calendar year 2019. The goal of these actions is to bring our supply more in line with the demand environment, with the majority of the supply reduction occurring by the middle of calendar year 2019. We do not expect this action to result in any incremental cash payments; however, we expect the temporary abnormal reduction in output to result in flash manufacturing underutilization charges to be recorded in cost of sales in the range of $250 million to $300 million spread over the remainder of fiscal 2019. We may adjust our plans based on market conditions, which could impact the timing and amount of any charges.

[0000106040-18-000034:mdna:10]
46

[0000106040-18-000034:mdna:11]
[same as prior period, unchanged from 0000106040-18-000016:mdna:21]

[0000106040-18-000034:mdna:12]
First Quarter Overview

[0000106040-18-000034:mdna:13]
[same as prior period, unchanged from 0000106040-18-000016:mdna:23]

[0000106040-18-000034:mdna:14]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 5,028 |  |  | 100.0 | % |  | $ | 5,181 |  |  | 100.0 | % |  | $ | (153 | ) |  | (3.0 | )% |
| Cost of revenue | 3,364 |  |  | 66.9 |  |  | 3,268 |  |  | 63.1 |  |  | 96 |  |  | 2.9 |  |
| Gross profit | 1,664 |  |  | 33.1 |  |  | 1,913 |  |  | 36.9 |  |  | (249 | ) |  | (13.0 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 576 |  |  | 11.5 |  |  | 592 |  |  | 11.4 |  |  | (16 | ) |  | (2.7 | ) |
| Selling, general and administrative | 356 |  |  | 7.1 |  |  | 364 |  |  | 7.0 |  |  | (8 | ) |  | (2.2 | ) |
| Employee termination, asset impairment, and other charges | 46 |  |  | 0.9 |  |  | 52 |  |  | 1.0 |  |  | (6 | ) |  | (11.5 | ) |
| Total operating expenses | 978 |  |  | 19.5 |  |  | 1,008 |  |  | 19.5 |  |  | (30 | ) |  | (3.0 | ) |
| Operating income | 686 |  |  | 13.6 |  |  | 905 |  |  | 17.5 |  |  | (219 | ) |  | (24.2 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 15 |  |  | 0.3 |  |  | 16 |  |  | 0.3 |  |  | (1 | ) |  | (6.3 | ) |
| Interest expense | (116 | ) |  | (2.3 | ) |  | (205 | ) |  | (4.0 | ) |  | 89 |  |  | (43.4 | ) |
| Other expense, net | (2 | ) |  | — |  |  | (6 | ) |  | (0.1 | ) |  | 4 |  |  | (66.7 | ) |
| Total interest and other expense, net | (103 | ) |  | (2.0 | ) |  | (195 | ) |  | (3.8 | ) |  | 92 |  |  | (47.2 | ) |
| Income before taxes | 583 |  |  | 11.6 |  |  | 710 |  |  | 13.7 |  |  | (127 | ) |  | (17.9 | ) |
| Income tax expense | 72 |  |  | 1.4 |  |  | 29 |  |  | 0.6 |  |  | 43 |  |  | 148.3 |  |
| Net income | $ | 511 |  |  | 10.2 |  |  | $ | 681 |  |  | 13.1 |  |  | $ | (170 | ) |  | (25.0 | ) |

[0000106040-18-000034:mdna:15]
[same as prior period, unchanged from 0000106040-18-000016:mdna:25]

[0000106040-18-000034:mdna:16]
The following table sets forth, for the periods presented, summary information regarding our revenue(1):

[0000106040-18-000034:mdna:17]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |

[0000106040-18-000034:mdna:18]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. |

[0000106040-18-000034:mdna:19]
47

[0000106040-18-000034:mdna:20]
Net Revenue and Gross Margin

[0000106040-18-000034:mdna:21]
Net Revenue. The decrease in net revenue in the three months ended September 28, 2018 from the comparable period of the prior year was primarily driven by lower average selling prices per gigabyte for flash-based products. Client Devices revenue decreased 1.0% year over year, primarily driven by a reduction in client compute HDD sales, lower average selling prices for flash-based products and lower gaming sales. These factors were largely offset by higher demand for mobility and surveillance products. Our revenue for Data Center Devices and Solutions increased 5.6% year over year, primarily driven by an increase in sales from our capacity enterprise HDD, partially offset by our lower sales of eSSDs and performance enterprise HDDs. Client Solutions revenue decreased 18.0% year over year, primarily driven by lower average selling prices per gigabyte of flash-based products.

[0000106040-18-000034:mdna:22]
[same as prior period, unchanged from 0000106040-18-000016:mdna:38]

[0000106040-18-000034:mdna:23]
For the three months ended September 28, 2018 and September 29, 2017, two customers accounted for 11% and 10%, respectively, of our net revenue. For the three months ended September 28, 2018 and September 29, 2017, our top 10 customers accounted for 48% and 42% of our net revenue, respectively.

[0000106040-18-000034:mdna:24]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For each of the three-month periods ended September 28, 2018 and September 29, 2017, these programs represented 12% of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-18-000034:mdna:25]
Gross Profit and Gross Margin.  The decrease in gross profit in the three months ended September 28, 2018 from the comparable period in the prior year was primarily due to the lower average selling prices for flash products. This was partially offset by improvements in our production costs from technology transitions and lower costs for amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $247 million, or 4.9%, of revenue, in the three months ended September 28, 2018, compared to $279 million, or 5.4%, of revenue, in the three months ended September 29, 2017.

[0000106040-18-000034:mdna:26]
[same as prior period, unchanged from 0000106040-18-000016:mdna:44]

[0000106040-18-000034:mdna:27]
The decrease in research and development (“R&D”) expense from the comparable period in the prior year is primarily due to our cost saving initiatives and lower variable compensation expense. In addition, the three months ended September 28, 2018 included aggregate charges of $39 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges compared to $47 million in the three months ended September 29, 2017.

[0000106040-18-000034:mdna:28]
The decrease in selling, general and administrative (“SG&A”) expense is primarily due to lower variable compensation expense and lower charges related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges. These charges aggregated $73 million in the three months ended September 28, 2018 compared to $90 million in the three months ended September 29, 2017. The decrease in these charges was partially offset by operating expenses from recent acquisitions and higher consulting services.

[0000106040-18-000034:mdna:29]
Employee termination, asset impairment and other charges primarily related to further actions associated with the realignment of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 13, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:30]
[same as prior period, unchanged from 0000106040-18-000016:mdna:49]

[0000106040-18-000034:mdna:31]
The decrease in total interest and other expense, net is primarily due to lower interest expense resulting from reductions in the principal amount of debt and lower interest rates as a result of changes to our debt facilities in the third and fourth quarters of fiscal 2018, partially offset by increases in the LIBOR interest rate.

[0000106040-18-000034:mdna:32]
Income Tax Expense

[0000106040-18-000034:mdna:33]
The following table sets forth income tax information from our Condensed Consolidated Statements of Operations by dollar and effective tax rate:

[0000106040-18-000034:mdna:34]
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Income before taxes | $ | 583 |  |  | $ | 710 |  |
| Income tax expense | 72 |  |  | 29 |  |
| Effective tax rate | 12 | % |  | 4 | % |

[0000106040-18-000034:mdna:35]
On December 22, 2017, the Tax Cuts and Jobs Act (the “2017 Act”) was enacted, which includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21% effective January 1, 2018, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred, and the creation of new taxes on certain foreign earnings.

[0000106040-18-000034:mdna:36]
Consistent with applicable Securities and Exchange Commission (“SEC”) guidance, we made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. For other elements of tax expense noted in Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q, or where we have not made an election, we have not been able to make a reasonable estimate and continue to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As we finalize the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, we expect to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000034:mdna:37]
The primary driver of the difference between the effective tax rate for the three months ended September 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the provisional income tax benefit of $52 million related to the decision to utilize our 2018 operating loss to partially offset the mandatory deemed repatriation tax.

[0000106040-18-000034:mdna:38]
The primary drivers for the difference between the effective tax rate for the three months ended September 29, 2017 and the U.S. Federal statutory rate of 35% are windfall benefits related to vesting and exercises of stock-based awards, the generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand.

[0000106040-18-000034:mdna:39]
Our future effective tax rate is subject to future regulatory developments, changes in the mix of our U.S. earnings compared to foreign earnings, updates to our assertion as to whether the remaining portion of our foreign undistributed earnings are indefinitely reinvested and other calculations under the 2017 Act. Our total tax expense in future fiscal years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-18-000034:mdna:40]
For additional information regarding income tax expense (benefit), see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:41]
[same as prior period, unchanged from 0000106040-18-000016:mdna:62]

[0000106040-18-000034:mdna:42]
[same as prior period, unchanged from 0000106040-18-000016:mdna:63]

[0000106040-18-000034:mdna:43]
|  | Three months ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 705 |  |  | $ | 1,133 |  |
| Investing activities | (259 | ) |  | (378 | ) |
| Financing activities | (807 | ) |  | (224 | ) |
| Effect of exchange rate changes on cash | 2 |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (359 | ) |  | $ | 532 |  |

[0000106040-18-000034:mdna:44]
[same as prior period, unchanged from 0000106040-18-000016:mdna:65]

[0000106040-18-000034:mdna:45]
During fiscal 2019, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to our Flash Ventures joint venture with Toshiba Memory Corporation to be approximately $1.50 billion to $1.90 billion. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-18-000034:mdna:46]
Pursuant to the 2017 Act, we are required to pay a one-time deemed repatriation tax related to the undistributed earnings of our foreign subsidiaries. As of September 28, 2018, the provisional amount of the mandatory deemed repatriation tax liability was $1.26 billion, which is payable over an 8-year period as further discussed below under “Short and Long-term Liquidity-Contractual Obligations and Commitments.” The provisional amount included in the Consolidated Financial Statements may change when we finalize the calculation of our post-1986 foreign earnings and profits that were previously deferred from U.S. income taxes and the amount of foreign earnings held in cash or other specified assets.  For additional information regarding our total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:47]
A total of $3.36 billion and $4.15 billion of our cash and cash equivalents was held outside of the U.S. as of September 28, 2018 and June 29, 2018, respectively. Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., we continue to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires us to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the U.S. deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. For the three months ended September 28, 2018, we made the decision to no longer continue to assert indefinite reinvestment on a portion of our foreign undistributed earnings in certain foreign jurisdictions and have included a provisional income tax expense of $26 million related to state income taxes, partially offset by a decrease to our valuation allowance of $17 million. Amounts related to foreign withholding taxes were not material. We continue to evaluate whether or not to assert indefinite reinvestment on our remaining foreign undistributed earnings. In the event we determine not to continue to assert the permanent reinvestment of part or all of our remaining foreign undistributed earnings, such a determination could result in the accrual and payment of additional federal, foreign, state and local taxes. For additional information regarding our indefinite reinvestment assertion, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:48]
[same as prior period, unchanged from 0000106040-18-000016:mdna:69]

[0000106040-18-000034:mdna:49]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in other operating assets and liabilities was $597 million for the three months ended September 28, 2018, as compared to $236 million for the three months ended September 29, 2017. The increase in cash used for changes in other operating assets and liabilities in the three months ended September 28, 2018 primarily reflects the payable recorded for the mandatory repatriation tax as described in Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q. Changes in our other operating assets and liabilities are also largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-18-000034:mdna:50]
|  | Quarter to Date |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in days) |
| Days sales outstanding | 40 |  |  | 37 |  |
| Days in inventory | 84 |  |  | 64 |  |
| Days payables outstanding | (64 | ) |  | (64 | ) |
| Cash conversion cycle | 60 |  |  | 37 |  |

[0000106040-18-000034:mdna:51]
[same as prior period, unchanged from 0000106040-18-000016:mdna:72]

[0000106040-18-000034:mdna:52]
For the three months ended September 28, 2018, DSO increased by 3 days over the prior year, primarily reflecting the timing of shipments and customer receipts. DIO increased by 20 days over the prior year, primarily reflecting increases in hard drive inventory to re-establish capacity enterprise to normal levels and, to a lesser extent, increases in flash inventory. DPO remained consistent with the prior year.

[0000106040-18-000034:mdna:53]
[same as prior period, unchanged from 0000106040-18-000016:mdna:74]

[0000106040-18-000034:mdna:54]
During the three months ended September 28, 2018, net cash used in investing activities primarily consisted of $277 million of capital expenditures and a net $29 million decrease in notes receivable issuances to Flash Ventures to fund its capital expansion. Net cash used in investing activities for the three months ended September 29, 2017 primarily consisted of $160 million of capital expenditures, a $131 million net increase in notes receivable issuances to and investments in Flash Ventures and $93 million for acquisitions.

[0000106040-18-000034:mdna:55]
[same as prior period, unchanged from 0000106040-18-000016:mdna:76]

[0000106040-18-000034:mdna:56]
[same as prior period, unchanged from 0000106040-18-000016:mdna:77]

[0000106040-18-000034:mdna:57]
During the three months ended September 28, 2018, net cash used in financing activities primarily consisted of $148 million to pay dividends on our common stock, $563 million of share repurchases, $66 million for taxes paid on vested stock awards under employee stock plans and $38 million for repayment of debt. Net cash used in financing activities for the during the three months ended September 29, 2017 primarily consisted of $147 million to pay dividends on our common stock, $62 million to repay debt, and a net $41 million used for employee stock plans, partially offset by proceeds of $26 million from the settlement of debt hedge contracts.

[0000106040-18-000034:mdna:58]
[same as prior period, unchanged from 0000106040-18-000016:mdna:80]

[0000106040-18-000034:mdna:59]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:60]
[same as prior period, unchanged from 0000106040-18-000016:mdna:82]

[0000106040-18-000034:mdna:61]
[same as prior period, unchanged from 0000106040-18-000016:mdna:83]

[0000106040-18-000034:mdna:62]
The following is a summary of our known contractual cash obligations and commercial commitments as of September 28, 2018:

[0000106040-18-000034:mdna:63]
|  | Total |  | 1 Year (Remaining 9 months of 2019) |  | 2-3 Years (2020-2021) |  | 4-5 Years (2022-2023) |  | More than 5 Years (Beyond 2023) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 11,337 |  |  | $ | 144 |  |  | $ | 586 |  |  | $ | 7,207 |  |  | $ | 3,400 |  |
| Interest on debt | 2,226 |  |  | 294 |  |  | 853 |  |  | 735 |  |  | 344 |  |
| Flash Ventures and other related commitments(2) | 7,343 |  |  | 2,721 |  |  | 2,662 |  |  | 1,540 |  |  | 420 |  |
| Operating leases | 181 |  |  | 42 |  |  | 81 |  |  | 38 |  |  | 20 |  |
| Purchase obligations | 3,286 |  |  | 2,653 |  |  | 313 |  |  | 320 |  |  | — |  |
| Mandatory Repatriation Tax | 1,113 |  |  | — |  |  | 164 |  |  | 200 |  |  | 749 |  |
| Total | $ | 25,486 |  |  | $ | 5,854 |  |  | $ | 4,659 |  |  | $ | 10,040 |  |  | $ | 4,933 |  |

[0000106040-18-000034:mdna:64]
| (1) | Principal portion of debt, excluding discounts and issuance costs. |

[0000106040-18-000034:mdna:65]
| (2) | Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and reimbursement for other committed expenses, including R&D. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments. |

[0000106040-18-000034:mdna:66]
[same as prior period, unchanged from 0000106040-18-000016:mdna:87]

[0000106040-18-000034:mdna:67]
See Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q and Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10‑K for the year ended June 29, 2018 for information regarding our indebtedness, including information about new borrowings and repayments, increased availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness.

[0000106040-18-000034:mdna:68]
Flash Ventures

[0000106040-18-000034:mdna:69]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of September 28, 2018, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding Flash Ventures.

[0000106040-18-000034:mdna:70]
52

[0000106040-18-000034:mdna:71]
Purchase Obligations

[0000106040-18-000034:mdna:72]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. In addition, we have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. The estimated related minimum purchase requirements are included in “Purchase obligations” in the table above. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-18-000034:mdna:73]
[same as prior period, unchanged from 0000106040-18-000016:mdna:99]

[0000106040-18-000034:mdna:74]
The following is a summary of our estimated provisional mandatory deemed repatriation tax obligations that are payable in the following fiscal years (in millions):

[0000106040-18-000034:mdna:75]
| Remaining nine months of 2019 |  | $ | — |  |
| 2020 |  | 64 |  |
| 2021 |  | 100 |  |
| 2022 |  | 100 |  |
| 2023 |  | 100 |  |
| 2024 |  | 187 |  |
| 2025 |  | 250 |  |
| 2026 |  | 312 |  |
| Total |  | $ | 1,113 |  |

[0000106040-18-000034:mdna:76]
The 2017 Act allows for the provisional mandatory deemed repatriation tax of $1.26 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. As of September 28, 2018, total payments of $150 million have been made towards the provisional mandatory deemed repatriation tax of $1.26 billion for a remaining net tax liability owed of $1.11 billion.  For additional information regarding our provisional estimate of the total tax liability for the mandatory repatriation tax, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:77]
[same as prior period, unchanged from 0000106040-18-000016:mdna:103]

[0000106040-18-000034:mdna:78]
As of September 28, 2018, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $557 million. Accrued interest and penalties related to unrecognized tax benefits as of September 28, 2018 was approximately $112 million. Of these amounts, approximately $553 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:79]
[same as prior period, unchanged from 0000106040-18-000016:mdna:89]

[0000106040-18-000034:mdna:80]
We have entered into interest rate swap agreements to moderate our exposure to fluctuations in interest rates underlying our variable rate debt. For a description of our current interest rate swaps, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:81]
[same as prior period, unchanged from 0000106040-18-000016:mdna:94]

[0000106040-18-000034:mdna:82]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk and Part I, Item 1, Note 6, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:83]
[same as prior period, unchanged from 0000106040-18-000016:mdna:96]

[0000106040-18-000034:mdna:84]
[same as prior period, unchanged from 0000106040-18-000016:mdna:97]

[0000106040-18-000034:mdna:85]
[same as prior period, unchanged from 0000106040-18-000016:mdna:98]

[0000106040-18-000034:mdna:86]
[same as prior period, unchanged from 0000106040-18-000016:mdna:105]

[0000106040-18-000034:mdna:87]
Our Board of Directors previously authorized $5.00 billion for the repurchase of our common stock. During the three months ended September 28, 2018, we repurchased 0.8 million shares for a total cost of $61 million under this previous authorization. On July 25, 2018, our Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. Subsequent to July 25, 2018 and through September 28, 2018, we repurchased an additional 7.6 million shares for a total cost of $502 million under this new program. Therefore, the Company’s stock repurchases under all stock repurchase authorizations in effect for the three months ended September 28, 2018 totaled $563 million. The remaining amount available to be purchased under our stock repurchase program as of September 28, 2018 was $4.50 billion.  Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows.

[0000106040-18-000034:mdna:88]
[same as prior period, unchanged from 0000106040-18-000016:mdna:107]

[0000106040-18-000034:mdna:89]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On July 16, 2018, we paid $148 million for a dividend declared in the fourth quarter of fiscal 2018.  On August 1, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of September 28, 2018, which aggregated $145 million and was paid on October 15, 2018. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-18-000034:mdna:90]
Recent Accounting Pronouncements

[0000106040-18-000034:mdna:91]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recent Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-18-000034:mdna:92]
[same as prior period, unchanged from 0000106040-18-000016:mdna:133]

[0000106040-18-000034:mdna:93]
We have prepared the accompanying Condensed Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate.  If these estimates differ significantly from actual results, the impact to the Condensed Consolidated Financial Statements may be material.

[0000106040-18-000034:mdna:94]
See Part I, Item 1, Note 2, Recent Accounting Pronouncements, and Note 3, Revenues, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for a discussion of a recently adopted accounting pronouncement that affects our recognition of revenue.  There have been no other material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 29, 2018.  Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 29, 2018 for a discussion of our critical accounting policies and estimates.
