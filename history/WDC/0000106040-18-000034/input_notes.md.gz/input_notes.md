# WDC notes — 0000106040-18-000034


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-18-000034:notes:1]
[same as prior period, unchanged from 0000106040-18-000016:notes:3]

[0000106040-18-000034:notes:2]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 4,646 |  |  | $ | 5,005 |  |
| Short-term available-for-sale securities (included within Other current assets) | 24 |  |  | 23 |  |
| Long-term available-for-sale securities (included within Other non-current assets) | 91 |  |  | 93 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 4,761 |  |  | $ | 5,121 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-18-000034:notes:3]
[same as prior period, unchanged from 0000106040-18-000016:notes:5]

[0000106040-18-000034:notes:4]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Benefit obligations | $ | 254 |  |  | $ | 260 |  |
| Fair value of plan assets | 197 |  |  | 200 |  |
| Unfunded status | $ | 57 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-18-000034:notes:5]
Commitments, Contingencies and Related Parties

[0000106040-18-000034:notes:6]
Flash Ventures

[0000106040-18-000034:notes:7]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-18-000034:notes:8]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 28, 2018 and June 29, 2018:

[0000106040-18-000034:notes:9]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 94 |  |  | 48 |  |
| Notes receivable, Flash Forward | 619 |  |  | 700 |  |
| Investment in Flash Partners | 187 |  |  | 191 |  |
| Investment in Flash Alliance | 277 |  |  | 283 |  |
| Investment in Flash Forward | 114 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,028 |  |  | $ | 2,105 |  |

[0000106040-18-000034:notes:10]
During the three months ended September 28, 2018, the Company made net payments to Flash Ventures of $744 million for purchased flash-based memory wafers and net loans and investments.

[0000106040-18-000034:notes:11]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-18-000034:notes:12]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three months ended September 28, 2018 or September 29, 2017.

[0000106040-18-000034:notes:13]
As of September 28, 2018 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $286 million and $259 million, respectively.

[0000106040-18-000034:notes:14]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 28, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-18-000034:notes:15]
|  | September 28, 2018 |
| Notes receivable | $ | 1,450 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 1,236 |  |
| Inventory and prepayments | 359 |  |
| Maximum estimable loss exposure | $ | 3,623 |  |

[0000106040-18-000034:notes:16]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. The Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-18-000034:notes:17]
Off-Balance Sheet Liabilities

[0000106040-18-000034:notes:18]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-18-000034:notes:19]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018.

[0000106040-18-000034:notes:20]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 140 |  |  | $ | 1,236 |  |

[0000106040-18-000034:notes:21]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 28, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 28, 2018:

[0000106040-18-000034:notes:22]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2019 |  | $ | 280 |  |  | $ | 33 |  |  | $ | 313 |  |
| 2020 |  | 282 |  |  | 61 |  |  | 343 |  |
| 2021 |  | 197 |  |  | 95 |  |  | 292 |  |
| 2022 |  | 110 |  |  | 47 |  |  | 157 |  |
| 2023 |  | 42 |  |  | 64 |  |  | 106 |  |
| Thereafter |  | 3 |  |  | 22 |  |  | 25 |  |
| Total guarantee obligations |  | $ | 914 |  |  | $ | 322 |  |  | $ | 1,236 |  |

[0000106040-18-000034:notes:23]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 28, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-18-000034:notes:24]
Unis Venture

[0000106040-18-000034:notes:25]
In November 2015, the Company entered into an agreement with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis “) to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture are recognized upon sell through to third-party customers. For the three-month periods ended September 28, 2018 and September 29, 2017, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of September 28, 2018 or June 29, 2018.

[0000106040-18-000034:notes:26]
Purchase Agreements

[0000106040-18-000034:notes:27]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of September 28, 2018, the Company had the following minimum long-term purchase commitments:

[0000106040-18-000034:notes:28]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining nine months of 2019 |  | $ | 14 |  |
| 2020 |  | 144 |  |
| 2021 |  | 141 |  |
| 2022 |  | 150 |  |
| 2023 and thereafter |  | 170 |  |
| Total |  | $ | 619 |  |


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-18-000034:notes:29]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 511 |  |  | $ | 465 |  |  | 345 |  |  | $ | (810 | ) |  | $ | 511 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | (37 | ) |  | (34 | ) |  | (34 | ) |  | 68 |  |  | (37 | ) |
| Net unrealized loss, on derivative contracts and available-for-sale securities | (1 | ) |  | (8 | ) |  | (10 | ) |  | 18 |  |  | (1 | ) |
| Total other comprehensive loss, before tax | (38 | ) |  | (42 | ) |  | (44 | ) |  | 86 |  |  | (38 | ) |
| Income tax benefit related to items of other comprehensive loss | 1 |  |  | — |  |  | 1 |  |  | (1 | ) |  | 1 |  |
| Other comprehensive loss, net of tax | (37 | ) |  | (42 | ) |  | (43 | ) |  | 85 |  |  | (37 | ) |
| Total comprehensive income | $ | 474 |  |  | $ | 423 |  |  | $ | 302 |  |  | $ | (725 | ) |  | $ | 474 |  |

[0000106040-18-000034:notes:30]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 681 |  |  | $ | 805 |  |  | $ | 575 |  |  | $ | (1,380 | ) |  | $ | 681 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | (4 | ) |  | (4 | ) |  | (4 | ) |  | 8 |  |  | (4 | ) |
| Net unrealized gain (loss) on derivative contracts and available-for-sale securities | 3 |  |  | 2 |  |  | 2 |  |  | (4 | ) |  | 3 |  |
| Total other comprehensive loss, before tax | (1 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (1 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | — |  |
| Other comprehensive loss, net of tax | (1 | ) |  | (2 | ) |  | (4 | ) |  | 6 |  |  | (1 | ) |
| Total comprehensive income | $ | 680 |  |  | $ | 803 |  |  | $ | 571 |  |  | $ | (1,374 | ) |  | $ | 680 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-18-000034:notes:31]
Debt

[0000106040-18-000034:notes:32]
Debt consisted of the following as of September 28, 2018 and June 29, 2018:

[0000106040-18-000034:notes:33]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,959 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,443 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 11,337 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (194 | ) |  | (203 | ) |
| Subtotal | 11,143 |  |  | 11,172 |  |
| Less current portion of long-term debt | (213 | ) |  | (179 | ) |
| Long-term debt | $ | 10,930 |  |  | $ | 10,993 |  |

[0000106040-18-000034:notes:34]
The Company is required to comply with certain financial covenants underlying its debt facilities, such as a leverage ratio and an interest coverage ratio. As of September 28, 2018, the Company was in compliance with all financial covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-18-000034:notes:35]
[same as prior period, unchanged from 0000106040-18-000016:notes:48]

[0000106040-18-000034:notes:36]
As of September 28, 2018, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps that were designated as cash flow hedges. The Company did not have any foreign exchange forward contracts with credit-risk-related contingent features. As of September 28, 2018, the amount of existing net gains related to cash flow hedges recorded in AOCI was not material and the majority is expected to be reclassified to earnings over the next twelve months.

[0000106040-18-000034:notes:37]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other expense, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three-month periods ended September 28, 2018 and September 29, 2017, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:38]
See Note 5, Fair Value Measurements and Investments, for additional disclosures related to the fair value of the Company’s foreign exchange forward contracts.

[0000106040-18-000034:notes:39]
[same as prior period, unchanged from 0000106040-18-000016:notes:57]

[0000106040-18-000034:notes:40]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of September 28, 2018 and June 29, 2018, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000106040-18-000034:notes:41]
The Company’s disaggregated revenue information is as follows(1):

[0000106040-18-000034:notes:42]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |
| Client Devices | $ | 2,650 |  |  | $ | 2,676 |  |
| Data Center Devices & Solutions | 1,446 |  |  | 1,369 |  |
| Client Solutions | 932 |  |  | 1,136 |  |
| Total Revenue | 5,028 |  |  | 5,181 |  |
| Revenue by Form Factor |  |  |  |
| HDD | $ | 2,494 |  |  | $ | 2,610 |  |
| Flash-based | 2,534 |  |  | 2,571 |  |
| Total Revenue | $ | 5,028 |  |  | $ | 5,181 |  |
| Revenue by Geography (%) |  |  |  |
| Americas | 25 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 18 |  |
| Asia | 57 |  |  | 56 |  |

[0000106040-18-000034:notes:43]
| (1) | Prior year information is presented in accordance with the accounting guidance in effect during that period and has not been updated for Topic 606. The impact of the adoption of Topic 606 was not material. |


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-18-000034:notes:44]
[same as prior period, unchanged from 0000106040-18-000016:notes:64]

[0000106040-18-000034:notes:45]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Options | $ | 5 |  |  | $ | 7 |  |
| Restricted and performance stock units | 67 |  |  | 83 |  |
| Employee stock purchase plan | 7 |  |  | 7 |  |
| Subtotal | 79 |  |  | 97 |  |
| Tax benefit | (11 | ) |  | (24 | ) |
| Total | $ | 68 |  |  | $ | 73 |  |

[0000106040-18-000034:notes:46]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Cost of revenue | $ | 11 |  |  | $ | 13 |  |
| Research and development | 39 |  |  | 44 |  |
| Selling, general and administrative | 29 |  |  | 40 |  |
| Subtotal | 79 |  |  | 97 |  |
| Tax benefit | (11 | ) |  | (24 | ) |
| Total | $ | 68 |  |  | $ | 73 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-18-000034:notes:47]
Net Income Per Common Share

[0000106040-18-000034:notes:48]
The following table presents the computation of basic and diluted income per common share:

[0000106040-18-000034:notes:49]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions, except per share data) |
| Net income | $ | 511 |  |  | $ | 681 |  |
| Weighted average shares outstanding: |  |  |  |
| Basic | 292 |  |  | 295 |  |
| Employee stock options, RSUs, PSUs and ESPP | 6 |  |  | 11 |  |
| Diluted | 298 |  |  | 306 |  |
| Income per common share |  |  |  |
| Basic | $ | 1.75 |  |  | $ | 2.31 |  |
| Diluted | $ | 1.71 |  |  | $ | 2.23 |  |
| Anti-dilutive potential common shares excluded(1) | 3 |  |  | 2 |  |

[0000106040-18-000034:notes:50]
| (1) | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-18-000034:notes:51]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-18-000034:notes:52]
[same as prior period, unchanged from 0000106040-18-000016:notes:72]

[0000106040-18-000034:notes:53]
[same as prior period, unchanged from 0000106040-18-000016:notes:73]

[0000106040-18-000034:notes:54]
[same as prior period, unchanged from 0000106040-18-000016:notes:74]

[0000106040-18-000034:notes:55]
[same as prior period, unchanged from 0000106040-18-000016:notes:75]

[0000106040-18-000034:notes:56]
[same as prior period, unchanged from 0000106040-18-000016:notes:76]

[0000106040-18-000034:notes:57]
[same as prior period, unchanged from 0000106040-18-000016:notes:77]

[0000106040-18-000034:notes:58]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of September 28, 2018 and June 29, 2018, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-18-000034:notes:59]
|  | September 28, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,229 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,229 |  |
| Total cash equivalents | 2,229 |  |  | — |  |  | — |  |  | 2,229 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds |  |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Total short-term available-for-sale securities | 3 |  |  | 21 |  |  | — |  |  | 24 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 69 |  |  | — |  |  | 69 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total long-term available-for-sale securities | 2 |  |  | 89 |  |  | — |  |  | 91 |  |
| Foreign exchange contracts | — |  |  | 46 |  |  | — |  |  | 46 |  |
| Interest rate swap contracts | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total assets at fair value | $ | 2,234 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 2,413 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000106040-18-000034:notes:60]
|  | June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,554 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,554 |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total cash equivalents | 2,554 |  |  | 4 |  |  | — |  |  | 2,558 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Total short-term available-for-sale securities | 5 |  |  | 18 |  |  | — |  |  | 23 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Asset-backed securities | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Municipal notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total long-term available-for-sale securities | 3 |  |  | 90 |  |  | — |  |  | 93 |  |
| Foreign exchange contracts | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Interest rate swap contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,562 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 2,741 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |

[0000106040-18-000034:notes:61]
During the three months ended September 28, 2018, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-18-000034:notes:62]
[same as prior period, unchanged from 0000106040-18-000016:notes:82]

[0000106040-18-000034:notes:63]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of September 28, 2018 and June 29, 2018.

[0000106040-18-000034:notes:64]
Equity Securities Without a Readily Determinable Fair Value (“RDFV”)

[0000106040-18-000034:notes:65]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity securities of these privately-held companies do not have a RDFV. Under ASU 2016-01, these equity securities are now measured and recorded using the measurement alternative, which is cost minus impairment, if any, plus or minus changes resulting from qualifying observable price changes. In addition, the existing impairment model has been replaced with a new one-step qualitative impairment model. Adjustments resulting from impairments and qualifying observable price changes are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. As of September 28, 2018 and June 30, 2018, these investments were not material.

[0000106040-18-000034:notes:66]
[same as prior period, unchanged from 0000106040-18-000016:notes:85]

[0000106040-18-000034:notes:67]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2019 and the fourth quarter of 2018, respectively.

[0000106040-18-000034:notes:68]
|  | September 28, 2018 |  | June 29, 2018 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 31 |  |  | $ | 34 |  |  | $ | 31 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,951 |  |  | 4,968 |  |  | 4,982 |  |  | 5,013 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,442 |  |  | 2,451 |  |  | 2,448 |  |  | 2,452 |  |
| 1.50% convertible notes due 2024 | 938 |  |  | 1,022 |  |  | 931 |  |  | 1,114 |  |
| 4.750% senior unsecured notes due 2026 | 2,281 |  |  | 2,232 |  |  | 2,280 |  |  | 2,238 |  |
| Total | $ | 10,643 |  |  | $ | 10,707 |  |  | $ | 10,672 |  |  | $ | 10,851 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-18-000034:notes:69]
Income Tax Expense

[0000106040-18-000034:notes:70]
The 2017 Act, enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21%, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred and the creation of new taxes on certain foreign earnings.

[0000106040-18-000034:notes:71]
The Company has not finalized the accounting for the tax effects of the enactment of the 2017 Act. However, consistent with applicable SEC guidance, the Company has made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. For other elements of tax expense noted below, or where the Company has not made an election, the Company has not been able to make a reasonable estimate and continues to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As the Company finalizes the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, the Company expects to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000034:notes:72]
[same as prior period, unchanged from 0000106040-18-000016:notes:95]

[0000106040-18-000034:notes:73]
[same as prior period, unchanged from 0000106040-18-000016:notes:96]

[0000106040-18-000034:notes:74]
The Company recorded a provisional income tax benefit of $65 million for the year ended June 29, 2018, which related to the re-measurements of the Company’s deferred tax balances and is based primarily on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. However, the Company is still analyzing certain aspects of the 2017 Act and refining the calculations, which could potentially affect the measurement of these balances or potentially give rise to new deferred tax amounts. The Company is also analyzing the impact of the 2017 Act to the existing valuation allowance assessments from both a federal and state tax perspective, which could potentially affect the realizability of the existing deferred tax assets. In calculating the provisional amount, the Company utilized an estimate of the expected reversals of certain tax assets and liabilities, which may be revised in future quarters during the one-year measurement period as additional information becomes available. The Company did not make any material refinements to the provisional estimate for the three months ended September 28, 2018.

[0000106040-18-000034:notes:75]
[same as prior period, unchanged from 0000106040-18-000016:notes:98]

[0000106040-18-000034:notes:76]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. For the year ended June 29, 2018, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.57 billion for foreign subsidiaries. The calculation of the mandatory deemed repatriation tax liability is provisional and based upon preliminary estimates of post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on a provisional amount of foreign earnings held in cash and other specified assets, which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period. On August 1, 2018, the U.S. Treasury issued proposed regulations as guidance for the mandatory deemed repatriation tax. The Company will continue to evaluate the impact of this guidance through the end of the one-year measurement period. As such, the provisional amount may change during the one-year measurement period when the Company finalizes the calculation of post-1986 foreign earnings and profits and the amount of foreign earnings held in cash or other specified assets. During the three months ended September 28, 2018, the Company reduced its mandatory deemed repatriation tax liability by $302 million, of which $250 million was for the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets is a reclassification that did not have an impact on the Company’s income tax provision for the three months ended September 28, 2018. The remaining $52 million reduction to the mandatory deemed repatriation tax primarily relates to the Company’s decision to no longer carry forward its 2018 operating loss and, instead, apply it against the mandatory deemed repatriation tax. The $52 million benefit results from utilizing the existing fiscal year 2018 operating losses at a 28% tax rate on the Company’s 2018 tax return as compared to the carryforward tax rate of 21%. The Company’s provisional estimate of the mandatory repatriation tax liability after these refinements is $1.26 billion.

[0000106040-18-000034:notes:77]
Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., the Company continues to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires the Company to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. The provisional tax expense recorded by the Company as of June 28, 2018 was based upon an assumption that foreign undistributed earnings are indefinitely reinvested. For the three months ended September 28, 2018, the Company made the decision to no longer continue to assert indefinite reinvestment on a portion of its foreign undistributed earnings in certain foreign jurisdictions and has included a provisional income tax expense of $26 million, related to state income taxes, partially offset by a decrease to the Company’s valuation allowance of $17 million. Amounts related to foreign withholding taxes were not material. The Company will continue to evaluate whether or not to assert indefinite reinvestment on its remaining foreign undistributed earnings upon the completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings. In the event the Company determines not to continue to assert the permanent reinvestment of part or all of the remaining foreign undistributed earnings, such a determination could result in the accrual and payment of additional federal, foreign, state and local taxes.

[0000106040-18-000034:notes:78]
[same as prior period, unchanged from 0000106040-18-000016:notes:101]

[0000106040-18-000034:notes:79]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision is effective for tax years beginning on or after January 1, 2018, which for the Company would be the fiscal year beginning on June 30, 2018 (fiscal year 2019). The Company is continuing to evaluate its accounting policy regarding whether to make an election to account for the effects of this provision either as a component of future income tax expense in the period the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities have been established for timing differences between foreign U.S. GAAP income and U.S. taxable income that would be expected to reverse under the new minimum tax in future years.

[0000106040-18-000034:notes:80]
The following table presents the Company’s income tax expense and the effective tax rate, which reflect provisional amounts related to the 2017 Act as discussed above:

[0000106040-18-000034:notes:81]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Income before taxes | $ | 583 |  |  | $ | 710 |  |
| Income tax expense | $ | 72 |  |  | $ | 29 |  |
| Effective tax rate | 12 | % |  | 4 | % |

[0000106040-18-000034:notes:82]
The primary driver of the difference between the effective tax rate for the three months ended September 28, 2018 and the U.S. Federal statutory rate of 21% is the discrete effect of the provisional income tax benefit of $52 million related to the decision to utilize the Company’s 2018 operating loss to partially offset the mandatory deemed repatriation tax.

[0000106040-18-000034:notes:83]
The primary drivers for the difference between the effective tax rate for the three months ended September 29, 2017 and the U.S. Federal statutory rate of 35% are windfall benefits related to vesting and exercises of stock-based awards, the generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand.

[0000106040-18-000034:notes:84]
During the three months ended September 28, 2018, the Company recorded an increase of $6 million in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of September 28, 2018, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $557 million. Accrued interest and penalties related to unrecognized tax benefits as of September 28, 2018 was $112 million.

[0000106040-18-000034:notes:85]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2009 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the unagreed issues, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-18-000034:notes:86]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of September 28, 2018, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-18-000034:notes:87]
Legal Proceedings

[0000106040-18-000034:notes:88]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-18-000034:notes:89]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-18-000034:notes:90]
Intellectual Property Litigation

[0000106040-18-000034:notes:91]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000034:notes:92]
Antitrust

[0000106040-18-000034:notes:93]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. Counsel for the remaining named plaintiffs are engaged in settlement discussions with counsel for the defendants. The case has been stayed pending these settlement discussions. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000034:notes:94]
Securities

[0000106040-18-000034:notes:95]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015.  The Company believes the allegations to be without merit and intends to defend itself vigorously in this matter.

[0000106040-18-000034:notes:96]
Copyright

[0000106040-18-000034:notes:97]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts.

[0000106040-18-000034:notes:98]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013.

[0000106040-18-000034:notes:99]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, the Company and ZPÜ intend to dismiss the actions against each other following an accounting and payment of past liabilities. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.

[0000106040-18-000034:notes:100]
Tax

[0000106040-18-000034:notes:101]
For disclosures regarding a statutory notice of deficiency issued by the IRS on June 28, 2018 and a petition filed by the Company with the U.S. Tax Court in September 2018, see Note 11, Income Tax Expense.

[0000106040-18-000034:notes:102]
Other Matters

[0000106040-18-000034:notes:103]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-18-000034:notes:104]
Recent Accounting Pronouncements

[0000106040-18-000034:notes:105]
Accounting Pronouncements Recently Adopted

[0000106040-18-000034:notes:106]
On August 29, 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2018-15, “Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” (“ASU 2018-15”), to reduce diversity in practice in accounting for the costs of implementing cloud computing arrangements that are service contracts.  ASU 2018-15 allows entities to apply the guidance in the FASB Accounting Standards Codification (“ASC”) 350-40 to determine which implementation costs are eligible to be capitalized as assets in a cloud computing arrangement that is considered a service contract.  The Company adopted this standard on a prospective basis effective June 30, 2018, the beginning of fiscal year 2019, as allowed by the standard.  This standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements upon adoption or for the three months ended September 28, 2018.

[0000106040-18-000034:notes:107]
In February 2018, the FASB issued ASU No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act enacted on December 22, 2017 (the “2017 Act”). Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. Because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. For tax effects that are unrelated to the 2017 Act, the Company’s policy to release these from Accumulated other comprehensive loss on an individual item basis rather than a portfolio basis remains unchanged. The Company early adopted this standard effective June 30, 2018 and elected to reclassify stranded tax effects resulting from the 2017 Act from Accumulated other comprehensive loss to Retained earnings. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:108]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness with the entire change in fair value of designated hedge reported in the results of operations in the same line item as the hedged item. The Company early adopted this standard effective June 30, 2018, using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:109]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. The Company adopted this standard on a prospective basis effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:110]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that the Company report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are now presented in Other expense, net in the Condensed Consolidated Statements of Operations. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:111]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business.” This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective June 30, 2018, and will apply it prospectively to transactions occurring thereafter. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:112]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:113]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. Marketable equity securities previously classified as available-for-sale equity investments are now measured and recorded at fair value with changes in fair value recorded within Other expense, net in the Condensed Consolidated Statements of Operations rather than as a component of Other comprehensive income as in prior years. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-18-000034:notes:114]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which superseded the requirements in ASC 605 “Revenue Recognition” (Topic 605). Topic 606 outlines a comprehensive five-step revenue recognition model based on the principle that an entity should recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. Topic 606 also requires more detailed disclosures to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted Topic 606 effective June 30, 2018, using the modified retrospective method to all contracts that were not completed contracts as of the beginning of the fiscal year. Results for reporting periods beginning with fiscal year 2019 are presented under Topic 606, while prior period information presented on the financial statements or elsewhere in this Quarterly Report on Form 10-Q is reported under the Company’s historic accounting policies under Topic 605 in effect for that period and is not adjusted to reflect the retrospective effect of the adoption of Topic 606. The cumulative effect of adopting Topic 606 was a post-tax increase to the opening retained earnings of $56 million as of June 30, 2018, which was primarily related to our license and royalty revenue arrangements. These arrangements had no remaining performance obligation but were previously recognized under Topic 605 when they were reported to the Company by its licensees, which was generally one quarter in arrears from the licensees’ sales of the licensed products. Adoption of the standard did not have a material impact on the Company’s financial position, results of operations, and cash flows, as of or for the three-month period ended September 28, 2018, and the Company expects that the impact of the adoption of the new standard will not be material to its results of operations prospectively. See Note 3, Revenues, for additional disclosures related to this standard.

[0000106040-18-000034:notes:115]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-18-000034:notes:116]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-18-000034:notes:117]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted. As the Company plans for the adoption of this standard, the Company has completed its first phase of identifying its leases including the identification of embedded leases. The Company is in the process of identifying changes to its processes, internal controls and system requirements and configurations for a new lease accounting system to address the new lease standard. The Company’s implementation efforts are progressing as planned. The Company expects to adopt this standard in the first quarter of fiscal 2020 and expects to elect the practical expedient to not present historical comparative information. The Company continues to evaluate the impact ASU 2016-02 will have on its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-18-000034:notes:118]
Organization and Basis of Presentation

[0000106040-18-000034:notes:119]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”), which is included in each of these three categories.

[0000106040-18-000034:notes:120]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 29, 2018. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 29, 2018. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-18-000034:notes:121]
Fiscal Year

[0000106040-18-000034:notes:122]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2019, which ends on June 28, 2019, and 2018, which ended on June 29, 2018, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-18-000034:notes:123]
Use of Estimates

[0000106040-18-000034:notes:124]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-18-000034:notes:125]
[same as prior period, unchanged from 0000106040-18-000016:notes:132]

[0000106040-18-000034:notes:126]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 939 |  |  | $ | 1,315 |  |
| Other non-current liabilities | 1,076 |  |  | 940 |  |
| Total other non-current liabilities | $ | 2,015 |  |  | $ | 2,255 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-18-000034:notes:127]
[same as prior period, unchanged from 0000106040-18-000016:notes:134]

[0000106040-18-000034:notes:128]
[same as prior period, unchanged from 0000106040-18-000016:notes:135]

[0000106040-18-000034:notes:129]
[same as prior period, unchanged from 0000106040-18-000016:notes:136]

[0000106040-18-000034:notes:130]
[same as prior period, unchanged from 0000106040-18-000016:notes:137]

[0000106040-18-000034:notes:131]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 56 |  |  | 59 |  |
| Net amount recognized | $ | 57 |  |  | $ | 60 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-18-000034:notes:132]
[same as prior period, unchanged from 0000106040-18-000016:notes:139]

[0000106040-18-000034:notes:133]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land | $ | 306 |  |  | $ | 306 |  |
| Buildings and improvements | 1,965 |  |  | 1,949 |  |
| Machinery and equipment | 7,311 |  |  | 7,209 |  |
| Computer equipment and software | 447 |  |  | 440 |  |
| Furniture and fixtures | 51 |  |  | 48 |  |
| Construction-in-process | 251 |  |  | 234 |  |
| Property, plant and equipment, gross | 10,331 |  |  | 10,186 |  |
| Accumulated depreciation | (7,277 | ) |  | (7,091 | ) |
| Property, plant, and equipment, net | $ | 3,054 |  |  | $ | 3,095 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-18-000034:notes:134]
reclassified out of AOCI related to derivative contracts were not material and were charged to Cost of revenue in the Condensed Consolidated Statements of Operations


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-18-000034:notes:135]
Revenues

[0000106040-18-000034:notes:136]
The Company offers a broad range of data storage products that include Client Devices, Data Center Devices and Solutions, and Client Solutions. Client Devices consist of hard disk drives (“HDDs”) and solid state drives (“SSDs”) for computing devices; flash-based embedded storage products; and flash-based memory wafers. Data Center Devices and Solutions consist of high-capacity enterprise HDDs and high-performance enterprise SSDs, data center software and system solutions. Client Solutions consist of HDDs and SSDs embedded into external storage products and removable flash-based products. The Company also generates license and royalty revenues related to its IP patent licenses which are not material.

[0000106040-18-000034:notes:137]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and that uncertainties are resolved in a fairly short period of time.

[0000106040-18-000034:notes:138]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts.  The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-18-000034:notes:139]
The Company’s customer payment terms are typically less than three months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-18-000034:notes:140]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company believes the estimate of variable consideration is not constrained and that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics. The Company’s methodology for the estimates is based on several factors, including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing.  The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are typically recorded as a reduction of the transaction price and, therefore, of revenue.

[0000106040-18-000034:notes:141]
Some of the Company’s revenue arrangements include more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these multiple-element arrangements, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

[0000106040-18-000034:notes:142]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either September 28, 2018 or the date of adoption of Topic 606.

[0000106040-18-000034:notes:143]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three months ended September 28, 2018 were not material.

[0000106040-18-000034:notes:144]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of September 28, 2018 and the date of adoption of Topic 606, contract liabilities were $86 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the three months ended September 28, 2018 were primarily the result of $41 million of revenue recognized during the period that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

[0000106040-18-000034:notes:145]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to unearned revenue and multi-year contracts with future installment payments at the end of any given period. The transaction price allocated to the other remaining performance obligations as of September 28, 2018 was $263 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $87 million during the remainder of fiscal 2019, $58 million in fiscal 2020, $45 million in fiscal 2021 and $73 million thereafter.

[0000106040-18-000034:notes:146]
For the three months ended September 28, 2018 and September 29, 2017, two customers accounted for 11% and 10%, respectively, of the Company’s net revenue. For the three months ended September 28, 2018 and September 29, 2017, the Company’s top 10 customers accounted for 48% and 42% of the Company’s net revenue, respectively.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-18-000034:notes:147]
[same as prior period, unchanged from 0000106040-18-000016:notes:143]

[0000106040-18-000034:notes:148]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Derivative Contracts and Available for Sale Securities |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 29, 2018 | $ | (19 | ) |  | $ | (21 | ) |  | $ | 1 |  |  | $ | (39 | ) |
| Other comprehensive loss before reclassifications | — |  |  | (37 | ) |  | (6 | ) |  | (43 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | 5 |  |  | 5 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Net current-period other comprehensive loss | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Balance at September 28, 2018 | $ | (19 | ) |  | $ | (58 | ) |  | $ | 1 |  |  | $ | (76 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-18-000034:notes:149]
| Condensed Consolidating Balance Sheet |
| As of September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 5 |  |  | $ | 1,061 |  |  | $ | 3,580 |  |  | $ | — |  |  | $ | 4,646 |  |
| Accounts receivable, net | — |  |  | 1,326 |  |  | 893 |  |  | — |  |  | 2,219 |  |
| Intercompany receivables | 2,344 |  |  | 4,306 |  |  | 2,142 |  |  | (8,792 | ) |  | — |  |
| Inventories | — |  |  | 991 |  |  | 2,302 |  |  | (174 | ) |  | 3,119 |  |
| Other current assets | 27 |  |  | 243 |  |  | 317 |  |  | — |  |  | 587 |  |
| Total current assets | 2,376 |  |  | 7,927 |  |  | 9,234 |  |  | (8,966 | ) |  | 10,571 |  |
| Property, plant and equipment, net | — |  |  | 1,072 |  |  | 1,982 |  |  | — |  |  | 3,054 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,028 |  |  | — |  |  | 2,028 |  |
| Goodwill | — |  |  | 387 |  |  | 9,685 |  |  | — |  |  | 10,072 |  |
| Other intangible assets, net | — |  |  | 35 |  |  | 2,369 |  |  | — |  |  | 2,404 |  |
| Investments in consolidated subsidiaries | 21,369 |  |  | 18,981 |  |  | — |  |  | (40,350 | ) |  | — |  |
| Loans due from consolidated affiliates | 247 |  |  | 16 |  |  | — |  |  | (263 | ) |  | — |  |
| Other non-current assets | 59 |  |  | 45 |  |  | 472 |  |  | — |  |  | 576 |  |
| Total assets | $ | 24,051 |  |  | $ | 28,463 |  |  | $ | 25,770 |  |  | $ | (49,579 | ) |  | $ | 28,705 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 193 |  |  | $ | 1,888 |  |  | $ | — |  |  | $ | 2,081 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 286 |  |  | — |  |  | 286 |  |
| Intercompany payables | 1,382 |  |  | 4,159 |  |  | 3,251 |  |  | (8,792 | ) |  | — |  |
| Accrued expenses | 162 |  |  | 561 |  |  | 582 |  |  | — |  |  | 1,305 |  |
| Accrued compensation | — |  |  | 295 |  |  | 205 |  |  | — |  |  | 500 |  |
| Current portion of long-term debt | 213 |  |  | — |  |  | — |  |  | — |  |  | 213 |  |
| Total current liabilities | 1,757 |  |  | 5,208 |  |  | 6,212 |  |  | (8,792 | ) |  | 4,385 |  |
| Long-term debt | 10,899 |  |  | — |  |  | 31 |  |  | — |  |  | 10,930 |  |
| Loans due to consolidated affiliates | — |  |  | 247 |  |  | 16 |  |  | (263 | ) |  | — |  |
| Other liabilities | 20 |  |  | 1,498 |  |  | 497 |  |  | — |  |  | 2,015 |  |
| Total liabilities | 12,676 |  |  | 6,953 |  |  | 6,756 |  |  | (9,055 | ) |  | 17,330 |  |
| Total shareholders’ equity | 11,375 |  |  | 21,510 |  |  | 19,014 |  |  | (40,524 | ) |  | 11,375 |  |
| Total liabilities and shareholders’ equity | $ | 24,051 |  |  | $ | 28,463 |  |  | $ | 25,770 |  |  | $ | (49,579 | ) |  | $ | 28,705 |  |

[0000106040-18-000034:notes:150]
| Condensed Consolidating Balance Sheet |
| As of June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |
| Accounts receivable, net | — |  |  | 1,358 |  |  | 839 |  |  | — |  |  | 2,197 |  |
| Intercompany receivables | 1,903 |  |  | 4,256 |  |  | 2,674 |  |  | (8,833 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,159 |  |  | (205 | ) |  | 2,944 |  |
| Other current assets | 20 |  |  | 195 |  |  | 277 |  |  | — |  |  | 492 |  |
| Total current assets | 1,963 |  |  | 7,467 |  |  | 10,246 |  |  | (9,038 | ) |  | 10,638 |  |
| Property, plant and equipment, net | — |  |  | 1,092 |  |  | 2,003 |  |  | — |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,105 |  |  | — |  |  | 2,105 |  |
| Goodwill | — |  |  | 387 |  |  | 9,688 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 38 |  |  | 2,642 |  |  | — |  |  | 2,680 |  |
| Investments in consolidated subsidiaries | 20,847 |  |  | 19,893 |  |  | — |  |  | (40,740 | ) |  | — |  |
| Loans due from consolidated affiliates | 943 |  |  | 16 |  |  | — |  |  | (959 | ) |  | — |  |
| Other non-current assets | 182 |  |  | 29 |  |  | 431 |  |  | — |  |  | 642 |  |
| Total assets | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 279 |  |  | $ | 1,986 |  |  | $ | — |  |  | $ | 2,265 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Intercompany payables | 1,066 |  |  | 4,648 |  |  | 3,119 |  |  | (8,833 | ) |  | — |  |
| Accrued expenses | 198 |  |  | 505 |  |  | 571 |  |  | — |  |  | 1,274 |  |
| Accrued compensation | — |  |  | 297 |  |  | 182 |  |  | — |  |  | 479 |  |
| Current portion of long-term debt | 179 |  |  | — |  |  | — |  |  | — |  |  | 179 |  |
| Total current liabilities | 1,443 |  |  | 5,729 |  |  | 6,117 |  |  | (8,833 | ) |  | 4,456 |  |
| Long-term debt | 10,962 |  |  | — |  |  | 31 |  |  | — |  |  | 10,993 |  |
| Loans due to consolidated affiliates | — |  |  | 427 |  |  | 532 |  |  | (959 | ) |  | — |  |
| Other liabilities | (1 | ) |  | 1,768 |  |  | 488 |  |  | — |  |  | 2,255 |  |
| Total liabilities | 12,404 |  |  | 7,924 |  |  | 7,168 |  |  | (9,792 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,531 |  |  | 20,998 |  |  | 19,947 |  |  | (40,945 | ) |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-18-000034:notes:151]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | (101 | ) |  | (691 | ) |  | 1,244 |  |  | 253 |  |  | 705 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (63 | ) |  | (214 | ) |  | — |  |  | (277 | ) |
| Purchases of investments | — |  |  | (2 | ) |  | (9 | ) |  | — |  |  | (11 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (115 | ) |  | — |  |  | (115 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 144 |  |  | — |  |  | 144 |  |
| Strategic investments and other, net | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Intercompany loan from consolidated affiliates | 696 |  |  | — |  |  | — |  |  | (696 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | 97 |  |  | (97 | ) |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 793 |  |  | (162 | ) |  | (194 | ) |  | (696 | ) |  | (259 | ) |
| Cash flows from financing activities |  |  |  |  |  |  | — |  |  |  |
| Issuance of stock under employee stock plans | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Taxes paid on vested stock awards under employee stock plans | (66 | ) |  | — |  |  | — |  |  | — |  |  | (66 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Dividends paid to shareholders | (148 | ) |  | — |  |  | — |  |  | — |  |  | (148 | ) |
| Repayment of debt | (38 | ) |  | — |  |  | — |  |  | — |  |  | (38 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (180 | ) |  | (516 | ) |  | 696 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 80 |  |  | 1,426 |  |  | (1,253 | ) |  | (253 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (727 | ) |  | 1,246 |  |  | (1,769 | ) |  | 443 |  |  | (807 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net increase (decrease) in cash and cash equivalents | (35 | ) |  | 393 |  |  | (717 | ) |  | — |  |  | (359 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | 5 |  |  | 1,061 |  |  | 3,580 |  |  | — |  |  | 4,646 |  |

[0000106040-18-000034:notes:152]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (6 | ) |  | $ | 145 |  |  | $ | 1,031 |  |  | $ | (37 | ) |  | $ | 1,133 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (47 | ) |  | (113 | ) |  | — |  |  | (160 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | — |  |  | — |  |  | (93 | ) |
| Purchases of investments | — |  |  | (10 | ) |  | (28 | ) |  | — |  |  | (38 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (229 | ) |  | — |  |  | (229 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 98 |  |  | — |  |  | 98 |  |
| Strategic investments and other, net |  |  |  |  | 23 |  |  | — |  |  | 23 |  |
| Advances from (to) consolidated affiliates | 60 |  |  | (62 | ) |  | — |  |  | 2 |  |  | — |  |
| Net cash provided by (used in) investing activities | 60 |  |  | (212 | ) |  | (228 | ) |  | 2 |  |  | (378 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 20 |  |  | — |  |  |  |  | — |  |  | 20 |  |
| Taxes paid on vested stock awards under employee stock plans | (61 | ) |  | — |  |  |  |  | — |  |  | (61 | ) |
| Dividends paid to shareholders | (147 | ) |  | — |  |  |  |  | — |  |  | (147 | ) |
| Settlement of debt hedge contracts | 26 |  |  |  |  |  |  | — |  |  | 26 |  |
| Repayment of debt | (62 | ) |  |  |  |  |  | — |  |  | (62 | ) |
| Intercompany loan from (to) consolidated affiliates | 300 |  |  |  |  | (300 | ) |  | — |  |  | — |  |
| Change in investment in consolidated subsidiaries | 117 |  |  | (129 | ) |  | (23 | ) |  | 35 |  |  | — |  |
| Net cash provided by (used in) financing activities | 193 |  |  | (129 | ) |  | (323 | ) |  | 35 |  |  | (224 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 247 |  |  | (196 | ) |  | 481 |  |  | — |  |  | 532 |  |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 265 |  |  | $ | 1,016 |  |  | $ | 5,605 |  |  | $ | — |  |  | $ | 6,886 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-18-000034:notes:153]
[same as prior period, unchanged from 0000106040-18-000016:notes:149]

[0000106040-18-000034:notes:154]
The Company’s senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the credit agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-18-000034:notes:155]
| Condensed Consolidating Statement of Operations |
| For the three months ended September 28, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,485 |  |  | $ | 4,996 |  |  | $ | (3,453 | ) |  | $ | 5,028 |  |
| Cost of revenue | — |  |  | 3,005 |  |  | 3,824 |  |  | (3,465 | ) |  | 3,364 |  |
| Gross profit | — |  |  | 480 |  |  | 1,172 |  |  | 12 |  |  | 1,664 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 363 |  |  | 213 |  |  | — |  |  | 576 |  |
| Selling, general and administrative | 1 |  |  | 251 |  |  | 104 |  |  | — |  |  | 356 |  |
| Intercompany operating expense (income) | — |  |  | (407 | ) |  | 407 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 32 |  |  | 14 |  |  | — |  |  | 46 |  |
| Total operating expenses | 1 |  |  | 239 |  |  | 738 |  |  | — |  |  | 978 |  |
| Operating income (loss) | (1 | ) |  | 241 |  |  | 434 |  |  | 12 |  |  | 686 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 8 |  |  | 3 |  |  | 12 |  |  | (8 | ) |  | 15 |  |
| Interest expense | (116 | ) |  | (6 | ) |  | (2 | ) |  | 8 |  |  | (116 | ) |
| Other income (expense), net | 1 |  |  | — |  |  | (1 | ) |  | (2 | ) |  | (2 | ) |
| Total interest and other income (expense), net | (107 | ) |  | (3 | ) |  | 9 |  |  | (2 | ) |  | (103 | ) |
| Income (loss) before taxes | (108 | ) |  | 238 |  |  | 443 |  |  | 10 |  |  | 583 |  |
| Income tax expense (benefit) | (144 | ) |  | 118 |  |  | 98 |  |  | — |  |  | 72 |  |
| Equity in earnings from subsidiaries | 475 |  |  | 345 |  |  | — |  |  | (820 | ) |  | — |  |
| Net income | $ | 511 |  |  | $ | 465 |  |  | $ | 345 |  |  | $ | (810 | ) |  | $ | 511 |  |

[0000106040-18-000034:notes:156]
| Condensed Consolidating Statement of Operations |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,710 |  |  | $ | 5,081 |  |  | $ | (3,610 | ) |  | $ | 5,181 |  |
| Cost of revenue | — |  |  | 3,200 |  |  | 3,647 |  |  | (3,579 | ) |  | 3,268 |  |
| Gross profit | — |  |  | 510 |  |  | 1,434 |  |  | (31 | ) |  | 1,913 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 381 |  |  | 211 |  |  | — |  |  | 592 |  |
| Selling, general and administrative | 2 |  |  | 258 |  |  | 104 |  |  | — |  |  | 364 |  |
| Intercompany operating expense (income) | — |  |  | (400 | ) |  | 400 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 11 |  |  | 41 |  |  | — |  |  | 52 |  |
| Total operating expenses | 2 |  |  | 250 |  |  | 756 |  |  | — |  |  | 1,008 |  |
| Operating income (loss) | (2 | ) |  | 260 |  |  | 678 |  |  | (31 | ) |  | 905 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 81 |  |  | 2 |  |  | 14 |  |  | (81 | ) |  | 16 |  |
| Interest expense | (204 | ) |  | (6 | ) |  | (76 | ) |  | 81 |  |  | (205 | ) |
| Other income (expense), net | (8 | ) |  | 11 |  |  | (9 | ) |  | — |  |  | (6 | ) |
| Total interest and other income (expense), net | (131 | ) |  | 7 |  |  | (71 | ) |  | — |  |  | (195 | ) |
| Income (loss) before taxes | (133 | ) |  | 267 |  |  | 607 |  |  | (31 | ) |  | 710 |  |
| Income tax expense (benefit) | (57 | ) |  | 54 |  |  | 32 |  |  | — |  |  | 29 |  |
| Equity in earnings from subsidiaries | 757 |  |  | 592 |  |  | — |  |  | (1,349 | ) |  |  |
| Net income | $ | 681 |  |  | $ | 805 |  |  | $ | 575 |  |  | $ | (1,380 | ) |  | $ | 681 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-18-000034:notes:157]
[same as prior period, unchanged from 0000106040-18-000016:notes:155]

[0000106040-18-000034:notes:158]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,818 |  |  | $ | 5,818 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (3,494 | ) |  | (3,218 | ) |
| Intangible assets, net | $ | 2,404 |  |  | $ | 2,680 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-18-000034:notes:159]
[same as prior period, unchanged from 0000106040-18-000016:notes:157]

[0000106040-18-000034:notes:160]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 29, 2018 | $ | 10,075 |  |
| Foreign currency translation adjustment | (3 | ) |
| Balance at September 28, 2018 | $ | 10,072 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-18-000034:notes:161]
[same as prior period, unchanged from 0000106040-18-000016:notes:159]

[0000106040-18-000034:notes:162]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,139 |  |  | $ | 1,048 |  |
| Work-in-process | 934 |  |  | 878 |  |
| Finished goods | 1,046 |  |  | 1,018 |  |
| Total inventories | $ | 3,119 |  |  | $ | 2,944 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-18-000034:notes:163]
[same as prior period, unchanged from 0000106040-18-000016:notes:161]

[0000106040-18-000034:notes:164]
[same as prior period, unchanged from 0000106040-18-000016:notes:162]

[0000106040-18-000034:notes:165]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 318 |  |  | $ | 311 |  |
| Charges to operations | 34 |  |  | 44 |  |
| Utilization | (26 | ) |  | (38 | ) |
| Changes in estimate related to pre-existing warranties | (3 | ) |  | (15 | ) |
| Warranty accrual, end of period | $ | 323 |  |  | $ | 302 |  |

[0000106040-18-000034:notes:166]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-18-000034:notes:167]
|  | September 28, 2018 |  | June 29, 2018 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion | $ | 169 |  |  | $ | 168 |  |
| Long-term portion | 154 |  |  | 150 |  |
| Total warranty accrual | $ | 323 |  |  | $ | 318 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-18-000034:notes:168]
[same as prior period, unchanged from 0000106040-18-000016:notes:168]

[0000106040-18-000034:notes:169]
|  | Three Months Ended |
|  | September 28, 2018 |  | September 29, 2017 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |
| Restructuring Plan 2016 | $ | — |  |  | $ | 45 |  |
| Closure of Foreign Manufacturing Facilities | 4 |  |  | — |  |
| Business Realignment | 42 |  |  | 7 |  |
| Total employee termination and other charges | $ | 46 |  |  | $ | 52 |  |

[0000106040-18-000034:notes:170]
The following table presents an analysis of the components of the activity against the reserve during the three months ended September 28, 2018:

[0000106040-18-000034:notes:171]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |
| Charges | 38 |  |  | 4 |  |  | 42 |  |
| Cash payments | (13 | ) |  | (4 | ) |  | (17 | ) |
| Accrual balance at September 28, 2018 | $ | 56 |  |  | $ | 5 |  |  | $ | 61 |  |

[0000106040-18-000034:notes:172]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the three months ended September 28, 2018:

[0000106040-18-000034:notes:173]
|  | Employee Termination Benefits |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 56 |  |
| Charges | 4 |  |
| Accrual balance at September 28, 2018 | $ | 60 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-18-000034:notes:174]
[same as prior period, unchanged from 0000106040-18-000016:notes:170]

[0000106040-18-000034:notes:175]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 29, 2018 | 4.8 |  |  | $ | 64.23 |  |  |  |  |  |
| Exercised | (0.2 | ) |  | 37.26 |  |  |  |  | $ | 6 |  |
| Canceled or expired | (0.1 | ) |  | 66.44 |  |  |  |  |  |
| Options outstanding at September 28, 2018 | 4.5 |  |  | $ | 65.38 |  |  | 3.5 |  | $ | 36 |  |
| Exercisable at September 28, 2018 | 3.1 |  |  | $ | 71.72 |  |  | 3.0 |  | $ | 19 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-18-000034:notes:176]
[same as prior period, unchanged from 0000106040-18-000016:notes:172]

[0000106040-18-000034:notes:177]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | $ | 58.31 |  |  |  |
| Granted | 6.1 |  |  | 63.12 |  |  |  |
| Vested | (2.8 | ) |  | 62.84 |  |  | $ | 196 |  |
| Forfeited | (0.3 | ) |  | 54.50 |  |  |  |
| RSUs and PSUs outstanding at September 28, 2018 | 15.6 |  |  | $ | 59.62 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-18-000034:notes:178]
[same as prior period, unchanged from 0000106040-18-000016:notes:174]

[0000106040-18-000034:notes:179]
[same as prior period, unchanged from 0000106040-18-000016:notes:175]

[0000106040-18-000034:notes:180]
Compensation cost related to unvested stock options, restricted stock unit awards, (“RSU”), performance-based restricted stock unit awards, (“PSU”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of September 28, 2018:

[0000106040-18-000034:notes:181]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 19 |  |  | 1.6 |
| RSUs and PSUs (1) | 750 |  |  | 2.7 |
| ESPP | 43 |  |  | 1.3 |
| Total unamortized compensation cost | $ | 812 |  |  |  |

[0000106040-18-000034:notes:182]
[same as prior period, unchanged from 0000106040-18-000016:notes:178]

[0000106040-18-000034:notes:183]
[same as prior period, unchanged from 0000106040-18-000016:notes:179]

[0000106040-18-000034:notes:184]
[same as prior period, unchanged from 0000106040-18-000016:notes:180]

[0000106040-18-000034:notes:185]
[same as prior period, unchanged from 0000106040-18-000016:notes:181]

[0000106040-18-000034:notes:186]
[same as prior period, unchanged from 0000106040-18-000016:notes:182]

[0000106040-18-000034:notes:187]
[same as prior period, unchanged from 0000106040-18-000016:notes:183]

[0000106040-18-000034:notes:188]
The Company’s Board of Directors previously authorized $5.00 billion for the repurchase of the Company’s common stock. During the three months ended September 28, 2018, the Company repurchased 0.8 million shares for a total cost of $61 million under this previous authorization. On July 25, 2018, the Company’s Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. During the three months ended September 28, 2018, the Company repurchased 7.6 million shares for a total cost of $502 million under this new program. Therefore, the Company’s stock repurchases under all stock repurchase authorizations in effect for the three months ended September 28, 2018 totaled $563 million. The remaining amount available to be repurchased under the Company’s stock repurchase program as of September 28, 2018 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-18-000034:notes:189]
[same as prior period, unchanged from 0000106040-18-000016:notes:185]

[0000106040-18-000034:notes:190]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the three months ended September 28, 2018, the Company declared a cash dividend of $0.50 per share on its outstanding common stock totaling $145 million, which was paid on October 15, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-18-000034:notes:191]
[same as prior period, unchanged from 0000106040-18-000016:notes:188]

[0000106040-18-000034:notes:192]
Accounts receivable, net

[0000106040-18-000034:notes:193]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three months ended September 28, 2018, the Company sold trade accounts receivable and received cash proceeds of $243 million. The discounts on the trade accounts receivable sold during the period were not material and were recorded within Other expense, net in the Condensed Consolidated Financial Statements. During the three months ended September 29, 2017, the Company did not sell any trade accounts receivable.

[0000106040-18-000034:notes:194]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-18-000034:notes:195]
[same as prior period, unchanged from 0000106040-18-000016:notes:194]

[0000106040-18-000034:notes:196]
[same as prior period, unchanged from 0000106040-18-000016:notes:195]

[0000106040-18-000034:notes:197]
During the three months ended September 28, 2018 and September 29, 2017, the amounts reclassified out of AOCI related to derivative contracts were not material and were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-18-000034:notes:198]
[same as prior period, unchanged from 0000106040-18-000016:notes:196]

[0000106040-18-000034:notes:199]
Closure of Foreign Manufacturing Facilities

[0000106040-18-000034:notes:200]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company expects the closure to be substantially completed by the end of the calendar year 2019 and to result in total pre-tax charges of approximately $160 million. These charges are expected to consist of approximately $85 million in employee termination benefits and $75 million in asset-related, contract termination and other charges. During the three months ended September 28, 2018, the Company recognized $4 million in employee termination benefits.

[0000106040-18-000034:notes:201]
[same as prior period, unchanged from 0000106040-18-000016:notes:199]

[0000106040-18-000034:notes:202]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the three months ended September 28, 2018:
