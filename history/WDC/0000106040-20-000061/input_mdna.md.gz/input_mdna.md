# WDC MD&A — 0000106040-20-000061


## mdna

[0000106040-20-000061:mdna:1]
Item 2.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-20-000061:mdna:2]
[same as prior period, unchanged from 0000106040-20-000024:mdna:2]

[0000106040-20-000061:mdna:3]
[same as prior period, unchanged from 0000106040-20-000024:mdna:3]

[0000106040-20-000061:mdna:4]
[same as prior period, unchanged from 0000106040-20-000024:mdna:4]

[0000106040-20-000061:mdna:5]
[same as prior period, unchanged from 0000106040-20-000024:mdna:5]

[0000106040-20-000061:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2021, which ends on July 2, 2021, will be comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-20-000061:mdna:7]
[same as prior period, unchanged from 0000106040-20-000024:mdna:7]

[0000106040-20-000061:mdna:8]
Business Structure

[0000106040-20-000061:mdna:9]
Late in the first quarter of fiscal 2021, we announced a decision to reorganize our business by forming two separate product business units: flash-based products and hard disk drive (“HDD”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas.  Beginning in the second fiscal quarter, we are in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. We are developing new reporting processes to support the new business structure and evaluating the impact of these changes on our discussion and analysis of our financial condition and results of operations in the future.

[0000106040-20-000061:mdna:10]
[same as prior period, unchanged from 0000106040-20-000024:mdna:8]

[0000106040-20-000061:mdna:11]
In March 2020, the World Health Organization declared COVID-19 a pandemic, and the United States declared a national emergency. In the intervening months, COVID-19 has spread globally and led governments and other authorities around the world, including federal, state and local authorities in the United States, to impose measures intended to reduce its spread, including restrictions on freedom of movement and business operations such as travel bans, border closings, business limitations and closures (subject to exceptions for essential operations and businesses), quarantines and shelter-in-place orders. Although some of these governmental restrictions have since been lifted or scaled back, a recent surge of COVID-19 infections has resulted in the re-imposition of certain restrictions and may lead to other restrictions being re-implemented in response to efforts to reduce the spread of COVID-19. These measures may remain in place for a significant amount of time. In light of these events, we have taken actions to protect the health and safety of our employees while continuing to serve our global customers as an essential business. We have implemented more thorough sanitation practices as outlined by health organizations and instituted social distancing policies at our locations around the world, including working from home, limiting the number of employees attending meetings, reducing the number of people in our sites at any one time, and suspending employee travel. In addition, the responses to COVID-19 taken by others in the supply chain have impacted our operations. As

[0000106040-20-000061:mdna:12]
35

[0000106040-20-000061:mdna:13]
a result, we have incurred charges of approximately $28 million during the three months ended October 2, 2020, primarily related to higher logistics costs, which were recorded in cost of revenue.

[0000106040-20-000061:mdna:14]
As an essential business, we continue to provide products and solutions that enable the proliferation of data and facilitate the sharing of information remotely, which has become more critical as much of the world is interacting from areas of self-isolation. Generally, demand for our products remains solid. During the three months ended October 2, 2020, we experienced lower sales in some of our capacity enterprise and Client Devices products as customers absorbed purchases made in recent quarters but we also experienced increased sales in retail as COVID-19 restrictions eased, more brick and mortar businesses resumed operations, the work and learn from home trend increased hard drive demand for desktops and notebooks, and gaming increased. Looking forward, we see positive indications of the progression of 5G ramp and the growth of gaming. We also currently expect retail demand to be solid in the near term and HDD to improve as customers absorb recent purchases and we ramp sales as we complete new product qualifications. However, the COVID-19 environment remains dynamic and we cannot predict the duration of the pandemic and how demand may change as it develops.

[0000106040-20-000061:mdna:15]
We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “The COVID-19 pandemic could adversely affect our business, results of operations and financial condition” in Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended July 3, 2020 for more information regarding the risks we face as a result of the COVID-19 pandemic.

[0000106040-20-000061:mdna:16]
[same as prior period, unchanged from 0000106040-20-000024:mdna:12]

[0000106040-20-000061:mdna:17]
Through our three business ventures with Kioxia Corporation (“Kioxia”), referred to as “Flash Ventures”, we and Kioxia operate flash-based memory wafer manufacturing facilities in Japan. We are obligated to pay for variable costs incurred in producing our share of Flash Ventures’ flash-based memory wafer supply, based on our three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, we are obligated to pay for half of Flash Ventures’ fixed costs regardless of the output we choose to purchase. We are also obligated to fund 49.9% to 50% of each Flash Ventures entity’s capital investments to the extent that Flash Ventures entity’s operating cash flow is insufficient to fund these investments. We also co-develop flash technologies (including process technology and memory design) with Kioxia and contribute IP for Flash Ventures’ use.

[0000106040-20-000061:mdna:18]
Since its inception, Flash Ventures’ primary manufacturing site has been located in Yokkaichi, Japan, which currently includes five wafer fabrication facilities. Production levels at the Yokkaichi site were temporarily reduced as a result of an unexpected power outage incident that occurred in the Yokkaichi region on June 15, 2019. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production. The incident resulted in a reduction of our flash wafer availability by approximately 4 exabytes. As a result of this power outage incident, we incurred charges of $68 million recorded in Cost of revenue in the three months ended October 4, 2019, which primarily consisted of unabsorbed manufacturing overhead costs. During the three months ended October 2, 2020, we received a recovery of $30 million related to this incident from our insurance carriers, which was recorded in Cost of revenue. We continue to pursue recovery of our losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-20-000061:mdna:19]
In May 2019, we entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. We have paid for most of our share of initial K1 equipment investments and relocation costs. Other period expenses associated with the initial production ramp at K1 are expected to begin trailing off toward the end of calendar year 2020 as output increases. Other period expenses associated with the initial production ramp at K1 will begin trailing off as output increases toward the end of the calendar year. We also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of October 2, 2020, remaining committed prepayments totaled $178 million.

[0000106040-20-000061:mdna:20]
In October 2020, Kioxia announced the start of construction of the shell for a new fabrication facility in Yokkaichi, Japan, referred to as “Y7”. We expect to continue Flash Ventures investments into Y7 in due course, following the completion of agreements with Kioxia governing the construction and operation of the new facility and according to then-prevailing market trends.

[0000106040-20-000061:mdna:21]
[same as prior period, unchanged from 0000106040-20-000024:mdna:18]

[0000106040-20-000061:mdna:22]
First Quarter Overview

[0000106040-20-000061:mdna:23]
[same as prior period, unchanged from 0000106040-20-000024:mdna:20]

[0000106040-20-000061:mdna:24]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 3,922 |  |  | 100.0 | % |  | $ | 4,040 |  |  | 100.0 | % |  | $ | (118) |  |  | (3) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,018 |  |  | 77.0 |  |  | 3,282 |  |  | 81.2 |  |  | (264) |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 904 |  |  | 23.0 |  |  | 758 |  |  | 18.8 |  |  | 146 |  |  | 19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 555 |  |  | 14.2 |  |  | 574 |  |  | 14.2 |  |  | (19) |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 256 |  |  | 6.5 |  |  | 305 |  |  | 7.5 |  |  | (49) |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 23 |  |  | 0.6 |  |  | 8 |  |  | 0.2 |  |  | 15 |  |  | 188 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 834 |  |  | 21.3 |  |  | 887 |  |  | 22.0 |  |  | (53) |  |  | (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | 70 |  |  | 1.8 |  |  | (129) |  |  | (3.2) |  |  | 199 |  |  | (154) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | 0.1 |  |  | 12 |  |  | 0.3 |  |  | (10) |  |  | (83) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (84) |  |  | (2.1) |  |  | (122) |  |  | (3.0) |  |  | 38 |  |  | (31) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 9 |  |  | 0.2 |  |  | 2 |  |  | — |  |  | 7 |  |  | 350 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (73) |  |  | (1.9) |  |  | (108) |  |  | (2.7) |  |  | 35 |  |  | (32) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss before taxes | (3) |  |  | (0.1) |  |  | (237) |  |  | (5.9) |  |  | 234 |  |  | (99) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 57 |  |  | 1.5 |  |  | 39 |  |  | 1.0 |  |  | 18 |  |  | 46 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (60) |  |  | (1.5) |  |  | $ | (276) |  |  | (6.8) |  |  | 216 |  |  | (78) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-20-000061:mdna:25]
(1)    Percentages may not total due to rounding.

[0000106040-20-000061:mdna:26]
37

[0000106040-20-000061:mdna:27]
[same as prior period, unchanged from 0000106040-20-000024:mdna:26]

[0000106040-20-000061:mdna:28]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |

[0000106040-20-000061:mdna:29]
[same as prior period, unchanged from 0000106040-20-000024:mdna:28]

[0000106040-20-000061:mdna:30]
Net revenue decreased 2.9% for the three months ended October 2, 2020 compared to the three months ended October 4, 2019. The decrease in net revenue for the three months ended October 2, 2020 from the comparable period in the prior year reflects lower volumes of memory for HDD products and more competitive pricing for both HDD and flash products, which contributed approximately 9 and 5 percentage points of decline, respectively, and which were partially offset by higher volumes of flash products sold. Client Devices revenue increased 20% year over year. Higher volumes of flash memory contributed 38 percentage points of growth, primarily from client compute SSD due to increased demand for SSD-based notebook and desktop products resulting from work from home and remote learning trends as well as significant growth in gaming as upcoming game consoles transition from hard drive-based storage solutions to flash. These increases were partially offset by lower average pricing on both HDD and flash products. Our revenue for Data Center Devices and Solutions decreased 26% year over year, which predominantly reflected lower volumes of both HDD and flash-based products as Cloud and OEM customers absorbed some of the capacity purchased in recent quarters and as we continued to ramp up new product transitions in hard drive and flash-based storage solutions. Client Solutions revenue decreased 5% year over year with more competitive pricing driving approximately 8 percentage points of decline, primarily in retail flash products, partially offset by volume growth in both flash and hard drive-based products driven by increased demand for our products that support both remote learning and work from home applications.

[0000106040-20-000061:mdna:31]
The changes in net revenue by geography reflect an increase in Asia primarily driven by our increased sales of mobility products to manufacturers in the Asia region, and a decrease in the Americas driven by lower sales of capacity enterprise products.

[0000106040-20-000061:mdna:32]
Our top 10 customers accounted for 44% and 43% of our net revenue for the three months ended October 2, 2020 and  October 4, 2019, respectively. For the three months ended October 2, 2020, no single customer accounted for 10% or more of our net revenue. For the three months ended October 4, 2019, one customer accounted for 11% of our net revenue.

[0000106040-20-000061:mdna:33]
38

[0000106040-20-000061:mdna:34]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three months ended October 2, 2020 and October 4, 2019, these programs represented 18% and 15%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-20-000061:mdna:35]
[same as prior period, unchanged from 0000106040-20-000024:mdna:34]

[0000106040-20-000061:mdna:36]
Gross profit increased by $146 million for the three months ended October 2, 2020 from the comparable period in the prior year, which primarily reflects the power outage charges of $68 million incurred in the prior year, the $30 million partial recovery in the current year, a $19 million decrease in charges in the current year related to amortization expense on acquired intangible assets and reduced manufacturing costs. These improvements were partially offset by COVID-19 related costs incurred in the current quarter.

[0000106040-20-000061:mdna:37]
Gross margin increased approximately 4 percentage points for the three months ended October 2, 2020 from the comparable period in the prior year, which primarily reflects the impacts of the lower charges noted above as well as reduced manufacturing costs as we ramp production of new products. Over the near term, we expect gross margin to be constrained by lower-margin retail products but expect improved gross margins over the longer term as we complete new product qualifications and ramp production on higher capacity drives.

[0000106040-20-000061:mdna:38]
[same as prior period, unchanged from 0000106040-20-000024:mdna:37]

[0000106040-20-000061:mdna:39]
Research and development (“R&D”) expense decreased $19 million for the three months ended October 2, 2020 from the comparable period in the prior year primarily reflecting additional expense related to the additional week in the prior year.

[0000106040-20-000061:mdna:40]
Selling, general and administrative (“SG&A”) expense decreased $49 million for the three months ended October 2, 2020 from the comparable period in the prior year primarily reflecting a $10 million reduction of expenses related to the additional week in the prior year, approximately $10 million in lower costs in the current year for travel and entertainment and marketing expenses as a result of COVID-19 as well as savings from the exit of our storage systems business and our cost reduction actions.

[0000106040-20-000061:mdna:41]
Employee termination, asset impairment and other charges increased from the comparable period in the prior year as we initiated incremental actions to align our operations with current market demand. For information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000061:mdna:42]
[same as prior period, unchanged from 0000106040-20-000024:mdna:41]

[0000106040-20-000061:mdna:43]
The decrease in total interest and other expense, net for the three months ended October 2, 2020 primarily reflects lower interest expense resulting from the pay-down of principal on our debt and lower index rates.

[0000106040-20-000061:mdna:44]
39

[0000106040-20-000061:mdna:45]
[same as prior period, unchanged from 0000106040-20-000024:mdna:43]

[0000106040-20-000061:mdna:46]
[same as prior period, unchanged from 0000106040-20-000024:mdna:44]

[0000106040-20-000061:mdna:47]
[same as prior period, unchanged from 0000106040-20-000024:mdna:45]

[0000106040-20-000061:mdna:48]
|  | Three Months Ended |  |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |
|  | ($ in millions) |  |
| Loss before taxes | $ | (3) |  |  | $ | (237) |  |  |  |  |  |  |
| Income tax expense | 57 |  |  | 39 |  |  |  |  |  |  |
| Effective tax rate | (1,900) | % |  | (16) | % |  |  |  |  |  |

[0000106040-20-000061:mdna:49]
The primary drivers of the difference between the effective tax rate for the three months ended October 2, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the three months ended October 2, 2020 includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of purchase accounting deferred tax liabilities due to restructuring activities. The discrete items have no impact on the amount of income taxes paid by us.

[0000106040-20-000061:mdna:50]
The primary driver of the difference between the effective tax rate for the three months ended October 4, 2019 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-20-000061:mdna:51]
[same as prior period, unchanged from 0000106040-20-000024:mdna:50]

[0000106040-20-000061:mdna:52]
[same as prior period, unchanged from 0000106040-20-000024:mdna:51]

[0000106040-20-000061:mdna:53]
[same as prior period, unchanged from 0000106040-20-000024:mdna:52]

[0000106040-20-000061:mdna:54]
[same as prior period, unchanged from 0000106040-20-000024:mdna:53]

[0000106040-20-000061:mdna:55]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 363 |  |  | $ | 253 |  |  |  |
| Investing activities | (166) |  |  | 34 |  |  |  |
| Financing activities | (253) |  |  | (492) |  |  |  |
| Effect of exchange rate changes on cash | 3 |  |  | (2) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (53) |  |  | $ | (207) |  |  |  |

[0000106040-20-000061:mdna:56]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020.

[0000106040-20-000061:mdna:57]
During fiscal 2021, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $3.1 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.3 billion during fiscal 2021. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-20-000061:mdna:58]
During fiscal 2019, we determined that it was our intention to repatriate all of our foreign undistributed earnings as a result of the 2017 Act, except a portion of our foreign undistributed earnings, which could result in additional federal taxes based on interpretive guidance issued by the IRS. After consideration of this interpretative guidance affecting the taxation of a certain portion of our foreign undistributed earnings, we determined that we do not intend to repatriate this portion of our foreign undistributed earnings and did not establish an accrual for this liability.

[0000106040-20-000061:mdna:59]
A total of $1.97 billion and $2.60 billion of our Cash and cash equivalents was held outside of the U.S. as of October 2, 2020 and October 4, 2019, respectively. As a result of the change in our permanent reinvestment assertion, there are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-20-000061:mdna:60]
[same as prior period, unchanged from 0000106040-20-000024:mdna:59]

[0000106040-20-000061:mdna:61]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $43 million for the three months ended October 2, 2020, as compared to $82 million of net cash used for changes in operating assets and liabilities for the three months ended October 4, 2019. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-20-000061:mdna:62]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |
|  | (in days) |
| Days sales outstanding | 49 |  |  | 35 |  |  |  |  |  |
| Days in inventory | 101 |  |  | 98 |  |  |  |  |  |
| Days payables outstanding | (71) |  |  | (67) |  |  |  |  |  |
| Cash conversion cycle | 79 |  |  | 66 |  |  |  |  |  |

[0000106040-20-000061:mdna:63]
[same as prior period, unchanged from 0000106040-20-000024:mdna:62]

[0000106040-20-000061:mdna:64]
For the three months ended October 2, 2020, DSO increased by 14 days over the prior year, primarily reflecting the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO increased by 3 days over the prior year, primarily reflecting higher stocking levels of HDD inventory. With supply chains experiencing disruptions as a result of COVID-19, we are taking actions to ensure that we have the components we need to build products and are stocking higher levels of inventory so that we can ship by ocean and reduce higher cost air freight. DPO increased by 4 days over the prior year, primarily reflecting resumptions of flash production volumes as well as routine variations in the timing of purchases and payments during the period.

[0000106040-20-000061:mdna:65]
[same as prior period, unchanged from 0000106040-20-000024:mdna:64]

[0000106040-20-000061:mdna:66]
Net cash used in investing activities for the three months ended October 2, 2020 primarily consisted of a $163 million net decrease in notes receivable issuances to Flash Ventures, partially offset by $337 million of capital expenditures. Net cash used in investing activities for the three months ended October 4, 2019 primarily consisted of $277 million of capital expenditures and a net $186 million decrease in notes receivable issuances to Flash Ventures to fund its capital expansion.

[0000106040-20-000061:mdna:67]
[same as prior period, unchanged from 0000106040-20-000024:mdna:66]

[0000106040-20-000061:mdna:68]
[same as prior period, unchanged from 0000106040-20-000024:mdna:67]

[0000106040-20-000061:mdna:69]
During the three months ended October 2, 2020, net cash used in financing activities primarily consisted of $213 million for repayment of debt, which included a $150 million voluntary prepayment on our Term Loan B-4, and $41 million for taxes paid on vested stock awards under employee stock plans. Net cash used in financing activities for the three months ended October 4, 2019 primarily consisted of $319 million for the repayment of our  debt, $147 million to pay dividends on our common stock and $52 million for taxes paid on vested stock awards under employee stock plans.

[0000106040-20-000061:mdna:70]
In April 2020, we suspended our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-20-000061:mdna:71]
[same as prior period, unchanged from 0000106040-20-000024:mdna:69]

[0000106040-20-000061:mdna:72]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-20-000061:mdna:73]
[same as prior period, unchanged from 0000106040-20-000024:mdna:48]

[0000106040-20-000061:mdna:74]
Short- and Long-term Liquidity

[0000106040-20-000061:mdna:75]
[same as prior period, unchanged from 0000106040-20-000024:mdna:73]

[0000106040-20-000061:mdna:76]
The following is a summary of our known contractual cash obligations and commercial commitments as of October 2, 2020:

[0000106040-20-000061:mdna:77]
|  | Total |  | Remaining nine months of 2021 |  | 2022-2023 |  | 2024-2025 |  | Beyond 2025 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 9,498 |  |  | $ | 223 |  |  | $ | 5,875 |  |  | $ | 1,100 |  |  | $ | 2,300 |  |
| Interest on debt | 1,039 |  |  | 182 |  |  | 513 |  |  | 235 |  |  | 109 |  |
| Flash Ventures related commitments(2) | 6,420 |  |  | 2,643 |  |  | 2,590 |  |  | 1,014 |  |  | 173 |  |
| Operating leases | 299 |  |  | 35 |  |  | 64 |  |  | 56 |  |  | 144 |  |
| Purchase obligations and other commitments | 4,370 |  |  | 2,556 |  |  | 1,154 |  |  | 470 |  |  | 190 |  |
| Mandatory Deemed Repatriation Tax | 925 |  |  | — |  |  | 210 |  |  | 417 |  |  | 298 |  |
| Total | $ | 22,551 |  |  | $ | 5,639 |  |  | $ | 10,406 |  |  | $ | 3,292 |  |  | $ | 3,214 |  |

[0000106040-20-000061:mdna:78]
[same as prior period, unchanged from 0000106040-20-000024:mdna:76]

[0000106040-20-000061:mdna:79]
[same as prior period, unchanged from 0000106040-20-000024:mdna:77]

[0000106040-20-000061:mdna:80]
[same as prior period, unchanged from 0000106040-20-000024:mdna:78]

[0000106040-20-000061:mdna:81]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 6, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020. The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 2, 2020, we were in compliance with these financial covenants.

[0000106040-20-000061:mdna:82]
[same as prior period, unchanged from 0000106040-20-000024:mdna:80]

[0000106040-20-000061:mdna:83]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of October 2, 2020, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-20-000061:mdna:84]
[same as prior period, unchanged from 0000106040-20-000024:mdna:82]

[0000106040-20-000061:mdna:85]
[same as prior period, unchanged from 0000106040-20-000024:mdna:83]

[0000106040-20-000061:mdna:86]
[same as prior period, unchanged from 0000106040-20-000024:mdna:84]

[0000106040-20-000061:mdna:87]
[same as prior period, unchanged from 0000106040-20-000024:mdna:85]

[0000106040-20-000061:mdna:88]
|  |  | October 2,2020 |
| Remainder of fiscal 2021 |  | $ | — |  |
| 2022 |  | 106 |  |
| 2023 |  | 104 |  |
| 2024 |  | 179 |  |
| 2025 |  | 238 |  |
| 2026 |  | 298 |  |
| Total |  | $ | 925 |  |

[0000106040-20-000061:mdna:89]
[same as prior period, unchanged from 0000106040-20-000024:mdna:87]

[0000106040-20-000061:mdna:90]
[same as prior period, unchanged from 0000106040-20-000024:mdna:88]

[0000106040-20-000061:mdna:91]
As of October 2, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $711 million. Accrued interest and penalties related to unrecognized tax benefits as of October 2, 2020 was approximately $141 million. Of these amounts, approximately $715 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-20-000061:mdna:92]
[same as prior period, unchanged from 0000106040-20-000024:mdna:90]

[0000106040-20-000061:mdna:93]
We have generally held a balance of fixed and variable rate debt. At October 2, 2020, we had $6.06 billion of variable rate debt, comprising 64% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $4.06 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual interest expense by $41 million.

[0000106040-20-000061:mdna:94]
[same as prior period, unchanged from 0000106040-20-000024:mdna:92]

[0000106040-20-000061:mdna:95]
[same as prior period, unchanged from 0000106040-20-000024:mdna:93]

[0000106040-20-000061:mdna:96]
[same as prior period, unchanged from 0000106040-20-000024:mdna:94]

[0000106040-20-000061:mdna:97]
[same as prior period, unchanged from 0000106040-20-000024:mdna:95]

[0000106040-20-000061:mdna:98]
[same as prior period, unchanged from 0000106040-20-000024:mdna:96]

[0000106040-20-000061:mdna:99]
[same as prior period, unchanged from 0000106040-20-000024:mdna:97]

[0000106040-20-000061:mdna:100]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the three months ended October 2, 2020 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of October 2, 2020 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-20-000061:mdna:101]
[same as prior period, unchanged from 0000106040-20-000024:mdna:99]

[0000106040-20-000061:mdna:102]
We issued a quarterly cash dividend from the first quarter of fiscal 2013 through the third quarter of fiscal 2020. In April 2020, we suspended our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-20-000061:mdna:103]
[same as prior period, unchanged from 0000106040-20-000024:mdna:101]

[0000106040-20-000061:mdna:104]
[same as prior period, unchanged from 0000106040-20-000024:mdna:102]

[0000106040-20-000061:mdna:105]
[same as prior period, unchanged from 0000106040-20-000024:mdna:103]

[0000106040-20-000061:mdna:106]
[same as prior period, unchanged from 0000106040-20-000024:mdna:104]

[0000106040-20-000061:mdna:107]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the fiscal year ended July 3, 2020. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the fiscal year ended July 3, 2020 for a discussion of our critical accounting policies and estimates.

[0000106040-20-000061:mdna:108]
[same as prior period, unchanged from 0000106040-20-000024:mdna:71]
