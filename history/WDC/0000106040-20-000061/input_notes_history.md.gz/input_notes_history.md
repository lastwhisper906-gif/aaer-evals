# WDC note change history — 0000106040-20-000024 → 0000106040-20-000061


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 2, 2020 and July 3, 2020:
  (was, 2020-05-08, similarity 0.9453):
[0000106040-20-000024:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 3, 2020 and June 28, 2019:

- changed (2020-11-06):
[0000106040-20-000061:note_history:2]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 271 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 231 |  |  | 301 |  |
| Notes receivable, Flash Forward | 597 |  |  | 670 |  |
| Investment in Flash Partners | 208 |  |  | 203 |  |
| Investment in Flash Alliance | 307 |  |  | 300 |  |
| Investment in Flash Forward | 132 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,746 |  |  | $ | 1,875 |  |
  (was, 2020-05-08, similarity 0.9767):
[0000106040-20-000024:note_history:2]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Notes receivable, Flash Partners | $ | 335 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 423 |  |  | 878 |  |
| Notes receivable, Flash Forward | 777 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 125 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,157 |  |  | $ | 2,791 |  |

- changed (2020-11-06):
[0000106040-20-000061:note_history:3]
During the three months ended October 2, 2020 and October 4, 2019, the Company made net payments to Flash Ventures of $981 million and $682 million, respectively, for purchased flash-based memory wafers and net loans and investments.
  (was, 2020-05-08, similarity 0.7107):
[0000106040-20-000024:note_history:3]
During the three and nine months ended April 3, 2020 and during the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $842 million and $2.36 billion, and $1.04 billion and $2.90 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

- changed (2020-11-06):
[0000106040-20-000061:note_history:4]
As of October 2, 2020 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $404 million and $407 million, respectively.
  (was, 2020-05-08, similarity 0.9489):
[0000106040-20-000024:note_history:4]
As of April 3, 2020 and June 28, 2019, the Company had Accounts payable balances due to Flash Ventures of $397 million and $331 million, respectively.

- added (2020-11-06):
[0000106040-20-000061:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 2, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2020-11-06):
[0000106040-20-000061:note_history:6]
|  | October 2,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,099 |  |
| Equity investments | 647 |  |
| Operating lease guarantees | 2,004 |  |
| Inventory and prepayments | 575 |  |
| Maximum estimable loss exposure | $ | 4,325 |  |

- changed (2020-11-06):
[0000106040-20-000061:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the three months ended October 2, 2020, the Company received a recovery of $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.
  (was, 2020-05-08, similarity 0.6638):
[0000106040-20-000024:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million in its fiscal 2020, all incurred in the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

- added (2020-11-06):
[0000106040-20-000061:note_history:8]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company has paid for most of its share of initial K1 equipment investments and relocation costs. Other period expenses associated with the initial production ramp at K1 are expected to begin trailing off toward the end of calendar year 2020 as output increases. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of October 2, 2020, remaining committed prepayments totaled $178 million.

- changed (2020-11-06):
[0000106040-20-000061:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020.
  (was, 2020-05-08, similarity 0.9765):
[0000106040-20-000024:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020.

- changed (2020-11-06):
[0000106040-20-000061:note_history:10]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 211 |  |  | $ | 2,004 |  |
  (was, 2020-05-08, similarity 0.9857):
[0000106040-20-000024:note_history:10]
|  | Lease Amounts |  |  |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 198 |  |  | $ | 1,827 |  |

- changed (2020-11-06):
[0000106040-20-000061:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 2, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020:
  (was, 2020-05-08, similarity 0.9666):
[0000106040-20-000024:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 3, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2020:

- changed (2020-11-06):
[0000106040-20-000061:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2021 |  | $ | 407 |  |  | $ | 80 |  |  | $ | 487 |  |
| 2022 |  | 469 |  |  | 51 |  |  | 520 |  |
| 2023 |  | 356 |  |  | 69 |  |  | 425 |  |
| 2024 |  | 194 |  |  | 123 |  |  | 317 |  |
| 2025 |  | 55 |  |  | 113 |  |  | 168 |  |
| Thereafter |  | 15 |  |  | 72 |  |  | 87 |  |
| Total guarantee obligations |  | $ | 1,496 |  |  | $ | 508 |  |  | $ | 2,004 |  |
  (was, 2020-05-08, similarity 0.9836):
[0000106040-20-000024:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |  |  |  |  |
| Remaining three months of 2020 |  | $ | 128 |  |  | $ | 20 |  |  | $ | 148 |  |
| 2021 |  | 450 |  |  | 108 |  |  | 558 |  |
| 2022 |  | 370 |  |  | 49 |  |  | 419 |  |
| 2023 |  | 259 |  |  | 67 |  |  | 326 |  |
| 2024 |  | 123 |  |  | 120 |  |  | 243 |  |
| Thereafter |  | 23 |  |  | 110 |  |  | 133 |  |
| Total guarantee obligations |  | $ | 1,353 |  |  | $ | 474 |  |  | $ | 1,827 |  |

- changed (2020-11-06):
[0000106040-20-000061:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 2, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2020-05-08, similarity 0.9473):
[0000106040-20-000024:note_history:13]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 3, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2020-11-06):
[0000106040-20-000061:note_history:14]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 2, 2020 and October 4, 2019, the Company recognized approximately 2% and 1%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 6% and 4% of Accounts receivable, net as of October 2, 2020 and July 3, 2020, respectively.

- removed (2020-11-06):
[0000106040-20-000024:note_history:15]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 3, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2020-11-06):
[0000106040-20-000024:note_history:16]
|  | April 3,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,535 |  |
| Equity investments | 622 |  |
| Operating lease guarantees | 1,827 |  |
| Inventory and prepayments | 468 |  |
| Maximum estimable loss exposure | $ | 4,452 |  |

- removed (2020-11-06):
[0000106040-20-000024:note_history:17]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company’s share of the initial commitment for K1 will result in equipment investments, relocation and other start-up costs which are expected to be incurred primarily through the end of fiscal year 2020. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 3, 2020, remaining committed prepayments totaled $205 million.

- removed (2020-11-06):
[0000106040-20-000024:note_history:18]
Unis Venture

- removed (2020-11-06):
[0000106040-20-000024:note_history:19]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 3, 2020 and March 29, 2019, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of April 3, 2020 or June 28, 2019.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:20]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.
  (was, 2020-05-08, similarity 0.9945):
[0000106040-20-000024:note_history:20]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

- changed (2020-11-06):
[0000106040-20-000061:note_history:21]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 3, 2020. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 3, 2020. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2020-05-08, similarity 0.8928):
[0000106040-20-000024:note_history:21]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 28, 2019. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2020-11-06):
[0000106040-20-000061:note_history:22]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2021, which ends on July 2, 2021, will be comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.
  (was, 2020-05-08, similarity 0.7593):
[0000106040-20-000024:note_history:22]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2020, which ends on July 3, 2020, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- added (2020-11-06):
[0000106040-20-000061:note_history:23]
Segment Information

- added (2020-11-06):
[0000106040-20-000061:note_history:24]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). Beginning in the second fiscal quarter, the Company is in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. Management expects to finalize its assessment of its operating segments when the transition is completed, which is expected to be by the end of fiscal 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:25]
Debt
Debt consisted of the following as of October 2, 2020 and July 3, 2020:
  (was, 2020-05-08, similarity 0.8955):
[0000106040-20-000024:note_history:25]
Debt
Debt consisted of the following as of April 3, 2020 and June 28, 2019:

- changed (2020-11-06):
[0000106040-20-000061:note_history:26]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,520 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,498 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (126) |  |  | (136) |  |
| Subtotal | 9,372 |  |  | 9,575 |  |
| Less current portion of long-term debt | (286) |  |  | (286) |  |
| Long-term debt | $ | 9,086 |  |  | $ | 9,289 |  |
  (was, 2020-05-08, similarity 0.9773):
[0000106040-20-000024:note_history:26]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,645 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,694 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,774 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (145) |  |  | (172) |  |
| Subtotal | 9,629 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286) |  |  | (276) |  |
| Long-term debt | $ | 9,343 |  |  | $ | 10,246 |  |

- added (2020-11-06):
[0000106040-20-000061:note_history:27]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 2, 2020, the Company was in compliance with these financial covenants.
During the three months ended October 2, 2020, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. Subsequent to October 2, 2020, the 0.50% convertible notes due 2020 were settled in full in accordance with their terms

- removed (2020-11-06):
[0000106040-20-000024:note_history:28]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 3, 2020, the Company was in compliance with these financial covenants.
During the nine months ended April 3, 2020, the Company made aggregate voluntary prepayments of $725 million on its U.S. Term Loan B-4, which were applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of April 3, 2020, there are no longer any scheduled amortization payments due under the U.S. Term Loan B-4 prior to its maturity on April 29, 2023.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:29]
Debt consisted of the following as of October 2, 2020 and July 3, 2020:
  (was, 2020-05-08, similarity 0.8871):
[0000106040-20-000024:note_history:29]
Debt consisted of the following as of April 3, 2020 and June 28, 2019:

- changed (2020-11-06):
[0000106040-20-000061:note_history:30]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,520 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,498 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (126) |  |  | (136) |  |
| Subtotal | 9,372 |  |  | 9,575 |  |
| Less current portion of long-term debt | (286) |  |  | (286) |  |
| Long-term debt | $ | 9,086 |  |  | $ | 9,289 |  |
  (was, 2020-05-08, similarity 0.9773):
[0000106040-20-000024:note_history:30]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,645 |  |  | 4,834 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 1,694 |  |  | 2,425 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,774 |  |  | 10,694 |  |
| Issuance costs and debt discounts | (145) |  |  | (172) |  |
| Subtotal | 9,629 |  |  | 10,522 |  |
| Less current portion of long-term debt | (286) |  |  | (276) |  |
| Long-term debt | $ | 9,343 |  |  | $ | 10,246 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:31]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 2, 2020 and July 3, 2020:
  (was, 2020-05-08, similarity 0.9453):
[0000106040-20-000024:note_history:31]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 3, 2020 and June 28, 2019:

- changed (2020-11-06):
[0000106040-20-000061:note_history:32]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 271 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 231 |  |  | 301 |  |
| Notes receivable, Flash Forward | 597 |  |  | 670 |  |
| Investment in Flash Partners | 208 |  |  | 203 |  |
| Investment in Flash Alliance | 307 |  |  | 300 |  |
| Investment in Flash Forward | 132 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,746 |  |  | $ | 1,875 |  |
  (was, 2020-05-08, similarity 0.9767):
[0000106040-20-000024:note_history:32]
|  | April 3,2020 |  | June 28,2019 |
|  | (in millions) |  |  |
| Notes receivable, Flash Partners | $ | 335 |  |  | $ | 551 |  |
| Notes receivable, Flash Alliance | 423 |  |  | 878 |  |
| Notes receivable, Flash Forward | 777 |  |  | 743 |  |
| Investment in Flash Partners | 200 |  |  | 200 |  |
| Investment in Flash Alliance | 297 |  |  | 296 |  |
| Investment in Flash Forward | 125 |  |  | 123 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,157 |  |  | $ | 2,791 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:33]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
  (was, 2020-05-08, similarity 0.7946):
[0000106040-20-000024:note_history:33]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0000106040-20-000061:note_history:34]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 2, 2020 or July 3, 2020.
  (was, 2020-05-08, similarity 0.958):
[0000106040-20-000024:note_history:34]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 3, 2020 or June 28, 2019.

- changed (2020-11-06):
[0000106040-20-000061:note_history:35]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 2, 2020 and July 3, 2020 as well as the related amortization for the three months ended October 2, 2020 and October 4, 2019 were not material.
  (was, 2020-05-08, similarity 0.9514):
[0000106040-20-000024:note_history:35]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 3, 2020 and June 28, 2019 as well as the related amortization for the three and nine months ended April 3, 2020 and March 29, 2019 were not material.

- changed (2020-11-06):
[0000106040-20-000061:note_history:36]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 2, 2020 and July 3, 2020, contract liabilities were not material.
  (was, 2020-05-08, similarity 0.8636):
[0000106040-20-000024:note_history:36]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 3, 2020 and June 28, 2019, contract liabilities were not material.

- changed (2020-11-06):
[0000106040-20-000061:note_history:37]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 2, 2020 was $102 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $31 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.
  (was, 2020-05-08, similarity 0.9842):
[0000106040-20-000024:note_history:37]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 3, 2020 was $122 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $11 million during the remainder of fiscal 2020, $41 million in fiscal 2021, $39 million in fiscal 2022 and $31 million thereafter.

- changed (2020-11-06):
[0000106040-20-000061:note_history:38]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
  (was, 2020-05-08, similarity 0.7946):
[0000106040-20-000024:note_history:38]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 2,114 |  |  | $ | 2,064 |  |  | $ | 6,918 |  |  | $ | 6,618 |  |  |  |
| Flash-based | 2,061 |  |  | 1,610 |  |  | 5,531 |  |  | 6,317 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,831 |  |  | $ | 1,625 |  |  | $ | 5,244 |  |  | $ | 6,489 |  |  |  |
| Data Center Devices & Solutions | 1,523 |  |  | 1,245 |  |  | 4,544 |  |  | 3,765 |  |  |  |
| Client Solutions | 821 |  |  | 804 |  |  | 2,661 |  |  | 2,681 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,325 |  |  | $ | 1,070 |  |  | $ | 3,934 |  |  | $ | 3,367 |  |  |  |
| Europe, Middle East and Africa | 770 |  |  | 748 |  |  | 2,360 |  |  | 2,394 |  |  |  |
| Asia | 2,080 |  |  | 1,856 |  |  | 6,155 |  |  | 7,174 |  |  |  |
| Total Revenue | $ | 4,175 |  |  | $ | 3,674 |  |  | $ | 12,449 |  |  | $ | 12,935 |  |  |  |

- added (2020-11-06):
[0000106040-20-000061:note_history:39]
The Company’s top 10 customers accounted for 44% of its net revenue for the three months ended October 2, 2020, and 43% of its net revenue for the three months ended October 4, 2019. For the three months ended October 2, 2020, no single customer accounted for 10% of the Company’s net revenue, and for the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue.

- removed (2020-11-06):
[0000106040-20-000024:note_history:40]
The Company’s top 10 customers accounted for 44% of its net revenue for both the three and nine months ended April 3, 2020, and 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively. For the three and nine months ended April 3, 2020 and March 29, 2019, no single customer accounted for 10% or more of the Company’s net revenue.
