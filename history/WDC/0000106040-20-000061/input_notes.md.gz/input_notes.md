# WDC notes — 0000106040-20-000061


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-20-000061:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

[0000106040-20-000061:notes:2]
[same as prior period, unchanged from 0000106040-20-000024:notes:2]

[0000106040-20-000061:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 3, 2020. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended July 3, 2020. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-20-000061:notes:4]
[same as prior period, unchanged from 0000106040-20-000024:notes:4]

[0000106040-20-000061:notes:5]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2021, which ends on July 2, 2021, will be comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-20-000061:notes:6]
[same as prior period, unchanged from 0000106040-20-000024:notes:6]

[0000106040-20-000061:notes:7]
[same as prior period, unchanged from 0000106040-20-000024:notes:7]

[0000106040-20-000061:notes:8]
Segment Information

[0000106040-20-000061:notes:9]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). Beginning in the second fiscal quarter, the Company is in the process of transitioning to this new operating model and discrete information has not yet been established to align with the new business structure. Management expects to finalize its assessment of its operating segments when the transition is completed, which is expected to be by the end of fiscal 2021.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-20-000061:notes:10]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-20-000061:notes:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Updates (“ASU”) No. 2016-13, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000061:notes:12]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted Accounting Standards Codification (ASC) 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-20-000061:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-20-000061:notes:14]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2020, which for the Company is the first quarter of fiscal 2022. Early adoption is permitted. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-20-000061:notes:15]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 2, 2020 or July 3, 2020.

[0000106040-20-000061:notes:16]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 2, 2020 and July 3, 2020 as well as the related amortization for the three months ended October 2, 2020 and October 4, 2019 were not material.

[0000106040-20-000061:notes:17]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 2, 2020 and July 3, 2020, contract liabilities were not material.

[0000106040-20-000061:notes:18]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 2, 2020 was $102 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $31 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.

[0000106040-20-000061:notes:19]
[same as prior period, unchanged from 0000106040-20-000024:notes:18]

[0000106040-20-000061:notes:20]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| Hard disk drives (“HDD”) | $ | 1,844 |  |  | $ | 2,408 |  |  |  |  |  |  |  |
| Flash-based | 2,078 |  |  | 1,632 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 1,946 |  |  | $ | 1,616 |  |  |  |  |  |  |  |
| Data Center Devices & Solutions | 1,129 |  |  | 1,532 |  |  |  |  |  |  |  |
| Client Solutions | 847 |  |  | 892 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,079 |  |  | $ | 1,313 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 629 |  |  | 779 |  |  |  |  |  |  |  |
| Asia | 2,214 |  |  | 1,948 |  |  |  |  |  |  |  |
| Total Revenue | $ | 3,922 |  |  | $ | 4,040 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:21]
The Company’s top 10 customers accounted for 44% of its net revenue for the three months ended October 2, 2020, and 43% of its net revenue for the three months ended October 4, 2019. For the three months ended October 2, 2020, no single customer accounted for 10% of the Company’s net revenue, and for the three months ended October 4, 2019, one customer accounted for 11% of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-20-000061:notes:22]
[same as prior period, unchanged from 0000106040-20-000024:notes:21]

[0000106040-20-000061:notes:23]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the three months ended October 2, 2020 and October 4, 2019, the Company sold trade accounts receivable and received cash proceeds of $128 million and $85 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. As of October 2, 2020 and July 3, 2020, the amount of factored receivables that remained outstanding was $128 million and $113 million, respectively.

[0000106040-20-000061:notes:24]
[same as prior period, unchanged from 0000106040-20-000024:notes:23]

[0000106040-20-000061:notes:25]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,426 |  |  | $ | 1,306 |  |
| Work-in-process | 964 |  |  | 956 |  |
| Finished goods | 965 |  |  | 808 |  |
| Total inventories | $ | 3,355 |  |  | $ | 3,070 |  |

[0000106040-20-000061:notes:26]
[same as prior period, unchanged from 0000106040-20-000024:notes:25]

[0000106040-20-000061:notes:27]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 286 |  |  | $ | 294 |  |
| Buildings and improvements | 1,865 |  |  | 1,837 |  |
| Machinery and equipment | 7,514 |  |  | 7,391 |  |
| Computer equipment and software | 430 |  |  | 429 |  |
| Furniture and fixtures | 52 |  |  | 52 |  |
| Construction-in-process | 327 |  |  | 297 |  |
| Property, plant and equipment, gross | 10,474 |  |  | 10,300 |  |
| Accumulated depreciation | (7,577) |  |  | (7,446) |  |
| Property, plant and equipment, net | $ | 2,897 |  |  | $ | 2,854 |  |

[0000106040-20-000061:notes:28]
[same as prior period, unchanged from 0000106040-20-000024:notes:27]

[0000106040-20-000061:notes:29]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 3, 2020 | $ | 10,067 |  |
| Foreign currency translation adjustment | 2 |  |
| Balance at October 2, 2020 | $ | 10,069 |  |

[0000106040-20-000061:notes:30]
[same as prior period, unchanged from 0000106040-20-000024:notes:33]

[0000106040-20-000061:notes:31]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,543 |  |  | $ | 5,541 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (4,865) |  |  | (4,680) |  |
| Intangible assets, net | $ | 758 |  |  | $ | 941 |  |

[0000106040-20-000061:notes:32]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-20-000061:notes:33]
[same as prior period, unchanged from 0000106040-20-000024:notes:36]

[0000106040-20-000061:notes:34]
[same as prior period, unchanged from 0000106040-20-000024:notes:37]

[0000106040-20-000061:notes:35]
|  | Three Months Ended |  |  |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 408 |  |  | $ | 350 |  |  |  |  |  |  |  |
| Charges to operations | 35 |  |  | 49 |  |  |  |  |  |  |  |
| Utilization | (31) |  |  | (48) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | (21) |  |  | 6 |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 391 |  |  | $ | 357 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:36]
[same as prior period, unchanged from 0000106040-20-000024:notes:39]

[0000106040-20-000061:notes:37]
|  | October 2,2020 |  | July 3,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 191 |  |  | $ | 205 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 200 |  |  | 203 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 391 |  |  | $ | 408 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:38]
[same as prior period, unchanged from 0000106040-20-000024:notes:41]

[0000106040-20-000061:notes:39]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 711 |  |  | $ | 815 |  |
| Payables related to unrecognized tax benefits | 715 |  |  | 720 |  |
| Other non-current liabilities | 885 |  |  | 881 |  |
| Total other liabilities | $ | 2,311 |  |  | $ | 2,416 |  |

[0000106040-20-000061:notes:40]
[same as prior period, unchanged from 0000106040-20-000024:notes:43]

[0000106040-20-000061:notes:41]
[same as prior period, unchanged from 0000106040-20-000024:notes:44]

[0000106040-20-000061:notes:42]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 3, 2020 | $ | (58) |  |  | $ | (2) |  |  |  |  |  |  | $ | (97) |  |  | $ | (157) |  |
| Other comprehensive loss before reclassifications | 1 |  |  | 32 |  |  |  |  |  |  | 18 |  |  | 51 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 12 |  |  | 12 |  |
| Income tax benefit (expense) related to items of other comprehensive loss | — |  |  | — |  |  |  |  |  |  | (7) |  |  | (7) |  |
| Net current-period other comprehensive loss | 1 |  |  | 32 |  |  |  |  |  |  | 23 |  |  | 56 |  |
| Balance at October 2, 2020 | $ | (57) |  |  | $ | 30 |  |  |  |  |  |  | $ | (74) |  |  | $ | (101) |  |

[0000106040-20-000061:notes:43]
During the three months ended October 2, 2020 and October 4, 2019, the amounts reclassified out of AOCI related to derivative contracts were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-20-000061:notes:44]
[same as prior period, unchanged from 0000106040-20-000024:notes:47]

[0000106040-20-000061:notes:45]
[same as prior period, unchanged from 0000106040-20-000024:notes:48]

[0000106040-20-000061:notes:46]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0000106040-20-000061:notes:47]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-20-000061:notes:48]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-20-000061:notes:49]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of October 2, 2020 and July 3, 2020, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-20-000061:notes:50]
|  | October 2, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 861 |  |  | $ | — |  |  | $ | — |  |  | $ | 861 |  |
| Foreign exchange contracts | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Total assets at fair value | $ | 861 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 885 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Interest rate swap contract | — |  |  | 120 |  |  | — |  |  | 120 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 130 |  |  | $ | — |  |  | $ | 130 |  |

[0000106040-20-000061:notes:51]
|  | July 3, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,079 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,079 |  |
| Foreign exchange contracts | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Total assets at fair value | $ | 1,079 |  |  | $ | 28 |  |  | $ | — |  |  | $ | 1,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Interest rate swap contract | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 142 |  |  | $ | — |  |  | $ | 142 |  |

[0000106040-20-000061:notes:52]
During the three months ended October 2, 2020 and October 4, 2019, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-20-000061:notes:53]
[same as prior period, unchanged from 0000106040-20-000024:notes:56]

[0000106040-20-000061:notes:54]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2021 and the fourth quarter of 2020, respectively.

[0000106040-20-000061:notes:55]
|  | October 2, 2020 |  | July 3, 2020 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 34 |  |  | $ | 34 |  |  | $ | 30 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,514 |  |  | 4,427 |  |  | 4,576 |  |  | 4,474 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,536 |  |  | 1,692 |  |  | 1,656 |  |
| 1.50% convertible notes due 2024 | 994 |  |  | 1,043 |  |  | 987 |  |  | 1,036 |  |
| 4.75% senior unsecured notes due 2026 | 2,286 |  |  | 2,475 |  |  | 2,286 |  |  | 2,428 |  |
| Total | $ | 9,372 |  |  | $ | 9,515 |  |  | $ | 9,575 |  |  | $ | 9,624 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-20-000061:notes:56]
Derivative Instruments and Hedging Activities
As of October 2, 2020, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-20-000061:notes:57]
As of October 2, 2020, the amount of existing net losses related to cash flow hedges recorded in AOCI included $70 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of October 2, 2020, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-20-000061:notes:58]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three months ended October 2, 2020 and October 4, 2019, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-20-000061:notes:59]
[same as prior period, unchanged from 0000106040-20-000024:notes:62]

[0000106040-20-000061:notes:60]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of October 2, 2020 and July 3, 2020, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-20-000061:notes:61]
Debt
Debt consisted of the following as of October 2, 2020 and July 3, 2020:

[0000106040-20-000061:notes:62]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,520 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,543 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,498 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (126) |  |  | (136) |  |
| Subtotal | 9,372 |  |  | 9,575 |  |
| Less current portion of long-term debt | (286) |  |  | (286) |  |
| Long-term debt | $ | 9,086 |  |  | $ | 9,289 |  |

[0000106040-20-000061:notes:63]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 2, 2020, the Company was in compliance with these financial covenants.
During the three months ended October 2, 2020, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. Subsequent to October 2, 2020, the 0.50% convertible notes due 2020 were settled in full in accordance with their terms


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-20-000061:notes:64]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand and the Philippines. All pension and other post-retirement benefit plans outside of the Company’s Japan, Thailand and Philippines defined benefit pension plans (the “Pension Plans”) are immaterial to the Condensed Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans assets is 2.5%.

[0000106040-20-000061:notes:65]
[same as prior period, unchanged from 0000106040-20-000024:notes:68]

[0000106040-20-000061:notes:66]
The following table presents the unfunded status of the benefit obligations for the Pension Plans:

[0000106040-20-000061:notes:67]
|  | October 2,2020 |  | July 3,2020 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 374 |  |  | $ | 366 |  |  |  |
| Fair value of plan assets at end of period | 221 |  |  | 215 |  |  |  |
| Unfunded status | $ | 153 |  |  | $ | 151 |  |  |  |

[0000106040-20-000061:notes:68]
The following table presents the unfunded amounts related to the Pension Plans as recognized on the Company’s Condensed Consolidated Balance Sheets:

[0000106040-20-000061:notes:69]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 152 |  |  | 150 |  |
| Net amount recognized | $ | 153 |  |  | $ | 151 |  |

[0000106040-20-000061:notes:70]
Net periodic benefit costs were not material for the three months ended October 2, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-20-000061:notes:71]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-20-000061:notes:72]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-20-000061:notes:73]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 2, 2020 and July 3, 2020:

[0000106040-20-000061:notes:74]
|  | October 2,2020 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 271 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 231 |  |  | 301 |  |
| Notes receivable, Flash Forward | 597 |  |  | 670 |  |
| Investment in Flash Partners | 208 |  |  | 203 |  |
| Investment in Flash Alliance | 307 |  |  | 300 |  |
| Investment in Flash Forward | 132 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,746 |  |  | $ | 1,875 |  |

[0000106040-20-000061:notes:75]
During the three months ended October 2, 2020 and October 4, 2019, the Company made net payments to Flash Ventures of $981 million and $682 million, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-20-000061:notes:76]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-20-000061:notes:77]
As of October 2, 2020 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $404 million and $407 million, respectively.

[0000106040-20-000061:notes:78]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 2, 2020, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-20-000061:notes:79]
|  | October 2,2020 |
|  | (in millions) |
| Notes receivable | $ | 1,099 |  |
| Equity investments | 647 |  |
| Operating lease guarantees | 2,004 |  |
| Inventory and prepayments | 575 |  |
| Maximum estimable loss exposure | $ | 4,325 |  |

[0000106040-20-000061:notes:80]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-20-000061:notes:81]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the three months ended October 4, 2019, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the three months ended October 2, 2020, the Company received a recovery of $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-20-000061:notes:82]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Output from the initial production line at K1 began in the third quarter of fiscal year 2020, although meaningful output from K1 is not expected to begin until the end of calendar 2020. The Company has paid for most of its share of initial K1 equipment investments and relocation costs. Other period expenses associated with the initial production ramp at K1 are expected to begin trailing off toward the end of calendar year 2020 as output increases. The Company also agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of October 2, 2020, remaining committed prepayments totaled $178 million.

[0000106040-20-000061:notes:83]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-20-000061:notes:84]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-20-000061:notes:85]
Off-Balance Sheet Liabilities

[0000106040-20-000061:notes:86]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-20-000061:notes:87]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020.

[0000106040-20-000061:notes:88]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 211 |  |  | $ | 2,004 |  |

[0000106040-20-000061:notes:89]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 2, 2020 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 2, 2020:

[0000106040-20-000061:notes:90]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2021 |  | $ | 407 |  |  | $ | 80 |  |  | $ | 487 |  |
| 2022 |  | 469 |  |  | 51 |  |  | 520 |  |
| 2023 |  | 356 |  |  | 69 |  |  | 425 |  |
| 2024 |  | 194 |  |  | 123 |  |  | 317 |  |
| 2025 |  | 55 |  |  | 113 |  |  | 168 |  |
| Thereafter |  | 15 |  |  | 72 |  |  | 87 |  |
| Total guarantee obligations |  | $ | 1,496 |  |  | $ | 508 |  |  | $ | 2,004 |  |

[0000106040-20-000061:notes:91]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 2, 2020, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-20-000061:notes:92]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 2, 2020 and October 4, 2019, the Company recognized approximately 2% and 1%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 6% and 4% of Accounts receivable, net as of October 2, 2020 and July 3, 2020, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-20-000061:notes:93]
[same as prior period, unchanged from 0000106040-20-000024:notes:97]

[0000106040-20-000061:notes:94]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of October 2, 2020:

[0000106040-20-000061:notes:95]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | (in millions) |  |  |  |  |  |  |  |  |
| Remaining nine months of 2021 | $ | 35 |  |  |  |  |  |  |  |  |  |
| 2022 | 35 |  |  |  |  |  |  |  |  |  |
| 2023 | 29 |  |  |  |  |  |  |  |  |  |
| 2024 | 29 |  |  |  |  |  |  |  |  |  |
| 2025 | 27 |  |  |  |  |  |  |  |  |  |
| Thereafter | 144 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 299 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | (56) |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 243 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 37 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 206 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 228 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 9.0 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.2 | % |  |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:96]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases:

[0000106040-20-000061:notes:97]
|  | Three Months Ended |  |  |  |  |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Cost of operating leases | $ | 13 |  |  | $ | 12 |  |  |  |  |  |  |  |
| Cash paid for operating leases | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 7 |  |  | 49 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:98]
[same as prior period, unchanged from 0000106040-20-000024:notes:102]

[0000106040-20-000061:notes:99]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of October 2, 2020, the Company had the following minimum long-term commitments:

[0000106040-20-000061:notes:100]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining nine months of 2021 |  | $ | 328 |  |
| 2022 |  | 596 |  |
| 2023 |  | 523 |  |
| 2024 |  | 322 |  |
| 2025 |  | 148 |  |
| Thereafter |  | 190 |  |
| Total |  | $ | 2,107 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-20-000061:notes:101]
[same as prior period, unchanged from 0000106040-20-000024:notes:105]

[0000106040-20-000061:notes:102]
The following tables present the Company’s stock-based compensation for equity-settled awards by type (i.e., stock options, restricted stock units (“RSUs”), restricted stock unit awards with performance conditions or market conditions (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”)) and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-20-000061:notes:103]
|  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | October 2,2020 |  | October 4,2019 |  |  |
|  |  |  |  |  | (in millions) |
| Options |  |  |  |  | $ | — |  |  | $ | 2 |  |  |  |
| RSUs and PSUs |  |  |  |  | 67 |  |  | 66 |  |  |  |
| ESPP |  |  |  |  | 9 |  |  | 9 |  |  |  |
| Total |  |  |  |  | $ | 76 |  |  | $ | 77 |  |  |  |

[0000106040-20-000061:notes:104]
|  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | October 2,2020 |  | October 4,2019 |  |  |
|  |  |  |  |  | (in millions) |
| Cost of revenue |  |  |  |  | $ | 12 |  |  | $ | 12 |  |  |  |
| Research and development |  |  |  |  | 39 |  |  | 41 |  |  |  |
| Selling, general and administrative |  |  |  |  | 25 |  |  | 24 |  |  |  |
| Subtotal |  |  |  |  | 76 |  |  | 77 |  |  |  |
| Tax benefit |  |  |  |  | (11) |  |  | (12) |  |  |  |
| Total |  |  |  |  | $ | 65 |  |  | $ | 65 |  |  |  |

[0000106040-20-000061:notes:105]
Windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-20-000061:notes:106]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of October 2, 2020:

[0000106040-20-000061:notes:107]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 743 |  |  | 3.0 |
| ESPP | 29 |  |  | 0.8 |
| Total unamortized compensation cost | $ | 772 |  |  |  |

[0000106040-20-000061:notes:108]
(1)    Weighted average service period assumes the performance metrics are met for the PSUs.

[0000106040-20-000061:notes:109]
[same as prior period, unchanged from 0000106040-20-000024:notes:113]

[0000106040-20-000061:notes:110]
[same as prior period, unchanged from 0000106040-20-000024:notes:114]

[0000106040-20-000061:notes:111]
[same as prior period, unchanged from 0000106040-20-000024:notes:115]

[0000106040-20-000061:notes:112]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 3, 2020 | 2.7 |  |  | $ | 69.16 |  |  | 2.1 |  | $ | — |  |
| Exercised | — |  |  | 18.30 |  |  |  |  | $ | — |  |
| Canceled or expired | (0.2) |  |  | 68.81 |  |  |  |  |  |
| Options outstanding at October 2, 2020 | 2.5 |  |  | 69.21 |  |  | 1.5 |  | $ | — |  |
| Exercisable at October 2, 2020 | 2.5 |  |  | $ | 69.21 |  |  | 1.5 |  | $ | — |  |

[0000106040-20-000061:notes:113]
[same as prior period, unchanged from 0000106040-20-000024:notes:117]

[0000106040-20-000061:notes:114]
[same as prior period, unchanged from 0000106040-20-000024:notes:118]

[0000106040-20-000061:notes:115]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 3, 2020 | 13.3 |  |  | $ | 60.92 |  |  |  |
| Granted | 7.9 |  |  | 37.86 |  |  |  |
| Vested | (3.7) |  |  | 61.20 |  |  | $ | 149 |  |
| Forfeited | (0.5) |  |  | 65.04 |  |  |  |
| RSUs and PSUs outstanding at October 2, 2020 | 17.0 |  |  | 49.70 |  |  |  |

[0000106040-20-000061:notes:116]
[same as prior period, unchanged from 0000106040-20-000024:notes:120]

[0000106040-20-000061:notes:117]
[same as prior period, unchanged from 0000106040-20-000024:notes:121]

[0000106040-20-000061:notes:118]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the three months ended October 2, 2020 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of October 2, 2020 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-20-000061:notes:119]
[same as prior period, unchanged from 0000106040-20-000024:notes:123]

[0000106040-20-000061:notes:120]
The Company issued a quarterly cash dividend from the first quarter of fiscal 2013 up to the third quarter of fiscal 2020. In April 2020, the Company suspended its dividend to reinvest in the business and to support its ongoing deleveraging efforts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-20-000061:notes:121]
Income Tax Expense
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted in response to the COVID-19 pandemic in the U.S. The CARES Act, among other things, allows net operating losses arising in tax years 2018, 2019, and 2020 to be carried back to each of the five preceding taxable years to generate a refund of previously paid income taxes and increases the business interest expense limitation from 30% to 50% of adjusted taxable income for tax years 2019 and 2020. Additionally, countries around the world continue to implement emergency tax measures to provide relief similar to the CARES Act. The Company at present does not expect that any of the provisions of the CARES Act or the emergency tax measures around the world would result in a material cash benefit. However, the Company continues to monitor and evaluate the regulatory and interpretive guidance related to the CARES Act as well as in other jurisdictions.

[0000106040-20-000061:notes:122]
[same as prior period, unchanged from 0000106040-20-000024:notes:126]

[0000106040-20-000061:notes:123]
[same as prior period, unchanged from 0000106040-20-000024:notes:127]

[0000106040-20-000061:notes:124]
|  | Three Months Ended |  |  |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Loss before taxes | $ | (3) |  |  | $ | (237) |  |  |  |  |  |  |  |
| Income tax expense | 57 |  |  | 39 |  |  |  |  |  |  |  |
| Effective tax rate | (1,900) | % |  | (16) | % |  |  |  |  |  |  |

[0000106040-20-000061:notes:125]
The primary drivers of the difference between the effective tax rate for the three months ended October 2, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for the three months ended October 2, 2020 includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of purchase accounting deferred tax liabilities due to restructuring activities. The discrete items have no impact on the amount of income taxes paid by the Company.

[0000106040-20-000061:notes:126]
The primary drivers of the difference between the effective tax rate for the three months ended October 4, 2019 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-20-000061:notes:127]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest and penalties. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest and penalties. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. On May 4, 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2009 and fiscal years 2010 through 2012. In September 2020, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries for fiscal years 2013 through 2015 that, if sustained, would result in additional federal tax totaling approximately $271 million. The Company disagrees with the proposed adjustments. The Company continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-20-000061:notes:128]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of October 2, 2020, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-20-000061:notes:129]
As of October 2, 2020, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $711 million. Accrued interest and penalties related to unrecognized tax benefits as of October 2, 2020 was approximately $141 million. Of these amounts, approximately $715 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-20-000061:notes:130]
Net Loss Per Common Share 
The following table presents the computation of basic and diluted loss per common share:

[0000106040-20-000061:notes:131]
|  | Three Months Ended |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions, except per share data) |  |  |
| Net loss | $ | (60) |  |  | $ | (276) |  |  |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic and diluted | 303 |  |  | 296 |  |  |  |  |  |  |  |
| Loss per common share |  |  |  |  |  |  |  |  |  |
| Basic and diluted | $ | (0.20) |  |  | $ | (0.93) |  |  |  |  |  |  |  |
| Anti-dilutive potential common shares excluded | 16 |  |  | 15 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:132]
The Company computes basic loss per common share using Net loss and the weighted average number of common shares outstanding during the period. Diluted loss per common share is computed using Net loss and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended October 2, 2020 and the three months ended October 4, 2019, the Company recorded net losses, and all shares subject to outstanding equity awards have been excluded for those periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-20-000061:notes:133]
[same as prior period, unchanged from 0000106040-20-000024:notes:137]

[0000106040-20-000061:notes:134]
|  | Three Months Ended |  |  |  |  |
|  | October 2,2020 |  | October 4,2019 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | — |  |  | $ | 4 |  |  |  |  |  |  |  |
| Business Realignment | 23 |  |  | 4 |  |  |  |  |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 23 |  |  | $ | 8 |  |  |  |  |  |  |  |

[0000106040-20-000061:notes:135]
[same as prior period, unchanged from 0000106040-20-000024:notes:143]

[0000106040-20-000061:notes:136]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources.

[0000106040-20-000061:notes:137]
The following table presents an analysis of the components of the activity against the reserve during the three months ended October 2, 2020:

[0000106040-20-000061:notes:138]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 3, 2020 | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Charges | 20 |  |  | 2 |  |  | 22 |  |
| Cash payments | (20) |  |  | (2) |  |  | (22) |  |
| Accrual balance at October 2, 2020 | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-20-000061:notes:139]
[same as prior period, unchanged from 0000106040-20-000024:notes:147]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-20-000061:notes:140]
Legal Proceedings
Tax

[0000106040-20-000061:notes:141]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 12, Income Tax Expense.

[0000106040-20-000061:notes:142]
Other Matters

[0000106040-20-000061:notes:143]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
