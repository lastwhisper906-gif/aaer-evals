# WDC notes — 0000106040-16-000022


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-16-000022:notes:1]
[same as prior period, unchanged from 0000106040-16-000019:notes:4]

[0000106040-16-000022:notes:2]
[same as prior period, unchanged from 0000106040-16-000019:notes:5]

[0000106040-16-000022:notes:3]
On October 21, 2015, the Company entered into the Merger Agreement with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of the Company will merge with and into SanDisk, with SanDisk surviving and becoming a wholly-owned indirect subsidiary of the Company. The Merger is primarily intended to deepen the Company's expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000022:notes:4]
Pursuant to the Merger Agreement, the Company will pay $67.50 per share in cash and issue 0.2387 shares of its common stock per share of SanDisk’s common stock. The merger consideration will be financed by a mix of cash, new debt financing and issuance of the Company’s common stock. For information related to the debt entered into in connection with the Merger, see Note 14 to these condensed consolidated financial statements.

[0000106040-16-000022:notes:5]
Consummation of the Merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and the Company’s shareholders, which was obtained on March 15, 2016; (ii) the expiration or early termination of the waiting period applicable to the consummation of the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, which expired on January 15, 2016, and the receipt of foreign regulatory approvals. In certain circumstances, a termination fee of up to $1.06 billion may be payable by the Company or a termination fee of up to $553.3 million may be payable by SanDisk, upon termination of the transaction as more fully described in the Merger Agreement.

[0000106040-16-000022:notes:6]
Acquisition of Amplidata NV (“Amplidata”)

[0000106040-16-000022:notes:7]
On March 9, 2015, the Company acquired Amplidata, a developer of object storage software for public and private cloud data centers. As a result of the acquisition, Amplidata became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition furthers the Company's strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers.

[0000106040-16-000022:notes:8]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $215 million to goodwill. The values assigned to the acquired assets and liabilities were finalized prior to March 9, 2016, which was the final date of the 12-month measurement period following the date of the acquisition. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements.

[0000106040-16-000022:notes:9]
The final purchase price allocation for Amplidata was as follows (in millions):

[0000106040-16-000022:notes:10]
[same as prior period, unchanged from 0000106040-16-000019:notes:14]

[0000106040-16-000022:notes:11]
The final purchase price allocation reflects adjustments since the date of acquisition that consist of an increase of $42 million to goodwill which primarily related to an adjustment to the value of deferred taxes acquired, an adjustment to the value of intangible assets acquired and an adjustment for the fair value of stock options assumed in the acquisition of Amplidata.

[0000106040-16-000022:notes:12]
The $215 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create hard disk drive storage solutions leveraging the core software acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Amplidata was immaterial to the Company’s condensed consolidated financial statements for the three and nine months ended April 1, 2016.


## us-gaap:DebtDisclosureTextBlock

[0000106040-16-000022:notes:13]
4. Debt

[0000106040-16-000022:notes:14]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the “Credit Agreement”), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.

[0000106040-16-000022:notes:15]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. The Company repaid the $255 million outstanding balance under the revolving credit facility in January 2016. As of April 1, 2016, the term loan facility had a variable interest rate of 1.9% and a remaining outstanding balance of $2.2 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $47 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-16-000022:notes:16]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of April 1, 2016, the Company was in compliance with all applicable financial covenants under the Credit Agreement.

[0000106040-16-000022:notes:17]
For information related to the debt entered into in connection with the planned merger (the “Merger”) with SanDisk Corporation (“SanDisk”), see Note 14 to these condensed consolidated financial statements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-16-000022:notes:18]
[same as prior period, unchanged from 0000106040-16-000019:notes:21]

[0000106040-16-000022:notes:19]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. As of April 1, 2016, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-16-000022:notes:20]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in accumulated other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and nine months ended April 1, 2016 and April 3, 2015.

[0000106040-16-000022:notes:21]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges were determined to be effective as of April 1, 2016 and July 3, 2015. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and nine months ended April 1, 2016 and April 3, 2015.

[0000106040-16-000022:notes:22]
As of April 1, 2016, the net amount of unrealized gains with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next twelve months was $27 million. In addition, as of April 1, 2016, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $996 million and $2.9 billion, and closed $1.0 billion and $3.1 billion, in foreign exchange contracts during the three and nine months ended April 1, 2016, respectively. The Company opened $1.5 billion and $3.5 billion, and closed $1.3 billion and $3.5 billion, in foreign exchange contracts during the three and nine months ended April 3, 2015, respectively. The fair value and balance sheet location of the Company's foreign exchange contracts as of April 1, 2016 and July 3, 2015 were as follows (in millions):

[0000106040-16-000022:notes:23]
|  | Asset Derivatives | Liability Derivatives |
|  | April 1, 2016 | July 3, 2015 | April 1, 2016 | July 3, 2015 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | 31 |  | Other current assets | $ | — |  | Accrued expenses | $ | — |  | Accrued expenses | $ | 31 |  |

[0000106040-16-000022:notes:24]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties and the net amounts recognized in the condensed consolidated balance sheet as of April 1, 2016 (in millions):

[0000106040-16-000022:notes:25]
| Derivatives Designated asHedging Instruments | Gross Amounts of RecognizedAssets (Liabilities) |  | Gross Amounts Offsetin the Balance Sheet |  | Net Amounts of AssetsPresented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 34 |  |  | $ | (3 | ) |  | $ | 31 |  |
| Financial liabilities | (3 | ) |  | 3 |  |  | — |  |
| Total derivative instruments | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000106040-16-000022:notes:26]
[same as prior period, unchanged from 0000106040-16-000019:notes:29]

[0000106040-16-000022:notes:27]
[same as prior period, unchanged from 0000106040-16-000019:notes:30]

[0000106040-16-000022:notes:28]
|  | Amount of Gain (Loss) Recognized in Accumulated OCI on Derivatives | Location ofGain (Loss) Reclassified from Accumulated OCI into Income | Amount of (Gain) Loss Reclassified From Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | Three Months Ended |  | Nine Months Ended |  | Three Months Ended |  | Nine Months Ended | Three Months Ended |  | Nine Months Ended |  | Three Months Ended |  | Nine Months Ended |
| April 1, 2016 |  | April 3, 2015 | April 1, 2016 |  | April 3, 2015 |
| Foreign exchange contracts | $ | 31 |  |  | $ | (9 | ) |  | $ | 19 |  |  | $ | (39 | ) | Cost of revenue | $ | 8 |  |  | $ | 61 |  |  | $ | 10 |  |  | $ | 24 |  |

[0000106040-16-000022:notes:29]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three and nine months ended April 1, 2016 and April 3, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000106040-16-000022:notes:30]
[same as prior period, unchanged from 0000106040-16-000019:notes:33]

[0000106040-16-000022:notes:31]
[same as prior period, unchanged from 0000106040-16-000019:notes:34]

[0000106040-16-000022:notes:32]
The following table presents the Company's stock-based compensation and related tax benefit for the three and nine months ended April 1, 2016 and April 3, 2015 (in millions):

[0000106040-16-000022:notes:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
|  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |
| Options and ESPP | $ | 19 |  |  | $ | 5 |  |  | $ | 17 |  |  | $ | 8 |  |  | $ | 51 |  |  | $ | 13 |  |  | $ | 53 |  |  | $ | 20 |  |
| RSUs | 23 |  |  | 6 |  |  | 21 |  |  | 6 |  |  | 70 |  |  | 18 |  |  | 64 |  |  | 17 |  |
| Total | $ | 42 |  |  | $ | 11 |  |  | $ | 38 |  |  | $ | 14 |  |  | $ | 121 |  |  | $ | 31 |  |  | $ | 117 |  |  | $ | 37 |  |

[0000106040-16-000022:notes:34]
As of April 1, 2016, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $99 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.3 years.

[0000106040-16-000022:notes:35]
For purposes of this footnote, references to restricted stock unit awards (“RSUs”) include performance stock unit awards (“PSUs”). PSUs are granted to certain employees only after the achievement of pre-determined performance metrics. Once the PSU is granted, vesting is then subject to continued service by the employee, and expense is recognized over the vesting period. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved. As of April 1, 2016, the aggregate unamortized fair value of all unvested RSUs was $178 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.9 years, assuming the performance metrics are met for the PSUs.

[0000106040-16-000022:notes:36]
[same as prior period, unchanged from 0000106040-16-000019:notes:39]

[0000106040-16-000022:notes:37]
[same as prior period, unchanged from 0000106040-16-000019:notes:40]

[0000106040-16-000022:notes:38]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| Options outstanding at July 3, 2015 | 6.8 |  |  | $ | 50.00 |  |  |  |  |  |
| Granted | 1.7 |  |  | 82.68 |  |  |  |  |  |
| Exercised | (1.2 | ) |  | 25.10 |  |  |  |  |  |
| Canceled or expired | (0.3 | ) |  | 63.04 |  |  |  |  |  |
| Options outstanding at April 1, 2016 | 7.0 |  |  | $ | 61.68 |  |  | 4.2 |  | $ | 45 |  |
| Exercisable at April 1, 2016 | 3.8 |  |  | $ | 47.36 |  |  | 3.1 |  | $ | 41 |  |
| Vested and expected to vest after April 1, 2016 | 6.8 |  |  | $ | 61.16 |  |  | 4.2 |  | $ | 45 |  |

[0000106040-16-000022:notes:39]
Options granted during the three and nine months ended April 1, 2016 had a weighted average fair value per share of $12.46 and $22.54, respectively. As of April 1, 2016, the Company had options outstanding to purchase an aggregate of 3.1 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $45 million at that date. During the three and nine months ended April 1, 2016, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $13 million and $49 million, respectively, determined as of the date of exercise, as compared to $73 million and $236 million in the respective prior-year periods.

[0000106040-16-000022:notes:40]
[same as prior period, unchanged from 0000106040-16-000019:notes:43]

[0000106040-16-000022:notes:41]
[same as prior period, unchanged from 0000106040-16-000019:notes:44]

[0000106040-16-000022:notes:42]
|  | Number of Shares |  | Weighted Average Grant-Date Fair Value |
| RSUs outstanding at July 3, 2015 | 3.0 |  |  | $ | 73.80 |  |
| Granted | 2.5 |  |  | 68.16 |  |
| Vested | (1.6 | ) |  | 62.43 |  |
| Forfeited | (0.2 | ) |  | 84.57 |  |
| RSUs outstanding at April 1, 2016 | 3.7 |  |  | $ | 74.48 |  |
| Expected to vest after April 1, 2016 | 3.4 |  |  | $ | 74.98 |  |

[0000106040-16-000022:notes:43]
Outstanding RSU awards have dividend equivalent rights which entitle holders of RSUs to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-16-000022:notes:44]
RSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units. The fair value of the shares underlying the RSU awards at the date of grant or assumption was $51 million and $160 million for awards granted in the three and nine months ended April 1, 2016. These amounts are being recognized to expense over the corresponding vesting periods.

[0000106040-16-000022:notes:45]
Included in the table above, the Company granted 1.0 million PSUs in the three months ended April 1, 2016, at a weighted average grant-date fair value of $50.06 per share. The total number of PSUs outstanding as of April 1, 2016 was 1.2 million, with a weighted average fair value per share of $55.78.

[0000106040-16-000022:notes:46]
[same as prior period, unchanged from 0000106040-16-000019:notes:47]

[0000106040-16-000022:notes:47]
During the three and nine months ended April 1, 2016, the Company recognized a $7 million and $18 million benefit, respectively, related to adjustments to fair market value of stock appreciation rights (“SARs”), as compared to a $9 million benefit and $3 million expense in the respective prior-year periods. The tax expense realized as a result of the aforementioned SARs benefit was $1 million and $2 million during the three and nine months ended April 1, 2016, respectively, as compared to a $2 million expense and $1 million benefit during the three and nine months ended April 3, 2015, respectively. The Company's SARs will be settled in cash upon exercise. The Company had a total liability of $22 million and $41 million related to SARs included in accrued expenses in the condensed consolidated balance sheet as of April 1, 2016 and July 3, 2015, respectively. As of April 1, 2016, all SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. As of April 1, 2016, 0.5 million SARs were outstanding with a weighted average exercise price of $7.87. There were no SARs granted during the three and nine months ended April 1, 2016.

[0000106040-16-000022:notes:48]
[same as prior period, unchanged from 0000106040-16-000019:notes:49]

[0000106040-16-000022:notes:49]
The Company's Board of Directors (the “Board”) previously authorized $5.0 billion for the repurchase of the Company's common stock and approved the extension of its stock repurchase program to February 3, 2020. Effective October 21, 2015, in connection with the Merger, the stock repurchase program was suspended. The Company did not repurchase any shares during the three months ended April 1, 2016. The Company repurchased 0.7 million shares for a total cost of $60 million during the nine months ended April 1, 2016. The remaining amount available to be purchased under the Company’s stock repurchase program as of April 1, 2016 was $2.1 billion.

[0000106040-16-000022:notes:50]
[same as prior period, unchanged from 0000106040-16-000019:notes:51]

[0000106040-16-000022:notes:51]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board. In the three months ended April 1, 2016, the Company declared a cash dividend of $0.50 per share to shareholders of record as of April 1, 2016, totaling $116 million, which was paid on April 15, 2016. In the nine months ended April 1, 2016, the Company declared total cash dividends of $1.50 per share for a total of $347 million. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.

[0000106040-16-000022:notes:52]
Termination of Investment by Unis

[0000106040-16-000022:notes:53]
On September 29, 2015, the Company entered into an agreement (the “Stock Purchase Agreement”) with Unis (the “Guarantor”) and Unis Union Information System Ltd., a subsidiary of Unis (the “Investor”), pursuant to which, subject to the conditions in the agreement, the Company agreed to issue and sell to the Investor 40,814,802 shares of the Company’s common stock (the “Shares”) for $92.50 per share, for an aggregate purchase price of approximately $3.775 billion, and the Guarantor agreed to guarantee the payment and performance of Investor’s obligations therein (collectively, the “Transaction”).

[0000106040-16-000022:notes:54]
The closing of the Transaction was subject to certain closing conditions. These closing conditions included clearance by the U.S. Committee on Foreign Investment in the United States (“CFIUS”) and the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, including clearance by the Ministry of Commerce of the People’s Republic of China, the Ministry of Education of the People’s Republic of China, the National Development and Reform Commission of the People’s Republic of China and the State Administration of Foreign Exchange of the People’s Republic of China. In addition, the Investor’s obligation to purchase the shares of common stock of the Company and the Guarantor’s guarantee were subject to approval of the Transaction by shareholders of the Guarantor.

[0000106040-16-000022:notes:55]
On February 22, 2016, CFIUS informed the Company that it planned to undertake an investigation of the transactions contemplated under the Stock Purchase Agreement, triggering a 15-day period during which either the Company or the Investor could terminate the Stock Purchase Agreement. On February 23, 2016, the Investor notified the Company of its termination of the Stock Purchase Agreement pursuant to the terms of the Stock Purchase Agreement. The Company did not incur any early termination penalties in connection with the termination of the Stock Purchase Agreement.

[0000106040-16-000022:notes:56]
The termination of the investment by Unis is not expected to impact the agreement to form a joint venture with Unis to market and sell the Company’s data center storage systems in China and to develop data center storage solutions for the Chinese market in the future.


## us-gaap:EarningsPerShareTextBlock

[0000106040-16-000022:notes:57]
[same as prior period, unchanged from 0000106040-16-000019:notes:55]

[0000106040-16-000022:notes:58]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and awards of restricted stock units.

[0000106040-16-000022:notes:59]
[same as prior period, unchanged from 0000106040-16-000019:notes:57]

[0000106040-16-000022:notes:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Net income | $ | 74 |  |  | $ | 384 |  |  | $ | 608 |  |  | $ | 1,245 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 233 |  |  | 231 |  |  | 232 |  |  | 233 |  |
| Employee stock options and other | 1 |  |  | 5 |  |  | 2 |  |  | 5 |  |
| Diluted | 234 |  |  | 236 |  |  | 234 |  |  | 238 |  |
| Income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.32 |  |  | $ | 1.66 |  |  | $ | 2.62 |  |  | $ | 5.34 |  |
| Diluted | $ | 0.32 |  |  | $ | 1.63 |  |  | $ | 2.60 |  |  | $ | 5.23 |  |
| Anti-dilutive potential common shares excluded* | 6 |  |  | 1 |  |  | 5 |  |  | 1 |  |

[0000106040-16-000022:notes:61]
[same as prior period, unchanged from 0000106040-16-000019:notes:59]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-16-000022:notes:62]
[same as prior period, unchanged from 0000106040-16-000019:notes:60]

[0000106040-16-000022:notes:63]
[same as prior period, unchanged from 0000106040-16-000019:notes:61]

[0000106040-16-000022:notes:64]
[same as prior period, unchanged from 0000106040-16-000019:notes:62]

[0000106040-16-000022:notes:65]
[same as prior period, unchanged from 0000106040-16-000019:notes:63]

[0000106040-16-000022:notes:66]
[same as prior period, unchanged from 0000106040-16-000019:notes:64]

[0000106040-16-000022:notes:67]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of April 1, 2016 and July 3, 2015, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values (in millions):

[0000106040-16-000022:notes:68]
|  | Fair Value Measurements at |  |  |
|  | April 1, 2016 |  |  |
|  | Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 231 |  |
| Total cash equivalents | 231 |  |  | — |  |  | — |  |  | 231 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 146 |  |  | — |  |  | 146 |  |
| Total short-term investments | — |  |  | 146 |  |  | — |  |  | 146 |  |
| Foreign exchange contracts | — |  |  | 31 |  |  | — |  |  | 31 |  |
| Total assets at fair value | $ | 231 |  |  | $ | 177 |  |  | $ | — |  |  | $ | 408 |  |

[0000106040-16-000022:notes:69]
[same as prior period, unchanged from 0000106040-16-000019:notes:67]

[0000106040-16-000022:notes:70]
[same as prior period, unchanged from 0000106040-16-000019:notes:68]

[0000106040-16-000022:notes:71]
[same as prior period, unchanged from 0000106040-16-000019:notes:69]

[0000106040-16-000022:notes:72]
[same as prior period, unchanged from 0000106040-16-000019:notes:70]

[0000106040-16-000022:notes:73]
[same as prior period, unchanged from 0000106040-16-000019:notes:71]

[0000106040-16-000022:notes:74]
[same as prior period, unchanged from 0000106040-16-000019:notes:72]

[0000106040-16-000022:notes:75]
[same as prior period, unchanged from 0000106040-16-000019:notes:73]

[0000106040-16-000022:notes:76]
In the three and nine months ended April 1, 2016, there were no transfers between levels. The carrying amounts of cash, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. As of April 1, 2016, the carrying amount of debt approximated fair value because of its variable interest rate.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-16-000022:notes:77]
[same as prior period, unchanged from 0000106040-16-000019:notes:75]

[0000106040-16-000022:notes:78]
The Company had income tax expense of $6 million and $30 million in the three and nine months ended April 1, 2016, respectively. The Company's income tax expense for the three and nine months ended April 3, 2015 was $28 million and $85 million, respectively. The Company’s tax provision for the three months ended April 1, 2016 reflects a tax benefit of $10 million for deductible acquisition expenses. The Company's tax provision for the nine months ended April 1, 2016 reflects a tax benefit of $34 million from restructuring activities and a tax benefit of $10 million for deductible acquisition expenses. The difference between the effective tax rate and the U.S. Federal statutory rate is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-16-000022:notes:79]
In the three and nine months ended April 1, 2016, the Company recorded a net decrease of $16 million and a net increase of $9 million, respectively, in its liability for unrecognized tax benefits. As of April 1, 2016, the Company's liability for unrecognized tax benefits was approximately $359 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three and nine months ended April 1, 2016.

[0000106040-16-000022:notes:80]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company's federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company has received Revenue Agent Reports (“RARs”) from the IRS that seek to increase the Company's U.S. taxable income which would result in additional federal tax expense totaling approximately $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012. During the nine months ended April 1, 2016, the IRS completed the examination of the fiscal period ended September 5, 2007 of Komag, Incorporated, which the Company acquired on September 5, 2007, with no material adjustments.

[0000106040-16-000022:notes:81]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of April 1, 2016, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-16-000022:notes:82]
5. Legal Proceedings

[0000106040-16-000022:notes:83]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows.

[0000106040-16-000022:notes:84]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-16-000022:notes:85]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company's acquisition of HGST on March 8, 2012 (the “HGST Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-16-000022:notes:86]
Intellectual Property Litigation

[0000106040-16-000022:notes:87]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-16-000022:notes:88]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

[0000106040-16-000022:notes:89]
Seagate Matter

[0000106040-16-000022:notes:90]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the final arbitration award and interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0000106040-16-000022:notes:91]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company had no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. On February 1, 2016, the matter was dismissed with prejudice pursuant to a stipulation of dismissal filed by the Company and Seagate. This matter is now closed.

[0000106040-16-000022:notes:92]
SanDisk Matters

[0000106040-16-000022:notes:93]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk on October 21, 2015 (the “Merger Agreement”).  The complaints alleged, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also alleged that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs were seeking injunctive relief to prevent the Merger from closing.  The plaintiffs were also seeking, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  At the request of the plaintiffs, the court ordered one of these matters dismissed without prejudice on February 26, 2016, and the other on March 8, 2016.

[0000106040-16-000022:notes:94]
Other Matters

[0000106040-16-000022:notes:95]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.

[0000106040-16-000022:notes:96]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. WD intends to defend itself vigorously in this matter.

[0000106040-16-000022:notes:97]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows.  It is reasonably possible that the Company may incur losses totaling up to $119 million, including the amounts accrued.

[0000106040-16-000022:notes:98]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company's expectations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-16-000022:notes:99]
13. Recent Accounting Pronouncements

[0000106040-16-000022:notes:100]
Recently Adopted

[0000106040-16-000022:notes:101]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-17, “Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes” (“ASU 2015-17”), which requires that deferred tax liabilities and assets for each tax-paying jurisdiction within each tax-paying component to be classified as noncurrent in a classified statement of financial position. The Company early adopted ASU 2015-17 during the second quarter of fiscal 2016 on a prospective basis, which resulted in the reclassification of approximately $165 million of net deferred tax assets as of January 1, 2016 from current assets to noncurrent assets. Since the Company adopted this standard on a prospective basis, no adjustments were made to prior-period balance sheets.

[0000106040-16-000022:notes:102]
Recently Issued

[0000106040-16-000022:notes:103]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). The new standard simplifies several aspects of the accounting for share-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The new standard is effective for fiscal years beginning after December 15, 2016, and interim periods within these periods, which for the Company is the first quarter of fiscal 2018. The Company is currently evaluating the impact ASU 2016-09 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:104]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). The new standard, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. The new standard is effective for fiscal years beginning after December 15, 2018, which for the Company is the first quarter of fiscal 2020. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:105]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). The new standard requires equity investments (except those accounted for under the equity method of accounting or those that result in consolidation of the investee) to be measured at fair value with changes in fair value recognized in net income, simplifies the impairment assessment of equity investments without readily determinable fair values, eliminates the requirement to disclose the methods and significant assumptions used to estimate fair value, requires use of the exit price notion when measuring fair value, requires separate presentation in certain financial statements and requires an evaluation of the need for a valuation allowance on a deferred tax asset related to available-for-sale securities. The new standard is effective for fiscal years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019. The Company is currently evaluating the impact ASU 2016-01 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:106]
In September 2015, the FASB issued ASU No. 2015-16, “Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments” (“ASU 2015-16”), which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Acquirers must recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. The new standard is effective for fiscal years beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. Earlier adoption is permitted for any interim and annual financial statements that have not yet been issued. The Company is currently evaluating the impact ASU 2015-16 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:107]
In August 2015, the FASB issued ASU 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”). The new standard states that SEC staff would not object to an entity deferring and presenting debt issuance costs as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The Company is currently evaluating the impact ASU 2015-15 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:108]
In April 2015, the FASB issued ASU 2015-03, “Interest — Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs” (“ASU 2015-03”). The new standard requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The Company is currently evaluating the impact ASU 2015-03 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:109]
In February 2015, the FASB issued ASU 2015-02, “Consolidation (Topic 810): Amendments to the Consolidation Analysis” (“ASU 2015-02”). The new standard eliminates the presumption that a general partner should consolidate a limited partnership, requires that a reporting entity determine whether it has a variable interest in the entity being evaluated for consolidation, eliminates the requirement to consolidate variable interest entities (“VIEs”) caused by certain fees paid to decision makers and eliminates the indefinite deferral of FASB Statement No. 167 included in ASU 2010-10. The new standard is effective for fiscal years beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. Early adoption is permitted. The Company is currently evaluating the impact ASU 2015-02 will have on its consolidated financial statements and related disclosures.

[0000106040-16-000022:notes:110]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts with Customers” (“ASU 2014-09”), which amends the guidance in former Accounting Standards Codification Topic 605, “Revenue Recognition,” to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of this ASU by one year. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years and interim periods within those years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019, and early adoption is permitted beginning after December 15, 2016. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-16-000022:notes:111]
[same as prior period, unchanged from 0000106040-16-000019:notes:107]

[0000106040-16-000022:notes:112]
[same as prior period, unchanged from 0000106040-16-000019:notes:108]

[0000106040-16-000022:notes:113]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal third quarters ended April 1, 2016 and April 3, 2015 both consisted of 13 weeks. The nine months ended April 1, 2016 and April 3, 2015 consisted of 39 and 40 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.

[0000106040-16-000022:notes:114]
[same as prior period, unchanged from 0000106040-16-000019:notes:110]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-16-000022:notes:115]
[same as prior period, unchanged from 0000106040-16-000019:notes:111]

[0000106040-16-000022:notes:116]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three and nine months ended April 1, 2016 and April 3, 2015. The expected long-term rate of return on the Japanese plan assets is 2.5%.

[0000106040-16-000022:notes:117]
[same as prior period, unchanged from 0000106040-16-000019:notes:113]

[0000106040-16-000022:notes:118]
|  | April 1, 2016 |  | July 3, 2015 |
| Benefit obligation | $ | 259 |  |  | $ | 231 |  |
| Fair value of plan assets | (212 | ) |  | (185 | ) |
| Unfunded status | $ | 47 |  |  | $ | 46 |  |

[0000106040-16-000022:notes:119]
[same as prior period, unchanged from 0000106040-16-000019:notes:115]

[0000106040-16-000022:notes:120]
|  | April 1, 2016 |  | July 3, 2015 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 46 |  |  | 45 |  |
| Net amount recognized | $ | 47 |  |  | $ | 46 |  |

[0000106040-16-000022:notes:121]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three and nine months ended April 1, 2016 and April 3, 2015. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $9 million in fiscal 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000106040-16-000022:notes:122]
[same as prior period, unchanged from 0000106040-16-000019:notes:118]

[0000106040-16-000022:notes:123]
The Company periodically incurs charges to realign its operations with anticipated market demand. In the three months ended April 1, 2016, the Company recognized $28 million of expenses related to this realignment, which consisted of $20 million in employee termination benefits and $8 million in contract termination and other costs. In the nine months ended April 1, 2016, the Company recognized $111 million of expenses related to this realignment, which consisted of $76 million in employee termination benefits, $8 million of asset impairments and $27 million of contract termination and other costs.

[0000106040-16-000022:notes:124]
Restructuring Plan (the “Restructuring Plan”)

[0000106040-16-000022:notes:125]
The Company has also initiated a set of actions relating to the Restructuring Plan associated with the integration of substantial portions of its HGST and WD subsidiaries. The Restructuring Plan consists of asset and footprint reduction, product roadmap consolidation and organization rationalization.

[0000106040-16-000022:notes:126]
The Company expects the Restructuring Plan to be substantially completed by the end of calendar year 2017 and it is expected to result in total pre-tax charges of approximately $400 million. These charges are expected to consist of approximately $185 million in employee termination benefits, $125 million in asset charges and $90 million in other related costs. Approximately $275 million of these charges are expected to be cash expenditures. In the three and nine months ended April 1, 2016, the Company recorded $64 million of expenses related to employee termination benefits as part of the Restructuring Plan.

[0000106040-16-000022:notes:127]
All of the components of the Restructuring Plan are not finalized and actual costs, cash expenditures and timing may vary from the Company’s estimates due to changes in the scope or assumptions underlying the Restructuring Plan.

[0000106040-16-000022:notes:128]
[same as prior period, unchanged from 0000106040-16-000019:notes:124]

[0000106040-16-000022:notes:129]
In January 2016, the Company announced it would be closing its head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. In the three and nine months ended April 1, 2016, the Company recognized $48 million of expenses related to the closure of the facility, which consisted of approximately $24 million in land impairment charges, $23 million in employee termination benefits and $1 million in contract termination and other costs. In addition, in the nine months ended April 1, 2016, the Company recognized $55 million of accelerated depreciation charges on assets held at the Odawara facility, of which $40 million was recognized in cost of revenue and $15 million was recognized in research and development within the condensed consolidated statements of income. The Company expects to record approximately $100 million in remaining charges during the fourth quarter of fiscal 2016.

[0000106040-16-000022:notes:130]
The total employee termination, asset impairment and other charges line item within the Company's condensed consolidated statements of income includes all of the activities described above and consisted of the following (in millions):

[0000106040-16-000022:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Employee termination benefits | $ | 107 |  |  | $ | 17 |  |  | $ | 163 |  |  | $ | 60 |  |
| Impairment of assets | 24 |  |  | 2 |  |  | 32 |  |  | 21 |  |
| Contract termination and other | 9 |  |  | (9 | ) |  | 28 |  |  | (9 | ) |
| Total | $ | 140 |  |  | $ | 10 |  |  | $ | 223 |  |  | $ | 72 |  |

[0000106040-16-000022:notes:132]
Impairment charges during the three and nine months ended April 1, 2016 primarily consisted of land impairment related to the closure of the Company's Odawara facility. Impairment charges during the nine months ended April 3, 2015 primarily consisted of other long-lived assets and equipment impairment.

[0000106040-16-000022:notes:133]
The following table provides those cash charges recorded as liabilities within the Company's condensed consolidated balance sheets (in millions):

[0000106040-16-000022:notes:134]
|  | July 3, 2015 |  | Accruals |  | Payments |  | April 1, 2016 |
| Employee termination benefits | $ | 10 |  |  | $ | 166 |  |  | $ | (64 | ) |  | $ | 112 |  |


## us-gaap:SubsequentEventsTextBlock

[0000106040-16-000022:notes:135]
14. Subsequent Event

[0000106040-16-000022:notes:136]
In connection with the Merger with SanDisk, the Company expects to enter into new debt facilities totaling approximately $18.1 billion, of which the Company has incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarterly Report on Form 10-Q. In addition to the notes and new credit agreement described below, the Company expects to enter into an additional bridge facility in the amount of $3.0 billion on the closing date of the Merger.

[0000106040-16-000022:notes:137]
Notes

[0000106040-16-000022:notes:138]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Notes were issued pursuant to indentures (the “Indentures”) among (i) the Company, (ii) HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (the “WD Guarantors”) and (iii) U.S. Bank National Association, as trustee (and as collateral agent with respect to the Secured Notes). Immediately following the consummation of the Merger, SanDisk Technologies, Inc., which will be an indirect subsidiary of the Company (the “SD Guarantor”), and the other parties to the Indentures will enter into supplemental indentures and the SD Guarantor will become party to the Indentures and will agree to guarantee the Company’s obligations under the Notes. The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the Indentures) or with the proceeds of certain non-ordinary course asset sales.

[0000106040-16-000022:notes:139]
The Company has deposited the gross proceeds from the offering of each series of Notes into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreements. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must redeem the Notes at a price equal to 100% of the initial issue price of the Notes, plus accrued and unpaid interest.

[0000106040-16-000022:notes:140]
Prior to the release of the Notes offering proceeds from escrow, each series of Notes and the related guarantees are secured by an exclusive first-priority lien on the funds held in the respective escrow account from the issuance of such series of Notes. Following the release of the Notes offering proceeds from escrow, the Secured Notes and related guarantees will be secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the New Credit Agreement as described below and, as a result, will be effectively senior to the Unsecured Notes to the extent of the value of the assets that secure the Secured Notes and will be effectively pari passu with obligations under the New Credit Agreement and all other existing and future obligations of WDC and the WD Guarantors secured by first-priority liens on the assets securing the Secured Notes (subject to permitted liens and certain limitations).

[0000106040-16-000022:notes:141]
New Credit Agreement

[0000106040-16-000022:notes:142]
On April 29, 2016, the Company entered into a new credit agreement (the “New Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent (the “Administrative Agent”), and the lenders party thereto, which provides for secured loan facilities consisting of a $4.125 billion term loan facility (the “Term Loan A Facility”), a $3.75 billion term loan facility (the “U.S. Term Loan B Facility”), an €885 million term loan facility (the “Euro Term Loan B Facility” and, together with the U.S. Term Loan B Facility, the “Term Loan B Facilities”), and a $1.0 billion revolving credit facility (the “Revolving Credit Facility”). The Revolving Credit Facility includes a $200 million sublimit for letters of credit. The Term Loan B Facilities closed into escrow on April 29, 2016. Borrowings under the U.S. Term Loan B Facility bear interest at a rate per annum, at the Company's option, of either an adjusted LIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.50% or at a base rate plus an applicable margin of 4.50%. The borrowings under the Euro Term Loan B Facility bear interest at a rate per annum equal to an adjusted EURIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.25%. As of April 29, 2016, the variable interest rates on the Term Loan B Facility and the Euro Term Loan B Facility were 6.25% and 6.00%, respectively.

[0000106040-16-000022:notes:143]
The Term Loan A Facility will close and the related proceeds will be received by the Company on the closing date of the Merger. The Revolving Credit Facility will be available starting on the closing date of the Merger. The Term Loan A Facility and the Revolving Credit Facility have terms of five years. The Term Loan B Facilities have terms of seven years. The obligations under the New Credit Agreement are guaranteed by the WD Guarantors. Immediately following the consummation of the Merger, the SD Guarantor will execute a guaranty supplement and will agree to guarantee the Company’s obligations under the New Credit Agreement. The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the Term Loan B Facilities require the Company to pay a 1.00% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before the one year anniversary of the effective date.

[0000106040-16-000022:notes:144]
As of the date of this Quarterly Report on Form 10-Q, the outstanding balances under the New Credit Agreement were $3.75 billion for the U.S. Term Loan B Facility and €885 million for the Euro Term Loan B Facility. Beginning in September 2016, the Company is required to make quarterly principal payments on the Term Loan B Facilities equal to 0.25% of the original principal amount thereof, with the remaining balance due in 2023.

[0000106040-16-000022:notes:145]
The Company has deposited the net proceeds of the borrowings under the Term Loan B Facilities into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreement for the Term Loan B Facilities. Prior to the release of the Term Loan B Facilities proceeds from escrow, the Administrative Agent will have a perfected first-priority lien on the funds held in the respective escrow accounts on behalf of the lenders under the Term Loan B Facilities. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must prepay in full the amount of the Term Loan B Facilities funded into escrow, plus accrued and unpaid interest.

[0000106040-16-000022:notes:146]
At the closing of the Merger, (i) the net proceeds of the borrowings under the Term Loan B Facilities will be released from escrow and (ii) the Company will borrow the full amount of the term loans under the Term Loan A Facility and will have the ability to borrow under the Revolving Credit Facility.

[0000106040-16-000022:notes:147]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the obligations under the New Credit Agreement will be secured on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by such entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

[0000106040-16-000022:notes:148]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the New Credit Agreement will require the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the New Credit Agreement contains customary covenants that will apply following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, make acquisitions and investments, loans and guarantees, enter into transactions with affiliates, make certain modifications of organizational documents and certain debt agreements and merge or consolidate, and customary events of default.

[0000106040-16-000022:notes:149]
Subject to certain exceptions and thresholds, following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the Term Loan A Facility and the Term Loan B Facilities require mandatory prepayments in connection with (i) excess cash flow (with respect to the Term Loan B Facilities only), (ii) non-ordinary course asset sales and other dispositions and (iii) the issuance of certain debt obligations, among other things. In addition, if more than $100 million in aggregate principal amount of SanDisk’s convertible notes due 2017 and 2020 remains outstanding on the date that is 90 days after the closing date of the Merger, the New Credit Agreement requires the Company to make a mandatory prepayment of the term loans under the Term Loan B Facilities in an amount equal to the outstanding amount of such convertible notes.

[0000106040-16-000022:notes:150]
Termination of Existing Credit Agreement

[0000106040-16-000022:notes:151]
On the closing date of the Merger, pursuant to the terms of the New Credit Agreement, Western Digital Technologies, Inc., Western Digital Ireland, Ltd. and Western Digital International Ltd. (collectively, the “Existing Borrowers”) will repay all outstanding loans, together with accrued interest, and will terminate all commitments under the credit agreement dated as of January 9, 2014, as amended, among the Company, the Existing Borrowers, the lenders party thereto and JPMorgan Chase Bank, N.A., as administrative agent.


## wdc:InventoriesPropertyPlantandEquipmentandOtherIntangibleAssetsTableTextBlock

[0000106040-16-000022:notes:152]
The fair value of the Company’s investments classified as available-for-sale securities at April 1, 2016, by remaining contractual maturity, were as follows (in millions):

[0000106040-16-000022:notes:153]
|  | Cost Basis |  | Fair Value |
| Due in less than one year (short-term investments): | $ | 146 |  |  | $ | 146 |  |
| Total | $ | 146 |  |  | $ | 146 |  |

[0000106040-16-000022:notes:154]
|  | April 1, 2016 |  | July 3, 2015 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 132 |  |  | $ | 168 |  |
| Work-in-process | 440 |  |  | 500 |  |
| Finished goods | 655 |  |  | 700 |  |
| Total inventories | $ | 1,227 |  |  | $ | 1,368 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 8,778 |  |  | $ | 8,604 |  |
| Accumulated depreciation | (6,091 | ) |  | (5,639 | ) |
| Property, plant and equipment, net | $ | 2,687 |  |  | $ | 2,965 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 1,018 |  |  | $ | 1,008 |  |
| Accumulated amortization | (750 | ) |  | (676 | ) |
| Other intangible assets, net | $ | 268 |  |  | $ | 332 |  |

[0000106040-16-000022:notes:155]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the nine months ended April 1, 2016 (in millions):

[0000106040-16-000022:notes:156]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 3, 2015 | $ | 5 |  |  | $ | (25 | ) |  | $ | (20 | ) |
| Other comprehensive loss before reclassifications | — |  |  | (9 | ) |  | (9 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 61 |  |  | 61 |  |
| Net current-period other comprehensive income | — |  |  | 52 |  |  | 52 |  |
| Balance at April 1, 2016 | $ | 5 |  |  | $ | 27 |  |  | $ | 32 |  |

[0000106040-16-000022:notes:157]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the nine months ended April 3, 2015 (in millions):

[0000106040-16-000022:notes:158]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | 5 |  |  | $ | 12 |  |
| Other comprehensive loss before reclassifications | — |  |  | (39 | ) |  | (39 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 24 |  |  | 24 |  |
| Net current-period other comprehensive loss | — |  |  | (15 | ) |  | (15 | ) |
| Balance at April 3, 2015 | $ | 7 |  |  | $ | (10 | ) |  | $ | (3 | ) |

[0000106040-16-000022:notes:159]
The following tables summarize, by major type, the fair value and cost basis of the Company’s investments (in millions):

[0000106040-16-000022:notes:160]
|  | April 1, 2016 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| Certificates of deposit | $ | 146 |  |  | $ | — |  |  | $ | 146 |  |
| Total | $ | 146 |  |  | $ | — |  |  | $ | 146 |  |

[0000106040-16-000022:notes:161]
|  | July 3, 2015 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 287 |  |  | $ | — |  |  | $ | 287 |  |
| U.S. Government agency securities | 95 |  |  | — |  |  | 95 |  |
| Commercial paper | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |

[0000106040-16-000022:notes:162]
Changes in the warranty accrual were as follows (in millions):

[0000106040-16-000022:notes:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Warranty accrual, beginning of period | $ | 225 |  |  | $ | 222 |  |  | $ | 221 |  |  | $ | 182 |  |
| Warranty liability assumed as a result of acquisition | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Charges to operations | 36 |  |  | 46 |  |  | 124 |  |  | 145 |  |
| Utilization | (42 | ) |  | (47 | ) |  | (137 | ) |  | (140 | ) |
| Changes in estimate related to pre-existing warranties | 2 |  |  | (1 | ) |  | 13 |  |  | 33 |  |
| Warranty accrual, end of period | $ | 221 |  |  | $ | 221 |  |  | $ | 221 |  |  | $ | 221 |  |


## wdc:SupplementalFinancialStatementDataTextBlock

[0000106040-16-000022:notes:164]
2. Supplemental Financial Statement Data

[0000106040-16-000022:notes:165]
Accounts Receivable

[0000106040-16-000022:notes:166]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. During the three and nine months ended April 1, 2016, the Company sold trade accounts receivable and received cash proceeds of $35 million and $235 million, respectively. During both the three and nine months ended April 3, 2015, the Company sold trade accounts receivable and received cash proceeds of $67 million. The discounts on the sales of trade accounts receivable were not material and were recorded within interest and other expense in the condensed consolidated statements of income.

[0000106040-16-000022:notes:167]
Inventories; Property, Plant and Equipment; and Other Intangible Assets

[0000106040-16-000022:notes:168]
Warranty

[0000106040-16-000022:notes:169]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected. Changes in the warranty accrual were as follows (in millions):

[0000106040-16-000022:notes:170]
The long-term portion of the warranty accrual classified in other liabilities was $75 million as of April 1, 2016 and $71 million as of July 3, 2015.

[0000106040-16-000022:notes:171]
Investments

[0000106040-16-000022:notes:172]
The Company determined no available-for-sale securities were other-than-temporarily impaired during the three and nine months ended April 1, 2016 and April 3, 2015. The Company sold the majority of its existing investments in the three months ended April 1, 2016, resulting in an immaterial realized loss that was included within interest and other expense in the condensed consolidated statements of income. For more information on the Company's available-for-sale securities, see Note 7 to these condensed consolidated financial statements.

[0000106040-16-000022:notes:173]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the condensed consolidated balance sheets and were not material to the condensed consolidated financial statements as of April 1, 2016 and July 3, 2015.

[0000106040-16-000022:notes:174]
Joint Venture

[0000106040-16-000022:notes:175]
In November 2015, the Company entered into an agreement to form a joint venture with Unisplendour Corporation Limited (“Unis”) to market and sell the Company's current data center storage systems in China and to develop data storage systems for the Chinese market in the future. The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by the Company. The joint venture is expected to become operational during the fourth quarter of fiscal 2016, pending regulatory approvals.

[0000106040-16-000022:notes:176]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-16-000022:notes:177]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The income tax impact on components of other comprehensive income is immaterial for all periods presented.
