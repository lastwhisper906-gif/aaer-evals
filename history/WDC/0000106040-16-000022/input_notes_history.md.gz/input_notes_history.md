# WDC note change history — 0000106040-16-000019 → 0000106040-16-000022


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-05-09):
[0000106040-16-000022:note_history:1]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint in the Western District of Pennsylvania against the Company and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices.  The Company intends to defend itself vigorously in this matter.

- changed (2016-05-09):
[0000106040-16-000022:note_history:2]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company had no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. On February 1, 2016, the matter was dismissed with prejudice pursuant to a stipulation of dismissal filed by the Company and Seagate. This matter is now closed.
  (was, 2016-02-10, similarity 0.8965):
[0000106040-16-000019:note_history:2]
Seagate disputed the method the Company used for calculating post-award interest and contended that the Company owed Seagate approximately $29 million in additional interest.  The Company denied Seagate’s contention.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate had been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals. On January 25, 2016, the Minnesota Court of Appeals reversed the District Court’s decision, determined that Seagate is owed additional post-award interest, and directed the District Court to enter judgment in accordance with its opinion.  The Company has no automatic right to appeal and, on January 27, 2016, the Company paid the additional post-award interest, which was not material to the Company’s financial position, results of operations or cash flows.  The additional post-award interest was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States. The Company and Seagate have signed and filed with the court a stipulation of dismissal with prejudice resolving this matter.

- changed (2016-05-09):
[0000106040-16-000022:note_history:3]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk on October 21, 2015 (the “Merger Agreement”).  The complaints alleged, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also alleged that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs were seeking injunctive relief to prevent the Merger from closing.  The plaintiffs were also seeking, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  At the request of the plaintiffs, the court ordered one of these matters dismissed without prejudice on February 26, 2016, and the other on March 8, 2016.
  (was, 2016-02-10, similarity 0.9088):
[0000106040-16-000019:note_history:3]
In November 2015, plaintiffs filed two putative class action complaints in the Superior Court of the State of California, County of Santa Clara, challenging the Agreement and Plan of Merger the Company entered into with SanDisk Corporation (“SanDisk”) on October 21, 2015 (the “Merger Agreement”).  The complaints allege, among other things, that the members of the SanDisk board breached their fiduciary duties to SanDisk’s shareholders by agreeing to sell SanDisk for inadequate consideration, failing to properly value SanDisk, agreeing to inappropriate deal protection provisions that may inhibit other bidders from coming forward with a superior offer, not protecting against alleged conflicts of interest resulting from the SanDisk directors’ own interrelationships or connection with the proposed transaction, and failing to disclose all material information regarding the proposed transaction.  The complaints also allege that the Company aided and abetted the SanDisk board members’ breaches of their fiduciary duties.  The plaintiffs seek injunctive relief to prevent the merger from closing.  The plaintiffs also seek, among other things, to recover costs and disbursement from the defendants, including attorneys’ fees and experts’ fees.  The Company intends to defend itself vigorously in this matter.

- changed (2016-05-09):
[0000106040-16-000022:note_history:4]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.
  (was, 2016-02-10, similarity 0.9988):
[0000106040-16-000019:note_history:4]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to the ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-09):
[0000106040-16-000022:note_history:5]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal third quarters ended April 1, 2016 and April 3, 2015 both consisted of 13 weeks. The nine months ended April 1, 2016 and April 3, 2015 consisted of 39 and 40 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.
  (was, 2016-02-10, similarity 0.8792):
[0000106040-16-000019:note_history:5]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal second quarters ended January 1, 2016 and January 2, 2015 both consisted of 13 weeks. The six months ended January 1, 2016 and January 2, 2015 consisted of 26 and 27 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-09):
[0000106040-16-000022:note_history:6]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the “Credit Agreement”), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.
  (was, 2016-02-10, similarity 0.9664):
[0000106040-16-000019:note_history:6]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the "Credit Agreement"), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.

- changed (2016-05-09):
[0000106040-16-000022:note_history:7]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. The Company repaid the $255 million outstanding balance under the revolving credit facility in January 2016. As of April 1, 2016, the term loan facility had a variable interest rate of 1.9% and a remaining outstanding balance of $2.2 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $47 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.
  (was, 2016-02-10, similarity 0.6824):
[0000106040-16-000019:note_history:7]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of January 1, 2016, the revolving credit facility had a variable interest rate of 1.7% and an outstanding balance of $255 million. The revolving credit facility was classified within current liabilities as of January 1, 2016 as the Company intended to repay the borrowings within the next 12 months. The Company repaid the $255 million outstanding balance under the revolving credit facility on January 15, 2016. As of January 1, 2016, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

- changed (2016-05-09):
[0000106040-16-000022:note_history:8]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of April 1, 2016, the Company was in compliance with all applicable financial covenants under the Credit Agreement.
  (was, 2016-02-10, similarity 0.8993):
[0000106040-16-000019:note_history:8]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default.

- added (2016-05-09):
[0000106040-16-000022:note_history:9]
For information related to the debt entered into in connection with the planned merger (the “Merger”) with SanDisk Corporation (“SanDisk”), see Note 14 to these condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-05-09):
[0000106040-16-000022:note_history:10]
14. Subsequent Event

- added (2016-05-09):
[0000106040-16-000022:note_history:11]
In connection with the Merger with SanDisk, the Company expects to enter into new debt facilities totaling approximately $18.1 billion, of which the Company has incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarterly Report on Form 10-Q. In addition to the notes and new credit agreement described below, the Company expects to enter into an additional bridge facility in the amount of $3.0 billion on the closing date of the Merger.

- added (2016-05-09):
[0000106040-16-000022:note_history:12]
Notes

- added (2016-05-09):
[0000106040-16-000022:note_history:13]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Unsecured Notes” and, together with the Secured Notes, the “Notes”). The Notes were issued pursuant to indentures (the “Indentures”) among (i) the Company, (ii) HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (the “WD Guarantors”) and (iii) U.S. Bank National Association, as trustee (and as collateral agent with respect to the Secured Notes). Immediately following the consummation of the Merger, SanDisk Technologies, Inc., which will be an indirect subsidiary of the Company (the “SD Guarantor”), and the other parties to the Indentures will enter into supplemental indentures and the SD Guarantor will become party to the Indentures and will agree to guarantee the Company’s obligations under the Notes. The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the Indentures) or with the proceeds of certain non-ordinary course asset sales.

- added (2016-05-09):
[0000106040-16-000022:note_history:14]
The Company has deposited the gross proceeds from the offering of each series of Notes into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreements. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must redeem the Notes at a price equal to 100% of the initial issue price of the Notes, plus accrued and unpaid interest.

- added (2016-05-09):
[0000106040-16-000022:note_history:15]
Prior to the release of the Notes offering proceeds from escrow, each series of Notes and the related guarantees are secured by an exclusive first-priority lien on the funds held in the respective escrow account from the issuance of such series of Notes. Following the release of the Notes offering proceeds from escrow, the Secured Notes and related guarantees will be secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the New Credit Agreement as described below and, as a result, will be effectively senior to the Unsecured Notes to the extent of the value of the assets that secure the Secured Notes and will be effectively pari passu with obligations under the New Credit Agreement and all other existing and future obligations of WDC and the WD Guarantors secured by first-priority liens on the assets securing the Secured Notes (subject to permitted liens and certain limitations).

- added (2016-05-09):
[0000106040-16-000022:note_history:16]
New Credit Agreement

- added (2016-05-09):
[0000106040-16-000022:note_history:17]
On April 29, 2016, the Company entered into a new credit agreement (the “New Credit Agreement”) with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent (the “Administrative Agent”), and the lenders party thereto, which provides for secured loan facilities consisting of a $4.125 billion term loan facility (the “Term Loan A Facility”), a $3.75 billion term loan facility (the “U.S. Term Loan B Facility”), an €885 million term loan facility (the “Euro Term Loan B Facility” and, together with the U.S. Term Loan B Facility, the “Term Loan B Facilities”), and a $1.0 billion revolving credit facility (the “Revolving Credit Facility”). The Revolving Credit Facility includes a $200 million sublimit for letters of credit. The Term Loan B Facilities closed into escrow on April 29, 2016. Borrowings under the U.S. Term Loan B Facility bear interest at a rate per annum, at the Company's option, of either an adjusted LIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.50% or at a base rate plus an applicable margin of 4.50%. The borrowings under the Euro Term Loan B Facility bear interest at a rate per annum equal to an adjusted EURIBOR rate (subject to a 0.75% floor) plus an applicable margin of 5.25%. As of April 29, 2016, the variable interest rates on the Term Loan B Facility and the Euro Term Loan B Facility were 6.25% and 6.00%, respectively.

- added (2016-05-09):
[0000106040-16-000022:note_history:18]
The Term Loan A Facility will close and the related proceeds will be received by the Company on the closing date of the Merger. The Revolving Credit Facility will be available starting on the closing date of the Merger. The Term Loan A Facility and the Revolving Credit Facility have terms of five years. The Term Loan B Facilities have terms of seven years. The obligations under the New Credit Agreement are guaranteed by the WD Guarantors. Immediately following the consummation of the Merger, the SD Guarantor will execute a guaranty supplement and will agree to guarantee the Company’s obligations under the New Credit Agreement. The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the Term Loan B Facilities require the Company to pay a 1.00% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before the one year anniversary of the effective date.

- added (2016-05-09):
[0000106040-16-000022:note_history:19]
As of the date of this Quarterly Report on Form 10-Q, the outstanding balances under the New Credit Agreement were $3.75 billion for the U.S. Term Loan B Facility and €885 million for the Euro Term Loan B Facility. Beginning in September 2016, the Company is required to make quarterly principal payments on the Term Loan B Facilities equal to 0.25% of the original principal amount thereof, with the remaining balance due in 2023.

- added (2016-05-09):
[0000106040-16-000022:note_history:20]
The Company has deposited the net proceeds of the borrowings under the Term Loan B Facilities into separate segregated escrow accounts. The release of the escrowed funds is subject to the conditions set forth in the escrow agreement for the Term Loan B Facilities. Prior to the release of the Term Loan B Facilities proceeds from escrow, the Administrative Agent will have a perfected first-priority lien on the funds held in the respective escrow accounts on behalf of the lenders under the Term Loan B Facilities. If the consummation of the Merger does not occur on or prior to January 21, 2017, the Company must prepay in full the amount of the Term Loan B Facilities funded into escrow, plus accrued and unpaid interest.

- added (2016-05-09):
[0000106040-16-000022:note_history:21]
At the closing of the Merger, (i) the net proceeds of the borrowings under the Term Loan B Facilities will be released from escrow and (ii) the Company will borrow the full amount of the term loans under the Term Loan A Facility and will have the ability to borrow under the Revolving Credit Facility.

- added (2016-05-09):
[0000106040-16-000022:note_history:22]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the obligations under the New Credit Agreement will be secured on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by such entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

- added (2016-05-09):
[0000106040-16-000022:note_history:23]
Upon the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the New Credit Agreement will require the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the New Credit Agreement contains customary covenants that will apply following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, make acquisitions and investments, loans and guarantees, enter into transactions with affiliates, make certain modifications of organizational documents and certain debt agreements and merge or consolidate, and customary events of default.

- added (2016-05-09):
[0000106040-16-000022:note_history:24]
Subject to certain exceptions and thresholds, following the release of the net proceeds of the borrowings under the Term Loan B Facilities from escrow, the Term Loan A Facility and the Term Loan B Facilities require mandatory prepayments in connection with (i) excess cash flow (with respect to the Term Loan B Facilities only), (ii) non-ordinary course asset sales and other dispositions and (iii) the issuance of certain debt obligations, among other things. In addition, if more than $100 million in aggregate principal amount of SanDisk’s convertible notes due 2017 and 2020 remains outstanding on the date that is 90 days after the closing date of the Merger, the New Credit Agreement requires the Company to make a mandatory prepayment of the term loans under the Term Loan B Facilities in an amount equal to the outstanding amount of such convertible notes.

- added (2016-05-09):
[0000106040-16-000022:note_history:25]
Termination of Existing Credit Agreement

- added (2016-05-09):
[0000106040-16-000022:note_history:26]
On the closing date of the Merger, pursuant to the terms of the New Credit Agreement, Western Digital Technologies, Inc., Western Digital Ireland, Ltd. and Western Digital International Ltd. (collectively, the “Existing Borrowers”) will repay all outstanding loans, together with accrued interest, and will terminate all commitments under the credit agreement dated as of January 9, 2014, as amended, among the Company, the Existing Borrowers, the lenders party thereto and JPMorgan Chase Bank, N.A., as administrative agent.
