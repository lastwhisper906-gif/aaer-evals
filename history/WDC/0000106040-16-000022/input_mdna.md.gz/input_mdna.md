# WDC MD&A — 0000106040-16-000022


## mdna

[0000106040-16-000022:mdna:1]
[same as prior period, unchanged from 0000106040-16-000019:mdna:1]

[0000106040-16-000022:mdna:2]
[same as prior period, unchanged from 0000106040-16-000019:mdna:2]

[0000106040-16-000022:mdna:3]
[same as prior period, unchanged from 0000106040-16-000019:mdna:3]

[0000106040-16-000022:mdna:4]
[same as prior period, unchanged from 0000106040-16-000019:mdna:5]

[0000106040-16-000022:mdna:5]
| • | expectations concerning the planned merger (the “Merger”) with SanDisk Corporation (“SanDisk”); |

[0000106040-16-000022:mdna:6]
[same as prior period, unchanged from 0000106040-16-000019:mdna:8]

[0000106040-16-000022:mdna:7]
[same as prior period, unchanged from 0000106040-16-000019:mdna:9]

[0000106040-16-000022:mdna:8]
[same as prior period, unchanged from 0000106040-16-000019:mdna:10]

[0000106040-16-000022:mdna:9]
| • | expectations regarding the personal computer (“PC”) market and the emergence of new storage markets for our products; |

[0000106040-16-000022:mdna:10]
[same as prior period, unchanged from 0000106040-16-000019:mdna:12]

[0000106040-16-000022:mdna:11]
[same as prior period, unchanged from 0000106040-16-000019:mdna:13]

[0000106040-16-000022:mdna:12]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0000106040-16-000022:mdna:13]
[same as prior period, unchanged from 0000106040-16-000019:mdna:15]

[0000106040-16-000022:mdna:14]
[same as prior period, unchanged from 0000106040-16-000019:mdna:16]

[0000106040-16-000022:mdna:15]
[same as prior period, unchanged from 0000106040-16-000019:mdna:17]

[0000106040-16-000022:mdna:16]
[same as prior period, unchanged from 0000106040-16-000019:mdna:18]

[0000106040-16-000022:mdna:17]
[same as prior period, unchanged from 0000106040-16-000019:mdna:19]

[0000106040-16-000022:mdna:18]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes hard disk drives (“HDDs”), solid state drives (“SSDs”), direct attached storage solutions, personal cloud network attached storage solutions and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for the vast majority of digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST and WD brand names.

[0000106040-16-000022:mdna:19]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal third quarters ended April 1, 2016 and April 3, 2015 both consisted of 13 weeks. The nine months ended April 1, 2016 and April 3, 2015 consisted of 39 and 40 weeks, respectively. Fiscal 2016 will be comprised of 52 weeks and will end on July 1, 2016. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015.

[0000106040-16-000022:mdna:20]
[same as prior period, unchanged from 0000106040-16-000019:mdna:23]

[0000106040-16-000022:mdna:21]
Restructuring Plan (the “Restructuring Plan”)

[0000106040-16-000022:mdna:22]
In connection with the regulatory approval process for the HGST acquisition, which closed on March 8, 2012, we agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, we have operated our global business through two independent subsidiaries — HGST and WD. In March 2014, we submitted an application to MOFCOM to lift the condition it imposed on us to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to our application that permits us to integrate our HGST and WD subsidiaries, except that we committed to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision.

[0000106040-16-000022:mdna:23]
We have initiated a set of actions relating to the Restructuring Plan associated with the integration of substantial portions of our HGST and WD subsidiaries. The Restructuring Plan consists of asset and footprint reduction, product roadmap consolidation and organization rationalization.

[0000106040-16-000022:mdna:24]
We expect the Restructuring Plan to be substantially completed by the end of calendar year 2017 and it is expected to result in total pre-tax charges of approximately $400 million. These charges are expected to consist of approximately $185 million in employee termination benefits, $125 million in asset charges and $90 million in other related costs. Approximately $275 million of these charges are expected to be cash expenditures. For further information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements and Part II, Item 5, Other Information included in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:25]
[same as prior period, unchanged from 0000106040-16-000019:mdna:28]

[0000106040-16-000022:mdna:26]
On October 21, 2015, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of our company will merge with and into SanDisk, with SanDisk surviving and becoming our wholly-owned indirect subsidiary. The Merger is primarily intended to deepen our expertise in non-volatile memory and enable us to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-16-000022:mdna:27]
Pursuant to the Merger Agreement, we will pay $67.50 per share in cash and issue 0.2387 shares of our common stock per share of SanDisk’s common stock. The Merger will be financed by a mix of cash, new debt financing and issuance of our common stock.

[0000106040-16-000022:mdna:28]
Consummation of the Merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and our shareholders, which was obtained on March 15, 2016; (ii) the expiration or early termination of the waiting period applicable to the consummation of the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, which expired on January 15, 2016, and the receipt of foreign regulatory approvals. In certain circumstances, a termination fee of up to $1.06 billion may be payable by us or a termination fee of up to $553.3 million may be payable by SanDisk, upon termination of the transaction as more fully described in the Merger Agreement.

[0000106040-16-000022:mdna:29]
New Debt Facilities

[0000106040-16-000022:mdna:30]
As further described below, in connection with the Merger with SanDisk, we expect to enter into new debt facilities totaling approximately $18.1 billion, of which we have incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarterly Report on Form 10-Q. In addition to the notes and new credit agreement described below, we expect to enter into an additional bridge facility in the amount of $3.0 billion on the closing date of the Merger. The proceeds from the new debt facilities will be used to pay a portion of the purchase price of the Merger, refinance existing debt of both us and SanDisk and pay transaction related fees and expenses.

[0000106040-16-000022:mdna:31]
On April 13, 2016, we completed an offering of our $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 and $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024.

[0000106040-16-000022:mdna:32]
On April 29, 2016, we entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and the lenders party thereto, which provides for secured loan facilities consisting of a $4.125 billion term loan facility, a $3.75 billion term loan facility, an €885 million term loan facility, and a $1.0 billion revolving credit facility.

[0000106040-16-000022:mdna:33]
For further information related to the debt entered into in connection with the Merger, refer to Part I, Item 1, Note 14 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:34]
[same as prior period, unchanged from 0000106040-16-000019:mdna:24]

[0000106040-16-000022:mdna:35]
In January 2016, we announced we would be closing our head component front end wafer manufacturing facility in Odawara, Japan, in order to reduce manufacturing costs. In the three and nine months ended April 1, 2016, we recognized $48 million of expenses related to the closure of the facility, which consisted of approximately $24 million in land impairment charges, $23 million in employee termination benefits and $1 million in contract termination and other costs. In addition, in the nine months ended April 1, 2016, we recognized $55 million of accelerated depreciation charges on assets held at the Odawara facility, of which $40 million was recognized in cost of revenue and $15 million was recognized in research and development within the condensed consolidated statements of income. We expect to record approximately $100 million in remaining charges during the fourth quarter of fiscal 2016.

[0000106040-16-000022:mdna:36]
Termination of Investment by Unisplendour Corporation Limited (“Unis”)

[0000106040-16-000022:mdna:37]
On September 29, 2015, we entered into an agreement (the “Stock Purchase Agreement”) with Unis and Unis Union Information System Ltd., a subsidiary of Unis (the “Investor”), pursuant to which, subject to the conditions in the agreement, we agreed to issue and sell to the Investor 40,814,802 shares of our common stock (the “Shares”) for $92.50 per share, for an aggregate purchase price of approximately $3.775 billion (the “Transaction”).

[0000106040-16-000022:mdna:38]
The closing of the Transaction was subject to certain closing conditions, including clearance by the U.S. Committee on Foreign Investment in the United States (“CFIUS”).

[0000106040-16-000022:mdna:39]
On February 22, 2016, CFIUS informed us that it planned to undertake an investigation of the Transaction, triggering a 15-day period during which either we or the Investor could terminate the Stock Purchase Agreement. On February 23, 2016, the Investor terminated the Stock Purchase Agreement pursuant to its terms. We did not incur any early termination penalties in connection with the termination of the Stock Purchase Agreement. For more information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:40]
[same as prior period, unchanged from 0000106040-16-000019:mdna:26]

[0000106040-16-000022:mdna:41]
In November 2015, we entered into an agreement to form a joint venture with Unis to market and sell our current data center storage systems in China and to develop data storage systems for the Chinese market in the future. The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by us. The termination of the investment by Unis described above is not expected to impact our agreement to form the joint venture, which is expected to become operational by the fourth quarter of fiscal 2016, pending regulatory approvals.

[0000106040-16-000022:mdna:42]
Third Quarter Overview

[0000106040-16-000022:mdna:43]
For the quarter ended April 1, 2016, we believe that overall HDD industry shipments totaled approximately 100 million units, down 20% from the prior-year period and down 13% from the quarter ended January 1, 2016. These decreases are the result of a softer demand environment.

[0000106040-16-000022:mdna:44]
[same as prior period, unchanged from 0000106040-16-000019:mdna:40]

[0000106040-16-000022:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Net revenue | $ | 2,822 |  |  | 100.0 | % |  | $ | 3,550 |  |  | 100.0 | % |  | $ | 9,499 |  |  | 100.0 | % |  | $ | 11,381 |  |  | 100.0 | % |
| Gross profit | 753 |  |  | 26.7 |  |  | 1,032 |  |  | 29.1 |  |  | 2,614 |  |  | 27.5 |  |  | 3,291 |  |  | 28.9 |  |
| Total operating expenses | 665 |  |  | 23.6 |  |  | 611 |  |  | 17.2 |  |  | 1,953 |  |  | 20.6 |  |  | 1,935 |  |  | 17.0 |  |
| Operating income | 88 |  |  | 3.1 |  |  | 421 |  |  | 11.9 |  |  | 661 |  |  | 7.0 |  |  | 1,356 |  |  | 11.9 |  |
| Net income | 74 |  |  | 2.6 |  |  | 384 |  |  | 10.8 |  |  | 608 |  |  | 6.4 |  |  | 1,245 |  |  | 10.9 |  |

[0000106040-16-000022:mdna:46]
The following is a summary of our financial performance for the third quarter of fiscal 2016:

[0000106040-16-000022:mdna:47]
| • | Consolidated net revenue totaled $2.8 billion. |

[0000106040-16-000022:mdna:48]
| • | Net revenue derived from enterprise SSDs was $200 million as compared to $224 million in the prior-year period. |

[0000106040-16-000022:mdna:49]
| • | HDD shipments decreased 21% from the prior-year period to 43.1 million units. |

[0000106040-16-000022:mdna:50]
| • | Gross margin decreased to 26.7% as compared to 29.1% in the prior-year period. |

[0000106040-16-000022:mdna:51]
| • | Operating income decreased to $88 million as compared to $421 million in the prior-year period. |

[0000106040-16-000022:mdna:52]
| • | We generated $485 million in cash flow from operations and ended the quarter with $5.9 billion in cash and cash equivalents. |

[0000106040-16-000022:mdna:53]
[same as prior period, unchanged from 0000106040-16-000019:mdna:50]

[0000106040-16-000022:mdna:54]
[same as prior period, unchanged from 0000106040-16-000019:mdna:51]

[0000106040-16-000022:mdna:55]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
| (in millions, except percentages andaverage selling price) | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |  | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |
| Net revenue | $ | 2,822 |  |  | $ | 3,550 |  |  | (21 | )% |  | $ | 9,499 |  |  | $ | 11,381 |  |  | (17 | )% |
| Average selling price (per unit)* | $ | 60 |  |  | $ | 61 |  |  | (2 | )% |  | $ | 60 |  |  | $ | 60 |  |  | — | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas | 30 | % |  | 29 | % |  |  |  | 30 | % |  | 27 | % |  |  |
| Europe, Middle East and Africa | 23 |  |  | 21 |  |  |  |  | 22 |  |  | 22 |  |  |  |
| Asia | 47 |  |  | 50 |  |  |  |  | 48 |  |  | 51 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEM | 66 | % |  | 64 | % |  |  |  | 66 | % |  | 64 | % |  |  |
| Distributors | 22 |  |  | 23 |  |  |  |  | 21 |  |  | 23 |  |  |  |
| Retailers | 12 |  |  | 13 |  |  |  |  | 13 |  |  | 13 |  |  |  |
| Unit Shipments* |  |  |  |  |  |  |  |  |  |  |  |
| PC | 24.2 |  |  | 32.3 |  |  |  |  | 79.5 |  |  | 108.6 |  |  |  |
| Non-PC | 18.9 |  |  | 22.2 |  |  |  |  | 65.0 |  |  | 71.7 |  |  |  |
| Total units shipped | 43.1 |  |  | 54.5 |  |  | (21 | )% |  | 144.5 |  |  | 180.3 |  |  | (20 | )% |

[0000106040-16-000022:mdna:56]
[same as prior period, unchanged from 0000106040-16-000019:mdna:53]

[0000106040-16-000022:mdna:57]
For the quarter ended April 1, 2016, net revenue was $2.8 billion, a decrease of 21% from the prior-year period. Total hard drive shipments decreased to 43.1 million units for the quarter ended April 1, 2016 as compared to 54.5 million units in the prior-year period. For the nine months ended April 1, 2016, net revenue was $9.5 billion, a decrease of 17% from the prior-year period. Total hard drive shipments decreased to 144.5 million units for the nine months ended April 1, 2016 as compared to 180.3 million units in the prior-year period. These decreases in revenue and shipments were primarily the result of a softer demand environment. For the quarter ended April 1, 2016, the average selling prices (“ASP”) for HDDs decreased to $60 compared to the prior-year period ASP for HDDs of $61. For the nine months ended April 1, 2016, the ASP for HDDs remained flat at $60 compared to the prior-year period ASP for HDDs.

[0000106040-16-000022:mdna:58]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For the three months ended April 1, 2016, Hewlett Packard Enterprise Company accounted for approximately 10% of our net revenue. For the nine months ended April 1, 2016, no one company accounted for 10% or more of our net revenue. For the three and nine months ended April 3, 2015, Hewlett-Packard Company accounted for approximately 10% and 11% of our net revenue, respectively.

[0000106040-16-000022:mdna:59]
[same as prior period, unchanged from 0000106040-16-000019:mdna:80]

[0000106040-16-000022:mdna:60]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Total sales incentive and marketing programs have ranged from 7% to 14% of gross revenues per quarter since the first quarter of fiscal 2014. For the three and nine months ended April 1, 2016, these programs represented 14% and 13% of gross revenues, respectively, as compared to 10% in both the respective prior-year periods. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.6% of quarterly gross revenue since the first quarter of fiscal 2014.

[0000106040-16-000022:mdna:61]
[same as prior period, unchanged from 0000106040-16-000019:mdna:58]

[0000106040-16-000022:mdna:62]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
| (in millions, except percentages) | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |  | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |
| Net revenue | $ | 2,822 |  |  | $ | 3,550 |  |  | (21 | )% |  | $ | 9,499 |  |  | $ | 11,381 |  |  | (17 | )% |
| Gross profit | 753 |  |  | 1,032 |  |  | (27 | )% |  | 2,614 |  |  | 3,291 |  |  | (21 | )% |
| Gross margin | 26.7 | % |  | 29.1 | % |  |  |  | 27.5 | % |  | 28.9 | % |  |  |

[0000106040-16-000022:mdna:63]
For the three months ended April 1, 2016, gross margin decreased to 26.7%, as compared to 29.1% for the prior-year period. For the nine months ended April 1, 2016, gross margin decreased to 27.5%, as compared to 28.9% for the prior-year period. These decreases in gross margin were primarily the result of a change in product mix and the related absorption impact due to lower sales volume, as well as charges related to the acceleration of depreciation on assets held at the Odawara, Japan facility as a result of the closure of the facility.

[0000106040-16-000022:mdna:64]
[same as prior period, unchanged from 0000106040-16-000019:mdna:61]

[0000106040-16-000022:mdna:65]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
| (in millions, except percentages) | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |  | April 1, 2016 |  | April 3, 2015 |  | Percentage Change |
| R&D expense | $ | 359 |  |  | $ | 402 |  |  | (11 | )% |  | $ | 1,133 |  |  | $ | 1,265 |  |  | (10 | )% |
| SG&A expense | 166 |  |  | 199 |  |  | (17 | )% |  | 565 |  |  | 583 |  |  | (3 | )% |
| Charges related to arbitration award | — |  |  | — |  |  | — | % |  | 32 |  |  | 15 |  |  | 113 | % |
| Employee termination, asset impairment and other charges | 140 |  |  | 10 |  |  | 1,300 | % |  | 223 |  |  | 72 |  |  | 210 | % |
| Total operating expenses | $ | 665 |  |  | $ | 611 |  |  |  |  | $ | 1,953 |  |  | $ | 1,935 |  |  |  |

[0000106040-16-000022:mdna:66]
Research and development (“R&D”) expense was $359 million for the three months ended April 1, 2016, a decrease of $43 million from the prior-year period. R&D expense was $1.1 billion for the nine months ended April 1, 2016, a decrease of $132 million from the prior-year period. These decreases were primarily the result of reductions in our R&D costs as a result of our business realignment initiatives, partially offset by charges related to the acceleration of depreciation on assets held at the Odawara, Japan facility. As a percentage of net revenue, R&D expense was 12.7% and 11.9% in the three and nine months ended April 1, 2016, as compared to 11.3% and 11.1% in the respective prior-year periods.

[0000106040-16-000022:mdna:67]
Selling, general and administrative (“SG&A”) expense was $166 million for the three months ended April 1, 2016, a decrease of $33 million from the prior-year period. SG&A expense was $565 million for the nine months ended April 1, 2016, a decrease of $18 million from the prior-year period. These decreases were primarily the result of reductions in our SG&A costs as a result of our business realignment initiatives, partially offset by acquisition expenses. SG&A expense as a percentage of net revenue was 5.9% in both the three and nine months ended April 1, 2016, as compared to 5.6% and 5.1% in the respective prior-year periods.

[0000106040-16-000022:mdna:68]
During the nine months ended April 1, 2016, we recorded $32 million of additional interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC, as compared to $15 million in the respective prior-year period. We paid the additional post-award interest to Seagate during the three months ended April 1, 2016 and no additional post-award interest amounts will be recorded on our consolidated financial statements or paid to Seagate. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:69]
During the three and nine months ended April 1, 2016, we recorded employee termination, asset impairment and other charges of $140 million and $223 million, respectively, which included charges related to the closure of our manufacturing facility in Odawara, Japan, charges related to realigning our operations with anticipated market demand and charges related to o

[0000106040-16-000022:mdna:70]
ur Restructuring Plan, as compared to $10 million and $72 million in the respective prior-year periods. For additional information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:71]
[same as prior period, unchanged from 0000106040-16-000019:mdna:67]

[0000106040-16-000022:mdna:72]
Other expense, net for the three and nine months ended April 1, 2016 was $8 million and $23 million, respectively, as compared to $9 million and $26 million in the respective prior-year periods. Interest and other income for the three and nine months ended April 1, 2016 increased $3 million and $6 million, respectively, as compared to the prior-year periods due to a higher average daily invested cash balance. Interest and other expense for the three months ended April 1, 2016 increased $2 million as compared to the prior-year period due to higher interest rates. Interest and other expense for the nine months ended April 1, 2016 increased $3 million as compared to the prior-year period due to a higher debt balance.

[0000106040-16-000022:mdna:73]
[same as prior period, unchanged from 0000106040-16-000019:mdna:70]

[0000106040-16-000022:mdna:74]
We had income tax expense of $6 million and $30 million in the three and nine months ended April 1, 2016, respectively. Our income tax expense for the three and nine months ended April 3, 2015 was $28 million and $85 million, respectively. Our tax provision for the three months ended April 1, 2016 reflects a tax benefit of $10 million for deductible acquisition expenses. Our tax provision for the nine months ended April 1, 2016 reflects a tax benefit of $34 million from restructuring activities and a tax benefit of $10 million for deductible acquisition expenses. The difference between the effective tax rate and the U.S. Federal statutory rate is primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:75]
[same as prior period, unchanged from 0000106040-16-000019:mdna:72]

[0000106040-16-000022:mdna:76]
We ended the third quarter of fiscal 2016 with total cash and cash equivalents of $5.9 billion. The following table summarizes our statements of cash flows (in millions):

[0000106040-16-000022:mdna:77]
|  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 1,628 |  |  | $ | 1,754 |  |
| Investing activities | (11 | ) |  | (712 | ) |
| Financing activities | (754 | ) |  | (1,034 | ) |
| Net increase in cash and cash equivalents | $ | 863 |  |  | $ | 8 |  |

[0000106040-16-000022:mdna:78]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:79]
As discussed above under Recent Developments, in connection with the Merger, we expect to enter into new debt facilities totaling approximately $18.1 billion, of which we have incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarterly Report on Form 10-Q. The proceeds from the new debt facilities will be used to pay a portion of the merger consideration, refinance existing debt of both us and SanDisk and pay transaction-related fees and expenses. For more information on the debt entered into in connection with the Merger, refer to Part I, Item 1, Note 14 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:80]
The cash on hand and indebtedness used to finance the Merger could cause us to place more reliance on cash generated from operations to pay principal and interest on our debt, thereby reducing the availability of our cash flow for working capital, dividend and capital expenditure needs or to pursue other potential strategic plans.

[0000106040-16-000022:mdna:81]
A total of $5.5 billion and $4.3 billion of our cash and cash equivalents was held outside of the United States as of April 1, 2016 and July 3, 2015, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or dividends to our shareholders pursuant to our quarterly cash dividend policy. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-16-000022:mdna:82]
29

[0000106040-16-000022:mdna:83]
[same as prior period, unchanged from 0000106040-16-000019:mdna:78]

[0000106040-16-000022:mdna:84]
Net cash provided by operating activities was $1.6 billion and $1.8 billion during the nine months ended April 1, 2016 and April 3, 2015, respectively. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by working capital changes was $133 million for the nine months ended April 1, 2016, as compared to $470 million used for working capital changes in the prior-year period. The increase in net cash provided by working capital changes compared to the prior-year period was primarily attributable to the payment of the Seagate arbitration award in the nine months ended April 3, 2015.

[0000106040-16-000022:mdna:85]
[same as prior period, unchanged from 0000106040-16-000019:mdna:81]

[0000106040-16-000022:mdna:86]
|  | Nine Months Ended |
|  | April 1, 2016 |  | April 3, 2015 |
| Days sales outstanding | 36 |  |  | 42 |  |
| Days in inventory | 49 |  |  | 46 |  |
| Days payables outstanding | (63 | ) |  | (70 | ) |
| Cash conversion cycle | 22 |  |  | 18 |  |

[0000106040-16-000022:mdna:87]
For the nine months ended April 1, 2016, our days sales outstanding (“DSOs”) decreased by 6 days, days in inventory (“DIOs”) increased by 3 days and days payable outstanding (“DPOs”) decreased by 7 days compared to the prior year period. Changes in DSOs are generally due to the linearity of shipments. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-16-000022:mdna:88]
[same as prior period, unchanged from 0000106040-16-000019:mdna:84]

[0000106040-16-000022:mdna:89]
Net cash used in investing activities for the nine months ended April 1, 2016 was $11 million as compared to $712 million used in investing activities in the prior-year period. Net cash used in investing activities for the nine months ended April 1, 2016 consisted of $462 million related to the purchase of investments, $433 million of capital expenditures and a net $23 million of other investing activities, mostly offset by $907 million of proceeds from sales and maturities of investments. Net cash used in investing activities for the nine months ended April 3, 2015 primarily consisted of $687 million related to the purchase of investments, $456 million of capital expenditures and $247 million related to acquisitions, partially offset by $665 million of proceeds from sales and maturities of investments.

[0000106040-16-000022:mdna:90]
[same as prior period, unchanged from 0000106040-16-000019:mdna:86]

[0000106040-16-000022:mdna:91]
Net cash used in financing activities for the nine months ended April 1, 2016 was $754 million as compared to $1.0 billion used in financing activities in the prior-year period. Net cash used in financing activities for the nine months ended April 1, 2016 consisted of $255 million used to repay the revolving credit facility, $109 million used to make principal payments on the term loan facility, $347 million used to pay dividends on our common stock, $60 million used to repurchase shares of our common stock, partially offset by a net $17 million provided by the issuance of stock under employee stock plans. Net cash used in financing activities for the nine months ended April 3, 2015 consisted of $772 million used to repurchase shares of our common stock, $280 million used to pay dividends on our common stock and $94 million used to make principal payments on the term loan facility, partially offset by a net $112 million provided by the issuance of stock under employee stock plans.

[0000106040-16-000022:mdna:92]
[same as prior period, unchanged from 0000106040-16-000019:mdna:88]

[0000106040-16-000022:mdna:93]
[same as prior period, unchanged from 0000106040-16-000019:mdna:89]

[0000106040-16-000022:mdna:94]
30

[0000106040-16-000022:mdna:95]
[same as prior period, unchanged from 0000106040-16-000019:mdna:90]

[0000106040-16-000022:mdna:96]
Debt — In January 2016, we repaid the outstanding balance of $255 million under the revolving credit facility. As of April 1, 2016, we had $2.2 billion outstanding on our term loan facility. We are required to make quarterly principal payments on the term loan facility totaling $47 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. As of April 1, 2016, under our credit agreement, we were in compliance with all covenants. In connection with the Merger, we expect to enter into new debt facilities totaling approximately $18.1 billion, of which we have incurred aggregate borrowings of approximately $10.0 billion as of the date of this Quarter Report on Form 10-Q. For additional information on our outstanding debt, refer to Part I, Item 1, Notes 4 and 14 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q. See also Part II, Item 1A of this Quarterly Report on Form 10-Q for a discussion of the risks associated with our indebtedness.

[0000106040-16-000022:mdna:97]
[same as prior period, unchanged from 0000106040-16-000019:mdna:92]

[0000106040-16-000022:mdna:98]
[same as prior period, unchanged from 0000106040-16-000019:mdna:93]

[0000106040-16-000022:mdna:99]
[same as prior period, unchanged from 0000106040-16-000019:mdna:94]

[0000106040-16-000022:mdna:100]
[same as prior period, unchanged from 0000106040-16-000019:mdna:95]

[0000106040-16-000022:mdna:101]
[same as prior period, unchanged from 0000106040-16-000019:mdna:96]

[0000106040-16-000022:mdna:102]
[same as prior period, unchanged from 0000106040-16-000019:mdna:97]

[0000106040-16-000022:mdna:103]
[same as prior period, unchanged from 0000106040-16-000019:mdna:98]

[0000106040-16-000022:mdna:104]
Unrecognized Tax Benefits — As of April 1, 2016, the amount of unrecognized tax benefits was $359 million, of which $251 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. See Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-16-000022:mdna:105]
Stock Repurchase Program — Our Board of Directors previously authorized a stock repurchase program. Effective October 21, 2015, in connection with the SanDisk Merger, we suspended this stock repurchase program. For additional information, refer to Part II, Item 2, Issuer Purchases of Equity Securities in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:106]
Cash Dividend Policy — Since the first quarter of fiscal 2014, we have issued a quarterly cash dividend. On May 3, 2016, we declared a cash dividend of $0.50 per share as of July 1, 2016, which will be paid on July 15, 2016. We may modify, suspend or cancel our cash dividend policy in any manner and at any time. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-16-000022:mdna:107]
[same as prior period, unchanged from 0000106040-16-000019:mdna:102]

[0000106040-16-000022:mdna:108]
We have prepared the unaudited condensed consolidated financial statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. For example, we test goodwill for impairment annually as of the first day of our fourth fiscal quarter and at other times if events have occurred or circumstances exist that indicate the carrying value of goodwill may no longer be recoverable. Subsequent to April 1, 2016, the recent volatility in our stock price has caused our market capitalization to be below our shareholders’ equity, and it is possible that our goodwill could become impaired in the near term which could result in a material charge and adversely affect our results of operations.

[0000106040-16-000022:mdna:109]
[same as prior period, unchanged from 0000106040-16-000019:mdna:104]

[0000106040-16-000022:mdna:110]
[same as prior period, unchanged from 0000106040-16-000019:mdna:105]

[0000106040-16-000022:mdna:111]
[same as prior period, unchanged from 0000106040-16-000019:mdna:106]
