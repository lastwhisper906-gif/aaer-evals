# WDC MD&A — 0000106040-19-000028


## mdna

[0000106040-19-000028:mdna:1]
[same as prior period, unchanged from 0000106040-19-000009:mdna:1]

[0000106040-19-000028:mdna:2]
[same as prior period, unchanged from 0000106040-19-000009:mdna:2]

[0000106040-19-000028:mdna:3]
[same as prior period, unchanged from 0000106040-19-000009:mdna:3]

[0000106040-19-000028:mdna:4]
[same as prior period, unchanged from 0000106040-19-000009:mdna:4]

[0000106040-19-000028:mdna:5]
[same as prior period, unchanged from 0000106040-19-000009:mdna:5]

[0000106040-19-000028:mdna:6]
[same as prior period, unchanged from 0000106040-19-000009:mdna:6]

[0000106040-19-000028:mdna:7]
The flash industry is characterized by cyclicality as it responds to variations in customers’ demand for products and manages production capacity to meet that demand. As technology conversions have matured and manufacturing yields have improved, flash supply has increased relative to demand. As a result, average selling price per gigabyte of flash-based products has declined in recent quarters.

[0000106040-19-000028:mdna:8]
[same as prior period, unchanged from 0000106040-19-000009:mdna:8]

[0000106040-19-000028:mdna:9]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of the current supply/demand imbalance for flash-based products, we have temporarily reduced our utilization of our share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align our flash-based wafer supply with the projected demand. We do not expect this action to result in any incremental cash payments; however, as a result of this temporary reduction to abnormally low production levels, we incurred costs of $148 million and $197 million associated with the reduction in utilization, which was recorded as a charge to cost of revenue in the three and nine months ended March 29, 2019, respectively. We expect additional underutilization charges to be recorded in cost of revenue in the range of $55 million to $75 million by the end of the fiscal year. We may adjust our plans based on market conditions, which could impact the timing and amount of any charges.

[0000106040-19-000028:mdna:10]
[same as prior period, unchanged from 0000106040-19-000009:mdna:10]

[0000106040-19-000028:mdna:11]
We implemented actions to better align our cost and expense structure to near-term business conditions. These actions included accelerating the closure of our HDD manufacturing facility in Kuala Lumpur, Malaysia, reducing other HDD manufacturing costs and other measures to reduce our costs and expenses. We incurred costs of $76 million in the three months ended March 29, 2019 towards the implementation of these actions and expect to reduce costs of revenue and operating expenses by $800 million on an annualized basis, with the reductions split approximately equally between cost of revenue and operating expenses. The level of our costs of revenue and operating expenses in any particular period may vary based on differing levels of incentive cash compensation, payroll tax increases, and unexpected or non-recurring costs or expenses.

[0000106040-19-000028:mdna:12]
55

[0000106040-19-000028:mdna:13]
[same as prior period, unchanged from 0000106040-19-000009:mdna:12]

[0000106040-19-000028:mdna:14]
Third Quarter and Nine Month Overview

[0000106040-19-000028:mdna:15]
[same as prior period, unchanged from 0000106040-19-000009:mdna:14]

[0000106040-19-000028:mdna:16]
|  | Three Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 3,674 |  |  | 100.0 | % |  | $ | 5,013 |  |  | 100.0 | % |  | $ | (1,339 | ) |  | (26.7 | )% |
| Cost of revenue | 3,095 |  |  | 84.2 |  |  | 3,086 |  |  | 61.6 |  |  | 9 |  |  | 0.3 |  |
| Gross profit | 579 |  |  | 15.8 |  |  | 1,927 |  |  | 38.4 |  |  | (1,348 | ) |  | (70.0 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 544 |  |  | 14.8 |  |  | 602 |  |  | 12.0 |  |  | (58 | ) |  | (9.6 | ) |
| Selling, general and administrative | 353 |  |  | 9.6 |  |  | 376 |  |  | 7.5 |  |  | (23 | ) |  | (6.1 | ) |
| Employee termination, asset impairment, and other charges | 76 |  |  | 2.1 |  |  | 35 |  |  | 0.7 |  |  | 41 |  |  | 117.1 |  |
| Total operating expenses | 973 |  |  | 26.5 |  |  | 1,013 |  |  | 20.2 |  |  | (40 | ) |  | (3.9 | ) |
| Operating income (loss) | (394 | ) |  | (10.7 | ) |  | 914 |  |  | 18.2 |  |  | (1,308 | ) |  | (143.1 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 13 |  |  | 0.4 |  |  | 16 |  |  | 0.3 |  |  | (3 | ) |  | (18.8 | ) |
| Interest expense | (118 | ) |  | (3.2 | ) |  | (160 | ) |  | (3.2 | ) |  | 42 |  |  | (26.3 | ) |
| Other income, net | 22 |  |  | 0.6 |  |  | (898 | ) |  | (17.9 | ) |  | 920 |  |  | (102.4 | ) |
| Total interest and other expense, net | (83 | ) |  | (2.3 | ) |  | (1,042 | ) |  | (20.8 | ) |  | 959 |  |  | (92.0 | ) |
| Income (loss) before taxes | (477 | ) |  | (13.0 | ) |  | (128 | ) |  | (2.6 | ) |  | (349 | ) |  | 272.7 |  |
| Income tax expense (benefit) | 104 |  |  | 2.8 |  |  | (189 | ) |  | (3.8 | ) |  | 293 |  |  | (155.0 | ) |
| Net income (loss) | $ | (581 | ) |  | (15.8 | ) |  | $ | 61 |  |  | 1.2 |  |  | $ | (642 | ) |  | (1,052.5 | ) |

[0000106040-19-000028:mdna:17]
[same as prior period, unchanged from 0000106040-19-000009:mdna:16]

[0000106040-19-000028:mdna:18]
[same as prior period, unchanged from 0000106040-19-000009:mdna:51]

[0000106040-19-000028:mdna:19]
|  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 12,935 |  |  | 100.0 | % |  | $ | 15,530 |  |  | 100.0 | % |  | $ | (2,595 | ) |  | (16.7 | )% |
| Cost of revenue | 9,648 |  |  | 74.6 |  |  | 9,677 |  |  | 62.3 |  |  | (29 | ) |  | (0.3 | ) |
| Gross profit | 3,287 |  |  | 25.4 |  |  | 5,853 |  |  | 37.7 |  |  | (2,566 | ) |  | (43.8 | ) |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,659 |  |  | 12.8 |  |  | 1,823 |  |  | 11.7 |  |  | (164 | ) |  | (9.0 | ) |
| Selling, general and administrative | 1,018 |  |  | 7.9 |  |  | 1,121 |  |  | 7.2 |  |  | (103 | ) |  | (9.2 | ) |
| Employee termination, asset impairment, and other charges | 142 |  |  | 1.1 |  |  | 135 |  |  | 0.9 |  |  | 7 |  |  | 5.2 |  |
| Total operating expenses | 2,819 |  |  | 21.8 |  |  | 3,079 |  |  | 19.8 |  |  | (260 | ) |  | (8.4 | ) |
| Operating income (loss) | 468 |  |  | 3.6 |  |  | 2,774 |  |  | 17.9 |  |  | (2,306 | ) |  | (83.1 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 43 |  |  | 0.3 |  |  | 46 |  |  | 0.3 |  |  | (3 | ) |  | (6.5 | ) |
| Interest expense | (352 | ) |  | (2.7 | ) |  | (562 | ) |  | (3.6 | ) |  | 210 |  |  | (37.4 | ) |
| Other income (expense), net | 28 |  |  | 0.2 |  |  | (902 | ) |  | (5.8 | ) |  | 930 |  |  | (103.1 | ) |
| Total interest and other expense, net | (281 | ) |  | (2.2 | ) |  | (1,418 | ) |  | (9.1 | ) |  | 1,137 |  |  | (80.2 | ) |
| Income (loss) before taxes | 187 |  |  | 1.4 |  |  | 1,356 |  |  | 8.7 |  |  | (1,169 | ) |  | (86.2 | ) |
| Income tax expense (benefit) | 744 |  |  | 5.8 |  |  | 1,437 |  |  | 9.3 |  |  | (693 | ) |  | (48.2 | ) |
| Net loss | $ | (557 | ) |  | (4.3 | ) |  | $ | (81 | ) |  | (0.5 | ) |  | $ | (476 | ) |  | 587.7 |  |

[0000106040-19-000028:mdna:20]
[same as prior period, unchanged from 0000106040-19-000009:mdna:19]

[0000106040-19-000028:mdna:21]
[same as prior period, unchanged from 0000106040-19-000009:mdna:20]

[0000106040-19-000028:mdna:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |

[0000106040-19-000028:mdna:23]
[same as prior period, unchanged from 0000106040-19-000009:mdna:22]

[0000106040-19-000028:mdna:24]
[same as prior period, unchanged from 0000106040-19-000009:mdna:23]

[0000106040-19-000028:mdna:25]
Net Revenue. The decrease in net revenue in the three months ended March 29, 2019 from the comparable period of the prior year was primarily driven by lower average selling prices per gigabyte for flash-based products and lower sales of HDD products. Specifically, Client Devices revenue decreased 29.7% year over year, primarily driven by a reduction in flash-based mobile products and client compute HDD. Our revenue for Data Center Devices and Solutions decreased 25.0% year over year, primarily driven by lower average selling prices per gigabyte of flash-based products as well as lower sales of enterprise SSD, capacity enterprise HDD and performance enterprise HDD products. Client Solutions revenue decreased 22.8% year over year, primarily driven by lower sales of retail HDD and lower average selling prices per gigabyte of flash-based products.

[0000106040-19-000028:mdna:26]
The decrease in net revenue for the nine months ended March 29, 2019, compared to the same period in the prior year, is primarily due to lower average selling prices per gigabyte for flash-based products and lower sales of HDD products. Specifically, Client Devices revenue for the nine months ended March 29, 2019 decreased 15.0% year over year, primarily driven by lower sales of client compute HDD products and flash-based mobile products and lower average selling prices per gigabyte of flash-based products, partially offset by higher sales of client SSD. Our revenue for Data Center Devices and Solutions for the nine months ended March 29, 2019 decreased 15.6% year over year, driven primarily by lower sales of our enterprise SSDs and performance enterprise HDDs. Client Solutions revenue for the nine months ended March 29, 2019 decreased 21.9% year over year, primarily driven by lower sales of retail HDD and lower average selling prices per gigabyte of flash-based products.

[0000106040-19-000028:mdna:27]
Our top 10 customers accounted for 41% and 45% of our net revenue for the three and nine months ended March 29, 2019, respectively, and 44% and 42% of our net revenue for the three and nine months ended March 30, 2018, respectively. For the three and nine months ended March 29, 2019 and March 30, 2018, no single customer accounted for 10% or more of our net revenue.

[0000106040-19-000028:mdna:28]
[same as prior period, unchanged from 0000106040-19-000009:mdna:27]

[0000106040-19-000028:mdna:29]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended March 29, 2019, these programs represented 17% and 15% of gross revenues, respectively. For the three and nine months ended March 30, 2018, these programs represented 11% and 12% of gross revenues, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-19-000028:mdna:30]
Gross Profit and Gross Margin. The decreases in gross profit for the three and nine months ended March 29, 2019 from the comparable periods in the prior year were primarily due to the lower average selling prices per gigabyte for flash-based products, the flash manufacturing underutilization charges and a charge to cost of revenue of $110 million (3.0% and 0.9% of revenue for the three and nine months ended March 29, 2019, respectively) primarily to reduce component inventory to net realizable value for flash-based multi-chip package products that include externally-sourced dynamic random access memory products. Gross profit and gross margin also include amortization expense on acquired intangible assets, stock-based compensation, a flash manufacturing underutilization charge, and charges related to the implementation of cost-saving initiatives and other charges, which aggregated $349 million, or 9.5%, of revenue, compared to $247 million, or 4.9%, of revenue, for the three months ended March 29, 2019 and March 30, 2018, respectively, and $879 million, or 6.8%, of revenue, compared to $819 million, or 5.3%, of revenue, for the nine months ended March 29, 2019 and March 30, 2018, respectively. We expect gross margins to be negatively impacted by flash manufacturing underutilization charges to be recorded in cost of revenue in the range of $55 million to $75 million with the substantial majority expected to be recognized by the end of the fiscal year.

[0000106040-19-000028:mdna:31]
[same as prior period, unchanged from 0000106040-19-000009:mdna:30]

[0000106040-19-000028:mdna:32]
The decrease in research and development (“R&D”) expense for the three months ended March 29, 2019 from the same period in the prior year is primarily due to lower variable and stock-based compensation expense, as well as progress on our expense reduction actions. The decrease in R&D expense for the nine months ended March 29, 2019 from the same period in the prior year is primarily due to lower variable compensation expense and lower stock-based compensation expenses.

[0000106040-19-000028:mdna:33]
The decrease in selling, general and administrative (“SG&A”) expense for the three months ended March 29, 2019 from the same period in the prior year is primarily due to lower variable compensation expense as well as progress on our expense reduction actions, partially offset by higher charges totaling $114 million in the aggregate relating to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges for the three months ended March 29, 2019 compared to $81 million for the three months ended March 30, 2018.

[0000106040-19-000028:mdna:34]
The decrease in SG&A expense for the nine months ended March 29, 2019 from the same period in the prior year is primarily due to lower variable compensation expense. In addition, we had lower charges related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges, which aggregated to $255 million for the nine months ended March 29, 2019 compared to $268 million in the nine months ended March 30, 2018.

[0000106040-19-000028:mdna:35]
Employee termination, asset impairment and other charges primarily related to actions associated with the realignment of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 13, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:36]
[same as prior period, unchanged from 0000106040-19-000009:mdna:34]

[0000106040-19-000028:mdna:37]
The decreases in total interest and other expense, net for both the three and nine months ended March 29, 2019 are primarily due to the loss on extinguishment of debt of $854 million in the prior year as well as lower interest expense resulting from reductions in the principal amount of debt and lower interest rates as a result of changes to our debt facilities in the third and fourth quarters of fiscal 2018, partially offset by increases in the LIBOR interest rate.

[0000106040-19-000028:mdna:38]
Income Tax Expense (Benefit)

[0000106040-19-000028:mdna:39]
[same as prior period, unchanged from 0000106040-19-000009:mdna:37]

[0000106040-19-000028:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Income (loss) before taxes | $ | (477 | ) |  | $ | (128 | ) |  | $ | 187 |  |  | $ | 1,356 |  |
| Income tax expense (benefit) | 104 |  |  | (189 | ) |  | 744 |  |  | 1,437 |  |
| Effective tax rate | (22 | )% |  | 148 | % |  | 398 | % |  | 106 | % |

[0000106040-19-000028:mdna:41]
[same as prior period, unchanged from 0000106040-19-000009:mdna:39]

[0000106040-19-000028:mdna:42]
When initially accounting for the tax effects of the enactment of the 2017 Act, we applied the applicable Securities and Exchange Commission (“SEC”) guidance and made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. As we finalized the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, we reflected adjustments to the recorded provisional amounts. During the second quarter of fiscal 2019, we completed our accounting for the tax effects of the enactment of the 2017 Act. Although the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, we anticipate the issuance of future additional regulatory and interpretive guidance, even though the one-year measurement period has ended. Although we were able to apply a reasonable interpretation of the law along with any available guidance in finalizing our accounting for the tax effects of the 2017 Act, such future additional regulatory or interpretive guidance would constitute new information which may require further refinements to our estimates in future periods.

[0000106040-19-000028:mdna:43]
The primary driver of the difference between the effective tax rate for the three and nine months ended March 29, 2019 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended March 29, 2019, these discrete effects consist of income tax benefits of $71 million related to the mandatory deemed repatriation tax. For the nine months ended March 29, 2019, these discrete effects consist of $107 million related to the mandatory deemed repatriation tax and $152 million related to the decision to change our indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to an increase in the estimated effective tax rate due to changes in the relative mix of earnings by jurisdiction, partially offset by credits and tax holidays. The windfall tax benefits resulting from the adoption of ASU 2016-09 were not material for the three and nine months ended March 29, 2019.

[0000106040-19-000028:mdna:44]
The primary drivers for the difference between the effective tax rate for the three months ended March 30, 2018 and the U.S. Federal statutory rate of 28% included discrete effects consisting of an income tax benefit of $211 million from deductible make-whole premiums and the write-off of unamortized issuance costs from our debt financing transactions. The primary drivers for the difference between the effective tax rate for the nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% were related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act and deductible make-whole premiums and the write-off of unamortized issuance costs from our debt financing transactions. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% were tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expired or expire at various dates during fiscal years 2018 through 2030 and windfall tax benefits related to vesting and exercises of stock-based awards. The windfall tax benefits are a result of the adoption of ASU 2016-09, which required us to recognize $46 million and $73 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of our income tax expense for the three and nine months ended March 30, 2018, respectively.

[0000106040-19-000028:mdna:45]
[same as prior period, unchanged from 0000106040-19-000009:mdna:43]

[0000106040-19-000028:mdna:46]
For additional information regarding income tax expense (benefit), see Part I, Item 1, Note 11, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:47]
[same as prior period, unchanged from 0000106040-19-000009:mdna:45]

[0000106040-19-000028:mdna:48]
[same as prior period, unchanged from 0000106040-19-000009:mdna:46]

[0000106040-19-000028:mdna:49]
|  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 1,378 |  |  | $ | 3,342 |  |
| Investing activities | (1,042 | ) |  | (1,406 | ) |
| Financing activities | (1,657 | ) |  | (3,337 | ) |
| Effect of exchange rate changes on cash | (2 | ) |  | 10 |  |
| Net decrease in cash and cash equivalents | $ | (1,323 | ) |  | $ | (1,391 | ) |

[0000106040-19-000028:mdna:50]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, stock repurchases, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q. See also “Debt” below for information regarding the credit agreement governing our revolving credit facility and term loans (as amended, the “Credit Agreement”).

[0000106040-19-000028:mdna:51]
[same as prior period, unchanged from 0000106040-19-000009:mdna:49]

[0000106040-19-000028:mdna:52]
A total of $2.55 billion and $4.15 billion of our cash and cash equivalents was held outside of the U.S. as of March 29, 2019 and June 29, 2018, respectively. During the second quarter of fiscal 2019, we finalized the accounting for the tax effects of the mandatory deemed repatriation tax on our indefinite reinvestment assertion. After re-evaluating the existing short- and long-term capital allocation polices, we intend to repatriate all of our foreign undistributed earnings. Our decision to change our indefinite reinvestment assertion is based on interpretative guidance issued by the IRS to date related to the ordering and the taxation of a repatriation of our foreign undistributed earnings. For additional information regarding our indefinite reinvestment assertion, see Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-19-000028:mdna:53]
[same as prior period, unchanged from 0000106040-19-000009:mdna:52]

[0000106040-19-000028:mdna:54]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in other operating assets and liabilities was $7 million for the nine months ended March 29, 2019, as compared to net cash provided of $948 million for the nine months ended March 30, 2018. The net cash provided by changes in other operating assets and liabilities in the nine months ended March 30, 2018 primarily reflects the payable recorded for the mandatory deemed repatriation tax as described in Part I, Item 1, Note 11, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q. Changes in our other operating assets and liabilities are also largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-19-000028:mdna:55]
|  | Quarter to Date |
|  | March 29, 2019 |  | March 30, 2018 |
|  | (in days) |
| Days sales outstanding | 30 |  |  | 36 |  |
| Days in inventory | 101 |  |  | 79 |  |
| Days payables outstanding | (55 | ) |  | (71 | ) |
| Cash conversion cycle | 76 |  |  | 44 |  |

[0000106040-19-000028:mdna:56]
[same as prior period, unchanged from 0000106040-19-000009:mdna:55]

[0000106040-19-000028:mdna:57]
For the three months ended March 29, 2019, DSO decreased by 6 days over the prior year, primarily reflecting the timing of shipments and customer collections and the factoring of receivables. DIO increased by 22 days over the prior year, primarily reflecting increases in hard drive inventory in response to the plant closure in Kuala Lumpur, Malaysia and increases in flash inventory. DPO decreased by 16 days over the prior year, primarily reflecting routine variations in timing of purchases and payments during the period.

[0000106040-19-000028:mdna:58]
[same as prior period, unchanged from 0000106040-19-000009:mdna:57]

[0000106040-19-000028:mdna:59]
During the nine months ended March 29, 2019, net cash used in investing activities primarily consisted of $722 million of capital expenditures and a net $288 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion. Net cash used in investing activities for the nine months ended March 30, 2018 primarily consisted of $643 million of capital expenditures, a $707 million net increase in notes receivable issuances to and investments in Flash Ventures and $99 million for acquisitions.

[0000106040-19-000028:mdna:60]
[same as prior period, unchanged from 0000106040-19-000009:mdna:59]

[0000106040-19-000028:mdna:61]
[same as prior period, unchanged from 0000106040-19-000009:mdna:60]

[0000106040-19-000028:mdna:62]
During the nine months ended March 29, 2019, net cash used in financing activities primarily consisted of $613 million for the repayment of our revolving credit facility and debt, $563 million of share repurchases and $438 million to pay dividends on our common stock. Net cash used in financing activities for the nine months ended March 30, 2018 primarily consisted of $14.58 billion in debt repayments, $443 million to pay dividends on our common stock and $155 million of share repurchases, partially offset by net proceeds of $11.83 billion from debt issuances and draws under our revolving credit facility.

[0000106040-19-000028:mdna:63]
61

[0000106040-19-000028:mdna:64]
[same as prior period, unchanged from 0000106040-19-000009:mdna:63]

[0000106040-19-000028:mdna:65]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:66]
[same as prior period, unchanged from 0000106040-19-000009:mdna:65]

[0000106040-19-000028:mdna:67]
[same as prior period, unchanged from 0000106040-19-000009:mdna:66]

[0000106040-19-000028:mdna:68]
The following is a summary of our known contractual cash obligations and commercial commitments as of March 29, 2019:

[0000106040-19-000028:mdna:69]
|  | Total |  | 1 Year (Remaining 3 months of 2019) |  | 2-3 Years (2020-2021) |  | 4-5 Years (2022-2023) |  | More than 5 Years (Beyond 2023) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 10,762 |  |  | $ | 69 |  |  | $ | 586 |  |  | $ | 6,707 |  |  | $ | 3,400 |  |
| Interest on debt | 1,995 |  |  | 76 |  |  | 846 |  |  | 729 |  |  | 344 |  |
| Flash Ventures and other related commitments(2) | 6,352 |  |  | 1,553 |  |  | 2,789 |  |  | 1,569 |  |  | 441 |  |
| Operating leases | 174 |  |  | 17 |  |  | 84 |  |  | 40 |  |  | 33 |  |
| Purchase obligations | 2,213 |  |  | 1,099 |  |  | 631 |  |  | 483 |  |  | — |  |
| Mandatory Deemed Repatriation Tax | 1,103 |  |  | — |  |  | 161 |  |  | 198 |  |  | 744 |  |
| Total | $ | 22,599 |  |  | $ | 2,814 |  |  | $ | 5,097 |  |  | $ | 9,726 |  |  | $ | 4,962 |  |

[0000106040-19-000028:mdna:70]
[same as prior period, unchanged from 0000106040-19-000009:mdna:69]

[0000106040-19-000028:mdna:71]
[same as prior period, unchanged from 0000106040-19-000009:mdna:70]

[0000106040-19-000028:mdna:72]
[same as prior period, unchanged from 0000106040-19-000009:mdna:71]

[0000106040-19-000028:mdna:73]
We had $10.76 billion of debt outstanding as of March 29, 2019, including $7.33 billion of term loans under our Credit Agreement, $2.30 billion of senior unsecured notes due 2024 and $1.10 billion of convertible notes due 2024.

[0000106040-19-000028:mdna:74]
Under the Credit Agreement, we are required to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, which consist of a leverage ratio and an interest coverage ratio, both of which are based upon a trailing twelve-month Adjusted EBITDA as defined in the Credit Agreement. As of March 29, 2019, we were in compliance with all financial covenants under the Credit Agreement.

[0000106040-19-000028:mdna:75]
In April 2019, we amended the Credit Agreement to include an addback for certain depreciation related payments with respect to the Company’s Flash Ventures in the Adjusted EBITDA calculation and to defer the reductions in required leverage ratios. The amendment provides additional operating flexibility for the term of the Credit Agreement; however, a significant deterioration in our operating results could cause our trailing twelve-month Adjusted EBITDA to drop below the threshold required for compliance with our leverage ratio, which could result in an event of default under the Credit Agreement. If an event of default under the Credit Agreement were to occur and if we were not able to obtain a waiver from the required lenders (or if we were not able to obtain such waiver on terms acceptable to us), there could be significant negative consequences for the Company. See Part II, Item 1A, “Risk Factors—Our high level of debt may have an adverse impact on our liquidity, restrict our current and future operations, particularly our ability to respond to business opportunities, and increase our vulnerability to adverse economic and industry conditions” for a discussion of risks related to our level of debt, including the consequences of an event of default thereunder.

[0000106040-19-000028:mdna:76]
62

[0000106040-19-000028:mdna:77]
Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q and Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10‑K for the year ended June 29, 2018.

[0000106040-19-000028:mdna:78]
[same as prior period, unchanged from 0000106040-19-000009:mdna:76]

[0000106040-19-000028:mdna:79]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of March 29, 2019, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-19-000028:mdna:80]
[same as prior period, unchanged from 0000106040-19-000009:mdna:78]

[0000106040-19-000028:mdna:81]
[same as prior period, unchanged from 0000106040-19-000009:mdna:79]

[0000106040-19-000028:mdna:82]
[same as prior period, unchanged from 0000106040-19-000009:mdna:80]

[0000106040-19-000028:mdna:83]
[same as prior period, unchanged from 0000106040-19-000009:mdna:81]

[0000106040-19-000028:mdna:84]
| Remaining three months of 2019 |  | $ | — |  |
| 2020 |  | 62 |  |
| 2021 |  | 99 |  |
| 2022 |  | 99 |  |
| 2023 |  | 99 |  |
| 2024 |  | 186 |  |
| 2025 |  | 248 |  |
| 2026 |  | 310 |  |
| Total |  | $ | 1,103 |  |

[0000106040-19-000028:mdna:85]
The 2017 Act allows for the mandatory deemed repatriation tax of $1.25 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. As of March 29, 2019, total payments of $150 million have been made towards the mandatory deemed repatriation tax of $1.25 billion for a remaining net tax liability owed of $1.10 billion. For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part I, Item 1, Note 11, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:86]
[same as prior period, unchanged from 0000106040-19-000009:mdna:84]

[0000106040-19-000028:mdna:87]
As of March 29, 2019, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $708 million. Accrued interest and penalties related to unrecognized tax benefits as of March 29, 2019 was approximately $120 million. Of these amounts, approximately $717 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 11, Income Tax Expense (Benefit), of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:88]
[same as prior period, unchanged from 0000106040-19-000009:mdna:86]

[0000106040-19-000028:mdna:89]
We have entered into interest rate swap agreements to moderate our exposure to fluctuations in interest rates underlying our variable rate debt. For a description of our current interest rate swaps, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:90]
[same as prior period, unchanged from 0000106040-19-000009:mdna:88]

[0000106040-19-000028:mdna:91]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk and Part I, Item 1, Note 6, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:92]
[same as prior period, unchanged from 0000106040-19-000009:mdna:90]

[0000106040-19-000028:mdna:93]
[same as prior period, unchanged from 0000106040-19-000009:mdna:91]

[0000106040-19-000028:mdna:94]
[same as prior period, unchanged from 0000106040-19-000009:mdna:92]

[0000106040-19-000028:mdna:95]
[same as prior period, unchanged from 0000106040-19-000009:mdna:93]

[0000106040-19-000028:mdna:96]
Our Board of Directors previously authorized $5.00 billion for the repurchase of our common stock. On July 25, 2018, our Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. For the three months ended March 29, 2019, we did not make any stock repurchases. For the nine months ended March 29, 2019, we repurchased 0.8 million shares for a total cost of $61 million under the previous authorization and 7.6 million shares for a total cost of $502 million under the new authorization. Therefore, our stock repurchases under all stock repurchase authorizations in effect for the nine months ended March 29, 2019 totaled $563 million. The remaining amount available to be repurchased under our current stock repurchase program as of March 29, 2019 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000028:mdna:97]
[same as prior period, unchanged from 0000106040-19-000009:mdna:95]

[0000106040-19-000028:mdna:98]
Since the first quarter of 2013, we have issued a quarterly cash dividend. During the nine months ended March 29, 2019, we declared aggregate cash dividends of $1.50 per share on our outstanding common stock totaling $436 million, of which $146 million was paid on April 15, 2019.

[0000106040-19-000028:mdna:99]
On May 2, 2019, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of June 28, 2019, which will be paid on July 15, 2019. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-19-000028:mdna:100]
[same as prior period, unchanged from 0000106040-19-000009:mdna:97]

[0000106040-19-000028:mdna:101]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recent Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-19-000028:mdna:102]
[same as prior period, unchanged from 0000106040-19-000009:mdna:99]

[0000106040-19-000028:mdna:103]
We have prepared the accompanying Condensed Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Condensed Consolidated Financial Statements may be material.

[0000106040-19-000028:mdna:104]
See Part I, Item 1, Note 2, Recent Accounting Pronouncements, and Note 3, Revenues, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for a discussion of a recently adopted accounting pronouncement that affects our recognition of revenue. There have been no other material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 29, 2018. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 29, 2018 for a discussion of our critical accounting policies and estimates.
