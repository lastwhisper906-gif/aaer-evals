# WDC notes — 0000106040-19-000028


## srt:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-19-000028:notes:1]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (557 | ) |  | $ | (544 | ) |  | $ | (521 | ) |  | $ | 1,065 |  |  | $ | (557 | ) |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | (8 | ) |  | (4 | ) |  | (4 | ) |  | 8 |  |  | (8 | ) |
| Net unrealized gain (loss), on derivative contracts and available-for-sale securities | (18 | ) |  | 23 |  |  | 21 |  |  | (44 | ) |  | (18 | ) |
| Total other comprehensive income (loss), before tax | (25 | ) |  | 20 |  |  | 18 |  |  | (38 | ) |  | (25 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | 9 |  |  | (2 | ) |  | (1 | ) |  | 3 |  |  | 9 |  |
| Other comprehensive income (loss), net of tax | (16 | ) |  | 18 |  |  | 17 |  |  | (35 | ) |  | (16 | ) |
| Total comprehensive loss | $ | (573 | ) |  | $ | (526 | ) |  | $ | (504 | ) |  | $ | 1,030 |  |  | $ | (573 | ) |

[0000106040-19-000028:notes:2]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 61 |  |  | $ | 763 |  |  | $ | 600 |  |  | $ | (1,363 | ) |  | $ | 61 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 76 |  |  | 75 |  |  | 75 |  |  | (150 | ) |  | 76 |  |
| Net unrealized gain on derivative contracts and available-for-sale securities | 18 |  |  | 10 |  |  | 11 |  |  | (21 | ) |  | 18 |  |
| Total other comprehensive income, before tax | 95 |  |  | 86 |  |  | 87 |  |  | (173 | ) |  | 95 |  |
| Income tax expense related to items of other comprehensive income | (3 | ) |  | (2 | ) |  | (3 | ) |  | 5 |  |  | (3 | ) |
| Other comprehensive income, net of tax | 92 |  |  | 84 |  |  | 84 |  |  | (168 | ) |  | 92 |  |
| Total comprehensive income | $ | 153 |  |  | $ | 847 |  |  | $ | 684 |  |  | $ | (1,531 | ) |  | $ | 153 |  |

[0000106040-19-000028:notes:3]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income (loss) | $ | (81 | ) |  | $ | 806 |  |  | $ | 1,770 |  |  | $ | (2,576 | ) |  | $ | (81 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 1 |  |  | 1 |  |  | 1 |  |  | (2 | ) |  | 1 |  |
| Foreign currency translation adjustment | 78 |  |  | 76 |  |  | 76 |  |  | (152 | ) |  | 78 |  |
| Net unrealized gain on derivative contracts and available-for-sale securities | 31 |  |  | 15 |  |  | 16 |  |  | (31 | ) |  | 31 |  |
| Total other comprehensive income, before tax | 110 |  |  | 92 |  |  | 93 |  |  | (185 | ) |  | 110 |  |
| Income tax expense related to items of other comprehensive income | (6 | ) |  | (2 | ) |  | (4 | ) |  | 6 |  |  | (6 | ) |
| Other comprehensive income, net of tax | 104 |  |  | 90 |  |  | 89 |  |  | (179 | ) |  | 104 |  |
| Total comprehensive income | $ | 23 |  |  | $ | 896 |  |  | $ | 1,859 |  |  | $ | (2,755 | ) |  | $ | 23 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-19-000028:notes:4]
| Condensed Consolidating Balance Sheet |
| As of March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 9 |  |  | $ | 1,019 |  |  | $ | 2,654 |  |  | $ | — |  |  | $ | 3,682 |  |
| Accounts receivable, net | — |  |  | 645 |  |  | 578 |  |  | — |  |  | 1,223 |  |
| Intercompany receivables | 2,602 |  |  | 5,564 |  |  | 1,924 |  |  | (10,090 | ) |  | — |  |
| Inventories | — |  |  | 1,115 |  |  | 2,517 |  |  | (192 | ) |  | 3,440 |  |
| Loans due from consolidated affiliates | — |  |  | — |  |  | 50 |  |  | (50 | ) |  | — |  |
| Other current assets | 11 |  |  | 273 |  |  | 273 |  |  | — |  |  | 557 |  |
| Total current assets | 2,622 |  |  | 8,616 |  |  | 7,996 |  |  | (10,332 | ) |  | 8,902 |  |
| Property, plant and equipment, net | — |  |  | 1,038 |  |  | 1,993 |  |  | — |  |  | 3,031 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,403 |  |  | — |  |  | 2,403 |  |
| Goodwill | — |  |  | 388 |  |  | 9,687 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 27 |  |  | 1,891 |  |  | — |  |  | 1,918 |  |
| Investments in consolidated subsidiaries | 20,540 |  |  | 16,822 |  |  | — |  |  | (37,362 | ) |  | — |  |
| Loans due from consolidated affiliates | — |  |  | 557 |  |  | — |  |  | (557 | ) |  | — |  |
| Other non-current assets | 56 |  |  | 49 |  |  | 479 |  |  | — |  |  | 584 |  |
| Total assets | $ | 23,218 |  |  | $ | 27,497 |  |  | $ | 24,449 |  |  | $ | (48,251 | ) |  | $ | 26,913 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 216 |  |  | $ | 1,361 |  |  | $ | — |  |  | $ | 1,577 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 312 |  |  | — |  |  | 312 |  |
| Intercompany payables | 1,704 |  |  | 3,969 |  |  | 4,417 |  |  | (10,090 | ) |  | — |  |
| Accrued expenses | 169 |  |  | 614 |  |  | 862 |  |  | — |  |  | 1,645 |  |
| Accrued compensation | — |  |  | 264 |  |  | 138 |  |  | — |  |  | 402 |  |
| Loans due to consolidated affiliates | — |  |  | 50 |  |  | — |  |  | (50 | ) |  | — |  |
| Current portion of long-term debt | 276 |  |  | — |  |  | — |  |  | — |  |  | 276 |  |
| Total current liabilities | 2,149 |  |  | 5,113 |  |  | 7,090 |  |  | (10,140 | ) |  | 4,212 |  |
| Long-term debt | 10,277 |  |  | — |  |  | 32 |  |  | — |  |  | 10,309 |  |
| Loans due to consolidated affiliates | 541 |  |  | — |  |  | 16 |  |  | (557 | ) |  | — |  |
| Other liabilities | 37 |  |  | 1,684 |  |  | 457 |  |  | — |  |  | 2,178 |  |
| Total liabilities | 13,004 |  |  | 6,797 |  |  | 7,595 |  |  | (10,697 | ) |  | 16,699 |  |
| Total shareholders’ equity | 10,214 |  |  | 20,700 |  |  | 16,854 |  |  | (37,554 | ) |  | 10,214 |  |
| Total liabilities and shareholders’ equity | $ | 23,218 |  |  | $ | 27,497 |  |  | $ | 24,449 |  |  | $ | (48,251 | ) |  | $ | 26,913 |  |

[0000106040-19-000028:notes:5]
| Condensed Consolidating Balance Sheet |
| As of June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |
| Accounts receivable, net | — |  |  | 1,358 |  |  | 839 |  |  | — |  |  | 2,197 |  |
| Intercompany receivables | 1,903 |  |  | 4,256 |  |  | 2,674 |  |  | (8,833 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,159 |  |  | (205 | ) |  | 2,944 |  |
| Other current assets | 20 |  |  | 195 |  |  | 277 |  |  | — |  |  | 492 |  |
| Total current assets | 1,963 |  |  | 7,467 |  |  | 10,246 |  |  | (9,038 | ) |  | 10,638 |  |
| Property, plant and equipment, net | — |  |  | 1,092 |  |  | 2,003 |  |  | — |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,105 |  |  | — |  |  | 2,105 |  |
| Goodwill | — |  |  | 387 |  |  | 9,688 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 38 |  |  | 2,642 |  |  | — |  |  | 2,680 |  |
| Investments in consolidated subsidiaries | 20,847 |  |  | 19,893 |  |  | — |  |  | (40,740 | ) |  | — |  |
| Loans due from consolidated affiliates | 943 |  |  | 16 |  |  | — |  |  | (959 | ) |  | — |  |
| Other non-current assets | 182 |  |  | 29 |  |  | 431 |  |  | — |  |  | 642 |  |
| Total assets | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 279 |  |  | $ | 1,986 |  |  | $ | — |  |  | $ | 2,265 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Intercompany payables | 1,066 |  |  | 4,648 |  |  | 3,119 |  |  | (8,833 | ) |  | — |  |
| Accrued expenses | 198 |  |  | 505 |  |  | 571 |  |  | — |  |  | 1,274 |  |
| Accrued compensation | — |  |  | 297 |  |  | 182 |  |  | — |  |  | 479 |  |
| Current portion of long-term debt | 179 |  |  | — |  |  | — |  |  | — |  |  | 179 |  |
| Total current liabilities | 1,443 |  |  | 5,729 |  |  | 6,117 |  |  | (8,833 | ) |  | 4,456 |  |
| Long-term debt | 10,962 |  |  | — |  |  | 31 |  |  | — |  |  | 10,993 |  |
| Loans due to consolidated affiliates | — |  |  | 427 |  |  | 532 |  |  | (959 | ) |  | — |  |
| Other liabilities | (1 | ) |  | 1,768 |  |  | 488 |  |  | — |  |  | 2,255 |  |
| Total liabilities | 12,404 |  |  | 7,924 |  |  | 7,168 |  |  | (9,792 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,531 |  |  | 20,998 |  |  | 19,947 |  |  | (40,945 | ) |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |


## srt:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-19-000028:notes:6]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 87 |  |  | $ | (1,115 | ) |  | $ | 2,461 |  |  | $ | (55 | ) |  | $ | 1,378 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (198 | ) |  | (524 | ) |  | — |  |  | (722 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Purchases of investments | — |  |  | (11 | ) |  | (58 | ) |  | — |  |  | (69 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (858 | ) |  | — |  |  | (858 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 570 |  |  | — |  |  | 570 |  |
| Strategic investments and other, net | — |  |  | 1 |  |  | (23 | ) |  | — |  |  | (22 | ) |
| Intercompany loan from (to) consolidated affiliates | 943 |  |  | (541 | ) |  | — |  |  | (402 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (243 | ) |  | 243 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 700 |  |  | (506 | ) |  | (834 | ) |  | (402 | ) |  | (1,042 | ) |
| Cash flows from financing activities |  |  |  |  |  |  | — |  |  |  |
| Issuance of stock under employee stock plans | 66 |  |  | — |  |  | — |  |  | — |  |  | 66 |  |
| Taxes paid on vested stock awards under employee stock plans | (109 | ) |  | — |  |  | — |  |  | — |  |  | (109 | ) |
| Repurchases of common stock | (563 | ) |  | — |  |  | — |  |  | — |  |  | (563 | ) |
| Repayment of revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Dividends paid to shareholders | (438 | ) |  | — |  |  | — |  |  | — |  |  | (438 | ) |
| Repayment of debt | (113 | ) |  | — |  |  | — |  |  | — |  |  | (113 | ) |
| Proceeds from (repayment of) revolving credit facility | (500 | ) |  | — |  |  | — |  |  | — |  |  | (500 | ) |
| Intercompany loan from (to) consolidated affiliates | 541 |  |  | (377 | ) |  | (566 | ) |  | 402 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 298 |  |  | 2,349 |  |  | (2,702 | ) |  | 55 |  |  | — |  |
| Net cash provided by (used in) financing activities | (818 | ) |  | 1,972 |  |  | (3,268 | ) |  | 457 |  |  | (1,657 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net increase (decrease) in cash and cash equivalents | (31 | ) |  | 351 |  |  | (1,643 | ) |  | — |  |  | (1,323 | ) |
| Cash and cash equivalents, beginning of year | 40 |  |  | 668 |  |  | 4,297 |  |  | — |  |  | 5,005 |  |
| Cash and cash equivalents, end of period | $ | 9 |  |  | $ | 1,019 |  |  | $ | 2,654 |  |  | $ | — |  |  | $ | 3,682 |  |

[0000106040-19-000028:notes:7]
| Condensed Consolidating Statement of Cash Flows |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (130 | ) |  | $ | 405 |  |  | $ | 3,284 |  |  | $ | (217 | ) |  | $ | 3,342 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (162 | ) |  | (481 | ) |  | — |  |  | (643 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | (6 | ) |  | — |  |  | (99 | ) |
| Purchases of investments | — |  |  | (11 | ) |  | (55 | ) |  | — |  |  | (66 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (1,015 | ) |  | — |  |  | (1,015 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 308 |  |  | — |  |  | 308 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | 31 |  |  | — |  |  | 30 |  |
| Intercompany loan from consolidated affiliates | 3,295 |  |  | — |  |  | — |  |  | (3,295 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (47 | ) |  | 47 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 3,248 |  |  | (220 | ) |  | (1,139 | ) |  | (3,295 | ) |  | (1,406 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 146 |  |  | — |  |  | — |  |  | — |  |  | 146 |  |
| Taxes paid on vested stock awards under employee stock plans | (164 | ) |  | — |  |  | — |  |  | — |  |  | (164 | ) |
| Repurchases of common stock | (155 | ) |  | — |  |  | — |  |  | — |  |  | (155 | ) |
| Dividends paid to shareholders | (443 | ) |  | — |  |  | — |  |  | — |  |  | (443 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt | (14,581 | ) |  | — |  |  | — |  |  | — |  |  | (14,581 | ) |
| Proceeds from debt | 11,384 |  |  | — |  |  | — |  |  | — |  |  | 11,384 |  |
| Proceeds from (repayment of) revolving credit facility | 500 |  |  | — |  |  | — |  |  | — |  |  | 500 |  |
| Debt issuance costs | (52 | ) |  | — |  |  | — |  |  | — |  |  | (52 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (205 | ) |  | (3,090 | ) |  | 3,295 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 319 |  |  | (463 | ) |  | (73 | ) |  | 217 |  |  | — |  |
| Net cash used in financing activities | (3,018 | ) |  | (668 | ) |  | (3,163 | ) |  | 3,512 |  |  | (3,337 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Net increase (decrease) in cash and cash equivalents | 100 |  |  | (483 | ) |  | (1,008 | ) |  | — |  |  | (1,391 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 118 |  |  | $ | 729 |  |  | $ | 4,116 |  |  | $ | — |  |  | $ | 4,963 |  |


## srt:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-19-000028:notes:8]
[same as prior period, unchanged from 0000106040-19-000009:notes:8]

[0000106040-19-000028:notes:9]
The Company’s senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the credit agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-19-000028:notes:10]
| Condensed Consolidating Statement of Operations |
| For the three months ended March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,054 |  |  | $ | 3,817 |  |  | $ | (3,197 | ) |  | $ | 3,674 |  |
| Cost of revenue | — |  |  | 2,655 |  |  | 3,667 |  |  | (3,227 | ) |  | 3,095 |  |
| Gross profit | — |  |  | 399 |  |  | 150 |  |  | 30 |  |  | 579 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 359 |  |  | 185 |  |  | — |  |  | 544 |  |
| Selling, general and administrative | 1 |  |  | 199 |  |  | 153 |  |  | — |  |  | 353 |  |
| Intercompany operating expense (income) | — |  |  | (394 | ) |  | 394 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 42 |  |  | 34 |  |  | — |  |  | 76 |  |
| Total operating expenses | 1 |  |  | 206 |  |  | 766 |  |  | — |  |  | 973 |  |
| Operating income (loss) | (1 | ) |  | 193 |  |  | (616 | ) |  | 30 |  |  | (394 | ) |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | — |  |  | 5 |  |  | 11 |  |  | (3 | ) |  | 13 |  |
| Interest expense | (119 | ) |  | (1 | ) |  | (1 | ) |  | 3 |  |  | (118 | ) |
| Other income, net | — |  |  | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total interest and other income (expense), net | (119 | ) |  | 4 |  |  | 32 |  |  | — |  |  | (83 | ) |
| Income (loss) before taxes | (120 | ) |  | 197 |  |  | (584 | ) |  | 30 |  |  | (477 | ) |
| Equity in earnings from subsidiaries | (558 | ) |  | (732 | ) |  | — |  |  | 1,290 |  |  | — |  |
| Income tax expense (benefit) | (97 | ) |  | 52 |  |  | 149 |  |  | — |  |  | 104 |  |
| Net loss | $ | (581 | ) |  | $ | (587 | ) |  | $ | (733 | ) |  | $ | 1,320 |  |  | $ | (581 | ) |

[0000106040-19-000028:notes:11]
| Condensed Consolidating Statement of Operations |
| For the nine months ended March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 9,931 |  |  | $ | 13,670 |  |  | $ | (10,666 | ) |  | $ | 12,935 |  |
| Cost of revenue | — |  |  | 8,602 |  |  | 11,706 |  |  | (10,660 | ) |  | 9,648 |  |
| Gross profit | — |  |  | 1,329 |  |  | 1,964 |  |  | (6 | ) |  | 3,287 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,056 |  |  | 603 |  |  | — |  |  | 1,659 |  |
| Selling, general and administrative | 2 |  |  | 664 |  |  | 352 |  |  | — |  |  | 1,018 |  |
| Intercompany operating expense (income) | — |  |  | (1,148 | ) |  | 1,148 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 80 |  |  | 62 |  |  | — |  |  | 142 |  |
| Total operating expenses | 2 |  |  | 652 |  |  | 2,165 |  |  | — |  |  | 2,819 |  |
| Operating income (loss) | (2 | ) |  | 677 |  |  | (201 | ) |  | (6 | ) |  | 468 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 10 |  |  | 12 |  |  | 35 |  |  | (14 | ) |  | 43 |  |
| Interest expense | (353 | ) |  | (9 | ) |  | (4 | ) |  | 14 |  |  | (352 | ) |
| Other income (expense), net | 1 |  |  | (2 | ) |  | 29 |  |  | — |  |  | 28 |  |
| Total interest and other income (expense), net | (342 | ) |  | 1 |  |  | 60 |  |  | — |  |  | (281 | ) |
| Income (loss) before taxes | (344 | ) |  | 678 |  |  | (141 | ) |  | (6 | ) |  | 187 |  |
| Equity in earnings from subsidiaries | (551 | ) |  | (520 | ) |  | — |  |  | 1,071 |  |  | — |  |
| Income tax expense (benefit) | (338 | ) |  | 702 |  |  | 380 |  |  | — |  |  | 744 |  |
| Net loss | $ | (557 | ) |  | $ | (544 | ) |  | $ | (521 | ) |  | $ | 1,065 |  |  | $ | (557 | ) |

[0000106040-19-000028:notes:12]
| Condensed Consolidating Statement of Operations |
| For the three months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,685 |  |  | $ | 4,924 |  |  | $ | (3,596 | ) |  | $ | 5,013 |  |
| Cost of revenue | — |  |  | 3,209 |  |  | 3,499 |  |  | (3,622 | ) |  | 3,086 |  |
| Gross profit | — |  |  | 476 |  |  | 1,425 |  |  | 26 |  |  | 1,927 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 361 |  |  | 241 |  |  | — |  |  | 602 |  |
| Selling, general and administrative | 3 |  |  | 264 |  |  | 109 |  |  | — |  |  | 376 |  |
| Intercompany operating expense (income) | (12 | ) |  | (391 | ) |  | 403 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 9 |  |  | 25 |  |  | — |  |  | 35 |  |
| Total operating expenses | (8 | ) |  | 243 |  |  | 778 |  |  | — |  |  | 1,013 |  |
| Operating income | 8 |  |  | 233 |  |  | 647 |  |  | 26 |  |  | 914 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 42 |  |  | 2 |  |  | 12 |  |  | (40 | ) |  | 16 |  |
| Interest expense | (160 | ) |  | (5 | ) |  | (35 | ) |  | 40 |  |  | (160 | ) |
| Other expense, net | (894 | ) |  | (7 | ) |  | (7 | ) |  | 10 |  |  | (898 | ) |
| Total interest and other expense, net | (1,012 | ) |  | (10 | ) |  | (30 | ) |  | 10 |  |  | (1,042 | ) |
| Income (loss) before taxes | (1,004 | ) |  | 223 |  |  | 617 |  |  | 36 |  |  | (128 | ) |
| Equity in earnings from subsidiaries | 837 |  |  | 562 |  |  | — |  |  | (1,399 | ) |  | — |  |
| Income tax expense (benefit) | (228 | ) |  | 22 |  |  | 17 |  |  | — |  |  | (189 | ) |
| Net income | $ | 61 |  |  | $ | 763 |  |  | $ | 600 |  |  | $ | (1,363 | ) |  | $ | 61 |  |

[0000106040-19-000028:notes:13]
| Condensed Consolidating Statement of Operations |
| For the nine months ended March 30, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 11,159 |  |  | $ | 15,178 |  |  | $ | (10,807 | ) |  | $ | 15,530 |  |
| Cost of revenue | — |  |  | 9,665 |  |  | 10,849 |  |  | (10,837 | ) |  | 9,677 |  |
| Gross profit | — |  |  | 1,494 |  |  | 4,329 |  |  | 30 |  |  | 5,853 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,142 |  |  | 681 |  |  | — |  |  | 1,823 |  |
| Selling, general and administrative | 6 |  |  | 798 |  |  | 317 |  |  | — |  |  | 1,121 |  |
| Intercompany operating expense (income) | (12 | ) |  | (1,221 | ) |  | 1,233 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 30 |  |  | 104 |  |  | — |  |  | 135 |  |
| Total operating expenses | (5 | ) |  | 749 |  |  | 2,335 |  |  | — |  |  | 3,079 |  |
| Operating income | 5 |  |  | 745 |  |  | 1,994 |  |  | 30 |  |  | 2,774 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 189 |  |  | 6 |  |  | 38 |  |  | (187 | ) |  | 46 |  |
| Interest expense | (561 | ) |  | (15 | ) |  | (173 | ) |  | 187 |  |  | (562 | ) |
| Other income (expense), net | (902 | ) |  | — |  |  | (10 | ) |  | 10 |  |  | (902 | ) |
| Total interest and other expense, net | (1,274 | ) |  | (9 | ) |  | (145 | ) |  | 10 |  |  | (1,418 | ) |
| Income (loss) before taxes | (1,269 | ) |  | 736 |  |  | 1,849 |  |  | 40 |  |  | 1,356 |  |
| Equity in earnings from subsidiaries | 869 |  |  | 1,747 |  |  | — |  |  | (2,616 | ) |  | — |  |
| Income tax expense (benefit) | (319 | ) |  | 1,677 |  |  | 79 |  |  | — |  |  | 1,437 |  |
| Net income (loss) | $ | (81 | ) |  | $ | 806 |  |  | $ | 1,770 |  |  | $ | (2,576 | ) |  | $ | (81 | ) |

[0000106040-19-000028:notes:14]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended March 29, 2019 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (581 | ) |  | $ | (587 | ) |  | $ | (733 | ) |  | $ | 1,320 |  |  | $ | (581 | ) |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustment | (2 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (2 | ) |
| Net unrealized gain (loss), on derivative contracts and available-for-sale securities | (24 | ) |  | 1 |  |  | 1 |  |  | (2 | ) |  | (24 | ) |
| Total other comprehensive income (loss), before tax | (26 | ) |  | (1 | ) |  | (1 | ) |  | 2 |  |  | (26 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | 5 |  |  | — |  |  | — |  |  | 1 |  |  | 6 |  |
| Other comprehensive income (loss), net of tax | (21 | ) |  | (1 | ) |  | (1 | ) |  | 3 |  |  | (20 | ) |
| Total comprehensive loss | $ | (602 | ) |  | $ | (588 | ) |  | $ | (734 | ) |  | $ | 1,323 |  |  | $ | (601 | ) |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-19-000028:notes:15]
[same as prior period, unchanged from 0000106040-19-000009:notes:15]

[0000106040-19-000028:notes:16]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 3,682 |  |  | $ | 5,005 |  |
| Short-term available-for-sale securities (included within Other current assets) | 15 |  |  | 23 |  |
| Long-term available-for-sale securities (included within Other non-current assets) | 104 |  |  | 93 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 3,801 |  |  | $ | 5,121 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-19-000028:notes:17]
[same as prior period, unchanged from 0000106040-19-000009:notes:17]

[0000106040-19-000028:notes:18]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Benefit obligations | $ | 260 |  |  | $ | 260 |  |
| Fair value of plan assets | 205 |  |  | 200 |  |
| Unfunded status | $ | 55 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-19-000028:notes:19]
Commitments, Contingencies and Related Parties

[0000106040-19-000028:notes:20]
Flash Ventures

[0000106040-19-000028:notes:21]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-19-000028:notes:22]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 29, 2019 and June 29, 2018:

[0000106040-19-000028:notes:23]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 620 |  |  | $ | 767 |  |
| Notes receivable, Flash Alliance | 599 |  |  | 48 |  |
| Notes receivable, Flash Forward | 584 |  |  | 700 |  |
| Investment in Flash Partners | 194 |  |  | 191 |  |
| Investment in Flash Alliance | 287 |  |  | 283 |  |
| Investment in Flash Forward | 119 |  |  | 116 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,403 |  |  | $ | 2,105 |  |

[0000106040-19-000028:notes:24]
During the three and nine months ended March 29, 2019, the Company made net payments to Flash Ventures of $1.0 billion and $2.9 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-19-000028:notes:25]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-19-000028:notes:26]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in the three and nine months ended March 29, 2019 or March 30, 2018.

[0000106040-19-000028:notes:27]
As of March 29, 2019 and June 29, 2018, the Company had accounts payable balances due to Flash Ventures of $312 million and $259 million, respectively.

[0000106040-19-000028:notes:28]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 29, 2019, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-19-000028:notes:29]
|  | March 29, 2019 |
| Notes receivable | $ | 1,803 |  |
| Equity investments | 600 |  |
| Operating lease guarantees | 1,421 |  |
| Inventory | 274 |  |
| Maximum estimable loss exposure | $ | 4,098 |  |

[0000106040-19-000028:notes:30]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-19-000028:notes:31]
Flash Ventures has historically operated near 100% of its manufacturing capacity. As a result of current supply/demand imbalance for flash-based products, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. The Company incurred costs of $148 million and $197 million associated with the reduction in utilization which was recorded as a charge to cost of revenue in the three and nine months ended March 29, 2019, respectively.

[0000106040-19-000028:notes:32]
Off-Balance Sheet Liabilities

[0000106040-19-000028:notes:33]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-19-000028:notes:34]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019.

[0000106040-19-000028:notes:35]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 157 |  |  | $ | 1,421 |  |

[0000106040-19-000028:notes:36]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 29, 2019 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 29, 2019:

[0000106040-19-000028:notes:37]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2019 |  | $ | 106 |  |  | $ | 9 |  |  | $ | 115 |  |
| 2020 |  | 360 |  |  | 64 |  |  | 424 |  |
| 2021 |  | 271 |  |  | 106 |  |  | 377 |  |
| 2022 |  | 185 |  |  | 48 |  |  | 233 |  |
| 2023 |  | 81 |  |  | 28 |  |  | 109 |  |
| Thereafter |  | 45 |  |  | 118 |  |  | 163 |  |
| Total guarantee obligations |  | $ | 1,048 |  |  | $ | 373 |  |  | $ | 1,421 |  |

[0000106040-19-000028:notes:38]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 29, 2019, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-19-000028:notes:39]
Unis Venture

[0000106040-19-000028:notes:40]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three and nine months ended March 29, 2019 and March 30, 2018, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were not material to the Condensed Consolidated Financial Statements as of March 29, 2019 or June 29, 2018.

[0000106040-19-000028:notes:41]
Purchase Agreements

[0000106040-19-000028:notes:42]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing, which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of March 29, 2019, the Company had the following minimum long-term purchase commitments:

[0000106040-19-000028:notes:43]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| Remaining three months of 2019 |  | $ | 15 |  |
| 2020 |  | 192 |  |
| 2021 |  | 208 |  |
| 2022 |  | 227 |  |
| 2023 and thereafter |  | 250 |  |
| Total |  | $ | 892 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-19-000028:notes:44]
Debt

[0000106040-19-000028:notes:45]
Debt consisted of the following as of March 29, 2019 and June 29, 2018:

[0000106040-19-000028:notes:46]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | — |  |  | 500 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,896 |  |  | 4,991 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,431 |  |  | 2,449 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 10,762 |  |  | 11,375 |  |
| Issuance costs and debt discounts | (177 | ) |  | (203 | ) |
| Subtotal | 10,585 |  |  | 11,172 |  |
| Less current portion of long-term debt | (276 | ) |  | (179 | ) |
| Long-term debt | $ | 10,309 |  |  | $ | 10,993 |  |

[0000106040-19-000028:notes:47]
In November 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At March 29, 2019, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

[0000106040-19-000028:notes:48]
The credit agreement governing the Company’s revolving credit facility and term loans (as amended, the “Credit Agreement”) requires the Company to comply with certain financial covenants with respect to the revolving credit facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). These covenants are based upon a trailing twelve-month consolidated adjusted EBITDA as defined in the Credit Agreement (“Adjusted EBITDA”). Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization as well as other contractual adjustments as provided for in the Credit Agreement. As of March 29, 2019, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-19-000028:notes:49]
In April 2019, the Company amended the Credit Agreement for the purposes of providing additional flexibility by adjusting the leverage ratio maintenance covenant levels applicable to the term A loan and revolving facilities thereunder and amending the definition of Consolidated Adjusted EBITDA under the financial maintenance covenants to include an addback for certain depreciation related payments with respect to the Company’s Flash Ventures. As amended, the Company is now required to maintain a maximum ratio of total funded debt to trailing twelve-month Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ending October 2, 2020, 4.00 to 1.00 through the quarter ending July 2, 2021, 3.75 to 1.00 through the quarter ending December 31, 2021, 3.50 to 1.00 through the quarter ending July 1, 2022, and 3.25 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00.

[0000106040-19-000028:notes:50]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-19-000028:notes:51]
[same as prior period, unchanged from 0000106040-19-000009:notes:51]

[0000106040-19-000028:notes:52]
As of March 29, 2019, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps that were designated as cash flow hedges. The Company did not have any foreign exchange forward contracts with credit-risk-related contingent features. As of March 29, 2019, the amount of existing net losses related to cash flow hedges recorded in AOCI was not material and the majority is expected to be reclassified to earnings over the next twelve months.

[0000106040-19-000028:notes:53]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and nine months ended March 29, 2019 and March 30, 2018, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:54]
[same as prior period, unchanged from 0000106040-19-000009:notes:54]

[0000106040-19-000028:notes:55]
[same as prior period, unchanged from 0000106040-19-000009:notes:55]

[0000106040-19-000028:notes:56]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 29, 2019 and June 29, 2018, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000106040-19-000028:notes:57]
[same as prior period, unchanged from 0000106040-19-000009:notes:57]

[0000106040-19-000028:notes:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except percentages) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Client Devices | $ | 1,625 |  |  | $ | 2,311 |  |  | $ | 6,489 |  |  | $ | 7,634 |  |
| Data Center Devices & Solutions | 1,245 |  |  | 1,660 |  |  | 3,765 |  |  | 4,463 |  |
| Client Solutions | 804 |  |  | 1,042 |  |  | 2,681 |  |  | 3,433 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Form Factor |  |  |  |  |  |  |  |
| HDD | $ | 2,064 |  |  | $ | 2,640 |  |  | $ | 6,618 |  |  | $ | 7,944 |  |
| Flash-based | 1,610 |  |  | 2,373 |  |  | 6,317 |  |  | 7,586 |  |
| Total Revenue | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Revenue by Geography (%) |  |  |  |  |  |  |  |
| Americas | 29 | % |  | 28 | % |  | 26 | % |  | 27 | % |
| Europe, Middle East and Africa | 20 |  |  | 19 |  |  | 19 |  |  | 18 |  |
| Asia | 51 |  |  | 53 |  |  | 55 |  |  | 55 |  |

[0000106040-19-000028:notes:59]
[same as prior period, unchanged from 0000106040-19-000009:notes:59]


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-19-000028:notes:60]
[same as prior period, unchanged from 0000106040-19-000009:notes:60]

[0000106040-19-000028:notes:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Options | $ | 3 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 19 |  |
| Restricted and performance stock units | 71 |  |  | 89 |  |  | 208 |  |  | 260 |  |
| Employee stock purchase plan | 10 |  |  | 8 |  |  | 22 |  |  | 20 |  |
| Subtotal | 84 |  |  | 103 |  |  | 242 |  |  | 299 |  |
| Tax benefit | (14 | ) |  | (17 | ) |  | (39 | ) |  | (51 | ) |
| Total | $ | 70 |  |  | $ | 86 |  |  | $ | 203 |  |  | $ | 248 |  |

[0000106040-19-000028:notes:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 11 |  |  | $ | 37 |  |  | $ | 37 |  |
| Research and development | 41 |  |  | 45 |  |  | 122 |  |  | 134 |  |
| Selling, general and administrative | 30 |  |  | 46 |  |  | 83 |  |  | 127 |  |
| Employee termination, asset impairment, and other charges | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Subtotal | 84 |  |  | 103 |  |  | 242 |  |  | 299 |  |
| Tax benefit | (14 | ) |  | (17 | ) |  | (39 | ) |  | (51 | ) |
| Total | $ | 70 |  |  | $ | 86 |  |  | $ | 203 |  |  | $ | 248 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-19-000028:notes:63]
[same as prior period, unchanged from 0000106040-19-000009:notes:63]

[0000106040-19-000028:notes:64]
[same as prior period, unchanged from 0000106040-19-000009:notes:64]

[0000106040-19-000028:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (581 | ) |  | $ | 61 |  |  | $ | (557 | ) |  | $ | (81 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 292 |  |  | 298 |  |  | 291 |  |  | 296 |  |
| Employee stock options, RSUs, PSUs and ESPP | — |  |  | 10 |  |  | — |  |  | — |  |
| Diluted | 292 |  |  | 308 |  |  | 291 |  |  | 296 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (1.99 | ) |  | $ | 0.20 |  |  | $ | (1.91 | ) |  | $ | (0.27 | ) |
| Diluted | $ | (1.99 | ) |  | $ | 0.20 |  |  | $ | (1.91 | ) |  | $ | (0.27 | ) |

[0000106040-19-000028:notes:66]
The Company computes basic income (loss) per common share using net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the three months ended March 30, 2018, the Company excluded 2 million common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For the three and nine months ended March 29, 2019 and the nine months ended March 30, 2018, the Company reported a net loss, and all outstanding equity awards have been excluded from such periods because including them would be anti-dilutive. See Note 10, Shareholders’ Equity.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-19-000028:notes:67]
[same as prior period, unchanged from 0000106040-19-000009:notes:67]

[0000106040-19-000028:notes:68]
[same as prior period, unchanged from 0000106040-19-000009:notes:68]

[0000106040-19-000028:notes:69]
[same as prior period, unchanged from 0000106040-19-000009:notes:69]

[0000106040-19-000028:notes:70]
[same as prior period, unchanged from 0000106040-19-000009:notes:70]

[0000106040-19-000028:notes:71]
[same as prior period, unchanged from 0000106040-19-000009:notes:71]

[0000106040-19-000028:notes:72]
[same as prior period, unchanged from 0000106040-19-000009:notes:72]

[0000106040-19-000028:notes:73]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 29, 2019 and June 29, 2018, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-19-000028:notes:74]
|  | March 29, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,508 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,508 |  |
| Certificates of deposit | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents | 1,508 |  |  | 6 |  |  | — |  |  | 1,514 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Asset-backed securities | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Municipal notes and bonds |  |  |  | 6 |  |  | — |  |  | 6 |  |
| Equity securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Total short-term available-for-sale securities | 1 |  |  | 14 |  |  | — |  |  | 15 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| International government securities | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Corporate notes and bonds | — |  |  | 75 |  |  | — |  |  | 75 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total long-term available-for-sale securities | 5 |  |  | 99 |  |  | — |  |  | 104 |  |
| Foreign exchange contracts | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Interest rate swap contracts | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total assets at fair value | $ | 1,514 |  |  | $ | 144 |  |  | $ | — |  |  | $ | 1,658 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |
| Interest rate swap contract | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 48 |  |  | $ | — |  |  | $ | 48 |  |

[0000106040-19-000028:notes:75]
[same as prior period, unchanged from 0000106040-19-000009:notes:75]

[0000106040-19-000028:notes:76]
During the three and nine months ended March 29, 2019, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-19-000028:notes:77]
[same as prior period, unchanged from 0000106040-19-000009:notes:77]

[0000106040-19-000028:notes:78]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of March 29, 2019 and June 29, 2018.

[0000106040-19-000028:notes:79]
[same as prior period, unchanged from 0000106040-19-000009:notes:79]

[0000106040-19-000028:notes:80]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity securities of these privately-held companies do not have a RDFV. Under ASU 2016-01, these equity securities are now measured and recorded using the measurement alternative, which is cost minus impairment, if any, plus or minus changes resulting from qualifying observable price changes. In addition, the existing impairment model has been replaced with a new one-step qualitative impairment model. Adjustments resulting from impairments and qualifying observable price changes are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. As of March 29, 2019 and June 30, 2018, these investments were not material.

[0000106040-19-000028:notes:81]
[same as prior period, unchanged from 0000106040-19-000009:notes:81]

[0000106040-19-000028:notes:82]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2019 and the fourth quarter of 2018, respectively.

[0000106040-19-000028:notes:83]
|  | March 29, 2019 |  | June 29, 2018 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 32 |  |  | $ | 34 |  |  | $ | 31 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,889 |  |  | 4,771 |  |  | 4,982 |  |  | 5,013 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,430 |  |  | 2,381 |  |  | 2,448 |  |  | 2,452 |  |
| 1.50% convertible notes due 2024 | 952 |  |  | 970 |  |  | 931 |  |  | 1,114 |  |
| 4.750% senior unsecured notes due 2026 | 2,282 |  |  | 2,199 |  |  | 2,280 |  |  | 2,238 |  |
| Total | $ | 10,585 |  |  | $ | 10,355 |  |  | $ | 10,672 |  |  | $ | 10,851 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-19-000028:notes:84]
Income Tax Expense (Benefit)

[0000106040-19-000028:notes:85]
[same as prior period, unchanged from 0000106040-19-000009:notes:85]

[0000106040-19-000028:notes:86]
When initially accounting for the tax effects of the enactment of the 2017 Act, the Company applied the applicable SEC guidance and made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act. As the Company finalized the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, the Company reflected adjustments to the recorded provisional amounts. During the second quarter of fiscal 2019, the Company completed its accounting for the tax effects of the enactment of the 2017 Act. Although the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, the Company anticipates the issuance of additional regulatory and interpretive guidance. Although the Company was able to apply a reasonable interpretation of the law along with any available guidance in finalizing its accounting for the tax effects of the 2017 Act, such additional regulatory or interpretive guidance would constitute new information which may require further refinements to its estimates in future periods.

[0000106040-19-000028:notes:87]
[same as prior period, unchanged from 0000106040-19-000009:notes:87]

[0000106040-19-000028:notes:88]
[same as prior period, unchanged from 0000106040-19-000009:notes:88]

[0000106040-19-000028:notes:89]
The Company recorded a provisional income tax benefit of $65 million for the year ended June 29, 2018, which related to the re-measurements of the Company’s deferred tax balances and is based primarily on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. As of December 28, 2018, the Company had finalized the accounting for the tax effects related to the re-measurements of the Company’s deferred tax balances with no material change for the six months ended December 28, 2018. During the three months ended March 29, 2019, the Company finalized the filing of its U.S. federal income tax return for the year ended June 29, 2018, which resulted in an additional income tax benefit of $5 million for the re-measurement of the Company’s deferred tax assets and liabilities that are expected to reverse at 22%.

[0000106040-19-000028:notes:90]
[same as prior period, unchanged from 0000106040-19-000009:notes:90]

[0000106040-19-000028:notes:91]
[same as prior period, unchanged from 0000106040-19-000009:notes:91]

[0000106040-19-000028:notes:92]
The Company had finalized the accounting for the tax effects of the mandatory deemed repatriation tax during the one-year measurement period permitted by applicable SEC guidance. During the first quarter of fiscal 2019, the Company reduced its mandatory deemed repatriation tax liability by $302 million, of which $250 million was for the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets was a reclassification that did not have an impact on the Company’s income tax provision for the three months ended September 28, 2018. The remaining $52 million reduction to the mandatory deemed repatriation tax primarily related to the Company’s decision to no longer carry forward its 2018 operating loss and, instead, apply it against the mandatory deemed repatriation tax. The $52 million benefit resulted from utilizing the existing fiscal year 2019 operating losses at a 28% tax rate on the Company’s 2018 tax return as compared to the carryforward tax rate of 21%. The Company’s estimate of the mandatory deemed repatriation tax liability after these refinements was $1.26 billion.

[0000106040-19-000028:notes:93]
During the second quarter of fiscal 2019, the Company also finalized its post-1986 earnings and profits along with the amount of earnings held in cash and other specified assets and increased its mandatory deemed repatriation tax liability by $95 million. The Company’s estimate of the mandatory deemed repatriation tax liability after these refinements was $1.36 billion, excluding a $135 million increase in its liability for unrecognized tax benefits.

[0000106040-19-000028:notes:94]
During the three months ended March 29, 2019, the Company finalized the filing of its U.S. federal income tax return for the year ended June 29, 2018, which resulted in a decrease to its mandatory repatriation tax liability by $105 million, of which $41 million related to the utilization of recorded deferred tax assets related to existing tax attributes. The utilization of the deferred tax assets resulted in an income tax benefit of $19 million for the three months ended March 29, 2019 with the remaining amount being a reclassification that did not have an impact on the Company’s income tax provision. The remaining $64 million benefit related to the issuance by the IRS of final regulations on January 15, 2019 with respect to the mandatory deemed repatriation tax liability. These regulations favorably impacted certain positions previously taken with respect to amounts recorded in the Company’s Consolidated Financial Statements. As of March 29, 2019, the Company’s estimate of the mandatory deemed repatriation tax liability after these refinements was $1.25 billion, excluding a $146 million liability for unrecognized tax benefits, which increased by $11 million from the second quarter.

[0000106040-19-000028:notes:95]
During the one-year measurement period, the Company had evaluated the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This required the Company to re-evaluate its existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax of repatriating cash to the U.S. The provisional tax expense recorded by the Company as of June 28, 2018 was based upon an assumption that all of its foreign undistributed earnings are indefinitely reinvested.

[0000106040-19-000028:notes:96]
During the second quarter of fiscal 2019, the Company had finalized the accounting for the tax effects of the mandatory deemed repatriation tax on its indefinite reinvestment assertion. As of the second quarter of fiscal 2019, the Company removed its permanent reinvestment assertion and intends to repatriate all of its foreign undistributed earnings. During the nine months ended March 29, 2019, the Company recorded a foreign income tax expense of $279 million related to foreign withholding taxes partially offset by foreign tax credits of $95 million. In addition, a state income tax expense of $54 million was recorded, partially offset by a decrease to the Company’s valuation allowance of $45 million. Amounts related to federal taxes other than the repatriation tax were not material. The Company’s decision to change its indefinite reinvestment assertion is based on interpretative guidance issued by the IRS to date related to the ordering and the taxation of a repatriation of the Company’s foreign undistributed earnings.

[0000106040-19-000028:notes:97]
[same as prior period, unchanged from 0000106040-19-000009:notes:97]

[0000106040-19-000028:notes:98]
[same as prior period, unchanged from 0000106040-19-000009:notes:98]

[0000106040-19-000028:notes:99]
Subsequent to June 28, 2018, the Company made the election to account for the effects of the global intangible low-tax income provision as a component of future income tax expense in the period in which the tax arises. There was no change in the Company’s accounting as a result of this election.

[0000106040-19-000028:notes:100]
[same as prior period, unchanged from 0000106040-19-000009:notes:100]

[0000106040-19-000028:notes:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Income (loss) before taxes | $ | (477 | ) |  | $ | (128 | ) |  | $ | 187 |  |  | $ | 1,356 |  |
| Income tax expense (benefit) | $ | 104 |  |  | $ | (189 | ) |  | $ | 744 |  |  | $ | 1,437 |  |
| Effective tax rate | (22 | )% |  | 148 | % |  | 398 | % |  | 106 | % |

[0000106040-19-000028:notes:102]
The primary driver of the difference between the effective tax rate for the three and nine months ended March 29, 2019 and the U.S. Federal statutory rate of 21% is the discrete effect of the finalization of the accounting for the tax effects of the enactment of the 2017 Act. For the three months ended March 29, 2019, these discrete effects consist of income tax benefits of $71 million related to the mandatory deemed repatriation tax. For the nine months ended March 29, 2019, these discrete effects consist of $107 million related to the mandatory deemed repatriation tax and $152 million related to the Company’s decision to change its indefinite reinvestment assertion. For both periods, the remaining difference is attributable primarily to an increase in the estimated effective tax rate due to changes in the relative mix of earnings by jurisdiction, partially offset by credits and tax holidays. The net windfall tax benefits related to vesting and exercises of stock-based awards were not material for the three and nine months ended March 29, 2019.

[0000106040-19-000028:notes:103]
The primary drivers for the difference between the effective tax rate for the three months ended March 30, 2018 and the U.S. Federal statutory rate of 28% included discrete effects consisting of an income tax benefit of $211 million from deductible make-whole premiums and the write-off of unamortized issuance costs from the Company’s debt financing transactions. The primary drivers for the difference between the effective tax rate for the nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% were related to the net charge of $1.66 billion for the one-time mandatory deemed repatriation tax, offset in part by an income tax benefit related to the re-measurement of deferred taxes as required by the 2017 Act and deductible make-whole premiums and the write-off of unamortized issuance costs from the Company’s debt financing transactions. The primary drivers for the remaining difference between the effective tax rate for the three and nine months ended March 30, 2018 and the U.S. Federal statutory rate of 28% were tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expired or expire at various dates during fiscal years 2018 through 2030 and net windfall tax benefits related to vesting and exercises of stock-based awards of $46 million and $73 million for the three and nine months ended March 30, 2018, respectively.

[0000106040-19-000028:notes:104]
During the nine months ended March 29, 2019, the Company recorded an increase of $157 million in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of March 29, 2019, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $708 million. Accrued interest and penalties related to unrecognized tax benefits as of March 29, 2019 was $120 million.

[0000106040-19-000028:notes:105]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2008 through 2012 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS for fiscal years 2008 through 2009, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the disputed matters for fiscal years 2008 through 2009, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest. The Company filed a petition with the U.S. Tax Court in September 2018. On December 10, 2018, the IRS issued a statutory notice of deficiency with respect to fiscal years 2010 through 2012, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax for fiscal years 2010 through 2012 totaling approximately $549 million, subject to interest. Approximately $535 million of the total additional federal tax for fiscal years 2010 through 2012 relates to proposed adjustments for transfer pricing with the Company’s foreign subsidiaries, intercompany payable balances and the utilization of certain tax attributes. The Company filed a petition with the U.S. Tax Court in March 2019. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS.

[0000106040-19-000028:notes:106]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 29, 2019, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-19-000028:notes:107]
Legal Proceedings

[0000106040-19-000028:notes:108]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-19-000028:notes:109]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-19-000028:notes:110]
Intellectual Property Litigation

[0000106040-19-000028:notes:111]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-19-000028:notes:112]
Securities

[0000106040-19-000028:notes:113]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. In September 2018, the District Court granted the Institutional Investor Group’s motion to certify a class of all persons and entities who purchased or otherwise acquired SanDisk’s publicly traded common stock between October 2014 and April 2015, excluding those who purchased or otherwise acquired SanDisk’s publicly traded common stock during the class period but who sold their stock prior to the first corrective disclosure in March 2015.  The Institutional Investor Group alleges artificial inflation in the price of SanDisk’s publicly traded common stock of $9.04 per share from October 16, 2014 through March 25, 2015, $2.26 per share on March 26, 2015, and $1.35 per share from March 27, 2015 through April 15, 2015. In March 2019, the parties reached a settlement of all claims in this matter, subject to formal ratification by party representatives and approval by the court, and a hearing on the parties’ motion for preliminary approval is set for May 16, 2019. The charge related to the settlement was recorded in Selling, general and administrative expense.

[0000106040-19-000028:notes:114]
Tax

[0000106040-19-000028:notes:115]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, see Note 11, Income Tax Expense.

[0000106040-19-000028:notes:116]
Other Matters

[0000106040-19-000028:notes:117]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-19-000028:notes:118]
Recent Accounting Pronouncements

[0000106040-19-000028:notes:119]
Accounting Pronouncements Recently Adopted

[0000106040-19-000028:notes:120]
On August 29, 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2018-15, “Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract” (“ASU 2018-15”), to reduce diversity in practice in accounting for the costs of implementing cloud computing arrangements that are service contracts. ASU 2018-15 allows entities to apply the guidance in the FASB Accounting Standards Codification (“ASC”) 350-40 to determine which implementation costs are eligible to be capitalized as assets in a cloud computing arrangement that is considered a service contract. The Company adopted this standard on a prospective basis effective June 30, 2018, the beginning of fiscal year 2019, as allowed by the standard. The adoption of this standard and the costs capitalized for the nine months ended March 29, 2019 were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:121]
In February 2018, the FASB issued ASU No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act enacted on December 22, 2017 (the “2017 Act”). Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. Because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. For tax effects that are unrelated to the 2017 Act, the Company’s policy to release these from Accumulated other comprehensive loss on an individual item basis rather than a portfolio basis remains unchanged. The Company early adopted this standard effective June 30, 2018 and elected to reclassify stranded tax effects resulting from the 2017 Act from Accumulated other comprehensive loss to Retained earnings. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:122]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness with the entire change in fair value of designated hedge reported in the results of operations in the same line item as the hedged item. The Company early adopted this standard effective June 30, 2018, using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:123]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. The Company adopted this standard on a prospective basis effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:124]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that the Company report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are now presented in Other income (expense), net in the Condensed Consolidated Statements of Operations. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:125]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business.” This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective June 30, 2018 and will apply it prospectively to transactions occurring thereafter. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:126]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving intellectual property (“IP”). The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:127]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. Marketable equity securities previously classified as available-for-sale equity investments are now measured and recorded at fair value with changes in fair value recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations rather than as a component of Other comprehensive income as in prior years. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. The Company adopted this standard effective June 30, 2018. The adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-19-000028:notes:128]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which superseded the requirements in ASC 605 “Revenue Recognition” (Topic 605). Topic 606 outlines a comprehensive five-step revenue recognition model based on the principle that an entity should recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. Topic 606 also requires more detailed disclosures to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted Topic 606 effective June 30, 2018, using the modified retrospective method to all contracts that were not completed contracts as of the beginning of the fiscal year. Results for reporting periods beginning with fiscal year 2019 are presented under Topic 606, while prior period information presented on the financial statements or elsewhere in this Quarterly Report on Form 10-Q is reported under the Company’s historic accounting policies under Topic 605 in effect for that period and is not adjusted to reflect the retrospective effect of the adoption of Topic 606. The cumulative effect of adopting Topic 606 was a post-tax increase to the opening retained earnings of $56 million as of June 30, 2018, which was primarily related to our license and royalty revenue arrangements. These arrangements had no remaining performance obligations but were previously recognized under Topic 605 when they were reported to the Company by its licensees, which was generally one quarter in arrears from the licensees’ sales of the licensed products. Adoption of the standard did not have a material impact on the Company’s financial position, results of operations, and cash flows, as of or for the three and nine months ended March 29, 2019, and the Company expects that the impact of the adoption of the new standard will not be material to its results of operations prospectively. See Note 3, Revenues, for additional disclosures related to this standard.

[0000106040-19-000028:notes:129]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-19-000028:notes:130]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company does not expect this update to have a material impact on its Consolidated Financial Statements.

[0000106040-19-000028:notes:131]
In October 2018, the FASB issued ASU No. 2018-16, “Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting Purposes” (“ASU 2018-16”). ASU 2018-16 allows for the use of the OIS rate based on the SOFR as a U.S. benchmark interest rate for hedge accounting purposes under Topic 815, Derivatives and Hedging. For public entities who have adopted ASU 2017-12, the amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, which for the Company is the first quarter of fiscal 2020. The Company does not expect this update to have a material impact on its Consolidated Financial Statements.

[0000106040-19-000028:notes:132]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-19-000028:notes:133]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or the direct use of, a specified asset for the lease term. The FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted, and provides optional practical expedients to simplify transition. The Company’s cross-functional project management team continues to identify and evaluate the impact of the amended guidance on the Company's Consolidated Financial Statements and related disclosures, business processes, internal controls, and information systems. The Company has identified its leases and selected a third-party lease accounting software solution. The Company is in the process of implementing its lease accounting software solution and changes to its processes and internal controls to address the new lease standard. The Company’s implementation efforts are progressing as planned. The Company expects to adopt this standard in the first quarter of fiscal 2020 and elect the transition method provided in ASU 2018-11 to apply Topic 842 as of the date of adoption without adjusting comparative periods. The Company also expects to elect the package of practical expedients and not reassess prior conclusions including (a) whether its contracts are or contain a lease, (b) lease classification and (c) capitalization of initial direct costs. The Company continues to evaluate the impact ASU 2016-02 will have on its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-19-000028:notes:134]
[same as prior period, unchanged from 0000106040-19-000009:notes:139]

[0000106040-19-000028:notes:135]
[same as prior period, unchanged from 0000106040-19-000009:notes:140]

[0000106040-19-000028:notes:136]
[same as prior period, unchanged from 0000106040-19-000009:notes:141]

[0000106040-19-000028:notes:137]
[same as prior period, unchanged from 0000106040-19-000009:notes:142]

[0000106040-19-000028:notes:138]
[same as prior period, unchanged from 0000106040-19-000009:notes:143]

[0000106040-19-000028:notes:139]
[same as prior period, unchanged from 0000106040-19-000009:notes:144]

[0000106040-19-000028:notes:140]
[same as prior period, unchanged from 0000106040-19-000009:notes:145]


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-19-000028:notes:141]
[same as prior period, unchanged from 0000106040-19-000009:notes:146]

[0000106040-19-000028:notes:142]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 930 |  |  | $ | 1,315 |  |
| Other non-current liabilities | 1,248 |  |  | 940 |  |
| Total other non-current liabilities | $ | 2,178 |  |  | $ | 2,255 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-19-000028:notes:143]
[same as prior period, unchanged from 0000106040-19-000009:notes:148]

[0000106040-19-000028:notes:144]
[same as prior period, unchanged from 0000106040-19-000009:notes:149]

[0000106040-19-000028:notes:145]
[same as prior period, unchanged from 0000106040-19-000009:notes:150]

[0000106040-19-000028:notes:146]
[same as prior period, unchanged from 0000106040-19-000009:notes:151]

[0000106040-19-000028:notes:147]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 54 |  |  | 59 |  |
| Net amount recognized | $ | 55 |  |  | $ | 60 |  |

[0000106040-19-000028:notes:148]
Net periodic benefit costs were not material for the three and nine months ended March 29, 2019.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-19-000028:notes:149]
[same as prior period, unchanged from 0000106040-19-000009:notes:154]

[0000106040-19-000028:notes:150]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land | $ | 307 |  |  | $ | 306 |  |
| Buildings and improvements | 2,012 |  |  | 1,949 |  |
| Machinery and equipment | 7,593 |  |  | 7,209 |  |
| Computer equipment and software | 460 |  |  | 440 |  |
| Furniture and fixtures | 55 |  |  | 48 |  |
| Construction-in-process | 211 |  |  | 234 |  |
| Property, plant and equipment, gross | 10,638 |  |  | 10,186 |  |
| Accumulated depreciation | (7,607 | ) |  | (7,091 | ) |
| Property, plant, and equipment, net | $ | 3,031 |  |  | $ | 3,095 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-19-000028:notes:151]
[same as prior period, unchanged from 0000106040-19-000009:notes:156]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-19-000028:notes:152]
[same as prior period, unchanged from 0000106040-19-000009:notes:157]

[0000106040-19-000028:notes:153]
[same as prior period, unchanged from 0000106040-19-000009:notes:158]

[0000106040-19-000028:notes:154]
[same as prior period, unchanged from 0000106040-19-000009:notes:159]

[0000106040-19-000028:notes:155]
[same as prior period, unchanged from 0000106040-19-000009:notes:160]

[0000106040-19-000028:notes:156]
[same as prior period, unchanged from 0000106040-19-000009:notes:161]

[0000106040-19-000028:notes:157]
[same as prior period, unchanged from 0000106040-19-000009:notes:162]

[0000106040-19-000028:notes:158]
[same as prior period, unchanged from 0000106040-19-000009:notes:163]

[0000106040-19-000028:notes:159]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 29, 2019 or the date of adoption of Topic 606.

[0000106040-19-000028:notes:160]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to selling, general and administrative expenses. Prior to the adoption of the new revenue standard, the Company’s policy was to expense all contract acquisition costs as incurred. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of and for the three and nine months ended March 29, 2019 were not material.

[0000106040-19-000028:notes:161]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of March 29, 2019 and the date of adoption of Topic 606, contract liabilities were $46 million and $120 million, respectively, and were reflected in Accrued expenses. Changes in the contract liability balance during the nine months ended March 29, 2019 include $93 million of revenue recognized during the period of which the substantial majority relates to the balance that was deferred at June 29, 2018, partially offset by payments received and billings in advance of satisfying performance obligations.

[0000106040-19-000028:notes:162]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 29, 2019 was $204 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2019, $62 million in fiscal 2020, $47 million in fiscal 2021 and $75 million thereafter.

[0000106040-19-000028:notes:163]
The Company’s top 10 customers accounted for 41% and 45% of its net revenue for the three and nine months ended March 29, 2019, respectively, and 44% and 42% of its net revenue for the three and nine months ended March 30, 2018, respectively. For the three and nine months ended March 29, 2019 and March 30, 2018, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-19-000028:notes:164]
[same as prior period, unchanged from 0000106040-19-000009:notes:169]

[0000106040-19-000028:notes:165]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 29, 2018 | $ | (19 | ) |  | $ | (21 | ) |  | $ | 1 |  |  | $ | (39 | ) |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | (8 | ) |  | (26 | ) |  | (33 | ) |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | 8 |  |  | 8 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | (1 | ) |  | 10 |  |  | 9 |  |
| Net current-period other comprehensive loss | 1 |  |  | (9 | ) |  | (8 | ) |  | (16 | ) |
| Balance at March 29, 2019 | $ | (18 | ) |  | $ | (30 | ) |  | $ | (7 | ) |  | $ | (55 | ) |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-19-000028:notes:166]
[same as prior period, unchanged from 0000106040-19-000009:notes:171]

[0000106040-19-000028:notes:167]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,824 |  |  | $ | 5,818 |  |
| In-process research and development | 72 |  |  | 80 |  |
| Accumulated amortization | (3,978 | ) |  | (3,218 | ) |
| Intangible assets, net | $ | 1,918 |  |  | $ | 2,680 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-19-000028:notes:168]
[same as prior period, unchanged from 0000106040-19-000009:notes:175]

[0000106040-19-000028:notes:169]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,122 |  |  | $ | 1,048 |  |
| Work-in-process | 955 |  |  | 878 |  |
| Finished goods | 1,363 |  |  | 1,018 |  |
| Total inventories | $ | 3,440 |  |  | $ | 2,944 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-19-000028:notes:170]
[same as prior period, unchanged from 0000106040-19-000009:notes:177]

[0000106040-19-000028:notes:171]
[same as prior period, unchanged from 0000106040-19-000009:notes:178]

[0000106040-19-000028:notes:172]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 337 |  |  | $ | 304 |  |  | $ | 318 |  |  | $ | 311 |  |
| Charges to operations | 38 |  |  | 43 |  |  | 119 |  |  | 133 |  |
| Utilization | (40 | ) |  | (37 | ) |  | (108 | ) |  | (118 | ) |
| Changes in estimate related to pre-existing warranties | (4 | ) |  | (5 | ) |  | 2 |  |  | (21 | ) |
| Warranty accrual, end of period | $ | 331 |  |  | $ | 305 |  |  | $ | 331 |  |  | $ | 305 |  |

[0000106040-19-000028:notes:173]
[same as prior period, unchanged from 0000106040-19-000009:notes:180]

[0000106040-19-000028:notes:174]
|  | March 29, 2019 |  | June 29, 2018 |
|  | (in millions) |
| Warranty accrual |  |  |  |
| Current portion | $ | 179 |  |  | $ | 168 |  |
| Long-term portion | 152 |  |  | 150 |  |
| Total warranty accrual | $ | 331 |  |  | $ | 318 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-19-000028:notes:175]
The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 29, 2019:

[0000106040-19-000028:notes:176]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 36 |  |  | $ | 7 |  |  | $ | 43 |  |
| Charges | 117 |  |  | 9 |  |  | 126 |  |
| Cash payments | (76 | ) |  | (8 | ) |  | (84 | ) |
| Accrual balance at March 29, 2019 | $ | 77 |  |  | $ | 8 |  |  | $ | 85 |  |

[0000106040-19-000028:notes:177]
[same as prior period, unchanged from 0000106040-19-000009:notes:186]

[0000106040-19-000028:notes:178]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 87 |  |
| Closure of Foreign Manufacturing Facilities | 5 |  |  | — |  |  | 16 |  |  | — |  |
| Business Realignment | 71 |  |  | 8 |  |  | 126 |  |  | 31 |  |
| Total employee termination and other charges | 76 |  |  | 18 |  |  | 142 |  |  | 118 |  |
| Stock-based compensation accelerations and adjustments: |  |  |  |  |  |  |  |
| Business Realignment | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total stock-based compensation accelerations and adjustments | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Asset impairment: |  |  |  |  |  |  |  |
| Restructuring Plan 2016 | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total asset impairment | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total employee termination and other charges, and stock-based compensation accelerations and adjustments | $ | 76 |  |  | $ | 35 |  |  | $ | 142 |  |  | $ | 135 |  |

[0000106040-19-000028:notes:179]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve during the nine months ended March 29, 2019:

[0000106040-19-000028:notes:180]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 29, 2018 | $ | 56 |  |  | $ | — |  |  | $ | 56 |  |
| Charges | 7 |  |  | 9 |  |  | 16 |  |
| Cash payments | (6 | ) |  | (7 | ) |  | (13 | ) |
| Accrual balance at March 29, 2019 | $ | 57 |  |  | $ | 2 |  |  | $ | 59 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-19-000028:notes:181]
[same as prior period, unchanged from 0000106040-19-000009:notes:188]

[0000106040-19-000028:notes:182]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 29, 2018 | 4.8 |  |  | $ | 64.23 |  |  |  |  |  |
| Exercised | (0.4 | ) |  | 39.11 |  |  |  |  | $ | 7 |  |
| Canceled or expired | (0.3 | ) |  | 80.18 |  |  |  |  |  |
| Options outstanding at March 29, 2019 | 4.1 |  |  | $ | 65.07 |  |  | 3.1 |  | $ | 9 |  |
| Exercisable at March 29, 2019 | 3.2 |  |  | $ | 69.46 |  |  | 2.8 |  | $ | 7 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-19-000028:notes:183]
[same as prior period, unchanged from 0000106040-19-000009:notes:190]

[0000106040-19-000028:notes:184]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | $ | 58.31 |  |  |  |
| Granted | 6.9 |  |  | 56.01 |  |  |  |
| Vested | (6.0 | ) |  | 52.36 |  |  | $ | 345 |  |
| Forfeited | (1.1 | ) |  | 56.68 |  |  |  |
| RSUs and PSUs outstanding at March 29, 2019 | 12.4 |  |  | $ | 62.63 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-19-000028:notes:185]
[same as prior period, unchanged from 0000106040-19-000009:notes:192]

[0000106040-19-000028:notes:186]
[same as prior period, unchanged from 0000106040-19-000009:notes:193]

[0000106040-19-000028:notes:187]
Compensation cost related to unvested stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of March 29, 2019:

[0000106040-19-000028:notes:188]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 12 |  |  | 1.2 |
| RSUs and PSUs (1) | 577 |  |  | 2.5 |
| ESPP | 62 |  |  | 1.7 |
| Total unamortized compensation cost | $ | 651 |  |  |  |

[0000106040-19-000028:notes:189]
[same as prior period, unchanged from 0000106040-19-000009:notes:196]

[0000106040-19-000028:notes:190]
[same as prior period, unchanged from 0000106040-19-000009:notes:197]

[0000106040-19-000028:notes:191]
[same as prior period, unchanged from 0000106040-19-000009:notes:198]

[0000106040-19-000028:notes:192]
[same as prior period, unchanged from 0000106040-19-000009:notes:199]

[0000106040-19-000028:notes:193]
[same as prior period, unchanged from 0000106040-19-000009:notes:200]

[0000106040-19-000028:notes:194]
[same as prior period, unchanged from 0000106040-19-000009:notes:201]

[0000106040-19-000028:notes:195]
The Company’s Board of Directors previously authorized $5.00 billion for the repurchase of the Company’s common stock. On July 25, 2018, the Company’s Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. For the three months ended March 29, 2019, the Company did not make any stock repurchases. For the nine months ended March 29, 2019, the Company repurchased 0.8 million shares for a total cost of $61 million under the previous authorization and 7.6 million shares for a total cost of $502 million under the new authorization. Therefore, the Company’s stock repurchases under all stock repurchase authorizations in effect for the nine months ended March 29, 2019 totaled $563 million. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of March 29, 2019 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-19-000028:notes:196]
[same as prior period, unchanged from 0000106040-19-000009:notes:203]

[0000106040-19-000028:notes:197]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the nine months ended March 29, 2019, the Company declared aggregate cash dividends of $1.50 per share on its outstanding common stock totaling $436 million, including $146 million that was paid on April 15, 2019.

[0000106040-19-000028:notes:198]
On May 2, 2019, the Board declared a cash dividend of $0.50 per share to shareholders of record as of June 28, 2019, which will be paid on July 15, 2019. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SubsequentEventsTextBlock

[0000106040-19-000028:notes:199]
Subsequent Events

[0000106040-19-000028:notes:200]
In April 2019, the Company completed a sale and leaseback of its manufacturing facility in Fremont, California. The Company received proceeds from the sale of $115 million and expects to recognize an approximate loss of $25 million. The property is being leased back over a term of 15 years at an annual lease rate of $7 million for the first year and increasing by 3% per year thereafter. The lease includes four 5-year renewal options for the ability to extend up to 20 years.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-19-000028:notes:201]
[same as prior period, unchanged from 0000106040-19-000009:notes:205]

[0000106040-19-000028:notes:202]
[same as prior period, unchanged from 0000106040-19-000009:notes:206]

[0000106040-19-000028:notes:203]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the nine months ended March 29, 2019, the Company sold trade accounts receivable and received cash proceeds of $702 million. The discounts on the trade accounts receivable sold during the period were not material and were recorded within Other income (expense), net in the Condensed Consolidated Financial Statements. During the nine months ended March 30, 2018, the Company did not sell any trade accounts receivable.

[0000106040-19-000028:notes:204]
Goodwill

[0000106040-19-000028:notes:205]
The Company tests for impairment, at a minimum, on an annual basis or earlier where certain events or changes in circumstances indicate that goodwill may more likely than not be impaired. The Company has experienced fluctuations in the market price of its stock, which resulted in the Company’s market capitalization decreasing below book value for eleven trading days near the end of the second quarter and beginning of the third quarter of fiscal 2019. The fair value of the Company using a market capitalization approach based on the Company’s share price would include a control premium based on recent transactions that have occurred in the technology industry. This indicative fair value exceeded the Company’s book value; therefore, management did not believe that it was more likely than not that goodwill was impaired as of March 29, 2019.

[0000106040-19-000028:notes:206]
The Company’s regularly scheduled annual impairment test is performed as of the first day of its fiscal fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative assessment to determine the amount of impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. The Company is in the process of completing its annual impairment test.

[0000106040-19-000028:notes:207]
If there are significant decreases in the Company’s stock price in the future or other unfavorable factors, the Company may be required to perform a goodwill impairment assessment, which may result in the recognition of a goodwill impairment that could be material to the Consolidated Financial Statements.

[0000106040-19-000028:notes:208]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During the three and nine months ended March 29, 2019, the Company reclassified $8 million of acquired IPR&D to existing technology and commenced amortization over its estimated useful life of 2 years.

[0000106040-19-000028:notes:209]
[same as prior period, unchanged from 0000106040-19-000009:notes:211]

[0000106040-19-000028:notes:210]
[same as prior period, unchanged from 0000106040-19-000009:notes:212]

[0000106040-19-000028:notes:211]
During the three and nine months ended March 29, 2019 and March 30, 2018, the amounts reclassified out of AOCI related to derivative contracts were not material and substantially all were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-19-000028:notes:212]
[same as prior period, unchanged from 0000106040-19-000009:notes:214]

[0000106040-19-000028:notes:213]
[same as prior period, unchanged from 0000106040-19-000009:notes:215]

[0000106040-19-000028:notes:214]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company currently expects the closure to be substantially completed by the fourth quarter of fiscal 2019 and to result in total pre-tax charges of approximately $110 million. These charges are expected to consist of approximately $70 million in employee termination benefits and $40 million in asset-related, contract termination and other charges, of which $56 million were recognized in the year ended June 29, 2018. During the nine months ended March 29, 2019, the Company recognized an additional $7 million in employee termination benefits and $9 million in asset-related, contract termination and other charges.

[0000106040-19-000028:notes:215]
[same as prior period, unchanged from 0000106040-19-000009:notes:217]

[0000106040-19-000028:notes:216]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve during the nine months ended March 29, 2019:
