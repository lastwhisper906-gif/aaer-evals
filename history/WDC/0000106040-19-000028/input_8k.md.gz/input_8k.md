# WDC 8-K — 0000106040-19-000017 filed 2019-04-29

## item codes, every 8-K on or before 2019-05-07

- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2019-05-07

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-19-000017:8k_2_02:1]
EX-99.1
2
ex991-pressreleaseq3.htm
EXHIBIT 99.1

[0000106040-19-000017:8k_2_02:2]
Exhibit

[0000106040-19-000017:8k_2_02:3]
Exhibit 99.1

[0000106040-19-000017:8k_2_02:4]
FOR IMMEDIATE RELEASE:

[0000106040-19-000017:8k_2_02:5]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0000106040-19-000017:8k_2_02:6]
THIRD QUARTER FISCAL YEAR 2019

[0000106040-19-000017:8k_2_02:7]
SAN JOSE, Calif. — April 29, 2019 — Western Digital Corp. (NASDAQ: WDC) today reported revenue of $3.7 billion for its third fiscal quarter ended March 29, 2019. The operating loss was $394 million with a net loss of $581 million, or ($1.99) per share. Excluding certain non-GAAP adjustments, the company achieved non-GAAP operating income of $186 million and non-GAAP net income of $49 million, or $0.17 per share. Both the GAAP and non-GAAP results include lower of cost or market inventory charges of approximately $110 million in cost of revenue, primarily related to certain flash memory products that contain DRAM components.

[0000106040-19-000017:8k_2_02:8]
In the year-ago quarter, the company reported revenue of $5.0 billion, operating income of $914 million and net income of $61 million, or $0.20 per share. Non-GAAP operating income in the year-ago quarter was $1.3 billion and non-GAAP net income was $1.1 billion, or $3.63 per share.

[0000106040-19-000017:8k_2_02:9]
The company generated $204 million in cash from operations during the third fiscal quarter of 2019, ending with $3.8 billion of total cash, cash equivalents and available-for-sale securities. The company returned $146 million to shareholders through dividends. On February 14, 2019, the company declared a cash dividend of $0.50 per share of its common stock, which was paid to shareholders on April 15, 2019.

[0000106040-19-000017:8k_2_02:10]
“Market conditions have generally been consistent with our expectations, and while the business environment remains soft, there are initial indications of improving trends,” said Steve Milligan, chief executive officer, Western Digital.  “Our expectation for the demand environment to further improve for both flash and hard drive products for the balance of calendar 2019 is largely unchanged.  We are executing well on enhancing our product portfolio, driving technology advancements, rightsizing our factory production levels and lowering our cost and expense structure, all of which position us to emerge stronger as market conditions improve.”

[0000106040-19-000017:8k_2_02:11]
Western Digital Announces Financial Results for Third Quarter Fiscal Year 2019

[0000106040-19-000017:8k_2_02:12]
The investment community conference call to discuss these results and the company’s guidance for the fourth fiscal quarter of 2019 will be broadcast live online today at 2:00 p.m. Pacific/5:00 p.m. Eastern. The live and archived conference call/webcast, the company’s guidance for the fourth fiscal quarter and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-19-000017:8k_2_02:13]
About Western Digital

[0000106040-19-000017:8k_2_02:14]
Western Digital creates environments for data to thrive. The company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, our industry-leading solutions deliver the possibilities of data. Western Digital data-centric solutions are comprised of the Western Digital®, G-Technology™, SanDisk® and WD® brands. Financial and investor information is available on the company's Investor Relations website at investor.wdc.com.

[0000106040-19-000017:8k_2_02:15]
Forward-Looking Statements

[0000106040-19-000017:8k_2_02:16]
Western Digital Announces Financial Results for Third Quarter Fiscal Year 2019

[0000106040-19-000017:8k_2_02:17]
restructuring activities and cost saving initiatives; impact of competitive products and pricing; market acceptance and cost of commodity materials and specialized product components; actions by competitors; unexpected advances in competing technologies; our development and introduction of products based on new technologies and expansion into new data storage markets; risks associated with acquisitions, mergers and joint ventures; difficulties or delays in manufacturing; the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-Q filed with the SEC on February 5, 2019, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update these forward-looking statements to reflect new information or events.

[0000106040-19-000017:8k_2_02:18]
###

[0000106040-19-000017:8k_2_02:19]
Western Digital, the Western Digital logo, G-Technology, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-19-000017:8k_2_02:20]
WESTERN DIGITAL CORPORATION

[0000106040-19-000017:8k_2_02:21]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-19-000017:8k_2_02:22]
(in millions; unaudited; on a US GAAP basis)

[0000106040-19-000017:8k_2_02:23]
|  | Mar. 29, 2019 |  | June 29, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,682 |  |  | $ | 5,005 |  |
| Accounts receivable, net | 1,223 |  |  | 2,197 |  |
| Inventories | 3,440 |  |  | 2,944 |  |
| Other current assets | 557 |  |  | 492 |  |
| Total current assets | 8,902 |  |  | 10,638 |  |
| Property, plant and equipment, net | 3,031 |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | 2,403 |  |  | 2,105 |  |
| Goodwill | 10,075 |  |  | 10,075 |  |
| Other intangible assets, net | 1,918 |  |  | 2,680 |  |
| Other non-current assets | 584 |  |  | 642 |  |
| Total assets | $ | 26,913 |  |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,577 |  |  | $ | 2,265 |  |
| Accounts payable to related parties | 312 |  |  | 259 |  |
| Accrued expenses | 1,645 |  |  | 1,274 |  |
| Accrued compensation | 402 |  |  | 479 |  |
| Current portion of long-term debt | 276 |  |  | 179 |  |
| Total current liabilities | 4,212 |  |  | 4,456 |  |
| Long-term debt | 10,309 |  |  | 10,993 |  |
| Other liabilities | 2,178 |  |  | 2,255 |  |
| Total liabilities | 16,699 |  |  | 17,704 |  |
| Total shareholders’ equity | 10,214 |  |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 26,913 |  |  | $ | 29,235 |  |

[0000106040-19-000017:8k_2_02:24]
WESTERN DIGITAL CORPORATION

[0000106040-19-000017:8k_2_02:25]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-19-000017:8k_2_02:26]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-19-000017:8k_2_02:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | Mar. 29, 2019 |  | Mar. 30,2018 |  | Mar. 29,2019 |  | Mar. 30,2018 |
| Revenue, net | $ | 3,674 |  |  | $ | 5,013 |  |  | $ | 12,935 |  |  | $ | 15,530 |  |
| Cost of revenue | 3,095 |  |  | 3,086 |  |  | 9,648 |  |  | 9,677 |  |
| Gross profit | 579 |  |  | 1,927 |  |  | 3,287 |  |  | 5,853 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 544 |  |  | 602 |  |  | 1,659 |  |  | 1,823 |  |
| Selling, general and administrative | 353 |  |  | 376 |  |  | 1,018 |  |  | 1,121 |  |
| Employee termination, asset impairment and other charges | 76 |  |  | 35 |  |  | 142 |  |  | 135 |  |
| Total operating expenses | 973 |  |  | 1,013 |  |  | 2,819 |  |  | 3,079 |  |
| Operating income (loss) | (394 | ) |  | 914 |  |  | 468 |  |  | 2,774 |  |
| Interest and other expense, net | (83 | ) |  | (1,042 | ) |  | (281 | ) |  | (1,418 | ) |
| Income (loss) before taxes | (477 | ) |  | (128 | ) |  | 187 |  |  | 1,356 |  |
| Income tax expense (benefit) | 104 |  |  | (189 | ) |  | 744 |  |  | 1,437 |  |
| Net income (loss) | $ | (581 | ) |  | $ | 61 |  |  | $ | (557 | ) |  | $ | (81 | ) |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | (1.99 | ) |  | $ | 0.20 |  |  | $ | (1.91 | ) |  | $ | (0.27 | ) |
| Diluted | $ | (1.99 | ) |  | $ | 0.20 |  |  | $ | (1.91 | ) |  | $ | (0.27 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 292 |  |  | 298 |  |  | 291 |  |  | 296 |  |
| Diluted | 292 |  |  | 308 |  |  | 291 |  |  | 296 |  |

[0000106040-19-000017:8k_2_02:28]
WESTERN DIGITAL CORPORATION

[0000106040-19-000017:8k_2_02:29]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-19-000017:8k_2_02:30]
(in millions; unaudited; on a US GAAP basis)

[0000106040-19-000017:8k_2_02:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | Mar. 29,2019 |  | Mar. 30,2018 |  | Mar. 29,2019 |  | Mar. 30,2018 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | (581 | ) |  | $ | 61 |  |  | $ | (557 | ) |  | $ | (81 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 444 |  |  | 499 |  |  | 1,396 |  |  | 1,567 |  |
| Stock-based compensation | 84 |  |  | 103 |  |  | 242 |  |  | 299 |  |
| Deferred income taxes | (28 | ) |  | (207 | ) |  | 253 |  |  | (336 | ) |
| Loss on disposal of assets | 3 |  |  | 4 |  |  | 4 |  |  | 16 |  |
| Write-off of issuance costs and amortization of debt discounts | 9 |  |  | 185 |  |  | 28 |  |  | 208 |  |
| Cash premium on extinguishment of debt | — |  |  | 720 |  |  | — |  |  | 720 |  |
| Non-cash portion of employee termination, asset impairment and other charges | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Other non-cash operating activities, net | (18 | ) |  | (31 | ) |  | 19 |  |  | (15 | ) |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | 493 |  |  | 41 |  |  | 975 |  |  | (58 | ) |
| Inventories | (13 | ) |  | (389 | ) |  | (496 | ) |  | (324 | ) |
| Accounts payable | (293 | ) |  | 235 |  |  | (549 | ) |  | (41 | ) |
| Accounts payable to related parties | 2 |  |  | 32 |  |  | 53 |  |  | 76 |  |
| Accrued expenses | 119 |  |  | (184 | ) |  | 373 |  |  | (89 | ) |
| Accrued compensation | 56 |  |  | (15 | ) |  | (78 | ) |  | 2 |  |
| Other assets and liabilities, net | (73 | ) |  | (43 | ) |  | (285 | ) |  | 1,382 |  |
| Net cash provided by operating activities | 204 |  |  | 1,027 |  |  | 1,378 |  |  | 3,342 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (222 | ) |  | (213 | ) |  | (719 | ) |  | (619 | ) |
| Activity related to Flash Ventures, net | (92 | ) |  | (198 | ) |  | (288 | ) |  | (707 | ) |
| Acquisitions, net of cash acquired | — |  |  | — |  |  | — |  |  | (99 | ) |
| Other | (3 | ) |  | 12 |  |  | (35 | ) |  | 19 |  |
| Net cash used in investing activities | (317 | ) |  | (399 | ) |  | (1,042 | ) |  | (1,406 | ) |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | (35 | ) |  | (50 | ) |  | (43 | ) |  | (18 | ) |
| Repurchases of common stock | — |  |  | (155 | ) |  | (563 | ) |  | (155 | ) |
| Dividends paid to shareholders | (146 | ) |  | (148 | ) |  | (438 | ) |  | (443 | ) |
| Settlement of debt hedge contracts | — |  |  | — |  |  | — |  |  | 28 |  |
| Proceeds from debt, net of issuance costs | — |  |  | 8,874 |  |  | — |  |  | 11,832 |  |
| Repayment of debt | (38 | ) |  | (10,467 | ) |  | (613 | ) |  | (14,581 | ) |
| Net cash used in financing activities | (219 | ) |  | (1,946 | ) |  | (1,657 | ) |  | (3,337 | ) |
| Effect of exchange rate changes on cash | 1 |  |  | 9 |  |  | (2 | ) |  | 10 |  |
| Decrease in cash and cash equivalents | (331 | ) |  | (1,309 | ) |  | (1,323 | ) |  | (1,391 | ) |
| Cash and cash equivalents, beginning of period | 4,013 |  |  | 6,272 |  |  | 5,005 |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 3,682 |  |  | $ | 4,963 |  |  | $ | 3,682 |  |  | $ | 4,963 |  |

[0000106040-19-000017:8k_2_02:32]
WESTERN DIGITAL CORPORATION

[0000106040-19-000017:8k_2_02:33]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-19-000017:8k_2_02:34]
(in millions; unaudited)

[0000106040-19-000017:8k_2_02:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | Mar. 29,2019 |  | Mar. 30,2018 |  | Mar. 29,2019 |  | Mar. 30,2018 |
| GAAP cost of revenue | $ | 3,095 |  |  | $ | 3,086 |  |  | $ | 9,648 |  |  | $ | 9,677 |  |
| Amortization of acquired intangible assets | (188 | ) |  | (235 | ) |  | (638 | ) |  | (788 | ) |
| Stock-based compensation expense | (13 | ) |  | (11 | ) |  | (37 | ) |  | (37 | ) |
| Charges related to cost saving initiatives | — |  |  | (1 | ) |  | (7 | ) |  | 6 |  |
| Manufacturing underutilization charges | (148 | ) |  | — |  |  | (197 | ) |  | — |  |
| Non-GAAP cost of revenue | $ | 2,746 |  |  | $ | 2,839 |  |  | $ | 8,769 |  |  | $ | 8,858 |  |
| GAAP gross profit | $ | 579 |  |  | $ | 1,927 |  |  | $ | 3,287 |  |  | $ | 5,853 |  |
| Amortization of acquired intangible assets | 188 |  |  | 235 |  |  | 638 |  |  | 788 |  |
| Stock-based compensation expense | 13 |  |  | 11 |  |  | 37 |  |  | 37 |  |
| Charges related to cost saving initiatives | — |  |  | 1 |  |  | 7 |  |  | (6 | ) |
| Manufacturing underutilization charges | 148 |  |  | — |  |  | 197 |  |  | — |  |
| Non-GAAP gross profit | $ | 928 |  |  | $ | 2,174 |  |  | $ | 4,166 |  |  | $ | 6,672 |  |
| GAAP operating expenses | $ | 973 |  |  | $ | 1,013 |  |  | $ | 2,819 |  |  | $ | 3,079 |  |
| Amortization of acquired intangible assets | (41 | ) |  | (41 | ) |  | (123 | ) |  | (122 | ) |
| Stock-based compensation expense | (71 | ) |  | (91 | ) |  | (205 | ) |  | (261 | ) |
| Employee termination, asset impairment and other charges | (76 | ) |  | (35 | ) |  | (142 | ) |  | (135 | ) |
| Acquisition-related charges | — |  |  | (2 | ) |  | — |  |  | (12 | ) |
| Charges related to cost saving initiatives | (3 | ) |  | 3 |  |  | (8 | ) |  | (18 | ) |
| Other | (40 | ) |  | 3 |  |  | (41 | ) |  | 3 |  |
| Non-GAAP operating expenses | $ | 742 |  |  | $ | 850 |  |  | $ | 2,300 |  |  | $ | 2,534 |  |
| GAAP operating income (loss) | $ | (394 | ) |  | $ | 914 |  |  | $ | 468 |  |  | $ | 2,774 |  |
| Cost of revenue adjustments | 349 |  |  | 247 |  |  | 879 |  |  | 819 |  |
| Operating expense adjustments | 231 |  |  | 163 |  |  | 519 |  |  | 545 |  |
| Non-GAAP operating income | $ | 186 |  |  | $ | 1,324 |  |  | $ | 1,866 |  |  | $ | 4,138 |  |
| GAAP interest and other expense, net | $ | (83 | ) |  | $ | (1,042 | ) |  | $ | (281 | ) |  | $ | (1,418 | ) |
| Convertible debt activity, net | 7 |  |  | 3 |  |  | 20 |  |  | 3 |  |
| Debt extinguishment costs | — |  |  | 894 |  |  | — |  |  | 896 |  |
| Other | (12 | ) |  | 8 |  |  | (19 | ) |  | 2 |  |
| Non-GAAP interest and other expense, net | $ | (88 | ) |  | $ | (137 | ) |  | $ | (280 | ) |  | $ | (517 | ) |
| GAAP income tax expense (benefit) | $ | 104 |  |  | $ | (189 | ) |  | $ | 744 |  |  | $ | 1,437 |  |
| Income tax adjustments | (55 | ) |  | 259 |  |  | (537 | ) |  | (1,230 | ) |
| Non-GAAP income tax expense | $ | 49 |  |  | $ | 70 |  |  | $ | 207 |  |  | $ | 207 |  |

[0000106040-19-000017:8k_2_02:36]
WESTERN DIGITAL CORPORATION

[0000106040-19-000017:8k_2_02:37]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-19-000017:8k_2_02:38]
(in millions, except per share amounts; unaudited)

[0000106040-19-000017:8k_2_02:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | Mar. 29,2019 |  | Mar. 30,2018 |  | Mar. 29,2019 |  | Mar. 30,2018 |
| GAAP net income (loss) | $ | (581 | ) |  | $ | 61 |  |  | $ | (557 | ) |  | $ | (81 | ) |
| Amortization of acquired intangible assets | 229 |  |  | 276 |  |  | 761 |  |  | 910 |  |
| Stock-based compensation expense | 84 |  |  | 102 |  |  | 242 |  |  | 298 |  |
| Employee termination, asset impairment and other charges | 76 |  |  | 35 |  |  | 142 |  |  | 135 |  |
| Acquisition-related charges | — |  |  | 2 |  |  | — |  |  | 12 |  |
| Charges related to cost saving initiatives | 3 |  |  | (2 | ) |  | 15 |  |  | 12 |  |
| Manufacturing underutilization charges | 148 |  |  | — |  |  | 197 |  |  | — |  |
| Convertible debt activity, net | 7 |  |  | 3 |  |  | 20 |  |  | 3 |  |
| Debt extinguishment costs | — |  |  | 894 |  |  | — |  |  | 896 |  |
| Other | 28 |  |  | 5 |  |  | 22 |  |  | (1 | ) |
| Income tax adjustments | 55 |  |  | (259 | ) |  | 537 |  |  | 1,230 |  |
| Non-GAAP net income | $ | 49 |  |  | $ | 1,117 |  |  | $ | 1,379 |  |  | $ | 3,414 |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |
| GAAP | $ | (1.99 | ) |  | $ | 0.20 |  |  | $ | (1.91 | ) |  | $ | (0.27 | ) |
| Non-GAAP | $ | 0.17 |  |  | $ | 3.63 |  |  | $ | 4.67 |  |  | $ | 11.12 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |
| GAAP | 292 |  |  | 308 |  |  | 291 |  |  | 296 |  |
| Non-GAAP | 294 |  |  | 308 |  |  | 295 |  |  | 307 |  |

[0000106040-19-000017:8k_2_02:40]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth non-GAAP cost of revenue; non-GAAP gross profit; non-GAAP operating expenses; non-GAAP operating income; non-GAAP interest and other expense, net; non-GAAP income tax expense; non-GAAP net income; and non-GAAP diluted income per common share (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude the amortization of acquired intangible assets, stock-based compensation expense, employee termination, asset impairment and other charges, acquisition-related

[0000106040-19-000017:8k_2_02:41]
charges, charges related to cost saving initiatives, manufacturing underutilization charges, convertible debt activity, debt extinguishment costs, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company's results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company's performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-19-000017:8k_2_02:42]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-19-000017:8k_2_02:43]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company's acquisitions and any related impairment charges.

[0000106040-19-000017:8k_2_02:44]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company's control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company's peers, a majority of whom also exclude stock-based compensation expense from their non-GAAP results.

[0000106040-19-000017:8k_2_02:45]
Employee termination, asset impairment and other charges.  From time-to-time, in order to realign the company's operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. These charges (including any reversals of charges recorded in prior periods) are inconsistent in amount and frequency, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000017:8k_2_02:46]
Acquisition-related charges.  In connection with the company's business combinations, the company incurs expenses which it would not have otherwise incurred as part of its business operations.  These expenses include third-party professional service and legal fees, third-party integration services, severance costs, non-cash adjustments to the fair value of acquired inventory, contract termination costs, and retention bonuses.  The company may also experience other accounting impacts in connection with these transactions.  These charges and impacts are related to acquisitions, are inconsistent in amount and frequency, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000017:8k_2_02:47]
Charges related to cost saving initiatives.  In connection with the transformation of the company's business, the company has incurred charges related to cost saving initiatives which do not qualify for special accounting treatment as exit or disposal activities. These charges, which the company believes are not indicative of the underlying performance of its business, primarily relate to costs associated with rationalizing the company's channel partners or vendors, transforming the company's information systems infrastructure, integrating the company's product roadmap, and accelerated depreciation of assets.

[0000106040-19-000017:8k_2_02:48]
Manufacturing underutilization charges.  In response to the current flash business conditions, the company is reducing its wafer starts at its flash-based memory manufacturing facilities operated through its strategic partnership with Toshiba Memory Corporation (TMC).  The temporary abnormal reduction in output has resulted in flash manufacturing underutilization charges which are expensed as incurred.  These charges are inconsistent in amount and frequency, and the company believes these charges are not part of the ongoing operation of its business.

[0000106040-19-000017:8k_2_02:49]
Convertible debt activity, net. The company excludes non-cash economic interest expense associated with its convertible notes, the gains and losses on the conversion of its convertible senior notes and call option, and unrealized gains and losses related to the change in fair value of the exercise option and call option. These charges and gains and losses do not reflect the company's operating results, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000017:8k_2_02:50]
Debt extinguishment costs. From time-to-time, the company replaces its existing debt with new financing at more favorable interest rates or utilizes available capital to settle debt early, both of which generate interest savings in future periods. The company incurs debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off of any related unamortized debt issuance costs. These gains and losses do not reflect the company’s operating results, and the company believes are not indicative of the underlying performance of its business.

[0000106040-19-000017:8k_2_02:51]
Other adjustments. From time-to-time, the company sells or impairs investments or other assets which are not considered necessary to its business operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business.  The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-19-000017:8k_2_02:52]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments. The income tax adjustments include the company’s final adjustments for the tax effects of the Tax Cuts and Jobs Act allowed within the one-year measurement period that ended on December 22, 2018, as well as estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act. These adjustments are excluded because they are infrequent and the company believes that they are not indicative of the underlying performance of its business.

[0000106040-19-000017:8k_2_02:53]
___________________

[0000106040-19-000017:8k_2_02:54]
Company contacts:

[0000106040-19-000017:8k_2_02:55]
Western Digital Corp.

[0000106040-19-000017:8k_2_02:56]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Jim Pascoe |
| 949.672.9655 |  | 408.717.6999 |
| peter.andrew@wdc.com |  | jim.pascoe@wdc.com |
| investor@wdc.com |  |  |
