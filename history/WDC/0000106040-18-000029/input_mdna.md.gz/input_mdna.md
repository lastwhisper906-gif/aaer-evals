# WDC MD&A — 0000106040-18-000029


## mdna

[0000106040-18-000029:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Conditions and Results of Operations |

[0000106040-18-000029:mdna:2]
Our Company

[0000106040-18-000029:mdna:3]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. Our broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. We also generate license and royalty revenue related to our intellectual property (“IP”), which is included in each of these three categories.

[0000106040-18-000029:mdna:4]
Key Developments

[0000106040-18-000029:mdna:5]
Debt Facilities

[0000106040-18-000029:mdna:6]
During the year ended June 29, 2018, we entered into new debt facilities, amended our existing credit agreement, increased our revolving credit facility, and repaid higher rate debt. These actions, along with scheduled principal payments, reduced the aggregate principal amount of our debt by $1.98 billion since the beginning of the fiscal year and reduced our overall interest cost, extended the tenor of our debt and provided additional flexible capacity to meet our financing needs. The financing arrangement activities were as follows in the year ended June 29, 2018:

[0000106040-18-000029:mdna:7]
| • | In November 2017, we settled our then-existing U.S. dollar-denominated term B-2 loans (“U.S. Term Loan B-2”) with the proceeds of a new issuance of a $2.96 billion U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) at an interest rate lower than our U.S. Term Loan B-2 tranche. In February 2018, we made a voluntary partial prepayment of $500 million of the U.S. Term Loan B-3 using drawings from the Revolving Facility (as defined below), and in May 2018, we settled our then-existing U.S. dollar-denominated term B-3 loans with the proceeds of a new issuance of a $2.46 billion U.S. dollar-denominated term loan (“U.S. Term Loan B-4”) at an interest rate lower than our U.S. Term Loan B-3 tranche. |

[0000106040-18-000029:mdna:8]
| • | In November 2017, we made a voluntary prepayment of the full principal amounts of our Euro-denominated term B-2 loans (“Euro Term Loan B-2”) using cash on hand. |

[0000106040-18-000029:mdna:9]
| • | In February 2018, we issued $2.3 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Senior Unsecured Notes”). |

[0000106040-18-000029:mdna:10]
| • | In February 2018, we issued a $1.1 billion aggregate principal amount of 1.50% convertible senior notes due 2024 (the “2024 Convertible Notes”). |

[0000106040-18-000029:mdna:11]
| • | In February 2018, we entered into an amendment to the credit agreement entered into on April 29, 2016 to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced our prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on our corporate credit ratings, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. We used a portion of the proceeds of the Term Loan A-1 to repay in full our previous variable interest rate Term Loan A maturing 2021 in the principal amount of $4.02 billion. |

[0000106040-18-000029:mdna:12]
| • | In February and March 2018, we completed the redemption of all of our outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of our outstanding 10.500% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Redeemed Notes”). |

[0000106040-18-000029:mdna:13]
| • | In connection with the settlements of the various debt instruments described above during 2018, we incurred aggregate losses on extinguishment of debt of $899 million for the year ended June 29, 2018, consisting of $720 million of “make-whole” premiums and $179 million of unamortized issuance costs. |

[0000106040-18-000029:mdna:14]
For additional information regarding our debt facilities, see Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:15]
41

[0000106040-18-000029:mdna:16]
Tax Reform

[0000106040-18-000029:mdna:17]
On December 22, 2017, the President of the United States of America signed the Tax Cuts and Jobs Act (the “2017 Act”), which includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21% and a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred, and creates new taxes on certain foreign earnings. As a result of the 2017 Act, we have made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.57 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $65 million related to the re-measurement of deferred tax assets and liabilities for the year ended June 29, 2018. For additional information regarding the 2017 Act, see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K. See also the discussion in “Results of Operations - Income Tax Expense” and “Liquidity and Capital Resources” below for information regarding the impact of the 2017 Act on our financial condition, results of operations and cash flows.

[0000106040-18-000029:mdna:18]
Closure of Foreign Manufacturing Facility

[0000106040-18-000029:mdna:19]
In July 2018, we announced the closing of our manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce manufacturing costs and consolidate hard disk drive (“HDD”) operations into Thailand. We expect the closure to be substantially completed by the end of the calendar year 2019 and to result in total pre-tax charges of approximately $160 million. These charges are expected to consist of approximately $85 million in employee termination benefits and $75 million in asset-related, contract termination and other charges. During the year ended June 29, 2018, we recognized $56 million in employee termination benefits within Employee termination, asset impairment and other charges in the Consolidated Statements of Operations. For additional information, see Part II, Item 8, Note 15, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:20]
42

[0000106040-18-000029:mdna:21]
Results of Operations

[0000106040-18-000029:mdna:22]
Summary Comparison of 2018, 2017 and 2016

[0000106040-18-000029:mdna:23]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-18-000029:mdna:24]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions, except percentages) |
| Revenue, net | $ | 20,647 |  |  | 100.0 | % |  | $ | 19,093 |  |  | 100.0 | % |  | $ | 12,994 |  |  | 100.0 | % |
| Cost of revenue | 12,942 |  |  | 62.7 |  |  | 13,021 |  |  | 68.2 |  |  | 9,559 |  |  | 73.6 |  |
| Gross profit | 7,705 |  |  | 37.3 |  |  | 6,072 |  |  | 31.8 |  |  | 3,435 |  |  | 26.4 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 2,400 |  |  | 11.6 |  |  | 2,441 |  |  | 12.8 |  |  | 1,627 |  |  | 12.5 |  |
| Selling, general and administrative | 1,473 |  |  | 7.1 |  |  | 1,445 |  |  | 7.6 |  |  | 997 |  |  | 7.7 |  |
| Employee termination, asset impairment, and other charges | 215 |  |  | 1.0 |  |  | 232 |  |  | 1.2 |  |  | 345 |  |  | 2.7 |  |
| Total operating expenses | 4,088 |  |  | 19.8 |  |  | 4,118 |  |  | 21.6 |  |  | 2,969 |  |  | 22.8 |  |
| Operating income | 3,617 |  |  | 17.5 |  |  | 1,954 |  |  | 10.2 |  |  | 466 |  |  | 3.6 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 60 |  |  | 0.3 |  |  | 26 |  |  | 0.1 |  |  | 26 |  |  | 0.2 |  |
| Interest expense | (676 | ) |  | (3.3 | ) |  | (847 | ) |  | (4.4 | ) |  | (266 | ) |  | (2.0 | ) |
| Other expense, net | (916 | ) |  | (4.4 | ) |  | (364 | ) |  | (1.9 | ) |  | (73 | ) |  | (0.6 | ) |
| Total interest and other expense, net | (1,532 | ) |  | (7.4 | ) |  | (1,185 | ) |  | (6.2 | ) |  | (313 | ) |  | (2.4 | ) |
| Income before taxes | 2,085 |  |  | 10.1 |  |  | 769 |  |  | 4.0 |  |  | 153 |  |  | 1.2 |  |
| Income tax expense (benefit) | 1,410 |  |  | 6.8 |  |  | 372 |  |  | 1.9 |  |  | (89 | ) |  | (0.7 | ) |
| Net income | $ | 675 |  |  | 3.3 |  |  | $ | 397 |  |  | 2.1 |  |  | $ | 242 |  |  | 1.9 |  |

[0000106040-18-000029:mdna:25]
| (1) | Percentages may not total due to rounding. |

[0000106040-18-000029:mdna:26]
The following table sets forth, for the periods presented, summary information regarding net revenues by geography and end market:

[0000106040-18-000029:mdna:27]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 20,647 |  |  | $ | 19,093 |  |  | $ | 12,994 |  |
| Revenues by Geography (%) |  |  |  |  |  |
| Americas | 27 | % |  | 27 | % |  | 32 | % |
| Europe, Middle East and Africa | 19 |  |  | 17 |  |  | 21 |  |
| Asia | 54 |  |  | 56 |  |  | 47 |  |
| Revenues by End Market (%) |  |  |  |  |  |
| Client Devices | 49 | % |  | 50 | % |  | 48 | % |
| Data Center Devices & Solutions | 29 |  |  | 29 |  |  | 38 |  |
| Client Solutions | 22 |  |  | 21 |  |  | 14 |  |
| Exabytes Shipped | 389 |  |  | 313 |  |  | 262 |  |

[0000106040-18-000029:mdna:28]
For each of 2018, 2017, and 2016, no single customer accounted for 10% or more of our net revenue. For 2018, 2017, and 2016, our top 10 customers accounted for 42%, 36% and 43% of our net revenue, respectively.

[0000106040-18-000029:mdna:29]
Fiscal Year 2018 Net Revenue and Gross Margin Compared to Fiscal Year 2017 Net Revenue and Gross Margin

[0000106040-18-000029:mdna:30]
Net Revenue.  Net revenue increased $1.55 billion, or 8%, in 2018 compared to 2017, driven by increases in all end markets. Client Devices revenue for the year ended June 29, 2018 increased 6% year over year, primarily driven by growth in embedded flash products offset by client compute HDD devices. Our revenue for Data Center Devices and Solutions for the year ended June 29, 2018 increased 10% year over year, driven primarily by a significant increase in sales from our capacity enterprise HDD, partially offset by our expected lower sales of performance enterprise HDDs. Client Solutions revenue for the year ended June 29, 2018 increased 10% year over year, reflecting growth in both retail flash and HDD products.

[0000106040-18-000029:mdna:31]
Changes in the net revenue by geography generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-18-000029:mdna:32]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2018, 2017 and 2016, these programs represented 12%, 12% and 13% of gross revenues, respectively. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-18-000029:mdna:33]
Gross Profit and Gross Margin.  Gross profit increased $1.63 billion, or 27%, in 2018 compared to 2017, primarily due to the increase in revenue and improvement in our gross margin. The improvement in our gross margin for the year ended June 29, 2018 was primarily due to a favorable demand environment for flash-based products, a higher mix of revenue from sales of flash-based products and capacity enterprise devices; and improvements in our production costs from technology transitions. In addition, gross profit was impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $1.06 billion, or 5.2%, of revenue, in 2018, compared to $1.14 billion, or 6.0%, of revenue, in 2017.

[0000106040-18-000029:mdna:34]
The flash industry is characterized by cyclicality as it responds to variations in customers’ demand for products and expands or manages production capacity to meet that demand. The favorable demand environment for flash-based products experienced by the industry for the last several quarters is beginning to normalize as technology conversions are maturing and manufacturing yields are improving, thus increasing flash supply. As a result, we expect our gross margins to decline in fiscal 2019 compared to fiscal 2018 due to expected declines in the average selling price per gigabyte of flash memory as supply grows to meet demand.

[0000106040-18-000029:mdna:35]
Fiscal Year 2017 Net Revenue and Gross Margin Compared to Fiscal Year 2016 Net Revenue and Gross Margin

[0000106040-18-000029:mdna:36]
Net Revenue. Net revenue increased $6.10 billion, or 47%, as compared to 2016, primarily due to a full year of revenue from the sale of flash-based products following the acquisition of SanDisk Corporation (“SanDisk”) in May 2016 (the “Merger”), compared to a partial year of such revenue in the prior year. This increase was partially offset by lower revenue related to lower PC and enterprise HDD shipments. Changes in the mix of net revenue by end market for 2017, as compared to 2016, reflect the full year increase in revenues from the Merger which has resulted in comparatively higher revenue in Client Devices and Client Solutions than our pre-acquisition business.

[0000106040-18-000029:mdna:37]
Changes in the mix of net revenue by geography for 2017, as compared to 2016, reflect the additional revenues from the Merger which has resulted in comparatively higher revenue in Asia than our pre-acquisition business.

[0000106040-18-000029:mdna:38]
Gross Profit and Gross Margin. Gross profit increased $2.64 billion, or 77%, in 2017, as compared to 2016, primarily due to the increase in revenue mentioned above. In addition, gross profit for 2017 was impacted by amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, stock-based compensation and acquisition related charges, which aggregated $1.14 billion, or 6.0% of revenue, for 2017, and $375 million, or 2.9% of revenue, for 2016. Gross margin increased to 31.8% for 2017, as compared to 26.4% for 2016. The increase in gross margin was primarily due to sales of flash-based products following the Merger, as such products have comparatively higher gross margins than our pre-acquisition products, cost improvements across all products driven by manufacturing integration activities and cost improvements as flash-based technology transitions to more cost efficient designs.

[0000106040-18-000029:mdna:39]
44

[0000106040-18-000029:mdna:40]
Operating Expenses

[0000106040-18-000029:mdna:41]
Fiscal Year 2018 Operating Expenses Compared to Fiscal Year 2017 Operating Expenses

[0000106040-18-000029:mdna:42]
Research and development (“R&D”) expense decreased $41 million, or 2%, in 2018 compared to 2017, primarily due to our cost saving initiatives and lower variable compensation expense, partially offset by further investments in flash technologies. In addition, fiscal year 2018 included aggregate charges of $179 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges compared to $199 million in 2017.

[0000106040-18-000029:mdna:43]
Selling, general and administrative (“SG&A”) expense increased $28 million, or 2%, in 2018 compared to 2017, primarily due to operating expenses from recent acquisitions and higher consulting services, partially offset by lower variable compensation expense and lower charges related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other charges aggregating to $340 million in 2018 compared to $404 million in 2017.

[0000106040-18-000029:mdna:44]
Employee termination, asset impairment and other charges was $215 million in 2018, a decrease of $17 million, or 7%, from 2017. The decrease is related to our progress toward completion of our integration restructuring plan, partially offset by the announced closure of our foreign manufacturing facility. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 15, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:45]
Fiscal Year 2017 Operating Expenses Compared to Fiscal Year 2016 Operating Expenses

[0000106040-18-000029:mdna:46]
R&D expense increased $814 million, or 50%, in 2017 compared to 2016, primarily due to the Merger and continued development of flash-based technology. Fiscal year 2017 also included aggregate charges of $199 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $106 million in 2016 related to such charges.

[0000106040-18-000029:mdna:47]
SG&A expense increased $448 million, or 45%, in 2017 compared to 2016, primarily due to the Merger. Fiscal year 2017 also included aggregate charges of $404 million related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $379 million in 2016 related to such charges.

[0000106040-18-000029:mdna:48]
Employee termination, asset impairment and other charges was $232 million in 2017, a decrease of $113 million, or 33%, from 2016. These charges in 2017 primarily related to further actions under the Restructuring Plan 2016 associated with the integration and business realignment of substantial portions of our business. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 15, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:49]
Interest and Other Income (Expense)

[0000106040-18-000029:mdna:50]
Fiscal Year 2018 Interest and Other Expense, Net Compared to Fiscal Year 2017 Interest and Other Expense, Net

[0000106040-18-000029:mdna:51]
Total interest and other expense, net increased $347 million in 2018, primarily due to losses on extinguishment of debt of $899 million in 2018 compared to $274 million in 2017. These losses were partially offset by lower interest expense resulting from reductions in the principal amount of debt and lower interest rates, lower impairment charges related to our cost-method investments, and higher interest income due to increased rates of return on investment (for additional information, see Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K) and impairment charges related to our cost-method investments.

[0000106040-18-000029:mdna:52]
Fiscal Year 2017 Interest and Other Expense, Net Compared to Fiscal Year 2016 Interest and Other Expense, Net

[0000106040-18-000029:mdna:53]
Total interest and other expense, net increased $872 million in 2017, primarily due to a full year of interest expense in 2017 resulting from the additional debt issued in connection with the Merger compared to only a partial year of such expense in 2016, as well as losses on the settlements of certain of our term loans and impairment charges related to our cost-method investments.

[0000106040-18-000029:mdna:54]
Income Tax Expense (Benefit)

[0000106040-18-000029:mdna:55]
The following table sets forth income tax information from our Consolidated Statement of Operations by dollar and effective tax rate:

[0000106040-18-000029:mdna:56]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions, except percentages) |
| Income before taxes | $ | 2,085 |  |  | $ | 769 |  |  | $ | 153 |  |
| Income tax expense (benefit) | 1,410 |  |  | 372 |  |  | (89 | ) |
| Effective tax rate | 68 | % |  | 48 | % |  | (58 | )% |

[0000106040-18-000029:mdna:57]
Under the 2017 Act, the U.S. federal corporate tax rate is reduced from 35% to 21% and is effective January 1, 2018, resulting in the use of an estimated annual effective tax rate of approximately 28% for our U.S. federal corporate tax rate for fiscal year 2018. For fiscal year 2019 and beyond, we will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000029:mdna:58]
Consistent with applicable Securities and Exchange Commission (“SEC”) guidance, we made a reasonable estimate of the effects on our existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and have recognized a provisional income tax expense of $1.57 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $65 million related to the re-measurement of deferred tax assets and liabilities for the year ended June 29, 2018. For other elements of tax expense noted in Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K, or where we have not made an election, we have not been able to make a reasonable estimate and continue to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As we finalize the accounting for the tax effects of the enactment of the 2017 Act during a one-year measurement period permitted by applicable SEC guidance, we expect to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000029:mdna:59]
The primary drivers for the difference between the effective tax rate for the year ended June 29, 2018 and the blended U.S. Federal statutory rate of 28% are provisional taxes recognized as a result of the 2017 Act and an increase to the valuation allowance for net operating loss carryforwards from restructuring activities, which are partially offset by the 2018 generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expired or will expire at various dates during fiscal years 2018 through 2030.

[0000106040-18-000029:mdna:60]
The primary drivers for the difference between the effective tax rate for the year ended June 30, 2017 and the U.S. Federal statutory rate of 35% are taxes related to the integration of SanDisk and an increase in the valuation allowance for both acquired tax attributes and net operating loss carryforwards from restructuring activities, which are partially offset by the 2017 generation of tax credits and foreign income taxed at lower rates due primarily to tax holidays in Malaysia, Philippines, Singapore and Thailand.

[0000106040-18-000029:mdna:61]
The primary drivers for the difference between the effective tax rate for the year ended July 1, 2016 and the U.S. Federal statutory rate of 35% are the 2016 generation of tax credits and foreign income taxed at lower rates due primarily to tax holidays in Malaysia, Philippines, Singapore and Thailand.

[0000106040-18-000029:mdna:62]
The 2017 Act is expected to have an unfavorable impact on our effective tax rate for fiscal year 2018 due to the mandatory deemed repatriation tax offset in part by the re-measurement of deferred taxes and the reduction in the corporate tax rate.  In future years, certain additional provisions of the 2017 Act, such as a minimum tax on foreign earnings, will also apply to us and, as a result, we generally expect our effective tax rate to increase from the rate expected for fiscal year 2018 (excluding the mandatory deemed repatriation tax and the re-measurement of deferred taxes). Our estimate of the effective tax rate increase is subject to our assertion as to whether foreign undistributed earnings are indefinitely reinvested and to other calculations and elections during the measurement period.  Our total tax expense in future fiscal years will also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-18-000029:mdna:63]
For additional information regarding income tax expense (benefit), see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:64]
Liquidity and Capital Resources

[0000106040-18-000029:mdna:65]
The following table summarizes our statements of cash flows:

[0000106040-18-000029:mdna:66]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 4,205 |  |  | $ | 3,437 |  |  | $ | 1,983 |  |
| Investing activities | (1,655 | ) |  | (636 | ) |  | (9,608 | ) |
| Financing activities | (3,900 | ) |  | (4,595 | ) |  | 10,751 |  |
| Effect of exchange rate changes on cash | 1 |  |  | (3 | ) |  | 1 |  |
| Net (decrease) increase in cash and cash equivalents | $ | (1,349 | ) |  | $ | (1,797 | ) |  | $ | 3,127 |  |

[0000106040-18-000029:mdna:67]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, stock repurchases, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:68]
During 2019, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to our Flash Ventures joint venture with Toshiba Memory Corporation to be approximately $1.50 billion to $1.90 billion. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-18-000029:mdna:69]
Pursuant to the 2017 Act, we are required to pay a one-time deemed repatriation tax related to the undistributed earnings of our foreign subsidiaries.  For 2018, we recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.57 billion, which is payable over an 8-year period as further discussed below under “Short and Long-term Liquidity-Contractual Obligations and Commitments.” The provisional amount included in the Consolidated Financial Statements may change when we finalize the calculation of our post-1986 foreign earnings and profits that were previously deferred from U.S. income taxes and the amount of foreign earnings held in cash or other specified assets.  For additional information regarding our total tax liability for the mandatory repatriation tax, see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:70]
A total of $4.15 billion and $4.99 billion of our cash and cash equivalents was held outside of the U.S. as of June 29, 2018 and June 30, 2017, respectively. Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., we continue to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires us to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the U.S. deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the current tax expense is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, our plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings.  In the event we determine not to continue to assert the permanent reinvestment of part or all of our foreign undistributed earnings, such a determination could result in the accrual and payment of additional federal, foreign, state and local taxes.

[0000106040-18-000029:mdna:71]
Operating Activities

[0000106040-18-000029:mdna:72]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash provided by changes in other operating assets and liabilities was $486 million for 2018, as compared to net cash provided by changes in other operating assets and liabilities of $91 million for 2017. The increase in cash provided by changes in other operating assets and liabilities in 2018 primarily reflects the payable recorded for the mandatory repatriation tax as described in the Tax Reform section of Key Developments above. Changes in our other operating assets and liabilities are also largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-18-000029:mdna:73]
47

[0000106040-18-000029:mdna:74]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in days) |
| Days sales outstanding | 39 |  | 37 |  | 41 |
| Days in inventory | 83 |  | 65 |  | 81 |
| Days payables outstanding | (71) |  | (66) |  | (78) |
| Cash conversion cycle | 51 |  | 36 |  | 44 |

[0000106040-18-000029:mdna:75]
Changes in days sales outstanding (“DSOs”) are generally due to the linearity of shipments. Changes in days in inventory (“DIOs”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPOs”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-18-000029:mdna:76]
For 2018, DSO increased by 2 days over the prior year, primarily reflecting the timing of shipments and customer receipts. DIO increased by 18 days over the prior year, primarily reflecting increases in flash inventory and an increase in HDD inventory due to ongoing hard drive manufacturing transformation activities. The decrease in DPO primarily reflects the increased production volume and timing of vendor payments.

[0000106040-18-000029:mdna:77]
The working capital metrics in 2016 were notably impacted by the inclusion of SanDisk’s accounts receivable, inventory and accounts payable balances as of July 1, 2016, but only including SanDisk’s revenue and cost of sales following the Merger. The Merger inflated DSO, DIO and DPO by 12 days, 32 days, and 14 days, respectively. Excluding the impact of the Merger in 2016, DSO in 2017 increased by 8 days over 2016, primarily reflecting timing of customer receipts in the prior year. Excluding the impact of the Merger in 2016, DIO in 2017 increased by 16 days over 2016. The increase in DIO primarily reflects short-term build-up of inventory to maintain supply as we close certain facilities and transition production. Excluding the impact of the Merger in 2016, DPO in 2017 increased by 2 days over 2016, primarily reflecting routine variations in timing of purchases and payments during the period.

[0000106040-18-000029:mdna:78]
Investing Activities

[0000106040-18-000029:mdna:79]
During 2018, net cash used in investing activities primarily consisted of $835 million of capital expenditures, a net $742 million increase in notes receivable issuances to Flash Ventures to fund its capital expansion, and $100 million for acquisitions. Net cash used in investing activities for 2017 primarily consisted of $578 million of capital expenditures and a $277 million net increase in notes receivable issuances to and investments in Flash Ventures, partially offset by a net reduction of our available for sale securities of $230 million. During 2016, net cash used in investing activities primarily consisted of $9.84 billion related to the Merger, net of cash acquired, $584 million of capital expenditures, $90 million net increase in notes receivable to Flash Ventures and a net $76 million of other investing activities, partially offset by $977 million of proceeds from a net decrease in investments and sales of marketable securities.

[0000106040-18-000029:mdna:80]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-18-000029:mdna:81]
48

[0000106040-18-000029:mdna:82]
Financing Activities

[0000106040-18-000029:mdna:83]
During 2018, net cash used in financing activities primarily consisted of $17.07 billion in debt repayments, $593 million to pay dividends on our common stock and $591 million of share repurchases, partially offset by net proceeds of $14.28 billion from debt issuances and draws under our Revolving Facility. During 2017, net cash used in financing activities primarily consisted of $11.70 billion to repay debt, $574 million to pay dividends on our common stock and $492 million to settle convertible debt, partially offset by $7.90 billion of proceeds from debt, net of issuance costs, a net $230 million provided by employee stock plans and $61 million of proceeds from call options. During 2016, net cash provided by financing activities consisted of $16.58 billion of proceeds from debt, net of issuance costs, $409 million of proceeds from call options and a net $74 million provided by employee stock plans, offset by a net $2.61 billion to settle convertible debt, $2.57 billion to repay debt and our prior revolving credit facility, $613 million for payment upon settlement of warrants, $464 million to pay dividends on our common stock and $60 million to repurchase shares of our common stock.

[0000106040-18-000029:mdna:84]
Off-Balance Sheet Arrangements

[0000106040-18-000029:mdna:85]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:86]
Short and Long-term Liquidity

[0000106040-18-000029:mdna:87]
Contractual Obligations and Commitments

[0000106040-18-000029:mdna:88]
The following is a summary of our known contractual cash obligations and commercial commitments as of June 29, 2018:

[0000106040-18-000029:mdna:89]
|  | Total |  | 1 Year (2019) |  | 2-3 Years (2020-2021) |  | 4-5 Years (2022-2023) |  | More than 5 Years (Beyond 2023) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 11,375 |  |  | $ | 179 |  |  | $ | 589 |  |  | $ | 7,207 |  |  | $ | 3,400 |  |
| Interest on debt | 2,323 |  |  | 425 |  |  | 835 |  |  | 719 |  |  | 344 |  |
| Flash Ventures and other related commitments(2) | 8,298 |  |  | 3,637 |  |  | 2,749 |  |  | 1,603 |  |  | 309 |  |
| Operating leases | 190 |  |  | 53 |  |  | 80 |  |  | 37 |  |  | 20 |  |
| Purchase obligations | 3,179 |  |  | 2,540 |  |  | 319 |  |  | 320 |  |  | — |  |
| Mandatory Repatriation Tax | 1,566 |  |  | 131 |  |  | 255 |  |  | 248 |  |  | 932 |  |
| Total | $ | 26,931 |  |  | $ | 6,965 |  |  | $ | 4,827 |  |  | $ | 10,134 |  |  | $ | 5,005 |  |

[0000106040-18-000029:mdna:90]
| (1) | Principal portion of debt, excluding discounts and issuance costs. |

[0000106040-18-000029:mdna:91]
| (2) | Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and reimbursement for other committed expenses, including R&D. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments. |

[0000106040-18-000029:mdna:92]
Debt

[0000106040-18-000029:mdna:93]
See Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K for information regarding our indebtedness, including information about new borrowings and repayments, increased availability under our Revolving Facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness.

[0000106040-18-000029:mdna:94]
49

[0000106040-18-000029:mdna:95]
Flash Ventures

[0000106040-18-000029:mdna:96]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of June 29, 2018, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8, Note 9, Commitments, Contingencies and Related Parties, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K for information regarding Flash Ventures.

[0000106040-18-000029:mdna:97]
Purchase Obligations

[0000106040-18-000029:mdna:98]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. In addition, we have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. The estimated related minimum purchase requirements are included in “Purchase obligations” in the table above. We have also entered into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-18-000029:mdna:99]
Mandatory Repatriation Tax

[0000106040-18-000029:mdna:100]
The following is a summary of our estimated provisional mandatory deemed repatriation tax obligations that are payable in the following fiscal years ending (in millions):

[0000106040-18-000029:mdna:101]
| June 28, 2019 |  | $ | 131 |  |
| July 3, 2020 |  | 131 |  |
| July 2, 2021 |  | 124 |  |
| July 1, 2022 |  | 124 |  |
| June 30, 2023 |  | 124 |  |
| June 28, 2024 |  | 233 |  |
| June 27, 2025 |  | 311 |  |
| July 3, 2026 |  | 388 |  |
| Total |  | $ | 1,566 |  |

[0000106040-18-000029:mdna:102]
The 2017 Act allows for the provisional mandatory deemed repatriation tax of $1.57 billion to be payable over an 8-year period without interest. The payments are due with 8% of the tax to be paid in each of the first five years, 15% in the 6th year, 20% in the 7th year, and 25% in the 8th year. For additional information regarding our provisional estimate of the total tax liability for the mandatory repatriation tax, see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:103]
Unrecognized Tax Benefits

[0000106040-18-000029:mdna:104]
As of June 29, 2018, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $551 million. Accrued interest and penalties related to unrecognized tax benefits as of June 29, 2018 was approximately $110 million. Of these amounts, approximately $508 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part II, Item 8, Note 13, Income Tax Expense (Benefit), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:105]
50

[0000106040-18-000029:mdna:106]
Interest Rate Swap

[0000106040-18-000029:mdna:107]
We have entered into interest rate swap agreements to moderate our exposure to fluctuations in interest rates underlying our variable rate debt. For a description of our current interest rate swaps, see Part II, Item 7A, Quantitative and Qualitative Disclosures About Market Risk and Part II, Item 8, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:108]
Foreign Exchange Contracts

[0000106040-18-000029:mdna:109]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 7A, Quantitative and Qualitative Disclosures About Market Risk and Part II, Item 8, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:110]
Indemnifications

[0000106040-18-000029:mdna:111]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-18-000029:mdna:112]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-18-000029:mdna:113]
Stock Repurchase Program

[0000106040-18-000029:mdna:114]
Our Board of Directors previously authorized $5.00 billion for the repurchase of our common stock. In 2018, we repurchased 7.1 million shares for a total cost of $591 million. Subsequent to June 29, 2018 and through July 25, 2018, we repurchased an additional 0.8 million shares for a total cost of $61 million. On July 25, 2018, our Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows. Subsequent to July 25, 2018 and through August 22, 2018, we repurchased an additional 5.9 million shares for a total cost of $404 million under this new program.

[0000106040-18-000029:mdna:115]
Cash Dividend

[0000106040-18-000029:mdna:116]
Since the first quarter of 2013, we have issued a quarterly cash dividend. During the year ended June 29, 2018, we declared aggregate cash dividends of $2.00 per share of our common stock totaling $592 million. On May 2, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of June 29, 2018, which aggregated $148 million and was paid on July 16, 2018. On August 1, 2018, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of September 28, 2018, which will be paid on October 15, 2018. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-18-000029:mdna:117]
Recent Accounting Pronouncements

[0000106040-18-000029:mdna:118]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:119]
51

[0000106040-18-000029:mdna:120]
Critical Accounting Policies and Estimates

[0000106040-18-000029:mdna:121]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to Consolidated Financial Statements may be material.

[0000106040-18-000029:mdna:122]
Revenue

[0000106040-18-000029:mdna:123]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return and we provide resellers and OEMs with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection and/or returns until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for our products or market conditions differ from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Total sales incentive and marketing programs have ranged from 12% to 13% of gross revenue and adjustments to revenue due to changes in accruals for these programs related to revenue reported in prior periods have generally averaged less than 1% of gross revenue over the last three fiscal years.

[0000106040-18-000029:mdna:124]
We establish provisions against revenue and cost of revenue for sales returns in the same period that the related revenue is recognized. We base these provisions on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results

[0000106040-18-000029:mdna:125]
Inventories

[0000106040-18-000029:mdna:126]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-18-000029:mdna:127]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-18-000029:mdna:128]
Litigation and Other Contingencies

[0000106040-18-000029:mdna:129]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. For additional information, see Part II, Item 8, Note 16, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:mdna:130]
Income Taxes

[0000106040-18-000029:mdna:131]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized.

[0000106040-18-000029:mdna:132]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-18-000029:mdna:133]
Goodwill and Other Long-Lived Assets

[0000106040-18-000029:mdna:134]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We use qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to perform a quantitative approach to determine the amount of impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations.

[0000106040-18-000029:mdna:135]
In-process research and development (“IPR&D”) is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated R&D effort. During the development period, we conduct an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, the impact of the economic environment on us and our customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-18-000029:mdna:136]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.
