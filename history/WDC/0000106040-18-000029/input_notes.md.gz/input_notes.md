# WDC notes — 0000106040-18-000029


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000106040-18-000029:notes:1]
dvertising costs are expensed as incurred and amounted to $112 million, $89 million and $60 million in 2018, 2017 and 2016, respectively. These expenses are included in Selling, general and administrative (“SG&A”) in the Consolidated Statements of Operations.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000106040-18-000029:notes:2]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000106040-18-000029:notes:3]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-18-000029:notes:4]
The Company’s total cash, cash equivalents and available-for-sale securities was as follows:

[0000106040-18-000029:notes:5]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 5,005 |  |  | $ | 6,354 |  |
| Short-term available-for-sale securities (included within Other current assets) | 23 |  |  | 24 |  |
| Long-term available-for-sale securities (included within Other non-current assets) | 93 |  |  | 94 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 5,121 |  |  | $ | 6,472 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-18-000029:notes:6]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan:

[0000106040-18-000029:notes:7]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Benefit obligation at beginning of period | $ | 249 |  |  | $ | 326 |  |  | $ | 231 |  |
| Service cost | 6 |  |  | 8 |  |  | 8 |  |
| Interest cost | 2 |  |  | 1 |  |  | 3 |  |
| Actuarial loss (gain) | 9 |  |  | (22 | ) |  | 52 |  |
| Benefits paid | (9 | ) |  | (30 | ) |  | (16 | ) |
| Settlement/Curtailment | — |  |  | (6 | ) |  | (1 | ) |
| Non-U.S. currency movement | 3 |  |  | (28 | ) |  | 49 |  |
| Benefit obligation at end of period | $ | 260 |  |  | $ | 249 |  |  | $ | 326 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | $ | 189 |  |  | $ | 212 |  |  | $ | 185 |  |
| Actual return on plan assets | 8 |  |  | 15 |  |  | (14 | ) |
| Employer contributions | 10 |  |  | 10 |  |  | 20 |  |
| Benefits paid | (9 | ) |  | (30 | ) |  | (16 | ) |
| Non-U.S. currency movement | 2 |  |  | (18 | ) |  | 37 |  |
| Fair value of plan assets at end of period | $ | 200 |  |  | $ | 189 |  |  | $ | 212 |  |
| Unfunded status | $ | 60 |  |  | $ | 60 |  |  | $ | 114 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-18-000029:notes:8]
Commitments, Contingencies and Related Parties

[0000106040-18-000029:notes:9]
Flash Ventures

[0000106040-18-000029:notes:10]
The Company’s business ventures with Toshiba Memory Corporation (“TMC”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and TMC has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and TMC collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by TMC at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from TMC at cost and then resell those wafers to the Company and TMC at cost plus a markup.

[0000106040-18-000029:notes:11]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of TMC’s “Fab 3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-18-000029:notes:12]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of TMC’s “Fab 4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-18-000029:notes:13]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of TMC’s “Fab 5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Fab 5 was built in two phases of approximately equal size.

[0000106040-18-000029:notes:14]
New Fab 2. The Company has a facility agreement with TMC related to the construction and operation of TMC’s “New Fab 2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Fab 2 is primarily intended to provide additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Fab 2 started in 2016.

[0000106040-18-000029:notes:15]
Fab 6. In December 2017, the Company entered into a facility agreement with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide clean room space to continue the transition of the parties’ existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. The Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of approved Flash Ventures investments in manufacturing equipment for Fab 6.

[0000106040-18-000029:notes:16]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-18-000029:notes:17]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of June 29, 2018 and June 30, 2017:

[0000106040-18-000029:notes:18]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 767 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 48 |  |  | 119 |  |
| Notes receivable, Flash Forward | 700 |  |  | 379 |  |
| Investment in Flash Partners | 191 |  |  | 187 |  |
| Investment in Flash Alliance | 283 |  |  | 279 |  |
| Investment in Flash Forward | 116 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,105 |  |  | $ | 1,340 |  |

[0000106040-18-000029:notes:19]
During 2018 and 2017, the Company made net payments to Flash Ventures of $3.79 billion and $2.64 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-18-000029:notes:20]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-18-000029:notes:21]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments in 2018, 2017, or 2016.

[0000106040-18-000029:notes:22]
As of June 29, 2018 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $259 million and $206 million, respectively.

[0000106040-18-000029:notes:23]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 29, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-18-000029:notes:24]
|  | June 29, 2018 |
| Notes receivable | $ | 1,515 |  |
| Equity investments | 590 |  |
| Operating lease guarantees | 1,223 |  |
| Inventory and prepayments | 282 |  |
| Maximum estimable loss exposure | $ | 3,610 |  |

[0000106040-18-000029:notes:25]
As of June 29, 2018 and June 30, 2017, the Company’s retained earnings included undistributed earnings of Flash Ventures of $8 million and $5 million, respectively.

[0000106040-18-000029:notes:26]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ flash-based wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-18-000029:notes:27]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-18-000029:notes:28]
Research and Development Activities. The Company participates in common R&D activities with TMC and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-18-000029:notes:29]
Off-Balance Sheet Liabilities

[0000106040-18-000029:notes:30]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-18-000029:notes:31]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 29, 2018.

[0000106040-18-000029:notes:32]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 135 |  |  | $ | 1,223 |  |

[0000106040-18-000029:notes:33]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of June 29, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 29, 2018:

[0000106040-18-000029:notes:34]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| 2019 |  | $ | 341 |  |  | $ | 24 |  |  | $ | 365 |  |
| 2020 |  | 218 |  |  | 45 |  |  | 263 |  |
| 2021 |  | 201 |  |  | 104 |  |  | 305 |  |
| 2022 |  | 112 |  |  | 70 |  |  | 182 |  |
| 2023 |  | 38 |  |  | 28 |  |  | 66 |  |
| Thereafter |  | 5 |  |  | 37 |  |  | 42 |  |
| Total guarantee obligations |  | $ | 915 |  |  | $ | 308 |  |  | $ | 1,223 |  |

[0000106040-18-000029:notes:35]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of June 29, 2018, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-18-000029:notes:36]
Unis Venture

[0000106040-18-000029:notes:37]
In November 2015, the Company entered into an agreement with Unis to form a joint venture, referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture became operational during 2017. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture are recognized upon sell through to third-party customers. During 2018, the Company recognized less than 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in Unis Venture were not material to the Consolidated Financial Statements as of June 29, 2018 or June 30, 2017.

[0000106040-18-000029:notes:38]
Lease Commitments

[0000106040-18-000029:notes:39]
The Company leases certain facilities and equipment under long-term, non-cancelable operating leases. The Company’s operating leases consist of leased property and equipment that expire at various dates through 2030. Future minimum lease payments under operating leases that have initial non-cancelable lease terms in excess of one year at June 29, 2018 are as follows:

[0000106040-18-000029:notes:40]
|  |  | Lease Amounts |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2019 |  | $ | 53 |  |
| 2020 |  | 45 |  |
| 2021 |  | 35 |  |
| 2022 |  | 23 |  |
| 2023 |  | 14 |  |
| Thereafter |  | 20 |  |
| Total future minimum lease payments |  | $ | 190 |  |

[0000106040-18-000029:notes:41]
Net rent expense was as follows:

[0000106040-18-000029:notes:42]
|  | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| Rent expense, net | $ | 49 |  |  | $ | 56 |  |  | $ | 59 |  |

[0000106040-18-000029:notes:43]
Purchase Agreements

[0000106040-18-000029:notes:44]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term purchase agreements with various component suppliers that carry fixed volumes and pricing which obligates the Company to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components. As of June 29, 2018, the Company had the following minimum long-term purchase commitments:

[0000106040-18-000029:notes:45]
|  |  | Long-term purchase commitments |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2019 |  | $ | 135 |  |
| 2020 |  | 141 |  |
| 2021 |  | 137 |  |
| 2022 |  | 150 |  |
| 2023 and thereafter |  | 170 |  |
| Total |  | $ | 733 |  |


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000106040-18-000029:notes:46]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 16, Legal Proceedings, for additional disclosures related to the Company’s litigation.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-18-000029:notes:47]
Business Segment, Geographic Information and Concentration of Risk

[0000106040-18-000029:notes:48]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company introduced a new operating model during the fourth quarter of fiscal 2016 that incorporates the HGST, WD and SanDisk businesses. Based upon the management structure under the current operating model, the Company determined that the Company’s Chief Operating Decision Maker, its Chief Executive Officer, evaluates performance of the Company and makes decisions regarding allocation of resources based on total Company results. As a result, the Company concluded it operates in one segment, data storage devices and solutions.

[0000106040-18-000029:notes:49]
The following table summarizes the Company’s revenues by end market product category, between Client Devices (mobile, desktop, gaming and digital video hard drives, client solid-state drives (“SSD”), embedded products and wafers); Data Center Devices and Solutions (capacity and performance enterprise hard disk drives (“HDD”), enterprise SSDs, data center software and system solutions); and Client Solutions (removable products, hard drive content solutions and flash content solutions):

[0000106040-18-000029:notes:50]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Client Devices | $ | 10,108 |  |  | $ | 9,520 |  |  | $ | 6,205 |  |
| Data Center Devices & Solutions | 6,075 |  |  | 5,505 |  |  | 4,919 |  |
| Client Solutions | 4,464 |  |  | 4,068 |  |  | 1,870 |  |
| Total revenues | $ | 20,647 |  |  | $ | 19,093 |  |  | $ | 12,994 |  |

[0000106040-18-000029:notes:51]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0000106040-18-000029:notes:52]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Net revenue(1) |  |  |  |  |  |
| United States | $ | 4,640 |  |  | $ | 3,881 |  |  | $ | 3,651 |  |
| China | 4,393 |  |  | 4,271 |  |  | 2,413 |  |
| Hong Kong | 4,022 |  |  | 3,257 |  |  | 1,527 |  |
| Rest of Asia | 2,752 |  |  | 3,181 |  |  | 2,462 |  |
| Europe, Middle East and Africa | 3,858 |  |  | 3,276 |  |  | 2,664 |  |
| Other | 982 |  |  | 1,227 |  |  | 277 |  |
| Total | $ | 20,647 |  |  | $ | 19,093 |  |  | $ | 12,994 |  |

[0000106040-18-000029:notes:53]
| (1) | Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee. |

[0000106040-18-000029:notes:54]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Long-lived assets(1) |  |  |  |
| United States | $ | 1,187 |  |  | $ | 1,249 |  |
| Malaysia | 737 |  |  | 556 |  |
| China | 427 |  |  | 443 |  |
| Thailand | 349 |  |  | 392 |  |
| Rest of Asia | 336 |  |  | 345 |  |
| Europe, Middle East and Africa | 59 |  |  | 48 |  |
| Total | $ | 3,095 |  |  | $ | 3,033 |  |

[0000106040-18-000029:notes:55]
| (1) | Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located. |

[0000106040-18-000029:notes:56]
Customer Concentration and Credit Risk

[0000106040-18-000029:notes:57]
The Company sells its products to computer manufacturers, resellers and retailers throughout the world. For each of 2018, 2017 and 2016, no customer accounted for 10% or more of the Company’s net revenue. For 2018, 2017 and 2016, the Company’s top 10 customers accounted for 42%, 36%, and 43%, respectively, of the Company’s net revenue.

[0000106040-18-000029:notes:58]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of June 29, 2018, two customers, Apple, Inc. and Dell Inc., accounted for 13% and 10%, respectively, of the Company’s net accounts receivable. As of June 30, 2017, one customer, Dell Inc., accounted for 11% of the Company’s net accounts receivable. As of June 29, 2018 and June 30, 2017, the Company had net accounts receivable of $2.20 billion and $1.95 billion, respectively, and reserves for potential credit losses were not material as of each period.

[0000106040-18-000029:notes:59]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-18-000029:notes:60]
Supplier Concentration

[0000106040-18-000029:notes:61]
All of the Company’s flash memory system products require silicon wafers for the memory and controller components. The Company’s flash memory wafers are currently supplied almost entirely from Flash Ventures and the controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-18-000029:notes:62]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-18-000029:notes:63]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 675 |  |  | $ | 1,552 |  |  | $ | 2,246 |  |  | $ | (3,798 | ) |  | $ | 675 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (2 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (2 | ) |
| Foreign currency translation adjustment | 18 |  |  | 15 |  |  | 15 |  |  | (30 | ) |  | 18 |  |
| Net unrealized gain (loss) on derivative contracts and available-for-sale securities | 7 |  |  | (10 | ) |  | (6 | ) |  | 16 |  |  | 7 |  |
| Total other comprehensive income, before tax | 23 |  |  | 3 |  |  | 7 |  |  | (10 | ) |  | 23 |  |
| Income tax benefit (expense) related to items of other comprehensive income | (4 | ) |  | 1 |  |  | (1 | ) |  | — |  |  | (4 | ) |
| Other comprehensive income, net of tax | 19 |  |  | 4 |  |  | 6 |  |  | (10 | ) |  | 19 |  |
| Total comprehensive income | $ | 694 |  |  | $ | 1,556 |  |  | $ | 2,252 |  |  | $ | (3,808 | ) |  | $ | 694 |  |

[0000106040-18-000029:notes:64]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 39 |  |  | 39 |  |  | 39 |  |  | (78 | ) |  | 39 |  |
| Foreign currency translation adjustment | (115 | ) |  | (113 | ) |  | (136 | ) |  | 249 |  |  | (115 | ) |
| Net unrealized gain (loss) on derivative contracts and available-for-sale securities | (75 | ) |  | (75 | ) |  | (73 | ) |  | 148 |  |  | (75 | ) |
| Total other comprehensive loss, before tax | (151 | ) |  | (149 | ) |  | (170 | ) |  | 319 |  |  | (151 | ) |
| Income tax expense related to items of other comprehensive loss | (10 | ) |  | (10 | ) |  | (8 | ) |  | 18 |  |  | (10 | ) |
| Other comprehensive loss, net of tax | (161 | ) |  | (159 | ) |  | (178 | ) |  | 337 |  |  | (161 | ) |
| Total comprehensive income | $ | 236 |  |  | $ | 888 |  |  | $ | 83 |  |  | $ | (971 | ) |  | $ | 236 |  |

[0000106040-18-000029:notes:65]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 242 |  |  | $ | 317 |  |  | $ | 396 |  |  | $ | (713 | ) |  | $ | 242 |  |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension loss | (73 | ) |  | (73 | ) |  | (73 | ) |  | 146 |  |  | (73 | ) |
| Foreign currency translation adjustment | 74 |  |  | 74 |  |  | 74 |  |  | (148 | ) |  | 74 |  |
| Net unrealized gain (loss) on derivative contracts | 99 |  |  | 99 |  |  | 93 |  |  | (192 | ) |  | 99 |  |
| Total other comprehensive loss, before tax | 100 |  |  | 100 |  |  | 94 |  |  | (194 | ) |  | 100 |  |
| Income tax benefit related to items of other comprehensive income (loss) | 23 |  |  | 23 |  |  | 23 |  |  | (46 | ) |  | 23 |  |
| Other comprehensive loss, net of tax | 123 |  |  | 123 |  |  | 117 |  |  | (240 | ) |  | 123 |  |
| Total comprehensive income | $ | 365 |  |  | $ | 440 |  |  | $ | 513 |  |  | $ | (953 | ) |  | $ | 365 |  |


## us-gaap:DebtDisclosureTextBlock

[0000106040-18-000029:notes:66]
Debt

[0000106040-18-000029:notes:67]
Debt consisted of the following as of June 29, 2018 and June 30, 2017:

[0000106040-18-000029:notes:68]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,991 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,449 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,375 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (203 | ) |  | (205 | ) |
| Subtotal | 11,172 |  |  | 13,151 |  |
| Less current portion of long-term debt | (179 | ) |  | (233 | ) |
| Long-term debt | $ | 10,993 |  |  | $ | 12,918 |  |

[0000106040-18-000029:notes:69]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |

[0000106040-18-000029:notes:70]
In February 2018, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced the Company’s prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on the Company’s corporate credit ratings as described in the indenture, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. The Company used a portion of the proceeds of the Term Loan A-1 to repay in full its previous variable interest rate Term Loan A in the principal amount of $4.02 billion.

[0000106040-18-000029:notes:71]
The Term Loan A-1 bears interest at a per annum rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings.  Currently the Company has selected the LIBOR rate option, and the applicable rate was 3.59% as of June 29, 2018. Principal payments are due in quarterly installments of (i) 0.625% per quarter from June 2018 through March 2019 and (ii) 1.25% per quarter from June 2019 through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of June 29, 2018, issuance costs of $8 million remained unamortized.

[0000106040-18-000029:notes:72]
In May 2017, the Company entered into an interest rate swap for $1.00 billion notional amount which it has designated as a cash flow hedge to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. Under the agreement, the Company pays interest monthly at a fixed rate of 1.66% and receives a LIBOR rate on the notional amount of the contract through May 2020. In addition, in April 2018, the Company entered into an interest rate swap for $1.00 billion notional amount which it has designated as a cash flow hedge to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. Under the agreement, the Company pays interest monthly at a fixed rate of 2.75% and receives a LIBOR rate on the notional amount of the contract through February 2023.

[0000106040-18-000029:notes:73]
Proceeds of $500 million were drawn under the Revolving Facility and were used to fund a voluntary partial prepayment of the Company’s existing U.S. Dollar denominated term B-3 loans (“U.S. Term Loan B-3”). Loans under the Revolving Facility bear interest, at the Company’s option, at either LIBOR plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.59% as of June 29, 2018. The Company will also pay an unused commitment fee on the Revolving Facility ranging from 0.120% to 0.350% based on the Company’s corporate credit ratings as described in the indenture, with an initial fee of 0.250%. As of June 29, 2018, the Company had $1.75 billion of additional borrowing availability under the Revolving Facility.

[0000106040-18-000029:notes:74]
In November 2017, the Company borrowed $2.96 billion under U.S. Term Loan B-3 under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. During the year ended June 29, 2018, the Company funded a voluntary partial prepayment of $500 million, using proceeds from the Revolving Facility. In May 2018, the Company borrowed $2.46 billion under U.S. Term Loan B-4 under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-3 previously outstanding under the Credit Agreement. The U.S. Term Loan B-4 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 1.75% or a base rate plus 0.75%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.84% as of June 29, 2018. Principal payments on U.S. Term Loan B-4 of 0.25% are due quarterly and began on June 29, 2018 with the balance due on April 29, 2023. The U.S. Term Loan B-4 issuance costs are amortized to interest expense over the term of the loan and as of June 29, 2018, issuance costs of $1 million remained unamortized.

[0000106040-18-000029:notes:75]
The Revolving Facility, Term Loan A-1 and Term Loan B-4 are unconditionally guaranteed by each of the guarantors under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantees will be automatically suspended upon certain conditions.

[0000106040-18-000029:notes:76]
The Company assumed the 0.5% convertible senior notes due November 15, 2020 (the “2020 Convertible Notes”) in connection with its acquisition of SanDisk Corporation (“SanDisk”), pursuant to an Agreement and Plan of Merger (the “Merger”), on May 12, 2016 (the “SanDisk Closing Date”). As of June 29, 2018, $35 million principal amount of the 2020 Convertible Notes was outstanding and had a conversion rate of 10.9006 units of reference property per $1,000 principal amount of the 2020 Convertible Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Convertible Notes are not currently exchangeable into reference property.

[0000106040-18-000029:notes:77]
The 2020 Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other expense, net in the Consolidated Statements of Operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options is reported in Accrued expenses and Other liabilities in the Consolidated Balance Sheets. See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair values of the exchange options. For 2018, the change in the fair value of the outstanding exchange options related to the 2020 Notes resulted in an immaterial loss.

[0000106040-18-000029:notes:78]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company.

[0000106040-18-000029:notes:79]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of approximately $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events. On or after February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

[0000106040-18-000029:notes:80]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of June 29, 2018, debt discount and issuance cost of $169 million remained unamortized.

[0000106040-18-000029:notes:81]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of June 29, 2018, issuance costs of $20 million remained unamortized.

[0000106040-18-000029:notes:82]
In February and March, 2018, the Company completed the redemption of all of its outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of its outstanding 10.50% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Redeemed Notes”), including an aggregate of $720 million of “make-whole” and tender premiums required for the tender offer of the 2024 Notes and the optional redemption of the Redeemed Notes in accordance with the applicable indentures and accrued interest through the applicable redemption dates. In November 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand.

[0000106040-18-000029:notes:83]
In connection with the settlements of the various debt instruments described above, in 2018, the Company recognized an aggregate loss on debt extinguishment of $899 million, consisting of $720 million of “make-whole” and tender premiums and $179 million of unamortized issuance costs. In 2017, the Company incurred losses on the extinguishment of debt of $274 million.

[0000106040-18-000029:notes:84]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of June 29, 2018, the Company was in compliance with all financial covenants. In addition, the Credit Agreement requires the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. In addition, the indentures governing the 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.

[0000106040-18-000029:notes:85]
Future Debt Payments

[0000106040-18-000029:notes:86]
As of June 29, 2018, annual future debt payments were as follows:

[0000106040-18-000029:notes:87]
|  |  | Future Debt Payments |
|  |  | (in millions) |
| Fiscal year |  |  |
| 2019 |  | $ | 179 |  |
| 2020 |  | 278 |  |
| 2021 |  | 311 |  |
| 2022 |  | 276 |  |
| 2023 |  | 6,931 |  |
| 2024 and thereafter |  | 3,400 |  |
| Total debt maturities |  | 11,375 |  |
| Issuance costs and debt discounts |  | (203 | ) |
| Net carrying value |  | $ | 11,172 |  |


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-18-000029:notes:88]
Western Digital Corporation 401(k) Plan

[0000106040-18-000029:notes:89]
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire unless the individual is covered by a collective bargaining agreement, provides services as a consultant, intern, independent contractor, leased or temporary employee, or otherwise is not treated as a common-law employee.

[0000106040-18-000029:notes:90]
Eligible employees are generally able to contribute up to 30% of their eligible compensation on a pre-tax basis or 10% of their eligible compensation on an after-tax basis subject to Internal Revenue Service (“IRS”) limitations. The Company makes a basic matching contribution equal to 50% of the each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. The Company’s employer matching contributions vest over a two-year graded period. The Company may suspend matching contributions at any time at its discretion. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-18-000029:notes:91]
For 2018, 2017 and 2016, the Company made Plan contributions of $35 million, $36 million and $20 million, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-18-000029:notes:92]
Derivative Instruments and Hedging Activities

[0000106040-18-000029:notes:93]
As of June 29, 2018, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps that were designated as cash flow hedges. The Company determined the ineffective portion and the amount excluded for effectiveness testing associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for 2018, 2017 and 2016.

[0000106040-18-000029:notes:94]
As of June 29, 2018, the amount of existing net gains related to cash flow hedges recorded in AOCI was $2 million, of which the majority is expected to be reclassified to earnings over the next twelve months. In addition, as of June 29, 2018, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-18-000029:notes:95]
Changes in fair values of the non-designated foreign exchange contracts are recognized in other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. During 2018, 2017 and 2016, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:96]
See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair value of the Company’s foreign exchange forward contracts.

[0000106040-18-000029:notes:97]
Netting Arrangements

[0000106040-18-000029:notes:98]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 29, 2018 and June 30, 2017, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DerivativesPolicyTextBlock

[0000106040-18-000029:notes:99]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Singapore dollar and Thai baht, which had an aggregate notional amount of $4.37 billion and $2.79 billion at June 29, 2018 and June 30, 2017, respectively.

[0000106040-18-000029:notes:100]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in cost of revenue and operating expenses, and presented within cash flows from operating activities. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-18-000029:notes:101]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other expense, net. See Note 4, Fair Value Measurements and Investments, and Note 5, Derivative Instruments and Hedging Activities, for additional disclosures related to the Company’s foreign exchange contracts.

[0000106040-18-000029:notes:102]
The Company accounts for its interest rate swaps as designated cash flow hedges to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. The Company pays interest monthly at a fixed rate and receives interest monthly at the LIBOR rate on the notional amount of the contract. The effective portion of the change in fair value of this designated cash flow hedge is deferred in Other comprehensive income (loss), net of tax, with any ineffective portion recognized in Other income (expense), net. See Note 5, Derivative Instruments and Hedging Activities, and Note 6, Debt, for further discussion on interest rate swaps.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-18-000029:notes:103]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-18-000029:notes:104]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Options | $ | 25 |  |  | $ | 41 |  |  | $ | 55 |  |
| Restricted and performance stock units | 325 |  |  | 330 |  |  | 123 |  |
| Employee stock purchase plan | 27 |  |  | 23 |  |  | 13 |  |
| Subtotal | 377 |  |  | 394 |  |  | 191 |  |
| Tax benefit | (66 | ) |  | (105 | ) |  | (48 | ) |
| Total | $ | 311 |  |  | $ | 289 |  |  | $ | 143 |  |

[0000106040-18-000029:notes:105]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Cost of revenue | $ | 49 |  |  | $ | 49 |  |  | $ | 21 |  |
| Research and development | 170 |  |  | 173 |  |  | 76 |  |
| Selling, general and administrative | 157 |  |  | 161 |  |  | 85 |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 11 |  |  | 9 |  |
| Subtotal | 377 |  |  | 394 |  |  | 191 |  |
| Tax benefit | (66 | ) |  | (105 | ) |  | (48 | ) |
| Total | $ | 311 |  |  | $ | 289 |  |  | $ | 143 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000106040-18-000029:notes:106]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”), performance-based restricted stock unit awards (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and shares issuable in connection with convertible debt.


## us-gaap:EarningsPerShareTextBlock

[0000106040-18-000029:notes:107]
Net Income Per Common Share

[0000106040-18-000029:notes:108]
The following table presents the computation of basic and diluted income per common share:

[0000106040-18-000029:notes:109]
|  | Year Ended |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions, except per share data) |
| Net income | $ | 675 |  |  | $ | 397 |  |  | $ | 242 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 297 |  |  | 288 |  |  | 239 |  |
| Employee stock options, RSUs, PSUs and ESPP | 10 |  |  | 8 |  |  | 3 |  |
| Diluted | 307 |  |  | 296 |  |  | 242 |  |
| Income per common share |  |  |  |  |  |
| Basic | $ | 2.27 |  |  | $ | 1.38 |  |  | $ | 1.01 |  |
| Diluted | $ | 2.20 |  |  | $ | 1.34 |  |  | $ | 1.00 |  |
| Anti-dilutive potential common shares excluded(1) | 2 |  |  | 3 |  |  | 5 |  |

[0000106040-18-000029:notes:110]
| (1) | For purposes of computing diluted income per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-18-000029:notes:111]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-18-000029:notes:112]
Fair Value Measurements and Investments

[0000106040-18-000029:notes:113]
Financial Instruments Carried at Fair Value

[0000106040-18-000029:notes:114]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-18-000029:notes:115]
| Level 1. | Quoted prices in active markets for identical assets or liabilities. |

[0000106040-18-000029:notes:116]
| Level 2. | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities. |

[0000106040-18-000029:notes:117]
| Level 3. | Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities. |

[0000106040-18-000029:notes:118]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 29, 2018 and June 30, 2017, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-18-000029:notes:119]
|  | June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,554 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,554 |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total cash equivalents | 2,554 |  |  | 4 |  |  | — |  |  | 2,558 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Total short-term available-for-sale securities | 5 |  |  | 18 |  |  | — |  |  | 23 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Asset-backed securities | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Municipal notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total long-term available-for-sale securities | 3 |  |  | 90 |  |  | — |  |  | 93 |  |
| Foreign exchange contracts | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Interest rate swap contract | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,562 |  |  | $ | 179 |  |  | $ | — |  |  | $ | 2,741 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |

[0000106040-18-000029:notes:120]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,836 |  |
| Certificates of deposit | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total cash equivalents | 2,836 |  |  | 10 |  |  | — |  |  | 2,846 |  |
| Short-term available-for-sale securities: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term available-for-sale securities | 4 |  |  | 20 |  |  | — |  |  | 24 |  |
| Long-term available-for-sale securities: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term available-for-sale securities | 5 |  |  | 89 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,845 |  |  | $ | 135 |  |  | $ | — |  |  | $ | 2,980 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swap contract | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Exchange options | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 10 |  |

[0000106040-18-000029:notes:121]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-18-000029:notes:122]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-18-000029:notes:123]
Asset-Backed Securities, and Corporate and Municipal Notes and Bonds. The Company’s asset-backed securities, and Corporate and Municipal notes and bonds securities are investments issued by corporations and U.S. state municipalities which are held in custody by a third party. Asset-backed securities, and Corporate and Municipal notes and bonds are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-18-000029:notes:124]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government and are held in custody by a third party. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-18-000029:notes:125]
U.S. Government Agency and International Government Securities. The Company’s U.S. Government agency and international government securities are investments in fixed income securities sponsored by the U.S. Government and international governments and are held in custody by a third party. U.S. Government agency and international government securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-18-000029:notes:126]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 5, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheet under Other current assets and Accrued expenses, respectively.

[0000106040-18-000029:notes:127]
Interest Rate Swaps. The Company’s interest rate swaps are long-term contracts to hedge the Company’s variable rate debt risk. Interest rate swaps are valued based on estimated present value of future cash flows model. The market-based observable inputs for the model include interest rate curves and credit valuation adjustments.

[0000106040-18-000029:notes:128]
Assets and Liabilities Measured at Fair Value on a Recurring Basis Using Significant Unobservable Inputs (Level 3)

[0000106040-18-000029:notes:129]
Exchange Options. The Company’s 2020 Convertible Notes (as defined in Note 6, Debt) were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as derivative liabilities because they are predominantly settled in cash.

[0000106040-18-000029:notes:130]
The fair value measurement of the exchange options arising from the Company’s 2020 Convertible Notes, which are not actively traded, is determined using unobservable inputs (Level 3). These inputs include (i) the estimated amount and timing of settlement of the underlying debt; (ii) the probability of the achievement of the factor(s) on which the settlement is based; (iii) the risk-adjusted discount rate based on the expected term to maturity of the debt; and (iv) the economic incentive for holders to exercise their exchange option. Significant increases or decreases in any of those inputs in isolation could result in a significantly lower or higher fair value measurement.

[0000106040-18-000029:notes:131]
During 2018 and 2017, the Company had no transfers of financial assets and liabilities between levels.

[0000106040-18-000029:notes:132]
Available-for-Sale Securities

[0000106040-18-000029:notes:133]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of June 29, 2018 and June 30, 2017.

[0000106040-18-000029:notes:134]
Financial Instruments Not Carried at Fair Value

[0000106040-18-000029:notes:135]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2018 and the fourth quarter of 2017, respectively.

[0000106040-18-000029:notes:136]
|  | June 29, 2018 |  | June 30, 2017 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 31 |  |  | $ | 34 |  |  | $ | 30 |  |  | $ | 34 |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | — |  |  | 4,074 |  |  | 4,130 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,982 |  |  | 5,013 |  |  | — |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | — |  |  | 2,968 |  |  | 2,989 |  |
| Variable interest rate U.S. Term Loan B-4 maturing 2023 | 2,448 |  |  | 2,452 |  |  | — |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | — |  |  | 1,000 |  |  | 1,010 |  |
| 7.375% senior secured notes due 2023 | — |  |  | — |  |  | 1,835 |  |  | 2,062 |  |
| 1.50% convertible notes due 2024 | 931 |  |  | 1,114 |  |  | — |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | — |  |  | 3,244 |  |  | 3,956 |  |
| 4.750% senior unsecured notes due 2026 | 2,280 |  |  | 2,238 |  |  | — |  |  | — |  |
| Total | $ | 10,672 |  |  | $ | 10,851 |  |  | $ | 13,151 |  |  | $ | 14,181 |  |

[0000106040-18-000029:notes:137]
Equity Method Investments

[0000106040-18-000029:notes:138]
The Company has joint venture investments with Toshiba Memory Corporation and with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”). See Note 9, Commitments, Contingencies and Related Parties, for further discussion regarding these joint ventures.

[0000106040-18-000029:notes:139]
Cost Method Investments

[0000106040-18-000029:notes:140]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company reports these investments under the cost method of accounting as it does not have a significant influence over the operations of these investees. These investments consist of debt and equity securities of privately-held companies that do not have a readily determinable fair value and are carried at historical cost. The Company assesses these securities for indications of other-than-temporary impairments.

[0000106040-18-000029:notes:141]
In 2018 and 2017, the Company recorded impairment charges and losses related to the sale of these cost method investments of $17 million and $55 million, respectively, which were included in Other expense, net in the Consolidated Statements of Operations. There were no impairments in 2016 related to these investments. As of June 29, 2018 and June 30, 2017, these investments aggregated $39 million and $91 million, respectively, and are reported under Other non-current assets in the Consolidated Balance Sheets.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000106040-18-000029:notes:142]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Intangible asset amortization was as follows:

[0000106040-18-000029:notes:143]
|  | 2018 |  | 2017 |  | 2016 |
|  | (In millions) |
| Intangible asset amortization | $ | 1,185 |  |  | $ | 1,169 |  |  | $ | 266 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000106040-18-000029:notes:144]
Goodwill and Other Intangible Assets

[0000106040-18-000029:notes:145]
The following table summarizes the activity related to the carrying amount of goodwill:

[0000106040-18-000029:notes:146]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 1, 2016 | $ | 9,951 |  |
| Purchase price adjustments to goodwill | 66 |  |
| Foreign currency translation adjustment | (3 | ) |
| Balance at June 30, 2017 | 10,014 |  |
| Goodwill recorded in connection with acquisitions | 61 |  |
| Balance at June 29, 2018 | $ | 10,075 |  |

[0000106040-18-000029:notes:147]
On September 15, 2017, the Company acquired substantially all the assets of Tegile Systems, Inc., a provider of flash and persistent-memory storage solutions for enterprise data center applications. On August 25, 2017, the Company acquired substantially all the assets of Upthere, Inc., a cloud services company. These acquisitions are primarily intended to help meet the evolving needs of customers, while driving long-term growth for the Company's existing data center and client solution products over the long term.

[0000106040-18-000029:notes:148]
The aggregate purchase price of acquisitions during the year ended June 29, 2018 was $100 million in cash, with net assets acquired primarily consisting of developed technology and other intangible assets, of which $61 million was allocated to goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings to its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. Goodwill is expected to be deductible for tax purposes because the acquisitions were structured as asset acquisitions but accounted for as business combinations. Concurrent with these acquisitions, the Company received $36 million in proceeds on previously outstanding notes receivable due from these acquired entities.

[0000106040-18-000029:notes:149]
During the year ended June 29, 2018, the expenses incurred by the Company related to these acquisitions were immaterial and are primarily included within Selling, general and administrative expenses in the Consolidated Statements of Operations. Revenues and earnings related to these acquisitions was not material.

[0000106040-18-000029:notes:150]
The purchase price adjustments in 2017 resulted from adjustments to the assessment of fair value for certain acquired intangible assets; inventory; property, plant and equipment; and a portion of the deferred tax liability related to the Merger.

[0000106040-18-000029:notes:151]
The following tables present intangible assets as of June 29, 2018 and June 30, 2017:

[0000106040-18-000029:notes:152]
|  | June 29, 2018 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,323 |  |  | $ | (2,528 | ) |  | $ | 1,795 |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (222 | ) |  | 426 |  |
| Customer relationships | 6 |  | 635 |  |  | (299 | ) |  | 336 |  |
| Other | 2 |  | 180 |  |  | (161 | ) |  | 19 |  |
| Leasehold interests | 31 |  | 32 |  |  | (8 | ) |  | 24 |  |
| Total finite intangible assets |  |  | 5,818 |  |  | (3,218 | ) |  | 2,600 |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |
| Total intangible assets |  |  | $ | 5,898 |  |  | $ | (3,218 | ) |  | $ | 2,680 |  |

[0000106040-18-000029:notes:153]
|  | June 30, 2017 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 3,478 |  |  | $ | (1,373 | ) |  | $ | 2,105 |  |
| Trade names and trademarks | 7 |  | 645 |  |  | (134 | ) |  | 511 |  |
| Customer relationships | 6 |  | 627 |  |  | (227 | ) |  | 400 |  |
| Other | 2 |  | 375 |  |  | (288 | ) |  | 87 |  |
| Leasehold interests | 31 |  | 35 |  |  | (11 | ) |  | 24 |  |
| Total finite intangible assets |  |  | 5,160 |  |  | (2,033 | ) |  | 3,127 |  |
| In-process research and development |  |  | 696 |  |  | — |  |  | 696 |  |
| Total intangible assets |  |  | $ | 5,856 |  |  | $ | (2,033 | ) |  | $ | 3,823 |  |

[0000106040-18-000029:notes:154]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility.  IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. During 2018, two IPR&D projects reached technological feasibility totaling $616 million and commenced amortization over an estimated useful life of 4 years.

[0000106040-18-000029:notes:155]
During 2018 and 2017, the Company did not record any impairment charges related to intangible assets. During 2016, the Company recorded $36 million of impairment charges related to intangible assets, which are recorded in Employee termination, asset impairment and other charges within the Consolidated Statements of Operations. The impairment charges primarily relate to acquired IPR&D projects that were abandoned and resulted in full impairment.

[0000106040-18-000029:notes:156]
The following table presents estimated future amortization expense for intangible assets currently subject to amortization as of June 29, 2018:

[0000106040-18-000029:notes:157]
|  | Future Intangible Asset Amortization Expense |
|  | (in millions) |
| Fiscal year |  |
| 2019 | $ | 968 |  |
| 2020 | 755 |  |
| 2021 | 503 |  |
| 2022 | 230 |  |
| 2023 and thereafter | 144 |  |
| Total future amortization expense | $ | 2,600 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000106040-18-000029:notes:158]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the first day of its fiscal fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-18-000029:notes:159]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-18-000029:notes:160]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. See Note 7, Goodwill and Other Intangible Assets, for additional disclosures related to the Company’s other intangible assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-18-000029:notes:161]
Income Tax Expense (Benefit)

[0000106040-18-000029:notes:162]
Income Before Taxes

[0000106040-18-000029:notes:163]
The domestic and foreign components of income before taxes were as follows:

[0000106040-18-000029:notes:164]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Foreign | $ | 2,398 |  |  | $ | 560 |  |  | $ | 516 |  |
| Domestic | (313 | ) |  | 209 |  |  | (363 | ) |
| Income before taxes | $ | 2,085 |  |  | $ | 769 |  |  | $ | 153 |  |

[0000106040-18-000029:notes:165]
The components of the income tax expense (benefit) were as follows:

[0000106040-18-000029:notes:166]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 166 |  |  | $ | 127 |  |  | $ | 59 |  |
| Domestic - Federal | 1,597 |  |  | 229 |  |  | 2 |  |
| Domestic - State | (5 | ) |  | 4 |  |  | (1 | ) |
|  | 1,758 |  |  | 360 |  |  | 60 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (39 | ) |  | 56 |  |  | (39 | ) |
| Domestic - Federal | (300 | ) |  | (44 | ) |  | (109 | ) |
| Domestic - State | (9 | ) |  | — |  |  | (1 | ) |
|  | (348 | ) |  | 12 |  |  | (149 | ) |
| Income tax expense (benefit) | $ | 1,410 |  |  | $ | 372 |  |  | $ | (89 | ) |

[0000106040-18-000029:notes:167]
The Tax Cuts and Jobs Act (“2017 Act”) was enacted on December 22, 2017. The 2017 Act includes a broad range of tax reform proposals affecting businesses, including a reduction in the U.S. federal corporate tax rate from 35% to 21%, a one-time mandatory deemed repatriation tax on earnings of certain foreign subsidiaries that were previously tax deferred and creates new taxes on certain foreign earnings.

[0000106040-18-000029:notes:168]
For the year ended June 29, 2018, the Company has not finalized the accounting for the tax effects of the enactment of the 2017 Act. However, consistent with applicable SEC guidance, the Company has made a reasonable estimate of the effects on the Company’s existing deferred tax balances and the one-time mandatory deemed repatriation tax required by the 2017 Act and has recognized a provisional income tax expense of $1.57 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $65 million related to the re-measurement of deferred tax assets and liabilities for the year ended June 29, 2018. For other elements of tax expense noted below, or where the Company has not made an election, the Company has not been able to make a reasonable estimate and continues to account for such items based on the provisions of the tax laws that were in effect immediately prior to the 2017 Act.  As the Company finalizes the accounting for the tax effects of the enactment of the 2017 Act during the one-year measurement period permitted by applicable SEC guidance, the Company expects to reflect adjustments to the recorded provisional amounts and record additional tax effects of the 2017 Act.

[0000106040-18-000029:notes:169]
Additional information regarding the significant provisions of the 2017 Act that are expected to impact the Company is provided below.

[0000106040-18-000029:notes:170]
Re-measurement of deferred taxes

[0000106040-18-000029:notes:171]
The provisional income tax benefit of $65 million recorded for the year ended June 29, 2018 related to the re-measurements of the Company’s deferred tax balances and is based primarily on the rates at which the deferred tax assets and liabilities are expected to reverse in the current and future fiscal years, which are generally 29% and 22%, respectively. However, the Company is still analyzing certain aspects of the 2017 Act and refining the calculations, which could potentially affect the measurement of these balances or potentially give rise to new deferred tax amounts. The Company is also analyzing the impact of the 2017 Act to the existing valuation allowance assessments from both a federal and state tax perspective, which could potentially affect the realizability of the existing deferred tax assets. In calculating the provisional amount, the Company utilized an estimate of the expected reversals of certain tax assets and liabilities, which will be revised in future quarters during the one-year measurement period as additional information becomes available. The provisional income tax benefit for the year ended June 29, 2018 reflects a revision to the Company’s initial provisional estimate resulting in income tax expense of $23 million for refinements to the expected reversals of deferred tax assets and liabilities.

[0000106040-18-000029:notes:172]
Mandatory deemed repatriation tax

[0000106040-18-000029:notes:173]
In connection with the transition from a global to a territorial U.S. tax system, companies are required to pay a mandatory deemed repatriation tax. For the year ended June 29, 2018, the Company recorded a provisional amount for the mandatory deemed repatriation tax liability of $1.57 billion for foreign subsidiaries and $131 million of this amount is classified as a current tax liability. The calculation of the mandatory deemed repatriation tax liability is provisional and based upon preliminary estimates of post-1986 earnings and profits. In addition, the mandatory deemed repatriation tax is based on a provisional amount of foreign earnings held in cash and other specified assets, which are taxed at 15.5% and 8%, respectively, and is payable over an 8-year period. On August 1, 2018, U.S. Treasury issued proposed regulations as guidance for the mandatory deemed repatriation tax. The Company will continue to evaluate the impact of this guidance through the end of the one-year measurement period. As such, the provisional amount may change during the one-year measurement period when the Company finalizes the calculation of post-1986 foreign earnings and profits and the amount of foreign earnings held in cash or other specified assets. The provisional income tax expense for the year ended June 29, 2018 reflects a revision to the Company’s initial provisional estimate resulting in income tax benefits of $18 million for the required utilization of the 2018 generated foreign tax credits and $73 million for potential cash tax payments arising from certain unrecognized tax benefits that would partially offset the mandatory deemed repatriation tax.

[0000106040-18-000029:notes:174]
Although the mandatory deemed repatriation tax has removed U.S. federal taxes on distributions to the U.S., the Company continues to evaluate the expected manner of recovery to determine whether or not to continue to assert indefinite reinvestment on a part or all the foreign undistributed earnings. This requires the Company to re-evaluate the existing short and long-term capital allocation policies in light of the 2017 Act and calculate the tax cost that is incremental to the deemed repatriation tax (e.g., foreign withholding, state income taxes, and additional U.S. tax on currency transaction gains or losses) of repatriating cash to the U.S. While the provisional tax expense for the year ended June 29, 2018 is based upon an assumption that foreign undistributed earnings are indefinitely reinvested, the Company’s plan may change upon the completion of long-term capital allocation plans in light of the 2017 Act and completion of the calculation of the incremental tax effects on the repatriation of foreign undistributed earnings. In the event the Company determines not to continue to assert the permanent reinvestment of part or all of foreign undistributed earnings, such a determination could result in the accrual and payment of additional federal, foreign, state and local taxes.

[0000106040-18-000029:notes:175]
Deferred taxes on foreign earnings

[0000106040-18-000029:notes:176]
As a result of the shift to a territorial system for U.S. taxation, the new minimum tax on certain foreign earnings (“global intangible low-tax income”) provision of the 2017 Act imposes a tax on foreign earnings and profits in excess of a deemed return on tangible assets of foreign subsidiaries. This provision is effective for tax years beginning on or after January 1, 2018, which for the Company would be the fiscal year beginning on June 30, 2018 (fiscal year 2019). The Company has not progressed sufficiently in the analysis of this provision to make an election either to account for the effects of this provision either as a component of future income tax expense in the period the tax arises or as a component of deferred taxes on the related investments. Accordingly, no deferred tax assets and liabilities have been established for timing differences between foreign U.S. GAAP income and foreign earnings and profits that would be expected to reverse under the new minimum tax in future years. Additionally, the Company has not yet completed the calculation of post-1986 foreign earnings and profits for the mandatory repatriation tax, which would be the starting point for the measurement of deferred tax assets and liabilities in order to record any provisional amounts.

[0000106040-18-000029:notes:177]
Undistributed Foreign Earnings

[0000106040-18-000029:notes:178]
The Company has previously asserted all of its unremitted earnings offshore were permanently reinvested and had not recorded any deferred taxes related to any outside basis differences associated with its foreign subsidiaries. The estimated remaining net undistributed earnings from foreign subsidiaries at June 29, 2018 is estimated to be approximately $17 billion. While the Company has included a provisional estimate of the mandatory deemed repatriation tax on these earnings, the Company is currently evaluating how the 2017 Act will impact the Company's existing assertion of indefinite reinvestment and determining a reasonable estimate of the remaining tax liability, if any, for any outside basis differences after consideration of the mandatory repatriation tax. As such, no change has been made with respect to this assertion for the year ended June 29, 2018. The Company will complete its analysis of the impact of the 2017 Act on its indefinite reinvestment assertion and record amounts, such as any remaining outside basis differences, foreign withholding taxes, state income taxes, and additional U.S. tax on currency transaction gains or losses, if necessary, during the measurement period.

[0000106040-18-000029:notes:179]
Deferred Taxes

[0000106040-18-000029:notes:180]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-18-000029:notes:181]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 53 |  |  | $ | 84 |  |
| Accrued compensation and benefits not currently deductible | 145 |  |  | 252 |  |
| Net operating loss carryforward | 443 |  |  | 292 |  |
| Business credit carryforward | 448 |  |  | 283 |  |
| Long-lived assets | 161 |  |  | 236 |  |
| Other | 118 |  |  | 141 |  |
| Total deferred tax assets | 1,368 |  |  | 1,288 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (491 | ) |  | (874 | ) |
| Unremitted earnings of certain non-U.S. entities | (5 | ) |  | (38 | ) |
| Other | (43 | ) |  | (11 | ) |
| Total deferred tax liabilities | (539 | ) |  | (923 | ) |
| Valuation allowances | (614 | ) |  | (518 | ) |
| Deferred tax assets (liabilities), net | $ | 215 |  |  | $ | (153 | ) |

[0000106040-18-000029:notes:182]
The change from a net deferred tax liability to a net deferred tax asset is primarily due to an increase in the deferred tax asset for the 2018 generation of net operating losses and business credits of $316 million, the 2018 reversal of the deferred tax liability associated purchase accounting intangibles of $90 million, and the re-measurement of the Company’s deferred tax balances of $65 million due to the 2017 Act.

[0000106040-18-000029:notes:183]
The net deferred tax asset valuation allowance increased by $96 million and $224 million in 2018 and 2017, respectively. The valuation allowance increase in 2018 is primarily attributable to the 2018 generation of foreign net operating loss carryforwards of $54 million and state tax credits of $33 million, which the Company does not anticipate being able to utilize. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-18-000029:notes:184]
In addition to the deferred tax assets presented above, the Company had benefits related to net operating loss benefits from stock-based compensation deductions of $20 million as of June 30, 2017. The reduction in NOL benefits from stock-based compensation deductions was due to the adoption of ASU 2016-09 during the first quarter of 2018. See Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10‑K.

[0000106040-18-000029:notes:185]
Effective Tax Rate

[0000106040-18-000029:notes:186]
Under the 2017 Act, the reduction of the U.S. federal corporate tax rate from 35% to 21% is effective January 1, 2018, requiring companies to use a blended rate for their fiscal 2018 tax year by applying a pro-rated percentage of the number of days before and after the January 1, 2018 effective date. This results in the use of an estimated annual effective tax rate of approximately 28% for the Company’s U.S. federal corporate tax rate for fiscal year 2018. For fiscal year 2019 and beyond, the Company will utilize the enacted U.S. federal corporate tax rate of 21%.

[0000106040-18-000029:notes:187]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-18-000029:notes:188]
|  | 2018 |  | 2017 |  | 2016 |
| U.S. Federal statutory rate | 28 | % |  | 35 | % |  | 35 | % |
| Tax rate differential on international income | (34 | ) |  | (27 | ) |  | (103 | ) |
| Tax effect of U.S. non-deductible convertible debt costs | — |  |  | — |  |  | 13 |  |
| Tax effect of U.S. non-deductible acquisition costs | — |  |  | — |  |  | 10 |  |
| Tax effect of U.S. foreign income inclusion | 1 |  |  | 4 |  |  | 9 |  |
| Tax effect of U.S. non-deductible stock-based compensation | 1 |  |  | 1 |  |  | 9 |  |
| Tax effect of U.S. permanent differences | (1 | ) |  | (1 | ) |  | 1 |  |
| State income tax, net of federal tax | — |  |  | 1 |  |  | (1 | ) |
| Impact of 2017 Act: |  |  |  |  |  |
| One-time mandatory deemed repatriation tax | 75 |  |  | — |  |  | — |  |
| Re-measurement of deferred taxes | (3 | ) |  | — |  |  | — |  |
| Change in valuation allowance | 5 |  |  | 29 |  |  | 16 |  |
| Unremitted earnings of certain non-U.S. entities | — |  |  | 5 |  |  | — |  |
| Tax related to SanDisk integration | — |  |  | 12 |  |  | — |  |
| Retroactive extension of Federal R&D credit | — |  |  | — |  |  | (9 | ) |
| Income tax credits | (4 | ) |  | (12 | ) |  | (43 | ) |
| Other | — |  |  | 1 |  |  | 5 |  |
| Effective tax rate | 68 | % |  | 48 | % |  | (58 | )% |

[0000106040-18-000029:notes:189]
Tax Holidays and Carryforwards

[0000106040-18-000029:notes:190]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines, Singapore and Thailand operate under various tax holidays and tax incentive programs which expired or will expire in whole or in part at various dates from 2018 through 2030. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $519 million, or $1.69 per diluted share, $467 million, or $1.58 per diluted share, and $500 million, or $2.07 per diluted share, in 2018, 2017, and 2016, respectively.

[0000106040-18-000029:notes:191]
As of June 29, 2018, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-18-000029:notes:192]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 766 |  |  | 2020 to 2037 |
| Federal NOL (Post 2017 Act Generation) | 704 |  |  | No expiration |
| State NOL | 850 |  |  | 2022 to 2038 |
| Federal tax credits | 155 |  |  | 2019 to 2038 |
| State tax credits | 550 |  |  | No expiration |

[0000106040-18-000029:notes:193]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal NOLs ultimately realized will be reduced by $448 million and state NOLs ultimately realized will be reduced by $435 million. The Company expects the total amount of federal credits ultimately realized will be reduced by $39 million and state tax credit carryforwards ultimately realized will be reduced by $550 million.

[0000106040-18-000029:notes:194]
The Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-18-000029:notes:195]
| Jurisdiction |  | NOL Carryforward Amount |  | Expiration |
|  |  | (in millions) |  |  |
| Japan |  | $ | 141 |  |  | 2024 to 2026 |
| Belgium |  | 86 |  |  | No expiration |
| China |  | 129 |  |  | 2023 to 2024 |
| Malaysia |  | 117 |  |  | No expiration |
| Spain |  | 56 |  |  | No expiration |

[0000106040-18-000029:notes:196]
The Company expects the total amount of NOL carryforwards in Japan ultimately realized will be reduced by $84 million. The Company expects the NOL carryforwards in Belgium, China and Spain will not be ultimately realized.

[0000106040-18-000029:notes:197]
Uncertain Tax Positions

[0000106040-18-000029:notes:198]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 29, 2018, June 30, 2017 and July 1, 2016 was $110 million, $89 million and $75 million, respectively.

[0000106040-18-000029:notes:199]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-18-000029:notes:200]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 522 |  |  | $ | 491 |  |  | $ | 350 |  |
| Gross increases related to current year tax positions | 38 |  |  | 35 |  |  | 46 |  |
| Gross increases related to prior year tax positions | 30 |  |  | 3 |  |  | 6 |  |
| Gross decreases related to prior year tax positions | (9 | ) |  | (8 | ) |  | (15 | ) |
| Settlements | (19 | ) |  | (8 | ) |  | (8 | ) |
| Lapse of statute of limitations | (11 | ) |  | (19 | ) |  | (8 | ) |
| Acquisitions | — |  |  | 28 |  |  | 120 |  |
| Unrecognized tax benefit, ending balance | $ | 551 |  |  | $ | 522 |  |  | $ | 491 |  |

[0000106040-18-000029:notes:201]
The Company’s unrecognized tax benefits are primarily included within long-term liabilities in the Consolidated Balance Sheets. The entire balance of unrecognized tax benefits as of June 29, 2018, June 30, 2017 and July 1, 2016, if recognized, would affect the effective tax rate.

[0000106040-18-000029:notes:202]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2010 through 2017. The Company is no longer subject to examination by the IRS for periods prior to 2010, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the major foreign jurisdictions, the Company could be subject to examination in China for calendar years 2008 through 2017, in Ireland for calendar years 2014 through 2017, in India for fiscal years 2013 through 2017, in Israel for fiscal years 2013 through 2017 and in Japan for fiscal years 2011 through 2017.

[0000106040-18-000029:notes:203]
The IRS previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. As previously disclosed, the Company received Revenue Agent Reports from the IRS, proposing adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. The Company and the IRS Appeals Office did not reach a settlement on the disputed matters. On June 28, 2018, the IRS issued a statutory notice of deficiency with respect to the unagreed issues, seeking to increase the Company’s U.S. taxable income by an amount that would result in additional federal tax through fiscal year 2009 totaling approximately $516 million, subject to interest.  The Company intends to file a Petition with the U.S. Tax Court. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-18-000029:notes:204]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 29, 2018, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0000106040-18-000029:notes:205]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized.

[0000106040-18-000029:notes:206]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.


## us-gaap:InventoryPolicyTextBlock

[0000106040-18-000029:notes:207]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out (“FIFO”) method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-18-000029:notes:208]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-18-000029:notes:209]
Legal Proceedings

[0000106040-18-000029:notes:210]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-18-000029:notes:211]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the SanDisk Closing Date; “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-18-000029:notes:212]
Intellectual Property Litigation

[0000106040-18-000029:notes:213]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000029:notes:214]
Antitrust

[0000106040-18-000029:notes:215]
In March 2011, a complaint was filed against SanDisk, SD-3C LLC, Panasonic Corporation, Panasonic Corporation of North America, Toshiba Corporation and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. In July 2018, ten of the thirteen named plaintiffs voluntarily dismissed their claims against the defendants. Counsel for the remaining named plaintiffs are engaged in settlement discussions with counsel for the defendants. The case has been stayed pending these settlement discussions. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000029:notes:216]
Securities

[0000106040-18-000029:notes:217]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

[0000106040-18-000029:notes:218]
Copyright

[0000106040-18-000029:notes:219]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts.

[0000106040-18-000029:notes:220]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013.

[0000106040-18-000029:notes:221]
On or around June 22, 2018, Bitkom, an industry association, and ZPÜ entered into an agreement for regulating the obligation to pay compensation under copyright law in Germany for hard drives for the period beginning January 1, 2008. On or around June 29, 2018, the Company elected to join the agreement. Pursuant to the agreement, the Company and ZPÜ intend to dismiss the actions against each other following an accounting and payment of past liabilities. The entry into this agreement did not have a material impact on the Company’s financial condition, results of operations or cash flows.

[0000106040-18-000029:notes:222]
Other Matters

[0000106040-18-000029:notes:223]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-18-000029:notes:224]
Recent Accounting Pronouncements

[0000106040-18-000029:notes:225]
Accounting Pronouncements Recently Adopted

[0000106040-18-000029:notes:226]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). ASU 2017-04 simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. As permitted by ASU 2017-04, the Company has elected to early adopt this standard for its fiscal 2018 goodwill impairment test, which was performed as of the first day of the Company’s fourth quarter, March 31, 2018. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:227]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). ASU 2016-15 provides amendments that address eight specific cash flow classification issues for which there exists diversity in practice: Debt prepayment or debt extinguishment costs; settlement of zero-coupon debt instruments or other debt instruments with coupon interest rates that are insignificant in relation to the effective interest rate of the borrowing; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies, including bank-owned life insurance policies; distributions received from equity method investees; beneficial interests in securitization transactions; and separately identifiable cash flows and application of the predominance principle. The Company adopted ASU 2016-15 in the second quarter of 2018 on a modified retrospective basis as required by the standard. The Company’s adoption of ASU 2016-15 did not have a material effect on the Company’s historical Consolidated Financial Statements.

[0000106040-18-000029:notes:228]
In March 2016, the FASB issued ASU No. 2016-09, “Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). ASU 2016-09 simplifies several aspects of the accounting for stock-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The Company adopted this standard in the first quarter of 2018 using the modified retrospective approach. This adoption resulted in a one-time net increase to beginning retained earnings of $70 million, consisting of a $58 million cumulative adjustment for the previously unrecognized windfall tax benefits related to previous vesting and exercises of stock-based awards, and a $19 million cumulative adjustment related to the change in accounting policy for estimated forfeitures and share cancellations, partially offset by a decrease of $7 million for the related tax impacts of change in forfeiture policy. In addition, upon adoption of the new standard in the Company’s first quarter of 2018, the Company began prospectively reflecting the tax deficiencies and benefits as an operating activity, rather than as a financing activity under the previous standard, in the Company’s Consolidated Statements of Cash Flows. For the year ended June 29, 2018, the Company recognized net excess tax benefits $78 million, as a component of Income tax expense (benefit).

[0000106040-18-000029:notes:229]
In July 2015, the FASB issued ASU No. 2015‑11, “Inventory (Topic 330) - Simplifying the Measurement of Inventory” (“ASU 2015‑11”), which dictates that an entity should measure inventory within the scope of this update at the lower of cost and net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this standard in the first quarter of 2018. The Company’s adoption of ASU 2015‑11 did not have a material impact on its Consolidated Financial Statements.

[0000106040-18-000029:notes:230]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-18-000029:notes:231]
In February 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2018-02, “Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income” (“ASU 2018-02”). ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the 2017 Act. Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. However, because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. The amendments in this update also require certain disclosures about stranded tax effects. The Company early adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:232]
In August 2017, the FASB issued ASU No. 2017-12, “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities” (“ASU 2017-12”). ASU 2017-12 simplifies hedge accounting through changes to both designation and measurement requirements. For hedges that qualify as highly effective, the new standard eliminates the requirement to separately measure and record hedge ineffectiveness, resulting in better alignment between the presentation of the effects of the hedging instrument and the hedged item in the financial statements. The Company adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:233]
In May 2017, the FASB issued ASU No. 2017-09, “Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting” (“ASU 2017-09”). ASU 2017-09 provides clarification when a change to the terms or conditions of a share-based payment award must be accounted for as a modification. The new guidance requires modification accounting if the fair value, vesting condition or the classification of the award is not the same immediately before and after a change to the terms and conditions of the award. This ASU is effective prospectively and was adopted effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:234]
In March 2017, the FASB issued ASU No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The Company adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:235]
In January 2017, the FASB issued ASU No. 2017-01, “Business Combinations (Topic 805): Clarifying the Definition of a Business” (“ASU 2017-01”). ASU 2017-01 narrows the definition of a “business”. This standard provides guidance to assist entities with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019, and applied it prospectively to transactions occurring thereafter. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:236]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB ASC Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of accounting principles generally accepted in the United States (“U.S. GAAP”) and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The Company adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:237]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021.  The Company is currently evaluating the impact this update will have on its Consolidated Financial Statements.

[0000106040-18-000029:notes:238]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02 supersedes ASC 840 “Leases”. The amendments in this update require, among other things, that lessees recognize the following for all leases (unless a policy election is made by class of underlying asset to exclude short-term leases) at the commencement date: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right-of-use asset, which is an asset that represents the lessee’s right to use, or control the use of, a specified asset for the lease term. Based on the standard as originally issued, lessees and lessors were to apply a modified retrospective transition approach for leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements. However, the FASB issued ASU 2018-11 on July 30, 2018, which allows entities to apply the provisions of ASC 842 at the effective date without adjusting comparative periods. The standard is effective for interim and annual reporting periods beginning after December 15, 2018, with early adoption permitted. As the Company plans for the adoption of this standard, the Company has completed its first phase of globally identifying its leases including the identification of embedded leases. The Company is in the process of identifying changes to its processes, internal controls and system requirements and configurations that would result from the new lease standard. The Company’s implementation efforts are progressing as planned. The Company expects to adopt this standard in the first quarter of fiscal 2020 and expects to elect the practical expedient to not present historical comparative information. The Company continues to evaluate the impact ASU 2016-02 will have on its Consolidated Financial Statements.

[0000106040-18-000029:notes:239]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. The Company adopted this standard effective June 30, 2018, the beginning of the first quarter of 2019. The adoption of this standard did not have a material impact on the Company’s Consolidated Financial Statements.

[0000106040-18-000029:notes:240]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)” (“ASC Topic 606”), which amends the guidance in former ASC Topic 605, “Revenue Recognition” (“ASC Topic 605”), to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted the new standard effective June 30, 2018, the beginning of the first quarter of 2019, using the modified retrospective method, with the cumulative effect of initially applying the guidance recognized at the date of initial application.

[0000106040-18-000029:notes:241]
The implementation of the new standard will impact the recognition of the Company’s revenue and cost as follows:

[0000106040-18-000029:notes:242]
| • | Substantially all of the Company’s current revenue is from the sale of hardware products. The Company does not believe that there are any material changes to the timing or amount of revenue for these types of sales under the new standard as the majority of the Company’s revenue is recognized at a point in time. |

[0000106040-18-000029:notes:243]
| • | For sales-based royalties, the Company will estimate and recognize revenue in the period the royalty-bearing sales occur as opposed to the existing treatment of recognizing revenue in the period the royalty report is received. This change will result in the acceleration of revenue recognition by one fiscal quarter as well as fluctuations between the estimated and actual reported sales-based royalties, which the Company does not expect to be material. |

[0000106040-18-000029:notes:244]
| • | For other revenue streams such as multi-element transactions, software and IP licenses, these transactions are immaterial and the related changes to revenue recognition will not be material. |

[0000106040-18-000029:notes:245]
| • | For assets recognized from costs incurred to obtain or fulfill a contract, the Company does not expect to have material capitalized fees for contracts where the amortization period is greater than one year. The Company will continue to expense these costs as incurred. |

[0000106040-18-000029:notes:246]
| • | The Company’s revenue disclosures will expand and may require judgment in certain areas. |

[0000106040-18-000029:notes:247]
The adoption of the new revenue standard resulted in a post-tax adjustment of approximately $54 million to increase the beginning retained earnings for fiscal year 2019 for uncompleted contracts for which revenue will not be recognized in the future periods under ASC Topic 606. The Company continues to evaluate the effect that ASC Topic 606 will have on its Consolidated Financial Statements, including the impact on income tax expense and related balance sheet accounts. Changes to the Company’s processes, internal controls and systems as a result of the adoption of this new revenue standard were not significant.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-18-000029:notes:248]
Organization and Basis of Presentation

[0000106040-18-000029:notes:249]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”) which is included in each of the three categories.

[0000106040-18-000029:notes:250]
Basis of Presentation

[0000106040-18-000029:notes:251]
Fiscal Year

[0000106040-18-000029:notes:252]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2018, which ended on June 29, 2018; 2017, which ended on June 30, 2017; and 2016, which ended on July 1, 2016, were each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-18-000029:notes:253]
Basis of Consolidation

[0000106040-18-000029:notes:254]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in accumulated other comprehensive income, a component of shareholders’ equity.

[0000106040-18-000029:notes:255]
Reclassifications

[0000106040-18-000029:notes:256]
Certain prior year amounts have been reclassified in the consolidated balance sheets to conform to the current year presentation.

[0000106040-18-000029:notes:257]
Use of Estimates

[0000106040-18-000029:notes:258]
Management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-18-000029:notes:259]
Cash Equivalents

[0000106040-18-000029:notes:260]
The Company invests in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities, and corporate and municipal notes and bonds, with original maturities at purchase of more than three months. These investments are classified as available-for-sale securities and included within other non-current assets in the Consolidated Balance Sheets. Available-for-sale securities are stated at fair value with unrealized gains and losses included in accumulated other comprehensive income (loss), which is a component of shareholders’ equity. Gains and losses on available-for-sale securities are recorded based on the specific identification method. The Company evaluates the available-for-sale securities in an unrealized loss position for other-than-temporary impairment. The amortized cost of available-for-sale securities is adjusted for amortization of premiums and accretion of discounts to maturity. Such amortization and accretion are included in Other expense, net in the Consolidated Statement of Operations. In addition, realized gains and losses are included in Other expense, net in the Consolidated Statement of Operations.

[0000106040-18-000029:notes:261]
Equity Investments

[0000106040-18-000029:notes:262]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other expense, net, in the Consolidated Statement of Operations.

[0000106040-18-000029:notes:263]
The Company accounts for investments in equity securities of other entities under the cost method of accounting if the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee. Investments accounted for under the cost method of accounting are recorded within Other non-current assets in the Consolidated Balance Sheets and are also periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-18-000029:notes:264]
Variable Interest Entities

[0000106040-18-000029:notes:265]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-18-000029:notes:266]
Fair Value of Financial Instruments

[0000106040-18-000029:notes:267]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-18-000029:notes:268]
Inventories

[0000106040-18-000029:notes:269]
Property, Plant and Equipment

[0000106040-18-000029:notes:270]
Property and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings are depreciated over periods ranging from fifteen to thirty-five years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-18-000029:notes:271]
Business Combinations

[0000106040-18-000029:notes:272]
The application of acquisition accounting to a business combination requires that the Company identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date using a combination of valuation techniques, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the excess purchase price are based upon preliminary estimates and assumptions and subject to revision when the Company receives final information, including appraisals and other analyses. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. The Company will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-18-000029:notes:273]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. The Company recognizes the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). The Company’s assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-18-000029:notes:274]
Goodwill and Other Long-Lived Assets

[0000106040-18-000029:notes:275]
Revenue and Accounts Receivable

[0000106040-18-000029:notes:276]
Revenue is recognized when the title and risk of loss have passed to the customer, there is persuasive evidence of an arrangement, delivery has occurred, or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured. The Company establishes provisions against revenue and cost of revenue for estimated sales returns in the same period that the related revenue is recognized based on existing product return notifications. If actual sales returns exceed expectations, an increase in the sales return accrual would be required, which could materially affect operating results.

[0000106040-18-000029:notes:277]
In accordance with standard industry practice, the Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions and/or a right of return and the Company provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. At the time the Company recognizes revenue to resellers and OEMs, a reduction of revenue is recorded for estimated price protection and/or returns until the resellers sell such inventory to their customers and the Company also records a reduction of revenue for the other programs in effect. The Company bases these adjustments on several factors including anticipated price decreases during the reseller holding period, reseller’s sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information, historical and anticipated returns information and customer claim processing. If customer demand for the Company’s products or market conditions differ from the Company’s expectations, the Company’s operating results could be materially affected. The Company also has programs under which it reimburses qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue.

[0000106040-18-000029:notes:278]
Revenue from patent licensing arrangements is recognized when earned, estimable and realizable. The timing of revenue recognition is dependent on the terms of each license agreement and on the timing of sales of licensed products. The Company generally recognizes royalty revenue when it is reported to the Company by its licensees, which is generally one quarter in arrears from the licensees’ sales of licensed products. For licensing fees that are not determined by the licensees’ sales, the Company generally recognizes license fee revenue on a straight-line basis over the life of the license.

[0000106040-18-000029:notes:279]
Some of the Company’s revenue arrangements are multiple-element arrangements because they are generally comprised of product, software and support services or multiple distinct licenses. For multiple-element arrangements, the Company evaluates whether each deliverable should be accounted for as a separate unit of accounting. For multiple-element arrangements that include support or software elements, the Company analyzes whether tangible products containing software and non-software components function together and therefore should be excluded from industry-specific software revenue recognition guidance. For all multiple-element arrangements, the Company allocates revenue to each element, or the software elements as a group, based on the relative selling price determined in accordance with the Company’s normal pricing and discounting practices for the specific element when sold separately. For multiple-element license agreements that include more than one license to distinct technology that are separate units of accounting, the Company allocates revenue to each license based on the relative selling price of each deliverable. License fees related to existing technology with no continuing performance obligations are generally recognized upon license commencement and other license fees are generally recognized on a straight-line basis over the life of the license. The Company primarily uses an estimate of selling price to allocate revenue for multiple-element license agreements based upon similar licenses, historical and estimated future sales volume, duration and market conditions.

[0000106040-18-000029:notes:280]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency, disputes or other collection issues. In addition, the Company routinely analyzes the different receivable aging categories and establishes reserves based on a combination of past due receivables and expected future losses based primarily on its historical levels of bad debt losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss history changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-18-000029:notes:281]
Warranty

[0000106040-18-000029:notes:282]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected.

[0000106040-18-000029:notes:283]
Litigation and Other Contingencies

[0000106040-18-000029:notes:284]
Advertising Expense

[0000106040-18-000029:notes:285]
Advertising costs are expensed as incurred and amounted to $112 million, $89 million and $60 million in 2018, 2017 and 2016, respectively. These expenses are included in Selling, general and administrative (“SG&A”) in the Consolidated Statements of Operations.

[0000106040-18-000029:notes:286]
Research and Development Expense

[0000106040-18-000029:notes:287]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-18-000029:notes:288]
Income Taxes

[0000106040-18-000029:notes:289]
Income per Common Share

[0000106040-18-000029:notes:290]
Stock-based Compensation

[0000106040-18-000029:notes:291]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options granted are estimated using a binomial option-pricing model, and the fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model. Both the binomial and the Black-Scholes-Merton option-pricing models require the input of highly subjective assumptions. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics. Once the performance metrics are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs will be earned. The Company records stock-based compensation expense based on the probability that the performance metrics will be achieved over the vesting period.

[0000106040-18-000029:notes:292]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-18-000029:notes:293]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, available-for-sale securities, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-18-000029:notes:294]
Derivative Contracts

[0000106040-18-000029:notes:295]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-18-000029:notes:296]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. See Note 8, Pension and Other Post-Retirement Benefit Plans, for additional disclosures related to the Company’s pensions and other post-retirement benefit plans.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0000106040-18-000029:notes:297]
Other liabilities

[0000106040-18-000029:notes:298]
|  | 2018 |  | 2017 |
|  | (in millions) |
| Other non-current liabilities: |  |  |  |
| Non-current net tax payable | $ | 1,315 |  |  | $ | — |  |
| Other non-current liabilities | 940 |  |  | 1,180 |  |
| Total other non-current liabilities | $ | 2,255 |  |  | $ | 1,180 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-18-000029:notes:299]
Pension and Other Post-Retirement Benefit Plans

[0000106040-18-000029:notes:300]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Consolidated Financial Statements.

[0000106040-18-000029:notes:301]
Obligations and Funded Status

[0000106040-18-000029:notes:302]
The following table presents the unfunded amounts related to the Japanese Plan as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-18-000029:notes:303]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 59 |  |  | 59 |  |
| Net amount recognized | $ | 60 |  |  | $ | 60 |  |

[0000106040-18-000029:notes:304]
The accumulated benefit obligation for the Japanese defined benefit pension plans was $260 million at June 29, 2018. As of June 29, 2018, actuarial losses for the Japanese defined benefit pension plans of $21 million are included in Accumulated other comprehensive loss in the Consolidated Balance Sheet. There were no prior service credits for the defined benefit pension plans recognized in Accumulated other comprehensive loss in the Consolidated Balance Sheet as of June 29, 2018.

[0000106040-18-000029:notes:305]
Assumptions

[0000106040-18-000029:notes:306]
Weighted-Average Assumptions

[0000106040-18-000029:notes:307]
The weighted-average actuarial assumptions used to determine benefit obligations for the Japanese defined benefit pension plans were as follows:

[0000106040-18-000029:notes:308]
|  | 2018 |  | 2017 |  | 2016 |
| Discount rate | 0.7 | % |  | 0.8 | % |  | 0.4 | % |
| Rate of compensation increase | 0.7 | % |  | 0.8 | % |  | 0.8 | % |

[0000106040-18-000029:notes:309]
The weighted-average actuarial assumptions used to determine benefit costs for the Japanese defined benefit pension plans were as follows:

[0000106040-18-000029:notes:310]
|  | 2018 |  | 2017 |  | 2016 |
| Discount rate | 0.8 | % |  | 0.4 | % |  | 1.3 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 0.8 | % |  | 0.8 | % |  | 0.9 | % |

[0000106040-18-000029:notes:311]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management in Japan then matches the benefit payments to bond ratings that are “AA” or higher which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-18-000029:notes:312]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in Japan as well as the investment portfolio applicable to the plan. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates.

[0000106040-18-000029:notes:313]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-18-000029:notes:314]
Plan Assets

[0000106040-18-000029:notes:315]
Investment Policies and Strategies

[0000106040-18-000029:notes:316]
The investment policy in Japan is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 63% in debt securities, 34% in equity securities, and the remaining 3% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-18-000029:notes:317]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-18-000029:notes:318]
Fair Value Measurements

[0000106040-18-000029:notes:319]
The following tables present the Japanese defined benefit pension plans’ major asset categories and their associated fair values as of June 29, 2018 and June 30, 2017:

[0000106040-18-000029:notes:320]
|  | June 29, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 125 |  |  | — |  |  | 125 |  |
| Cash equivalents and short-term investments | 3 |  |  | 4 |  |  | — |  |  | 7 |  |
| Fair value of plan assets | $ | 3 |  |  | $ | 197 |  |  | $ | — |  |  | $ | 200 |  |

[0000106040-18-000029:notes:321]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 116 |  |  | — |  |  | 116 |  |
| Cash equivalents and short-term investments | 2 |  |  | 4 |  |  | — |  |  | 6 |  |
| Fair value of plan assets | $ | 2 |  |  | $ | 187 |  |  | $ | — |  |  | $ | 189 |  |

[0000106040-18-000029:notes:322]
| (1) | Commingled funds represent pooled institutional investments. |

[0000106040-18-000029:notes:323]
| (2) | Equity mutual funds invest primarily in equity securities. |

[0000106040-18-000029:notes:324]
| (3) | Fixed income mutual funds invest primarily in fixed income securities. |

[0000106040-18-000029:notes:325]
Assets held in defined benefit plans in the Philippines, Taiwan and Thailand were immaterial and are not presented in the above tables.

[0000106040-18-000029:notes:326]
There were no significant movements of assets between any level categories in 2018, 2017 or 2016.

[0000106040-18-000029:notes:327]
Fair Value Valuation Techniques

[0000106040-18-000029:notes:328]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-18-000029:notes:329]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-18-000029:notes:330]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-18-000029:notes:331]
Cash Flows

[0000106040-18-000029:notes:332]
The Company’s expected employer contributions for 2019 and annual benefit payments over the next 5 years for its Japanese defined benefit pension plans are not expected to be material.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-18-000029:notes:333]
Property, plant and equipment, net

[0000106040-18-000029:notes:334]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,998 |  |  | $ | 1,855 |  |
| Machinery and equipment | 7,209 |  |  | 6,815 |  |
| Computer equipment and software | 440 |  |  | 404 |  |
| Furniture and fixtures | 48 |  |  | 49 |  |
| Leasehold improvements | 257 |  |  | 259 |  |
| Construction-in-process | 234 |  |  | 144 |  |
| Property, plant and equipment, gross | 10,186 |  |  | 9,526 |  |
| Accumulated depreciation | (7,091 | ) |  | (6,493 | ) |
| Property, plant, and equipment, net | $ | 3,095 |  |  | $ | 3,033 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-18-000029:notes:335]
Quarterly Results of Operations (unaudited)

[0000106040-18-000029:notes:336]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2018 |  |  |  |  |  |  |  |
| Revenue, net | $ | 5,181 |  |  | $ | 5,336 |  |  | $ | 5,013 |  |  | $ | 5,117 |  |
| Gross profit | 1,913 |  |  | 2,013 |  |  | 1,927 |  |  | 1,852 |  |
| Operating income | 905 |  |  | 955 |  |  | 914 |  |  | 843 |  |
| Net income (loss) | 681 |  |  | (823 | ) |  | 61 |  |  | 756 |  |
| Basic income (loss) per common share | $ | 2.31 |  |  | $ | (2.78 | ) |  | $ | 0.20 |  |  | $ | 2.53 |  |
| Diluted income (loss) per common share | $ | 2.23 |  |  | $ | (2.78 | ) |  | $ | 0.20 |  |  | $ | 2.46 |  |

[0000106040-18-000029:notes:337]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2017 |  |  |  |  |  |  |  |
| Revenue, net | $ | 4,714 |  |  | $ | 4,888 |  |  | $ | 4,649 |  |  | $ | 4,842 |  |
| Gross profit | 1,335 |  |  | 1,533 |  |  | 1,523 |  |  | 1,681 |  |
| Operating income (loss) | 232 |  |  | 545 |  |  | 525 |  |  | 652 |  |
| Net income (loss) | (366 | ) |  | 235 |  |  | 248 |  |  | 280 |  |
| Basic income (loss) per common share | $ | (1.28 | ) |  | $ | 0.82 |  |  | $ | 0.86 |  |  | $ | 0.96 |  |
| Diluted income (loss) per common share | $ | (1.28 | ) |  | $ | 0.80 |  |  | $ | 0.83 |  |  | $ | 0.93 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-18-000029:notes:338]
The following table illustrates the significant amounts of each component reclassified out of AOCI to the Consolidated Statements of Operations:

[0000106040-18-000029:notes:339]
| AOCI Component |  | 2018 |  | 2017 |  | 2016 |  | Statement of Operations Line Item |
|  | (in millions) |  |  |
| Unrealized holding gain (loss) on designated hedging activities: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 16 |  |  | $ | 33 |  |  | $ | (17 | ) |  | Cost of revenue |
| Foreign exchange contracts |  | 2 |  |  | (3 | ) |  | (34 | ) |  | Research and development |
| Total reclassifications for the period |  | $ | 18 |  |  | $ | 30 |  |  | $ | (51 | ) |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-18-000029:notes:340]
The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):

[0000106040-18-000029:notes:341]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Derivative Contracts and Available for Sale Securities |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 1, 2016 | $ | (45 | ) |  | $ | 74 |  |  | $ | 74 |  |  | $ | 103 |  |
| Other comprehensive income (loss) before reclassifications | 39 |  |  | (115 | ) |  | (45 | ) |  | (121 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (30 | ) |  | (30 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (12 | ) |  | 2 |  |  | — |  |  | (10 | ) |
| Net current-period other comprehensive income (loss) | 27 |  |  | (113 | ) |  | (75 | ) |  | (161 | ) |
| Balance at June 30, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (2 | ) |  | 18 |  |  | 25 |  |  | 41 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (18 | ) |  | (18 | ) |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | 1 |  |  | — |  |  | (5 | ) |  | (4 | ) |
| Net current-period other comprehensive income (loss) | (1 | ) |  | 18 |  |  | 2 |  |  | 19 |  |
| Balance at June 29, 2018 | $ | (19 | ) |  | $ | (21 | ) |  | $ | 1 |  |  | $ | (39 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-18-000029:notes:342]
| Condensed Consolidating Balance Sheet |
| As of June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |
| Accounts receivable, net | — |  |  | 1,358 |  |  | 839 |  |  | — |  |  | 2,197 |  |
| Intercompany receivables | 1,903 |  |  | 4,256 |  |  | 2,674 |  |  | (8,833 | ) |  | — |  |
| Inventories | — |  |  | 990 |  |  | 2,159 |  |  | (205 | ) |  | 2,944 |  |
| Other current assets | 20 |  |  | 195 |  |  | 277 |  |  | — |  |  | 492 |  |
| Total current assets | 1,963 |  |  | 7,467 |  |  | 10,246 |  |  | (9,038 | ) |  | 10,638 |  |
| Property, plant and equipment, net | — |  |  | 1,092 |  |  | 2,003 |  |  | — |  |  | 3,095 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 2,105 |  |  | — |  |  | 2,105 |  |
| Goodwill | — |  |  | 387 |  |  | 9,688 |  |  | — |  |  | 10,075 |  |
| Other intangible assets, net | — |  |  | 38 |  |  | 2,642 |  |  | — |  |  | 2,680 |  |
| Investments in consolidated subsidiaries | 20,847 |  |  | 19,893 |  |  | — |  |  | (40,740 | ) |  | — |  |
| Loans due from consolidated affiliates | 943 |  |  | 16 |  |  | — |  |  | (959 | ) |  | — |  |
| Other non-current assets | 182 |  |  | 29 |  |  | 431 |  |  | — |  |  | 642 |  |
| Total assets | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 279 |  |  | $ | 1,986 |  |  | $ | — |  |  | $ | 2,265 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 259 |  |  | — |  |  | 259 |  |
| Intercompany payables | 1,066 |  |  | 4,648 |  |  | 3,119 |  |  | (8,833 | ) |  | — |  |
| Accrued expenses | 198 |  |  | 505 |  |  | 571 |  |  | — |  |  | 1,274 |  |
| Accrued compensation | — |  |  | 297 |  |  | 182 |  |  | — |  |  | 479 |  |
| Current portion of long-term debt | 179 |  |  | — |  |  | — |  |  | — |  |  | 179 |  |
| Total current liabilities | 1,443 |  |  | 5,729 |  |  | 6,117 |  |  | (8,833 | ) |  | 4,456 |  |
| Long-term debt | 10,962 |  |  | — |  |  | 31 |  |  | — |  |  | 10,993 |  |
| Loans due to consolidated affiliates | — |  |  | 427 |  |  | 532 |  |  | (959 | ) |  | — |  |
| Other liabilities | (1 | ) |  | 1,768 |  |  | 488 |  |  | — |  |  | 2,255 |  |
| Total liabilities | 12,404 |  |  | 7,924 |  |  | 7,168 |  |  | (9,792 | ) |  | 17,704 |  |
| Total shareholders’ equity | 11,531 |  |  | 20,998 |  |  | 19,947 |  |  | (40,945 | ) |  | 11,531 |  |
| Total liabilities and shareholders’ equity | $ | 23,935 |  |  | $ | 28,922 |  |  | $ | 27,115 |  |  | $ | (50,737 | ) |  | $ | 29,235 |  |

[0000106040-18-000029:notes:343]
| Condensed Consolidating Balance Sheet |
| As of June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 18 |  |  | $ | 1,212 |  |  | $ | 5,124 |  |  | $ | — |  |  | $ | 6,354 |  |
| Accounts receivable, net | — |  |  | 1,247 |  |  | 701 |  |  | — |  |  | 1,948 |  |
| Intercompany receivables | 1,225 |  |  | 2,528 |  |  | 622 |  |  | (4,375 | ) |  | — |  |
| Inventories | — |  |  | 1,133 |  |  | 1,494 |  |  | (286 | ) |  | 2,341 |  |
| Other current assets | 4 |  |  | 158 |  |  | 245 |  |  | 6 |  |  | 413 |  |
| Total current assets | 1,247 |  |  | 6,278 |  |  | 8,186 |  |  | (4,655 | ) |  | 11,056 |  |
| Property, plant and equipment, net | — |  |  | 1,124 |  |  | 1,909 |  |  | — |  |  | 3,033 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,340 |  |  | — |  |  | 1,340 |  |
| Goodwill | — |  |  | 331 |  |  | 9,683 |  |  | — |  |  | 10,014 |  |
| Other intangible assets, net | — |  |  | 11 |  |  | 3,812 |  |  | — |  |  | 3,823 |  |
| Investments in consolidated subsidiaries | 19,082 |  |  | 17,588 |  |  | — |  |  | (36,670 | ) |  | — |  |
| Loans due from consolidated affiliates | 4,700 |  |  | 16 |  |  | — |  |  | (4,716 | ) |  | — |  |
| Other non-current assets | 51 |  |  | 723 |  |  | 419 |  |  | (599 | ) |  | 594 |  |
| Total assets | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 257 |  |  | $ | 1,887 |  |  | $ | — |  |  | $ | 2,144 |  |
| Accounts payable to Flash Ventures | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Intercompany payables | 270 |  |  | 4,039 |  |  | 66 |  |  | (4,375 | ) |  | — |  |
| Accrued expenses | 270 |  |  | 364 |  |  | 621 |  |  | — |  |  | 1,255 |  |
| Accrued compensation | — |  |  | 313 |  |  | 193 |  |  | — |  |  | 506 |  |
| Current portion of long-term debt | 233 |  |  | — |  |  | — |  |  | — |  |  | 233 |  |
| Total current liabilities | 773 |  |  | 4,973 |  |  | 2,973 |  |  | (4,375 | ) |  | 4,344 |  |
| Long-term debt | 12,889 |  |  | — |  |  | 29 |  |  | — |  |  | 12,918 |  |
| Loans due to consolidated affiliates | — |  |  | 546 |  |  | 4,170 |  |  | (4,716 | ) |  | — |  |
| Other liabilities | — |  |  | 1,243 |  |  | 530 |  |  | (593 | ) |  | 1,180 |  |
| Total liabilities | 13,662 |  |  | 6,762 |  |  | 7,702 |  |  | (9,684 | ) |  | 18,442 |  |
| Total shareholders’ equity | 11,418 |  |  | 19,309 |  |  | 17,647 |  |  | (36,956 | ) |  | 11,418 |  |
| Total liabilities and shareholders’ equity | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-18-000029:notes:344]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (144 | ) |  | $ | 211 |  |  | $ | 4,158 |  |  | $ | (20 | ) |  | $ | 4,205 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (220 | ) |  | (615 | ) |  | — |  |  | (835 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Acquisitions, net of cash acquired | — |  |  | (94 | ) |  | (6 | ) |  | — |  |  | (100 | ) |
| Purchases of investments | — |  |  | (21 | ) |  | (68 | ) |  | — |  |  | (89 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (1,313 | ) |  | — |  |  | (1,313 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 571 |  |  | — |  |  | 571 |  |
| Strategic investments and other, net | — |  |  | (2 | ) |  | 20 |  |  | — |  |  | 18 |  |
| Intercompany loan from consolidated affiliates | 3,757 |  |  | — |  |  | — |  |  | (3,757 | ) |  | — |  |
| Advances from (to) parent and consolidated affiliates | (86 | ) |  | 86 |  |  | — |  |  | — |  |  | — |  |
| Net cash provided by (used in) investing activities | 3,671 |  |  | (251 | ) |  | (1,318 | ) |  | (3,757 | ) |  | (1,655 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 220 |  |  | — |  |  | — |  |  | — |  |  | 220 |  |
| Taxes paid on vested stock awards under employee stock plans | (171 | ) |  | — |  |  | — |  |  | — |  |  | (171 | ) |
| Repurchases of common stock | (591 | ) |  | — |  |  | — |  |  | — |  |  | (591 | ) |
| Dividends paid to shareholders | (593 | ) |  | — |  |  | — |  |  | — |  |  | (593 | ) |
| Settlement of debt hedge contracts | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Repayment of debt and premiums | (17,074 | ) |  | — |  |  | — |  |  | — |  |  | (17,074 | ) |
| Proceeds from debt | 13,840 |  |  | — |  |  | — |  |  | — |  |  | 13,840 |  |
| Proceeds from (repayment of) revolving credit facility | 500 |  |  | — |  |  | — |  |  | — |  |  | 500 |  |
| Debt issuance costs | (59 | ) |  | — |  |  | — |  |  | — |  |  | (59 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (119 | ) |  | (3,638 | ) |  | 3,757 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 395 |  |  | (385 | ) |  | (30 | ) |  | 20 |  |  | — |  |
| Net cash used in financing activities | (3,505 | ) |  | (504 | ) |  | (3,668 | ) |  | 3,777 |  |  | (3,900 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 22 |  |  | (544 | ) |  | (827 | ) |  | — |  |  | (1,349 | ) |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of year | $ | 40 |  |  | $ | 668 |  |  | $ | 4,297 |  |  | $ | — |  |  | $ | 5,005 |  |

[0000106040-18-000029:notes:345]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (360 | ) |  | $ | (836 | ) |  | $ | 4,593 |  |  | $ | 40 |  |  | $ | 3,437 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (240 | ) |  | (338 | ) |  | — |  |  | (578 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Purchases of investments | — |  |  | — |  |  | (281 | ) |  | — |  |  | (281 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 94 |  |  | — |  |  | 94 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 417 |  |  | — |  |  | 417 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (549 | ) |  | — |  |  | (549 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 292 |  |  | — |  |  | 292 |  |
| Strategic investments and other, net | — |  |  | (1 | ) |  | (31 | ) |  | — |  |  | (32 | ) |
| Intercompany loans from consolidated affiliates | 1,300 |  |  | 39 |  |  | — |  |  | (1,339 | ) |  | — |  |
| Advances from (to) consolidated affiliates | (158 | ) |  | 166 |  |  | — |  |  | (8 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 1,142 |  |  | (36 | ) |  | (395 | ) |  | (1,347 | ) |  | (636 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 235 |  |  | — |  |  | — |  |  | — |  |  | 235 |  |
| Taxes paid on vested stock awards under employee stock plans | (124 | ) |  | — |  |  | — |  |  | — |  |  | (124 | ) |
| Excess tax benefits from employee stock plans | 119 |  |  | — |  |  | — |  |  | — |  |  | 119 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Settlement of convertible debt | — |  |  | — |  |  | (492 | ) |  | — |  |  | (492 | ) |
| Dividends paid to shareholders | (574 | ) |  | — |  |  | — |  |  | — |  |  | (574 | ) |
| Settlement of debt hedge contracts | — |  |  | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Repayment of debt and premiums | (8,702 | ) |  | (2,995 | ) |  | — |  |  | — |  |  | (11,697 | ) |
| Proceeds from debt | 7,908 |  |  | — |  |  | — |  |  | — |  |  | 7,908 |  |
| Debt issuance costs | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Intercompany loan to consolidated affiliates | — |  |  | (5,454 | ) |  | 4,115 |  |  | 1,339 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 384 |  |  | 9,348 |  |  | (9,700 | ) |  | (32 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (764 | ) |  | 878 |  |  | (6,016 | ) |  | 1,307 |  |  | (4,595 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents | 18 |  |  | 6 |  |  | (1,821 | ) |  | — |  |  | (1,797 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of year | $ | 18 |  |  | $ | 1,212 |  |  | $ | 5,124 |  |  | $ | — |  |  | $ | 6,354 |  |

[0000106040-18-000029:notes:346]
| Condensed Consolidating Statement of Cash Flows |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | (210 | ) |  | $ | 1,018 |  |  | $ | 1,299 |  |  | $ | (124 | ) |  | $ | 1,983 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (233 | ) |  | (351 | ) |  | — |  |  | (584 | ) |
| Acquisitions, net of cash acquired | — |  |  | (13,767 | ) |  | 3,932 |  |  | — |  |  | (9,835 | ) |
| Purchases of investments | — |  |  | — |  |  | (632 | ) |  | — |  |  | (632 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 1,204 |  |  | — |  |  | 1,204 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 405 |  |  | — |  |  | 405 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (106 | ) |  | — |  |  | (106 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Strategic investments and other, net | (34 | ) |  | (10 | ) |  | (32 | ) |  | — |  |  | (76 | ) |
| Intercompany loans from (to) consolidated affiliates | (6,000 | ) |  | 40 |  |  | — |  |  | 5,960 |  |  | — |  |
| Advances to consolidated affiliates | (8,845 | ) |  | (96 | ) |  | (229 | ) |  | 9,170 |  |  | — |  |
| Net cash provided by (used in) investing activities | (14,879 | ) |  | (14,066 | ) |  | 4,207 |  |  | 15,130 |  |  | (9,608 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 117 |  |  | — |  |  | — |  |  | — |  |  | 117 |  |
| Taxes paid on vested stock awards under employee stock plans | (50 | ) |  | — |  |  | — |  |  | — |  |  | (50 | ) |
| Excess tax benefits from employee stock plans | 7 |  |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 409 |  |  | — |  |  | 409 |  |
| Settlement of convertible debt | — |  |  | — |  |  | (2,611 | ) |  | — |  |  | (2,611 | ) |
| Repurchases of common stock | (60 | ) |  | — |  |  | — |  |  | — |  |  | (60 | ) |
| Dividends paid to shareholders | (464 | ) |  | — |  |  | — |  |  | — |  |  | (464 | ) |
| Repayment of debt | — |  |  | (2,313 | ) |  | — |  |  | — |  |  | (2,313 | ) |
| Proceeds from debt | 14,108 |  |  | 3,000 |  |  | — |  |  | — |  |  | 17,108 |  |
| Proceeds from (repayment of) revolving credit facility | — |  |  | — |  |  | (255 | ) |  | — |  |  | (255 | ) |
| Debt issuance costs | (497 | ) |  | (27 | ) |  | — |  |  | — |  |  | (524 | ) |
| Payment upon settlement of acquired warrants | — |  |  | — |  |  | (613 | ) |  | — |  |  | (613 | ) |
| Intercompany loan from (to) consolidated affiliates | — |  |  | 6,000 |  |  | (40 | ) |  | (5,960 | ) |  | — |  |
| Change in investment in consolidated subsidiaries | 1,928 |  |  | 6,933 |  |  | 185 |  |  | (9,046 | ) |  | — |  |
| Net cash provided by (used in) financing activities | 15,089 |  |  | 13,593 |  |  | (2,925 | ) |  | (15,006 | ) |  | 10,751 |  |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | — |  |  | 545 |  |  | 2,582 |  |  | — |  |  | 3,127 |  |
| Cash and cash equivalents, beginning of year | — |  |  | 661 |  |  | 4,363 |  |  | — |  |  | 5,024 |  |
| Cash and cash equivalents, end of year | $ | — |  |  | $ | 1,206 |  |  | $ | 6,945 |  |  | $ | — |  |  | $ | 8,151 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-18-000029:notes:347]
Separate Financial Information of Guarantor Subsidiaries

[0000106040-18-000029:notes:348]
The 2026 Senior Unsecured Notes are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by certain 100% owned material domestic subsidiaries of the Company (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the 2026 Senior Unsecured Notes, (ii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the 2026 Senior Unsecured Notes, (iii) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (iv) the Company’s exercise of its defeasance options under the indenture governing the 2026 Senior Unsecured Notes, (v) the dissolution or liquidation of a Guarantor Subsidiary or (vi) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the 2026 Senior Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-18-000029:notes:349]
| Condensed Consolidating Statement of Operations |
| For the year ended June 29, 2018 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,913 |  |  | $ | 20,155 |  |  | $ | (14,421 | ) |  | $ | 20,647 |  |
| Cost of revenue | — |  |  | 12,913 |  |  | 14,573 |  |  | (14,544 | ) |  | 12,942 |  |
| Gross profit | — |  |  | 2,000 |  |  | 5,582 |  |  | 123 |  |  | 7,705 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,551 |  |  | 849 |  |  | — |  |  | 2,400 |  |
| Selling, general and administrative | 8 |  |  | 1,044 |  |  | 421 |  |  | — |  |  | 1,473 |  |
| Intercompany operating expense (income) | — |  |  | (1,626 | ) |  | 1,626 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | 1 |  |  | 47 |  |  | 167 |  |  | — |  |  | 215 |  |
| Total operating expenses | 9 |  |  | 1,016 |  |  | 3,063 |  |  | — |  |  | 4,088 |  |
| Operating income (loss) | (9 | ) |  | 984 |  |  | 2,519 |  |  | 123 |  |  | 3,617 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 211 |  |  | 8 |  |  | 51 |  |  | (210 | ) |  | 60 |  |
| Interest expense | (674 | ) |  | (21 | ) |  | (191 | ) |  | 210 |  |  | (676 | ) |
| Other expense, net | (905 | ) |  | (9 | ) |  | (2 | ) |  | — |  |  | (916 | ) |
| Total interest and other expense, net | (1,368 | ) |  | (22 | ) |  | (142 | ) |  | — |  |  | (1,532 | ) |
| Income (loss) before taxes | (1,377 | ) |  | 962 |  |  | 2,377 |  |  | 123 |  |  | 2,085 |  |
| Income tax expense (benefit) | (354 | ) |  | 1,633 |  |  | 131 |  |  | — |  |  | 1,410 |  |
| Equity in earnings from subsidiaries | 1,698 |  |  | 2,223 |  |  | — |  |  | (3,921 | ) |  | — |  |
| Net income | $ | 675 |  |  | $ | 1,552 |  |  | $ | 2,246 |  |  | $ | (3,798 | ) |  | $ | 675 |  |

[0000106040-18-000029:notes:350]
| Condensed Consolidating Statement of Operations |
| For the year ended June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 14,732 |  |  | $ | 16,381 |  |  | $ | (12,020 | ) |  | $ | 19,093 |  |
| Cost of revenue | — |  |  | 12,786 |  |  | 12,203 |  |  | (11,968 | ) |  | 13,021 |  |
| Gross profit | — |  |  | 1,946 |  |  | 4,178 |  |  | (52 | ) |  | 6,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,619 |  |  | 822 |  |  | — |  |  | 2,441 |  |
| Selling, general and administrative | 6 |  |  | 1,006 |  |  | 433 |  |  | — |  |  | 1,445 |  |
| Intercompany operating expense (income) | — |  |  | (1,736 | ) |  | 1,736 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 88 |  |  | 144 |  |  | — |  |  | 232 |  |
| Total operating expenses | 6 |  |  | 977 |  |  | 3,135 |  |  | — |  |  | 4,118 |  |
| Operating income (loss) | (6 | ) |  | 969 |  |  | 1,043 |  |  | (52 | ) |  | 1,954 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 347 |  |  | 11 |  |  | 22 |  |  | (354 | ) |  | 26 |  |
| Interest expense | (843 | ) |  | (10 | ) |  | (348 | ) |  | 354 |  |  | (847 | ) |
| Other income (expense), net | (290 | ) |  | 49 |  |  | (61 | ) |  | (62 | ) |  | (364 | ) |
| Total interest and other income (expense), net | (786 | ) |  | 50 |  |  | (387 | ) |  | (62 | ) |  | (1,185 | ) |
| Income (loss) before taxes | (792 | ) |  | 1,019 |  |  | 656 |  |  | (114 | ) |  | 769 |  |
| Income tax expense (benefit) | (282 | ) |  | 259 |  |  | 395 |  |  | — |  |  | 372 |  |
| Equity in earnings from subsidiaries | 907 |  |  | 287 |  |  | — |  |  | (1,194 | ) |  | — |  |
| Net income | $ | 397 |  |  | $ | 1,047 |  |  | $ | 261 |  |  | $ | (1,308 | ) |  | $ | 397 |  |

[0000106040-18-000029:notes:351]
| Condensed Consolidating Statement of Operations |
| For the year ended July 1, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 12,600 |  |  | $ | 13,285 |  |  | $ | (12,891 | ) |  | $ | 12,994 |  |
| Cost of revenue | — |  |  | 11,796 |  |  | 10,662 |  |  | (12,899 | ) |  | 9,559 |  |
| Gross profit | — |  |  | 804 |  |  | 2,623 |  |  | 8 |  |  | 3,435 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 1,095 |  |  | 532 |  |  | — |  |  | 1,627 |  |
| Selling, general and administrative | 4 |  |  | 645 |  |  | 348 |  |  | — |  |  | 997 |  |
| Intercompany operating expense (income) | — |  |  | (1,087 | ) |  | 1,087 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 105 |  |  | 240 |  |  | — |  |  | 345 |  |
| Total operating expenses | 4 |  |  | 758 |  |  | 2,207 |  |  | — |  |  | 2,969 |  |
| Operating income (loss) | (4 | ) |  | 46 |  |  | 416 |  |  | 8 |  |  | 466 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 54 |  |  | 2 |  |  | 24 |  |  | (54 | ) |  | 26 |  |
| Interest expense | (184 | ) |  | (128 | ) |  | (8 | ) |  | 54 |  |  | (266 | ) |
| Other income (expense), net | 11 |  |  | (30 | ) |  | (54 | ) |  | — |  |  | (73 | ) |
| Total interest and other expense, net | (119 | ) |  | (156 | ) |  | (38 | ) |  | — |  |  | (313 | ) |
| Income (loss) before taxes | (123 | ) |  | (110 | ) |  | 378 |  |  | 8 |  |  | 153 |  |
| Income tax benefit | (44 | ) |  | (27 | ) |  | (18 | ) |  | — |  |  | (89 | ) |
| Equity in earnings from subsidiaries | 321 |  |  | 400 |  |  | — |  |  | (721 | ) |  | — |  |
| Net income | $ | 242 |  |  | $ | 317 |  |  | $ | 396 |  |  | $ | (713 | ) |  | $ | 242 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-18-000029:notes:352]
|  | June 29, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,048 |  |  | $ | 646 |  |
| Work-in-process | 878 |  |  | 632 |  |
| Finished goods | 1,018 |  |  | 1,063 |  |
| Total inventories | $ | 2,944 |  |  | $ | 2,341 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-18-000029:notes:353]
Product warranty liability

[0000106040-18-000029:notes:354]
Changes in the warranty accrual were as follows:

[0000106040-18-000029:notes:355]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 311 |  |  | $ | 279 |  |  | $ | 221 |  |
| Warranty liabilities assumed as a result of acquisitions | — |  |  | — |  |  | 45 |  |
| Charges to operations | 176 |  |  | 177 |  |  | 162 |  |
| Utilization | (151 | ) |  | (151 | ) |  | (178 | ) |
| Changes in estimate related to pre-existing warranties | (18 | ) |  | 6 |  |  | 29 |  |
| Warranty accrual, end of period | $ | 318 |  |  | $ | 311 |  |  | $ | 279 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-18-000029:notes:356]
The following table presents an analysis of the components of the restructuring charges, payments and adjustments made against the reserve as of June 29, 2018:

[0000106040-18-000029:notes:357]
|  | Employee Termination Benefits |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | — |  |
| Charges | 56 |  |
| Accrual balance at June 29, 2018 | $ | 56 |  |

[0000106040-18-000029:notes:358]
The following table presents an analysis of the components of the activity against the reserve during the year ended June 29, 2018:

[0000106040-18-000029:notes:359]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 11 |  |  | $ | 2 |  |  | $ | 13 |  |
| Charges | 68 |  |  | 24 |  |  | 92 |  |
| Cash payments | (74 | ) |  | (23 | ) |  | (97 | ) |
| Non-cash items and other | — |  |  | (1 | ) |  | (1 | ) |
| Accrual balance at June 29, 2018 | $ | 5 |  |  | $ | 2 |  |  | $ | 7 |  |

[0000106040-18-000029:notes:360]
The Company recorded the following charges related to employee terminations benefits, asset impairment, and other charges:

[0000106040-18-000029:notes:361]
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |
| Restructuring Plan 2016 | $ | 92 |  |  | $ | 128 |  |  | $ | 77 |  |
| Closure of Foreign Manufacturing Facilities | 56 |  |  | 10 |  |  | 128 |  |
| Business Realignment | 50 |  |  | 72 |  |  | 94 |  |
| Total employee termination and other charges | 198 |  |  | 210 |  |  | 299 |  |
| Stock-based compensation accelerations and adjustments |  |  |  |  |  |
| Business Realignment | 1 |  |  | 11 |  |  | 9 |  |
| Total stock-based compensation accelerations and adjustments | 1 |  |  | 11 |  |  | 9 |  |
| Asset impairment: |  |  |  |  |  |
| Restructuring Plan 2016 | 16 |  |  | — |  |  | 5 |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 11 |  |  | 24 |  |
| Business Realignment | — |  |  | — |  |  | 8 |  |
| Total asset impairment | 16 |  |  | 11 |  |  | 37 |  |
| Total employee termination and other charges, and stock-based compensation accelerations and adjustments | $ | 215 |  |  | $ | 232 |  |  | $ | 345 |  |

[0000106040-18-000029:notes:362]
The following table presents an analysis of the components of the activity against the reserve:

[0000106040-18-000029:notes:363]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 18 |  |  | $ | 5 |  |  | $ | 23 |  |
| Charges | 43 |  |  | 7 |  |  | 50 |  |
| Cash payments | (29 | ) |  | (6 | ) |  | (35 | ) |
| Non-cash items and other | (1 | ) |  | (1 | ) |  | (2 | ) |
| Accrual balance at June 29, 2018 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-18-000029:notes:364]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-18-000029:notes:365]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 3, 2015 | 6.8 |  |  | $ | 50.00 |  |  |  |  |  |
| Granted | 1.7 |  |  | 82.68 |  |  |  |  |  |
| Assumed | 2.9 |  |  | 38.37 |  |  |  |  |  |
| Exercised | (1.7 | ) |  | 27.43 |  |  |  |  | $ | 57 |  |
| Canceled or expired | (0.7 | ) |  | 66.03 |  |  |  |  |  |
| Options outstanding at July 1, 2016 | 9.0 |  |  | 55.74 |  |  |  |  |  |
| Granted | 2.8 |  |  | 44.83 |  |  |  |  |  |
| Exercised | (3.5 | ) |  | 37.72 |  |  |  |  | 120 |  |
| Canceled or expired | (0.9 | ) |  | 71.31 |  |  |  |  |  |
| Options outstanding at June 30, 2017 | 7.4 |  |  | $ | 58.14 |  |  |  |  |  |
| Exercised | (2.2 | ) |  | 44.52 |  |  |  |  | $ | 99 |  |
| Canceled or expired | (0.4 | ) |  | 60.85 |  |  |  |  |  |
| Options outstanding at June 29, 2018 | 4.8 |  |  | $ | 64.23 |  |  | 3.7 |  | $ | 94 |  |
| Exercisable at June 29, 2018 | 3.0 |  |  | $ | 70.70 |  |  | 3.1 |  | $ | 47 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000106040-18-000029:notes:366]
The fair values of all outstanding ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-18-000029:notes:367]
|  | 2018 |  | 2017 |  | 2016 |
| Weighted-average expected term (in years) | 1.24 |  | 1.26 |  | 1.27 |
| Risk-free interest rate | 2.25% |  | 0.81% |  | 0.82% |
| Stock price volatility | 0.35 |  | 0.42 |  | 0.38 |
| Dividend yield | 2.42% |  | 4.02% |  | 3.92% |
| Fair value | $16.89 |  | $10.06 |  | $9.91 |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000106040-18-000029:notes:368]
The fair value of stock options granted in 2017 and 2016 was estimated using the following weighted average assumptions:

[0000106040-18-000029:notes:369]
|  | 2017 |  | 2016 |
| Suboptimal exercise factor | 2.69 |  | 2.71 |
| Range of risk-free interest rates | 0.59% to 1.42% |  | 0.25% to 2.09% |
| Range of expected stock price volatility | 0.35 to 0.49 |  | 0.28 to 0.49 |
| Weighted-average expected volatility | 0.40 |  | 0.35 |
| Post-vesting termination rate | 1.71% |  | 0.47% |
| Dividend yield | 3.42% |  | 2.61% |
| Fair value | $13.72 |  | $22.54 |
| Weighted-average expected term (in years) | 3.6 |  | 4.7 |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-18-000029:notes:370]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-18-000029:notes:371]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 3, 2015 | 3.0 |  |  | $ | 73.80 |  |  |  |
| Granted | 2.7 |  |  | 61.32 |  |  |  |
| Assumed | 12.5 |  |  | 32.14 |  |  |  |
| Vested | (2.0 | ) |  | 56.11 |  |  | $ | 144 |  |
| Forfeited | (0.5 | ) |  | 62.09 |  |  |  |
| RSUs and PSUs outstanding at July 1, 2016 | 15.7 |  |  | 41.92 |  |  |  |
| Granted | 6.0 |  |  | 44.13 |  |  |  |
| Vested | (5.9 | ) |  | 46.98 |  |  | 399 |  |
| Forfeited | (2.1 | ) |  | 43.89 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | $ | 45.01 |  |  |  |
| Granted | 6.3 |  |  | 74.68 |  |  |  |
| Vested | (6.3 | ) |  | 45.20 |  |  | $ | 552 |  |
| Forfeited | (1.1 | ) |  | 50.35 |  |  |  |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | $ | 58.31 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-18-000029:notes:372]
Shareholders’ Equity

[0000106040-18-000029:notes:373]
2017 Performance Incentive Plan

[0000106040-18-000029:notes:374]
The types of awards that may be granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (“2017 Performance Incentive Plan”) include stock options, SARs, RSUs, PSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2017 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2017 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2017 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2017 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance metrics and completion of requisite service periods. Once the performance metrics are met, vesting of PSUs is generally subject to continued service by the employee. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-18-000029:notes:375]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-18-000029:notes:376]
As of June 29, 2018, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2017 Performance Incentive Plan was 80.5 million shares. Shares issued in respect of stock options and SARs granted under the 2017 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas currently, shares issued in respect of any other type of award granted count against the plan’s share limit as 1.72 shares for every one share issued in connection with such award. The 2017 Performance Incentive Plan was extended in 2013 and will terminate on August 4, 2025 unless terminated earlier by the Company’s Board of Directors (the “Board”).

[0000106040-18-000029:notes:377]
Employee Stock Purchase Plan

[0000106040-18-000029:notes:378]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock on either the first day of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-18-000029:notes:379]
During 2018, 2017 and 2016, the Company issued 2.5 million, 2.3 million, and 1.3 million shares, respectively, for aggregate purchase amounts of $119 million, $105 million, and $68 million, respectively.

[0000106040-18-000029:notes:380]
Stock-based Compensation Expense

[0000106040-18-000029:notes:381]
Compensation cost related to unvested stock options, RSU, PSU and ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 29, 2018:

[0000106040-18-000029:notes:382]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 25 |  |  | 1.8 |
| RSUs and PSUs (1) | 464 |  |  | 2.1 |
| ESPP | 51 |  |  | 1.5 |
| Total unamortized compensation cost | $ | 540 |  |  |  |

[0000106040-18-000029:notes:383]
| (1) | Weighted average service period assumes the performance metrics are met for the PSUs. |

[0000106040-18-000029:notes:384]
Plan Activities

[0000106040-18-000029:notes:385]
Stock Options

[0000106040-18-000029:notes:386]
RSUs and PSUs

[0000106040-18-000029:notes:387]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-18-000029:notes:388]
Fair Value Valuation Assumptions

[0000106040-18-000029:notes:389]
Stock Option Grants — Binomial Model

[0000106040-18-000029:notes:390]
The fair value of stock options granted is estimated using a binomial option-pricing model. The binomial model requires the input of highly subjective assumptions. The Company uses historical data to estimate exercise, employee termination and expected stock price volatility within the binomial model. The risk-free rate for periods within the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. No options were granted in 2018. The fair value of stock options granted in 2017 and 2016 was estimated using the following weighted average assumptions:

[0000106040-18-000029:notes:391]
RSU and PSU Grants

[0000106040-18-000029:notes:392]
The fair value of the Company’s RSU and PSU awards granted, excluding unvested RSU awards assumed through acquisitions, was based upon the closing price of the Company’s stock price on the date of grant.

[0000106040-18-000029:notes:393]
ESPP — Black-Scholes-Merton Model

[0000106040-18-000029:notes:394]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-18-000029:notes:395]
Stock Repurchase Program

[0000106040-18-000029:notes:396]
The Company’s Board of Directors previously authorized $5.00 billion for the repurchase of the Company’s common stock. In 2018, the Company repurchased 7.1 million shares for a total cost of $591 million. Subsequent to June 29, 2018 and through July 25, 2018, the Company repurchased an additional 0.8 million shares for a total cost of $61 million. On July 25, 2018, the Company’s Board of Directors authorized a new $5.00 billion share repurchase program that is effective through July 25, 2023, replacing all prior programs. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows. Subsequent to July 25, 2018 and through August 22, 2018, the Company repurchased an additional 5.9 million shares for a total cost of $404 million under this new program.

[0000106040-18-000029:notes:397]
Stock Reserved for Issuance

[0000106040-18-000029:notes:398]
The following table summarizes all common stock reserved for issuance at June 29, 2018:

[0000106040-18-000029:notes:399]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 36 |  |
| ESPP | 5 |  |
| Total | 41 |  |

[0000106040-18-000029:notes:400]
Dividends to Shareholders

[0000106040-18-000029:notes:401]
Since the first quarter of 2013, the Company has issued a quarterly cash dividend. During the year ended June 29, 2018, the Company declared aggregate cash dividends of $2.00 per share on its outstanding common stock totaling $592 million, of which $148 million was paid on July 16, 2018.

[0000106040-18-000029:notes:402]
On August 1, 2018, the Board declared a cash dividend of $0.50 per share to shareholders of record as of September 28, 2018, which will be paid on October 15, 2018. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-18-000029:notes:403]
Supplemental Financial Statement Data

[0000106040-18-000029:notes:404]
Accounts receivable, net

[0000106040-18-000029:notes:405]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During 2018, the Company sold trade accounts receivable and received cash proceeds of $57 million. The discounts on the trade accounts receivable sold during 2018 were not material and were recorded within Other expense, net in the Consolidated Financial Statements. During 2017, the Company did not sell any trade accounts receivable.

[0000106040-18-000029:notes:406]
Depreciation expense of property, plant, and equipment totaled $871 million, $960 million and $888 million in 2018, 2017 and 2016, respectively.

[0000106040-18-000029:notes:407]
In 2018, the Company updated its estimate of the timing of its expected expenditures for warranty obligations resulting in a reclassification from current to long-term warranty obligations. The current portion of the warranty accrual classified in Accrued expenses was $168 million and $186 million as of June 29, 2018 and June 30, 2017, respectively, with the long-term portion of $150 million and $125 million, respectively, classified in Other liabilities.

[0000106040-18-000029:notes:408]
Accumulated other comprehensive income (loss)

[0000106040-18-000029:notes:409]
Other comprehensive income (“OCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss) (“AOCI”):


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-18-000029:notes:410]
Employee Termination, Asset Impairment and Other Charges

[0000106040-18-000029:notes:411]
Restructuring Plan 2016

[0000106040-18-000029:notes:412]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 as presented above, the Company recognized $9 million and $65 million of accelerated depreciation on facility assets in cost of revenue during the year ended June 29, 2018 and June 30, 2017, respectively.

[0000106040-18-000029:notes:413]
Closure of Foreign Manufacturing Facilities

[0000106040-18-000029:notes:414]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company expects the closure to be substantially completed by the end of the calendar year 2019 and to result in total pre-tax charges of approximately $160 million.  These charges are expected to consist of approximately $85 million in employee termination benefits and $75 million in asset-related, contract termination and other charges. During the year ended June 29, 2018, the Company recognized $56 million in employee termination benefits within Employee termination, asset impairment and other charges in the Consolidated Statements of Operations.

[0000106040-18-000029:notes:415]
The Company incurred charges of $10 million and $128 million in 2017 and 2016, respectively, related to the closure of its head component front end wafer manufacturing facility in Odawara, Japan. As of June 29, 2018, the Company had completed all activities related to the closure of the facility.

[0000106040-18-000029:notes:416]
Business Realignment

[0000106040-18-000029:notes:417]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve:
