# WDC note change history — 0000106040-18-000010 → 0000106040-18-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-05-08):
[0000106040-18-000016:note_history:1]
In connection with a settlement agreement with Toshiba in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of the parties’ existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6.

- changed (2018-05-08):
[0000106040-18-000016:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 30, 2018 and June 30, 2017:
  (was, 2018-02-06, similarity 0.965):
[0000106040-18-000010:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 29, 2017 and June 30, 2017:

- changed (2018-05-08):
[0000106040-18-000016:note_history:3]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 838 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 76 |  |  | 119 |  |
| Notes receivable, Flash Forward | 633 |  |  | 379 |  |
| Investment in Flash Partners | 198 |  |  | 187 |  |
| Investment in Flash Alliance | 295 |  |  | 279 |  |
| Investment in Flash Forward | 120 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,160 |  |  | $ | 1,340 |  |
  (was, 2018-02-06, similarity 0.985):
[0000106040-18-000010:note_history:3]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 101 |  |  | 119 |  |
| Notes receivable, Flash Forward | 429 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 279 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,845 |  |  | $ | 1,340 |  |

- changed (2018-05-08):
[0000106040-18-000016:note_history:4]
During the three and nine months ended March 30, 2018, the Company made net payments to Flash Ventures of $1.00 billion and $3.0 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2018-02-06, similarity 0.9643):
[0000106040-18-000010:note_history:4]
During the three and six months ended December 29, 2017, the Company made net payments to Flash Ventures of $1.2 billion and $2.0 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2018-05-08):
[0000106040-18-000016:note_history:5]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. There were no impairments for credit worthiness in the three and nine months ended March 30, 2018 and March 31, 2017.
  (was, 2018-02-06, similarity 0.6134):
[0000106040-18-000010:note_history:5]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no such impairments in the three and six months ended December 29, 2017 and December 30, 2016.

- changed (2018-05-08):
[0000106040-18-000016:note_history:6]
As of March 30, 2018 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $282 million and $206 million, respectively.
  (was, 2018-02-06, similarity 0.9673):
[0000106040-18-000010:note_history:6]
As of December 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $250 million and $206 million, respectively.

- changed (2018-05-08):
[0000106040-18-000016:note_history:7]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 30, 2018, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2018-02-06, similarity 0.9839):
[0000106040-18-000010:note_history:7]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2018-05-08):
[0000106040-18-000016:note_history:8]
|  | March 30, 2018 |
| Notes receivable | $ | 1,547 |  |
| Equity investments | 613 |  |
| Operating lease guarantees | 1,109 |  |
| Inventory and prepayments | 319 |  |
| Maximum estimable loss exposure | $ | 3,588 |  |
  (was, 2018-02-06, similarity 0.977):
[0000106040-18-000010:note_history:8]
|  | December 29, 2017 |
| Notes receivable | $ | 1,267 |  |
| Equity investments | 578 |  |
| Operating lease guarantees | 941 |  |
| Inventory and prepayments | 268 |  |
| Maximum estimable loss exposure | $ | 3,054 |  |

- changed (2018-05-08):
[0000106040-18-000016:note_history:9]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.
  (was, 2018-02-06, similarity 0.9583):
[0000106040-18-000010:note_history:9]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

- changed (2018-05-08):
[0000106040-18-000016:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018.
  (was, 2018-02-06, similarity 0.9785):
[0000106040-18-000010:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017.

- changed (2018-05-08):
[0000106040-18-000016:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 30, 2018 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 30, 2018:
  (was, 2018-02-06, similarity 0.9639):
[0000106040-18-000010:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 29, 2017:

- changed (2018-05-08):
[0000106040-18-000016:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 307 |  |  | $ | 15 |  |  | $ | 322 |  |
| Year 2 |  | 212 |  |  | 40 |  |  | 252 |  |
| Year 3 |  | 188 |  |  | 116 |  |  | 304 |  |
| Year 4 |  | 94 |  |  | 81 |  |  | 175 |  |
| Year 5 |  | 24 |  |  | — |  |  | 24 |  |
| Year 6 |  | 3 |  |  | 29 |  |  | 32 |  |
| Total guarantee obligations |  | $ | 828 |  |  | $ | 281 |  |  | $ | 1,109 |  |
  (was, 2018-02-06, similarity 0.7075):
[0000106040-18-000010:note_history:12]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 267 |  |  | $ | — |  |  | $ | 267 |  |
| Year 2 |  | 178 |  |  | 34 |  |  | 212 |  |
| Year 3 |  | 163 |  |  | 85 |  |  | 248 |  |
| Year 4 |  | 80 |  |  | 98 |  |  | 178 |  |
| Year 5 |  | 15 |  |  | 21 |  |  | 36 |  |
| Total guarantee obligations |  | $ | 703 |  |  | $ | 238 |  |  | $ | 941 |  |

- changed (2018-05-08):
[0000106040-18-000016:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 30, 2018, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2018-02-06, similarity 0.9872):
[0000106040-18-000010:note_history:13]
The Company and TMC have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- removed (2018-05-08):
[0000106040-18-000010:note_history:14]
In connection with a settlement agreement with Toshiba, in December 2017, the Company entered into a facility agreement (“Y6 Facility Agreement”) with TMC related to the construction and operation of a new 300-millimeter wafer fabrication facility in Yokkaichi, Japan, referred to as “Fab 6”, which is primarily intended to provide cleanroom space to continue the transition of existing 2D NAND manufacturing capacity to BiCS 3D NAND manufacturing capacity. Under the Y6 Facility Agreement, the Company is committed to 50% of Fab 6’s start-up costs, as well as 50% of the joint ventures’ portion of an upcoming investment in manufacturing equipment for Fab 6. See also Note 13, Legal Proceedings.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000106040-18-000016:note_history:15]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision. In April 2018, Samsung voluntarily dismissed its case against Panasonic and SD-3C with prejudice.
  (was, 2018-02-06, similarity 0.9669):
[0000106040-18-000010:note_history:15]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba Corporation (“Toshiba”), and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.

- changed (2018-05-08):
[0000106040-18-000016:note_history:16]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are brought on behalf of a purported class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.
  (was, 2018-02-06, similarity 0.9945):
[0000106040-18-000010:note_history:16]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

- changed (2018-05-08):
[0000106040-18-000016:note_history:17]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products that it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.
  (was, 2018-02-06, similarity 0.9978):
[0000106040-18-000010:note_history:17]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

- removed (2018-05-08):
[0000106040-18-000010:note_history:18]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. In December 2017, WD and HGST filed an amended notice of appeal with the Federal Circuit with respect to validity. In January 2018, WD, HGST and Convolve entered into a settlement agreement resolving the litigation and agreeing to seek dismissal of all claims and actions between the parties.

- removed (2018-05-08):
[0000106040-18-000010:note_history:19]
Toshiba Matters

- removed (2018-05-08):
[0000106040-18-000010:note_history:20]
In December 2017, the Company entered into a Confidential Settlement and Mutual Release Agreement (the “Toshiba Settlement Agreement”) with Toshiba and TMC. Under the Toshiba Settlement Agreement, the parties agreed to withdraw and seek dismissal of the litigation and arbitration proceedings discussed below.  Further information about the Toshiba Settlement Agreement is set forth below under “Settlement Agreement.”

- removed (2018-05-08):
[0000106040-18-000010:note_history:21]
Proceedings

- removed (2018-05-08):
[0000106040-18-000010:note_history:22]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and TMC in the Tokyo District Court. The petition alleged that the Company engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requested injunctive relief.

- removed (2018-05-08):
[0000106040-18-000010:note_history:23]
In August 2017, the Company received a complaint filed by Toshiba and TMC in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint was based on the same allegations as the petition for provisional disposition.

- removed (2018-05-08):
[0000106040-18-000010:note_history:24]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, TMC, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer.

- removed (2018-05-08):
[0000106040-18-000010:note_history:25]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture (the “Access Restrictions”). SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order, in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. In July 2017, SanDisk LLC amended its request for arbitration to, among other things, add TMC as a defendant.

- removed (2018-05-08):
[0000106040-18-000010:note_history:26]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan. The SanDisk Subsidiaries sought, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.

- removed (2018-05-08):
[0000106040-18-000010:note_history:27]
Settlement Agreement

- removed (2018-05-08):
[0000106040-18-000010:note_history:28]
In December 2017, the Company, the SanDisk Subsidiaries, Toshiba and TMC entered into the Toshiba Settlement Agreement pursuant to which the parties agreed to withdraw and seek dismissal of the proceedings above and mutually release each other from all claims relating to, among other things, (i) the transfer of Toshiba’s equity interests in Flash Ventures to TMC, (ii) the Access Restrictions, (iii) TMC’s decision to invest unilaterally in Phase I of Fab 6 and (iv) the sale of TMC to K.K. Pangea (“Pangea”), which will be owned, as of the closing of the sale, by certain members of a consortium of investors led by Bain Capital (as defined below). In addition, the Company agreed to consent to the transfer of Toshiba’s interests in Flash Ventures to TMC, the assignment of all agreements relating to Flash Ventures by Toshiba to TMC and the sale of TMC to Pangea. Toshiba and TMC have also agreed to end the Access Restrictions. For a period of three years following the closing of the sale of TMC to Pangea, the Company’s consent shall be required for any issuance or transfer of equity securities, voting rights or control in TMC by TMC, Toshiba, Bain Capital or their respective affiliates to certain restricted parties, subject to certain limited exceptions.  Pursuant to the Toshiba Settlement Agreement, the Company and the SanDisk Subsidiaries also entered into certain other agreements with TMC related to the operation of Flash Ventures, including an agreement regarding the construction and operation of Fab 6 and the extension of the term of Flash Alliance.

- removed (2018-05-08):
[0000106040-18-000010:note_history:29]
In December 2017, the Company and the SanDisk Subsidiaries also entered into a Confidential Settlement Agreement and Mutual Release with Bain Capital Private Equity, L.P., BCPE Pangea Cayman, L.P., BCPE Pangea Cayman2, Ltd., Bain Capital Fund XII, L.P., Bain Capital Asia Fund III, L.P. and Pangea (together, “Bain Capital”) on terms substantially similar to the terms of the Toshiba Settlement Agreement, subject to certain transfer restrictions on Bain Capital.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000106040-18-000016:note_history:30]
Debt consisted of the following as of March 30, 2018 and June 30, 2017:
  (was, 2018-02-06, similarity 0.928):
[0000106040-18-000010:note_history:30]
Debt consisted of the following as of December 29, 2017 and June 30, 2017:

- added (2018-05-08):
[0000106040-18-000016:note_history:31]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,022 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,455 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,412 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (212 | ) |  | (205 | ) |
| Subtotal | 11,200 |  |  | 13,151 |  |
| Less current portion of long-term debt | (124 | ) |  | (233 | ) |
| Long-term debt | $ | 11,076 |  |  | $ | 12,918 |  |

- changed (2018-05-08):
[0000106040-18-000016:note_history:32]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |
  (was, 2018-02-06, similarity 0.9627):
[0000106040-18-000010:note_history:32]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |

- added (2018-05-08):
[0000106040-18-000016:note_history:33]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of March 30, 2018, issuance costs of $20 million remained unamortized.

- added (2018-05-08):
[0000106040-18-000016:note_history:34]
In February 2018, the Company also issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by certain material domestic subsidiaries of the Company.

- added (2018-05-08):
[0000106040-18-000016:note_history:35]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of approximately $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events.

- added (2018-05-08):
[0000106040-18-000016:note_history:36]
On or after February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

- added (2018-05-08):
[0000106040-18-000016:note_history:37]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of March 30, 2018, debt discount and issuance cost of $176 million remained unamortized.

- added (2018-05-08):
[0000106040-18-000016:note_history:38]
In February 2018, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to provide for, among other things, (i) the issuance of a new $5.02 billion of term loan A-1 due 2023 (the “Term Loan A-1”), (ii) a new $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), which replaced the Company’s prior $1.50 billion revolving credit facility maturing in 2021, (iii) modifications to the restrictive and financial maintenance covenants, to provide more flexibility and increased incremental debt capacity, (iv) amendments of the applicable varying interest rate margins to be based on the Company’s corporate credit ratings as described in the indenture, and (v) upon the occurrence of certain circumstances, a release of the security and guarantees as well as further covenant flexibility and increased incremental debt capacity. The Company used a portion of the proceeds of the Term Loan A-1 to repay in full its previous variable interest rate Term Loan A in the principal amount of $4.02 billion.

- added (2018-05-08):
[0000106040-18-000016:note_history:39]
The Term Loan A-1 bears interest at a per annum rate equal to, at the Company’s option, either an adjusted London Interbank Offered Rate (“LIBOR”) rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings.  Currently the Company has selected the LIBOR rate option, and the applicable rate was 3.38% as of March 30, 2018. Principal payments are due in quarterly installments of (i) 0.625% per quarter from June 2018 through March 2019 and (ii) 1.25% per quarter from June 2019 through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of March 30, 2018, issuance costs of $9 million remained unamortized.

- added (2018-05-08):
[0000106040-18-000016:note_history:40]
Proceeds of $500 million were drawn under the Revolving Facility and were used to fund a voluntary partial prepayment of the Company’s existing U.S. Dollar denominated term B-3 loans (“U.S. Term Loan B-3”). Loans under the Revolving Facility bear interest, at the Company’s option, at either LIBOR plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.38% as of March 30, 2018. The Company will also pay an unused commitment fee on the Revolving Facility ranging from 0.120% to 0.350% based on the Company’s corporate credit ratings as described in the indenture, with an initial fee of 0.250%.

- added (2018-05-08):
[0000106040-18-000016:note_history:41]
The Term Loan A-1 and the Revolving Facility are unconditionally guaranteed by each of the guarantors under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantees will be automatically suspended upon certain conditions.

- added (2018-05-08):
[0000106040-18-000016:note_history:42]
During the three months ended March 30, 2018, the Company completed the redemption of all of its outstanding 7.375% senior secured notes due 2023 in the aggregate principal amount of $1.875 billion (the “2023 Notes”) and the tender offer and redemption and settlement of all of its outstanding 10.50% senior unsecured notes due 2024 in the aggregate principal amount of $3.350 billion (the “2024 Notes” and collectively with the 2023 Notes, the “Redeemed Notes”), including an aggregate of $720 million of “make-whole” and tender premiums required for the tender offer of the 2024 Notes and the optional redemption of the Redeemed Notes in accordance with the applicable indentures and accrued interest through the applicable redemption dates.

- added (2018-05-08):
[0000106040-18-000016:note_history:43]
In November 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. Additionally, in November 2017, the Company borrowed $2.96 billion under U.S. Term Loan B-3 under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 3.88% as of March 30, 2018. Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. During the three months ended March 30, 2018, the Company funded a voluntary partial prepayment of $500 million, which was allocated towards principal payments. As a result, the Company is not required to make principal payments on the U.S. Term Loan B-3 prior to its maturity date. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of March 30, 2018, issuance costs of $3 million remained unamortized.

- added (2018-05-08):
[0000106040-18-000016:note_history:44]
In connection with the settlements of the various debt instruments described above, the Company recognized an aggregate loss on debt extinguishment of $896 million for the nine months ended March 30, 2018, consisting of $720 million of “make-whole” and tender premiums and $176 million of unamortized issuance costs, of which $894 million was incurred in the three months ended March 30, 2018. In the three and nine months ended March 31, 2017, the Company incurred losses on the extinguishment of debt of $7 million and $274 million, respectively.

- changed (2018-05-08):
[0000106040-18-000016:note_history:45]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of March 30, 2018, the Company was in compliance with all financial covenants. In addition, the Credit Agreement requires the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations. In addition, the indentures governing the 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.
  (was, 2018-02-06, similarity 0.6975):
[0000106040-18-000010:note_history:45]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of December 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

- removed (2018-05-08):
[0000106040-18-000010:note_history:46]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,022 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,955 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 12,237 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (186 | ) |  | (205 | ) |
| Subtotal | 12,051 |  |  | 13,151 |  |
| Less current portion of long-term debt | (274 | ) |  | (233 | ) |
| Long-term debt | $ | 11,777 |  |  | $ | 12,918 |  |

- removed (2018-05-08):
[0000106040-18-000010:note_history:47]
On November 29, 2017, the Company entered into an amendment to the credit agreement entered into on April 29, 2016 (as amended, the “Credit Agreement”), to increase the size of its existing $1.0 billion revolving credit facility by $500 million to $1.5 billion. The term of the revolving credit facility remained unchanged and will mature on April 29, 2021. As of December 29, 2017, there were no borrowings under the revolving credit facility.

- removed (2018-05-08):
[0000106040-18-000010:note_history:48]
On November 17, 2017, the Company settled in full the principal amounts of the Euro Term Loan B-2, plus accrued interest, using cash on hand. On November 8, 2017, the Company borrowed $2.96 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-3”) under its Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-2 previously outstanding under the Credit Agreement. The U.S. Term Loan B-3 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 2.00% or a base rate plus 1.00% (3.57% as of December 29, 2017). Principal payments on U.S. Term Loan B-3 of 0.25% are due quarterly and began on December 29, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-3 issuance costs are amortized to interest expense over the term of the loan and as of December 29, 2017, issuance costs of $3 million remain unamortized. In connection with the settlements of the U.S. Term Loan B-2 and Euro Term Loan B-2, the Company recognized an aggregate loss on debt extinguishment of $2 million consisting of unamortized issuance costs.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000106040-18-000016:note_history:49]
Debt consisted of the following as of March 30, 2018 and June 30, 2017:
  (was, 2018-02-06, similarity 0.928):
[0000106040-18-000010:note_history:49]
Debt consisted of the following as of December 29, 2017 and June 30, 2017:

- added (2018-05-08):
[0000106040-18-000016:note_history:50]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | 35 |  |  | $ | 35 |  |
| Revolving credit facility maturing 2023 | 500 |  |  | — |  |
| Variable interest rate Term Loan A maturing 2021 | — |  |  | 4,125 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 5,022 |  |  | — |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,455 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | — |  |  | 1,875 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | — |  |
| 10.50% senior unsecured notes due 2024 | — |  |  | 3,350 |  |
| 4.750% senior unsecured notes due 2026 | 2,300 |  |  | — |  |
| Total debt | 11,412 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (212 | ) |  | (205 | ) |
| Subtotal | 11,200 |  |  | 13,151 |  |
| Less current portion of long-term debt | (124 | ) |  | (233 | ) |
| Long-term debt | $ | 11,076 |  |  | $ | 12,918 |  |

- changed (2018-05-08):
[0000106040-18-000016:note_history:51]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that date. |
  (was, 2018-02-06, similarity 0.9627):
[0000106040-18-000010:note_history:51]
| (1) | Euro Term Loan B-2 outstanding principal amount as of June 30, 2017 was based upon the Euro to U.S. dollar exchange rate as of that respective date. |

- removed (2018-05-08):
[0000106040-18-000010:note_history:52]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,022 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | — |  |  | 2,970 |  |
| Variable interest rate U.S. Term Loan B-3 maturing 2023 | 2,955 |  |  | — |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | — |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 12,237 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (186 | ) |  | (205 | ) |
| Subtotal | 12,051 |  |  | 13,151 |  |
| Less current portion of long-term debt | (274 | ) |  | (233 | ) |
| Long-term debt | $ | 11,777 |  |  | $ | 12,918 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000106040-18-000016:note_history:53]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 30, 2018 and June 30, 2017:
  (was, 2018-02-06, similarity 0.965):
[0000106040-18-000010:note_history:53]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 29, 2017 and June 30, 2017:

- changed (2018-05-08):
[0000106040-18-000016:note_history:54]
|  | March 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 838 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 76 |  |  | 119 |  |
| Notes receivable, Flash Forward | 633 |  |  | 379 |  |
| Investment in Flash Partners | 198 |  |  | 187 |  |
| Investment in Flash Alliance | 295 |  |  | 279 |  |
| Investment in Flash Forward | 120 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 2,160 |  |  | $ | 1,340 |  |
  (was, 2018-02-06, similarity 0.985):
[0000106040-18-000010:note_history:54]
|  | December 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 737 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 101 |  |  | 119 |  |
| Notes receivable, Flash Forward | 429 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 279 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,845 |  |  | $ | 1,340 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-05-08):
[0000106040-18-000010:note_history:55]
Subsequent Events

- removed (2018-05-08):
[0000106040-18-000010:note_history:56]
In January 2018, the Company announced its planned issuance of $2.30 billion aggregate principal amount of 4.750% senior unsecured notes due 2026 (the “2026 Notes”) and $1.00 billion aggregate principal amount of 1.5% convertible senior notes due 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes will be convertible into cash, shares of the Company’s common stock or a combination thereof, at an initial conversion price of approximately $121.91 per share. The issuance of the 2026 Notes and 2024 Convertible Notes is subject to customary closing conditions.

- removed (2018-05-08):
[0000106040-18-000010:note_history:57]
On January 29, 2018, the Company commenced a cash tender offer with respect to any and all of its outstanding $3.35 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “2024 Unsecured Notes”).  The consideration offered for the 2024 Unsecured Notes is a total consideration of $1,167.25 per $1,000 principal amount, which includes the tender offer consideration of $1,137.25 and an early tender premium of $30.00. On January 30, 2018, the Company delivered a notice of conditional redemption with respect to the 2024 Unsecured Notes, with a March 1, 2018 redemption date.  The redemption of the 2024 Unsecured Notes is conditioned upon the issuance of the 2026 Notes. On January 30, 2018, the Company also delivered a notice of conditional redemption with respect to its outstanding $1.88 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “2023 Secured Notes”), with a March 1, 2018 redemption date. The redemption of the 2023 Secured Notes is conditioned upon the issuance of the 2024 Convertible Notes and/or an increase in the Company’s Term Loan A credit facility that collectively generates proceeds in excess of $2 billion.

- removed (2018-05-08):
[0000106040-18-000010:note_history:58]
Since December 29, 2017, the Company also resumed its stock repurchase program and has repurchased approximately $151 million of its common stock in privately negotiated transactions, at a purchase price per share equal to $87.08 per share, with available cash on hand.
