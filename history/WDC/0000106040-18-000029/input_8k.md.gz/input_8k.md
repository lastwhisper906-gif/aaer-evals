# WDC 8-K — 0001193125-18-227786 filed 2018-07-26

## item codes, every 8-K on or before 2018-08-24

- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2018-08-24

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-227786:8k_2_02:1]
EX-99.1
2
d578100dex991.htm
EX-99.1

[0001193125-18-227786:8k_2_02:2]
EX-99.1

[0001193125-18-227786:8k_2_02:3]
Exhibit 99.1

[0001193125-18-227786:8k_2_02:4]
FOR IMMEDIATE RELEASE:

[0001193125-18-227786:8k_2_02:5]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0001193125-18-227786:8k_2_02:6]
FOURTH QUARTER AND FISCAL YEAR 2018

[0001193125-18-227786:8k_2_02:7]
Fiscal 2018 Revenue Grows to $20.6 Billion, +8% Year-over-Year

[0001193125-18-227786:8k_2_02:8]
Authorizes New $5 Billion Share Repurchase Program

[0001193125-18-227786:8k_2_02:9]
SAN JOSE, Calif. — JULY 26, 2018 — Western Digital Corp. (NASDAQ: WDC) today reported revenue of $5.1 billion for its fourth fiscal
quarter ended June 29, 2018. Operating income was $843 million with net income of $756 million, or $2.46 per share. Excluding certain non-GAAP adjustments, the company achieved non-GAAP operating income of $1.3 billion and non-GAAP net income of $1.1 billion, or $3.61 per share.

[0001193125-18-227786:8k_2_02:10]
In the year-ago quarter, the company reported revenue of $4.8 billion, operating income of
$652 million and net income of $280 million, or $0.93 per share. Non-GAAP operating income in the year-ago quarter was $1.2 billion and non-GAAP net income was $881 million, or $2.93 per share.

[0001193125-18-227786:8k_2_02:11]
The company generated $863 million
in cash from operations during the fourth fiscal quarter of 2018, ending with $5.1 billion of total cash, cash equivalents and available-for-sale securities. On
May 2, 2018, the company declared a cash dividend of $0.50 per share of its common stock, which was paid to shareholders on July 16, 2018.

[0001193125-18-227786:8k_2_02:12]
For fiscal 2018, the company achieved record revenue of $20.6 billion, operating income of $3.6 billion and net income of
$675 million, or $2.20 per share, compared to fiscal 2017 revenue of $19.1 billion, operating income of $2.0 billion and net income of $397 million, or $1.34 per share. On a non-GAAP basis,
fiscal 2018 operating income was $5.4 billion and net income was $4.5 billion, or $14.73 per share, compared to fiscal 2017 operating income of $3.9 billion and net income of $2.7 billion, or $9.19 per share. The company
generated $4.2 billion in cash from operations during the fiscal year 2018 and returned $1.2 billion to shareholders through share repurchases and dividends.

[0001193125-18-227786:8k_2_02:13]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2018

[0001193125-18-227786:8k_2_02:14]
“I am pleased with our financial performance as we report strong revenue, profitability
and cash flow generation,” said Steve Milligan, chief executive officer of Western Digital. “The Western Digital platform allows us to continue to deliver differentiated financial performance enabling us to effectively navigate dynamic
market conditions. With a deepening customer engagement, and our growing exposure to secular growth areas such as mobility and cloud, we remain poised to deliver compelling long-term shareholder value.”

[0001193125-18-227786:8k_2_02:15]
The company also announced that its Board of Directors has authorized a new $5 billion share repurchase program, replacing all prior
programs.

[0001193125-18-227786:8k_2_02:16]
“Western Digital’s products and solutions are a key enabler of the ongoing growth in the volume and value of data.
Our differentiated performance has demonstrated the stability, reliability and resiliency of our business model,” said Steve Milligan. “This new significant share repurchase authorization reflects ongoing confidence in the fundamentals of
our business and its cash flow generation capabilities. We believe it is an excellent capital allocation opportunity to enhance long-term shareholder value.”

[0001193125-18-227786:8k_2_02:17]
The investment community conference call to discuss these results, the company’s guidance for the first fiscal quarter 2019 and an
accompanying presentation will be broadcast live online today at 2:30 p.m. Pacific/5:30 p.m. Eastern. The live and archived conference call/webcast, the company’s guidance for the first fiscal quarter and the earnings presentation can be
accessed online at investor.wdc.com. The telephone replay number in the U.S. is 1(855) 859-2056 or +1(404) 537-3406 for international callers. The required
conference ID is 8876946.

[0001193125-18-227786:8k_2_02:18]
About Western Digital®

[0001193125-18-227786:8k_2_02:19]
Western Digital creates environments for data to thrive. The company is driving the innovation needed to help customers capture, preserve,
access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, our industry-leading solutions deliver the possibilities of data. Western Digital data-centric
solutions are marketed under the G-Technology™, HGST, SanDisk®, Tegile™, Upthere™ and
WD® brands. Financial and investor information is available on the company’s Investor Relations website at investor.wdc.com.

[0001193125-18-227786:8k_2_02:20]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2018

[0001193125-18-227786:8k_2_02:21]
Forward-Looking Statements

[0001193125-18-227786:8k_2_02:22]
Western Digital Announces Financial Results for Fourth Quarter and Fiscal Year 2018

[0001193125-18-227786:8k_2_02:23]
###

[0001193125-18-227786:8k_2_02:24]
Western Digital, the Western Digital logo, G-Technology, HGST, SanDisk, Tegile, Upthere and WD are registered
trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0001193125-18-227786:8k_2_02:25]
Company contacts:

[0001193125-18-227786:8k_2_02:26]
Western Digital Corp.

[0001193125-18-227786:8k_2_02:27]
Investor Contact:

[0001193125-18-227786:8k_2_02:28]
T. Peter Andrew

[0001193125-18-227786:8k_2_02:29]
949-672-9655

[0001193125-18-227786:8k_2_02:30]
peter.andrew@wdc.com

[0001193125-18-227786:8k_2_02:31]
investor@wdc.com

[0001193125-18-227786:8k_2_02:32]
Media Contact:

[0001193125-18-227786:8k_2_02:33]
Jim Pascoe

[0001193125-18-227786:8k_2_02:34]
408.717.6999

[0001193125-18-227786:8k_2_02:35]
jim.pascoe@wdc.com

[0001193125-18-227786:8k_2_02:36]
WESTERN DIGITAL CORPORATION

[0001193125-18-227786:8k_2_02:37]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-227786:8k_2_02:38]
(in millions; unaudited; on a US GAAP basis)

[0001193125-18-227786:8k_2_02:39]
|  |  | June 29,2018 |  |  | June 30,2017 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,005 |  |  | $ | 6,354 |  |
| Accounts receivable, net |  |  | 2,197 |  |  |  | 1,948 |  |
| Inventories |  |  | 2,944 |  |  |  | 2,341 |  |
| Other current assets |  |  | 492 |  |  |  | 413 |  |
| Total current assets |  |  | 10,638 |  |  |  | 11,056 |  |
| Property, plant and equipment, net |  |  | 3,095 |  |  |  | 3,033 |  |
| Notes receivable and investments in Flash Ventures |  |  | 2,105 |  |  |  | 1,340 |  |
| Goodwill |  |  | 10,075 |  |  |  | 10,014 |  |
| Other intangible assets, net |  |  | 2,680 |  |  |  | 3,823 |  |
| Other non-current assets |  |  | 642 |  |  |  | 594 |  |
| Total assets |  | $ | 29,235 |  |  | $ | 29,860 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 2,265 |  |  | $ | 2,144 |  |
| Accounts payable to related parties |  |  | 259 |  |  |  | 206 |  |
| Accrued expenses |  |  | 1,274 |  |  |  | 1,255 |  |
| Accrued compensation |  |  | 479 |  |  |  | 506 |  |
| Current portion of long-term debt |  |  | 179 |  |  |  | 233 |  |
| Total current liabilities |  |  | 4,456 |  |  |  | 4,344 |  |
| Long-term debt |  |  | 10,993 |  |  |  | 12,918 |  |
| Other liabilities |  |  | 2,255 |  |  |  | 1,180 |  |
| Total liabilities |  |  | 17,704 |  |  |  | 18,442 |  |
| Total shareholders’ equity |  |  | 11,531 |  |  |  | 11,418 |  |
| Total liabilities and shareholders’ equity |  | $ | 29,235 |  |  | $ | 29,860 |  |

[0001193125-18-227786:8k_2_02:40]
WESTERN DIGITAL CORPORATION

[0001193125-18-227786:8k_2_02:41]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-227786:8k_2_02:42]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0001193125-18-227786:8k_2_02:43]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Revenue, net |  | $ | 5,117 |  |  | $ | 4,842 |  |  | $ | 20,647 |  |  | $ | 19,093 |  |
| Cost of revenue |  |  | 3,265 |  |  |  | 3,161 |  |  |  | 12,942 |  |  |  | 13,021 |  |
| Gross profit |  |  | 1,852 |  |  |  | 1,681 |  |  |  | 7,705 |  |  |  | 6,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 577 |  |  |  | 604 |  |  |  | 2,400 |  |  |  | 2,441 |  |
| Selling, general and administrative |  |  | 352 |  |  |  | 345 |  |  |  | 1,473 |  |  |  | 1,445 |  |
| Employee termination, asset impairment and other charges |  |  | 80 |  |  |  | 80 |  |  |  | 215 |  |  |  | 232 |  |
| Total operating expenses |  |  | 1,009 |  |  |  | 1,029 |  |  |  | 4,088 |  |  |  | 4,118 |  |
| Operating income |  |  | 843 |  |  |  | 652 |  |  |  | 3,617 |  |  |  | 1,954 |  |
| Interest and other expense, net |  |  | (114 | ) |  |  | (237 | ) |  |  | (1,532 | ) |  |  | (1,185 | ) |
| Income before taxes |  |  | 729 |  |  |  | 415 |  |  |  | 2,085 |  |  |  | 769 |  |
| Income tax expense (benefit) |  |  | (27 | ) |  |  | 135 |  |  |  | 1,410 |  |  |  | 372 |  |
| Net income |  | $ | 756 |  |  | $ | 280 |  |  | $ | 675 |  |  | $ | 397 |  |
| Income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.53 |  |  | $ | 0.96 |  |  | $ | 2.27 |  |  | $ | 1.38 |  |
| Diluted |  | $ | 2.46 |  |  | $ | 0.93 |  |  | $ | 2.20 |  |  | $ | 1.34 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 299 |  |  |  | 292 |  |  |  | 297 |  |  |  | 288 |  |
| Diluted |  |  | 307 |  |  |  | 301 |  |  |  | 307 |  |  |  | 296 |  |

[0001193125-18-227786:8k_2_02:44]
WESTERN DIGITAL CORPORATION

[0001193125-18-227786:8k_2_02:45]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-227786:8k_2_02:46]
(in millions; unaudited; on a US GAAP basis)

[0001193125-18-227786:8k_2_02:47]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 756 |  |  | $ | 280 |  |  | $ | 675 |  |  | $ | 397 |  |
| Adjustments to reconcile net income to net cash provided by operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 489 |  |  |  | 546 |  |  |  | 2,056 |  |  |  | 2,128 |  |
| Stock-based compensation |  |  | 78 |  |  |  | 91 |  |  |  | 377 |  |  |  | 394 |  |
| Deferred income taxes |  |  | (12 | ) |  |  | (49 | ) |  |  | (348 | ) |  |  | 12 |  |
| Loss on disposal of assets |  |  | 5 |  |  |  | 6 |  |  |  | 21 |  |  |  | 18 |  |
| Write-off of issuance costs and amortization of debt discounts |  |  | 13 |  |  |  | 10 |  |  |  | 221 |  |  |  | 285 |  |
| Cash premium on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 720 |  |  |  | 5 |  |
| Non-cash portion of employee termination, asset impairment, and other charges |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 13 |  |
| Other non-cash operating activities, net |  |  | (4 | ) |  |  | 35 |  |  |  | (19 | ) |  |  | 94 |  |
| Changes in: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (186 | ) |  |  | 2 |  |  |  | (244 | ) |  |  | (487 | ) |
| Inventories |  |  | (274 | ) |  |  | (87 | ) |  |  | (598 | ) |  |  | (204 | ) |
| Accounts payable |  |  | 26 |  |  |  | (96 | ) |  |  | (15 | ) |  |  | 223 |  |
| Accounts payable to related parties |  |  | (23 | ) |  |  | 13 |  |  |  | 53 |  |  |  | 38 |  |
| Accrued expenses |  |  | 72 |  |  |  | 71 |  |  |  | (17 | ) |  |  | 231 |  |
| Accrued compensation |  |  | (28 | ) |  |  | 25 |  |  |  | (26 | ) |  |  | 115 |  |
| Other assets and liabilities, net |  |  | (49 | ) |  |  | 92 |  |  |  | 1,333 |  |  |  | 175 |  |
| Net cash provided by operating activities |  |  | 863 |  |  |  | 939 |  |  |  | 4,205 |  |  |  | 3,437 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net |  |  | (190 | ) |  |  | (125 | ) |  |  | (809 | ) |  |  | (557 | ) |
| Activity related to Flash Ventures, net |  |  | (35 | ) |  |  | (53 | ) |  |  | (742 | ) |  |  | (277 | ) |
| Acquisitions, net of cash acquired |  |  | (1 | ) |  |  | — |  |  |  | (100 | ) |  |  | — |  |
| Investment activity, net |  |  | (11 | ) |  |  | (1 | ) |  |  | (22 | ) |  |  | 230 |  |
| Strategic investments and other, net |  |  | (12 | ) |  |  | (11 | ) |  |  | 18 |  |  |  | (32 | ) |
| Net cash used in investing activities |  |  | (249 | ) |  |  | (190 | ) |  |  | (1,655 | ) |  |  | (636 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee stock plans, net |  |  | 67 |  |  |  | 128 |  |  |  | 49 |  |  |  | 230 |  |
| Repurchases of common stock |  |  | (436 | ) |  |  | — |  |  |  | (591 | ) |  |  | — |  |
| Proceeds from acquired call option |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 61 |  |
| Dividends paid to shareholders |  |  | (150 | ) |  |  | (146 | ) |  |  | (593 | ) |  |  | (574 | ) |
| Settlement of debt hedge contracts |  |  | — |  |  |  | (21 | ) |  |  | 28 |  |  |  | (21 | ) |
| Proceeds from revolving credit facility |  |  | — |  |  |  | — |  |  |  | 500 |  |  |  | — |  |
| Proceeds from debt, net of issuance costs |  |  | 2,449 |  |  |  | — |  |  |  | 13,781 |  |  |  | 7,898 |  |
| Repayment of debt and premiums |  |  | (2,493 | ) |  |  | (10 | ) |  |  | (17,074 | ) |  |  | (12,189 | ) |
| Net cash used in financing activities |  |  | (563 | ) |  |  | (49 | ) |  |  | (3,900 | ) |  |  | (4,595 | ) |
| Effect of exchange rate changes on cash |  |  | (9 | ) |  |  | 2 |  |  |  | 1 |  |  |  | (3 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 42 |  |  |  | 702 |  |  |  | (1,349 | ) |  |  | (1,797 | ) |
| Cash and cash equivalents, beginning of period |  |  | 4,963 |  |  |  | 5,652 |  |  |  | 6,354 |  |  |  | 8,151 |  |
| Cash and cash equivalents, end of period |  | $ | 5,005 |  |  | $ | 6,354 |  |  | $ | 5,005 |  |  | $ | 6,354 |  |

[0001193125-18-227786:8k_2_02:48]
WESTERN DIGITAL CORPORATION

[0001193125-18-227786:8k_2_02:49]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001193125-18-227786:8k_2_02:50]
(in millions, except per share amounts; unaudited)

[0001193125-18-227786:8k_2_02:51]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| GAAP cost of revenue |  | $ | 3,265 |  |  | $ | 3,161 |  |  | $ | 12,942 |  |  | $ | 13,021 |  |
| Amortization of acquired intangible assets |  |  | (234 | ) |  |  | (279 | ) |  |  | (1,022 | ) |  |  | (1,003 | ) |
| Stock-based compensation expense |  |  | (12 | ) |  |  | (12 | ) |  |  | (49 | ) |  |  | (49 | ) |
| Acquisition-related charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (18 | ) |
| Charges related to cost saving initiatives |  |  | 1 |  |  |  | (24 | ) |  |  | 7 |  |  |  | (68 | ) |
| Other |  |  | — |  |  |  | (2 | ) |  |  | — |  |  |  | (5 | ) |
| Non-GAAP cost of revenue |  | $ | 3,020 |  |  | $ | 2,844 |  |  | $ | 11,878 |  |  | $ | 11,878 |  |
| GAAP gross profit |  | $ | 1,852 |  |  | $ | 1,681 |  |  | $ | 7,705 |  |  | $ | 6,072 |  |
| Amortization of acquired intangible assets |  |  | 234 |  |  |  | 279 |  |  |  | 1,022 |  |  |  | 1,003 |  |
| Stock-based compensation expense |  |  | 12 |  |  |  | 12 |  |  |  | 49 |  |  |  | 49 |  |
| Acquisition-related charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 18 |  |
| Charges related to cost saving initiatives |  |  | (1 | ) |  |  | 24 |  |  |  | (7 | ) |  |  | 68 |  |
| Other |  |  | — |  |  |  | 2 |  |  |  | — |  |  |  | 5 |  |
| Non-GAAP gross profit |  | $ | 2,097 |  |  | $ | 1,998 |  |  | $ | 8,769 |  |  | $ | 7,215 |  |
| GAAP operating expenses |  | $ | 1,009 |  |  | $ | 1,029 |  |  | $ | 4,088 |  |  | $ | 4,118 |  |
| Amortization of acquired intangible assets |  |  | (41 | ) |  |  | (40 | ) |  |  | (163 | ) |  |  | (159 | ) |
| Stock-based compensation expense |  |  | (66 | ) |  |  | (77 | ) |  |  | (327 | ) |  |  | (333 | ) |
| Employee termination, asset impairment and other charges |  |  | (80 | ) |  |  | (80 | ) |  |  | (215 | ) |  |  | (232 | ) |
| Acquisition-related charges |  |  | (1 | ) |  |  | — |  |  |  | (13 | ) |  |  | (17 | ) |
| Charges related to cost saving initiatives |  |  | (1 | ) |  |  | (16 | ) |  |  | (19 | ) |  |  | (86 | ) |
| Other |  |  | — |  |  |  | (4 | ) |  |  | 3 |  |  |  | (8 | ) |
| Non-GAAP operating expenses |  | $ | 820 |  |  | $ | 812 |  |  | $ | 3,354 |  |  | $ | 3,283 |  |
| GAAP operating income |  | $ | 843 |  |  | $ | 652 |  |  | $ | 3,617 |  |  | $ | 1,954 |  |
| Cost of revenue adjustments |  |  | 245 |  |  |  | 317 |  |  |  | 1,064 |  |  |  | 1,143 |  |
| Operating expense adjustments |  |  | 189 |  |  |  | 217 |  |  |  | 734 |  |  |  | 835 |  |
| Non-GAAP operating income |  | $ | 1,277 |  |  | $ | 1,186 |  |  | $ | 5,415 |  |  | $ | 3,932 |  |
| GAAP interest and other expense, net |  | $ | (114 | ) |  | $ | (237 | ) |  | $ | (1,532 | ) |  | $ | (1,185 | ) |
| Convertible debt activity, net |  |  | 7 |  |  |  | (1 | ) |  |  | 10 |  |  |  | 6 |  |
| Debt extinguishment costs |  |  | 3 |  |  |  | — |  |  |  | 899 |  |  |  | 274 |  |
| Other |  |  | 3 |  |  |  | 41 |  |  |  | 5 |  |  |  | 54 |  |
| Non-GAAP interest and other expense, net |  | $ | (101 | ) |  | $ | (197 | ) |  | $ | (618 | ) |  | $ | (851 | ) |
| GAAP income tax expense (benefit) |  | $ | (27 | ) |  | $ | 135 |  |  | $ | 1,410 |  |  | $ | 372 |  |
| Income tax adjustments |  |  | 94 |  |  |  | (27 | ) |  |  | (1,136 | ) |  |  | (11 | ) |
| Non-GAAP income tax expense |  | $ | 67 |  |  | $ | 108 |  |  | $ | 274 |  |  | $ | 361 |  |

[0001193125-18-227786:8k_2_02:52]
|  |  | Three Months Ended |  |  | Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| GAAP net income |  | $ | 756 |  |  | $ | 280 |  |  | $ | 675 |  |  | $ | 397 |  |
| Amortization of acquired intangible assets |  |  | 275 |  |  |  | 319 |  |  |  | 1,185 |  |  |  | 1,162 |  |
| Stock-based compensation expense |  |  | 78 |  |  |  | 89 |  |  |  | 376 |  |  |  | 382 |  |
| Employee termination, asset impairment and other charges |  |  | 80 |  |  |  | 80 |  |  |  | 215 |  |  |  | 232 |  |
| Acquisition-related charges |  |  | 1 |  |  |  | — |  |  |  | 13 |  |  |  | 35 |  |
| Charges related to cost saving initiatives |  |  | — |  |  |  | 40 |  |  |  | 12 |  |  |  | 154 |  |
| Convertible debt activity, net |  |  | 7 |  |  |  | (1 | ) |  |  | 10 |  |  |  | 6 |  |
| Debt extinguishment costs |  |  | 3 |  |  |  | — |  |  |  | 899 |  |  |  | 274 |  |
| Other |  |  | 3 |  |  |  | 47 |  |  |  | 2 |  |  |  | 67 |  |
| Income tax adjustments |  |  | (94 | ) |  |  | 27 |  |  |  | 1,136 |  |  |  | 11 |  |
| Non-GAAP net income |  | $ | 1,109 |  |  | $ | 881 |  |  | $ | 4,523 |  |  | $ | 2,720 |  |
| Diluted income per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 2.46 |  |  | $ | 0.93 |  |  | $ | 2.20 |  |  | $ | 1.34 |  |
| Non-GAAP |  | $ | 3.61 |  |  | $ | 2.93 |  |  | $ | 14.73 |  |  | $ | 9.19 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  | 307 |  |  |  | 301 |  |  |  | 307 |  |  |  | 296 |  |
| Non-GAAP |  |  | 307 |  |  |  | 301 |  |  |  | 307 |  |  |  | 296 |  |

[0001193125-18-227786:8k_2_02:53]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting
principles (“GAAP”), the table above sets forth non-GAAP cost of revenue; non-GAAP gross profit; non-GAAP operating
expenses; non-GAAP operating income; non-GAAP interest and other expense, net; non-GAAP income tax expense; non-GAAP net income and non-GAAP diluted income per common share (“Non-GAAP measures”). These
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other
companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the
company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they
exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its
peers. As discussed further below, these Non-GAAP measures exclude the amortization of acquired intangible assets, stock-based compensation expense, employee termination, asset impairment and other charges,
acquisition-related charges, charges related to cost saving initiatives, convertible debt activity, debt extinguishment costs, other charges, and income tax adjustments, and the company believes these measures along with the related reconciliations
to the GAAP measures provide additional detail and comparability for assessing the company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the
company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0001193125-18-227786:8k_2_02:54]
As described above, the company excludes the following items from its Non-GAAP measures:

[0001193125-18-227786:8k_2_02:55]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives.
Such charges are significantly impacted by the timing and magnitude of the company’s acquisitions and any related impairment charges.

[0001193125-18-227786:8k_2_02:56]
Stock-based
compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in
valuations that can be driven by market conditions outside the company’s control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying
performance of its business over time and compare it against the company’s peers, a majority of whom also exclude stock-based compensation expense from their non-GAAP results.

[0001193125-18-227786:8k_2_02:57]
Employee termination, asset impairment and other charges. From time-to-time, in order to realign the company’s operations with anticipated market
demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. During the fiscal quarter ended June 29, 2018, the company incurred charges related to a planned hard
drive manufacturing site closure and consolidation, as well as other restructuring actions. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. These charges (including any
reversals of charges recorded in prior periods) are inconsistent in amount and frequency, and the company believes are not indicative of the underlying performance of its business.

[0001193125-18-227786:8k_2_02:58]
Acquisition-related charges. In connection with the company’s business combinations, the company incurs expenses which it would not have otherwise
incurred as part of its business operations. These expenses include third-party professional service and legal fees, third-party integration services, severance costs, non-cash adjustments to the fair value of acquired inventory, contract
termination costs, and retention bonuses. The company may also experience other accounting impacts in connection with these transactions. These charges and impacts are related to acquisitions, are inconsistent in amount and frequency, and the
company believes are not indicative of the underlying performance of its business.

[0001193125-18-227786:8k_2_02:59]
Charges related to cost saving initiatives. In connection with
the transformation of the company’s business, the company has incurred charges related to cost saving initiatives which do not qualify for special accounting treatment as exit or disposal activities. These charges, which the company believes
are not indicative of the underlying performance of its business, primarily relate to costs associated with rationalizing the company’s channel partners or vendors, transforming the company’s information systems infrastructure, integrating
the company’s product roadmap, and accelerated depreciation on assets.

[0001193125-18-227786:8k_2_02:60]
Convertible debt activity, net. The company excludes non-cash economic
interest expense associated with its convertible notes, the gains and losses on the conversion of its convertible senior notes and call option, and unrealized gains and losses related to the change in fair value of the exercise option and call
option. These charges and gains and losses do not reflect the company’s operating results, and the company believes are not indicative of the underlying performance of its business.

[0001193125-18-227786:8k_2_02:61]
Debt extinguishment costs. From time-to-time, the company replaces its existing debt with new financing at more favorable interest rates or utilizes
available capital to settle debt early, both of which generate interest savings in future periods. The company incurs debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off of any related unamortized debt
issuance costs. These gains and losses do not reflect the company’s operating results, and the company believes are not indicative of the underlying performance of its business.

[0001193125-18-227786:8k_2_02:62]
Other charges. From time-to-time, the company sells or impairs investments or other assets which are not considered necessary to its business
operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0001193125-18-227786:8k_2_02:63]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a
forecasted annual non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain non-GAAP pre-tax adjustments. Additionally, as a result of the Tax Cuts and Jobs Act, the fiscal year ended June 29, 2018 income tax
adjustments include a net provisional income tax expense of $1.6 billion for the one-time mandatory deemed repatriation tax and a provisional income tax benefit of $65 million related to the re-measurement of deferred tax assets and liabilities.
