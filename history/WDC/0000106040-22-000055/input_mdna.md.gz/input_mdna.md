# WDC MD&A — 0000106040-22-000055


## mdna

[0000106040-22-000055:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-22-000055:mdna:2]
Our Company

[0000106040-22-000055:mdna:3]
We are on a mission to unlock the potential of data by harnessing the possibility to use it. We are a leading developer, manufacturer, and provider of data storage devices based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated business units driving advancements in NAND flash and magnetic recording technologies, we create and drive innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-22-000055:mdna:4]
Our broad portfolio of technology and products address multiple end markets. In 2022, we refined the end markets we report to be “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers, which we believe we are uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-22-000055:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2022 and 2021, which ended on July 1, 2022 and July 2, 2021, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-22-000055:mdna:6]
Key Developments

[0000106040-22-000055:mdna:7]
Business Structure and Strategic Alternatives

[0000106040-22-000055:mdna:8]
In 2021, we made and announced the decision to reorganize our business by forming two separate product business units: Flash and HDD. The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. To align with the new operating model and business structure, we made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of our operating segments and concluded that we now have two reportable segments: Flash and HDD.

[0000106040-22-000055:mdna:9]
In June 2022, we announced that we are reviewing potential strategic alternatives aimed at further optimizing long-term value for stockholders. The Executive Committee of our Board of Directors is overseeing the assessment process and evaluating a range of alternatives, including options for separating our Flash and HDD business units. In conjunction with that review process, we announced that we had entered into a letter agreement with Elliott Investment Management L.P. (“Elliott”), which had disclosed in May 2022 a $1 billion investment in our Company and called for a full strategic review of our business. We are actively working with financial advisors and our legal counsel in this strategic review process.

[0000106040-22-000055:mdna:10]
Tax Resolution

[0000106040-22-000055:mdna:11]
As previously disclosed, we have received statutory notices of deficiency and notices of proposed adjustments from the Internal Revenue Service (“IRS”) with respect to 2008 through 2015. During 2022, new information became available which required us to re-measure our unrecognized tax benefits for this IRS matter. We and the IRS tentatively reached a settlement for resolving this matter. Additional information is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 14, Income Tax Expense, of the Notes to the Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity-Unrecognized Tax Benefits” section below.

[0000106040-22-000055:mdna:12]
32

[0000106040-22-000055:mdna:13]
Flash Ventures Contamination Incident

[0000106040-22-000055:mdna:14]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in our flash wafer availability. During 2022, we incurred charges of $207 million related to this contamination incident that were recorded in cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs. We are evaluating potential options for recovery.

[0000106040-22-000055:mdna:15]
Financing Activities

[0000106040-22-000055:mdna:16]
During 2022, we continued to execute on our commitment to reduce our overall debt levels and Fitch Ratings, Inc. raised our Company credit rating to investment grade in December 2021. We fully repaid our Term Loan B-4 in October 2021 and shortly thereafter initiated a series of transactions to further reduce our debt levels and better stagger the maturities of our debt. In December 2021, we issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and we issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”). We used the proceeds from these note offerings and available cash to voluntarily repay $1.21 billion of our Term Loan A-1 and reduce the principal amount to $3.0 billion as of December 31, 2021. In January 2022, we amended and restated our existing loan agreement to provide for, among other things: (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 to replace our previously existing Term Loan A-1; (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 to replace our previously existing $2.25 billion revolving credit facility; and (iii) additional covenant flexibility and other modifications. As of July 1, 2022, over 80% of the principal amount of our debt is now due in 2026 or later. We believe this new debt structure gives us greater financial stability and flexibility to manage our business over the longer term.

[0000106040-22-000055:mdna:17]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:18]
New Flash Ventures Fabrication Facility

[0000106040-22-000055:mdna:19]
In January 2022, we entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The first phase of construction of Y7 is complete and output is expected to commence in the first half of 2023. We are committed to pay, among other items, future building depreciation prepayments of approximately $268 million in 2023 and $22 million in 2024, to be credited against future wafer charges.

[0000106040-22-000055:mdna:20]
COVID-19 Pandemic and Operational Update

[0000106040-22-000055:mdna:21]
As the ongoing COVID-19 pandemic has evolved, we have implemented and maintained more thorough sanitation practices as outlined by health organizations and supported vaccination efforts. We continually monitor and update our practices based on recommendations from health organizations to ensure the continued safety of our employees and business partners. In addition, the responses to COVID-19 taken by others in the supply chain have contributed to the increases in the costs of their services, which have in turn impacted our operations. We incurred incremental charges primarily related to logistics, absorption, and other factory-related costs of approximately $248 million and $127 million, during 2022 and 2021, respectively, which were recorded in Cost of revenue.

[0000106040-22-000055:mdna:22]
The technology hardware and semiconductor industries faced supply chain disruptions and component shortages during 2022, which negatively impacted both our customers’ ability to ship products and our ability to build products. In order to meet our end customers’ demand, we are incurring increased component costs, which primarily impacted our hard drive gross margins in 2022. Additionally, the global economy has recently experienced significant volatility and disruptions impacted by increases in inflation rates, Russia’s invasion of Ukraine and rising fuel prices, rising interest rates, declines in consumer confidence, declines in economic growth, and uncertainty about economic stability. We are seeing our PC OEM customers aggressively right-size their inventory to reflect current demand conditions, which will impact our business in this market in the second half of the calendar year. While we ultimately expect that the impact of these conditions will be transitory, the severity and duration of the impact of these conditions on our business is dynamic and cannot be predicted.

[0000106040-22-000055:mdna:23]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. Our BiCS5 based products continue to play a significant role in driving top line results across our end markets as we move further along the product roadmap. Additionally, OptiNAND and shingled magnetic recording (“SMR”) technologies are progressing as planned as we have commenced commercial shipments on a number of OptiNand-based products and are undergoing qualifications of our latest 26-terabyte SMR drive. For our next generation 3D-flash technology, we continued commercial shipment of consumer flash devices based on our 162-layer BiCS6 technology as we expect to start ramping the technology towards the end of calendar year 2022. We are also aware of the ongoing trends in the HDD Client market as PCs shift from using HDD to Flash technology. As a result, we have and are still undergoing actions to restructure our HDD manufacturing footprint to reflect this market dynamic.

[0000106040-22-000055:mdna:24]
We will continue to actively monitor these situations and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See Part I, Item 1A, Risk Factors, of this Annual Report on Form 10-K for more information regarding the risks we face as a result of the COVID-19 pandemic, supply chain disruptions and current macroeconomic conditions.

[0000106040-22-000055:mdna:25]
Russia Sanctions

[0000106040-22-000055:mdna:26]
In February 2022, the U.S. and other countries imposed sanctions on Russia. In accordance with these sanctions, we have ceased shipments to distributors for customers located in Russia. Our revenue from distributors for customers in Russia have not been significant. We have no material assets or operations in Russia.

[0000106040-22-000055:mdna:27]
34

[0000106040-22-000055:mdna:28]
Results of Operations

[0000106040-22-000055:mdna:29]
Summary Comparison of 2022, 2021 and 2020

[0000106040-22-000055:mdna:30]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-22-000055:mdna:31]
|  |  |  |  |  |  |  |  |  | 2022 |  | 2021 |  |  |  | 2020 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,793 |  |  | 100.0 | % |  | $ | 16,922 |  |  | 100.0 | % |  |  |  | $ | 16,736 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 12,919 |  |  | 68.7 |  |  | 12,401 |  |  | 73.3 |  |  |  |  | 12,955 |  |  | 77.4 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 5,874 |  |  | 31.3 |  |  | 4,521 |  |  | 26.7 |  |  |  |  | 3,781 |  |  | 22.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 2,323 |  |  | 12.4 |  |  | 2,243 |  |  | 13.3 |  |  |  |  | 2,261 |  |  | 13.5 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 1,117 |  |  | 5.9 |  |  | 1,105 |  |  | 6.5 |  |  |  |  | 1,153 |  |  | 6.9 |  |
| Employee termination, asset impairment, and other charges |  |  |  |  |  |  |  |  |  |  |  |  | 43 |  |  | 0.2 |  |  | (47) |  |  | (0.3) |  |  |  |  | 32 |  |  | 0.2 |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 3,483 |  |  | 18.5 |  |  | 3,301 |  |  | 19.5 |  |  |  |  | 3,446 |  |  | 20.6 |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  | 2,391 |  |  | 12.7 |  |  | 1,220 |  |  | 7.2 |  |  |  |  | 335 |  |  | 2.0 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  | — |  |  | 7 |  |  | — |  |  |  |  | 28 |  |  | 0.2 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (304) |  |  | (1.6) |  |  | (326) |  |  | (1.9) |  |  |  |  | (413) |  |  | (2.5) |  |
| Other income, net |  |  |  |  |  |  |  |  |  |  |  |  | 30 |  |  | 0.2 |  |  | 26 |  |  | 0.2 |  |  |  |  | 4 |  |  | — |  |
| Total interest and other expense, net |  |  |  |  |  |  |  |  |  |  |  |  | (268) |  |  | (1.4) |  |  | (293) |  |  | (1.7) |  |  |  |  | (381) |  |  | (2.3) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |  | 11.3 |  |  | 927 |  |  | 5.5 |  |  |  |  | (46) |  |  | (0.3) |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 623 |  |  | 3.3 |  |  | 106 |  |  | 0.6 |  |  |  |  | 204 |  |  | 1.2 |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,500 |  |  | 8.0 | % |  | $ | 821 |  |  | 4.9 | % |  |  |  | $ | (250) |  |  | (1.5) | % |

[0000106040-22-000055:mdna:32]
(1)    Percentages may not total due to rounding.

[0000106040-22-000055:mdna:33]
The following table sets forth, for the periods presented, a summary of our segment information:

[0000106040-22-000055:mdna:34]
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Flash | $ | 9,753 |  | $ | 8,706 |  | $ | 7,769 |
| HDD | 9,040 |  | 8,216 |  | 8,967 |
| Total net revenue | $ | 18,793 |  | $ | 16,922 |  | $ | 16,736 |
| Gross profit: |  |  |  |  |  |
| Flash | $ | 3,527 |  | $ | 2,611 |  | $ | 1,903 |
| HDD | 2,661 |  | 2,221 |  | 2,602 |
| Unallocated corporate items: |  |  |  |  |  |
| Amortization of acquired intangible assets | (66) |  | (331) |  | (610) |
| Stock-based compensation expense | (48) |  | (55) |  | (51) |
| Contamination related charges | (207) |  | — |  | — |
| Recoveries from a power outage incident | 7 |  | 75 |  | (68) |
| Other | — |  | — |  | 5 |
| Total unallocated corporate items | (314) |  | (311) |  | (724) |
| Consolidated gross profit | $ | 5,874 |  | $ | 4,521 |  | $ | 3,781 |
| Gross margin: |  |  |  |  |  |
| Flash | 36.2% |  | 30.0% |  | 24.5% |
| HDD | 29.4% |  | 27.0% |  | 29.0% |
| Consolidated gross margin | 31.3% |  | 26.7% |  | 22.6% |

[0000106040-22-000055:mdna:35]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0000106040-22-000055:mdna:36]
|  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
|  |  |  |  |  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 8,017 |  |  | $ | 5,723 |  |  | $ | 7,018 |  |
| Client |  |  |  |  | 7,076 |  |  | 7,281 |  |  | 6,335 |  |
| Consumer |  |  |  |  | 3,700 |  |  | 3,918 |  |  | 3,383 |  |
| Total Revenue |  |  |  |  | $ | 18,793 |  |  | $ | 16,922 |  |  | $ | 16,736 |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 10,054 |  |  | $ | 9,455 |  |  | $ | 8,366 |  |
| Americas |  |  |  |  | 5,867 |  |  | 4,406 |  |  | 5,444 |  |
| Europe, Middle East and Africa |  |  |  |  | 2,872 |  |  | 3,061 |  |  | 2,926 |  |
| Total Revenue |  |  |  |  | $ | 18,793 |  |  | $ | 16,922 |  |  | $ | 16,736 |  |
| Exabytes Shipped |  |  |  |  | 645 |  |  | 541 |  |  | 518 |  |

[0000106040-22-000055:mdna:37]
Net Revenue

[0000106040-22-000055:mdna:38]
Net revenue increased 11% in 2022 compared to 2021, which reflects increases in exabytes of Flash and HDD sold as further discussed below. The net revenue increases driven by exabyte growth were partially offset by declines in the average price per gigabyte of storage for both Flash and HDD as product mix shifted to more efficient, high-capacity drives.

[0000106040-22-000055:mdna:39]
36

[0000106040-22-000055:mdna:40]
Despite the temporary disruption to our Flash production from the contamination event at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan, Flash revenue increased 12% in 2022 compared to 2021, primarily driven by a 21% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as product mix shifted to more efficient, high-capacity drives. The higher exabytes sold primarily reflected the growth in Cloud and the ramp of our latest BiCS5 flash solutions. Higher volume was also driven by strong demand in gaming along with a growing brand recognition of WD_Black based products in our Consumer market.

[0000106040-22-000055:mdna:41]
HDD revenue increased 10% in 2022, compared to 2021, primarily driven by a 19% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as product mix shifted to more efficient higher-capacity drives. The increase in exabytes sold was due to continued demand for our latest generation energy assisted drives among our public and private cloud customers as discussed below. The increase in Cloud was partly offset by a decline in HDD exabytes sold in our Client and Consumer end markets due to continued pressure in the commercial channel related to component issues impacting our customers’ ability to ship product and greater component sourcing constraints within our own operations, and customers transitioning to client SSD.

[0000106040-22-000055:mdna:42]
The increase in Cloud revenue in 2022 compared to 2021 was led by the demand increase for HDD capacity enterprise drives, including growth in our 18-terabyte capacity drives and ramp of our 20-terabyte and 22-terabyte capacity drives. Additionally, revenue from Flash for enterprise SSD applications more than doubled in 2022 compared to 2021. In Client, the decrease in revenue in 2022 compared to 2021, primarily reflected a mid-30% decrease in client HDD revenue, as a result of the supply chain disruptions noted previously, as well as lower shipments of PCs toward the end of 2022, partially offset by an increase in Flash revenue due to the ramp of 5G phones. In Consumer, the decrease in revenues in 2022 compared to 2021 reflected declines in HDD as a result of short-term demand weakness tied to macroeconomic factors, as well as COVID-related measures.

[0000106040-22-000055:mdna:43]
The changes in net revenue by geography in 2022, compared to 2021 are primarily related to growth in Asia driven by the ramp in 5G products as well as routine variations in the mix of business.

[0000106040-22-000055:mdna:44]
For 2022, 2021 and 2020, our top 10 customers accounted for 45%, 39% and 42%, respectively, of our net revenue. For each of 2022, 2021 and 2020, no single customer accounted for 10% or more of our net revenue.

[0000106040-22-000055:mdna:45]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2022, 2021 and 2020, these programs represented 17%, 19% and 16%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue over the last three years. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-22-000055:mdna:46]
Gross Profit and Gross Margin

[0000106040-22-000055:mdna:47]
Consolidated gross profit increased $1.35 billion, or 30%, in 2022 compared to 2021, which reflects the increase in revenue in both Flash and HDD, the shift in product mix to more efficient higher-capacity drives, and cost efficiencies as we ramped production on new products, as well as a $265 million decrease in charges in the current period related to amortization expense on acquired intangible assets, some of which became fully amortized. These improvements were partially offset by the contamination related charges of $207 million noted above. Consolidated gross margin increased 4.6 percentage points over the prior year with Flash gross margin up 6.2 percentage points and HDD gross margin up 2.4 percentage points, which primarily reflected cost reductions as we ramped production on newer products. Consolidated gross margin also increased as a result of a shift in product mix to higher-margin flash drives.

[0000106040-22-000055:mdna:48]
Operating Expenses

[0000106040-22-000055:mdna:49]
R&D expense increased $80 million in 2022 compared to 2021 as we continued to invest in new technologies. The primary drivers of the year-over-year change were increases in headcount and annual merit compensation, which accounted for approximately $30 million of the overall increase, as well as a similarly sized increase in material use due to an increase in projects.

[0000106040-22-000055:mdna:50]
Selling, general and administrative (“SG&A”) expense in 2022 was relatively flat compared to 2021 as we tightly managed costs in light of a dynamic macroeconomic environment.

[0000106040-22-000055:mdna:51]
The losses recognized in Employee termination, asset impairment and other charges compared to the gains in the prior year primarily reflect lower gains on the disposal of assets associated with our business realignment activities, partially offset by higher employee termination and other charges associated with our business realignment activities. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 16, Employee Termination, Asset Impairment, and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:52]
Interest and Other Income (Expense)

[0000106040-22-000055:mdna:53]
The decreases in total interest and other expense, net in 2022 compared to 2021 primarily reflects a decrease in interest expense resulting from the pay-down of principal on our debt during 2022.

[0000106040-22-000055:mdna:54]
Income Tax Expense

[0000106040-22-000055:mdna:55]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of 2019. However, the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-22-000055:mdna:56]
The following table sets forth Income tax information from our Consolidated Statement of Operations by dollar and effective tax rate:

[0000106040-22-000055:mdna:57]
|  |  |  |  |  | 2022 |  | 2021 |  | 2020 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | 2,123 |  |  | $ | 927 |  |  | $ | (46) |  |
| Income tax expense |  |  |  |  | 623 |  |  | 106 |  |  | 204 |  |
| Effective tax rate |  |  |  |  | 29 | % |  | 11 | % |  | (443) | % |

[0000106040-22-000055:mdna:58]
The primary drivers of the difference between the effective tax rate for 2022 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for 2022 includes a net increase to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of ongoing discussions with various taxing authorities of $352 million. This amount includes $324 million related to the effects of the tentative settlement with the IRS resolving the statutory notices of deficiency and notices of proposed adjustments with respect to 2008 through 2015.

[0000106040-22-000055:mdna:59]
The primary drivers of the difference between the effective tax rate for 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during 2021 through 2031.

[0000106040-22-000055:mdna:60]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. In particular, beginning in 2023, the 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in year incurred, which is expected to both materially increase our effective tax rate and materially reduce our operating cash flows, if not repealed or otherwise modified. Our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-22-000055:mdna:61]
For additional information regarding Income tax expense (benefit), see Part II, Item 8, Note 14, Income Tax Expense, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:62]
A discussion of our results of operations for 2020, including a comparison of such results of operations to 2021, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, included in our Annual Report on Form 10-K for the year ended July 2, 2021 filed with the Securities and Exchange Commission on August 27, 2021.

[0000106040-22-000055:mdna:63]
Liquidity and Capital Resources

[0000106040-22-000055:mdna:64]
The following table summarizes our statements of cash flows:

[0000106040-22-000055:mdna:65]
|  | 2022 |  | 2021 |  | 2020 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,880 |  |  | $ | 1,898 |  |  | $ | 824 |  |
| Investing activities | (1,192) |  |  | (765) |  |  | 278 |  |
| Financing activities | (1,718) |  |  | (817) |  |  | (1,508) |  |
| Effect of exchange rate changes on cash | (13) |  |  | 6 |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (1,043) |  |  | $ | 322 |  |  | $ | (407) |  |

[0000106040-22-000055:mdna:66]
We and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015. We expect to pay tax and interest totaling approximately $600 million to $700 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 to $150 million. See Part I, Item 1, Note 14, Income Tax Expense for further details.

[0000106040-22-000055:mdna:67]
As further explained under Key Developments - Financing Activities above, we have taken recent actions to reduce our overall debt levels and extend the average maturity. Following these actions, we have reduced the outstanding principal amount of our debt by approximately $1.73 billion since July 2, 2021 and over 80% of the principal amount is now due in 2026 or later. We also have an existing shelf registration statement (the “Shelf Registration Statement”) filed with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We used the Shelf Registration Statement to complete our offering of $1.0 billion aggregate principal amount of senior unsecured notes in December 2021, and we may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-22-000055:mdna:68]
During 2023, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate to $3.2 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.6 billion during 2023. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-22-000055:mdna:69]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, capital expenditure needs and other cash material cash requirements for at least the next twelve months and the foreseeable future. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:70]
A total of $1.82 billion and $1.99 billion of our cash and cash equivalents was held outside of the U.S. as of July 1, 2022 and July 2, 2021, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-22-000055:mdna:71]
Operating Activities

[0000106040-22-000055:mdna:72]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $1.08 billion for 2022, as compared to $175 million for 2021. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. At the end of the respective fourth quarters, the cash conversion cycles were as follows (in days):

[0000106040-22-000055:mdna:73]
|  | 2022 |  | 2021 |  | 2020 |
|  | (in days) |
| Days sales outstanding | 56 |  |  | 42 |  |  | 50 |  |
| Days in inventory | 107 |  |  | 98 |  |  | 87 |  |
| Days payables outstanding | (66) |  |  | (63) |  |  | (67) |  |
| Cash conversion cycle | 97 |  |  | 77 |  |  | 70 |  |

[0000106040-22-000055:mdna:74]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-22-000055:mdna:75]
For 2022, DSO increased by 14 days over the prior year, reflecting timing of shipments, as well as more favorable customer terms in the prior year, partially offset by a decrease of approximately 6 days for higher factoring of receivables. We have seen no significant deterioration in our receivables as a result of COVID-19 or other market conditions. DIO increased by 9 days over the prior fiscal year, reflecting higher stocking levels of raw materials to minimize the risk of supply chain disruptions. DPO increased 3 days over the prior year, primarily reflecting routine variations in the timing of purchases and payments during the period.

[0000106040-22-000055:mdna:76]
Investing Activities

[0000106040-22-000055:mdna:77]
Net cash used in investing activities in 2022 primarily consisted of $1.1 billion in capital expenditures and a $91 million net increase in notes receivable issuance to Flash Ventures. Net cash used by investing activities in 2021 primarily consisted of a $1.1 billion of capital expenditures, partially offset by a $231 million net decrease in notes receivable issuances to Flash Ventures.

[0000106040-22-000055:mdna:78]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities.

[0000106040-22-000055:mdna:79]
Financing Activities

[0000106040-22-000055:mdna:80]
During 2022, net cash used in financing activities primarily related to our efforts to reduce our overall level of debt. See “Key Development - Financing Activities” above for additional discussion. Net cash used in financing activities in 2021 primarily consisted of $886 million for repayment of debt, which included $600 million in voluntary prepayments on our Term Loan B-4, and $56 million for taxes paid on vested stock awards under employee stock plans, partially offset by $134 million of cash from the issuance of stock under our employee stock plans.

[0000106040-22-000055:mdna:81]
A discussion of our cash flows for the year ended July 3, 2020 is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended July 2, 2021 filed with the Securities and Exchange Commission on August 27, 2021.

[0000106040-22-000055:mdna:82]
Off-Balance Sheet Arrangements

[0000106040-22-000055:mdna:83]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Indemnifications” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:84]
41

[0000106040-22-000055:mdna:85]
Short and Long-term Liquidity

[0000106040-22-000055:mdna:86]
Material Cash Commitments

[0000106040-22-000055:mdna:87]
The following is a summary of our known material cash commitments, including those for capital expenditures, as of July 1, 2022:

[0000106040-22-000055:mdna:88]
|  | Total |  | 1 Year (2023) |  | 2-3 Years (2024-2025) |  | 4-5 Years (2026-2027) |  | More than 5 Years (Beyond 2027) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,100 |  |  | $ | — |  |  | $ | 1,363 |  |  | $ | 4,737 |  |  | $ | 1,000 |  |
| Interest on debt | 1,185 |  |  | 256 |  |  | 466 |  |  | 288 |  |  | 175 |  |
| Flash Ventures related commitments(2) | 5,263 |  |  | 3,162 |  |  | 1,683 |  |  | 631 |  |  | (213) |  |
| Operating leases | 369 |  |  | 48 |  |  | 92 |  |  | 82 |  |  | 147 |  |
| Purchase obligations and other commitments | 3,705 |  |  | 2,467 |  |  | 989 |  |  | 99 |  |  | 150 |  |
| Mandatory Deemed Repatriation Tax | 765 |  |  | 106 |  |  | 384 |  |  | 275 |  |  | — |  |
| Total | $ | 18,387 |  |  | $ | 6,039 |  |  | $ | 4,977 |  |  | $ | 6,112 |  |  | $ | 1,259 |  |

[0000106040-22-000055:mdna:89]
(1)Principal portion of debt, excluding discounts and issuance costs.

[0000106040-22-000055:mdna:90]
(2)Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0000106040-22-000055:mdna:91]
Debt

[0000106040-22-000055:mdna:92]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. The loan agreement governing our revolving credit facility and our term loan A-2 due 2027 requires us to comply with a leverage ratio financial covenant. As of July 1, 2022, we were in compliance with this financial covenant.

[0000106040-22-000055:mdna:93]
Flash Ventures

[0000106040-22-000055:mdna:94]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of July 1, 2022, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0000106040-22-000055:mdna:95]
Purchase Obligations and Other Commitments

[0000106040-22-000055:mdna:96]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-22-000055:mdna:97]
42

[0000106040-22-000055:mdna:98]
Mandatory Deemed Repatriation Tax

[0000106040-22-000055:mdna:99]
The following is a summary of our estimated mandatory deemed repatriation tax obligations under the 2017 Act that are payable in the following fiscal years (in millions):

[0000106040-22-000055:mdna:100]
|  |  | July 1,2022 |
| 2023 |  | $ | 106 |  |
| 2024 |  | 165 |  |
| 2025 |  | 219 |  |
| 2026 |  | 275 |  |
| Total |  | $ | 765 |  |

[0000106040-22-000055:mdna:101]
For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part II, Item 8, Note 14, Income Tax Expense, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 28, 2019.

[0000106040-22-000055:mdna:102]
Unrecognized Tax Benefits

[0000106040-22-000055:mdna:103]
As of July 1, 2022, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $1.05 billion. Accrued interest and penalties related to unrecognized tax benefits as of July 1, 2022 was approximately $254 million. Of these amounts, approximately $1.16 billion could result in potential cash payments. With the exception of the tentative settlement, we are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-22-000055:mdna:104]
During 2022, we and the IRS tentatively reached a settlement for resolving the statutory notices of deficiency and notices of proposed adjustments with respect to years 2008 through 2015 subject to the parties entering into final stipulations and a closing agreement. As a result, the trial originally scheduled to take place in May 2022 was cancelled. The tentative settlement for resolution incrementally increased the liability for unrecognized tax benefits, including interest and offsetting tax benefits, by $324 million. Including this incremental increase, we expect to pay tax and interest totaling approximately $600 million to $700 million, which we expect to be partially offset by future reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions aggregating to approximately $100 to $150 million. While we continue to work with the IRS to come to a final agreement on the federal tax and interest calculations, we are uncertain as to when a final agreement will be reached, and the exact timing of when any payments will be made. However, we believe it is reasonably likely that payments may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on our Consolidated Balance Sheet as of July 1, 2022. This classification and amount may be subject to change in the next twelve months depending on when we are able to reach a final agreement with the IRS.

[0000106040-22-000055:mdna:105]
Mandatory Research and Development Expense Capitalization

[0000106040-22-000055:mdna:106]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments, if not repealed or otherwise modified.

[0000106040-22-000055:mdna:107]
Interest Rate Risk

[0000106040-22-000055:mdna:108]
We have generally held a balance of fixed and variable rate debt. As of July 1, 2022, we had reduced the amount of variable rate debt to $2.70 billion from $5.43 billion as of July 2, 2021. As of July 1, 2022, a one percent increase in the variable rate of interest would increase annual interest expense by $27 million. We currently have pay-fixed interest rate swaps of $2.0 billion notional amount, which would mitigate the impact of fluctuations in variable interest rates through February 2023.

[0000106040-22-000055:mdna:109]
Foreign Exchange Contracts

[0000106040-22-000055:mdna:110]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 8, Note 7, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:111]
43

[0000106040-22-000055:mdna:112]
Indemnifications

[0000106040-22-000055:mdna:113]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-22-000055:mdna:114]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-22-000055:mdna:115]
Stock Repurchase Program

[0000106040-22-000055:mdna:116]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of our common stock, which authorization is effective through July 25, 2023. For the year ended July 1, 2022, we did not make any stock repurchases and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of July 1, 2022 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-22-000055:mdna:117]
Cash Dividend

[0000106040-22-000055:mdna:118]
We issued a quarterly cash dividend from the first quarter of 2013 up to the third quarter of 2020. In April 2020, we suspended our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-22-000055:mdna:119]
Recent Accounting Pronouncements

[0000106040-22-000055:mdna:120]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-22-000055:mdna:121]
Critical Accounting Policies and Estimates

[0000106040-22-000055:mdna:122]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0000106040-22-000055:mdna:123]
Revenue

[0000106040-22-000055:mdna:124]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0000106040-22-000055:mdna:125]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgment and differences between the estimated and actual amounts of variable consideration can be significant.

[0000106040-22-000055:mdna:126]
Inventories

[0000106040-22-000055:mdna:127]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-22-000055:mdna:128]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results. While adjustments to these reserves have generally not been material, in 2019, we recorded a charge to Cost of Sales of $110 million primarily to reduce component inventory to net realizable value as a result of a sudden change in demand for certain products.

[0000106040-22-000055:mdna:129]
Income Taxes

[0000106040-22-000055:mdna:130]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-22-000055:mdna:131]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-22-000055:mdna:132]
Goodwill

[0000106040-22-000055:mdna:133]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fourth quarter for each reporting unit. We use qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to perform a quantitative approach to determine the amount of impairment. We are required to use judgment when applying the goodwill impairment test, including in the identification of our reporting units. We also make judgments and assumptions in the assignment of assets and liabilities to our reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each of our reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations. Our recent assessments have indicated that fair value exceeds carrying value by a reasonable margin and we have not identified any impairment indicators for our reporting units.
