# WDC 8-K — 0000106040-22-000049 filed 2022-08-05

## item codes, every 8-K on or before 2022-08-25

- 2022-08-05 0000106040-22-000049 — 2.02, 9.01
- 2022-07-01 0001193125-22-187239 — 1.01, 9.01
- 2022-06-17 0001193125-22-176478 — 5.02, 9.01
- 2022-06-08 0001193125-22-169552 — 1.01, 7.01, 8.01, 9.01
- 2022-04-28 0000106040-22-000030 — 2.02, 9.01
- 2022-01-27 0001193125-22-019801 — 5.02, 7.01, 9.01
- 2022-01-27 0000106040-22-000010 — 2.02, 9.01
- 2022-01-07 0001193125-22-004434 — 1.01, 2.03, 7.01
- 2021-12-10 0001193125-21-353971 — 1.01, 2.03, 7.01, 8.01, 9.01
- 2021-12-06 0001193125-21-348304 — 7.01
- 2021-11-19 0001193125-21-335120 — 5.04, 9.01
- 2021-11-18 0001193125-21-332703 — 5.02
- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2022-08-25

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-22-000049:8k_2_02:1]
EX-99.1
2
ex991-pressreleaseq422.htm
EX-99.1

[0000106040-22-000049:8k_2_02:2]
Document

[0000106040-22-000049:8k_2_02:3]
Exhibit 99.1

[0000106040-22-000049:8k_2_02:4]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:5]
News Summary

[0000106040-22-000049:8k_2_02:6]
•Fourth quarter revenue was $4.53 billion, down 8% year-over-year (YoY). Cloud revenue increased 5%, Client revenue declined 14%, and Consumer revenue declined 23% YoY. Fiscal year 2022 revenue was $18.79 billion, up 11% YoY.

[0000106040-22-000049:8k_2_02:7]
•Fourth quarter GAAP earnings per share (EPS) was $0.95 and Non-GAAP EPS was $1.78. Fiscal year 2022 GAAP EPS was $4.75 and non-GAAP EPS was $8.22.

[0000106040-22-000049:8k_2_02:8]
•Generated operating cash flow of $295 million and free cash flow of $(97) million in the fourth quarter. Generated operating cash flow of $1.88 billion and free cash flow of $0.68 billion in fiscal year 2022.

[0000106040-22-000049:8k_2_02:9]
•Expect fiscal first quarter 2023 revenue to be in the range of $3.60 billion to $3.80 billion with Non-GAAP EPS in the range of $0.35 to $0.65.

[0000106040-22-000049:8k_2_02:10]
SAN JOSE, Calif., — August 5, 2022 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal fourth quarter and fiscal year 2022 financial results.

[0000106040-22-000049:8k_2_02:11]
“I am proud of our team for driving strong fiscal year 2022 performance, during which revenue grew 11% and non-GAAP EPS increased 81%, demonstrating progress in unlocking the earnings potential of our business,” said David Goeckeler, Western Digital CEO. “In addition to strong financial performance, fiscal year 2022 was a hallmark year for Western Digital from an innovation, product development and execution perspective. The combination of our innovation engine and the multiple channels to deliver our products to the market puts Western Digital in a great position to capitalize on the large and growing opportunities in storage ahead even in the midst of macro dynamics weighing on near-term demand.”

[0000106040-22-000049:8k_2_02:12]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:13]
Q4 2022 Financial Highlights

[0000106040-22-000049:8k_2_02:14]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q4 2022 | Q3 2022 | Q/Q |  | Q4 2022 | Q3 2022 | Q/Q |
| Revenue ($M) |  | $4,528 | $4,381 | up 3% |  | $4,528 | $4,381 | up 3% |
| Gross Margin |  | 31.9% | 27.0% | up 4.9 ppt |  | 32.3% | 31.7% | up 0.6 ppt |
| Operating Expenses ($M) |  | $883 | $857 | up 3% |  | $760 | $740 | up 3% |
| Operating Income ($M) |  | $562 | $324 | up 73% |  | $702 | $650 | up 8% |
| Net Income ($M) |  | $301 | $25 | * |  | $567 | $521 | up 9% |
| Earnings Per Share |  | $0.95 | $0.08 | * |  | $1.78 | $1.65 | up 8% |

[0000106040-22-000049:8k_2_02:15]
* not a meaningful figure

[0000106040-22-000049:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q4 2022 | Q4 2021 | Y/Y |  | Q4 2022 | Q4 2021 | Y/Y |
| Revenue ($M) |  | $4,528 | $4,920 | down 8% |  | $4,528 | $4,920 | down 8% |
| Gross Margin |  | 31.9% | 31.8% | up 0.1 ppt |  | 32.3% | 32.9% | down 0.6 ppt |
| Operating Expenses ($M) |  | $883 | $891 | down 1% |  | $760 | $790 | down 4% |
| Operating Income ($M) |  | $562 | $675 | down 17% |  | $702 | $828 | down 15% |
| Net Income ($M) |  | $301 | $622 | down 52% |  | $567 | $680 | down 17% |
| Earnings Per Share |  | $0.95 | $1.97 | down 52% |  | $1.78 | $2.16 | down 18% |

[0000106040-22-000049:8k_2_02:17]
The company generated $295 million in cash flow from operations, made a scheduled and discretionary debt repayment of $150 million and ended the quarter with $2.33 billion of total cash and cash equivalents.

[0000106040-22-000049:8k_2_02:18]
Fiscal Year 2022 Financial Highlights

[0000106040-22-000049:8k_2_02:19]
|  |  | GAAP |  | Non-GAAP |
|  |  | 2022 | 2021 | Y/Y |  | 2022 | 2021 | Y/Y |
| Revenue ($M) |  | $18,793 | $16,922 | up 11% |  | $18,793 | $16,922 | up 11% |
| Gross Margin |  | 31.3% | 26.7% | up 4.6 ppt |  | 32.9% | 28.6% | up 4.3 ppt |
| Operating Expenses ($M) |  | $3,483 | $3,301 | up 6% |  | $3,002 | $2,926 | up 3% |
| Operating Income ($M) |  | $2,391 | $1,220 | up 96% |  | $3,186 | $1,906 | up 67% |
| Net Income ($M) |  | $1,500 | $821 | up 83% |  | $2,599 | $1,406 | up 85% |
| Earnings Per Share |  | $4.75 | $2.66 | up 79% |  | $8.22 | $4.55 | up 81% |

[0000106040-22-000049:8k_2_02:20]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-22-000049:8k_2_02:21]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:22]
End Market Summary

[0000106040-22-000049:8k_2_02:23]
| Revenue ($M) | Q4 2022 | Q3 2022 | Q/Q |  |  | Q4 2021 | Y/Y | 2022 | 2021 | Y/Y |  |  |  |  |  |  |
| Cloud | $2,098 | $1,774 | up 18% |  |  | $1,995 | up 5% | $8,017 | $5,723 | up 40% |  |  |  |  |  |  |
| Client | 1,637 | 1,732 | down 5% |  |  | 1,895 | down 14% | 7,076 | 7,281 | down 3% |  |  |  |  |  |  |
| Consumer | 793 | 875 | down 9% |  |  | 1,030 | down 23% | 3,700 | 3,918 | down 6% |  |  |  |  |  |  |
| Total Revenue | $4,528 | $4,381 | up 3% |  |  | $4,920 | down 8% | $18,793 | $16,922 | up 11% |  |  |  |  |  |  |

[0000106040-22-000049:8k_2_02:24]
In the fiscal fourth quarter:

[0000106040-22-000049:8k_2_02:25]
•Cloud represented 46% of total revenue. Within Cloud, the continued ramp of our 18-terabyte and 20-terabyte drives drove a 7% year-over-year increase in nearline HDD revenue. In Flash, enterprise SSD revenue more than doubled sequentially and was up 38% year-over-year.

[0000106040-22-000049:8k_2_02:26]
•Client represented 36% of total revenue. On both a sequential and year-over-year basis, client HDD led the revenue decline while Flash was roughly flat.

[0000106040-22-000049:8k_2_02:27]
•Consumer represented 18% of revenue.  On a sequential basis, the revenue decline was primarily due to lower retail HDD shipments. The year-over-year decrease was due to broad-based decline in retail products across HDD and Flash.

[0000106040-22-000049:8k_2_02:28]
In fiscal year 2022:

[0000106040-22-000049:8k_2_02:29]
•Cloud represented 42% of total revenue. The revenue increase was led by a 38% increase in nearline HDD while Flash products for enterprise SSD applications more than doubled.

[0000106040-22-000049:8k_2_02:30]
•Client represented 38% of total revenue. Revenue declined modestly as growth in Flash was offset by a mid-30% decrease in client HDD.

[0000106040-22-000049:8k_2_02:31]
•Consumer represented 20% of total revenue. The revenue decline was all attributed to retail HDD.

[0000106040-22-000049:8k_2_02:32]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:33]
Business Outlook for Fiscal First Quarter of 2023

[0000106040-22-000049:8k_2_02:34]
|  | Three Months EndingSeptember 30, 2022 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) | $3.60 - $3.80 |  | $3.60 - $3.80 |
| Gross margin | 27.1% - 29.1% |  | 27.5% - 29.5% |
| Operating expenses ($M) | $870 - $890 |  | $760 - $780 |
| Interest and other expense, net ($M) | ~$70 |  | ~$70 |
| Tax rate | N/A |  | 28% - 30%(2) |
| Diluted earnings per share | N/A |  | $0.35 - $0.65 |
| Diluted shares outstanding (in millions) | ~319 |  | ~319 |

[0000106040-22-000049:8k_2_02:35]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense of approximately $10 million to $15 million. The company’s Non-GAAP operating expenses guidance excludes amortization of acquired intangible assets and stock-based compensation expense, totaling approximately $100 million to $120 million. In the aggregate, Non-GAAP diluted earnings per share guidance excludes these items totaling $110 million to $135 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, and Non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the company excludes from its Non-GAAP tax rate and Non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP tax rate and Non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, tax rate and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-22-000049:8k_2_02:36]
(2) The Non-GAAP tax rate provided is based on a percentage of Non-GAAP pre-tax income. Due to differences in the tax treatment of items excluded from our Non-GAAP net income and because our tax rate is based on an estimated forecasted annual GAAP tax rate, our estimated Non-GAAP tax rate may differ from our GAAP tax rate and from our actual tax rates. Tax law changes that became effective for our fiscal year 2023 require the capitalization of certain R&D costs that were previously eligible for immediate deduction from taxable income. The impact of these tax law changes is expected to include an immediate increase in our tax rate of approximately 12 percentage points, which is reflected in the guidance provided in the table above. This impact on the tax rate is expected to decrease gradually over time.

[0000106040-22-000049:8k_2_02:37]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:38]
Investor Communications

[0000106040-22-000049:8k_2_02:39]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal first quarter of 2023 will be broadcast live online today at 5:30 a.m. Pacific/8:30 a.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-22-000049:8k_2_02:40]
About Western Digital

[0000106040-22-000049:8k_2_02:41]
Western Digital is on a mission to unlock the potential of data by harnessing the possibility to use it. With Flash and HDD franchises, underpinned by advancements in memory technologies, we create breakthrough innovations and powerful data storage solutions that enable the world to actualize its aspirations. Core to our values, we recognize the urgency to combat climate change and have committed to ambitious carbon reduction goals approved by the Science Based Targets initiative. Learn more about Western Digital and the Western Digital®, SanDisk® and WD® brands at www.westerndigital.com.

[0000106040-22-000049:8k_2_02:42]
Forward-Looking Statements

[0000106040-22-000049:8k_2_02:43]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2022 Financial Results

[0000106040-22-000049:8k_2_02:44]
in manufacturing or other supply chain disruptions; hiring and retention of key employees; our level of debt and other financial obligations; changes to our relationships with key customers; disruptions in operations from cybersecurity incidents or other system security risks; actions by competitors; risks associated with compliance with changing legal and regulatory requirements and the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-K filed with the SEC on August 27, 2021, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update or revise these forward-looking statements to reflect new information or events, except as required by law.

[0000106040-22-000049:8k_2_02:45]
###

[0000106040-22-000049:8k_2_02:46]
Western Digital, the Western Digital logo, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-22-000049:8k_2_02:47]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:48]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-22-000049:8k_2_02:49]
(in millions; unaudited; on a US GAAP basis)

[0000106040-22-000049:8k_2_02:50]
|  | July 1,2022 |  | July 2,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,327 |  |  | $ | 3,370 |  |
| Accounts receivable, net | 2,804 |  |  | 2,257 |  |
| Inventories | 3,638 |  |  | 3,616 |  |
| Other current assets | 684 |  |  | 514 |  |
| Total current assets | 9,453 |  |  | 9,757 |  |
| Property, plant and equipment, net | 3,670 |  |  | 3,188 |  |
| Notes receivable and investments in Flash Ventures | 1,396 |  |  | 1,586 |  |
| Goodwill | 10,041 |  |  | 10,066 |  |
| Other intangible assets, net | 213 |  |  | 442 |  |
| Other non-current assets | 1,486 |  |  | 1,093 |  |
| Total assets | $ | 26,259 |  |  | $ | 26,132 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,902 |  |  | $ | 1,934 |  |
| Accounts payable to related parties | 320 |  |  | 398 |  |
| Accrued expenses | 1,825 |  |  | 1,653 |  |
| Accrued compensation | 510 |  |  | 634 |  |
| Current portion of long-term debt | — |  |  | 251 |  |
| Total current liabilities | 4,557 |  |  | 4,870 |  |
| Long-term debt | 7,022 |  |  | 8,474 |  |
| Other liabilities | 2,459 |  |  | 2,067 |  |
| Total liabilities | 14,038 |  |  | 15,411 |  |
| Total shareholders’ equity | 12,221 |  |  | 10,721 |  |
| Total liabilities and shareholders’ equity | $ | 26,259 |  |  | $ | 26,132 |  |

[0000106040-22-000049:8k_2_02:51]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:52]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-22-000049:8k_2_02:53]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-22-000049:8k_2_02:54]
|  | Three Months Ended |  | Years Ended |
|  | July 1,2022 |  | July 2,2021 |  | July 1,2022 |  | July 2,2021 |
| Revenue, net | $ | 4,528 |  |  | $ | 4,920 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |
| Cost of revenue | 3,083 |  |  | 3,354 |  |  | 12,919 |  |  | 12,401 |  |
| Gross profit | 1,445 |  |  | 1,566 |  |  | 5,874 |  |  | 4,521 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 598 |  |  | 598 |  |  | 2,323 |  |  | 2,243 |  |
| Selling, general and administrative | 266 |  |  | 297 |  |  | 1,117 |  |  | 1,105 |  |
| Employee termination, asset impairment and other charges | 19 |  |  | (4) |  |  | 43 |  |  | (47) |  |
| Total operating expenses | 883 |  |  | 891 |  |  | 3,483 |  |  | 3,301 |  |
| Operating income | 562 |  |  | 675 |  |  | 2,391 |  |  | 1,220 |  |
| Interest and other expense, net | (51) |  |  | (79) |  |  | (268) |  |  | (293) |  |
| Income before taxes | 511 |  |  | 596 |  |  | 2,123 |  |  | 927 |  |
| Income tax expense/(benefit) | 210 |  |  | (26) |  |  | 623 |  |  | 106 |  |
| Net income | $ | 301 |  |  | $ | 622 |  |  | $ | 1,500 |  |  | $ | 821 |  |
| Income per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.96 |  |  | $ | 2.03 |  |  | $ | 4.81 |  |  | $ | 2.69 |  |
| Diluted | $ | 0.95 |  |  | $ | 1.97 |  |  | $ | 4.75 |  |  | $ | 2.66 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 314 |  |  | 307 |  |  | 312 |  |  | 305 |  |
| Diluted | 318 |  |  | 315 |  |  | 316 |  |  | 309 |  |

[0000106040-22-000049:8k_2_02:55]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:56]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-22-000049:8k_2_02:57]
(in millions; unaudited; on a US GAAP basis)

[0000106040-22-000049:8k_2_02:58]
|  | Three Months Ended |  | Years Ended |
|  | July 1,2022 |  | July 2,2021 |  | July 1,2022 |  | July 2,2021 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income | $ | 301 |  |  | $ | 622 |  |  | $ | 1,500 |  |  | $ | 821 |  |
| Adjustments to reconcile net income to net cash provided by operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 221 |  |  | 251 |  |  | 929 |  |  | 1,212 |  |
| Stock-based compensation | 77 |  |  | 79 |  |  | 326 |  |  | 318 |  |
| Deferred income taxes | 73 |  |  | (201) |  |  | 114 |  |  | (242) |  |
| Gain on disposal of assets | (2) |  |  | (5) |  |  | (16) |  |  | (70) |  |
| Gain on business divestiture | (9) |  |  | — |  |  | (9) |  |  | — |  |
| Amortization of debt issuance costs and discounts | 10 |  |  | 10 |  |  | 44 |  |  | 40 |  |
| Other non-cash operating activities, net | 25 |  |  | 20 |  |  | 67 |  |  | (6) |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (450) |  |  | (353) |  |  | (546) |  |  | 121 |  |
| Inventories | 23 |  |  | 67 |  |  | (22) |  |  | (546) |  |
| Accounts payable | (29) |  |  | 150 |  |  | (129) |  |  | 11 |  |
| Accounts payable to related parties | (76) |  |  | 1 |  |  | (78) |  |  | (9) |  |
| Accrued expenses | 219 |  |  | 101 |  |  | 171 |  |  | 352 |  |
| Accrued compensation | 26 |  |  | 140 |  |  | (123) |  |  | 162 |  |
| Other assets and liabilities, net | (114) |  |  | 112 |  |  | (348) |  |  | (266) |  |
| Net cash provided by operating activities | 295 |  |  | 994 |  |  | 1,880 |  |  | 1,898 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (278) |  |  | (304) |  |  | (1,107) |  |  | (1,003) |  |
| Activity related to Flash Ventures, net | (114) |  |  | 102 |  |  | (91) |  |  | 231 |  |
| Strategic Investments and other, net | 22 |  |  | (1) |  |  | 6 |  |  | 7 |  |
| Net cash used in investing activities | (370) |  |  | (203) |  |  | (1,192) |  |  | (765) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | 55 |  |  | 58 |  |  | 32 |  |  | 78 |  |
| Repayment of debt | (150) |  |  | (213) |  |  | (3,621) |  |  | (886) |  |
| Proceeds from debt | — |  |  | — |  |  | 1,894 |  |  | — |  |
| Debt issuance costs | — |  |  | — |  |  | (23) |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | (9) |  |
| Net cash used in financing activities | (95) |  |  | (155) |  |  | (1,718) |  |  | (817) |  |
| Effect of exchange rate changes on cash | (8) |  |  | — |  |  | (13) |  |  | 6 |  |
| Net increase/(decrease) in cash and cash equivalents | (178) |  |  | 636 |  |  | (1,043) |  |  | 322 |  |
| Cash and cash equivalents, beginning of period | 2,505 |  |  | 2,734 |  |  | 3,370 |  |  | 3,048 |  |
| Cash and cash equivalents, end of period | $ | 2,327 |  |  | $ | 3,370 |  |  | $ | 2,327 |  |  | $ | 3,370 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Noncash exchange of Term Loan A-1 for Term Loan A-2 | $ | — |  |  | $ | — |  |  | $ | 2,104 |  |  | $ | — |  |

[0000106040-22-000049:8k_2_02:59]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:60]
Supplemental Operating Segment Results

[0000106040-22-000049:8k_2_02:61]
(in millions; except percentages; unaudited)

[0000106040-22-000049:8k_2_02:62]
|  | Three Months Ended |  | Years Ended |
|  | July 1,2022 |  | July 2,2021 |  | July 1,2022 |  | July 2,2021 |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 2,400 |  |  | $ | 2,419 |  |  | $ | 9,753 |  |  | $ | 8,706 |  |
| HDD | 2,128 |  |  | 2,501 |  |  | 9,040 |  |  | 8,216 |  |
| Total net revenue | $ | 4,528 |  |  | $ | 4,920 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 862 |  |  | $ | 859 |  |  | $ | 3,527 |  |  | $ | 2,611 |  |
| HDD | 600 |  |  | 759 |  |  | 2,661 |  |  | 2,221 |  |
| Total gross profit for segments | 1,462 |  |  | 1,618 |  |  | 6,188 |  |  | 4,832 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Contamination related charges | (4) |  |  | — |  |  | (207) |  |  | — |  |
| Amortization of acquired intangible assets | (1) |  |  | (38) |  |  | (66) |  |  | (331) |  |
| Stock-based compensation expense | (12) |  |  | (14) |  |  | (48) |  |  | (55) |  |
| Recoveries from a power outage incident | — |  |  | — |  |  | 7 |  |  | 75 |  |
| Total unallocated corporate items | (17) |  |  | (52) |  |  | (314) |  |  | (311) |  |
| Consolidated gross profit | $ | 1,445 |  |  | $ | 1,566 |  |  | $ | 5,874 |  |  | $ | 4,521 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 35.9 | % |  | 35.5 | % |  | 36.2 | % |  | 30.0 | % |
| HDD | 28.2 | % |  | 30.3 | % |  | 29.4 | % |  | 27.0 | % |
| Total gross margin for segments | 32.3 | % |  | 32.9 | % |  | 32.9 | % |  | 28.6 | % |
| Consolidated gross margin | 31.9 | % |  | 31.8 | % |  | 31.3 | % |  | 26.7 | % |

[0000106040-22-000049:8k_2_02:63]
Historically, the company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the company announced a decision to reorganize its business by forming two separate product business units: flash-based products (“Flash”) and hard disk drives (“HDD”). To align with the new operating model and business structure, the company made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of its operating segments and now reports two segments: Flash and HDD. In the table above, total gross profit for segments and total gross margin for segments are Non-GAAP financial measures, which are also referred to herein as Non-GAAP gross profit and Non-GAAP gross margin, respectively.

[0000106040-22-000049:8k_2_02:64]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:65]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-22-000049:8k_2_02:66]
(in millions; unaudited)

[0000106040-22-000049:8k_2_02:67]
|  | Three Months Ended |  | Years Ended |  |  |
|  | July 1,2022 |  | April 1,2022 |  | July 2,2021 |  | July 1,2022 |  | July 2,2021 |  |  |
| GAAP cost of revenue | $ | 3,083 |  |  | $ | 3,200 |  |  | $ | 3,354 |  |  | $ | 12,919 |  |  | $ | 12,401 |  |  |  |
| Contamination related charges | (4) |  |  | (203) |  |  | — |  |  | (207) |  |  | — |  |  |  |
| Stock-based compensation expense | (12) |  |  | (13) |  |  | (14) |  |  | (48) |  |  | (55) |  |  |  |
| Amortization of acquired intangible assets | (1) |  |  | — |  |  | (38) |  |  | (66) |  |  | (331) |  |  |  |
| Recoveries from a power outage incident | — |  |  | 7 |  |  | — |  |  | 7 |  |  | 75 |  |  |  |
| Non-GAAP cost of revenue | $ | 3,066 |  |  | $ | 2,991 |  |  | $ | 3,302 |  |  | $ | 12,605 |  |  | $ | 12,090 |  |  |  |
| GAAP gross profit | $ | 1,445 |  |  | $ | 1,181 |  |  | $ | 1,566 |  |  | $ | 5,874 |  |  | $ | 4,521 |  |  |  |
| Contamination related charges | 4 |  |  | 203 |  |  | — |  |  | 207 |  |  | — |  |  |  |
| Stock-based compensation expense | 12 |  |  | 13 |  |  | 14 |  |  | 48 |  |  | 55 |  |  |  |
| Amortization of acquired intangible assets | 1 |  |  | — |  |  | 38 |  |  | 66 |  |  | 331 |  |  |  |
| Recoveries from a power outage incident | — |  |  | (7) |  |  | — |  |  | (7) |  |  | (75) |  |  |  |
| Non-GAAP gross profit | $ | 1,462 |  |  | $ | 1,390 |  |  | $ | 1,618 |  |  | $ | 6,188 |  |  | $ | 4,832 |  |  |  |
| GAAP operating expenses | $ | 883 |  |  | $ | 857 |  |  | $ | 891 |  |  | $ | 3,483 |  |  | $ | 3,301 |  |  |  |
| Stock-based compensation expense | (65) |  |  | (73) |  |  | (65) |  |  | (278) |  |  | (263) |  |  |  |
| Amortization of acquired intangible assets | (39) |  |  | (39) |  |  | (38) |  |  | (155) |  |  | (155) |  |  |  |
| Employee termination, asset impairment and other charges | (19) |  |  | (4) |  |  | 4 |  |  | (43) |  |  | 47 |  |  |  |
| Other | — |  |  | (1) |  |  | (2) |  |  | (5) |  |  | (4) |  |  |  |
| Non-GAAP operating expenses | $ | 760 |  |  | $ | 740 |  |  | $ | 790 |  |  | $ | 3,002 |  |  | $ | 2,926 |  |  |  |
| GAAP operating income | $ | 562 |  |  | $ | 324 |  |  | $ | 675 |  |  | $ | 2,391 |  |  | $ | 1,220 |  |  |  |
| Cost of revenue adjustments | 17 |  |  | 209 |  |  | 52 |  |  | 314 |  |  | 311 |  |  |  |
| Operating expense adjustments | 123 |  |  | 117 |  |  | 101 |  |  | 481 |  |  | 375 |  |  |  |
| Non-GAAP operating income | $ | 702 |  |  | $ | 650 |  |  | $ | 828 |  |  | $ | 3,186 |  |  | $ | 1,906 |  |  |  |
| GAAP interest and other expense, net | $ | (51) |  |  | $ | (62) |  |  | $ | (79) |  |  | $ | (268) |  |  | $ | (293) |  |  |  |
| Non-cash economic interest and Other | (14) |  |  | (2) |  |  | — |  |  | 3 |  |  | 11 |  |  |  |
| Non-GAAP interest and other expense, net | $ | (65) |  |  | $ | (64) |  |  | $ | (79) |  |  | $ | (265) |  |  | $ | (282) |  |  |  |
| GAAP income tax expense/(benefit) | $ | 210 |  |  | $ | 237 |  |  | $ | (26) |  |  | $ | 623 |  |  | $ | 106 |  |  |  |
| Income tax adjustments | (140) |  |  | (172) |  |  | 95 |  |  | (301) |  |  | 112 |  |  |  |
| Non-GAAP income tax expense | $ | 70 |  |  | $ | 65 |  |  | $ | 69 |  |  | $ | 322 |  |  | $ | 218 |  |  |  |

[0000106040-22-000049:8k_2_02:68]
WESTERN DIGITAL CORPORATION

[0000106040-22-000049:8k_2_02:69]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-22-000049:8k_2_02:70]
(in millions, except per share amounts; unaudited)

[0000106040-22-000049:8k_2_02:71]
|  | Three Months Ended |  | Years Ended |
|  | July 1,2022 |  | April 1,2022 |  | July 2,2021 |  | July 1,2022 |  | July 2,2021 |
| GAAP net income | $ | 301 |  |  | $ | 25 |  |  | $ | 622 |  |  | $ | 1,500 |  |  | $ | 821 |  |
| Contamination related charges | 4 |  |  | 203 |  |  | — |  |  | 207 |  |  | — |  |
| Stock-based compensation expense | 77 |  |  | 86 |  |  | 79 |  |  | 326 |  |  | 318 |  |
| Amortization of acquired intangible assets | 40 |  |  | 39 |  |  | 76 |  |  | 221 |  |  | 486 |  |
| Recoveries from a power outage incident | — |  |  | (7) |  |  | — |  |  | (7) |  |  | (75) |  |
| Employee termination, asset impairment and other charges | 19 |  |  | 4 |  |  | (4) |  |  | 43 |  |  | (47) |  |
| Non-cash economic interest and Other | (14) |  |  | (1) |  |  | 2 |  |  | 8 |  |  | 15 |  |
| Income tax adjustments | 140 |  |  | 172 |  |  | (95) |  |  | 301 |  |  | (112) |  |
| Non-GAAP net income | $ | 567 |  |  | $ | 521 |  |  | $ | 680 |  |  | $ | 2,599 |  |  | $ | 1,406 |  |
| Diluted income per common share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 0.95 |  |  | $ | 0.08 |  |  | $ | 1.97 |  |  | $ | 4.75 |  |  | $ | 2.66 |  |
| Non-GAAP | $ | 1.78 |  |  | $ | 1.65 |  |  | $ | 2.16 |  |  | $ | 8.22 |  |  | $ | 4.55 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 318 |  |  | 316 |  |  | 315 |  |  | 316 |  |  | 309 |  |
| Non-GAAP | 318 |  |  | 316 |  |  | 315 |  |  | 316 |  |  | 309 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by operating activities | $ | 295 |  |  | $ | 398 |  |  | $ | 994 |  |  | $ | 1,880 |  |  | $ | 1,898 |  |
| Purchases of property, plant and equipment, net | (278) |  |  | (290) |  |  | (304) |  |  | (1,107) |  |  | (1,003) |  |
| Activity related to Flash Ventures, net | (114) |  |  | 40 |  |  | 102 |  |  | (91) |  |  | 231 |  |
| Free cash flow | $ | (97) |  |  | $ | 148 |  |  | $ | 792 |  |  | $ | 682 |  |  | $ | 1,126 |  |

[0000106040-22-000049:8k_2_02:72]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth Non-GAAP cost of revenue; Non-GAAP gross profit; Non-GAAP gross margin; Non-GAAP operating expenses; Non-GAAP operating income; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income; Non-GAAP diluted income per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, contamination related charges, stock-based compensation expense, amortization of acquired intangible assets, recoveries from a power outage incident, employee termination, asset impairment and other charges, non-cash economic interest, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company's results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company's performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-22-000049:8k_2_02:73]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-22-000049:8k_2_02:74]
Contamination related charges. In February 2022, a contamination of certain materials used in the company's manufacturing process occurred and affected production operation at the flash-based memory manufacturing facilities in Yokkaichi and Kitakami, Japan, which are operated through the company's joint business ventures with Kioxia Corporation (collectively, "Flash Ventures"). The contamination resulted in scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs, which are expensed as incurred. These charges are inconsistent in amount and frequency, and the company believes these charges are not part of the ongoing production operation of its business.

[0000106040-22-000049:8k_2_02:75]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company's control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company's peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0000106040-22-000049:8k_2_02:76]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company's acquisitions and any related impairment charges.

[0000106040-22-000049:8k_2_02:77]
Recoveries from a power outage incident. In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated through the company's joint venture with Kioxia Corporation in Yokkaichi, Japan. The power outage incident resulted in costs associated with the repair of damaged tools and the write-off of damaged inventory and unabsorbed manufacturing overhead costs which are expensed as incurred. During fiscal years 2021 and 2022, the company received recoveries of these losses from other parties. The recoveries are inconsistent in amount and frequency, and the company believes they are not part of the ongoing production operation of its business.

[0000106040-22-000049:8k_2_02:78]
Employee termination, asset impairment and other charges. From time-to-time, in order to realign the company's operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-22-000049:8k_2_02:79]
Non-cash economic interest. The company excludes non-cash economic interest expense associated with its convertible notes. These charges do not reflect the company's operating results, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-22-000049:8k_2_02:80]
Other adjustments. From time-to-time, the company incurs charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-22-000049:8k_2_02:81]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments to estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act and the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-22-000049:8k_2_02:82]
Additionally, free cash flow is defined as cash flows provided by operating activities less purchases of property, plant and equipment, net, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company's business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-22-000049:8k_2_02:83]
___________________

[0000106040-22-000049:8k_2_02:84]
Contacts:

[0000106040-22-000049:8k_2_02:85]
Western Digital Corp.

[0000106040-22-000049:8k_2_02:86]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Robin Schultz |
| 949.672.9655 |  | 408.573.5043 |
| peter.andrew@wdc.com |  | robin.schultz@wdc.com |
| investor@wdc.com |  |  |
