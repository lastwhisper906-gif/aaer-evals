# WDC notes — 0000106040-23-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-23-000034:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both NAND flash and hard disk drive technologies.

[0000106040-23-000034:notes:2]
The Company’s broad portfolio of technology and products address the following key end markets: Cloud, Client and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

[0000106040-23-000034:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-23-000034:notes:4]
[same as prior period, unchanged from 0000106040-23-000017:notes:3]

[0000106040-23-000034:notes:5]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-23-000034:notes:6]
[same as prior period, unchanged from 0000106040-23-000017:notes:5]

[0000106040-23-000034:notes:7]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”).

[0000106040-23-000034:notes:8]
The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), evaluates the performance of the Company and makes decisions regarding the allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are either not available or not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000106040-23-000034:notes:9]
[same as prior period, unchanged from 0000106040-23-000017:notes:8]

[0000106040-23-000034:notes:10]
[same as prior period, unchanged from 0000106040-23-000017:notes:9]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-23-000034:notes:11]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-23-000034:notes:12]
In September 2022, the Financial Accounting Standards Board issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU requires the Company to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 and to provide certain rollforward information related to those obligations beginning in the Company’s first fiscal quarter of 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. The Company adopted the guidance on the first day of fiscal year 2024, except for the rollforward information, which the Company is compiling and intends to provide beginning in fiscal year 2025. See Note 15, Supplier Finance Program, of the Notes to the Condensed Consolidated Financial Statements for information regarding the supplier finance program.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-23-000034:notes:13]
Business Segments, Geographic Information, and Concentrations of Risk
The following table summarizes the operating performance of the Company’s reportable segments:

[0000106040-23-000034:notes:14]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,556 |  |  | $ | 1,722 |  |  |  |  |  |
| HDD | 1,194 |  |  | 2,014 |  |  |  |  |  |
| Total net revenue | $ | 2,750 |  |  | $ | 3,736 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | (161) |  |  | $ | 422 |  |  |  |  |  |
| HDD | 273 |  |  | 574 |  |  |  |  |  |
| Total gross profit for segments | 112 |  |  | 996 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (13) |  |  | (14) |  |  |  |  |  |
| Amortization of acquired intangible assets | — |  |  | (1) |  |  |  |  |  |
| Total unallocated corporate items | (13) |  |  | (15) |  |  |  |  |  |
| Consolidated gross profit | $ | 99 |  |  | $ | 981 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | (10.3) | % |  | 24.5 | % |  |  |  |  |
| HDD | 22.9 | % |  | 28.5 | % |  |  |  |  |
| Consolidated gross margin | 3.6 | % |  | 26.3 | % |  |  |  |  |

[0000106040-23-000034:notes:15]
Disaggregated Revenue

[0000106040-23-000034:notes:16]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-23-000034:notes:17]
The Company’s disaggregated revenue information is as follows:

[0000106040-23-000034:notes:18]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29,2023 |  | September 30,2022 |
|  |  |  |  |  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 872 |  |  | $ | 1,829 |  |
| Client |  |  |  |  | 1,147 |  |  | 1,229 |  |
| Consumer |  |  |  |  | 731 |  |  | 678 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 1,551 |  |  | $ | 1,686 |  |
| Americas |  |  |  |  | 662 |  |  | 1,423 |  |
| Europe, Middle East and Africa |  |  |  |  | 537 |  |  | 627 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |

[0000106040-23-000034:notes:19]
The Company’s top 10 customers accounted for 44% and 52% of its net revenue for the three months ended September 29, 2023 and September 30, 2022, respectively. For the three months ended September 29, 2023 and September 30, 2022, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-23-000034:notes:20]
Goodwill

[0000106040-23-000034:notes:21]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed a goodwill impairment assessment for each segment and concluded there were no impairment indicators as of either the beginning or end of the three months ended September 29, 2023. The following table provides a summary of goodwill activity for the period:

[0000106040-23-000034:notes:22]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at June 30, 2023 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |
| Foreign currency translation adjustment | (1) |  |  | (1) |  |  | (2) |  |
| Balance at September 29, 2023 | $ | 5,715 |  |  | $ | 4,320 |  |  | $ | 10,035 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-23-000034:notes:23]
[same as prior period, unchanged from 0000106040-23-000017:notes:37]

[0000106040-23-000034:notes:24]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. During the three months ended September 29, 2023 and September 30, 2022, the Company sold trade accounts receivable aggregating $150 million and $291 million, respectively. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. As of both September 29, 2023 and June 30, 2023, the amount of factored receivables that remained outstanding was $150 million.

[0000106040-23-000034:notes:25]
[same as prior period, unchanged from 0000106040-23-000017:notes:39]

[0000106040-23-000034:notes:26]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,975 |  |  | $ | 2,096 |  |
| Work-in-process | 925 |  |  | 979 |  |
| Finished goods | 597 |  |  | 623 |  |
| Total inventories | $ | 3,497 |  |  | $ | 3,698 |  |

[0000106040-23-000034:notes:27]
[same as prior period, unchanged from 0000106040-23-000017:notes:41]

[0000106040-23-000034:notes:28]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 235 |  |  | $ | 269 |  |
| Buildings and improvements | 1,842 |  |  | 1,955 |  |
| Machinery and equipment | 8,691 |  |  | 8,704 |  |
| Computer equipment and software | 473 |  |  | 470 |  |
| Furniture and fixtures | 55 |  |  | 54 |  |
| Construction-in-process | 729 |  |  | 798 |  |
| Property, plant and equipment, gross | 12,025 |  |  | 12,250 |  |
| Accumulated depreciation | (8,654) |  |  | (8,630) |  |
| Property, plant and equipment, net | $ | 3,371 |  |  | $ | 3,620 |  |

[0000106040-23-000034:notes:29]
[same as prior period, unchanged from 0000106040-23-000017:notes:43]

[0000106040-23-000034:notes:30]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of both September 29, 2023, and June 30, 2023, IPR&D included in intangible assets, net was $80 million. As of both September 29, 2023 and June 30, 2023, all other intangible assets were fully amortized.

[0000106040-23-000034:notes:31]
[same as prior period, unchanged from 0000106040-23-000017:notes:46]

[0000106040-23-000034:notes:32]
[same as prior period, unchanged from 0000106040-23-000017:notes:47]

[0000106040-23-000034:notes:33]
|  | Three Months Ended |  |  |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 244 |  |  | $ | 345 |  |  |  |  |  |  |  |
| Charges to operations | 22 |  |  | 32 |  |  |  |  |  |  |  |
| Utilization | (43) |  |  | (34) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | (5) |  |  | (3) |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 218 |  |  | $ | 340 |  |  |  |  |  |  |  |

[0000106040-23-000034:notes:34]
[same as prior period, unchanged from 0000106040-23-000017:notes:49]

[0000106040-23-000034:notes:35]
|  | September 29,2023 |  | June 30,2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 61 |  |  | $ | 97 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 157 |  |  | 147 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 218 |  |  | $ | 244 |  |  |  |  |  |  |  |

[0000106040-23-000034:notes:36]
[same as prior period, unchanged from 0000106040-23-000017:notes:51]

[0000106040-23-000034:notes:37]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 199 |  |  | $ | 464 |  |
| Non-current portion of unrecognized tax benefits | 497 |  |  | 408 |  |
| Other non-current liabilities | 702 |  |  | 543 |  |
| Total other liabilities | $ | 1,398 |  |  | $ | 1,415 |  |

[0000106040-23-000034:notes:38]
[same as prior period, unchanged from 0000106040-23-000017:notes:53]

[0000106040-23-000034:notes:39]
Accumulated other comprehensive loss (“AOCL”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCL:

[0000106040-23-000034:notes:40]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 30, 2023 | $ | (2) |  |  | $ | (357) |  |  |  |  |  |  | $ | (157) |  |  | $ | (516) |  |
| Other comprehensive loss before reclassifications | — |  |  | (38) |  |  |  |  |  |  | (101) |  |  | (139) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 43 |  |  | 43 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | 1 |  |  |  |  |  |  | 12 |  |  | 13 |  |
| Net current-period other comprehensive loss | — |  |  | (37) |  |  |  |  |  |  | (46) |  |  | (83) |  |
| Balance at September 29, 2023 | $ | (2) |  |  | $ | (394) |  |  |  |  |  |  | $ | (203) |  |  | $ | (599) |  |

[0000106040-23-000034:notes:41]
During the three months ended September 29, 2023, the amounts reclassified out of AOCL were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. 
As of September 29, 2023, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months. In addition, as of September 29, 2023, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-23-000034:notes:42]
[same as prior period, unchanged from 0000106040-23-000017:notes:57]

[0000106040-23-000034:notes:43]
[same as prior period, unchanged from 0000106040-23-000017:notes:58]

[0000106040-23-000034:notes:44]
[same as prior period, unchanged from 0000106040-23-000017:notes:59]

[0000106040-23-000034:notes:45]
[same as prior period, unchanged from 0000106040-23-000017:notes:60]

[0000106040-23-000034:notes:46]
[same as prior period, unchanged from 0000106040-23-000017:notes:61]

[0000106040-23-000034:notes:47]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of September 29, 2023 and June 30, 2023, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-23-000034:notes:48]
|  | September 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 371 |  |  | $ | — |  |  | $ | — |  |  | $ | 371 |  |
| Foreign exchange contracts | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Total assets at fair value | $ | 371 |  |  | $ | 28 |  |  | $ | — |  |  | $ | 399 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 226 |  |  | $ | — |  |  | $ | 226 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 226 |  |  | $ | — |  |  | $ | 226 |  |

[0000106040-23-000034:notes:49]
|  | June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 371 |  |  | $ | — |  |  | $ | — |  |  | $ | 371 |  |
| Foreign exchange contracts | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total assets at fair value | $ | 371 |  |  | $ | 35 |  |  | $ | — |  |  | $ | 406 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |

[0000106040-23-000034:notes:50]
[same as prior period, unchanged from 0000106040-23-000017:notes:65]

[0000106040-23-000034:notes:51]
[same as prior period, unchanged from 0000106040-23-000017:notes:66]

[0000106040-23-000034:notes:52]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2024 and the fourth quarter of 2023, respectively.

[0000106040-23-000034:notes:53]
|  | September 29, 2023 |  | June 30, 2023 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,099 |  |  | $ | 1,082 |  |  | $ | 1,099 |  |  | $ | 1,067 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | 606 |  |  | — |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,294 |  |  | 2,194 |  |  | 2,293 |  |  | 2,193 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,688 |  |  | 2,678 |  |  | 2,687 |  |  | 2,661 |  |
| 2.85% senior notes due 2029 | 496 |  |  | 401 |  |  | 496 |  |  | 400 |  |
| 3.10% senior notes due 2032 | 495 |  |  | 367 |  |  | 495 |  |  | 371 |  |
| Total | $ | 7,672 |  |  | $ | 7,328 |  |  | $ | 7,070 |  |  | $ | 6,692 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-23-000034:notes:54]
Derivative Instruments and Hedging Activities
As of September 29, 2023, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of September 29, 2023, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-23-000034:notes:55]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three months ended September 29, 2023 and September 30, 2022, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-23-000034:notes:56]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 4, Supplemental Financial Statement Data - Accumulated other comprehensive loss.

[0000106040-23-000034:notes:57]
[same as prior period, unchanged from 0000106040-23-000017:notes:72]

[0000106040-23-000034:notes:58]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of September 29, 2023 and June 30, 2023, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-23-000034:notes:59]
Debt
Debt consisted of the following:

[0000106040-23-000034:notes:60]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,700 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (28) |  |  | (30) |  |
| Subtotal | 7,672 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,850) |  |  | (1,213) |  |
| Long-term debt | $ | 5,822 |  |  | $ | 5,857 |  |

[0000106040-23-000034:notes:61]
During the three months ended September 29, 2023, the Company drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024.

[0000106040-23-000034:notes:62]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of September 29, 2023 was 7.416%.

[0000106040-23-000034:notes:63]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.375%. The all-in interest rate for Term Loan A-2 as of September 29, 2023 was 6.807%.

[0000106040-23-000034:notes:64]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 due 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of September 29, 2023, the Company was in compliance with these financial covenants.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-23-000034:notes:65]
[same as prior period, unchanged from 0000106040-23-000017:notes:85]

[0000106040-23-000034:notes:66]
[same as prior period, unchanged from 0000106040-23-000017:notes:86]

[0000106040-23-000034:notes:67]
[same as prior period, unchanged from 0000106040-23-000017:notes:87]

[0000106040-23-000034:notes:68]
|  | September 29,2023 |  | June 30,2023 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 265 |  |  | $ | 273 |  |  |  |
| Fair value of plan assets at end of period | 180 |  |  | 185 |  |  |  |
| Unfunded status | $ | 85 |  |  | $ | 88 |  |  |  |

[0000106040-23-000034:notes:69]
[same as prior period, unchanged from 0000106040-23-000017:notes:89]

[0000106040-23-000034:notes:70]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 84 |  |  | 87 |  |
| Net amount recognized | $ | 85 |  |  | $ | 88 |  |

[0000106040-23-000034:notes:71]
Net periodic benefit costs were not material for the three months ended September 29, 2023.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-23-000034:notes:72]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-23-000034:notes:73]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-23-000034:notes:74]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

[0000106040-23-000034:notes:75]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 21 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 48 |  |
| Notes receivable, Flash Forward | 699 |  |  | 709 |  |
| Investment in Flash Partners | 155 |  |  | 160 |  |
| Investment in Flash Alliance | 227 |  |  | 234 |  |
| Investment in Flash Forward | 108 |  |  | 109 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,245 |  |  | $ | 1,297 |  |

[0000106040-23-000034:notes:76]
During the three months ended September 29, 2023 and September 30, 2022, the Company made net payments to Flash Ventures of $0.9 billion and $1.0 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-23-000034:notes:77]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-23-000034:notes:78]
As of September 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $277 million and $292 million, respectively.

[0000106040-23-000034:notes:79]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-23-000034:notes:80]
|  | September 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 755 |  |
| Equity investments | 490 |  |
| Operating lease guarantees | 1,590 |  |
| Inventory and prepayments | 1,047 |  |
| Maximum estimable loss exposure | $ | 3,882 |  |

[0000106040-23-000034:notes:81]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-23-000034:notes:82]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2023 and the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 30, 2022.

[0000106040-23-000034:notes:83]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of September 29, 2023, such prepayments aggregated $539 million and will be credited against future wafer charges.

[0000106040-23-000034:notes:84]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-23-000034:notes:85]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-23-000034:notes:86]
Off-Balance Sheet Liabilities

[0000106040-23-000034:notes:87]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-23-000034:notes:88]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023.

[0000106040-23-000034:notes:89]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 237 |  |  | $ | 1,590 |  |

[0000106040-23-000034:notes:90]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023:

[0000106040-23-000034:notes:91]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2024 |  | $ | 340 |  |  | $ | 70 |  |  | $ | 410 |  |
| 2025 |  | 273 |  |  | 80 |  |  | 353 |  |
| 2026 |  | 324 |  |  | 121 |  |  | 445 |  |
| 2027 |  | 128 |  |  | 102 |  |  | 230 |  |
| 2028 |  | 37 |  |  | 99 |  |  | 136 |  |
| 2029 |  | 1 |  | 15 |  | 16 |  |
| Total guarantee obligations |  | $ | 1,103 |  |  | $ | 487 |  |  | $ | 1,590 |  |

[0000106040-23-000034:notes:92]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-23-000034:notes:93]
Unis Venture

[0000106040-23-000034:notes:94]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 29, 2023 and September 30, 2022, the Company recognized approximately 6% and 3% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 7% and 8% of Accounts receivable, net as of September 29, 2023 and June 30, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-23-000034:notes:95]
[same as prior period, unchanged from 0000106040-23-000017:notes:114]

[0000106040-23-000034:notes:96]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2039. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term.

[0000106040-23-000034:notes:97]
The following table summarizes supplemental balance sheet information related to operating leases as of September 29, 2023:

[0000106040-23-000034:notes:98]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: |  |  |  |  |  |  |  |  |  |
| Remaining nine months of 2024 | $ | 49 |  |  |  |  |  |  |  |  |  |
| 2025 | 63 |  |  |  |  |  |  |  |  |  |
| 2026 | 65 |  |  |  |  |  |  |  |  |  |
| 2027 | 58 |  |  |  |  |  |  |  |  |  |
| 2028 | 51 |  |  |  |  |  |  |  |  |  |
| Thereafter | 329 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 615 |  |  |  |  |  |  |  |  |  |
| Less: Imputed interest | 175 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 440 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 44 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 396 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 419 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 10.5 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 6.0 | % |  |  |  |  |  |  |  |  |

[0000106040-23-000034:notes:99]
[same as prior period, unchanged from 0000106040-23-000017:notes:117]

[0000106040-23-000034:notes:100]
|  | Three Months Ended |
|  | September 29,2023 |  | September 30,2022 |
|  | (in millions) |
| Cost of operating leases | $ | 14 |  |  | $ | 14 |  |
| Cash paid for operating leases | 15 |  |  | 14 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 168 |  |  | 4 |  |

[0000106040-23-000034:notes:101]
Sale-Leaseback

[0000106040-23-000034:notes:102]
In September 2023, the Company completed a sale and leaseback of its facility in Milpitas, California. The Company received net proceeds of $191 million in cash and recorded a gain of $85 million on the sale. In connection with the sale, the Company agreed to lease back the facility at an annual lease rate of $16 million for the first year, increasing by 3% per year thereafter through January 1, 2039. The lease includes three 5-year renewal options and one 4-year renewal option for the ability to extend through December 2057. The supplemental balance sheet information and supplemental disclosures of operating cost and cash flow information related to the lease are included in the tables above.

[0000106040-23-000034:notes:103]
[same as prior period, unchanged from 0000106040-23-000017:notes:119]

[0000106040-23-000034:notes:104]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of September 29, 2023, the Company had the following minimum long-term commitments:

[0000106040-23-000034:notes:105]
|  |  | Long-Term Commitments |
|  |  | (in millions) |
| Year: |  |  |
| Remaining nine months of 2024 |  | $ | 215 |  |
| 2025 |  | 267 |  |
| 2026 |  | 75 |  |
| 2027 |  | 52 |  |
| 2028 |  | 20 |  |
| Thereafter |  | 130 |  |
| Total |  | $ | 759 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-23-000034:notes:106]
[same as prior period, unchanged from 0000106040-23-000017:notes:122]

[0000106040-23-000034:notes:107]
[same as prior period, unchanged from 0000106040-23-000017:notes:123]

[0000106040-23-000034:notes:108]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 65 |  |  | $ | 75 |  |  |  |
| ESPP | 12 |  |  | 11 |  |  |  |
| Total | $ | 77 |  |  | $ | 86 |  |  |  |

[0000106040-23-000034:notes:109]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 14 |  |  |  |
| Research and development | 34 |  |  | 39 |  |  |  |
| Selling, general and administrative | 30 |  |  | 33 |  |  |  |
| Subtotal | 77 |  |  | 86 |  |  |  |
| Tax benefit | (10) |  |  | (13) |  |  |  |
| Total | $ | 67 |  |  | $ | 73 |  |  |  |

[0000106040-23-000034:notes:110]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-23-000034:notes:111]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of September 29, 2023:

[0000106040-23-000034:notes:112]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 588 |  |  | 2.8 |
| ESPP | 55 |  |  | 1.2 |
| Total unamortized compensation cost | $ | 643 |  |  |  |

[0000106040-23-000034:notes:113]
(1)    Weighted average service period assumes the performance conditions are met for the PSUs.

[0000106040-23-000034:notes:114]
[same as prior period, unchanged from 0000106040-23-000017:notes:130]

[0000106040-23-000034:notes:115]
[same as prior period, unchanged from 0000106040-23-000017:notes:131]

[0000106040-23-000034:notes:116]
The following table summarizes stock option activity under the Company’s incentive plans. As of September 29, 2023, there were no remaining outstanding options.

[0000106040-23-000034:notes:117]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  |  |
|  | (in millions) |  |  |  | (in years) |  |  |
| Options outstanding at June 30, 2023 | 0.3 |  |  | $ | 44.95 |  |  | 0.10 |  |  |
| Canceled or expired | (0.3) |  |  | 44.95 |  |  |  |  |  |
| Options outstanding at September 29, 2023 | — |  |  | $ | — |  |  |  |  |  |

[0000106040-23-000034:notes:118]
[same as prior period, unchanged from 0000106040-23-000017:notes:134]

[0000106040-23-000034:notes:119]
[same as prior period, unchanged from 0000106040-23-000017:notes:135]

[0000106040-23-000034:notes:120]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | $ | 46.56 |  |  |  |
| Granted | 5.5 |  |  | 37.87 |  |  |  |
| Vested | (3.3) |  |  | 47.00 |  |  | $ | 147 |  |
| Forfeited | (0.9) |  |  | 46.86 |  |  |  |
| RSUs and PSUs outstanding at September 29, 2023 | 15.1 |  |  | $ | 43.85 |  |  |  |

[0000106040-23-000034:notes:121]
[same as prior period, unchanged from 0000106040-23-000017:notes:137]

[0000106040-23-000034:notes:122]
[same as prior period, unchanged from 0000106040-23-000017:notes:138]

[0000106040-23-000034:notes:123]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million. The Preferred Shares accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of September 29, 2023 and June 30, 2023, unpaid and cumulative dividends payable with respect to the Preferred Shares were $39 million and $24 million, respectively.

[0000106040-23-000034:notes:124]
The Preferred Shares outstanding would have been convertible, if otherwise permitted, into approximately 20 million shares of common stock on September 29, 2023 and June 30, 2023 and as of September 29, 2023 and June 30, 2023, the total aggregate liquidation preference was $939 million and $924 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-23-000034:notes:125]
Income Tax Expense 
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-23-000034:notes:126]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The corporate alternative minimum tax is effective for the Company beginning with fiscal year 2024. The Company is not subject to the CAMT of 15% for fiscal year 2024 as its average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-23-000034:notes:127]
[same as prior period, unchanged from 0000106040-23-000017:notes:155]

[0000106040-23-000034:notes:128]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
|  | ($ in millions) |
| Income (loss) before taxes | $ | (682) |  |  | $ | 84 |  |  |  |  |  |
| Income tax expense | 3 |  |  | 57 |  |  |  |  |  |
| Effective tax rate | — | % |  | 68 | % |  |  |  |  |

[0000106040-23-000034:notes:129]
Beginning in 2023, the 2017 Act requires the Company to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three months ended September 29, 2023, but did not have a material impact on the Company’s effective tax rate.

[0000106040-23-000034:notes:130]
The primary drivers of the difference between the effective tax rate for the three months ended September 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for the three months ended September 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-23-000034:notes:131]
The primary drivers of the difference between the effective tax rate for three months ended September 30, 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-23-000034:notes:132]
[same as prior period, unchanged from 0000106040-23-000017:notes:159]

[0000106040-23-000034:notes:133]
[same as prior period, unchanged from 0000106040-23-000017:notes:160]

[0000106040-23-000034:notes:134]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 29, 2023 (in millions):

[0000106040-23-000034:notes:135]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross increases related to prior year tax positions | 17 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (2) |  |
| Accrual balance at September 29, 2023 | $ | 672 |  |

[0000106040-23-000034:notes:136]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of September 29, 2023 were $157 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of September 29, 2023, approximately $663 million could result in potential cash payments and the Company believes it is reasonably likely that payments of approximately $183 million may be made within the next twelve months and has classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on the Consolidated Balance Sheets as of September 29, 2023. The remaining payables related to unrecognized tax benefits are included in Other liabilities on the Condensed Consolidated Balance Sheets as of September 29, 2023.

[0000106040-23-000034:notes:137]
The Company reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. As of September 29, 2023, the Company has recognized a liability for tax and interest of $183 million related to all years from 2008 through 2015. The change in this liability from the prior quarter liability of $753 million was the result of a payment of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 as well as adjustments to align with IRS calculations. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000034:notes:138]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $168 million. Of this amount, $34 million of the interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-23-000034:notes:139]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of September 29, 2023, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-23-000034:notes:140]
[same as prior period, unchanged from 0000106040-23-000017:notes:166]

[0000106040-23-000034:notes:141]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  |  | September 30,2022 |  |  |  |  |
|  | (in millions, except per share data) |
| Net income (loss) | $ | (685) |  |  |  | $ | 27 |  |  |  |  |  |
| Less: cumulative dividends on Preferred Stock | 15 |  |  |  | — |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | (700) |  |  |  | $ | 27 |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 323 |  |  |  | 316 |  |  |  |  |  |
| Employee stock options, RSUs, PSUs, and ESPP | — |  |  |  | 3 |  |  |  |  |  |
| Diluted | 323 |  |  |  | 319 |  |  |  |  |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Basic | $ | (2.17) |  |  |  | $ | 0.09 |  |  |  |  |  |
| Diluted | $ | (2.17) |  |  |  | $ | 0.08 |  |  |  |  |  |
| Anti-dilutive potential common shares excluded | 15 |  |  |  | 8 |  |  |  |  |  |

[0000106040-23-000034:notes:142]
Basic net income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the 1.50% convertible notes and the Preferred Shares. The treasury stock method is used to determine the dilutive impact of unvested restricted stock.
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the 1.50% convertible notes due 2024, and the Preferred Shares. For the three months ended September 29, 2023, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive. For the three months ended September 30, 2022, the Company excluded common shares subject to certain outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-23-000034:notes:143]
Employee Termination, Asset Impairment, and Other
Business Realignment

[0000106040-23-000034:notes:144]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. In this regard, in the three months ended September 29, 2023, the Company reassessed existing capacity development plans and made a decision to cancel certain projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress and the recognition of a liability for certain contract termination costs. The Company has also taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in September 2023. The Company recorded the following net charges related to these actions for the periods noted below:

[0000106040-23-000034:notes:145]
|  | Three Months Ended |  |  |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 19 |  |  | $ | 24 |  |  |  |  |  |  |  |
| Contract termination and other | 29 |  |  | — |  |  |  |  |  |  |  |
| Asset impairments | 94 |  |  | — |  |  |  |  |  |  |  |
| Gain on sale-leaseback of facility | (85) |  |  | — |  |  |  |  |  |  |  |
| Total employee termination, asset impairment, and other | $ | 57 |  |  | $ | 24 |  |  |  |  |  |  |  |

[0000106040-23-000034:notes:146]
The following table presents an analysis of the components of these activities against the reserve during the three months ended September 29, 2023:

[0000106040-23-000034:notes:147]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Accrual balance at June 30, 2023 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |  |  |  |  |
| Charges | 19 |  |  | 29 |  |  | 48 |  |  |  |  |  |
| Cash payments | (45) |  |  | — |  |  | (45) |  |  |  |  |  |
| Accrual balance at September 29, 2023 | $ | 5 |  |  | $ | 34 |  |  | $ | 39 |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-23-000034:notes:148]
Supplier Finance Program
The Company maintains a voluntary supplier finance program that provides participating suppliers with enhanced receivable options. The program allows participating suppliers of the Company, at their sole discretion and cost, to sell their receivables due from the Company to a third-party financial institution and receive early payment at terms negotiated between the supplier and the third-party financial institution. The Company’s vendor payment terms and amounts are not impacted by a supplier’s decision to participate in this program.

[0000106040-23-000034:notes:149]
The Company’s current payment terms with its suppliers under these programs generally range from 60 to 90 days and payment terms that the Company negotiates with its suppliers are not impacted by whether a supplier participates in the program. The Company does not provide any guarantees to any third parties and no assets are pledged in connection with the arrangements.

[0000106040-23-000034:notes:150]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $39 million and $38 million as of September 29, 2023 and June 30, 2023, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-23-000034:notes:151]
Legal Proceedings
Tax

[0000106040-23-000034:notes:152]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

[0000106040-23-000034:notes:153]
Other Matters

[0000106040-23-000034:notes:154]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:SubsequentEventsTextBlock

[0000106040-23-000034:notes:155]
Subsequent Events
Separation of Business Units

[0000106040-23-000034:notes:156]
On October 30, 2023, the Company announced that its Board of Directors authorized management to pursue a plan to separate its HDD and Flash business units into two independent public companies. The completion of the separation is subject to certain conditions, including final approval by its Board of Directors. The Company is targeting to complete the separation of the business units in the second half of calendar year 2024.

[0000106040-23-000034:notes:157]
Convertible Notes and Related Capped Call Transactions

[0000106040-23-000034:notes:158]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 2026 Notes (currently, Western Digital Technologies, Inc.).

[0000106040-23-000034:notes:159]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-23-000034:notes:160]
In connection with the debt issuance, the Company used approximately $155 million of the net proceeds of the 2028 Convertible Notes offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 per share to hedge the potential dilution impact of the notes’ conversion feature.

[0000106040-23-000034:notes:161]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.
