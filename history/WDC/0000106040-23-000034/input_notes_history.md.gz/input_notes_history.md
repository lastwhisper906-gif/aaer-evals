# WDC note change history — 0000106040-23-000017 → 0000106040-23-000034


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-11-07):
[0000106040-23-000034:note_history:1]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

- removed (2023-11-07):
[0000106040-23-000017:note_history:2]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and further Amendments to Answers filed by the IRS in June 2021 and January 2022, and the status of resolution with respect to certain matters, see Note 13, Income Tax Expense.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:3]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended September 29, 2023 (in millions):
  (was, 2023-05-10, similarity 0.9731):
[0000106040-23-000017:note_history:3]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended March 31, 2023 (in millions):

- changed (2023-11-07):
[0000106040-23-000034:note_history:4]
| Accrual balance at June 30, 2023 | $ | 1,021 |  |
| Gross increases related to current year tax positions | 2 |  |
| Gross increases related to prior year tax positions | 17 |  |
| Gross decreases related to prior year tax positions | (3) |  |
| Settlements | (363) |  |
| Lapse of statute of limitations | (2) |  |
| Accrual balance at September 29, 2023 | $ | 672 |  |
  (was, 2023-05-10, similarity 0.9767):
[0000106040-23-000017:note_history:4]
| Accrual balance at July 1, 2022 | $ | 1,047 |  |
| Gross increases related to current year tax positions | 6 |  |
| Gross increases related to prior year tax positions | 3 |  |
| Gross decreases related to prior year tax positions | (25) |  |
| Settlements | (5) |  |
| Lapse of statute of limitations | (3) |  |
| Accrual balance at March 31, 2023 | $ | 1,023 |  |


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: title_similarity, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:5]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 21 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 48 |  |
| Notes receivable, Flash Forward | 699 |  |  | 709 |  |
| Investment in Flash Partners | 155 |  |  | 160 |  |
| Investment in Flash Alliance | 227 |  |  | 234 |  |
| Investment in Flash Forward | 108 |  |  | 109 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,245 |  |  | $ | 1,297 |  |
  (was, 2023-05-10, similarity 0.979):
[0000106040-23-000017:note_history:5]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 47 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 727 |  |  | 793 |  |
| Investment in Flash Partners | 173 |  |  | 166 |  |
| Investment in Flash Alliance | 253 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,379 |  |  | $ | 1,396 |  |

- changed (2023-11-07):
[0000106040-23-000034:note_history:6]
During the three months ended September 29, 2023 and September 30, 2022, the Company made net payments to Flash Ventures of $0.9 billion and $1.0 billion, respectively, for purchased flash-based memory wafers and net loans.
  (was, 2023-05-10, similarity 0.75):
[0000106040-23-000017:note_history:6]
During the three and nine months ended March 31, 2023 and April 1, 2022, the Company made net payments to Flash Ventures of $1.2 billion and $3.2 billion, and $1.1 billion and $3.4 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2023-11-07):
[0000106040-23-000034:note_history:7]
As of September 29, 2023 and June 30, 2023, the Company had accounts payable balances due to Flash Ventures of $277 million and $292 million, respectively.
  (was, 2023-05-10, similarity 0.9493):
[0000106040-23-000017:note_history:7]
As of March 31, 2023 and July 1, 2022, the Company had accounts payable balances due to Flash Ventures of $265 million and $320 million, respectively.

- added (2023-11-07):
[0000106040-23-000034:note_history:8]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2023-11-07):
[0000106040-23-000034:note_history:9]
|  | September 29,2023 |
|  | (in millions) |
| Notes receivable | $ | 755 |  |
| Equity investments | 490 |  |
| Operating lease guarantees | 1,590 |  |
| Inventory and prepayments | 1,047 |  |
| Maximum estimable loss exposure | $ | 3,882 |  |

- added (2023-11-07):
[0000106040-23-000034:note_history:10]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2023 and the three months ended September 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three months ended September 29, 2023, the Company incurred costs of $141 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 30, 2022.

- added (2023-11-07):
[0000106040-23-000034:note_history:11]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan and a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. As of September 29, 2023, such prepayments aggregated $539 million and will be credited against future wafer charges.

- changed (2023-11-07):
[0000106040-23-000034:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023.
  (was, 2023-05-10, similarity 0.9766):
[0000106040-23-000017:note_history:12]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023.

- changed (2023-11-07):
[0000106040-23-000034:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2023:
  (was, 2023-05-10, similarity 0.9612):
[0000106040-23-000017:note_history:13]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2023:

- changed (2023-11-07):
[0000106040-23-000034:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2024 |  | $ | 340 |  |  | $ | 70 |  |  | $ | 410 |  |
| 2025 |  | 273 |  |  | 80 |  |  | 353 |  |
| 2026 |  | 324 |  |  | 121 |  |  | 445 |  |
| 2027 |  | 128 |  |  | 102 |  |  | 230 |  |
| 2028 |  | 37 |  |  | 99 |  |  | 136 |  |
| 2029 |  | 1 |  | 15 |  | 16 |  |
| Total guarantee obligations |  | $ | 1,103 |  |  | $ | 487 |  |  | $ | 1,590 |  |
  (was, 2023-05-10, similarity 0.9357):
[0000106040-23-000017:note_history:14]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2023 |  | $ | 144 |  |  | $ | 31 |  |  | $ | 175 |  |
| 2024 |  | 480 |  |  | 98 |  |  | 578 |  |
| 2025 |  | 271 |  |  | 90 |  |  | 361 |  |
| 2026 |  | 297 |  |  | 135 |  |  | 432 |  |
| 2027 |  | 104 |  |  | 115 |  |  | 219 |  |
| 2028 and thereafter |  | 24 |  |  | 87 |  |  | 111 |  |
| Total guarantee obligations |  | $ | 1,320 |  |  | $ | 556 |  |  | $ | 1,876 |  |

- changed (2023-11-07):
[0000106040-23-000034:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2023, no amounts had been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2023-05-10, similarity 0.8059):
[0000106040-23-000017:note_history:15]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2023, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2023-11-07):
[0000106040-23-000034:note_history:16]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended September 29, 2023 and September 30, 2022, the Company recognized approximately 6% and 3% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 7% and 8% of Accounts receivable, net as of September 29, 2023 and June 30, 2023, respectively.
  (was, 2023-05-10, similarity 0.7181):
[0000106040-23-000017:note_history:16]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended March 31, 2023, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 1, 2022, the Company recognized approximately 5% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 5% of Accounts receivable, net as of March 31, 2023 and July 1, 2022, respectively.

- removed (2023-11-07):
[0000106040-23-000017:note_history:17]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2023-11-07):
[0000106040-23-000017:note_history:18]
|  | March 31,2023 |
|  | (in millions) |
| Notes receivable | $ | 836 |  |
| Equity investments | 543 |  |
| Operating lease guarantees | 1,876 |  |
| Inventory and prepayments | 1,073 |  |
| Maximum estimable loss exposure | $ | 4,328 |  |

- removed (2023-11-07):
[0000106040-23-000017:note_history:19]
In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility currently under construction in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The Company is committed to pay, among other items, future building depreciation prepayments aggregating approximately $70 million as follows: $47 million for the remaining three months of 2023 and $23 million in 2024, to be credited against future wafer charges.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:20]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both NAND flash and hard disk drive technologies.
  (was, 2023-05-10, similarity 0.6276):
[0000106040-23-000017:note_history:20]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both flash-based products (“Flash”) and hard disk drives (“HDD”) technologies. With dedicated Flash and HDD business units driving advancements in storage technologies, the Company creates and drives innovations needed to help customers capture, preserve, access, and transform an ever-increasing diversity of data.

- added (2023-11-07):
[0000106040-23-000034:note_history:21]
The Company’s broad portfolio of technology and products address the following key end markets: Cloud, Client and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- changed (2023-11-07):
[0000106040-23-000034:note_history:22]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 30, 2023. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2023-05-10, similarity 0.9964):
[0000106040-23-000017:note_history:22]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended July 1, 2022. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2023-11-07):
[0000106040-23-000034:note_history:23]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2023-05-10, similarity 0.9013):
[0000106040-23-000017:note_history:23]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, which ends on June 30, 2023, and 2022, which ended on July 1, 2022, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- changed (2023-11-07):
[0000106040-23-000034:note_history:24]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”).
  (was, 2023-05-10, similarity 0.8987):
[0000106040-23-000017:note_history:24]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: Flash and HDD.

- changed (2023-11-07):
[0000106040-23-000034:note_history:25]
The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), evaluates the performance of the Company and makes decisions regarding the allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are either not available or not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.
  (was, 2023-05-10, similarity 0.8931):
[0000106040-23-000017:note_history:25]
The Company’s Chief Operating Decision Maker (“CODM”) evaluates performance of the Company and makes decisions regarding allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are not available or reviewed by the CODM to evaluate the performance of or to allocate resources to the segments.

- removed (2023-11-07):
[0000106040-23-000017:note_history:26]
Income (Loss) per Common Share
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:27]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,700 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (28) |  |  | (30) |  |
| Subtotal | 7,672 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,850) |  |  | (1,213) |  |
| Long-term debt | $ | 5,822 |  |  | $ | 5,857 |  |
  (was, 2023-05-10, similarity 0.783):
[0000106040-23-000017:note_history:27]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (27) |  |  | (78) |  |
| Subtotal | 7,073 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,175) |  |  | — |  |
| Long-term debt | $ | 5,898 |  |  | $ | 7,022 |  |

- added (2023-11-07):
[0000106040-23-000034:note_history:28]
During the three months ended September 29, 2023, the Company drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $600 million through August 14, 2023. The Delayed Draw Term Loan will mature on June 28, 2024.

- changed (2023-11-07):
[0000106040-23-000034:note_history:29]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch Ratings, Inc. (the “Credit Rating Agencies”). The all-in interest rate for the Delayed Draw Term Loan as of September 29, 2023 was 7.416%.
  (was, 2023-05-10, similarity 0.7145):
[0000106040-23-000017:note_history:29]
The Delayed Draw Term Loan will bear interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies. The Company will also pay an unused commitment fee on the Delayed Draw Term Loan Agreement of 0.200%.

- added (2023-11-07):
[0000106040-23-000034:note_history:30]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.375%. The all-in interest rate for Term Loan A-2 as of September 29, 2023 was 6.807%.

- added (2023-11-07):
[0000106040-23-000034:note_history:31]
The loan agreements governing the Company’s revolving credit facility, Term Loan A-2 due 2027, and the Delayed Draw Term Loan require the Company to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of September 29, 2023, the Company was in compliance with these financial covenants.

- removed (2023-11-07):
[0000106040-23-000017:note_history:32]
During the nine months ended March 31, 2023, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”).

- removed (2023-11-07):
[0000106040-23-000017:note_history:33]
In December 2022, the Company amended the credit agreement governing the 2027 Revolving Credit Facility and Term Loan A-2 for the purposes of providing flexibility by adjusting the leverage ratio requirements of the financial covenant thereunder through the Company’s quarter ending September 27, 2024 (such period, the “Covenant Relief Period”). As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

- removed (2023-11-07):
[0000106040-23-000017:note_history:34]
| Quarter ending: | Leverage ratio |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |

- removed (2023-11-07):
[0000106040-23-000017:note_history:35]
As of March 31, 2023, the Company was in compliance with this financial covenant. The amendment also provides that the due date for amounts outstanding under the Credit Agreement will be accelerated from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have cash and cash equivalents plus available unused capacity under its credit facilities that exceed by $1 billion the sum of the outstanding balance of the 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within 12 months. In addition, during the Covenant Relief Period, the amendment requires certain subsidiaries of the Company to provide guarantees if the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services, Moody’s Investors Service, Inc. and Fitch, Inc. (the “Credit Rating Agencies”) drops below investment grade and includes limits on secured indebtedness and certain types of unsecured subsidiary indebtedness.

- removed (2023-11-07):
[0000106040-23-000017:note_history:36]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allows the Company to draw a single unsecured loan of up to $875 million (the “Delayed Draw Term Loan”) through June 30, 2023. The Delayed Draw Term Loan Agreement may be terminated, at the election of the Company, at any time without premium or penalty, subject to certain conditions. As of March 31, 2023, the Company had not drawn on the Delayed Draw Term Loan.

- removed (2023-11-07):
[0000106040-23-000017:note_history:37]
Any amount drawn under the Delayed Draw Term Loan Agreement will mature 364 days following the date of the initial draw. However, the due date will be accelerated to November 2, 2023 if conditions for acceleration of amounts due under the Credit Agreement have been triggered as described above.

- removed (2023-11-07):
[0000106040-23-000017:note_history:38]
The key covenants, limitations and requirements provided under the Credit Agreement amendment noted above also apply to the Delayed Draw Term Loan Agreement.

- removed (2023-11-07):
[0000106040-23-000017:note_history:39]
As described in Note 2, Recent Accounting Pronouncements, the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on its 1.50% convertible notes due 2024.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:40]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| Variable interest rate Delayed Draw Term Loan due 2024 | 600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,700 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (28) |  |  | (30) |  |
| Subtotal | 7,672 |  |  | 7,070 |  |
| Less current portion of long-term debt | (1,850) |  |  | (1,213) |  |
| Long-term debt | $ | 5,822 |  |  | $ | 5,857 |  |
  (was, 2023-05-10, similarity 0.783):
[0000106040-23-000017:note_history:40]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (27) |  |  | (78) |  |
| Subtotal | 7,073 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,175) |  |  | — |  |
| Long-term debt | $ | 5,898 |  |  | $ | 7,022 |  |


## wdc:DebtInstrumentScheduleOfLeverageRatioTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-11-07):
[0000106040-23-000017:note_history:41]
As amended, the Company is required to maintain a maximum ratio (“Leverage Ratio”) of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

- removed (2023-11-07):
[0000106040-23-000017:note_history:42]
| Quarter ending: | Leverage ratio |
| March 31, 2023 | 3.75 to 1.00 |
| June 30, 2023 | 4.75 to 1.00 |
| September 29, 2023 | 5.00 to 1.00 |
| December 29, 2023 | 4.75 to 1.00 |
| March 29, 2024 | 4.50 to 1.00 |
| June 28, 2024 | 4.25 to 1.00 |
| September 27, 2024 | 3.75 to 1.00 |
| December 27, 2024 and thereafter | 3.25 to 1.00 |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:43]
|  | September 29,2023 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 21 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 48 |  |
| Notes receivable, Flash Forward | 699 |  |  | 709 |  |
| Investment in Flash Partners | 155 |  |  | 160 |  |
| Investment in Flash Alliance | 227 |  |  | 234 |  |
| Investment in Flash Forward | 108 |  |  | 109 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,245 |  |  | $ | 1,297 |  |
  (was, 2023-05-10, similarity 0.979):
[0000106040-23-000017:note_history:43]
|  | March 31,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 47 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 62 |  |  | 55 |  |
| Notes receivable, Flash Forward | 727 |  |  | 793 |  |
| Investment in Flash Partners | 173 |  |  | 166 |  |
| Investment in Flash Alliance | 253 |  |  | 243 |  |
| Investment in Flash Forward | 117 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,379 |  |  | $ | 1,396 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0000106040-23-000034:note_history:44]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29,2023 |  | September 30,2022 |
|  |  |  |  |  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 872 |  |  | $ | 1,829 |  |
| Client |  |  |  |  | 1,147 |  |  | 1,229 |  |
| Consumer |  |  |  |  | 731 |  |  | 678 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 1,551 |  |  | $ | 1,686 |  |
| Americas |  |  |  |  | 662 |  |  | 1,423 |  |
| Europe, Middle East and Africa |  |  |  |  | 537 |  |  | 627 |  |
| Total Revenue |  |  |  |  | $ | 2,750 |  |  | $ | 3,736 |  |
  (was, 2023-05-10, similarity 0.7557):
[0000106040-23-000017:note_history:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 1,205 |  |  | $ | 1,774 |  |  | $ | 4,258 |  |  | $ | 5,919 |  |
| Client | 975 |  |  | 1,732 |  |  | 3,293 |  |  | 5,439 |  |
| Consumer | 623 |  |  | 875 |  |  | 2,095 |  |  | 2,907 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,353 |  |  | $ | 2,400 |  |  | $ | 4,533 |  |  | $ | 7,685 |  |
| Americas | 935 |  |  | 1,377 |  |  | 3,448 |  |  | 4,398 |  |
| Europe, Middle East and Africa | 515 |  |  | 604 |  |  | 1,665 |  |  | 2,182 |  |
| Total Revenue | $ | 2,803 |  |  | $ | 4,381 |  |  | $ | 9,646 |  |  | $ | 14,265 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2023-11-07):
[0000106040-23-000017:note_history:45]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either March 31, 2023 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of March 31, 2023 and July 1, 2022 and changes in contract liabilities for the nine months ended March 31, 2023 and April 1, 2022 were not material.

- removed (2023-11-07):
[0000106040-23-000017:note_history:46]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

- removed (2023-11-07):
[0000106040-23-000017:note_history:47]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of March 31, 2023 was not material.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-11-07):
[0000106040-23-000034:note_history:48]
Subsequent Events
Separation of Business Units

- added (2023-11-07):
[0000106040-23-000034:note_history:49]
On October 30, 2023, the Company announced that its Board of Directors authorized management to pursue a plan to separate its HDD and Flash business units into two independent public companies. The completion of the separation is subject to certain conditions, including final approval by its Board of Directors. The Company is targeting to complete the separation of the business units in the second half of calendar year 2024.

- added (2023-11-07):
[0000106040-23-000034:note_history:50]
Convertible Notes and Related Capped Call Transactions

- added (2023-11-07):
[0000106040-23-000034:note_history:51]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 2026 Notes (currently, Western Digital Technologies, Inc.).

- added (2023-11-07):
[0000106040-23-000034:note_history:52]
The 2028 Convertible Notes are convertible at an initial conversion price of approximately $52.20 per share of common stock. Prior to August 15, 2028, the 2028 Convertible Notes are convertible only upon the occurrence of certain events and during certain periods. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash up to the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- added (2023-11-07):
[0000106040-23-000034:note_history:53]
In connection with the debt issuance, the Company used approximately $155 million of the net proceeds of the 2028 Convertible Notes offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 per share to hedge the potential dilution impact of the notes’ conversion feature.

- added (2023-11-07):
[0000106040-23-000034:note_history:54]
Contemporaneously with the issuance of the 2028 Convertible Notes, the Company entered into individually negotiated transactions with certain holders of the Company’s existing 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount.
