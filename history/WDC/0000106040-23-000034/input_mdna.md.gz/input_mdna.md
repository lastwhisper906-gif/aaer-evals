# WDC MD&A — 0000106040-23-000034


## mdna

[0000106040-23-000034:mdna:1]
[same as prior period, unchanged from 0000106040-23-000017:mdna:1]

[0000106040-23-000034:mdna:2]
[same as prior period, unchanged from 0000106040-23-000017:mdna:2]

[0000106040-23-000034:mdna:3]
[same as prior period, unchanged from 0000106040-23-000017:mdna:3]

[0000106040-23-000034:mdna:4]
We are on a mission to unlock the potential of data by harnessing the possibility to use it. We are a leading developer, manufacturer, and provider of data storage devices based on both NAND flash and hard disk drive technologies. With dedicated flash-based products (“Flash”) and hard disk drives (“HDD”) business units driving advancements in storage technologies, our broad and ever-expanding portfolio delivers powerful Flash and HDD storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-23-000034:mdna:5]
Our broad portfolio of technology and products address our multiple end markets: “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers, which we believe we are uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-23-000034:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2024, which will end on June 28, 2024, and fiscal year 2023, which ended June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-23-000034:mdna:7]
[same as prior period, unchanged from 0000106040-23-000017:mdna:6]

[0000106040-23-000034:mdna:8]
Separation of Business Units

[0000106040-23-000034:mdna:9]
On October 30, 2023, we announced that our Board of Directors had completed its strategic review of our business and, after evaluating a comprehensive range of alternatives, authorized us to pursue a plan to separate our HDD and Flash business units to create two independent, public companies. We believe the separation will better position each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, and operate more efficiently with distinct capital structures. The completion of the planned separation is subject to certain conditions, including final approval by our Board of Directors. We are targeting to complete the separation of the businesses in the second half of calendar year 2024.

[0000106040-23-000034:mdna:10]
[same as prior period, unchanged from 0000106040-23-000017:mdna:18]

[0000106040-23-000034:mdna:11]
In August 2023, we drew $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement we entered into in January 2023 and amended in June 2023 (the “Delayed Draw Term Loan Agreement”), which allowed us to draw a single loan of up to $600 million through August 14, 2023. Proceeds from this loan were primarily used for payments on tax liability to the IRS for the years 2008 through 2012. Borrowings on this loan will mature on June 28, 2024.

[0000106040-23-000034:mdna:12]
On November 3, 2023, we issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). We received net proceeds of approximately $1.56 billion after issuance costs. Contemporaneously with the issuance of the 2028 Convertible Notes, we entered into individually negotiated transactions with certain holders of our existing 1.50% convertible senior notes due 2024 (the “2024 Convertible Notes”), which mature on February 1, 2024, to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount using net proceeds from the offering of the 2028 Convertible Notes. In connection with the issuance of the 2028 Convertible Notes, we also used approximately $155 million of the net proceeds from the offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 to hedge the potential dilution impact of the conversion feature. The remaining net proceeds from the offering of the 2028 Convertible Notes will be used primarily to settle the remaining 2024 Convertible Notes.

[0000106040-23-000034:mdna:13]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, and additional information on the terms of our convertible preferred shares and the 2028 Convertible Notes is included in Part II, Item 8, Note 8, Debt, and Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023 and Note 17, Subsequent Events, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-23-000034:mdna:14]
Sale-Leaseback

[0000106040-23-000034:mdna:15]
In September 2023, we completed a sale and leaseback of our facility in Milpitas, California. We received net proceeds of $191 million in cash and recorded a gain of $85 million on the sale. We are leasing back the facility at an annual lease rate of $16 million for the first year, increasing by 3% per year thereafter through January 1, 2039. The lease includes three 5-year renewal options and one 4-year renewal option for the ability to extend through December 2057.

[0000106040-23-000034:mdna:16]
Asset Impairment and Contract Termination Costs

[0000106040-23-000034:mdna:17]
During the three months ended September 29, 2023, we reassessed our existing capacity development plans and made a decision to cancel certain projects to expand capacity in our Penang, Malaysia facility, resulting in a $94 million impairment of existing construction in progress and recognition of a $29 million liability for certain contract termination costs.

[0000106040-23-000034:mdna:18]
[same as prior period, unchanged from 0000106040-23-000017:mdna:24]

[0000106040-23-000034:mdna:19]
As previously disclosed, we reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 29, 2023, we made payments aggregating $523 million for tax and interest with respect to years 2008 through 2012 and have a remaining liability of $183 million as of September 29, 2023 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months. Additional information regarding these settlements and our assessment of the potential tax and interest payments we expect to pay in connection with the settlements is provided in our discussion of Income tax expense in our results of operations below, as well as in Part I, Item 1, Note 12, Income Tax Expense, of the Notes to the Condensed Consolidated Financial Statements, and in the “Short- and Long-term Liquidity - Unrecognized Tax Benefits” section below.

[0000106040-23-000034:mdna:20]
[same as prior period, unchanged from 0000106040-23-000017:mdna:14]

[0000106040-23-000034:mdna:21]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry have been experiencing a supply-demand imbalance, which has resulted in reduced shipments and negatively impacted pricing, particularly in Flash. While the supply-demand imbalance has recently started to show signs of stabilization, particularly in Client and Consumer, we continue to face a dynamic market environment. To adapt to these conditions, we have scaled back on capital expenditures, consolidated production lines and reduced production bit growth since the beginning of 2023 in order to better align with market demand and have also implemented measures to reduce operating expenses. These actions have resulted in incremental charges for employee termination, asset impairment and other, and manufacturing underutilization charges in Flash and HDD, and are expected to continue to negatively impact near-term results. Notwithstanding the current supply-demand imbalance, we believe digital transformation will continue to drive long-term growth for data storage in both Flash and HDD and believe that the actions we are taking will position us to capitalize on market conditions when they improve to address long-term growth opportunities in data storage across all our end markets.

[0000106040-23-000034:mdna:22]
We will continue to actively monitor developments impacting our business and may take additional responsive actions that we determine to be in the best interest of our business and stakeholders.

[0000106040-23-000034:mdna:23]
See Part I, Item 1A, Risk Factors, of our Annual Report on Form 10-K for the year ended June 30, 2023 for more information regarding the risks we face as a result of macroeconomic conditions and supply chain disruptions.

[0000106040-23-000034:mdna:24]
[same as prior period, unchanged from 0000106040-23-000017:mdna:23]

[0000106040-23-000034:mdna:25]
[same as prior period, unchanged from 0000106040-23-000017:mdna:28]

[0000106040-23-000034:mdna:26]
First Quarter Overview

[0000106040-23-000034:mdna:27]
[same as prior period, unchanged from 0000106040-23-000017:mdna:30]

[0000106040-23-000034:mdna:28]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 2,750 |  |  | 100.0 | % |  | $ | 3,736 |  |  | 100.0 | % |  | $ | (986) |  |  | (26) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 2,651 |  |  | 96.4 |  |  | 2,755 |  |  | 73.7 |  |  | (104) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 99 |  |  | 3.6 |  |  | 981 |  |  | 26.3 |  |  | (882) |  |  | (90) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 431 |  |  | 15.7 |  |  | 552 |  |  | 14.8 |  |  | (121) |  |  | (22) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 207 |  |  | 7.5 |  |  | 247 |  |  | 6.6 |  |  | (40) |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other | 57 |  |  | 2.1 |  |  | 24 |  |  | 0.6 |  |  | 33 |  |  | 138 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 695 |  |  | 25.3 |  |  | 823 |  |  | 22.0 |  |  | (128) |  |  | (16) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) | (596) |  |  | (21.7) |  |  | 158 |  |  | 4.2 |  |  | (754) |  |  | (477) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 8 |  |  | 0.3 |  |  | 2 |  |  | 0.1 |  |  | 6 |  |  | 300 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (98) |  |  | (3.6) |  |  | (70) |  |  | (1.9) |  |  | (28) |  |  | 40 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 4 |  |  | 0.1 |  |  | (6) |  |  | (0.2) |  |  | 10 |  |  | (167) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (86) |  |  | (3.1) |  |  | (74) |  |  | (2.0) |  |  | (12) |  |  | 16 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | (682) |  |  | (24.8) |  |  | 84 |  |  | 2.2 |  |  | (766) |  |  | (912) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 3 |  |  | 0.1 |  |  | 57 |  |  | 1.5 |  |  | (54) |  |  | (95) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | (685) |  |  | (24.9) |  |  | 27 |  |  | 0.7 |  |  | (712) |  |  | (26) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 15 |  |  | 0.5 |  |  | — |  |  | — |  |  | 15 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common shareholders | $ | (700) |  |  | (25.5) | % |  | $ | 27 |  |  | 0.7 | % |  | $ | (727) |  |  | (2,693) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-23-000034:mdna:29]
[same as prior period, unchanged from 0000106040-23-000017:mdna:32]

[0000106040-23-000034:mdna:30]
[same as prior period, unchanged from 0000106040-23-000017:mdna:36]

[0000106040-23-000034:mdna:31]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
|  | $ in millions |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,556 |  |  | $ | 1,722 |  |  |  |  |  |
| HDD | 1,194 |  |  | 2,014 |  |  |  |  |  |
| Total net revenue | $ | 2,750 |  |  | $ | 3,736 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | (161) |  |  | $ | 422 |  |  |  |  |  |
| HDD | 273 |  |  | 574 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (13) |  |  | (14) |  |  |  |  |  |
| Amortization of acquired intangible assets | — |  |  | (1) |  |  |  |  |  |
| Total unallocated corporate items | (13) |  |  | (15) |  |  |  |  |  |
| Consolidated gross profit | $ | 99 |  |  | $ | 981 |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | (10.3) | % |  | 24.5 | % |  |  |  |  |
| HDD | 22.9 | % |  | 28.5 | % |  |  |  |  |
| Consolidated gross margin | 3.6 | % |  | 26.3 | % |  |  |  |  |

[0000106040-23-000034:mdna:32]
[same as prior period, unchanged from 0000106040-23-000017:mdna:39]

[0000106040-23-000034:mdna:33]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |
| Cloud | $ | 872 |  |  | $ | 1,829 |  |  |  |  |  |
| Client | 1,147 |  |  | 1,229 |  |  |  |  |  |
| Consumer | 731 |  |  | 678 |  |  |  |  |  |
| Total Revenue | $ | 2,750 |  |  | $ | 3,736 |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |
| Asia | $ | 1,551 |  |  | $ | 1,686 |  |  |  |  |  |
| Americas | 662 |  |  | 1,423 |  |  |  |  |  |
| Europe, Middle East and Africa | 537 |  |  | 627 |  |  |  |  |  |
| Total Revenue | $ | 2,750 |  |  | $ | 3,736 |  |  |  |  |  |

[0000106040-23-000034:mdna:34]
[same as prior period, unchanged from 0000106040-23-000017:mdna:42]

[0000106040-23-000034:mdna:35]
Comparison of Three Months Ended September 29, 2023 to Three Months Ended September 30, 2022

[0000106040-23-000034:mdna:36]
The decrease in consolidated net revenue for the three months ended September 29, 2023 from the comparable period in the prior year reflected the current supply-demand imbalance and macroeconomic pressures described in “Operational Update” above.

[0000106040-23-000034:mdna:37]
Flash revenue decreased 10% for the three months ended September 29, 2023 from the comparable period in the prior year primarily as a result of a 39% decline in average selling prices per gigabyte caused by the macroeconomic pressures noted previously, partially offset by an increase in exabytes shipped.

[0000106040-23-000034:mdna:38]
HDD revenue decreased 41% for the three months ended September 29, 2023, from the comparable period in the prior year primarily as a result of a 42% decline in exabytes shipped, which was substantially all driven by lower shipments to customers in our Cloud end market.

[0000106040-23-000034:mdna:39]
The 52% decrease in Cloud revenue for the three months ended September 29, 2023 from the comparable period in the prior year was substantially all driven by lower volume in HDD and Flash. In Client, the 7% decrease in revenue for the three months ended September 29, 2023 from the comparable period in the prior year primarily reflected approximately 57 percentage points of decline from lower pricing, driven by Flash, which was largely offset by an increase in volume, also in Flash. In Consumer, the 8% increase in revenue for the three months ended September 29, 2023 from the comparable period in the prior year primarily reflected approximately 44 percentage points of increase from higher volume, driven by Flash,which was largely offset by a decline in pricing, also in Flash.

[0000106040-23-000034:mdna:40]
The changes in net revenue by geography for the three months ended September 29, 2023 from the comparable period in the prior year reflected a larger decline in Americas from lower Cloud revenue in this region as our Cloud customers reduced purchases to align with current market demand, as well as routine variations in the mix of business.

[0000106040-23-000034:mdna:41]
Our top 10 customers accounted for 44% of our net revenue for the three months ended September 29, 2023, compared to 52% of our net revenue for the three months ended September 30, 2022. For each of the three months ended September 29, 2023 and September 30, 2022, no single customer accounted for 10% or more of our net revenue.

[0000106040-23-000034:mdna:42]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 20% of gross revenue for the three months ended September 29, 2023, and 19% of gross revenue for the three months ended September 30, 2022. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-23-000034:mdna:43]
[same as prior period, unchanged from 0000106040-23-000017:mdna:52]

[0000106040-23-000034:mdna:44]
Consolidated gross profit decreased by $882 million for the three months ended September 29, 2023 from the comparable period in the prior year, which primarily reflected the decrease in revenue described above as well as charges of approximately $225 million for manufacturing underutilization and related charges ($142 million in Flash and $83 million in HDD) and a write down of certain Flash inventory to the lower of cost or market value during the three months ended September 29, 2023. Consolidated gross margin decreased 23 percentage points for the three months ended September 29, 2023 from the comparable period in the prior year, with approximately 8 percentage points of the decline due to the net charges noted above and the remainder primarily driven by the lower average selling prices per gigabyte in Flash. Flash gross margin decreased by approximately 35 percentage points year over year, with approximately 9 percentage points of the decline due to the net charges noted above and the remainder driven by the lower average selling prices per gigabyte. HDD gross margin decreased by 6 percentage points year over year, with approximately 6 percentage points of the decline due to the net charges noted above.

[0000106040-23-000034:mdna:45]
[same as prior period, unchanged from 0000106040-23-000017:mdna:55]

[0000106040-23-000034:mdna:46]
Research and development (“R&D”) expense decreased $121 million for the three months ended September 29, 2023 from the comparable period in the prior year. The decline was primarily driven by reductions in variable compensation expenses, headcount, and material use as we took actions to reduce expenses in the current environment.

[0000106040-23-000034:mdna:47]
Selling, general and administrative (“SG&A”) expense decreased $40 million for the three months ended September 29, 2023 from the comparable period in the prior year. The decline was primarily driven by reductions in headcount, variable compensation expenses, and a decrease in intangible amortization expense.

[0000106040-23-000034:mdna:48]
Employee termination, asset impairment and other increased $33 million for the three months ended September 29, 2023 from the comparable period in the prior year. The increase was primarily driven by asset impairments caused by project cancellations, partially offset by a gain on the sale-leaseback of our Milpitas, California facility. For information regarding Employee termination, asset impairment and other, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment, and Other of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000034:mdna:49]
[same as prior period, unchanged from 0000106040-23-000017:mdna:59]

[0000106040-23-000034:mdna:50]
Total interest and other expense, net increased $12 million for the three months ended September 29, 2023 from the comparable period in the prior year, reflecting higher interest expenses resulting from increases in interest rates and the drawdown of our Delayed Draw Term Loan discussed in “Key Developments-Financing Activities” above.

[0000106040-23-000034:mdna:51]
[same as prior period, unchanged from 0000106040-23-000017:mdna:61]

[0000106040-23-000034:mdna:52]
[same as prior period, unchanged from 0000106040-23-000017:mdna:62]

[0000106040-23-000034:mdna:53]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant legal changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The CAMT is effective for us beginning with fiscal year 2024. We are not subject to the CAMT of 15% for fiscal year 2024 as our annual average AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-23-000034:mdna:54]
The following table sets forth Income tax information from our Condensed Consolidated Statements of Operations by dollar and effective tax rate:

[0000106040-23-000034:mdna:55]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
|  | $ in millions |
| Income (loss) before taxes | $ | (682) |  |  | $ | 84 |  |  |  |  |  |
| Income tax expense | 3 |  |  | 57 |  |  |  |  |  |
| Effective tax rate | — | % |  | 68 | % |  |  |  |  |

[0000106040-23-000034:mdna:56]
Since the beginning of fiscal year 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three months ended September 29, 2023, but did not have a material impact on our effective tax rate. The primary drivers of the difference between the effective tax rate for the three months ended September 29, 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three months ended September 29, 2023 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0000106040-23-000034:mdna:57]
The primary drivers of the difference between the effective tax rate for the three months ended September 30, 2022 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-23-000034:mdna:58]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for the three months ended September 29, 2023, but did not have a material impact on the effective tax rate in those periods due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-23-000034:mdna:59]
For additional information regarding Income tax expense, see Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000034:mdna:60]
[same as prior period, unchanged from 0000106040-23-000017:mdna:70]

[0000106040-23-000034:mdna:61]
[same as prior period, unchanged from 0000106040-23-000017:mdna:71]

[0000106040-23-000034:mdna:62]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (626) |  |  | $ | 6 |  |  |  |
| Investing activities | 84 |  |  | (224) |  |  |  |
| Financing activities | 554 |  |  | (50) |  |  |  |
| Effect of exchange rate changes on cash | (3) |  |  | (10) |  |  |  |
| Net increase (decrease) in cash and cash equivalents | $ | 9 |  |  | $ | (278) |  |  |  |

[0000106040-23-000034:mdna:63]
We reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 29, 2023, the Company made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in remaining liability of $183 million as of September 29, 2023, related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000034:mdna:64]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $168 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules. See Part I, Item 1, Note 12, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for further details.

[0000106040-23-000034:mdna:65]
[same as prior period, unchanged from 0000106040-23-000017:mdna:74]

[0000106040-23-000034:mdna:66]
As noted previously, we have been scaling back on capital expenditures, consolidating production lines and reducing bit growth to align with market demand. We reduced our expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to approximately $1.4 billion in 2023 from approximately $1.5 billion in 2022. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we reduced our net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to $793 million in 2023 from $1.2 billion in 2022. We currently expect the capital expenditures for 2024 to be less than 2023.

[0000106040-23-000034:mdna:67]
We believe our Cash and cash equivalents, including the proceeds from the drawdown of the Delayed Draw Term Loan, the net proceeds we received from the sale and leaseback of our Milpitas facility, and the proceeds from the issuance of the 2028 Convertible Notes, each as discussed in “Key Developments” above, and our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter, as we navigate the current market downturn before returning to profitable operations and positive cash flows when the market normalizes. We believe we can also access the various debt capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our Annual Report on Form 10-K for the year ended June 30, 2023.

[0000106040-23-000034:mdna:68]
A total of $1.43 billion and $1.28 billion of our Cash and cash equivalents was held by our foreign subsidiaries as of September 29, 2023 and June 30, 2023, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-23-000034:mdna:69]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-23-000034:mdna:70]
[same as prior period, unchanged from 0000106040-23-000017:mdna:79]

[0000106040-23-000034:mdna:71]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $132 million for the three months ended September 29, 2023, as compared to $329 million for the three months ended September 30, 2022, which largely reflects the reduction in operating assets resulting from the reduction in volume of our business, partially offset by payments made on the IRS matter, as discussed above. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-23-000034:mdna:72]
|  | Three Months Ended |  |  |
|  | September 29,2023 |  | September 30,2022 |  |  |  |  |
| Days sales outstanding | 48 |  |  | 59 |  |  |  |  |  |
| Days in inventory | 120 |  |  | 128 |  |  |  |  |  |
| Days payable outstanding | (54) |  |  | (65) |  |  |  |  |  |
| Cash conversion cycle | 114 |  |  | 122 |  |  |  |  |  |

[0000106040-23-000034:mdna:73]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds, including staging of inventory to meet expected future demand. Changes in days payable outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-23-000034:mdna:74]
For the three months ended September 29, 2023, DSO decreased by 11 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. DIO decreased by 8 days from the comparable period in the prior year, primarily reflecting lower production volumes in the current year and an increase in products shipped. DPO decreased by 11 days from the comparable period in the prior year primarily due to reductions in production volume and capital expenditures as well as routine variations in the timing of purchases and payments during the period.

[0000106040-23-000034:mdna:75]
[same as prior period, unchanged from 0000106040-23-000017:mdna:84]

[0000106040-23-000034:mdna:76]
Net cash provided by investing activities for the three months ended September 29, 2023 primarily consisted of $69 million in proceeds from disposals of assets, which includes the proceeds from our sale-leaseback of our Milpitas, California facility, net of capital expenditures, and $13 million in proceeds from net activity related to Flash Ventures. Net cash used in investing activities for the three months ended September 30, 2022 primarily consisted of $320 million in capital expenditures, net of disposals, partially offset by $99 million in proceeds from activity related to Flash Ventures.

[0000106040-23-000034:mdna:77]
[same as prior period, unchanged from 0000106040-23-000017:mdna:86]

[0000106040-23-000034:mdna:78]
During the three months ended September 29, 2023, net cash provided by financing activities primarily consisted of $600 million in proceeds from the drawdown of the Delayed Draw Term Loan, partially offset by $43 million used for taxes paid on vested stock awards under employee stock plans. During the three months ended September 30, 2022 cash flows from financing activities primarily consisted of $50 million used for taxes paid on vested stock awards under employee stock plans, while we drew and repaid $300 million under our revolving credit facility within the period.

[0000106040-23-000034:mdna:79]
[same as prior period, unchanged from 0000106040-23-000017:mdna:88]

[0000106040-23-000034:mdna:80]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-23-000034:mdna:81]
47

[0000106040-23-000034:mdna:82]
[same as prior period, unchanged from 0000106040-23-000017:mdna:91]

[0000106040-23-000034:mdna:83]
[same as prior period, unchanged from 0000106040-23-000017:mdna:92]

[0000106040-23-000034:mdna:84]
In addition to cash requirements for unrecognized tax benefits and dividend rights with respect to the Series A Preferred Stock discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of September 29, 2023:

[0000106040-23-000034:mdna:85]
|  | Total |  | 1 Year (Remaining Nine Months of 2024) |  | 2-3 Years (2025-2026) |  | 4-5 Years (2027-2028) |  | More than 5 Years (Beyond 2028) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,700 |  |  | $ | 1,813 |  |  | $ | 2,600 |  |  | $ | 2,287 |  |  | $ | 1,000 |  |
| Interest on debt | 1,098 |  |  | 253 |  |  | 629 |  |  | 140 |  |  | 76 |  |
| Flash Ventures related commitments(2) | 3,857 |  |  | 1,301 |  |  | 1,893 |  |  | 642 |  |  | 21 |  |
| Operating leases | 615 |  |  | 49 |  |  | 128 |  |  | 109 |  |  | 329 |  |
| Purchase obligations and other commitments | 759 |  |  | 215 |  |  | 342 |  |  | 72 |  |  | 130 |  |
| Mandatory deemed repatriation tax | 663 |  |  | 199 |  |  | 464 |  |  | — |  |  | — |  |
| Total | $ | 14,692 |  |  | $ | 3,830 |  |  | $ | 6,056 |  |  | $ | 3,250 |  |  | $ | 1,556 |  |

[0000106040-23-000034:mdna:86]
[same as prior period, unchanged from 0000106040-23-000017:mdna:95]

[0000106040-23-000034:mdna:87]
[same as prior period, unchanged from 0000106040-23-000017:mdna:96]

[0000106040-23-000034:mdna:88]
[same as prior period, unchanged from 0000106040-23-000017:mdna:97]

[0000106040-23-000034:mdna:89]
On January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. These shares are entitled to cumulative preferred dividends. See Part I, Item 1, Note 11, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0000106040-23-000034:mdna:90]
[same as prior period, unchanged from 0000106040-23-000017:mdna:99]

[0000106040-23-000034:mdna:91]
In addition to our existing debt, as of September 29, 2023, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Furthermore, we issued 2028 Convertible Notes as noted in “Key Developments-Financing Activities” above. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 30, 2023 and Note 17, Subsequent Events, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0000106040-23-000034:mdna:92]
The loan agreements governing our revolving credit facility, our Term Loan A-2 due 2027, and our Delayed Draw Term Loan require us to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirement. As of September 29, 2023, we were in compliance with these financial covenants.

[0000106040-23-000034:mdna:93]
[same as prior period, unchanged from 0000106040-23-000017:mdna:101]

[0000106040-23-000034:mdna:94]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of September 29, 2023, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-23-000034:mdna:95]
48

[0000106040-23-000034:mdna:96]
[same as prior period, unchanged from 0000106040-23-000017:mdna:103]

[0000106040-23-000034:mdna:97]
[same as prior period, unchanged from 0000106040-23-000017:mdna:104]

[0000106040-23-000034:mdna:98]
[same as prior period, unchanged from 0000106040-23-000017:mdna:105]

[0000106040-23-000034:mdna:99]
[same as prior period, unchanged from 0000106040-23-000017:mdna:106]

[0000106040-23-000034:mdna:100]
|  |  | September 29,2023 |
|  |  | (in millions) |
| Remainder of fiscal 2024 |  | $ | 199 |  |
| 2025 |  | 265 |  |
| 2026 |  | 199 |  |
| Total |  | $ | 663 |  |

[0000106040-23-000034:mdna:101]
[same as prior period, unchanged from 0000106040-23-000017:mdna:109]

[0000106040-23-000034:mdna:102]
As of September 29, 2023, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $672 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of September 29, 2023 was $157 million. Of these amounts, approximately $663 million could result in potential cash payments.

[0000106040-23-000034:mdna:103]
As noted above, we reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the three months ended September 29, 2023, we made payments of $363 million for tax and $160 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in remaining liability of $183 million as of September 29, 2023 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000034:mdna:104]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $168 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-23-000034:mdna:105]
[same as prior period, unchanged from 0000106040-23-000017:mdna:112]

[0000106040-23-000034:mdna:106]
Since the beginning of 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments in future periods, if not repealed or otherwise modified.

[0000106040-23-000034:mdna:107]
[same as prior period, unchanged from 0000106040-23-000017:mdna:114]

[0000106040-23-000034:mdna:108]
[same as prior period, unchanged from 0000106040-23-000017:mdna:115]

[0000106040-23-000034:mdna:109]
[same as prior period, unchanged from 0000106040-23-000017:mdna:90]

[0000106040-23-000034:mdna:110]
[same as prior period, unchanged from 0000106040-23-000017:mdna:116]

[0000106040-23-000034:mdna:111]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-23-000034:mdna:112]
[same as prior period, unchanged from 0000106040-23-000017:mdna:118]

[0000106040-23-000034:mdna:113]
[same as prior period, unchanged from 0000106040-23-000017:mdna:121]

[0000106040-23-000034:mdna:114]
[same as prior period, unchanged from 0000106040-23-000017:mdna:122]

[0000106040-23-000034:mdna:115]
[same as prior period, unchanged from 0000106040-23-000017:mdna:123]

[0000106040-23-000034:mdna:116]
[same as prior period, unchanged from 0000106040-23-000017:mdna:124]

[0000106040-23-000034:mdna:117]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for the year ended June 30, 2023. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the year ended June 30, 2023 for a discussion of our critical accounting policies and estimates.
