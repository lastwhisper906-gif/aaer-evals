# WDC notes — 0000106040-25-000026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-25-000026:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology.

[0000106040-25-000026:notes:2]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

[0000106040-25-000026:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024 (the “2024 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2024 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-25-000026:notes:4]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 3, Discontinued Operations.

[0000106040-25-000026:notes:5]
[same as prior period, unchanged from 0000106040-25-000008:notes:4]

[0000106040-25-000026:notes:6]
[same as prior period, unchanged from 0000106040-25-000008:notes:5]

[0000106040-25-000026:notes:7]
[same as prior period, unchanged from 0000106040-25-000008:notes:6]

[0000106040-25-000026:notes:8]
Historically, the Company had been managed and operated under two reportable segments: hard disk drives (“HDD”) and Flash-based products (“Flash”). As a result of the Separation (as defined in Note 3, Discontinued Operations) and disposition of the Flash segment, the Company’s continuing operations now consist of a single reportable segment, HDD. The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), now evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s consolidated results.

[0000106040-25-000026:notes:9]
[same as prior period, unchanged from 0000106040-25-000008:notes:11]

[0000106040-25-000026:notes:10]
[same as prior period, unchanged from 0000106040-25-000008:notes:12]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-25-000026:notes:11]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-25-000026:notes:12]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued accounting standards update (“ASU”) No. 2022-04, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations” (“ASU 2022-04”), which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. As required by ASU 2022-04, the Company began to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 (see Note 15, Supplier Finance Program). Additionally, the Company will provide certain annual roll-forward information related to those obligations beginning with the Company’s financial statements for the year ending June 27, 2025.

[0000106040-25-000026:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-25-000026:notes:14]
In November 2024, the FASB issued ASU No. 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. The new guidance requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement, within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This standard is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years following adoption, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption and expects to adopt the guidance for annual reporting periods in its annual report for the year ending June 30, 2028.

[0000106040-25-000026:notes:15]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures” (“ASU 2023-07”), which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. ASU 2023-07 requires that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company is currently assessing these reporting requirements and expects to provide any required disclosures at the required time.

[0000106040-25-000026:notes:16]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” (“ASU 2023-09”). ASU 2023-09 calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company is currently compiling the information required for these disclosures and expects to provide any required disclosures in the year ending July 3, 2026.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000106040-25-000026:notes:17]
Discontinued Operations
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. In connection with the Separation, the Company has incurred separation and transition costs, which are recorded as Business separation costs within discontinued operations in the Company’s Condensed Consolidated Financial Statements as further detailed in the summary of net income (loss) from discontinued operations, net of taxes, below.

[0000106040-25-000026:notes:18]
On February 21, 2025, the Company completed the previously announced separation of its Flash business (the “Separation”) through a pro rata distribution of 80.1% of the outstanding shares of Sandisk Corporation (“Sandisk”) to Western Digital stockholders. The Separation is intended to be tax-free for U.S. federal income tax purposes. To reflect the completion of the Separation, the Company recorded a decrease in shareholders’ equity for the net book value of applicable assets and liabilities derecognized in connection with the Separation, net of the Company’s retained 19.9% ownership interest, initially based on the net book value of the applicable assets and liabilities derecognized. As a result of the Separation, Sandisk became an independent public company and Western Digital no longer consolidates Sandisk into the Company’s financial results. The historical net income of Sandisk and applicable assets and liabilities included in the Separation are now reported in the Company’s Condensed Consolidated Financial Statements as discontinued operations. Following the Separation, as the Company no longer controls or has the ability to exert significant influence over Sandisk, the Company measures, at fair value on a recurring basis, its retained ownership interest in Sandisk common stock (see additional information in Note 6, Fair Value Measurements and Investments). The Company expects to monetize its stake in Sandisk within one year from the Separation date.

[0000106040-25-000026:notes:19]
The Company entered into various agreements to effect the Separation and provide for the temporary framework of the relationship between Western Digital and Sandisk following the Separation, including, among others, a separation and distribution agreement, a tax matters agreement, and a transition services agreement. The transition services agreement provides for transition service support to be provided for various periods of time ranging up to 15 months. The amounts involved under these agreements are not expected to be material.

[0000106040-25-000026:notes:20]
The historical results of Sandisk have been reflected as discontinued operations in the Company’s Condensed Consolidated Financial Statements for all periods prior to the Separation on February 21, 2025.

[0000106040-25-000026:notes:21]
The following table provides a summary of the assets and liabilities classified as discontinued operations:

[0000106040-25-000026:notes:22]
| Assets and Liabilities of Discontinued Operations |  | June 28,2024 |
|  |  | (in millions) |
| Assets |
| Cash and cash equivalents |  | $ | 328 |  |
| Accounts receivable, net |  | 935 |  |
| Inventories |  | 1,955 |  |
| Other current assets |  | 313 |  |
| Current assets of discontinued operations |  | $ | 3,531 |  |
| Property, plant and equipment, net |  | $ | 808 |  |
| Notes receivable and investments in Flash Ventures |  | 991 |  |
| Goodwill |  | 5,713 |  |
| Other non-current assets |  | 1,101 |  |
| Non-current assets of discontinued operations |  | $ | 8,613 |  |
| Liabilities |
| Accounts payable |  | $ | 357 |  |
| Accounts payable to related parties |  | 313 |  |
| Accrued expenses |  | 427 |  |
| Income taxes payable |  | 54 |  |
| Accrued compensation |  | 173 |  |
| Current liabilities of discontinued operations |  | $ | 1,324 |  |
| Non-current liabilities of discontinued operations |  | $ | 368 |  |

[0000106040-25-000026:notes:23]
The following table provides a summary of net income (loss) from discontinued operations, net of taxes:

[0000106040-25-000026:notes:24]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
| Net Income (Loss) from Discontinued Operations, Net of Taxes |  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |  |  |
|  |  | (in millions) |  |  |
| Revenue, net |  | $ | 602 |  |  | $ | 1,705 |  |  | $ | 4,361 |  |  | $ | 4,926 |  |  |  |
| Cost of revenue |  | 485 |  |  | 1,223 |  |  | 2,892 |  |  | 4,410 |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 185 |  |  | 251 |  |  | 718 |  |  | 686 |  |  |  |
| Selling, general and administrative |  | 84 |  |  | 27 |  |  | 229 |  |  | 66 |  |  |  |
| Gain on business divestiture |  | — |  |  | — |  |  | (113) |  |  | — |  |  |  |
| Business separation costs |  | 57 |  |  | 23 |  |  | 144 |  |  | 59 |  |  |  |
| Employee termination, asset impairment and other |  | — |  |  | 2 |  |  | 3 |  |  | (74) |  |  |  |
| Operating income (loss) |  | (209) |  |  | 179 |  |  | 488 |  |  | (221) |  |  |  |
| Total interest and other income (expense), net |  | 1 |  |  | 11 |  |  | (36) |  |  | 4 |  |  |  |
| Income (loss) before taxes |  | (208) |  |  | 190 |  |  | 452 |  |  | (217) |  |  |  |
| Income tax expense |  | 44 |  |  | 47 |  |  | 236 |  |  | 101 |  |  |  |
| Net income (loss) from discontinued operations, net of taxes |  | $ | (252) |  |  | $ | 143 |  |  | $ | 216 |  |  | $ | (318) |  |  |  |

[0000106040-25-000026:notes:25]
Cash flows related to discontinued operations have not been segregated and are included in the Condensed Consolidated Statements of Cash Flows for all periods presented. The following table provides selected financial information related to cash flows from discontinued operations:

[0000106040-25-000026:notes:26]
|  |  | Nine Months Ended |
| Select Cash Flow Information from Discontinued Operations |  | March 28,2025 |  | March 29,2024 |
|  |  | (in millions) |
| Depreciation and amortization |  | $ | 117 |  |  | $ | 166 |  |
| Purchases of property, plant and equipment |  | 139 |  |  | 128 |  |
| Stock-based compensation |  | 98 |  |  | 71 |  |

[0000106040-25-000026:notes:27]
On February 21, 2025, prior to the effective time of the Separation, Sandisk entered into a loan agreement (the “Sandisk Loan Agreement”) by and among Sandisk, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and others party thereto. The Sandisk Loan Agreement comprises a term loan B facility in the principal amount of $2 billion (the “Sandisk Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Sandisk Revolving Credit Facility” and together with the Sandisk Term Loan Facility, the “Sandisk Facilities”). The obligations under this facility were retained by Sandisk upon the Separation.

[0000106040-25-000026:notes:28]
The Company previously had business ventures with Kioxia Corporation (“Kioxia”), which consisted of three separate legal entities: Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. The Company also previously had a business venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., both collectively referred to as the “Unis Venture.” All business ventures with Kioxia and Unis Venture were distributed to Sandisk in connection with the Separation and are included in discontinued operations.

[0000106040-25-000026:notes:29]
Prior to the Separation, effective September 28, 2024, the Company sold 80% of its equity interest in an indirect wholly-owned subsidiary in its Flash business, SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), resulting in a gain on divestiture of $113 million. Net proceeds from the sale received prior to the Separation were $401 million. The rights to the remaining future proceeds from the sale and the 20% retained interest in SDSS were distributed to Sandisk in connection with the Separation.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0000106040-25-000026:notes:30]
The following table provides selected financial information related to cash flows from discontinued operations:


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-25-000026:notes:31]
Disaggregated Revenue, Geographic Information, and Concentrations of Risk
Disaggregated Revenue

[0000106040-25-000026:notes:32]
The Company’s broad portfolio of technology and products addresses multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.

[0000106040-25-000026:notes:33]
[same as prior period, unchanged from 0000106040-25-000008:notes:23]

[0000106040-25-000026:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,007 |  |  | $ | 1,455 |  |  | $ | 6,012 |  |  | $ | 3,340 |  |
| Client | 137 |  |  | 140 |  |  | 416 |  |  | 440 |  |
| Consumer | 150 |  |  | 157 |  |  | 487 |  |  | 533 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 753 |  |  | $ | 600 |  |  | $ | 2,349 |  |  | $ | 1,677 |  |
| Americas | 1,182 |  |  | 882 |  |  | 3,468 |  |  | 1,844 |  |
| Europe, Middle East and Africa | 359 |  |  | 270 |  |  | 1,098 |  |  | 792 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |

[0000106040-25-000026:notes:35]
The Company’s top 10 customers accounted for 73% and 68% of its net revenue for the three and nine months ended March 28, 2025, respectively, compared to 59% and 53% of its net revenue for the three and nine months ended March 29, 2024, respectively. For the three months ended March 28, 2025, three customers accounted for 18%, 16%, and 13% of the Company’s net revenue, and for the nine months ended March 28, 2025, two customers accounted for 18% and 11% of the Company’s net revenue. For the three months ended March 29, 2024, one customer accounted for 12% of the Company’s net revenue, and for the nine months ended March 29, 2024, no customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-25-000026:notes:36]
[same as prior period, unchanged from 0000106040-25-000008:notes:30]

[0000106040-25-000026:notes:37]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. There were no trade accounts receivable sold during the nine months ended March 28, 2025. During the nine months ended March 29, 2024, the Company sold trade accounts receivable aggregating to $284 million. The discounts on the trade accounts receivable sold were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. There were no factored receivables outstanding as of March 28, 2025 and June 28, 2024.

[0000106040-25-000026:notes:38]
[same as prior period, unchanged from 0000106040-25-000008:notes:32]

[0000106040-25-000026:notes:39]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 227 |  |  | $ | 329 |  |
| Work-in-process | 786 |  |  | 829 |  |
| Finished goods | 298 |  |  | 229 |  |
| Total inventories | $ | 1,311 |  |  | $ | 1,387 |  |

[0000106040-25-000026:notes:40]
[same as prior period, unchanged from 0000106040-25-000008:notes:34]

[0000106040-25-000026:notes:41]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 225 |  |  | $ | 225 |  |
| Buildings and improvements | 1,543 |  |  | 1,419 |  |
| Machinery and equipment | 6,468 |  |  | 6,301 |  |
| Computer equipment and software | 323 |  |  | 313 |  |
| Furniture and fixtures | 33 |  |  | 32 |  |
| Construction-in-process | 576 |  |  | 685 |  |
| Property, plant and equipment, gross | 9,168 |  |  | 8,975 |  |
| Accumulated depreciation | (6,821) |  |  | (6,616) |  |
| Property, plant and equipment, net | $ | 2,347 |  |  | $ | 2,359 |  |

[0000106040-25-000026:notes:42]
[same as prior period, unchanged from 0000106040-25-000008:notes:36]

[0000106040-25-000026:notes:43]
As part of the Company’s prior acquisitions, the Company recorded, at the time of each acquisition, acquired in-process research and development (“IPR&D”) for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of both March 28, 2025 and June 28, 2024, IPR&D included in intangible assets, net was $72 million. During the three and nine months ended March 28, 2025 and March 29, 2024, the Company did not record any impairment charges related to IPR&D.

[0000106040-25-000026:notes:44]
Non-current assets

[0000106040-25-000026:notes:45]
|  | March 28,2025 |  | June 28,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Non-current assets: |  |  |  |  |  |  |  |  |  |
| Deferred tax assets | $ | 989 |  |  | $ | 225 |  |  |  |  |  |  |  |
| Other non-current assets | 551 |  |  | 534 |  |  |  |  |  |  |  |
| Total non-current assets | $ | 1,540 |  |  | $ | 759 |  |  |  |  |  |  |  |

[0000106040-25-000026:notes:46]
[same as prior period, unchanged from 0000106040-25-000008:notes:38]

[0000106040-25-000026:notes:47]
[same as prior period, unchanged from 0000106040-25-000008:notes:39]

[0000106040-25-000026:notes:48]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 121 |  |  | $ | 159 |  |  | $ | 142 |  |  | $ | 202 |  |  |  |
| Charges to operations | 24 |  |  | 21 |  |  | 73 |  |  | 55 |  |  |  |
| Utilization | (18) |  |  | (21) |  |  | (61) |  |  | (87) |  |  |  |
| Changes in estimate related to pre-existing warranties | (11) |  |  | 1 |  |  | (38) |  |  | (10) |  |  |  |
| Warranty accrual, end of period | $ | 116 |  |  | $ | 160 |  |  | $ | 116 |  |  | $ | 160 |  |  |  |

[0000106040-25-000026:notes:49]
[same as prior period, unchanged from 0000106040-25-000008:notes:41]

[0000106040-25-000026:notes:50]
|  | March 28,2025 |  | June 28,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 33 |  |  | $ | 9 |  |  |  |  |  |  |  |
| Long-term portion | 83 |  |  | 133 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 116 |  |  | $ | 142 |  |  |  |  |  |  |  |

[0000106040-25-000026:notes:51]
[same as prior period, unchanged from 0000106040-25-000008:notes:43]

[0000106040-25-000026:notes:52]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | — |  |  | $ | 144 |  |
| Non-current portion of unrecognized tax benefits | 473 |  |  | 499 |  |
| Other non-current liabilities | 400 |  |  | 359 |  |
| Total other liabilities | $ | 873 |  |  | $ | 1,002 |  |

[0000106040-25-000026:notes:53]
Goodwill

[0000106040-25-000026:notes:54]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed goodwill impairment assessments and concluded there were no impairments for the three- and nine-month periods ended March 28, 2025 and March 29, 2024. The carrying amount of goodwill was $4.32 billion as of both March 28, 2025 and June 28, 2024.

[0000106040-25-000026:notes:55]
Accumulated other comprehensive income (loss)

[0000106040-25-000026:notes:56]
Accumulated other comprehensive income (loss), net of tax, refers to expenses, gains, and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The components of accumulated other comprehensive income (loss) were as follows:

[0000106040-25-000026:notes:57]
|  | Actuarial Pension Gains |  | Foreign Currency Translation Adjustment |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 28, 2024 | $ | 14 |  |  | $ | (505) |  |  |  |  | $ | (221) |  |  | $ | (712) |  |
| Other comprehensive income before reclassifications | — |  |  | 45 |  |  |  |  | 21 |  |  | 66 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  | 151 |  |  | 151 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | — |  |  |  |  | (40) |  |  | (40) |  |
| Net current-period other comprehensive income | — |  |  | 45 |  |  |  |  | 132 |  |  | 177 |  |
| Distribution in connection with the Separation | — |  |  | 458 |  |  |  |  | 88 |  |  | 546 |  |
| Balance at March 28, 2025 | $ | 14 |  |  | $ | (2) |  |  |  |  | $ | (1) |  |  | $ | 11 |  |

[0000106040-25-000026:notes:58]
During the three and nine months ended March 28, 2025, the amounts reclassified out of accumulated other comprehensive loss were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0000106040-25-000026:notes:59]
As of March 28, 2025, all existing net losses related to cash flow hedges recorded in accumulated other comprehensive income (loss) are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-25-000026:notes:60]
[same as prior period, unchanged from 0000106040-25-000008:notes:50]

[0000106040-25-000026:notes:61]
[same as prior period, unchanged from 0000106040-25-000008:notes:51]

[0000106040-25-000026:notes:62]
[same as prior period, unchanged from 0000106040-25-000008:notes:52]

[0000106040-25-000026:notes:63]
[same as prior period, unchanged from 0000106040-25-000008:notes:53]

[0000106040-25-000026:notes:64]
[same as prior period, unchanged from 0000106040-25-000008:notes:54]

[0000106040-25-000026:notes:65]
The following tables present information about the Company’s financial instruments that were measured at fair value on a recurring basis for the periods presented and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-25-000026:notes:66]
|  | March 28, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,447 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,447 |  |
| Retained interest in Sandisk | 1,412 |  |  | — |  |  | — |  |  | 1,412 |  |
| Foreign exchange contracts | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets at fair value | $ | 2,859 |  |  | $ | 5 |  |  | $ | — |  |  | $ | 2,864 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |

[0000106040-25-000026:notes:67]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 388 |  |  | $ | — |  |  | $ | — |  |  | $ | 388 |  |
| Foreign exchange contracts | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets at fair value | $ | 388 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 389 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |

[0000106040-25-000026:notes:68]
[same as prior period, unchanged from 0000106040-25-000008:notes:58]

[0000106040-25-000026:notes:69]
[same as prior period, unchanged from 0000106040-25-000008:notes:59]

[0000106040-25-000026:notes:70]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of 2025 and the fourth quarter of 2024, respectively.

[0000106040-25-000026:notes:71]
|  | March 28, 2025 |  | June 28, 2024 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,298 |  |  | $ | 2,292 |  |  | $ | 2,296 |  |  | $ | 2,253 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | — |  |  | 2,578 |  |  | 2,539 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,469 |  |  | 2,458 |  |  | — |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,573 |  |  | 2,068 |  |  | 1,568 |  |  | 2,556 |  |
| 2.85% senior notes due 2029 | 497 |  |  | 454 |  |  | 496 |  |  | 434 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 421 |  |  | 496 |  |  | 407 |  |
| Total | $ | 7,333 |  |  | $ | 7,693 |  |  | $ | 7,434 |  |  | $ | 8,189 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-25-000026:notes:72]
Derivative Instruments and Hedging Activities
As of March 28, 2025, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. All of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of March 28, 2025, the Company did not have any derivative contracts with credit risk related contingent features.

[0000106040-25-000026:notes:73]
Changes in fair values of the non-designated foreign exchange contracts were recognized in Other income (expense), net and were largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For each of the three and nine months ended March 28, 2025 and March 29, 2024, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-25-000026:notes:74]
Unrealized gains or losses on designated cash flow hedges were recognized in Accumulated other comprehensive income (loss). For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data – Accumulated other comprehensive income (loss).

[0000106040-25-000026:notes:75]
[same as prior period, unchanged from 0000106040-25-000008:notes:65]

[0000106040-25-000026:notes:76]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of March 28, 2025 and June 28, 2024, the effect of offset rights was not material, and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-25-000026:notes:77]
Debt
Debt consisted of the following:

[0000106040-25-000026:notes:78]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,480 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,380 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,333 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,426) |  |  | (1,750) |  |
| Long-term debt | $ | 4,907 |  |  | $ | 5,684 |  |

[0000106040-25-000026:notes:79]
On February 20, 2025, the Company entered into a fourth amendment to the loan agreement governing the Company’s revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”) and term loan facility, dated as of January 7, 2022 (as amended, the “Loan Agreement”) that, among other changes, (a) permitted the Separation, (b) provided for the automatic release, in connection with the Separation, of guarantees and liens on collateral provided by Sandisk (as defined below) and Sandisk Technologies, Inc. under the Loan Agreement, (c) provided for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a noncash exchange to replace the Company’s previously existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”), (d) facilitates a potential future debt for equity exchange with respect to the Term Loan A-3 in connection with the Sandisk retained interest, and (e) in connection with the Separation, reduced the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion.

[0000106040-25-000026:notes:80]
During the three and nine months ended March 28, 2025, the Company made scheduled repayments of $32 million and $107 million, respectively, under the Term Loan Facility. The Term Loan A-3 bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies (as defined in the Loan Agreement), with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-3 as of March 28, 2025 was 5.927%.

[0000106040-25-000026:notes:81]
During the nine months ended March 28, 2025, the Company drew and repaid $150 million principal amount under the 2027 Revolving Credit Facility. As of March 28, 2025, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $1.25 billion as of that date.

[0000106040-25-000026:notes:82]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of March 28, 2025, the Company was in compliance with the financial covenant.

[0000106040-25-000026:notes:83]
As of March 28, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

[0000106040-25-000026:notes:84]
The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.89 per share of common stock (which conversion price has been adjusted from its original conversion price of approximately $52.20 in accordance with the Indenture as a result of the Separation). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028, upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-25-000026:notes:85]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended March 31, 2025 and accordingly, the holders of the 2028 Convertible Notes do not have the right to convert the notes during the succeeding calendar quarter ending June 30, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of March 28, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

[0000106040-25-000026:notes:86]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $37.89 per share, which has been adjusted from its original conversion price of approximately $52.20 per share according to the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $51.00 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 11 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.

[0000106040-25-000026:notes:87]
Subsequent to March 28, 2025, the Company redeemed, at its election, $1.80 billion aggregate principal amount of its 4.75% senior unsecured notes due 2026 (the “2026 Notes”) at par plus accrued interest. Following such redemption, $500 million aggregate principal amount of the 2026 Notes remained outstanding.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-25-000026:notes:88]
[same as prior period, unchanged from 0000106040-25-000008:notes:76]

[0000106040-25-000026:notes:89]
[same as prior period, unchanged from 0000106040-25-000008:notes:77]

[0000106040-25-000026:notes:90]
[same as prior period, unchanged from 0000106040-25-000008:notes:78]

[0000106040-25-000026:notes:91]
|  | March 28,2025 |  | June 28,2024 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 256 |  |  | $ | 244 |  |  |  |
| Fair value of plan assets at end of period | 188 |  |  | 184 |  |  |  |
| Unfunded status | $ | 68 |  |  | $ | 60 |  |  |  |

[0000106040-25-000026:notes:92]
[same as prior period, unchanged from 0000106040-25-000008:notes:80]

[0000106040-25-000026:notes:93]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Current liabilities (included in Accrued expenses) | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities (included in Other liabilities) | 67 |  |  | 59 |  |
| Net amount recognized | $ | 68 |  |  | $ | 60 |  |

[0000106040-25-000026:notes:94]
Net periodic benefit costs were immaterial for the three and nine months ended March 28, 2025 and March 29, 2024.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-25-000026:notes:95]
[same as prior period, unchanged from 0000106040-25-000008:notes:113]

[0000106040-25-000026:notes:96]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term.

[0000106040-25-000026:notes:97]
[same as prior period, unchanged from 0000106040-25-000008:notes:115]

[0000106040-25-000026:notes:98]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 129 |  |  | $ | 143 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 31 |  |  | 28 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 116 |  |  | 133 |  |
| Total operating lease liabilities | $ | 147 |  |  | $ | 161 |  |

[0000106040-25-000026:notes:99]
[same as prior period, unchanged from 0000106040-25-000008:notes:117]

[0000106040-25-000026:notes:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Cost of operating leases | $ | 7 |  |  | $ | 10 |  |  | $ | 24 |  |  | $ | 30 |  |
| Cash paid for operating leases | 8 |  |  | 11 |  |  | 28 |  |  | 33 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 6 |  |  | 1 |  |  | 18 |  |  | 10 |  |

[0000106040-25-000026:notes:101]
[same as prior period, unchanged from 0000106040-25-000008:notes:119]

[0000106040-25-000026:notes:102]
|  | March 28,2025 |  | June 28,2024 |  |  |
| Weighted average remaining lease term in years | 6.2 |  | 6.6 |  |  |
| Weighted average discount rate | 5.0 | % |  | 5.0 | % |  |  |

[0000106040-25-000026:notes:103]
As of March 28, 2025, minimum lease payments were as follows:

[0000106040-25-000026:notes:104]
|  | Lease Amounts |
|  | (in millions) |
| Remaining three months of 2025 | $ | 9 |  |
| 2026 | 36 |  |
| 2027 | 30 |  |
| 2028 | 23 |  |
| 2029 | 17 |  |
| Thereafter | 57 |  |
| Total future minimum lease payments | 172 |  |
| Less: imputed interest | 25 |  |
| Present value of lease liabilities | $ | 147 |  |

[0000106040-25-000026:notes:105]
[same as prior period, unchanged from 0000106040-25-000008:notes:125]

[0000106040-25-000026:notes:106]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions, such as performance, quality and technology of the vendor’s components. As of March 28, 2025, the Company had the following minimum long-term commitments:

[0000106040-25-000026:notes:107]
|  | Long-Term Commitments |
|  | (in millions) |
| Remaining three months of 2025 | $ | 45 |  |
| 2026 | 49 |  |
| 2027 | 27 |  |
| Total | $ | 121 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-25-000026:notes:108]
[same as prior period, unchanged from 0000106040-25-000008:notes:128]

[0000106040-25-000026:notes:109]
In connection with the Separation (as discussed in Note 3, Discontinued Operations), on February 21, 2025, all outstanding stock-based compensation awards associated with continuing Western Digital employees were adjusted with the intent to preserve the intrinsic value of each award immediately before and after the Separation. The adjustments were determined using a ratio calculated based on the closing price of the Company’s common stock immediately before the Separation and the average of the closing price on each of the first five days of trading after the Separation. The terms of the outstanding awards remain the same and any unvested stock awards will continue to vest over the original vesting periods. An incremental value of approximately $40 million resulting from the adjustment of the unvested awards will be recognized ratably over the remaining service periods. Upon the Separation, approximately 3.1 million unvested stock-based compensation awards were retained by Sandisk employees and will vest upon completion of any remaining service period with Sandisk and approximately 3.5 million awards were cancelled from the Company’s incentive plans.

[0000106040-25-000026:notes:110]
The following tables present the Company’s stock-based compensation for equity-settled awards by type (i.e., restricted stock units (“RSUs”), restricted stock unit awards with performance conditions or market conditions (“PSUs”), and rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”)) and financial statement line items as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-25-000026:notes:111]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |  |
|  | (in millions) |
| RSUs and PSUs | $ | 34 |  |  | $ | 44 |  |  | $ | 110 |  |  | $ | 137 |  |  |
| ESPP | 1 |  |  | 8 |  |  | 12 |  |  | 18 |  |  |
| Total | $ | 35 |  |  | $ | 52 |  |  | $ | 122 |  |  | $ | 155 |  |  |

[0000106040-25-000026:notes:112]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |  |
|  | (in millions) |
| Cost of revenue | $ | 7 |  |  | $ | 8 |  |  | $ | 26 |  |  | $ | 28 |  |  |
| Research and development | 17 |  |  | 17 |  |  | 52 |  |  | 49 |  |  |
| Selling, general and administrative | 11 |  |  | 27 |  |  | 44 |  |  | 78 |  |  |
| Subtotal | 35 |  |  | 52 |  |  | 122 |  |  | 155 |  |  |
| Tax benefit | (4) |  |  | (7) |  |  | (15) |  |  | (21) |  |  |
| Total | $ | 31 |  |  | $ | 45 |  |  | $ | 107 |  |  | $ | 134 |  |  |

[0000106040-25-000026:notes:113]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax benefit, were immaterial for the periods presented.

[0000106040-25-000026:notes:114]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of March 28, 2025:

[0000106040-25-000026:notes:115]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 270 |  |  | 2.2 |

[0000106040-25-000026:notes:116]
[same as prior period, unchanged from 0000106040-25-000008:notes:135]

[0000106040-25-000026:notes:117]
[same as prior period, unchanged from 0000106040-25-000008:notes:136]

[0000106040-25-000026:notes:118]
[same as prior period, unchanged from 0000106040-25-000008:notes:137]

[0000106040-25-000026:notes:119]
[same as prior period, unchanged from 0000106040-25-000008:notes:138]

[0000106040-25-000026:notes:120]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 28, 2024 | 13.0 |  |  | $ | 44.42 |  |  |  |
| Granted | 5.2 |  |  | 59.54 |  |  |  |
| Vested | (5.0) |  |  | 42.92 |  |  | $ | 304 |  |
| Forfeited | (1.1) |  |  | 45.71 |  |  |  |
| Share conversion due to Separation | 2.6 |  |  | 52.15 |  |  |  |
| Awards cancelled due to Separation | (3.5) |  |  | 52.32 |  |  |  |
| RSUs and PSUs outstanding at March 28, 2025 | 11.2 |  |  | $ | 37.88 |  |  |  |

[0000106040-25-000026:notes:121]
[same as prior period, unchanged from 0000106040-25-000008:notes:140]

[0000106040-25-000026:notes:122]
Dividends

[0000106040-25-000026:notes:123]
On April 29, 2025, the Company’s Board of Directors authorized the adoption of a quarterly cash dividend program. Under the cash dividend program, holders of the Company’s common stock will receive dividends when and as declared by the Board of Directors. In conjunction with the adoption of the cash dividend program, the Board of Directors declared a cash dividend of $0.10 per share of the Company’s common stock, which will be paid on June 18, 2025 to shareholders of record as of the close of business on June 4, 2025. The Company may suspend or discontinue its cash dividend program at any time.

[0000106040-25-000026:notes:124]
[same as prior period, unchanged from 0000106040-25-000008:notes:141]

[0000106040-25-000026:notes:125]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing 5,000,000 authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement. As of March 28, 2025 and June 28, 2024, 235,000 of the Preferred Shares were outstanding.

[0000106040-25-000026:notes:126]
The Preferred Shares have an initial stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. Such dividends are payable on a quarterly basis in cash or in-kind through an increase to the stated value. Through December 27, 2024, the Company paid quarterly dividends on the Preferred Shares in-kind through an increase to the stated value. On January 25, 2025, the Board of the Directors of the Company declared its first cash dividend on the Preferred Shares, which was paid subsequent to quarter end on March 31, 2025, to the holders of the Preferred Shares as of March 15, 2025, the record date for the dividend. As of March 28, 2025 and June 28, 2024, unpaid and cumulative dividends payable with respect to the Preferred Shares were $30 million and $22 million, respectively. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis.

[0000106040-25-000026:notes:127]
As of March 28, 2025, the Preferred Shares are convertible into shares of the Company’s common stock at a conversion rate of approximately $35.51 per share (the “Conversion Price”). The conversion rate was adjusted from the initial conversion rate of $47.75 per share as a result of the Separation, in accordance with the Certificate of Designations for the Preferred Shares, using a ratio of the closing price of the Company’s and Sandisk’s common stock over the first 10 trading days after the Separation. This rate is subject to future anti-dilution adjustments and certain other one-time adjustments in the event of various specified spin-off transactions. The conversion applies to the total of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends. In the case of future standalone spin-off transactions, holders of the Preferred Shares may convert one-third of their shares into a similar class of preferred shares of the spin-off entity. The Company may opt to convert the Preferred Shares after January 31, 2026, if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately before the Company's conversion notice.

[0000106040-25-000026:notes:128]
As of March 28, 2025 and June 28, 2024, the Preferred Shares outstanding had an aggregate liquidation preference of $265 million and $257 million, respectively, and would have been convertible, if otherwise permitted, into approximately 7 million and 5 million shares of common stock, respectively, based on the conversion rate in effect at each date.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-25-000026:notes:129]
Income Taxes 
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act requires the Company to capitalize and amortize research and development (“R&D”) expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for the three and nine months ended March 28, 2025 and March 29, 2024.

[0000106040-25-000026:notes:130]
[same as prior period, unchanged from 0000106040-25-000008:notes:147]

[0000106040-25-000026:notes:131]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”), some of which are effective for the Company in fiscal year 2025. For fiscal year 2025, the Company currently expects to be able to meet certain transitional safe harbors and does not expect any material GMT taxes. As more jurisdictions adopt this legislation in fiscal year 2026, there may be material increases in the Company’s future tax obligations in certain jurisdictions.

[0000106040-25-000026:notes:132]
The following table presents the Company’s Income tax benefit and the effective tax rate:

[0000106040-25-000026:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 74 |  | $ | (12) |  | $ | 783 |  | $ | (546) |
| Income tax benefit | (698) |  | (4) |  | (608) |  | (27) |
| Effective tax rate | (943) | % |  | 33 | % |  | (78) | % |  | 5 | % |

[0000106040-25-000026:notes:134]
The primary drivers of the difference between the effective tax rate for the three and nine months ended March 28, 2025 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, credits, and tax holidays in the Philippines and Thailand that will expire at various dates during years 2026 through 2033. These resulted in decreases to the Company’s effective tax rate below the U.S. statutory rate for the three and nine months ended March 28, 2025. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in the Company’s effective tax rate being close to the U.S. Federal statutory rate for the three and nine months ended March 28, 2025. In anticipation of operating as a standalone HDD business in a GMT environment, the Company executed an inter-entity asset transfer in conjunction with the separation of its Flash business. This resulted in the recognition of one-time deferred tax benefits to continuing operations of $711 million for the three and nine months ended March 28, 2025.

[0000106040-25-000026:notes:135]
The primary drivers of the difference between the effective tax rate for the three and nine months ended March 29, 2024 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits, and tax holidays in Malaysia, the Philippines, and Thailand. In addition, the effective tax rate for the nine months ended March 29, 2024 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with U.S. Internal Revenue Service (“IRS”) calculations.

[0000106040-25-000026:notes:136]
[same as prior period, unchanged from 0000106040-25-000008:notes:153]

[0000106040-25-000026:notes:137]
[same as prior period, unchanged from 0000106040-25-000008:notes:154]

[0000106040-25-000026:notes:138]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the nine months ended March 28, 2025 (in millions):

[0000106040-25-000026:notes:139]
| Accrual balance at June 28, 2024 | $ | 721 |  |
| Gross increases related to current year tax positions | 11 |  |
| Gross increases related to prior year tax positions | 4 |  |
| Gross decreases related to prior year tax positions | (7) |  |
| Settlements | (40) |  |
| Lapse of statute of limitations | (2) |  |
| Transfer to discontinued operations | (126) |  |
| Accrual balance at March 28, 2025 | $ | 561 |  |

[0000106040-25-000026:notes:140]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of March 28, 2025 were $70 million. Of the aggregate unrecognized tax benefits, including interest and penalties, as of March 28, 2025, approximately $476 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-25-000026:notes:141]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024 also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the nine months ended March 28, 2025, the Company made a payment of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of March 28, 2025 related to all years from 2008 through 2015.

[0000106040-25-000026:notes:142]
[same as prior period, unchanged from 0000106040-25-000008:notes:159]

[0000106040-25-000026:notes:143]
The Company believes that an adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 28, 2025, with the exception of the IRS matter discussed above, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:EarningsPerShareTextBlock

[0000106040-25-000026:notes:144]
[same as prior period, unchanged from 0000106040-25-000008:notes:161]

[0000106040-25-000026:notes:145]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions, except per share data) |
| Net income (loss) from continuing operations | $ | 772 |  |  |  | $ | (8) |  |  | $ | 1,391 |  |  | $ | (519) |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  |  | 15 |  |  | 12 |  |  | 44 |  |
| Less: income attributable to participating securities(1) | 13 |  |  |  | (1) |  |  | 25 |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic | 755 |  |  |  | (22) |  |  | 1,354 |  |  | (563) |  |
| Net income (loss) from discontinued operations, net of taxes | (248) |  |  |  | 135 |  |  | 213 |  |  | (318) |  |
| Net income (loss) attributable to common shareholders - basic | $ | 507 |  |  |  | $ | 113 |  |  | $ | 1,567 |  |  | $ | (881) |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic | $ | 755 |  |  |  | $ | (22) |  |  | $ | 1,354 |  |  | $ | (563) |  |
| Re-allocation of participating securities considered potentially dilutive securities | — |  |  |  | — |  |  | 1 |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - diluted | 755 |  |  |  | (22) |  |  | 1,355 |  |  | (563) |  |
| Net income (loss) from discontinued operations, net of taxes | (248) |  |  |  | 135 |  |  | 213 |  |  | (318) |  |
| Net income (loss) attributable to common shareholders - diluted | $ | 507 |  |  |  | $ | 113 |  |  | $ | 1,568 |  |  | $ | (881) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 348 |  |  |  | 326 |  |  | 346 |  |  | 324 |  |
| RSUs, PSUs, ESPP, and the convertible notes | 10 |  |  |  | 9 |  |  | 12 |  |  | — |  |
| Diluted | 358 |  |  |  | 335 |  |  | 358 |  |  | 324 |  |
| Net income (loss) per common share |  |  |  |  |  |  |  |  |
| Continuing operations - basic | $ | 2.17 |  |  |  | $ | (0.07) |  |  | $ | 3.91 |  |  | $ | (1.74) |  |
| Discontinued operations - basic | $ | (0.71) |  |  |  | $ | 0.42 |  |  | $ | 0.62 |  |  | $ | (0.98) |  |
| Net income (loss) per common share - basic | $ | 1.46 |  |  |  | $ | 0.35 |  |  | $ | 4.53 |  |  | $ | (2.72) |  |
| Continuing operations - diluted | $ | 2.11 |  |  |  | $ | (0.07) |  |  | $ | 3.79 |  |  | $ | (1.74) |  |
| Discontinued operations - diluted | $ | (0.69) |  |  |  | $ | 0.41 |  |  | $ | 0.59 |  |  | $ | (0.98) |  |
| Net income (loss) per common share - diluted | $ | 1.42 |  |  |  | $ | 0.34 |  |  | $ | 4.38 |  |  | $ | (2.72) |  |
| Anti-dilutive potential common shares excluded | — |  |  |  | — |  |  | — |  |  | 13 |  |

[0000106040-25-000026:notes:146]
[same as prior period, unchanged from 0000106040-25-000008:notes:163]

[0000106040-25-000026:notes:147]
Basic net income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends allocated to preferred shareholders less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income or loss per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The “if-converted” method is used to determine the dilutive impact for the convertible notes and the preferred shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.
Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and preferred shares. For the nine months ended March 29, 2024, the Company recorded a net loss, and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for those periods because their impact would have been anti-dilutive. For the three and nine months ended March 28, 2025 and three months ended March 29, 2024, based on the Company’s average stock price during the period, an insignificant number of common shares subject to outstanding equity awards were anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-25-000026:notes:148]
[same as prior period, unchanged from 0000106040-25-000008:notes:166]

[0000106040-25-000026:notes:149]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure, and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. In this regard, for the nine months ended March 29, 2024, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress and other assets and the recognition of a liability for certain contract termination costs.

[0000106040-25-000026:notes:150]
[same as prior period, unchanged from 0000106040-25-000008:notes:168]

[0000106040-25-000026:notes:151]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 35 |  |  |  |
| Asset impairments | — |  |  | 5 |  |  | — |  |  | 99 |  |  |  |
| Other charges (gains): |  |  |  |  |  |  |  |  |  |
| Recovery of non-cancellable purchase order | — |  |  | — |  |  | (9) |  |  | — |  |  |  |
| Contract termination and other | — |  |  | — |  |  | 2 |  |  | 29 |  |  |  |
| Total employee termination, asset impairment and other | $ | — |  |  | $ | 6 |  |  | $ | (7) |  |  | $ | 163 |  |  |  |

[0000106040-25-000026:notes:152]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the nine months ended March 28, 2025:

[0000106040-25-000026:notes:153]
|  |  |  | Contract Termination and Other |  |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |  |
| Accrual balance at June 28, 2024 |  |  | $ | 28 |  |  |  |  |  |  |  |
| Charges |  |  | 2 |  |  |  |  |  |  |  |
| Cash payments |  |  | (9) |  |  |  |  |  |  |  |
| Recovery of non-cancellable purchase order |  |  | (9) |  |  |  |  |  |  |  |
| Accrual balance at March 28, 2025 |  |  | $ | 12 |  |  |  |  |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-25-000026:notes:154]
[same as prior period, unchanged from 0000106040-25-000008:notes:172]

[0000106040-25-000026:notes:155]
[same as prior period, unchanged from 0000106040-25-000008:notes:173]

[0000106040-25-000026:notes:156]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $44 million and $37 million as of March 28, 2025 and June 28, 2024, respectively, and are included within Accounts payable on the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-25-000026:notes:157]
Legal Proceedings
Tax

[0000106040-25-000026:notes:158]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Taxes.

[0000106040-25-000026:notes:159]
Intellectual Property Litigation

[0000106040-25-000026:notes:160]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S. Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

[0000106040-25-000026:notes:161]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives.

[0000106040-25-000026:notes:162]
Subsequent to March 28, 2025, pursuant to a confidential agreement effective as of April 17, 2025, MRT and the Company reached a global settlement of $130 million for all pending legal disputes. The settlement results in the dismissal of the MRT matter, as well as a second patent litigation matter MRT filed on August 22, 2024 against the Company. As a result of the settlement, the Company reversed $201 million of previously recorded charges in Operating expense under Litigation matter and $6 million of post-judgment interest previously recorded in Other income (expense), net.

[0000106040-25-000026:notes:163]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company is contesting the judgment and, based on available arguments, the Company believes the judgment, including any prejudgment interest and legal costs will be reversed, amended or vacated based on the Company’s motions for judgment as a matter of law in the district court or when the Company presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of March 28, 2025.

[0000106040-25-000026:notes:164]
Other Matters

[0000106040-25-000026:notes:165]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.

[0000106040-25-000026:notes:166]
The ability to predict the ultimate outcome of any legal proceeding involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000106040-25-000026:notes:167]
Gene Zamiska, Senior Vice President, Global Accounting and Chief Accounting Officer of the Company, adopted a Rule 10b5-1 Plan on March 6, 2025. Under this plan, up to an aggregate of 29,653 shares of the Company’s common stock may be sold before the plan expires on September 4, 2026.
