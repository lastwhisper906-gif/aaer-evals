# WDC 8-K — 0000106040-25-000020 filed 2025-04-30

## item codes, every 8-K on or before 2025-05-02

- 2025-04-30 0000106040-25-000020 — 2.02, 9.01
- 2025-04-07 0000106040-25-000016 — 7.01, 9.01
- 2025-03-13 0001193125-25-054005 — 5.03, 7.01, 9.01
- 2025-02-26 0000106040-25-000012 — 9.01 — amendment of 0001193125-25-033383
- 2025-02-24 0001193125-25-033383 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2025-02-03 0001193125-25-019294 — 8.01, 9.01
- 2025-02-03 0001193125-25-019288 — 5.02
- 2025-01-30 0001193125-25-017188 — 5.02, 9.01
- 2025-01-29 0000106040-25-000005 — 2.02, 9.01
- 2025-01-16 0001193125-25-007725 — 2.02, 5.02
- 2024-12-13 0001193125-24-278458 — 5.02
- 2024-11-25 0001193125-24-265164 — 5.02, 5.07, 9.01
- 2024-10-24 0000106040-24-000037 — 2.02, 9.01
- 2024-08-27 0001193125-24-207265 — 8.01, 9.01
- 2024-07-31 0000106040-24-000026 — 2.02, 9.01
- 2024-05-24 0001193125-24-147062 — 5.02
- 2024-05-14 0001193125-24-138274 — 3.03, 5.03, 5.07, 9.01
- 2024-04-25 0000106040-24-000020 — 2.02, 9.01
- 2024-03-05 0001193125-24-059385 — 8.01, 9.01
- 2024-03-04 0001193125-24-056949 — 1.01, 8.01
- 2024-01-25 0000106040-24-000003 — 2.02, 9.01
- 2024-01-04 0001193125-24-002432 — 5.02
- 2023-12-26 0001193125-23-302249 — 8.01, 9.01
- 2023-11-17 0001193125-23-279782 — 5.02, 5.07, 9.01
- 2023-11-03 0001193125-23-270415 — 1.01, 2.03, 3.02, 9.01
- 2023-11-01 0001193125-23-267654 — 7.01, 9.01
- 2023-10-30 0001193125-23-266188 — 7.01, 9.01
- 2023-10-30 0001193125-23-265708 — 7.01, 9.01
- 2023-10-30 0000106040-23-000032 — 2.02, 9.01
- 2023-10-10 0001193125-23-253508 — 1.01, 9.01
- 2023-07-31 0000106040-23-000020 — 2.02, 5.02, 9.01
- 2023-06-21 0001193125-23-171211 — 1.01, 9.01
- 2023-05-08 0000106040-23-000014 — 2.02, 9.01
- 2023-05-05 0001193125-23-137241 — 8.01, 9.01
- 2023-04-03 0001193125-23-088802 — 8.01, 9.01
- 2023-02-07 0001193125-23-026907 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01 — amendment of 0001193125-23-020502
- 2023-02-01 0001193125-23-020502 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01
- 2023-01-31 0000106040-23-000006 — 1.01, 2.02, 2.03, 9.01
- 2022-12-23 0001193125-22-311796 — 1.01, 9.01
- 2022-11-18 0001193125-22-288992 — 5.02, 5.07, 9.01
- 2022-10-27 0000106040-22-000061 — 2.02, 9.01
- 2022-08-05 0000106040-22-000049 — 2.02, 9.01
- 2022-07-01 0001193125-22-187239 — 1.01, 9.01
- 2022-06-17 0001193125-22-176478 — 5.02, 9.01
- 2022-06-08 0001193125-22-169552 — 1.01, 7.01, 8.01, 9.01
- 2022-04-28 0000106040-22-000030 — 2.02, 9.01
- 2022-01-27 0001193125-22-019801 — 5.02, 7.01, 9.01
- 2022-01-27 0000106040-22-000010 — 2.02, 9.01
- 2022-01-07 0001193125-22-004434 — 1.01, 2.03, 7.01
- 2021-12-10 0001193125-21-353971 — 1.01, 2.03, 7.01, 8.01, 9.01
- 2021-12-06 0001193125-21-348304 — 7.01
- 2021-11-19 0001193125-21-335120 — 5.04, 9.01
- 2021-11-18 0001193125-21-332703 — 5.02
- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2025-05-02

- 2024-02-08 0000106040-24-000011 — NT 10-Q, for the period ended 2023-12-29
- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-25-000020:8k_2_02:1]
EX-99.1
2
a4ex991-pressreleaseq325.htm
EX-99.1

[0000106040-25-000020:8k_2_02:2]
Document

[0000106040-25-000020:8k_2_02:3]
Exhibit 99.1

[0000106040-25-000020:8k_2_02:4]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results; Adopts Dividend Program and Declares Quarterly Cash Dividend on Common Stock

[0000106040-25-000020:8k_2_02:5]
News Summary

[0000106040-25-000020:8k_2_02:6]
•Third quarter revenue was $2.29 billion, down 5% sequentially (QoQ). Cloud revenue decreased 4% (QoQ), Client revenue decreased 2% (QoQ) and Consumer revenue decreased 13% (QoQ).

[0000106040-25-000020:8k_2_02:7]
•Third quarter GAAP earnings per share (EPS) was $2.11 and Non-GAAP EPS was $1.36.

[0000106040-25-000020:8k_2_02:8]
•Expect fiscal fourth quarter 2025 revenue to be in the range of $2.45 billion +/- $150 million.

[0000106040-25-000020:8k_2_02:9]
•Expect Non-GAAP EPS in the range of $1.45 +/- $0.20.

[0000106040-25-000020:8k_2_02:10]
•The company’s Board of Directors authorized the adoption of a quarterly cash dividend program and declared a cash dividend of $0.10 per share.

[0000106040-25-000020:8k_2_02:11]
SAN JOSE, Calif. — April 30, 2025 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal third quarter 2025 financial results.

[0000106040-25-000020:8k_2_02:12]
“Western Digital executed well in its fiscal third quarter achieving revenue at the high end of our guidance range and gross margin over 40%,” said Irving Tan, CEO of Western Digital. “Even in a world marked by geopolitical uncertainty and shifting tariff dynamics, one thing remains constant: the exponential growth of data. When it comes to storing that data, at scale, no technology rivals the cost-efficiency and reliability of HDDs. With our rich portfolio of storage products, WD is uniquely positioned to meet our customers’ mass storage needs.”

[0000106040-25-000020:8k_2_02:13]
On April 29, 2025, the company’s Board of Directors authorized the adoption of a quarterly cash dividend program beginning with the quarter ending June 27, 2025 and declared a cash dividend of $0.10 per share of the company’s common stock, payable on June 18, 2025 to shareholders of record as of June 4, 2025.

[0000106040-25-000020:8k_2_02:14]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results

[0000106040-25-000020:8k_2_02:15]
Q3 2025 Financial Highlights

[0000106040-25-000020:8k_2_02:16]
| ($ in millions, except per share amounts) |  |  |  |  |  |  |  |  |
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2025 | Q2 2025 | Q/Q |  | Q3 2025 | Q2 2025 | Q/Q |
| Revenue |  | $2,294 | $2,409 | down 5% |  | $2,294 | $2,409 | down 5% |
| Gross Margin |  | 39.8% | 37.7% | up 2.1 ppt |  | 40.1% | 38.4% | up 1.7 ppt |
| Operating Expenses |  | $152 | $347 | down 56% |  | $324 | $335 | down 3% |
| Operating Income |  | $760 | $560 | up 36% |  | $596 | $591 | up 1% |
| Diluted Net Income Attributable to Common Shareholders |  | $755 | $455 | up 66% |  | $487 | $420 | up 16% |
| Net Income Per Share |  | $2.11 | $1.27 | up 66% |  | $1.36 | $1.18 | up 15% |

[0000106040-25-000020:8k_2_02:17]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q3 2025 | Q3 2024 | Y/Y |  | Q3 2025 | Q3 2024 | Y/Y |
| Revenue |  | $2,294 | $1,752 | up 31% |  | $2,294 | $1,752 | up 31% |
| Gross Margin |  | 39.8% | 29.6% | up 10.2 ppt |  | 40.1% | 30.1% | up 10.0 ppt |
| Operating Expenses |  | $152 | $425 | down 64% |  | $324 | $375 | down 14% |
| Operating Income |  | $760 | $94 | up 709% |  | $596 | $153 | up 290% |

[0000106040-25-000020:8k_2_02:18]
The company had an operating cash inflow of $508 million and ended the quarter with $3.48 billion of total cash and cash equivalents.

[0000106040-25-000020:8k_2_02:19]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-25-000020:8k_2_02:20]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results

[0000106040-25-000020:8k_2_02:21]
End Market Summary

[0000106040-25-000020:8k_2_02:22]
| Revenue ($M) | Q3 2025 | Q2 2025 | Q/Q |  |  | Q3 2024 | Y/Y |  |  |  |
| Cloud | $2,007 | $2,096 | down 4% |  |  | $1,455 | up 38% |  |  |  |
| Client | 137 | 140 | down 2% |  |  | 140 | down 2% |  |  |  |
| Consumer | 150 | 173 | down 13% |  |  | 157 | down 4% |  |  |  |
| Total Revenue | $2,294 | $2,409 | down 5% |  |  | $1,752 | up 31% |  |  |  |

[0000106040-25-000020:8k_2_02:23]
In the fiscal third quarter:

[0000106040-25-000020:8k_2_02:24]
•Cloud represented 87% of total revenue at $2.0 billion, down 4% sequentially and up 38% year-over-year. On a sequential basis, the decline was due to a 6% reduction in nearline bit shipments while pricing per unit in Cloud was up 5%. On a year-over-year basis, both revenue and bit shipments grew at 38% and 32%, respectively, driven by the strength of our product portfolio.

[0000106040-25-000020:8k_2_02:25]
•Client represented 6% of total revenue at $137 million, down 2% on both a sequential and year-over-year basis. Compared to last quarter and last year, revenue was down due to lower unit shipments.

[0000106040-25-000020:8k_2_02:26]
•Consumer represented 7% of total revenue at $150 million, down 13% sequentially and 4% year-over-year. The sequential decline in Consumer was primarily due to lower unit shipments; year over year, the decrease was largely due to pricing.

[0000106040-25-000020:8k_2_02:27]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results

[0000106040-25-000020:8k_2_02:28]
Business Outlook for Fiscal Fourth Quarter of 2025

[0000106040-25-000020:8k_2_02:29]
|  | Three Months Ending |
|  | June 27, 2025 |
|  | GAAP |  | Non-GAAP(1) |
| Revenue | $2.45B +/- $150M |  | $2.45B +/- $150M |
| Gross margin | 39.5% - 40.5% |  | 40.0% - 41.0% |
| Operating expenses ($M) | $385 - $395 |  | $330 - $340 |
| Interest and other expense, net ($M) | ~ $70 |  | ~ $70 |
| Tax rate(2) | N/A |  | 8.0% - 10.0% |
| Diluted earnings per share | N/A |  | $1.45 +/- $0.20 |
| Diluted shares outstanding (in millions) | ~ 360 |  | ~ 360 |

[0000106040-25-000020:8k_2_02:30]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense, totaling approximately $10 million to $15 million. The company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense and other expenses, totaling approximately $50 million to $60 million. In the aggregate, Non-GAAP diluted earnings per share guidance excludes these items totaling $60 million to $75 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, and Non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the company excludes from its Non-GAAP tax rate and Non-GAAP diluted earnings per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP tax rate and Non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, tax rate and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-25-000020:8k_2_02:31]
(2) Non-GAAP tax rate is determined based on a percentage of Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax rate may differ from our GAAP tax rate (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) due to the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax rate for the full year, excluding loss jurisdictions; and (iii) because our GAAP income taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0000106040-25-000020:8k_2_02:32]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results

[0000106040-25-000020:8k_2_02:33]
Basis of Presentation

[0000106040-25-000020:8k_2_02:34]
On February 21, 2025 (the “Separation Date”), Western Digital Corporation (“WDC”) completed the previously announced separation of its Flash business unit into a separate company, Sandisk Corporation (“Sandisk”). Sandisk is now an independent public company.

[0000106040-25-000020:8k_2_02:35]
The financial and operating results of Sandisk subsequent to the Separation Date are no longer consolidated into WDC’s financial and operating results, and the historical results and financial position of Sandisk for all periods prior to the Separation Date have been reflected as discontinued operations in WDC’s preliminary condensed consolidated balance sheets and preliminary condensed consolidated statements of operations included in this release.

[0000106040-25-000020:8k_2_02:36]
Dividend Program

[0000106040-25-000020:8k_2_02:37]
The amount and timing of future dividends under the company’s dividend program will depend on market conditions and other corporate considerations. The company may suspend or discontinue the dividend program at any time.

[0000106040-25-000020:8k_2_02:38]
Investor Communications

[0000106040-25-000020:8k_2_02:39]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal fourth quarter of 2025 will be broadcast live online today at 5:30 a.m. Pacific/8:30 a.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-25-000020:8k_2_02:40]
About Western Digital

[0000106040-25-000020:8k_2_02:41]
Western Digital empowers the systems and people who rely on data. Consistently delivering massive capacity, high quality and low total cost of ownership, Western Digital is trusted by hyperscale cloud providers, enterprise data centers, content professionals and consumers around the world. Core to its values, the company recognizes the urgency to combat climate change and is on a mission to design storage technologies that not only meet today’s data demands but also contribute to a more climate-conscious future. Follow Western Digital on LinkedIn and learn more at www.westerndigital.com.

[0000106040-25-000020:8k_2_02:42]
Forward-Looking Statements

[0000106040-25-000020:8k_2_02:43]
Western Digital Reports Fiscal Third Quarter 2025 Financial Results

[0000106040-25-000020:8k_2_02:44]
and growth opportunities; and the company’s dividend payment plans. These forward-looking statements are based on management’s current expectations and are subject to risks and uncertainties that could cause actual results to differ materially from those expressed or implied in the forward-looking statements. The preliminary financial results for the company’s fiscal third quarter ended March 28, 2025 included in this press release represent the most current information available to management. Actual results when disclosed in the company’s Form 10-Q may differ from these preliminary results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review by the company’s independent registered accounting firm; and other developments that may arise between now and the filing of the company’s Form 10-Q. Other key risks and uncertainties that could cause actual results to differ materially from those expressed or implied in the forward-looking statements include: adverse global or regional conditions, including new or additional tariffs or trade restrictions; volatility in demand for the company’s products; inflation; increases in interest rates and an economic recession; future responses to and effects of global health crises; the impact of business and market conditions; the outcome and impact of the company’s completed separation of its HDD and Flash businesses, including with respect to stock price volatility and the diversion of management’s attention from ongoing business operations and opportunities; the impact of competitive products and pricing; the company’s development and introduction of products based on new technologies and expansion into new data storage markets; risks associated with cost saving initiatives, restructurings, acquisitions, divestitures, mergers, joint ventures and the company’s strategic relationships; difficulties or delays in manufacturing or other supply chain disruptions; hiring and retention of key employees; the company’s level of debt and other financial obligations; changes to the company’s relationships with key customers; compromise, damage or interruption from cybersecurity incidents or other data system security risks; actions by competitors; any decisions to reduce or discontinue paying cash dividends; the company’s ability to achieve its greenhouse gas emissions reduction and other sustainability goals; the impact of international conflicts; risks associated with compliance with changing legal and regulatory requirements and the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Annual Report on Form 10-K filed with the SEC on August 20, 2024 to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update or revise these forward-looking statements to reflect new information or events, except as required by law.

[0000106040-25-000020:8k_2_02:45]
###

[0000106040-25-000020:8k_2_02:46]
Western Digital, the Western Digital logo, and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-25-000020:8k_2_02:47]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:48]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-25-000020:8k_2_02:49]
(in millions; unaudited; on a US GAAP basis)

[0000106040-25-000020:8k_2_02:50]
|  | March 28,2025 |  | June 28,2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,477 |  |  | $ | 1,551 |  |
| Accounts receivable, net | 1,469 |  |  | 1,231 |  |
| Inventories | 1,311 |  |  | 1,387 |  |
| Retained interest in Sandisk | 1,412 |  |  | — |  |
| Other current assets | 417 |  |  | 360 |  |
| Current assets of discontinued operations | — |  |  | 3,531 |  |
| Total current assets | 8,086 |  |  | 8,060 |  |
| Property, plant and equipment, net | 2,347 |  |  | 2,359 |  |
| Goodwill | 4,319 |  |  | 4,319 |  |
| Other intangible assets, net | 76 |  |  | 78 |  |
| Other non-current assets | 1,540 |  |  | 759 |  |
| Non-current assets of discontinued operations | — |  |  | 8,613 |  |
| Total assets | $ | 16,368 |  |  | $ | 24,188 |  |
| LIABILITIES, CONVERTIBLE PREFERRED STOCK AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,287 |  |  | $ | 1,054 |  |
| Accrued expenses | 774 |  |  | 1,053 |  |
| Income taxes payable | 373 |  |  | 471 |  |
| Accrued compensation | 322 |  |  | 435 |  |
| Current portion of long-term debt | 2,426 |  |  | 1,750 |  |
| Current liabilities of discontinued operations | — |  |  | 1,324 |  |
| Total current liabilities | 5,182 |  |  | 6,087 |  |
| Long-term debt | 4,907 |  |  | 5,684 |  |
| Other liabilities | 873 |  |  | 1,002 |  |
| Non-current liabilities of discontinued operations | — |  |  | 368 |  |
| Total liabilities | 10,962 |  |  | 13,141 |  |
| Convertible preferred stock, aggregate liquidation preference of $265 and $257, respectively | 229 |  |  | 229 |  |
| Total shareholders’ equity | 5,177 |  |  | 10,818 |  |
| Total liabilities, convertible preferred stock and shareholders’ equity | $ | 16,368 |  |  | $ | 24,188 |  |

[0000106040-25-000020:8k_2_02:51]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:52]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-25-000020:8k_2_02:53]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-25-000020:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenue, net | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |  |  |
| Cost of revenue | 1,382 |  |  | 1,233 |  |  | 4,290 |  |  | 3,237 |  |  |  |
| Gross profit | 912 |  |  | 519 |  |  | 2,625 |  |  | 1,076 |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 245 |  |  | 243 |  |  | 732 |  |  | 683 |  |  |  |
| Selling, general and administrative | 108 |  |  | 176 |  |  | 444 |  |  | 542 |  |  |  |
| Litigation matter | (201) |  |  | — |  |  | (198) |  |  | — |  |  |  |
| Employee termination, asset impairment and other | — |  |  | 6 |  |  | (7) |  |  | 163 |  |  |  |
| Total operating expenses | 152 |  |  | 425 |  |  | 971 |  |  | 1,388 |  |  |  |
| Operating income (loss) | 760 |  |  | 94 |  |  | 1,654 |  |  | (312) |  |  |  |
| Interest and other expense | (686) |  |  | (106) |  |  | (871) |  |  | (234) |  |  |  |
| Income (loss) before taxes | 74 |  |  | (12) |  |  | 783 |  |  | (546) |  |  |  |
| Income tax benefit | (698) |  |  | (4) |  |  | (608) |  |  | (27) |  |  |  |
| Net income (loss) from continuing operations | 772 |  |  | (8) |  |  | 1,391 |  |  | (519) |  |  |  |
| Net income (loss) from discontinued operations, net of taxes | (252) |  |  | 143 |  |  | 216 |  |  | (318) |  |  |  |
| Net income (loss) | $ | 520 |  |  | $ | 135 |  |  | $ | 1,607 |  |  | $ | (837) |  |  |  |

[0000106040-25-000020:8k_2_02:55]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:56]
PRELIMINARY EARNINGS (LOSS) PER COMMON SHARE

[0000106040-25-000020:8k_2_02:57]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-25-000020:8k_2_02:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions, except per share data) |
| Net income (loss) from continuing operations | $ | 772 |  |  |  | $ | (8) |  |  | $ | 1,391 |  |  | $ | (519) |  |
| Less: dividends allocated to preferred shareholders | 4 |  |  |  | 15 |  |  | 12 |  |  | 44 |  |
| Less: income attributable to participating securities(1) | 13 |  |  |  | (1) |  |  | 25 |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic | 755 |  |  |  | (22) |  |  | 1,354 |  |  | (563) |  |
| Net income (loss) from discontinued operations, net of taxes | (248) |  |  |  | 135 |  |  | 213 |  |  | (318) |  |
| Net income (loss) attributable to common shareholders - basic | $ | 507 |  |  |  | $ | 113 |  |  | $ | 1,567 |  |  | $ | (881) |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic | $ | 755 |  |  |  | $ | (22) |  |  | $ | 1,354 |  |  | $ | (563) |  |
| Re-allocation of participating securities considered potentially dilutive securities | — |  |  |  | — |  |  | 1 |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - diluted | 755 |  |  |  | (22) |  |  | 1,355 |  |  | (563) |  |
| Net income (loss) from discontinued operations, net of taxes | (248) |  |  |  | 135 |  |  | 213 |  |  | (318) |  |
| Net income (loss) attributable to common shareholders - diluted | $ | 507 |  |  |  | $ | 113 |  |  | $ | 1,568 |  |  | $ | (881) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 348 |  |  |  | 326 |  |  | 346 |  |  | 324 |  |
| RSUs, PSUs, ESPP, and the convertible notes | 10 |  |  |  | 9 |  |  | 12 |  |  | — |  |
| Diluted | 358 |  |  |  | 335 |  |  | 358 |  |  | 324 |  |
| Net income (loss) from continuing operations per common share |  |  |  |  |  |  |  |  |
| Continuing operations - basic | $ | 2.17 |  |  |  | $ | (0.07) |  |  | $ | 3.91 |  |  | $ | (1.74) |  |
| Discontinued operations - basic | $ | (0.71) |  |  |  | $ | 0.42 |  |  | $ | 0.62 |  |  | $ | (0.98) |  |
| Earnings (loss) per common share - basic | $ | 1.46 |  |  |  | $ | 0.35 |  |  | $ | 4.53 |  |  | $ | (2.72) |  |
| Continuing operations - diluted | $ | 2.11 |  |  |  | $ | (0.07) |  |  | $ | 3.79 |  |  | $ | (1.74) |  |
| Discontinued operations - diluted | $ | (0.69) |  |  |  | $ | 0.41 |  |  | $ | 0.59 |  |  | $ | (0.98) |  |
| Earnings (loss) per common share - diluted | $ | 1.42 |  |  |  | $ | 0.34 |  |  | $ | 4.38 |  |  | $ | (2.72) |  |

[0000106040-25-000020:8k_2_02:59]
(1)     Preferred stock represents participating securities because the preferred stock participates in any dividends on shares of common stock on a pari passu, pro rata basis. Preferred stock does not participate in undistributed net losses.

[0000106040-25-000020:8k_2_02:60]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:61]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-25-000020:8k_2_02:62]
(in millions; unaudited; on a US GAAP basis)

[0000106040-25-000020:8k_2_02:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Cash flows from operating activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | 520 |  |  | $ | 135 |  |  | $ | 1,607 |  |  | $ | (837) |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 110 |  |  | 140 |  |  | 365 |  |  | 430 |  |
| Stock-based compensation | 59 |  |  | 77 |  |  | 220 |  |  | 226 |  |
| Deferred income taxes | (708) |  |  | (52) |  |  | (682) |  |  | (120) |  |
| Gain on disposal of assets | 2 |  |  | — |  |  | (3) |  |  | (87) |  |
| Gain on business divestiture | — |  |  | — |  |  | (113) |  |  | — |  |
| Asset impairment | — |  |  | 4 |  |  | — |  |  | 99 |  |
| Gain on repurchases of debt | — |  |  | — |  |  | — |  |  | (4) |  |
| Amortization of debt issuance costs and discounts | 11 |  |  | 5 |  |  | 21 |  |  | 14 |  |
| Unrealized loss on retained interest in Sandisk | 606 |  |  | — |  |  | 606 |  |  | — |  |
| Other non-cash operating activities, net | 18 |  |  | 52 |  |  | 75 |  |  | 24 |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | 527 |  |  | (277) |  |  | 96 |  |  | (202) |  |
| Inventories | (317) |  |  | 1 |  |  | (429) |  |  | 483 |  |
| Accounts payable | 99 |  |  | (88) |  |  | 341 |  |  | 211 |  |
| Accounts payable to related parties | 15 |  |  | 59 |  |  | (39) |  |  | 18 |  |
| Accrued expenses | (425) |  |  | (64) |  |  | (316) |  |  | (310) |  |
| Income taxes payable | (23) |  |  | (30) |  |  | (80) |  |  | (524) |  |
| Accrued compensation | (55) |  |  | 93 |  |  | (131) |  |  | 97 |  |
| Other assets and liabilities, net | 69 |  |  | 3 |  |  | (593) |  |  | (178) |  |
| Net cash provided by (used in) operating activities | 508 |  |  | 58 |  |  | 945 |  |  | (660) |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (128) |  |  | (95) |  |  | (336) |  |  | (176) |  |
| Net proceeds from business divestiture | 210 |  |  | — |  |  | 401 |  |  | — |  |
| Activity related to Flash Ventures, net | 56 |  |  | 128 |  |  | 148 |  |  | 207 |  |
| Strategic investments and other, net | 4 |  |  | (26) |  |  | 7 |  |  | — |  |
| Net cash provided by investing activities | 142 |  |  | 7 |  |  | 220 |  |  | 31 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |
| Employee stock plans, net | 5 |  |  | (16) |  |  | (23) |  |  | (26) |  |
| Convertible preferred stock issuance costs | — |  |  | — |  |  | — |  |  | (5) |  |
| Purchase of capped calls | — |  |  | — |  |  | — |  |  | (155) |  |
| Repurchases of debt | — |  |  | — |  |  | — |  |  | (505) |  |
| Proceeds from (repayments of) debt, net | 1,968 |  |  | (629) |  |  | 1,893 |  |  | 1,233 |  |
| Debt issuance costs | (74) |  |  | — |  |  | (74) |  |  | (36) |  |
| Cash transferred to Sandisk related to Separation | (1,366) |  |  | — |  |  | (1,366) |  |  | — |  |
| Net cash provided by (used in) financing activities | 533 |  |  | (645) |  |  | 430 |  |  | 506 |  |
| Effect of exchange rate changes on cash | 3 |  |  | (7) |  |  | 3 |  |  | (6) |  |
| Net increase (decrease) in cash and cash equivalents | 1,186 |  |  | (587) |  |  | 1,598 |  |  | (129) |  |
| Cash and cash equivalents, beginning of period | 2,291 |  |  | 2,481 |  |  | 1,879 |  |  | 2,023 |  |
| Cash and cash equivalents, end of period | $ | 3,477 |  |  | $ | 1,894 |  |  | $ | 3,477 |  |  | $ | 1,894 |  |

[0000106040-25-000020:8k_2_02:64]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:65]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-25-000020:8k_2_02:66]
(in millions; unaudited)

[0000106040-25-000020:8k_2_02:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | December 27,2024 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| GAAP gross profit | $ | 912 |  |  | $ | 907 |  |  | $ | 519 |  |  | $ | 2,625 |  |  | $ | 1,076 |  |
| Stock-based compensation expense | 7 |  |  | 9 |  |  | 8 |  |  | 26 |  |  | 28 |  |
| Litigation matter | — |  |  | 10 |  |  | — |  |  | 19 |  |  | — |  |
| Other | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Non-GAAP gross profit | $ | 920 |  |  | $ | 926 |  |  | $ | 528 |  |  | $ | 2,672 |  |  | $ | 1,105 |  |
| GAAP operating expenses | $ | 152 |  |  | $ | 347 |  |  | $ | 425 |  |  | $ | 971 |  |  | $ | 1,388 |  |
| Stock-based compensation expense | (28) |  |  | (21) |  |  | (44) |  |  | (96) |  |  | (127) |  |
| Litigation matter | 201 |  |  | — |  |  | — |  |  | 198 |  |  | — |  |
| Employee termination, asset impairment and other | — |  |  | 10 |  |  | (6) |  |  | 7 |  |  | (163) |  |
| Strategic review | — |  |  | — |  |  | — |  |  | — |  |  | (38) |  |
| Other | (1) |  |  | (1) |  |  | — |  |  | (2) |  |  | (2) |  |
| Non-GAAP operating expenses | $ | 324 |  |  | $ | 335 |  |  | $ | 375 |  |  | $ | 1,078 |  |  | $ | 1,058 |  |
| GAAP operating income (loss) | $ | 760 |  |  | $ | 560 |  |  | $ | 94 |  |  | $ | 1,654 |  |  | $ | (312) |  |
| Gross profit adjustments | 8 |  |  | 19 |  |  | 9 |  |  | 47 |  |  | 29 |  |
| Operating expense adjustments | (172) |  |  | 12 |  |  | 50 |  |  | (107) |  |  | 330 |  |
| Non-GAAP operating income | $ | 596 |  |  | $ | 591 |  |  | $ | 153 |  |  | $ | 1,594 |  |  | $ | 47 |  |
| GAAP interest and other expense, net | $ | (686) |  |  | $ | (94) |  |  | $ | (106) |  |  | $ | (871) |  |  | $ | (234) |  |
| Unrealized loss on retained interest in Sandisk | 606 |  |  | — |  |  | — |  |  | 606 |  |  | — |  |
| Litigation matter | (6) |  |  | 4 |  |  | — |  |  | — |  |  | — |  |
| Other | 2 |  |  | — |  |  | 3 |  |  | 3 |  |  | (58) |  |
| Non-GAAP interest and other expense, net | $ | (84) |  |  | $ | (90) |  |  | $ | (103) |  |  | $ | (262) |  |  | $ | (292) |  |
| GAAP income tax benefit | $ | (698) |  |  | $ | — |  |  | N/A |  | $ | (608) |  |  | N/A |
| Income tax adjustments | 710 |  |  | 70 |  |  |  |  | 741 |  |  |  |
| Non-GAAP income tax expense | $ | 12 |  |  | $ | 70 |  |  |  |  | $ | 133 |  |  |  |

[0000106040-25-000020:8k_2_02:68]
WESTERN DIGITAL CORPORATION

[0000106040-25-000020:8k_2_02:69]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-25-000020:8k_2_02:70]
(in millions, except per share amounts; unaudited)

[0000106040-25-000020:8k_2_02:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | December 27,2024 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| GAAP net income | $ | 772 |  |  | $ | 466 |  |  | N/A |  | $ | 1,391 |  |  | N/A |
| Stock-based compensation expense | 35 |  |  | 30 |  |  |  |  | 122 |  |  |  |
| Litigation matter | (207) |  |  | 14 |  |  |  |  | (179) |  |  |  |
| Employee termination, asset impairment and other | — |  |  | (10) |  |  |  |  | (7) |  |  |  |
| Unrealized loss on retained interest in Sandisk | 606 |  |  | — |  |  |  |  | 606 |  |  |  |
| Other | 4 |  |  | 1 |  |  |  |  | 7 |  |  |  |
| Income tax adjustments | (710) |  |  | (70) |  |  |  |  | (741) |  |  |  |
| Non-GAAP net income | 500 |  |  | 431 |  |  |  |  | 1,199 |  |  |  |
| Less: amount allocated to preferred shareholders | 13 |  |  | 11 |  |  |  |  | 32 |  |  |  |
| Non-GAAP diluted net income attributable to common shareholders | $ | 487 |  |  | $ | 420 |  |  |  |  | $ | 1,167 |  |  |  |
| Diluted income per common share: |  |  |  |  |  |  |  |  |  |
| GAAP(1) | $ | 2.11 |  |  | $ | 1.27 |  |  |  |  | $ | 3.79 |  |  |  |
| Non-GAAP | $ | 1.36 |  |  | $ | 1.18 |  |  |  |  | $ | 3.26 |  |  |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 358 |  |  | 357 |  |  |  |  | 358 |  |  |  |
| Non-GAAP | 358 |  |  | 357 |  |  |  |  | 358 |  |  |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 508 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 945 |  |  | $ | (660) |  |
| Purchases of property, plant and equipment, net | (128) |  |  | (113) |  |  | (95) |  |  | (336) |  |  | (176) |  |
| Activity related to Flash Ventures, net | 56 |  |  | 45 |  |  | 128 |  |  | 148 |  |  | 207 |  |
| Free cash flow(2) | $ | 436 |  |  | $ | 335 |  |  | $ | 91 |  |  | $ | 757 |  |  | $ | (629) |  |

[0000106040-25-000020:8k_2_02:72]
(1) To calculate GAAP diluted net income from continuing operations per common share for the three months ended December 27, 2024, net income from continuing operations is reduced by $11 million for the amount allocated to preferred shareholders to determine the amount available to common shareholders.

[0000106040-25-000020:8k_2_02:73]
(2) Cash flows are presented on a consolidated basis and include the results of Sandisk through the February 21, 2025 date of separation.

[0000106040-25-000020:8k_2_02:74]
Notes to Preliminary GAAP to Non-GAAP Reconciliations

[0000106040-25-000020:8k_2_02:75]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the tables above set forth Non-GAAP gross profit; Non-GAAP gross margin; Non-GAAP operating expenses; Non-GAAP operating income and loss; Non-GAAP interest and other expense, net; Non-GAAP interest tax expense; Non-GAAP net income; Non-GAAP diluted income per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not alternatives for measures prepared in accordance with GAAP and may be different from similarly titled Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense; charges related to a litigation matter; employee termination, asset impairment and other; expenses related to our strategic review; unrealized loss on retained interest in Sandisk; other adjustments; and income tax adjustments. The company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-25-000020:8k_2_02:76]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-25-000020:8k_2_02:77]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company’s control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0000106040-25-000020:8k_2_02:78]
Litigation matter. The company had recognized expenses related to a previous judgment in a patent litigation matter, which consisted of an award of damages, prejudgment interest, and estimated plaintiff legal costs. The company had also recognized post-judgment interest in interest and other expense, net as well as expenses in its cost of revenue related to the amortization of patent licenses that the company has capitalized related to this litigation matter. The company has since entered into a settlement agreement with the plaintiff, which resulted in the reversal of a portion of these charges for the three and nine months ended March 28, 2025. The company believes these charges and reversals do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business. For further information regarding the litigation matter, see Note 17 to the notes to consolidated financial statements included in the company’s Annual Report on Form 10-K filed with the SEC on August 20, 2024, as well as Note 16 to the notes to consolidated financial statements included in the company’s Quarterly Report on Form 10-Q for the quarter ended March 28, 2025 when filed.

[0000106040-25-000020:8k_2_02:79]
Employee termination, asset impairment and other. From time to time, in order to realign the company’s operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time to time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. In addition, the company has taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-25-000020:8k_2_02:80]
Strategic review. The company incurred expenses associated with its review of strategic alternatives that resulted in the planned separation of its HDD and Flash business units to create two independent, public companies. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-25-000020:8k_2_02:81]
Unrealized loss on retained interest in Sandisk. The company retained a 19.9% ownership interest in Sandisk and recognized an unrealized loss on the mark-to-market adjustment of such interest. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-25-000020:8k_2_02:82]
Other adjustments. From time to time, the company sells or impairs investments or other assets that are not considered necessary to its business operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-25-000020:8k_2_02:83]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments for one-time deferred tax benefits related to an internal reorganization executed in conjunction with the separation of the Flash business and the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-25-000020:8k_2_02:84]
Additionally, free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company’s business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-25-000020:8k_2_02:85]
___________________

[0000106040-25-000020:8k_2_02:86]
Contacts:

[0000106040-25-000020:8k_2_02:87]
Western Digital Corp.

[0000106040-25-000020:8k_2_02:88]
| Investor Contact: |  | Media Contact: |
| Ambrish Srivastava |  | Media Relations |
| 408.717.9765 |  | 408.801.0021 |
| ambrish.srivastava@wdc.com |  | WD.Mediainquiries@wdc.com |
| investor@wdc.com |  |  |
