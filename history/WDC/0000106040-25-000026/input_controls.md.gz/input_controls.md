# WDC 10-Q controls and the auditor's report


## item_4_controls

[0000106040-25-000026:item_4_controls:1]
Item 4.    Controls and Procedures

[0000106040-25-000026:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000106040-25-000026:item_4_controls:3]
As required by Rule 13a-15(b) promulgated by the Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Quarterly Report on Form 10-Q, our disclosure controls and procedures were effective.

[0000106040-25-000026:item_4_controls:4]
Changes in Internal Controls over Financial Reporting

[0000106040-25-000026:item_4_controls:5]
During the quarter ended March 28, 2025, we completed the separation of our Flash business (the “Separation”). In connection with the Separation, certain controls within our internal control over financial reporting related to the divested operations were removed from our control environment.

[0000106040-25-000026:item_4_controls:6]
Other than the changes related to the Separation described above, there were no changes in our internal control over financial reporting during the third quarter of fiscal year 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000106040-25-000026:item_4_controls:7]
55
