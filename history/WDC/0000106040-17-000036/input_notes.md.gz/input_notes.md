# WDC notes — 0000106040-17-000036


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-17-000036:notes:1]
The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of September 29, 2017, by remaining contractual maturity, were as follows:

[0000106040-17-000036:notes:2]
|  | Cost Basis |  | Fair Value |
|  | (in millions) |
| Due in less than one year (short-term investments) | $ | 34 |  |  | $ | 35 |  |
| Due in one to five years (included in other non-current assets) | 94 |  |  | 94 |  |
| Total | $ | 128 |  |  | $ | 129 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0000106040-17-000036:notes:3]
[same as prior period, unchanged from 0000106040-17-000013:notes:12]

[0000106040-17-000036:notes:4]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 6,886 |  |  | $ | 6,354 |  |
| Short-term marketable securities | 35 |  |  | 24 |  |
| Long-term marketable securities | 94 |  |  | 94 |  |
| Total cash, cash equivalents and marketable securities | $ | 7,015 |  |  | $ | 6,472 |  |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0000106040-17-000036:notes:5]
The following table presents the unfunded status of the benefit obligations for the Japanese Plan:

[0000106040-17-000036:notes:6]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Benefit obligations | $ | 248 |  |  | $ | 249 |  |
| Fair value of plan assets | 190 |  |  | 189 |  |
| Unfunded status | $ | 58 |  |  | $ | 60 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-17-000036:notes:7]
Commitments, Contingencies and Related Parties

[0000106040-17-000036:notes:8]
Flash Ventures

[0000106040-17-000036:notes:9]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-17-000036:notes:10]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 29, 2017 and June 30, 2017:

[0000106040-17-000036:notes:11]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 365 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 114 |  |  | 119 |  |
| Notes receivable, Flash Forward | 406 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 278 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,462 |  |  | $ | 1,340 |  |

[0000106040-17-000036:notes:12]
During the three months ended September 29, 2017, the Company made net payments to Flash Ventures of $792 million for purchased flash-based memory wafers and net loans and investments.

[0000106040-17-000036:notes:13]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-17-000036:notes:14]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other expense, net in the Condensed Consolidated Statements of Operations. There were no such impairments in each of the three-month periods ended September 29, 2017 and September 30, 2016.

[0000106040-17-000036:notes:15]
As of September 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $226 million and $206 million, respectively.

[0000106040-17-000036:notes:16]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-17-000036:notes:17]
|  | September 29, 2017 |
| Notes receivable | $ | 885 |  |
| Equity investments | 577 |  |
| Operating lease guarantees | 1,022 |  |
| Inventory | 202 |  |
| Maximum estimable loss exposure | $ | 2,686 |  |

[0000106040-17-000036:notes:18]
The Company is committed to purchase its provided three-month forecast of Flash Ventures’ NAND wafer supply, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-17-000036:notes:19]
Off-Balance Sheet Liabilities

[0000106040-17-000036:notes:20]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including the Company.

[0000106040-17-000036:notes:21]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017.

[0000106040-17-000036:notes:22]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 115 |  |  | $ | 1,022 |  |

[0000106040-17-000036:notes:23]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017:

[0000106040-17-000036:notes:24]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Year 1 |  | $ | 275 |  |  | $ | 10 |  |  | $ | 285 |  |
| Year 2 |  | 190 |  |  | 34 |  |  | 224 |  |
| Year 3 |  | 184 |  |  | 82 |  |  | 266 |  |
| Year 4 |  | 96 |  |  | 76 |  |  | 172 |  |
| Year 5 |  | 29 |  |  | 46 |  |  | 75 |  |
| Total guarantee obligations |  | $ | 774 |  |  | $ | 248 |  |  | $ | 1,022 |  |

[0000106040-17-000036:notes:25]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.


## us-gaap:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0000106040-17-000036:notes:26]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net income | $ | 681 |  |  | $ | 805 |  |  | $ | 575 |  |  | $ | (1,380 | ) |  | $ | 681 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment | (4 | ) |  | (4 | ) |  | (4 | ) |  | 8 |  |  | (4 | ) |
| Net unrealized gain on derivative contracts | 4 |  |  | 3 |  |  | 3 |  |  | (6 | ) |  | 4 |  |
| Net unrealized loss on available-for-sale securities | (1 | ) |  | (1 | ) |  | (1 | ) |  | 2 |  |  | (1 | ) |
| Total other comprehensive loss, before tax | (1 | ) |  | (2 | ) |  | (2 | ) |  | 4 |  |  | (1 | ) |
| Income tax benefit (expense) related to items of other comprehensive loss | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | — |  |
| Other comprehensive loss, net of tax | (1 | ) |  | (2 | ) |  | (4 | ) |  | 6 |  |  | (1 | ) |
| Total comprehensive income | $ | 680 |  |  | $ | 803 |  |  | $ | 571 |  |  | $ | (1,374 | ) |  | $ | 680 |  |

[0000106040-17-000036:notes:27]
| Condensed Consolidating Statement of Comprehensive Income (Loss) |
| For the three months ended September 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Net loss | $ | (366 | ) |  | $ | (15 | ) |  | $ | (227 | ) |  | $ | 242 |  |  | $ | (366 | ) |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |
| Actuarial pension gain | 5 |  |  | 5 |  |  | 5 |  |  | (10 | ) |  | 5 |  |
| Foreign currency translation adjustment | 17 |  |  | 17 |  |  | 18 |  |  | (35 | ) |  | 17 |  |
| Net unrealized loss on derivative contracts | (4 | ) |  | (4 | ) |  | (4 | ) |  | 8 |  |  | (4 | ) |
| Total other comprehensive income, before tax | 18 |  |  | 18 |  |  | 19 |  |  | (37 | ) |  | 18 |  |
| Income tax expense related to items of other comprehensive income | (6 | ) |  | (7 | ) |  | (8 | ) |  | 15 |  |  | (6 | ) |
| Other comprehensive income, net of tax | 12 |  |  | 11 |  |  | 11 |  |  | (22 | ) |  | 12 |  |
| Total comprehensive loss | $ | (354 | ) |  | $ | (4 | ) |  | $ | (216 | ) |  | $ | 220 |  |  | $ | (354 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000106040-17-000036:notes:28]
Debt

[0000106040-17-000036:notes:29]
Debt consisted of the following as of September 29, 2017 and June 30, 2017:

[0000106040-17-000036:notes:30]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,073 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,963 |  |  | 2,970 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,031 |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 13,327 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (196 | ) |  | (205 | ) |
| Subtotal | 13,131 |  |  | 13,151 |  |
| Less current portion of long-term debt | (258 | ) |  | (233 | ) |
| Long-term debt | $ | 12,873 |  |  | $ | 12,918 |  |

[0000106040-17-000036:notes:31]
| (1) | Euro Term Loan B-2 outstanding principal amounts as of September 29, 2017 and June 30, 2017 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

[0000106040-17-000036:notes:32]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of September 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-17-000036:notes:33]
Derivative Instruments and Hedging Activities

[0000106040-17-000036:notes:34]
As of September 29, 2017, the Company had outstanding foreign exchange forward contracts which were designated as either cash flow hedges or non-designated hedges. The contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding interest rate swaps which were designated as cash flow hedges. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Condensed Consolidated Financial Statements for each of the three-month periods ended September 29, 2017 and September 30, 2016.

[0000106040-17-000036:notes:35]
As of September 29, 2017, the amount of existing net gains related to cash flow hedges recorded in AOCI that are expected to be reclassified into earnings over the next twelve months was $1 million. In addition, as of September 29, 2017, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-17-000036:notes:36]
A change in the fair value of non-designated hedges is recognized in earnings in the period incurred and is reported as a component of Other expense, net. The changes in fair value on these contracts were immaterial to the Condensed Consolidated Financial Statements for each of the three-month periods ended September 29, 2017 and September 30, 2016.

[0000106040-17-000036:notes:37]
See Note 4, Fair Value Measurements and Investments, for additional disclosures related to the fair value of the Company’s foreign exchange forward contracts.

[0000106040-17-000036:notes:38]
[same as prior period, unchanged from 0000106040-17-000013:notes:78]

[0000106040-17-000036:notes:39]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of set-off associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of September 29, 2017 and June 30, 2017, the effect of rights of set-off was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.

[0000106040-17-000036:notes:40]
Effect of Derivative Contracts on the Condensed Consolidated Statements of Operations

[0000106040-17-000036:notes:41]
The impact of derivative contracts designated as hedging instruments and the total net realized transaction and foreign exchange forward contract currency gains and losses were not material to the Condensed Consolidated Financial Statements for each of the three-month periods ended September 29, 2017 and September 30, 2016.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0000106040-17-000036:notes:42]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Condensed Consolidated Statements of Operations:

[0000106040-17-000036:notes:43]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Options | $ | 7 |  |  | $ | 12 |  |
| Restricted and performance stock units | 83 |  |  | 79 |  |
| Employee stock purchase plan | 7 |  |  | 8 |  |
| Subtotal | 97 |  |  | 99 |  |
| Tax benefit | (24 | ) |  | (25 | ) |
| Total | $ | 73 |  |  | $ | 74 |  |

[0000106040-17-000036:notes:44]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Cost of revenue | $ | 13 |  |  | $ | 13 |  |
| Research and development | 44 |  |  | 44 |  |
| Selling, general and administrative | 40 |  |  | 42 |  |
| Subtotal | 97 |  |  | 99 |  |
| Tax benefit | (24 | ) |  | (25 | ) |
| Total | $ | 73 |  |  | $ | 74 |  |


## us-gaap:EarningsPerShareTextBlock

[0000106040-17-000036:notes:45]
Net Income (Loss) Per Common Share

[0000106040-17-000036:notes:46]
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-17-000036:notes:47]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 681 |  |  | $ | (366 | ) |
| Weighted average shares outstanding: |  |  |  |
| Basic | 295 |  |  | 285 |  |
| Employee stock options, RSUs, PSUs and ESPP | 11 |  |  | — |  |
| Diluted | 306 |  |  | 285 |  |
| Income (loss) per common share |  |  |  |
| Basic | $ | 2.31 |  |  | $ | (1.28 | ) |
| Diluted | $ | 2.23 |  |  | $ | (1.28 | ) |
| Anti-dilutive potential common shares excluded(1) | 2 |  |  | 5 |  |

[0000106040-17-000036:notes:48]
| (1) | For purposes of computing diluted income (loss) per common share, certain potentially dilutive securities have been excluded from the calculation because their effect would have been anti-dilutive. |

[0000106040-17-000036:notes:49]
The Company computes basic income (loss) per common share using net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-17-000036:notes:50]
[same as prior period, unchanged from 0000106040-17-000013:notes:95]

[0000106040-17-000036:notes:51]
[same as prior period, unchanged from 0000106040-17-000013:notes:96]

[0000106040-17-000036:notes:52]
[same as prior period, unchanged from 0000106040-17-000013:notes:97]

[0000106040-17-000036:notes:53]
[same as prior period, unchanged from 0000106040-17-000013:notes:98]

[0000106040-17-000036:notes:54]
[same as prior period, unchanged from 0000106040-17-000013:notes:99]

[0000106040-17-000036:notes:55]
[same as prior period, unchanged from 0000106040-17-000013:notes:100]

[0000106040-17-000036:notes:56]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of September 29, 2017 and June 30, 2017, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-17-000036:notes:57]
|  | September 29, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 3,585 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,585 |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total cash equivalents | 3,585 |  |  | 4 |  |  | — |  |  | 3,589 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Corporate notes and bonds | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Equity securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Total short-term investments | 3 |  |  | 32 |  |  | — |  |  | 35 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 6 |  |  | — |  |  | — |  |  | 6 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Asset-backed securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Municipal notes and bonds | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total long-term investments | 6 |  |  | 88 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Total assets at fair value | $ | 3,594 |  |  | $ | 143 |  |  | $ | — |  |  | $ | 3,737 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |

[0000106040-17-000036:notes:58]
|  | June 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,836 |  |
| Certificates of deposit | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total cash equivalents | 2,836 |  |  | 10 |  |  | — |  |  | 2,846 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Corporate notes and bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Equity securities | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 4 |  |  | 20 |  |  | — |  |  | 24 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |
| U.S. Government agency securities | — |  |  | 5 |  |  | — |  |  | 5 |  |
| International government securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Corporate notes and bonds | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Asset-backed securities | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Municipal notes and bonds | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total long-term investments | 5 |  |  | 89 |  |  | — |  |  | 94 |  |
| Foreign exchange contracts | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total assets at fair value | $ | 2,845 |  |  | $ | 135 |  |  | $ | — |  |  | $ | 2,980 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swap contract | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Exchange option | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 10 |  |

[0000106040-17-000036:notes:59]
During the three months ended September 29, 2017, the Company had no transfers of financial assets and liabilities between Level 1 and Level 2.

[0000106040-17-000036:notes:60]
[same as prior period, unchanged from 0000106040-17-000013:notes:117]

[0000106040-17-000036:notes:61]
The cost basis of the Company’s investments classified as available-for-sale securities, individually and in the aggregate, approximated its fair value as of September 29, 2017 and June 30, 2017. The cost basis and fair value of the Company’s investments classified as available-for-sale securities as of September 29, 2017, by remaining contractual maturity, were as follows:

[0000106040-17-000036:notes:62]
The Company determined available-for-sale securities had no material other-than-temporary impairments in the three months ended September 29, 2017 or September 30, 2016.

[0000106040-17-000036:notes:63]
[same as prior period, unchanged from 0000106040-17-000013:notes:111]

[0000106040-17-000036:notes:64]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2018 and the fourth quarter of 2017, respectively.

[0000106040-17-000036:notes:65]
|  | September 29, 2017 |  | June 30, 2017 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Secured Notes | $ | 1,835 |  |  | $ | 2,056 |  |  | $ | 1,835 |  |  | $ | 2,062 |  |
| Unsecured Notes | 3,248 |  |  | 3,939 |  |  | 3,244 |  |  | 3,956 |  |
| Term Loan A | 4,026 |  |  | 4,096 |  |  | 4,074 |  |  | 4,130 |  |
| U.S. Term Loan B-2 | 2,962 |  |  | 2,983 |  |  | 2,968 |  |  | 2,989 |  |
| Euro Term Loan B-2(1) | 1,030 |  |  | 1,039 |  |  | 1,000 |  |  | 1,010 |  |
| Convertible Debt 2020 | 30 |  |  | 34 |  |  | 30 |  |  | 34 |  |
| Total | $ | 13,131 |  |  | $ | 14,147 |  |  | $ | 13,151 |  |  | $ | 14,181 |  |

[0000106040-17-000036:notes:66]
[same as prior period, unchanged from 0000106040-17-000013:notes:114]

[0000106040-17-000036:notes:67]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. The Company reports these investments under the cost method of accounting as these investments consist of debt and equity securities of privately-held companies which do not have a readily determinable fair value. The Company assesses these securities for indications of other-than-temporary impairments. During the three months ended September 29, 2017, the Company recorded $6 million of impairment charges to Other expense, net in the Condensed Consolidated Statements of Operations. As of September 29, 2017 and June 30, 2017, these investments aggregated $57 million and $91 million, respectively, and are reported under Other non-current assets in the Condensed Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-17-000036:notes:68]
[same as prior period, unchanged from 0000106040-17-000013:notes:120]

[0000106040-17-000036:notes:69]
The following table presents the Company’s income tax expense and the effective tax rate:

[0000106040-17-000036:notes:70]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Income (loss) before taxes | $ | 710 |  |  | $ | (271 | ) |
| Income tax expense | $ | 29 |  |  | $ | 95 |  |
| Effective tax rate | 4 | % |  | (35 | )% |

[0000106040-17-000036:notes:71]
The primary drivers for the difference between the effective tax rate for the three months ended September 29, 2017 and the U.S. Federal statutory rate of 35% are windfall benefits related to vesting and exercises of stock-based awards and the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires the Company to now recognize $22 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of its income tax expense for the three months ended September 29, 2017. The windfall tax benefits for the three months ended September 30, 2016 were recorded within stockholders’ equity.

[0000106040-17-000036:notes:72]
Income tax expense for the three months ended September 30, 2016 is attributable to discrete effects consisting of income tax expense from the integration of SanDisk Corporation (“SanDisk”) of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $96 million and from decreases in the Company’s liability for unrecognized tax benefits due to lapses in the statute of limitations of $8 million. The primary drivers for the difference between the effective tax rate for the three months ended September 30, 2016 and the U.S. Federal statutory rate of 35% are these discrete items and the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-17-000036:notes:73]
During the three months ended September 29, 2017, the Company recorded no change in its liability for unrecognized tax benefits (excluding accrued interest and penalties). As of September 29, 2017, the Company’s liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $522 million. Accrued interest and penalties related to unrecognized tax benefits as of September 29, 2017 was $92 million.

[0000106040-17-000036:notes:74]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company received Revenue Agent Reports from the IRS that seek to increase the Company’s U.S. taxable income which would result in additional federal tax expense totaling $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office and received the IRS rebuttal in July 2016. Meetings with the IRS Appeals Office began in March 2017. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012.

[0000106040-17-000036:notes:75]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of September 29, 2017, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-17-000036:notes:76]
Legal Proceedings

[0000106040-17-000036:notes:77]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-17-000036:notes:78]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company’s acquisition of HGST on March 8, 2012 (the “HGST Closing Date”) and SanDisk prior to the closing of the Company’s acquisition of SanDisk on May 12, 2016 (the “SanDisk Closing Date”); “HGST” refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date; “SanDisk” refers to SanDisk Corporation or one or more of its subsidiaries as of the SanDisk Closing Date; and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST and SanDisk.

[0000106040-17-000036:notes:79]
Intellectual Property Litigation

[0000106040-17-000036:notes:80]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-17-000036:notes:81]
In May 2016, Lambeth Magnetic Structures, LLC (“Lambeth”) filed a complaint with the U.S. District Court for the Western District of Pennsylvania against WD and certain of its subsidiaries alleging infringement of U.S. Patent No. 7,128,988. The complaint seeks unspecified monetary damages and injunctive relief. The ’988 patent, entitled “Magnetic Material Structures, Devices and Methods,” allegedly relates to a magnetic material structure for hard disk drive devices. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000036:notes:82]
Antitrust

[0000106040-17-000036:notes:83]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.

[0000106040-17-000036:notes:84]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000036:notes:85]
Securities

[0000106040-17-000036:notes:86]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000036:notes:87]
Toshiba Matters

[0000106040-17-000036:notes:88]
Toshiba litigation against the Company

[0000106040-17-000036:notes:89]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court. The petition alleges that the Company has engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requests injunctive relief.

[0000106040-17-000036:notes:90]
In August 2017, the Company received a complaint filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint is based on the same allegations as the petition for provisional disposition. The Company intends to defend itself vigorously in these matters.

[0000106040-17-000036:notes:91]
SanDisk litigation against Toshiba

[0000106040-17-000036:notes:92]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, Toshiba Memory Corporation, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer. In July 2017, the Superior Court entered a stipulated order requiring Toshiba to give the SanDisk Subsidiaries at least 14 days’ advance notice of any transfer to a third party involving Toshiba’s interests in Flash Ventures, in order to ensure that the issue is preserved for arbitration. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.

[0000106040-17-000036:notes:93]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture. SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order (“TRO”), in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. On July 11, 2017, the Superior Court granted a TRO in favor of SanDisk. Toshiba filed a notice of appeal, and on July 18, 2017, the California Court of Appeal, First Appellate District, issued a temporary stay of the TRO while it reviewed Toshiba’s petition for a permanent stay of the TRO pending appeal. On July 24, 2017, SanDisk LLC amended its request for arbitration to, among other things, add Toshiba Memory Corporation as a defendant. On August 2, 2017, the Court of Appeal denied Toshiba’s petition for a permanent stay of the TRO and dissolved the temporary stay. On August 14, 2017, the Superior Court granted SanDisk’s request for a preliminary injunction. On August 18, 2017, Toshiba withdrew its appeal of the TRO, and filed a notice of appeal of the preliminary injunction. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.

[0000106040-17-000036:notes:94]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan.  The SanDisk Subsidiaries seek, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.

[0000106040-17-000036:notes:95]
Copyright

[0000106040-17-000036:notes:96]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte) (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against WD’s German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010. In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the Higher Court to determine the copyright levy issue. In May 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ in November 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain products which it sold in Germany between January 2008 and December 2010. The judgment specified levy amounts on certain products sold from January 2008 through December 2010 and directed WD Germany to disclose applicable sales data to ZPÜ. The exact amount of the judgment had not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. In March 2017, the German Federal Court of Justice rendered a judgment affirming ZPÜ’s claim concerning the disclosure of WD Germany’s sales data regarding HDDs sold between January 2008 and December 2010. The German Federal Court of Justice also set aside the Higher Court’s decision on the levy amounts and referred the case back to the Higher Court for further fact finding and decision on the levy amounts. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000036:notes:97]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. The Company intends to defend itself vigorously in this matter.

[0000106040-17-000036:notes:98]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $166 million, inclusive of amounts accrued, if it does not prevail in this matter.

[0000106040-17-000036:notes:99]
Other Matters

[0000106040-17-000036:notes:100]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company’s expectations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-17-000036:notes:101]
Recently Adopted Accounting Pronouncements

[0000106040-17-000036:notes:102]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-09, “Compensation — Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting” (“ASU 2016-09”). ASU 2016-09 simplifies several aspects of the accounting for stock-based payment transactions and states that, among other things, all excess tax benefits and tax deficiencies should be recognized as income tax expense or benefit in the income statement and an entity can make an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures when they occur. The Company adopted this standard in the first quarter of 2018 using the modified retrospective approach. This adoption resulted in a one-time net increase to beginning retained earnings of $70 million, consisting of a $58 million cumulative adjustment for the previously unrecognized windfall tax benefits related to previous vesting and exercises of stock-based awards, and a $19 million cumulative adjustment related to the change in accounting policy for estimated forfeitures and share cancellations, partially offset by a decrease of $7 million for the related tax impacts of change in forfeiture policy. In addition, under the new standard, the Company will prospectively reflect the tax deficiencies and benefits as an operating activity, rather than as a financing activity under the previous standard, in the Company’s Consolidated Statements of Cash Flows. For the three months ended September 29, 2017, the Company recognized excess tax benefits of $22 million as a component of its income tax expense.

[0000106040-17-000036:notes:103]
In July 2015, the FASB issued ASU No. 2015‑11, “Inventory (Topic 330) - Simplifying the Measurement of Inventory” (“ASU 2015‑11”), which dictates that an entity should measure inventory within the scope of this update at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company’s adoption of ASU 2015‑11 did not have a material impact on its Consolidated Financial Statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-17-000036:notes:104]
[same as prior period, unchanged from 0000106040-17-000013:notes:157]

[0000106040-17-000036:notes:105]
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese defined benefit pension plan (the “Japanese Plan”) are immaterial to the Condensed Consolidated Financial Statements. The expected long-term rate of return on the Japanese Plan assets is 2.5%.

[0000106040-17-000036:notes:106]
[same as prior period, unchanged from 0000106040-17-000013:notes:159]

[0000106040-17-000036:notes:107]
The following table presents the unfunded amounts related to the Japanese Plan as recognized on the Company’s Condensed Consolidated Balance Sheets:

[0000106040-17-000036:notes:108]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 57 |  |  | 59 |  |
| Net amount recognized | $ | 58 |  |  | $ | 60 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000106040-17-000036:notes:109]
[same as prior period, unchanged from 0000106040-17-000013:notes:162]

[0000106040-17-000036:notes:110]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Property, plant, and equipment: |  |  |  |
| Land and buildings | $ | 1,891 |  |  | $ | 1,855 |  |
| Machinery and equipment | 6,950 |  |  | 6,853 |  |
| Computer equipment and software | 420 |  |  | 405 |  |
| Furniture and fixtures | 50 |  |  | 49 |  |
| Leasehold improvements | 262 |  |  | 259 |  |
| Construction-in-process | 152 |  |  | 144 |  |
| Property, plant, and equipment, gross | 9,725 |  |  | 9,565 |  |
| Accumulated depreciation | (6,677 | ) |  | (6,532 | ) |
| Property, plant, and equipment, net | $ | 3,048 |  |  | $ | 3,033 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0000106040-17-000036:notes:111]
The following table illustrates the significant amounts of each component reclassified out of AOCI to the Condensed Consolidated Statements of Operations:

[0000106040-17-000036:notes:112]
|  |  | Three Months Ended |  |  |
| AOCI Component |  | September 29, 2017 |  | September 30, 2016 |  | Statement of Operations Line Item |
|  |  | (in millions) |  |  |
| Unrealized holding gain (loss) on designated hedging activities: |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (3 | ) |  | $ | 24 |  |  | Cost of revenue |
| Foreign exchange contracts |  | — |  |  | 2 |  |  | Research and development |
| Unrealized holding gain (loss) on designated hedging activities |  | (3 | ) |  | 26 |  |  |  |
| Total reclassifications for the period |  | $ | (3 | ) |  | $ | 26 |  |  |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-17-000036:notes:113]
[same as prior period, unchanged from 0000106040-17-000013:notes:166]

[0000106040-17-000036:notes:114]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Gains (Losses) |  | Unrealized Gains (Losses) on Available for Sale Securities |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 30, 2017 | $ | (18 | ) |  | $ | (39 | ) |  | $ | 2 |  |  | $ | (3 | ) |  | $ | (58 | ) |
| Other comprehensive income (loss) before reclassifications | — |  |  | (4 | ) |  | (1 | ) |  | 1 |  |  | (4 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Net current-period other comprehensive income (loss) | — |  |  | (4 | ) |  | (1 | ) |  | 4 |  |  | (1 | ) |
| Balance at September 29, 2017 | $ | (18 | ) |  | $ | (43 | ) |  | $ | 1 |  |  | $ | 1 |  |  | $ | (59 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000106040-17-000036:notes:115]
| Condensed Consolidating Balance Sheet |
| As of September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 265 |  |  | $ | 1,016 |  |  | $ | 5,605 |  |  | $ | — |  |  | $ | 6,886 |  |
| Short-term investments | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Accounts receivable, net | — |  |  | 1,275 |  |  | 826 |  |  | — |  |  | 2,101 |  |
| Intercompany receivables | 1,537 |  |  | 2,748 |  |  | 2,152 |  |  | (6,437 | ) |  | — |  |
| Inventories | — |  |  | 1,120 |  |  | 1,506 |  |  | (324 | ) |  | 2,302 |  |
| Other current assets | 4 |  |  | 337 |  |  | 271 |  |  | (116 | ) |  | 496 |  |
| Total current assets | 1,806 |  |  | 6,496 |  |  | 10,395 |  |  | (6,877 | ) |  | 11,820 |  |
| Property, plant and equipment, net | — |  |  | 1,118 |  |  | 1,930 |  |  | — |  |  | 3,048 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,462 |  |  | — |  |  | 1,462 |  |
| Goodwill | — |  |  | 387 |  |  | 9,686 |  |  | — |  |  | 10,073 |  |
| Other intangible assets, net | — |  |  | 48 |  |  | 3,497 |  |  | — |  |  | 3,545 |  |
| Investments in consolidated subsidiaries | 19,759 |  |  | 18,152 |  |  | — |  |  | (37,911 | ) |  | — |  |
| Loans due from consolidated affiliates | 4,400 |  |  | 16 |  |  | — |  |  | (4,416 | ) |  | — |  |
| Other non-current assets | 50 |  |  | 601 |  |  | 391 |  |  | (485 | ) |  | 557 |  |
| Total assets | $ | 26,015 |  |  | $ | 26,818 |  |  | $ | 27,361 |  |  | $ | (49,689 | ) |  | $ | 30,505 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 248 |  |  | $ | 1,818 |  |  | $ | — |  |  | $ | 2,066 |  |
| Accounts payable to related parties | — |  |  | — |  |  | 226 |  |  | — |  |  | 226 |  |
| Intercompany payables | 461 |  |  | 4,125 |  |  | 1,851 |  |  | (6,437 | ) |  | — |  |
| Accrued expenses | 394 |  |  | 416 |  |  | 461 |  |  | — |  |  | 1,271 |  |
| Accrued compensation | — |  |  | 281 |  |  | 187 |  |  | — |  |  | 468 |  |
| Accrued warranty | — |  |  | 2 |  |  | 178 |  |  | — |  |  | 180 |  |
| Current portion of long-term debt | 258 |  |  | — |  |  | — |  |  | — |  |  | 258 |  |
| Total current liabilities | 1,113 |  |  | 5,072 |  |  | 4,721 |  |  | (6,437 | ) |  | 4,469 |  |
| Long-term debt | 12,843 |  |  | — |  |  | 30 |  |  | — |  |  | 12,873 |  |
| Loans due to consolidated affiliates | — |  |  | 546 |  |  | 3,870 |  |  | (4,416 | ) |  | — |  |
| Other liabilities | — |  |  | 1,177 |  |  | 527 |  |  | (600 | ) |  | 1,104 |  |
| Total liabilities | 13,956 |  |  | 6,795 |  |  | 9,148 |  |  | (11,453 | ) |  | 18,446 |  |
| Total shareholders’ equity | 12,059 |  |  | 20,023 |  |  | 18,213 |  |  | (38,236 | ) |  | 12,059 |  |
| Total liabilities and shareholders’ equity | $ | 26,015 |  |  | $ | 26,818 |  |  | $ | 27,361 |  |  | $ | (49,689 | ) |  | $ | 30,505 |  |

[0000106040-17-000036:notes:116]
| Condensed Consolidating Balance Sheet |
| As of June 30, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 18 |  |  | $ | 1,212 |  |  | $ | 5,124 |  |  | $ | — |  |  | $ | 6,354 |  |
| Short-term investments | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Accounts receivable, net | — |  |  | 1,247 |  |  | 701 |  |  | — |  |  | 1,948 |  |
| Intercompany receivables | 1,225 |  |  | 2,528 |  |  | 622 |  |  | (4,375 | ) |  | — |  |
| Inventories | — |  |  | 1,133 |  |  | 1,494 |  |  | (286 | ) |  | 2,341 |  |
| Other current assets | 4 |  |  | 158 |  |  | 221 |  |  | 6 |  |  | 389 |  |
| Total current assets | 1,247 |  |  | 6,278 |  |  | 8,186 |  |  | (4,655 | ) |  | 11,056 |  |
| Property, plant and equipment, net | — |  |  | 1,124 |  |  | 1,909 |  |  | — |  |  | 3,033 |  |
| Notes receivable and investments in Flash Ventures | — |  |  | — |  |  | 1,340 |  |  | — |  |  | 1,340 |  |
| Goodwill | — |  |  | 331 |  |  | 9,683 |  |  | — |  |  | 10,014 |  |
| Other intangible assets, net | — |  |  | 11 |  |  | 3,812 |  |  | — |  |  | 3,823 |  |
| Investments in consolidated subsidiaries | 19,082 |  |  | 17,588 |  |  | — |  |  | (36,670 | ) |  | — |  |
| Loans due from consolidated affiliates | 4,700 |  |  | 16 |  |  | — |  |  | (4,716 | ) |  | — |  |
| Other non-current assets | 51 |  |  | 723 |  |  | 419 |  |  | (599 | ) |  | 594 |  |
| Total assets | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | — |  |  | $ | 257 |  |  | $ | 1,887 |  |  | $ | — |  |  | $ | 2,144 |  |
| Accounts payable to Flash Ventures | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Intercompany payables | 270 |  |  | 4,039 |  |  | 66 |  |  | (4,375 | ) |  | — |  |
| Accrued expenses | 270 |  |  | 360 |  |  | 439 |  |  | — |  |  | 1,069 |  |
| Accrued compensation | — |  |  | 313 |  |  | 193 |  |  | — |  |  | 506 |  |
| Accrued warranty | — |  |  | 4 |  |  | 182 |  |  | — |  |  | 186 |  |
| Current portion of long-term debt | 233 |  |  | — |  |  | — |  |  | — |  |  | 233 |  |
| Total current liabilities | 773 |  |  | 4,973 |  |  | 2,973 |  |  | (4,375 | ) |  | 4,344 |  |
| Long-term debt | 12,889 |  |  | — |  |  | 29 |  |  | — |  |  | 12,918 |  |
| Loans due to consolidated affiliates | — |  |  | 546 |  |  | 4,170 |  |  | (4,716 | ) |  | — |  |
| Other liabilities | — |  |  | 1,243 |  |  | 530 |  |  | (593 | ) |  | 1,180 |  |
| Total liabilities | 13,662 |  |  | 6,762 |  |  | 7,702 |  |  | (9,684 | ) |  | 18,442 |  |
| Total shareholders’ equity | 11,418 |  |  | 19,309 |  |  | 17,647 |  |  | (36,956 | ) |  | 11,418 |  |
| Total liabilities and shareholders’ equity | $ | 25,080 |  |  | $ | 26,071 |  |  | $ | 25,349 |  |  | $ | (46,640 | ) |  | $ | 29,860 |  |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0000106040-17-000036:notes:117]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | (6 | ) |  | $ | 145 |  |  | $ | 1,031 |  |  | $ | (37 | ) |  | $ | 1,133 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (47 | ) |  | (113 | ) |  | — |  |  | (160 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Acquisitions, net of cash acquired | — |  |  | (93 | ) |  | — |  |  | — |  |  | (93 | ) |
| Purchases of investments | — |  |  | (10 | ) |  | (28 | ) |  | — |  |  | (38 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (229 | ) |  | — |  |  | (229 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 98 |  |  | — |  |  | 98 |  |
| Strategic investments and other, net | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Advances from (to) parent and consolidated affiliates | 60 |  |  | (62 | ) |  | — |  |  | 2 |  |  | — |  |
| Net cash provided by (used in) investing activities | 60 |  |  | (212 | ) |  | (228 | ) |  | 2 |  |  | (378 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 20 |  |  | — |  |  | — |  |  | — |  |  | 20 |  |
| Taxes paid on vested stock awards under employee stock plans | (61 | ) |  | — |  |  | — |  |  | — |  |  | (61 | ) |
| Dividends paid to shareholders | (147 | ) |  | — |  |  | — |  |  | — |  |  | (147 | ) |
| Settlement of debt hedge contracts | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |
| Repayment of debt | (62 | ) |  | — |  |  | — |  |  | — |  |  | (62 | ) |
| Intercompany loan from (to) consolidated affiliates | 300 |  |  | — |  |  | (300 | ) |  | — |  |  | — |  |
| Change in investment in consolidated subsidiaries | 117 |  |  | (129 | ) |  | (23 | ) |  | 35 |  |  | — |  |
| Net cash provided by (used in) financing activities | 193 |  |  | (129 | ) |  | (323 | ) |  | 35 |  |  | (224 | ) |
| Effect of exchange rate changes on cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents | 247 |  |  | (196 | ) |  | 481 |  |  | — |  |  | 532 |  |
| Cash and cash equivalents, beginning of year | 18 |  |  | 1,212 |  |  | 5,124 |  |  | — |  |  | 6,354 |  |
| Cash and cash equivalents, end of period | $ | 265 |  |  | $ | 1,016 |  |  | $ | 5,605 |  |  | $ | — |  |  | $ | 6,886 |  |

[0000106040-17-000036:notes:118]
| Condensed Consolidating Statement of Cash Flows |
| For the three months ended September 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 181 |  |  | $ | (96 | ) |  | $ | 580 |  |  | $ | (225 | ) |  | $ | 440 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | — |  |  | (67 | ) |  | (117 | ) |  | — |  |  | (184 | ) |
| Proceeds from the sale of property, plant and equipment | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Purchases of investments | — |  |  | — |  |  | (84 | ) |  | — |  |  | (84 | ) |
| Proceeds from sale of investments | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Proceeds from maturities of investments | — |  |  | — |  |  | 54 |  |  | — |  |  | 54 |  |
| Investments in Flash Ventures | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Notes receivable issuances to Flash Ventures | — |  |  | — |  |  | (127 | ) |  | — |  |  | (127 | ) |
| Notes receivable proceeds from Flash Ventures | — |  |  | — |  |  | 120 |  |  | — |  |  | 120 |  |
| Strategic investments and other, net | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Intercompany loans from consolidated affiliates | 770 |  |  | 40 |  |  | — |  |  | (810 | ) |  | — |  |
| Advances from consolidated affiliates | 12 |  |  | 4 |  |  | 6 |  |  | (22 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 781 |  |  | (23 | ) |  | (128 | ) |  | (832 | ) |  | (202 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 24 |  |  | — |  |  | — |  |  | — |  |  | 24 |  |
| Taxes paid on vested stock awards under employee stock plans | (26 | ) |  | — |  |  | — |  |  | — |  |  | (26 | ) |
| Excess tax benefits from employee stock plans | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Proceeds from acquired call option | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Dividends paid to shareholders | (142 | ) |  | — |  |  | — |  |  | — |  |  | (142 | ) |
| Repayment of debt | (4,757 | ) |  | (2,995 | ) |  | (490 | ) |  | — |  |  | (8,242 | ) |
| Proceeds from debt | 3,992 |  |  | — |  |  | — |  |  | — |  |  | 3,992 |  |
| Debt issuance costs | (7 | ) |  | — |  |  | — |  |  | — |  |  | (7 | ) |
| Intercompany loan from (to) consolidated affiliates | — |  |  | (5,966 | ) |  | 5,156 |  |  | 810 |  |  | — |  |
| Change in investment in consolidated subsidiaries | 192 |  |  | 8,697 |  |  | (9,136 | ) |  | 247 |  |  | — |  |
| Net cash used in financing activities | (696 | ) |  | (264 | ) |  | (4,409 | ) |  | 1,057 |  |  | (4,312 | ) |
| Net increase (decrease) in cash and cash equivalents | 266 |  |  | (383 | ) |  | (3,957 | ) |  | — |  |  | (4,074 | ) |
| Cash and cash equivalents, beginning of year | — |  |  | 1,206 |  |  | 6,945 |  |  | — |  |  | 8,151 |  |
| Cash and cash equivalents, end of period | $ | 266 |  |  | $ | 823 |  |  | $ | 2,988 |  |  | $ | — |  |  | $ | 4,077 |  |


## us-gaap:ScheduleOfCondensedFinancialStatementsTableTextBlock

[0000106040-17-000036:notes:119]
[same as prior period, unchanged from 0000106040-17-000013:notes:172]

[0000106040-17-000036:notes:120]
The Company’s 10.500% senior unsecured notes due 2024 (“Unsecured Notes”) are fully and unconditionally guaranteed, jointly and severally, on a senior unsecured basis, subject to certain customary guarantor release conditions, by the WD Guarantors (or the “Guarantor Subsidiaries”). The guarantee by a Guarantor Subsidiary will be released in the event of (i) the designation of a Guarantor Subsidiary as an unrestricted subsidiary under the indenture governing the Unsecured Notes, (ii) the release of a Guarantor Subsidiary from its guarantee of indebtedness under the Credit Agreement or other indebtedness that would have required the Guarantor Subsidiary to guarantee the Unsecured Notes, (iii) the sale, issuance or other disposition of capital stock of a Guarantor Subsidiary such that it is no longer a restricted subsidiary under the indenture governing the Unsecured Notes, (iv) the sale of all or substantially all of a Guarantor Subsidiary’s assets, (v) the Company’s exercise of its defeasance options under the indenture governing the Unsecured Notes, (vi) the dissolution or liquidation of a Guarantor Subsidiary or (vii) the sale of all the equity interest in a Guarantor Subsidiary. The Company’s other domestic subsidiaries and its foreign subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) do not guarantee the Unsecured Notes. The following condensed consolidating financial information reflects the summarized financial information of Western Digital Corporation (“Parent”), the Guarantor Subsidiaries on a combined basis, and the Non-Guarantor Subsidiaries on a combined basis.

[0000106040-17-000036:notes:121]
For more information regarding the Unsecured Notes, refer to Note 6, Debt.

[0000106040-17-000036:notes:122]
| Condensed Consolidating Statement of Operations |
| For the three months ended September 29, 2017 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,710 |  |  | $ | 5,081 |  |  | $ | (3,610 | ) |  | $ | 5,181 |  |
| Cost of revenue | — |  |  | 3,200 |  |  | 3,647 |  |  | (3,579 | ) |  | 3,268 |  |
| Gross profit | — |  |  | 510 |  |  | 1,434 |  |  | (31 | ) |  | 1,913 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 381 |  |  | 211 |  |  | — |  |  | 592 |  |
| Selling, general and administrative | 2 |  |  | 258 |  |  | 104 |  |  | — |  |  | 364 |  |
| Intercompany operating expense (income) | — |  |  | (400 | ) |  | 400 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 11 |  |  | 41 |  |  | — |  |  | 52 |  |
| Total operating expenses | 2 |  |  | 250 |  |  | 756 |  |  | — |  |  | 1,008 |  |
| Operating income (loss) | (2 | ) |  | 260 |  |  | 678 |  |  | (31 | ) |  | 905 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 81 |  |  | 2 |  |  | 14 |  |  | (81 | ) |  | 16 |  |
| Interest expense | (204 | ) |  | (6 | ) |  | (76 | ) |  | 81 |  |  | (205 | ) |
| Other income (expense), net | (8 | ) |  | 11 |  |  | (9 | ) |  | — |  |  | (6 | ) |
| Total interest and other income (expense), net | (131 | ) |  | 7 |  |  | (71 | ) |  | — |  |  | (195 | ) |
| Income (loss) before taxes | (133 | ) |  | 267 |  |  | 607 |  |  | (31 | ) |  | 710 |  |
| Income tax expense (benefit) | (57 | ) |  | 54 |  |  | 32 |  |  | — |  |  | 29 |  |
| Equity in earnings from subsidiaries | 757 |  |  | 592 |  |  | — |  |  | (1,349 | ) |  | — |  |
| Net income | $ | 681 |  |  | $ | 805 |  |  | $ | 575 |  |  | $ | (1,380 | ) |  | $ | 681 |  |

[0000106040-17-000036:notes:123]
| Condensed Consolidating Statement of Operations |
| For the three months ended September 30, 2016 |
|  | Parent |  | Guarantor Subsidiaries |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Total Company |
|  | (in millions) |
| Revenue, net | $ | — |  |  | $ | 3,698 |  |  | $ | 4,293 |  |  | $ | (3,277 | ) |  | $ | 4,714 |  |
| Cost of revenue | — |  |  | 3,065 |  |  | 3,553 |  |  | (3,239 | ) |  | 3,379 |  |
| Gross profit | — |  |  | 633 |  |  | 740 |  |  | (38 | ) |  | 1,335 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | — |  |  | 441 |  |  | 198 |  |  | — |  |  | 639 |  |
| Selling, general and administrative | 1 |  |  | 274 |  |  | 121 |  |  | — |  |  | 396 |  |
| Intercompany operating expense (income) | — |  |  | (351 | ) |  | 351 |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other charges | — |  |  | 49 |  |  | 19 |  |  | — |  |  | 68 |  |
| Total operating expenses | 1 |  |  | 413 |  |  | 689 |  |  | — |  |  | 1,103 |  |
| Operating income (loss) | (1 | ) |  | 220 |  |  | 51 |  |  | (38 | ) |  | 232 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 94 |  |  | 1 |  |  | 7 |  |  | (97 | ) |  | 5 |  |
| Interest expense | (228 | ) |  | (5 | ) |  | (100 | ) |  | 97 |  |  | (236 | ) |
| Other income (expense), net | (272 | ) |  | 1 |  |  | (1 | ) |  | — |  |  | (272 | ) |
| Total interest and other expense, net | (406 | ) |  | (3 | ) |  | (94 | ) |  | — |  |  | (503 | ) |
| Income (loss) before taxes | (407 | ) |  | 217 |  |  | (43 | ) |  | (38 | ) |  | (271 | ) |
| Income tax expense (benefit) | (94 | ) |  | 5 |  |  | 184 |  |  | — |  |  | 95 |  |
| Equity in earnings from subsidiaries | (53 | ) |  | (227 | ) |  | — |  |  | 280 |  |  | — |  |
| Net loss | $ | (366 | ) |  | $ | (15 | ) |  | $ | (227 | ) |  | $ | 242 |  |  | $ | (366 | ) |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000106040-17-000036:notes:124]
Intangible assets

[0000106040-17-000036:notes:125]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,193 |  |  | $ | 5,160 |  |
| In-process research and development | 703 |  |  | 696 |  |
| Accumulated amortization | (2,351 | ) |  | (2,033 | ) |
| Intangible assets, net | $ | 3,545 |  |  | $ | 3,823 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000106040-17-000036:notes:126]
[same as prior period, unchanged from 0000106040-17-000013:notes:179]

[0000106040-17-000036:notes:127]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 30, 2017 | $ | 10,014 |  |
| Goodwill recorded in connection with acquisitions | 59 |  |
| Balance at September 29, 2017 | $ | 10,073 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000106040-17-000036:notes:128]
[same as prior period, unchanged from 0000106040-17-000013:notes:183]

[0000106040-17-000036:notes:129]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 650 |  |  | $ | 646 |  |
| Work-in-process | 682 |  |  | 632 |  |
| Finished goods | 970 |  |  | 1,063 |  |
| Total inventories | $ | 2,302 |  |  | $ | 2,341 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-17-000036:notes:130]
[same as prior period, unchanged from 0000106040-17-000013:notes:185]

[0000106040-17-000036:notes:131]
[same as prior period, unchanged from 0000106040-17-000013:notes:186]

[0000106040-17-000036:notes:132]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 311 |  |  | $ | 279 |  |
| Charges to operations | 44 |  |  | 47 |  |
| Utilization | (38 | ) |  | (45 | ) |
| Changes in estimate related to pre-existing warranties | (15 | ) |  | (4 | ) |
| Warranty accrual, end of period | $ | 302 |  |  | $ | 277 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-17-000036:notes:133]
The Company recorded the following charges related to employee terminations benefits, asset impairment, and other charges:

[0000106040-17-000036:notes:134]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |
| Restructuring Plan 2016 | $ | 45 |  |  | $ | 27 |  |
| Closure of Foreign Manufacturing Facility | — |  |  | 4 |  |
| Business Realignment | 7 |  |  | 37 |  |
| Total employee termination and other charges | $ | 52 |  |  | $ | 68 |  |

[0000106040-17-000036:notes:135]
The following table presents an analysis of the components of the activity against the reserve:

[0000106040-17-000036:notes:136]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 18 |  |  | $ | 5 |  |  | $ | 23 |  |
| Charges | 4 |  |  | 3 |  |  | 7 |  |
| Cash payments | (4 | ) |  | (1 | ) |  | (5 | ) |
| Accrual balance at September 29, 2017 | $ | 18 |  |  | $ | 7 |  |  | $ | 25 |  |

[0000106040-17-000036:notes:137]
The following table presents an analysis of the components of the activity against the reserve during the three months ended September 29, 2017:

[0000106040-17-000036:notes:138]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2017 | $ | 11 |  |  | $ | 2 |  |  | $ | 13 |  |
| Charges | 36 |  |  | 9 |  |  | 45 |  |
| Cash payments | (8 | ) |  | (6 | ) |  | (14 | ) |
| Accrual balance at September 29, 2017 | $ | 39 |  |  | $ | 5 |  |  | $ | 44 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000106040-17-000036:notes:139]
[same as prior period, unchanged from 0000106040-17-000013:notes:194]

[0000106040-17-000036:notes:140]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 30, 2017 | 7.4 |  |  | $ | 58.14 |  |  |  |  |  |
| Exercised | (0.5 | ) |  | 41.12 |  |  |  |  | $ | 21 |  |
| Canceled or expired | (0.1 | ) |  | 71.99 |  |  |  |  |  |
| Options outstanding at September 29, 2017 | 6.8 |  |  | $ | 59.06 |  |  | 4.3 |  | $ | 204 |  |
| Exercisable at September 29, 2017 | 3.8 |  |  | $ | 61.96 |  |  | 3.4 |  | $ | 106 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0000106040-17-000036:notes:141]
[same as prior period, unchanged from 0000106040-17-000013:notes:196]

[0000106040-17-000036:notes:142]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 30, 2017 | 13.7 |  |  | $ | 45.01 |  |  |  |
| Granted | 3.7 |  |  | 83.05 |  |  |  |
| Vested | (2.1 | ) |  | 55.51 |  |  | $ | 182 |  |
| Forfeited | (0.3 | ) |  | 45.17 |  |  |  |
| RSUs and PSUs outstanding at September 29, 2017 | 15.0 |  |  | $ | 52.67 |  |  |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-17-000036:notes:143]
[same as prior period, unchanged from 0000106040-17-000013:notes:198]

[0000106040-17-000036:notes:144]
[same as prior period, unchanged from 0000106040-17-000013:notes:199]

[0000106040-17-000036:notes:145]
Compensation cost related to unvested stock options, restricted stock unit awards (“RSU”), performance-based restricted stock unit awards (“PSU”) and the Company’s Employee Stock Purchase Plan (“ESPP”) will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of September 29, 2017.

[0000106040-17-000036:notes:146]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| Options | $ | 46 |  |  | 2.3 |
| RSUs and PSUs (1) | 662 |  |  | 2.4 |
| ESPP | 23 |  |  | 0.7 |
| Total unamortized compensation cost | $ | 731 |  |  |  |

[0000106040-17-000036:notes:147]
(1) Weighted average service period assumes the performance metrics are met for the PSUs.

[0000106040-17-000036:notes:148]
Plan Activities

[0000106040-17-000036:notes:149]
Stock Options

[0000106040-17-000036:notes:150]
RSU and PSU

[0000106040-17-000036:notes:151]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-17-000036:notes:152]
[same as prior period, unchanged from 0000106040-17-000013:notes:210]

[0000106040-17-000036:notes:153]
The Company’s Board of Directors (the “Board”) has authorized $5.00 billion for the repurchase of the Company’s common stock. The stock repurchase program is effective until February 3, 2020. The Company did not repurchase any shares of common stock during the three months ended September 29, 2017. The remaining amount available to be purchased under the Company’s stock repurchase program as of September 29, 2017 was $2.10 billion.

[0000106040-17-000036:notes:154]
[same as prior period, unchanged from 0000106040-17-000013:notes:212]

[0000106040-17-000036:notes:155]
On September 13, 2012, the Company announced that the Board had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Board.

[0000106040-17-000036:notes:156]
On August 2, 2017, the Board declared a cash dividend of $0.50 per share of the Company’s common stock. The cash dividend aggregating $148 million was paid on October 16, 2017 to the Company’s shareholders of record as of September 29, 2017. On November 1, 2017, the Board declared a cash dividend of $0.50 per share to shareholders of record as of December 29, 2017, which will be paid on January 16, 2018. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-17-000036:notes:157]
[same as prior period, unchanged from 0000106040-17-000013:notes:217]

[0000106040-17-000036:notes:158]
On September 15, 2017, the Company acquired substantially all the assets of Tegile Systems, Inc., a provider of flash and persistent-memory storage solutions for enterprise data center applications. On August 25, 2017, the Company acquired substantially all the assets of Upthere, Inc., a cloud services company. These acquisitions are primarily intended to help meet the evolving needs of customers, while driving long-term growth for the Company's existing data center and client solution products over the long term.

[0000106040-17-000036:notes:159]
The aggregate purchase price of these acquisitions was $93 million in cash, with net assets acquired primarily consisting of developed technology and other intangibles assets, of which $59 million was allocated to goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings to its Data Center Devices and Solutions, and Client Solutions end markets and the acquired workforce. Goodwill is expected to be deductible for tax purposes because the acquisitions were structured as asset acquisitions but accounted for as business combinations. Concurrent with these acquisitions, the Company received $36 million in proceeds on previously outstanding notes receivable due from these acquired entities.

[0000106040-17-000036:notes:160]
During the period, the Company incurred $4 million of transaction expenses related to these acquisitions, which are primarily included within Selling, General and Administrative expenses in the Condensed Consolidated Statements of Operations. Revenues and earnings related to these acquisitions was not material.

[0000106040-17-000036:notes:161]
The long-term portion of the warranty accrual classified in Other liabilities was $122 million and $125 million as of September 29, 2017 and June 30, 2017, respectively.

[0000106040-17-000036:notes:162]
[same as prior period, unchanged from 0000106040-17-000013:notes:223]

[0000106040-17-000036:notes:163]
[same as prior period, unchanged from 0000106040-17-000013:notes:224]

[0000106040-17-000036:notes:164]
During the three months ended September 29, 2017, there were no material reclassifications out of OCI. The following table illustrates the significant amounts of each component reclassified out of AOCI to the Condensed Consolidated Statements of Operations:


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-17-000036:notes:165]
[same as prior period, unchanged from 0000106040-17-000013:notes:225]

[0000106040-17-000036:notes:166]
[same as prior period, unchanged from 0000106040-17-000013:notes:226]

[0000106040-17-000036:notes:167]
In 2016, the Company initiated a set of actions relating to the restructuring plan associated with the integration of substantial portions of its HGST and WD subsidiaries (“Restructuring Plan 2016”). Restructuring Plan 2016 consists of asset and footprint reduction, product road map consolidation and organization rationalization. In addition to the amounts recognized under Restructuring Plan 2016 as presented above, the Company recognized $5 million and $26 million of accelerated depreciation on facility assets in cost of revenue during the three months ended September 29, 2017 and September 30, 2016, respectively. The Company expects Restructuring Plan 2016 to be substantially completed by the end of calendar year 2017.

[0000106040-17-000036:notes:168]
[same as prior period, unchanged from 0000106040-17-000013:notes:230]

[0000106040-17-000036:notes:169]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The following table presents an analysis of the components of the activity against the reserve:


## wdc:OrganizationandBasisofPresentationTextBlock

[0000106040-17-000036:notes:170]
Organization and Basis of Presentation

[0000106040-17-000036:notes:171]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”) which is included in each of these three categories.

[0000106040-17-000036:notes:172]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-17-000036:notes:173]
Fiscal Year

[0000106040-17-000036:notes:174]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2018, which ends on June 29, 2018, and 2017, which ended on June 30, 2017, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-17-000036:notes:175]
Use of Estimates

[0000106040-17-000036:notes:176]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.
