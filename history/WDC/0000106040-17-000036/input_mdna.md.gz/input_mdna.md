# WDC MD&A — 0000106040-17-000036


## mdna

[0000106040-17-000036:mdna:1]
[same as prior period, unchanged from 0000106040-17-000013:mdna:1]

[0000106040-17-000036:mdna:2]
[same as prior period, unchanged from 0000106040-17-000013:mdna:2]

[0000106040-17-000036:mdna:3]
[same as prior period, unchanged from 0000106040-17-000013:mdna:3]

[0000106040-17-000036:mdna:4]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. Our broad portfolio of technology and products address the following key markets: Data Center Devices and Solutions; Client Devices; and Client Solutions. We also generate license and royalty revenue related to our intellectual property (“IP”), which is included in each of these three categories.

[0000106040-17-000036:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2018, which ends on June 29, 2018, and 2017, which ended on June 30, 2017, are both comprised 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-17-000036:mdna:6]
Key Developments

[0000106040-17-000036:mdna:7]
Ventures with Toshiba

[0000106040-17-000036:mdna:8]
Through our strategic partnership with Toshiba Corporation (“Toshiba”), which consists of three separate legal entities: Flash Partners Ltd., Flash Alliance Ltd. and Flash Forward Ltd., collectively referred to as “Flash Ventures”, we and Toshiba currently operate three business ventures in 300-millimeter NAND-flash manufacturing facilities in Yokkaichi, Japan, which provide us leading-edge, cost-competitive NAND wafers for our end products. We are committed to the success of Flash Ventures and we intend to, and have been engaged in discussions with Toshiba to, jointly invest in a new wafer fab in Yokkaichi, Japan, to provide additional cleanroom space to support the continued conversion of 2D NAND capacity to 3D NAND, which we refer to as Fab 6.

[0000106040-17-000036:mdna:9]
Toshiba has announced significant losses related to its U.S. nuclear business and substantial doubt about its ability to continue as a going concern. Due to Toshiba’s financial condition, Toshiba’s working capital and access to credit and capital markets are severely limited. Toshiba could become unable to, or otherwise fail to, timely fund investments in Flash Ventures or our joint development efforts or fulfill its payment obligations to suppliers, which could harm Flash Ventures’ operations, our joint technology roadmap and supplier relationships. On September 28, 2017, Toshiba announced it had entered into a definitive agreement to sell its memory business, including its interest in Flash Ventures, to a consortium led by SK Hynix Inc. and Bain Capital that includes other competitors, as well as key customers.  We have asserted our consent rights under the terms of the Flash Ventures agreements with respect to the transactions involving, among other things, the transfer of Toshiba’s interests in Flash Ventures. See Part I, Item 1, Note 13, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for a further discussion of these proceedings and other actions. For a discussion of risks associated with our business ventures with Toshiba, see Part II, Item 1A, Risk Factors, of this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:10]
39

[0000106040-17-000036:mdna:11]
[same as prior period, unchanged from 0000106040-17-000013:mdna:15]

[0000106040-17-000036:mdna:12]
First Quarter Overview

[0000106040-17-000036:mdna:13]
The following table sets forth, for the periods presented, selected summary information from our Condensed Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-17-000036:mdna:14]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 5,181 |  |  | 100.0 | % |  | $ | 4,714 |  |  | 100.0 | % |  | 10 | % |
| Cost of revenue | 3,268 |  |  | 63.1 |  |  | 3,379 |  |  | 71.7 |  |  | (3 | ) |
| Gross profit | 1,913 |  |  | 36.9 |  |  | 1,335 |  |  | 28.3 |  |  | 43 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 592 |  |  | 11.4 |  |  | 639 |  |  | 13.6 |  |  | (7 | ) |
| Selling, general and administrative | 364 |  |  | 7.0 |  |  | 396 |  |  | 8.4 |  |  | (8 | ) |
| Employee termination, asset impairment, and other charges | 52 |  |  | 1.0 |  |  | 68 |  |  | 1.4 |  |  | (24 | ) |
| Total operating expenses | 1,008 |  |  | 19.5 |  |  | 1,103 |  |  | 23.4 |  |  | (9 | ) |
| Operating income | 905 |  |  | 17.5 |  |  | 232 |  |  | 4.9 |  |  | 290 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 16 |  |  | 0.3 |  |  | 5 |  |  | 0.1 |  |  | 220 |  |
| Interest expense | (205 | ) |  | (4.0 | ) |  | (236 | ) |  | (5.0 | ) |  | (13 | ) |
| Other expense, net | (6 | ) |  | (0.1 | ) |  | (272 | ) |  | (5.8 | ) |  | (98 | ) |
| Total interest and other expense, net | (195 | ) |  | (3.8 | ) |  | (503 | ) |  | (10.7 | ) |  | (61 | ) |
| Income (loss) before taxes | 710 |  |  | 13.7 |  |  | (271 | ) |  | (5.7 | ) |  | (362 | ) |
| Income tax expense | 29 |  |  | 0.6 |  |  | 95 |  |  | 2.0 |  |  | (69 | ) |
| Net income (loss) | $ | 681 |  |  | 13.1 |  |  | $ | (366 | ) |  | (7.8 | ) |  | (286 | ) |

[0000106040-17-000036:mdna:15]
[same as prior period, unchanged from 0000106040-17-000013:mdna:36]

[0000106040-17-000036:mdna:16]
40

[0000106040-17-000036:mdna:17]
[same as prior period, unchanged from 0000106040-17-000013:mdna:19]

[0000106040-17-000036:mdna:18]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions, except exabytes and percentages) |
| Revenue, net | $ | 5,181 |  |  | $ | 4,714 |  |
| Revenues by Geography (%) (1) |  |  |  |
| Americas | 26 | % |  | 26 | % |
| Europe, Middle East and Africa | 18 |  |  | 17 |  |
| Asia | 56 |  |  | 57 |  |
| Revenues by End Market (%) |  |  |  |
| Client Devices | 52 | % |  | 50 | % |
| Data Center Devices & Solutions | 26 |  |  | 29 |  |
| Client Solutions | 22 |  |  | 21 |  |
| Exabytes Shipped | 87 |  |  | 80 |  |

[0000106040-17-000036:mdna:19]
| (1) | Percentages for the prior year have been revised to conform to the current year presentation. |

[0000106040-17-000036:mdna:20]
Net Revenue.

[0000106040-17-000036:mdna:21]
Net revenue for the three months ended September 29, 2017 increased $467 million, or 10%, as compared to the same period in the prior year, reflecting a favorable demand environment and growth of our diversified product portfolio. Client Devices revenue increased 13% year-over-year, primarily driven by significant growth in embedded flash-based products and client solid state drives (“SSD”). Our revenue for Data Center Devices and Solutions was relatively flat year-over-year driven primarily by an increase in sales from our capacity enterprise hard disk drives (“HDD”) and enterprise SSD, partially offset by an expected decline in sales from our performance enterprise HDDs. Client Solutions revenue increased 16% year-over-year, primarily from our global retail brands in removable flash and other flash-based products.

[0000106040-17-000036:mdna:22]
For each of the three-month periods ended September 29, 2017 and September 30, 2016, no customer accounted for 10% or more of our net revenue. For the three months ended September 29, 2017 and September 30, 2016, our top 10 customers accounted for 42% and 43% of our net revenue, respectively.

[0000106040-17-000036:mdna:23]
Changes in the net revenue by geography generally reflect normal fluctuations in market demand and competitive dynamics.

[0000106040-17-000036:mdna:24]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three months ended September 29, 2017 and September 30, 2016, these programs represented 8% and 13% of gross revenues, respectively. The decrease in sales incentive and marketing programs year-over-year reflects lower incentive programs offered primarily due to increased demand for our products. The amounts attributed to our sales incentive and marketing programs also generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-17-000036:mdna:25]
Gross Profit and Gross Margin.

[0000106040-17-000036:mdna:26]
Gross profit for the three months ended September 29, 2017 increased $578 million, or 43%, as compared to the same period in the prior year. Gross margin was 36.9% for the three months ended September 29, 2017, as compared to 28.3% for the same period in the prior year. The increase in gross margin was primarily due to a favorable demand environment for flash-based products, improvements in our production costs from technology transitions and a higher mix of flash-based product revenue. Gross profit was negatively impacted by amortization expense on acquired intangible assets, stock-based compensation, charges related to the implementation of cost-saving initiatives and other charges, which aggregated $279 million, or 5.4%, of revenue, for the three months ended September 29, 2017, and $251 million, or 5.3%, of revenue, for the three months ended September 30, 2016.

[0000106040-17-000036:mdna:27]
[same as prior period, unchanged from 0000106040-17-000013:mdna:34]

[0000106040-17-000036:mdna:28]
Research and development (“R&D”) expense for the three months ended September 29, 2017 decreased $47 million, or 7%, from the same period in the prior year, primarily due to the synergies from the integration of development activities across the combined companies and lower variable compensation. The three months ended September 29, 2017 also included aggregate charges of $47 million related to stock-based compensation expenses, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $53 million for the three months ended September 30, 2016 related to such charges.

[0000106040-17-000036:mdna:29]
Selling, general and administrative (“SG&A”) expense for the three months ended September 29, 2017 decreased $32 million, or 8%, from the same period in the prior year, primarily due to lower variable compensation partially offset by higher costs related to our recent acquisitions and legal expenses. The three months ended September 29, 2017 also included aggregate charges of $90 million related to stock-based compensation expenses, amortization expense on acquired intangible assets, charges related to the implementation of cost-saving initiatives, acquisition-related charges and other discrete charges, compared to $119 million for the three months ended September 30, 2016 related to such charges.

[0000106040-17-000036:mdna:30]
Employee termination and other charges for the three months ended September 29, 2017 decreased $16 million, or 24%, from the same period in the prior year. The charges in 2017 primarily related to further actions associated with the integration and business realignment of substantial portions of our business. For additional information regarding employee termination, asset impairment and other charges, see Part I, Item 1, Note 12, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:31]
[same as prior period, unchanged from 0000106040-17-000013:mdna:40]

[0000106040-17-000036:mdna:32]
Total interest and other expense, net for the three months ended September 29, 2017 decreased $308 million from the same period in the prior year, primarily due to the loss on extinguishment of debt of $266 million recognized in the prior year, lower interest expense of $31 million resulting from reductions in the principal amount of debt and lower interest rates on our current term loans, and higher interest income of $11 million related to increased investments.

[0000106040-17-000036:mdna:33]
[same as prior period, unchanged from 0000106040-17-000013:mdna:47]

[0000106040-17-000036:mdna:34]
The following table sets forth income tax information from our Consolidated Statement of Operations by dollar and effective tax rate.

[0000106040-17-000036:mdna:35]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions, except percentages) |
| Income (loss) before taxes | $ | 710 |  |  | $ | (271 | ) |
| Income tax expense | 29 |  |  | 95 |  |
| Effective tax rate | 4 | % |  | (35 | )% |

[0000106040-17-000036:mdna:36]
Income tax expense was $29 million for the three months ended September 29, 2017, as compared to $95 million for the three months ended September 30, 2016. Income tax expense as a percentage of income before taxes was 4% for the three months ended September 29, 2017, as compared to negative 35% in the prior year period.

[0000106040-17-000036:mdna:37]
The primary drivers for the difference between the effective tax rate for the three months ended September 29, 2017 and the U.S. Federal statutory rate of 35% are windfall benefits related to vesting and exercises of stock-based awards and the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030. The windfall tax benefits are a result of the adoption of ASU 2016-09, which requires the Company to now recognize $22 million of windfall tax benefits related to vesting and exercises of stock-based awards as a component of its income tax expense for the three months ended September 29, 2017. The windfall tax benefits for the three months ended September 30, 2016 were recorded within stockholders’ equity.

[0000106040-17-000036:mdna:38]
Income tax expense for the three months ended September 30, 2016 is attributable to discrete effects consisting of income tax expense from the integration of SanDisk of $90 million and a valuation allowance on acquired tax attributes of $109 million, partially offset by income tax benefit from deductible debt issuance costs, debt discounts and prepayment fees from the debt extinguishment of $96 million and from decreases in our liability for unrecognized tax benefits due to lapses in the statute of limitations of $8 million. The primary drivers for the difference between the effective tax rate for the three months ended September 30, 2016 and the U.S. Federal statutory rate of 35% are these discrete items and the current year generation of tax credits and tax holidays in Malaysia, Philippines, Singapore and Thailand that expire at various dates during fiscal years 2018 through 2030.

[0000106040-17-000036:mdna:39]
For additional information regarding income tax expense (benefit), see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:40]
43

[0000106040-17-000036:mdna:41]
[same as prior period, unchanged from 0000106040-17-000013:mdna:53]

[0000106040-17-000036:mdna:42]
The following table summarizes our statements of cash flows:

[0000106040-17-000036:mdna:43]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 1,133 |  |  | $ | 440 |  |
| Investing activities | (378 | ) |  | (202 | ) |
| Financing activities | (224 | ) |  | (4,312 | ) |
| Effect of exchange rate changes on cash | 1 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | 532 |  |  | $ | (4,074 | ) |

[0000106040-17-000036:mdna:44]
We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:45]
During 2018, we expect cash used for purchases of property, plant and equipment and net activity in notes receivable and equity investments relating to Flash Ventures to be approximately $1.50 billion to $1.90 billion. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-17-000036:mdna:46]
A total of $5.49 billion and $4.99 billion of our cash and cash equivalents was held outside of the U.S. as of September 29, 2017 and June 30, 2017, respectively. Our current plans anticipate we can meet our U.S. cash needs while continuing to permanently reinvest the undistributed earnings of our foreign subsidiaries. In the event the reinvested earnings of our foreign subsidiaries are distributed to the U.S., such a distribution could result in the accrual and payment of additional U.S. taxes.

[0000106040-17-000036:mdna:47]
[same as prior period, unchanged from 0000106040-17-000013:mdna:60]

[0000106040-17-000036:mdna:48]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in other operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in other operating assets and liabilities was $236 million for the three months ended September 29, 2017, as compared to net cash used for changes in other operating assets and liabilities of $205 million for the three months ended September 30, 2016.

[0000106040-17-000036:mdna:49]
Changes in our other operating assets and liabilities is largely affected by our working capital requirements which is dependent on the effective management of our cash conversion cycle.  Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-17-000036:mdna:50]
|  | Three Months Ended |
|  | September 29, 2017 |  | September 30, 2016 |
|  | (in days) |
| Days sales outstanding | 37 |  |  | 39 |  |
| Days in inventory | 64 |  |  | 57 |  |
| Days payables outstanding | (64 | ) |  | (58 | ) |
| Cash conversion cycle | 37 |  |  | 38 |  |

[0000106040-17-000036:mdna:51]
Changes in days sales outstanding (“DSOs”) are generally due to the linearity of shipments. Changes in days in inventory (“DIOs”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPOs”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-17-000036:mdna:52]
For the three months ended September 29, 2017, DSO decreased by 2 days over the prior year, primarily reflecting routine variations in the timing of customer receipts. DIO increased by 7 days over the prior year, primarily reflecting short-term build-up of inventory to maintain supply as we close certain facilities and transition production. DPO increased by 6 days over the prior year, primarily reflecting routine variations in timing of purchases and payments during the period.

[0000106040-17-000036:mdna:53]
[same as prior period, unchanged from 0000106040-17-000013:mdna:65]

[0000106040-17-000036:mdna:54]
Net cash used in investing activities for the three months ended September 29, 2017 primarily consisted of $160 million of capital expenditures, a net $131 million increase in notes receivable issuances to and investments in Flash Ventures, and $93 million for acquisitions. Net cash used in investing activities for the three months ended September 30, 2016 primarily consisted of $184 million of capital expenditures and a $27 million net increase in notes receivable issuances to Flash Ventures.

[0000106040-17-000036:mdna:55]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit. In addition, we invest directly in U.S. Treasury securities, U.S. and International Government agency securities, certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-17-000036:mdna:56]
[same as prior period, unchanged from 0000106040-17-000013:mdna:68]

[0000106040-17-000036:mdna:57]
Net cash used in financing activities for the three months ended September 29, 2017 primarily consisted of $147 million to pay dividends on our common stock, $62 million to repay debt, and a net $41 million used for employee stock plans, partially offset by proceeds of $26 million from the settlement of debt hedge contracts.  Net cash used in financing activities for the three months ended September 30, 2016 consisted of $8.24 billion to repay debt, $142 million to pay dividends on our common stock, partially offset by $3.99 billion of proceeds from debt, net of issuance costs, $61 million of proceeds from call options, and a net $26 million provided by employee stock plans.

[0000106040-17-000036:mdna:58]
[same as prior period, unchanged from 0000106040-17-000013:mdna:70]

[0000106040-17-000036:mdna:59]
Other than the commitments related to Flash Ventures, facility lease commitments incurred in the normal course of business and certain indemnification provisions (see “Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any special-purpose entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:60]
[same as prior period, unchanged from 0000106040-17-000013:mdna:73]

[0000106040-17-000036:mdna:61]
[same as prior period, unchanged from 0000106040-17-000013:mdna:74]

[0000106040-17-000036:mdna:62]
The following is a summary of our known contractual cash obligations and commercial commitments as of September 29, 2017:

[0000106040-17-000036:mdna:63]
|  | Total |  | 1 Year (Remaining 9 months of 2018) |  | 2-3 Years (2019-2020) |  | 4-5 Years (2021-2022) |  | More than 5 Years (Beyond 2022) |
|  | (in millions) |
| Long-term debt, including current portion | $ | 13,327 |  |  | $ | 185 |  |  | $ | 803 |  |  | $ | 3,279 |  |  | $ | 9,060 |  |
| Interest on debt | 4,253 |  |  | 570 |  |  | 1,498 |  |  | 1,346 |  |  | 839 |  |
| Flash Ventures and other related commitments(1) | 7,146 |  |  | 2,581 |  |  | 2,678 |  |  | 1,473 |  |  | 414 |  |
| Operating leases | 176 |  |  | 40 |  |  | 78 |  |  | 40 |  |  | 18 |  |
| Purchase obligations | 1,791 |  |  | 1,726 |  |  | 65 |  |  | — |  |  | — |  |
| Total | $ | 26,693 |  |  | $ | 5,102 |  |  | $ | 5,122 |  |  | $ | 6,138 |  |  | $ | 10,331 |  |

[0000106040-17-000036:mdna:64]
[same as prior period, unchanged from 0000106040-17-000013:mdna:77]

[0000106040-17-000036:mdna:65]
[same as prior period, unchanged from 0000106040-17-000013:mdna:78]

[0000106040-17-000036:mdna:66]
See Part I, Item 1, Note 6, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms.

[0000106040-17-000036:mdna:67]
Interest Rate Swap

[0000106040-17-000036:mdna:68]
We have entered into interest rate swap agreements to moderate our exposure to fluctuations in interest rates underlying our variable rate debt. For a description of our current interest rate swaps, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk and Part I, Item 1, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:69]
[same as prior period, unchanged from 0000106040-17-000013:mdna:81]

[0000106040-17-000036:mdna:70]
Flash Ventures sells and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half of the total outstanding obligations. The lease agreements contain customary covenants for Japanese lease facilities. In addition to containing customary events of default related to Flash Ventures that could result in an acceleration of Flash Ventures’ obligations, the lease agreements contain acceleration clauses for certain events of default related to the guarantors, including us. As of September 29, 2017, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 8, Commitments, Contingencies and Related Parties, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q for information regarding Flash Ventures.

[0000106040-17-000036:mdna:71]
[same as prior period, unchanged from 0000106040-17-000013:mdna:84]

[0000106040-17-000036:mdna:72]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part I, Item 3, Quantitative and Qualitative Disclosures About Market Risk and Part I, Item 1, Note 5, Derivative Instruments and Hedging Activities, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:73]
[same as prior period, unchanged from 0000106040-17-000013:mdna:86]

[0000106040-17-000036:mdna:74]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-17-000036:mdna:75]
[same as prior period, unchanged from 0000106040-17-000013:mdna:88]

[0000106040-17-000036:mdna:76]
[same as prior period, unchanged from 0000106040-17-000013:mdna:89]

[0000106040-17-000036:mdna:77]
As of September 29, 2017, the amount of unrecognized tax benefits, including related accrued interest and penalties, was $614 million, of which $497 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. For additional information regarding our total tax liability for unrecognized tax benefits, see Part I, Item 1, Note 10, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:78]
[same as prior period, unchanged from 0000106040-17-000013:mdna:91]

[0000106040-17-000036:mdna:79]
Since the first quarter of 2013, we have issued a quarterly cash dividend. On August 2, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of September 29, 2017. The cash dividend of $148 million was paid on October 16, 2017.

[0000106040-17-000036:mdna:80]
On November 1, 2017, we declared a cash dividend of $0.50 per share of our common stock to our shareholders of record as of December 29, 2017, which will be paid on January 16, 2018. We may modify, suspend, or cancel our cash dividend policy in any manner and at any time.

[0000106040-17-000036:mdna:81]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-17-000036:mdna:82]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07, “Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost” (“ASU 2017-07”). ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted within the first interim period. We are currently evaluating the impact ASU 2017-07 will have on our Consolidated Financial Statements.

[0000106040-17-000036:mdna:83]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles — Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment” (“ASU 2017-04”). ASU 2017-04 simplifies the test for goodwill impairment by removing Step 2 from the goodwill impairment test. Companies will now perform the goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount, recognizing an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value not to exceed the total amount of goodwill allocated to that reporting unit. An entity still has the option to perform the qualitative assessment for a reporting unit to determine if the quantitative impairment test is necessary. The new standard is effective for goodwill impairment tests in fiscal years beginning after December 15, 2019, which for us is the first quarter of 2021. Early adoption is permitted for goodwill impairment tests performed after January 1, 2017. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-17-000036:mdna:84]
In October 2016, the FASB issued ASU No. 2016-16, “Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory” (“ASU 2016-16”). ASU 2016-16 removes the prohibition in the FASB Accounting Standards Codification (“ASC”) Topic 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new standard is intended to reduce the complexity of accounting principles generally accepted in the United States (“U.S. GAAP”) and diversity in practice related to the tax consequences of certain types of intra-entity asset transfers, particularly those involving IP. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We are currently evaluating the impact ASU 2016-16 will have on our Consolidated Financial Statements.

[0000106040-17-000036:mdna:85]
In August 2016, the FASB issued ASU No. 2016-15, “Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments” (“ASU 2016-15”). ASU 2016-15 addresses certain cash flows issues regarding the classification of certain cash receipts and cash payments, which, among others, includes our disclosure requirement related to debt prepayment or extinguishment costs and distributions received from equity method investees. The new standard is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is permitted. We expect to adopt this standard in the first quarter of 2019. The adoption of this standard is not expected to have a material impact on our Consolidated Financial Statements.

[0000106040-17-000036:mdna:86]
In February 2016, the FASB issued ASU No. 2016-02, “Leases (Topic 842)” (“ASU 2016-02”). ASU 2016-02, among other things, requires lessees to recognize a right-of-use asset and a lease liability for leases. We expect to adopt this standard in the first quarter of 2020. We are currently evaluating the impact ASU 2016-02 will have on our Consolidated Financial Statements and related disclosures.

[0000106040-17-000036:mdna:87]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities” (“ASU 2016-01”). ASU 2016-01 provides guidance related to accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments, including the requirement to measure certain equity investments at fair value with changes in fair value recognized in net income. In addition, the FASB clarified guidance related to the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. ASU 2016-01 is effective for fiscal years beginning after December 15, 2017, which for us is the first quarter of 2019. Early adoption is not permitted. We are currently evaluating the impact ASU 2016-01 will have on our Consolidated Financial Statements.

[0000106040-17-000036:mdna:88]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606)” (“ASC Topic 606”), which amends the guidance in former ASC Topic 605, “Revenue Recognition”, to provide a single, comprehensive revenue recognition model for all contracts with customers. ASC Topic 606 requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The standard is effective beginning the first quarter of fiscal 2019, with early adoption permitted. The standard may be applied retrospectively to all prior periods presented (“full retrospective method”), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (“modified retrospective method”). Based on our preliminary plan, we intend to adopt the new standard beginning with the first quarter of 2019 using the modified retrospective method; however, we continue to assess this in connection with our entire project plan.

[0000106040-17-000036:mdna:89]
[same as prior period, unchanged from 0000106040-17-000013:mdna:106]

[0000106040-17-000036:mdna:90]
[same as prior period, unchanged from 0000106040-17-000013:mdna:107]

[0000106040-17-000036:mdna:91]
| • | For sales-based royalties, we will need to estimate and recognize revenue in the period the royalty-bearing sales occur as opposed to the existing treatment of recognizing revenue in the period the royalty report is received. This change will result in the acceleration of revenue recognition by one fiscal quarter as well as fluctuations between the estimated and actual reported sales-based royalties which we do not expect to be material. |

[0000106040-17-000036:mdna:92]
| • | For software and IP licenses, we are still assessing the impact and timing to revenue from the implementation of the new standard. However, we do not currently expect the new standard to have a material impact on our revenue for these types of arrangements. |

[0000106040-17-000036:mdna:93]
| • | Our revenue disclosures are expected to expand and may require judgment in certain areas. |

[0000106040-17-000036:mdna:94]
As we are completing our assessment, we are also identifying and preparing to implement changes to our processes, internal controls and systems configurations from the implementation of the new revenue standard. We do not currently expect any significant changes to our other accounting policies from the adoption of the new revenue standard. Our implementation efforts are progressing as planned.

[0000106040-17-000036:mdna:95]
For a description of recently adopted accounting pronouncements, including the respective dates of adoption and effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recently Adopted Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10‑Q.

[0000106040-17-000036:mdna:96]
[same as prior period, unchanged from 0000106040-17-000013:mdna:93]

[0000106040-17-000036:mdna:97]
We have prepared the accompanying unaudited Condensed Consolidated Financial Statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Condensed Consolidated Financial Statements may be material.

[0000106040-17-000036:mdna:98]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10‑K for our fiscal year ended June 30, 2017. Please refer to Part II, Item 7 of our Annual Report on Form 10‑K for the fiscal year ended June 30, 2017 for a discussion of our critical accounting policies and estimates.
