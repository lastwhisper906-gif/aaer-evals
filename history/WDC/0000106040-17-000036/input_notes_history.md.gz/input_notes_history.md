# WDC note change history — 0000106040-17-000013 → 0000106040-17-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-11-07):
[0000106040-17-000036:note_history:1]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- changed (2017-11-07):
[0000106040-17-000036:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 29, 2017 and June 30, 2017:
  (was, 2017-05-08, similarity 0.9457):
[0000106040-17-000013:note_history:2]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 31, 2017 and July 1, 2016:

- changed (2017-11-07):
[0000106040-17-000036:note_history:3]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 365 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 114 |  |  | 119 |  |
| Notes receivable, Flash Forward | 406 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 278 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,462 |  |  | $ | 1,340 |  |
  (was, 2017-05-08, similarity 0.9792):
[0000106040-17-000013:note_history:3]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 232 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 126 |  |  | 235 |  |
| Notes receivable, Flash Forward | 354 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 280 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,291 |  |  | $ | 1,171 |  |

- added (2017-11-07):
[0000106040-17-000036:note_history:4]
During the three months ended September 29, 2017, the Company made net payments to Flash Ventures of $792 million for purchased flash-based memory wafers and net loans and investments.

- changed (2017-11-07):
[0000106040-17-000036:note_history:5]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other expense, net in the Condensed Consolidated Statements of Operations. There were no such impairments in each of the three-month periods ended September 29, 2017 and September 30, 2016.
  (was, 2017-05-08, similarity 0.8717):
[0000106040-17-000013:note_history:5]
The Company assesses financing receivable credit quality through financial and operational reviews of the borrower and creditworthiness, including credit rating agency ratings, of significant investors of the borrower, where material or known. Impairments, when required for credit worthiness, are recorded in Other income (expense), net in the condensed consolidated statements of operations.

- changed (2017-11-07):
[0000106040-17-000036:note_history:6]
As of September 29, 2017 and June 30, 2017, the Company had accounts payable balances due to Flash Ventures of $226 million and $206 million, respectively.
  (was, 2017-05-08, similarity 0.9493):
[0000106040-17-000013:note_history:6]
As of March 31, 2017 and July 1, 2016, the Company had accounts payable balances due to Flash Ventures of $194 million and $168 million, respectively.

- added (2017-11-07):
[0000106040-17-000036:note_history:7]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at September 29, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2017-11-07):
[0000106040-17-000036:note_history:8]
|  | September 29, 2017 |
| Notes receivable | $ | 885 |  |
| Equity investments | 577 |  |
| Operating lease guarantees | 1,022 |  |
| Inventory | 202 |  |
| Maximum estimable loss exposure | $ | 2,686 |  |

- changed (2017-11-07):
[0000106040-17-000036:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017.
  (was, 2017-05-08, similarity 0.9746):
[0000106040-17-000013:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017.

- changed (2017-11-07):
[0000106040-17-000036:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of September 29, 2017 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of September 29, 2017:
  (was, 2017-05-08, similarity 0.9598):
[0000106040-17-000013:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of March 31, 2017 in U.S. dollars based upon the Japanese yen to U.S. dollar exchange rate as of March 31, 2017:

- changed (2017-11-07):
[0000106040-17-000036:note_history:11]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of September 29, 2017, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2017-05-08, similarity 0.7335):
[0000106040-17-000013:note_history:11]
The Company and Toshiba have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of March 31, 2017, no amounts have been accrued in the condensed consolidated financial statements with respect to these indemnification guarantees.

- removed (2017-11-07):
[0000106040-17-000013:note_history:12]
The Company’s business ventures with Toshiba Corporation (“Toshiba”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd (“Flash Forward” and together with Flash Partners and Flash Alliance, referred to as “Flash Ventures”). The Company has a 49.9% ownership interest and Toshiba has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Toshiba collaborate in the development and manufacture of NAND flash memory products, which are manufactured by Toshiba at its wafer fabrication facilities located in Yokkaichi, Japan, using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. The entities within Flash Ventures purchase wafers from Toshiba at cost and then resell those wafers to the Company and Toshiba at cost plus a markup.

- removed (2017-11-07):
[0000106040-17-000013:note_history:13]
The Company accounts for its ownership position of each entity with Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are variable interest entities (“VIEs”). The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

- removed (2017-11-07):
[0000106040-17-000013:note_history:14]
During the three and nine months ended March 31, 2017, the Company made net payments to Flash Ventures of $727 million and $2.0 billion, respectively, for purchased NAND flash memory wafers and net loans and investments.

- removed (2017-11-07):
[0000106040-17-000013:note_history:15]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 31, 2017, is presented below. Investments in Flash Ventures are denominated in Japanese yen and the maximum possible loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2017-11-07):
[0000106040-17-000013:note_history:16]
|  | March 31, 2017 |
|  | (in millions) |
| Notes receivable | $ | 712 |  |
| Equity investments | 579 |  |
| Operating lease guarantees | 1,048 |  |
| Prepayments | 23 |  |
| Maximum estimable loss exposure | $ | 2,362 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0000106040-17-000036:note_history:17]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment. In June 2017, the District Court vacated the judgment against WD and HGST with respect to infringement, willfulness, and damages and denied Convolve’s motion for reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.
  (was, 2017-05-08, similarity 0.8802):
[0000106040-17-000013:note_history:17]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint with the U.S. District Court for the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ’473 patent. The ’473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed notices of appeal with the U.S. District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the District Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

- added (2017-11-07):
[0000106040-17-000036:note_history:18]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic Corporation (“Panasonic”) and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted. The arbitration between Samsung and Toshiba was concluded in May 2017. In October 2017, the District Court issued an order directing Samsung and Toshiba to seek clarification from the arbitration panel regarding certain aspects of its decision.

- changed (2017-11-07):
[0000106040-17-000036:note_history:19]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.
  (was, 2017-05-08, similarity 0.7741):
[0000106040-17-000013:note_history:19]
In March 2011, a complaint was filed against SanDisk, SD-3C, Panasonic Corporation, Panasonic Corporation of North America, Toshiba and Toshiba America Electronic Components, Inc. with the U.S. District Court for the Northern District of California. The lawsuit purports to be on behalf of a nationwide class of indirect purchasers of SD cards. The complaint asserts claims under federal antitrust laws and California antitrust and unfair competition laws, as well as common law claims. The complaint seeks damages, restitution, injunctive relief, and fees and costs. The plaintiffs allege that the defendants conspired to artificially inflate the royalty costs associated with manufacturing SD cards, which in turn allegedly caused the plaintiffs to pay higher prices for SD cards. The allegations are similar to and incorporate allegations in Samsung Electronics Co., Ltd. v. Panasonic Corp., et al., described above. In May 2012, the District Court granted the defendants’ motion to dismiss the complaint with prejudice. The plaintiffs appealed. In May 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. In February 2015, the plaintiffs filed a second amended complaint in the District Court. In September 2015, the District Court granted the defendants’ motion to dismiss with leave to amend. In November 2015, the plaintiffs filed a third amended complaint. In November 2015, the defendants filed a motion to dismiss the plaintiffs’ federal law claims. In October 2016, the District Court granted the defendants’ motion with leave to amend and the defendants filed a motion to dismiss the plaintiffs’ remaining claims. Discovery is presently stayed until after completion of the pleading stage. The Company intends to defend itself vigorously in this matter.

- changed (2017-11-07):
[0000106040-17-000036:note_history:20]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. In June 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. In June 2017, the District Court denied the defendants’ motion to dismiss. The Company intends to defend itself vigorously in this matter.
  (was, 2017-05-08, similarity 0.9185):
[0000106040-17-000013:note_history:20]
Beginning in March 2015, SanDisk and two of its officers, Sanjay Mehrotra and Judy Bruner, were named in three putative class action lawsuits filed with the U.S. District Court for the Northern District of California. Two complaints are allegedly brought on behalf of a class of purchasers of SanDisk’s securities between October 2014 and March 2015, and one is brought on behalf of a purported class of purchasers of SanDisk’s securities between April 2014 and April 2015. The complaints generally allege violations of federal securities laws arising out of alleged misstatements or omissions by the defendants during the alleged class periods. The complaints seek, among other things, damages and fees and costs. In July 2015, the District Court consolidated the cases and appointed Union Asset Management Holding AG and KBC Asset Management NV as lead plaintiffs. The lead plaintiffs filed an amended complaint in August 2015. In January 2016, the District Court granted the defendants’ motion to dismiss and dismissed the amended complaint with leave to amend. In February 2016, the District Court issued an order appointing as new lead plaintiffs Bristol Pension Fund; City of Milford, Connecticut Pension & Retirement Board; Pavers and Road Builders Pension, Annuity and Welfare Funds; the Newport News Employees’ Retirement Fund; and Massachusetts Laborers’ Pension Fund (collectively, the “Institutional Investor Group”). In March 2016, the Institutional Investor Group filed an amended complaint. The defendants filed a motion to dismiss in April 2016. In June 2016, the District Court granted the motion and dismissed the amended complaint with leave to amend. In July 2016, the Institutional Investor Group filed a further amended complaint. The defendants filed a motion to dismiss in August 2016. In January 2017, the District Court denied the motion to dismiss without prejudice to the defendants filing a renewed motion to dismiss, which the defendants filed soon thereafter. The Company intends to defend itself vigorously in this matter.

- added (2017-11-07):
[0000106040-17-000036:note_history:21]
Toshiba Matters

- added (2017-11-07):
[0000106040-17-000036:note_history:22]
Toshiba litigation against the Company

- added (2017-11-07):
[0000106040-17-000036:note_history:23]
In July 2017, the Company received a petition for provisional disposition that was filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court. The petition alleges that the Company has engaged in acts of defamation and wrongful acquisition and use of trade secrets in violation of the Unfair Competition Prevention Act. The petition requests injunctive relief.

- added (2017-11-07):
[0000106040-17-000036:note_history:24]
In August 2017, the Company received a complaint filed by Toshiba and Toshiba Memory Corporation in the Tokyo District Court seeking a permanent injunction and damages of 120 billion Japanese yen. The complaint is based on the same allegations as the petition for provisional disposition. The Company intends to defend itself vigorously in these matters.

- added (2017-11-07):
[0000106040-17-000036:note_history:25]
SanDisk litigation against Toshiba

- added (2017-11-07):
[0000106040-17-000036:note_history:26]
In May 2017, several of the Company’s SanDisk subsidiaries (the “SanDisk Subsidiaries”) filed a request for arbitration with the ICC International Court of Arbitration seeking an order requiring Toshiba to unwind the transfer of its interests in Flash Ventures to its affiliate, Toshiba Memory Corporation, and injunctive relief preventing Toshiba from further breaching the Flash Ventures agreements in violation of the SanDisk Subsidiaries’ consent rights. In June 2017, the SanDisk Subsidiaries sought preliminary injunctive relief in the Superior Court of the State of California for the County of San Francisco in aid of that arbitration. Among other things, SanDisk asked the Superior Court to prevent Toshiba from transferring its interests in Flash Ventures until the SanDisk Subsidiaries could seek injunctive relief in the arbitration to prevent a transfer. In July 2017, the Superior Court entered a stipulated order requiring Toshiba to give the SanDisk Subsidiaries at least 14 days’ advance notice of any transfer to a third party involving Toshiba’s interests in Flash Ventures, in order to ensure that the issue is preserved for arbitration. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.

- added (2017-11-07):
[0000106040-17-000036:note_history:27]
In July 2017, SanDisk LLC filed a request for arbitration with the ICC International Court of Arbitration against Toshiba seeking damages and injunctive relief for, among other things, blocking certain employees of SanDisk’s affiliates from accessing shared databases regarding Flash Ventures and from refusing to ship certain engineering wafers and samples to SanDisk’s affiliates in breach of the agreements governing the joint venture. SanDisk LLC also sought injunctive relief, a preliminary injunction and a temporary restraining order (“TRO”), in aid of that arbitration from the Superior Court of the State of California for the County of San Francisco. On July 11, 2017, the Superior Court granted a TRO in favor of SanDisk. Toshiba filed a notice of appeal, and on July 18, 2017, the California Court of Appeal, First Appellate District, issued a temporary stay of the TRO while it reviewed Toshiba’s petition for a permanent stay of the TRO pending appeal. On July 24, 2017, SanDisk LLC amended its request for arbitration to, among other things, add Toshiba Memory Corporation as a defendant. On August 2, 2017, the Court of Appeal denied Toshiba’s petition for a permanent stay of the TRO and dissolved the temporary stay. On August 14, 2017, the Superior Court granted SanDisk’s request for a preliminary injunction. On August 18, 2017, Toshiba withdrew its appeal of the TRO, and filed a notice of appeal of the preliminary injunction. In October 2017, the ICC International Court of Arbitration confirmed the three-member arbitral panel that will decide the arbitration matter.

- added (2017-11-07):
[0000106040-17-000036:note_history:28]
In September 2017, the SanDisk Subsidiaries filed a request for arbitration with the ICC International Court of Arbitration against Toshiba in relation to Toshiba's announced decision to invest unilaterally in manufacturing equipment for the Fab 6 clean room at the joint venture operations in Yokkaichi, Japan.  The SanDisk Subsidiaries seek, among other things, a permanent injunction preventing Toshiba from making unilateral investments in capacity expansions and conversions for 3‑dimensional (“3D”) NAND technology, which we refer to as BiCS 3D NAND-flash memory, including investments in manufacturing equipment for Fab 6, without first complying with its obligations with respect to giving the SanDisk Subsidiaries the opportunity to make comparable investments.

- added (2017-11-07):
[0000106040-17-000036:note_history:29]
Copyright

- changed (2017-11-07):
[0000106040-17-000036:note_history:30]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows; however, it is reasonably possible that the Company could incur losses totaling up to $166 million, inclusive of amounts accrued, if it does not prevail in this matter.
  (was, 2017-05-08, similarity 0.8325):
[0000106040-17-000013:note_history:30]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows. It is reasonably possible that the Company may incur losses totaling up to $141 million, including the amounts accrued.

- removed (2017-11-07):
[0000106040-17-000013:note_history:31]
In December 2016, Memory Technologies, LLC (“MTL”) filed two complaints - one with the International Trade Commission (“ITC”) and the other with the U.S. District Court for the Central District of California - against WD and certain of its subsidiaries alleging infringement of various patents. In the ITC complaint, MTL asserts that certain of the Company’s Secure Digital (“SD”) and microSD products infringe U.S. Patent Nos. RE45,542; RE45,486; 7,565,469; 9,063,850; and 8,307,180. The ITC complaint seeks an exclusion order barring the accused products, and components thereof, from entry into the U.S. On January 5, 2017, the ITC issued a notice of institution of investigation regarding the complaint. On February 6, 2017, the Company filed its response to the complaint. In the other complaint, MTL asserts that certain of the Company’s SD, microSD and/or eMMC products infringe the same patents asserted in the ITC complaint, as well as U.S. Patent Nos. 7,275,186; 7,827,370; and 7,739,487. The complaint seeks unspecified monetary damages. The District Court action has been stayed pending resolution of the ITC proceeding. The Company intends to defend itself vigorously in these matters.

- removed (2017-11-07):
[0000106040-17-000013:note_history:32]
In June 2010, Ritz Camera & Image, LLC (“Ritz”) filed a complaint with the U.S. District Court for the Northern District of California, alleging that SanDisk violated federal antitrust laws by conspiring to monopolize and monopolizing the market for flash memory products. The lawsuit purports to be on behalf of direct purchasers of flash memory products sold by SanDisk and SanDisk-controlled joint ventures from June 2006 through the present. The complaint alleged that SanDisk created and maintained a monopoly by fraudulently obtaining patents and using them to restrain competition and by allegedly converting other patents for its competitive use. The complaint sought damages, injunctive relief, and fees and costs. In February 2011, the District Court granted in part SanDisk’s motion to dismiss, which resulted in Dr. Harari being dismissed as a defendant. Between 2013 and 2014, the District Court granted Ritz’s motion to substitute in as named plaintiff Albert Giuliano, the Chapter 7 Trustee of the Ritz bankruptcy estate, and the Trustee’s motions to add as named plaintiffs CPM Electronics Inc., E.S.E. Electronics, Inc. and Mflash, Inc. In May 2015, the District Court granted in part plaintiffs’ motion for class certification. In April 2016, the District Court granted SanDisk’s motion for summary judgment and entered judgment in SanDisk’s favor as to all of the plaintiffs’ claims. In May 2016, the plaintiffs filed a notice of appeal to the U.S. Court of Appeals for the Federal Circuit. The appeal is currently pending.

- removed (2017-11-07):
[0000106040-17-000013:note_history:33]
In July 2010, Samsung Electronics Co., Ltd. (“Samsung”) filed an action against Panasonic and SD-3C LLC (“SD-3C”) with the U.S. District Court for the Northern District of California, alleging that the defendants violated federal antitrust laws and California antitrust and unfair competition laws relating to the licensing practices and operations of SD-3C. The complaint seeks damages, restitution, injunctive and declaratory relief, and fees and costs. SanDisk is not a defendant in this case, but it established SD-3C along with Panasonic and Toshiba, and the complaint includes various factual allegations concerning SanDisk. As a member of SD-3C, SanDisk could be responsible for a portion of any monetary award. Other requested relief, if granted, could result in a loss of revenue to SanDisk. In August 2011, the District Court granted the defendants’ motion to dismiss, dismissing Samsung’s patent misuse claim with prejudice and all other claims with leave to amend. Samsung filed an amended complaint in September 2011. In January 2012, the District Court granted the defendants’ motion to dismiss Samsung’s amended complaint without leave to amend. Samsung appealed. In April 2014, the U.S. Court of Appeals for the Ninth Circuit reversed the District Court’s dismissal and remanded the case to the District Court for further proceedings. Samsung filed a third amended complaint in January 2015. In September 2015, the District Court granted in part the defendants’ motion to dismiss with leave to amend. In October 2015, Samsung filed a fourth amended complaint. In November 2015, the defendants filed a motion to dismiss. In September 2016, the District Court stayed the litigation pending the outcome of an ongoing arbitration between Samsung and Toshiba. The District Court denied the motion to dismiss without prejudice to refiling after the stay is lifted.


## wdc:OrganizationandBasisofPresentationTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 0.7119

- changed (2017-11-07):
[0000106040-17-000036:note_history:34]
Organization and Basis of Presentation
  (was, 2017-05-08, similarity 0.7119):
[0000106040-17-000013:note_history:34]
Basis of Presentation

- added (2017-11-07):
[0000106040-17-000036:note_history:35]
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company’s broad portfolio of technology and products address the following key markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue related to its intellectual property (“IP”) which is included in each of these three categories.

- changed (2017-11-07):
[0000106040-17-000036:note_history:36]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the fiscal year ended June 30, 2017. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2017-05-08, similarity 0.9856):
[0000106040-17-000013:note_history:36]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2017-11-07):
[0000106040-17-000036:note_history:37]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2018, which ends on June 29, 2018, and 2017, which ended on June 30, 2017, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.
  (was, 2017-05-08, similarity 0.9919):
[0000106040-17-000013:note_history:37]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Fiscal years 2017, which ends on June 30, 2017, and 2016, which ended on July 1, 2016, are both comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- removed (2017-11-07):
[0000106040-17-000013:note_history:38]
Western Digital Corporation (the “Company” or “Western Digital”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every industry. The Company also generates license and royalty revenue related to its intellectual property.

- removed (2017-11-07):
[0000106040-17-000013:note_history:39]
Reclassifications

- removed (2017-11-07):
[0000106040-17-000013:note_history:40]
Certain prior year amounts have been reclassified in the condensed consolidated statements of operations and condensed consolidated statements of cash flows to conform to the current year presentation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0000106040-17-000036:note_history:41]
Debt consisted of the following as of September 29, 2017 and June 30, 2017:
  (was, 2017-05-08, similarity 0.8889):
[0000106040-17-000013:note_history:41]
Debt consisted of the following as of March 31, 2017 and July 1, 2016:

- changed (2017-11-07):
[0000106040-17-000036:note_history:42]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,073 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,963 |  |  | 2,970 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,031 |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 13,327 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (196 | ) |  | (205 | ) |
| Subtotal | 13,131 |  |  | 13,151 |  |
| Less current portion of long-term debt | (258 | ) |  | (233 | ) |
| Long-term debt | $ | 12,873 |  |  | $ | 12,918 |  |
  (was, 2017-05-08, similarity 0.8536):
[0000106040-17-000013:note_history:42]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,978 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 938 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,301 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (213 | ) |  | (532 | ) |
| Subtotal | 13,088 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (181 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,907 |  |  | $ | 13,660 |  |

- changed (2017-11-07):
[0000106040-17-000036:note_history:43]
| (1) | Euro Term Loan B-2 outstanding principal amounts as of September 29, 2017 and June 30, 2017 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2017-05-08, similarity 0.9046):
[0000106040-17-000013:note_history:43]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of March 31, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |

- changed (2017-11-07):
[0000106040-17-000036:note_history:44]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. As of September 29, 2017, the Company was in compliance with all financial covenants. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.
  (was, 2017-05-08, similarity 0.9358):
[0000106040-17-000013:note_history:44]
The Credit Agreement requires the Company to comply with certain financial covenants, such as a leverage ratio and an interest coverage ratio. In addition, the documents governing substantially all of the Company’s outstanding debt, including the Credit Agreement, require the Company to comply with customary covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens and indebtedness; make certain restricted payments, acquisitions, investments, loans and guarantees; and enter into certain transactions with affiliates, mergers and consolidations.

- removed (2017-11-07):
[0000106040-17-000013:note_history:45]
Credit Agreement – Term Loans and Revolving Credit Facility

- removed (2017-11-07):
[0000106040-17-000013:note_history:46]
On April 29, 2016, the Company entered into a credit agreement (the “Credit Agreement”) that provided for a $4.125 billion Term Loan A, a $3.750 billion U.S. Term Loan B, a €885 million Euro Term Loan B and a $1.0 billion revolving credit facility. The revolving credit facility includes a $200 million sublimit for letters of credit.

- removed (2017-11-07):
[0000106040-17-000013:note_history:47]
On August 17, 2016, the Company borrowed $3.0 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan and cash of $750 million to prepay in full the U.S. Term Loan B previously outstanding under the Credit Agreement. On September 22, 2016, the Company borrowed €885 million under a new Euro-denominated term loan (“Euro Term Loan B-1”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B previously outstanding under the Credit Agreement. In connection with the settlement of the U.S. Term Loan B and Euro Term Loan B, the Company recognized a loss on debt extinguishment of $227 million consisting of unamortized issuance costs and debt discount fees.

- removed (2017-11-07):
[0000106040-17-000013:note_history:48]
On March 14, 2017, the Company borrowed $2.985 billion under a new U.S. dollar-denominated term loan (“U.S. Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the U.S. Term Loan B-1 previously outstanding under the Credit Agreement. The U.S. Term Loan B-2 has an interest rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.75% floor, plus 2.75% or a base rate plus 1.75% (3.73% as of March 31, 2017). Principal payments on U.S. Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The U.S. Term Loan B-2 issuance costs of $2 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $2 million remain unamortized.

- removed (2017-11-07):
[0000106040-17-000013:note_history:49]
On March 23, 2017, the Company borrowed €881 million under a new Euro-denominated term loan (“Euro Term Loan B-2”) under the Credit Agreement and used the proceeds of this new loan to prepay in full the Euro Term Loan B-1 previously outstanding under the Credit Agreement. The Euro Term Loan B-2 has an interest rate equal to an adjusted EURIBOR rate, subject to a 0.75% floor, plus 2.00% (2.75% as of March 31, 2017). Principal payments on Euro Term Loan B-2 of 0.25% are due quarterly and began on March 31, 2017 with the balance due on April 29, 2023. The Euro Term Loan B-2 issuance costs of $1 million are amortized to interest expense over the term of the loan. As of March 31, 2017, issuance costs of $1 million remain unamortized.

- removed (2017-11-07):
[0000106040-17-000013:note_history:50]
In connection with the settlement of the U.S. Term Loan B-1 and Euro Term Loan B-1, the Company recognized a loss of $7 million consisting of unamortized issuance costs and debt discount fees.

- removed (2017-11-07):
[0000106040-17-000013:note_history:51]
As of March 31, 2017, the revolving credit facility was not drawn upon, and there was no outstanding balance.

- removed (2017-11-07):
[0000106040-17-000013:note_history:52]
Beginning in September 2017, the Company is required to make quarterly principal payments on Term Loan A totaling $206 million in 2018, $309 million in 2019, $413 million in 2020 and the remaining balance of $3.197 billion due in 2021. As of March 31, 2017, Term Loan A had an outstanding balance of $4.125 billion with a variable interest rate of 2.98%.

- removed (2017-11-07):
[0000106040-17-000013:note_history:53]
The obligations under the Credit Agreement are guaranteed by HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC and Western Digital Technologies, Inc. (“WDT”) (together referred to as the “WD Guarantors”), and are secured on a first-priority basis by a lien on substantially all the assets and properties of the Company and the WD Guarantors, including all of the capital stock held by these entities (subject to a 65% limitation on pledges of capital stock of foreign subsidiaries and domestic holding companies of foreign subsidiaries), subject to certain exceptions.

- removed (2017-11-07):
[0000106040-17-000013:note_history:54]
The term loans and the revolving credit loans under the Credit Agreement may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions, except that the U.S. Term Loan B-2 and the Euro Term Loan B-2 require the Company to pay a 1.0% prepayment fee if the loans thereunder are repaid in connection with certain “repricing” transactions on or before September 14, 2017, with respect to U.S. Term Loan B-2, and September 23, 2017, with respect to Euro Term Loan B-2.

- removed (2017-11-07):
[0000106040-17-000013:note_history:55]
Additional Bridge Facility

- removed (2017-11-07):
[0000106040-17-000013:note_history:56]
On May 12, 2016, WDT entered into a short-term senior secured bridge credit agreement providing for $3.0 billion in aggregate principal amount of senior secured bridge loans. On July 21, 2016, the Company repaid in full the $3.0 billion aggregate principal amount outstanding, together with accrued interest.

- removed (2017-11-07):
[0000106040-17-000013:note_history:57]
Senior Notes

- removed (2017-11-07):
[0000106040-17-000013:note_history:58]
On April 13, 2016, the Company completed an offering of its $1.875 billion aggregate principal amount of 7.375% senior secured notes due 2023 (the “Secured Notes”) and $3.350 billion aggregate principal amount of 10.500% senior unsecured notes due 2024 (the “Initial Unsecured Notes”). On January 6, 2017, to fulfill the Company’s obligations under the registration rights agreement associated with the Initial Unsecured Notes, the Company commenced an exchange offer to exchange all of these outstanding unsecured notes for an equal principal amount of new 10.500% senior unsecured notes due 2024 (the “New Unsecured Notes”), with substantially the same terms as the Initial Unsecured Notes. On February 6, 2017, the exchange offer expired and substantially all of the outstanding Initial Unsecured Notes were tendered in the exchange offer and accepted by the Company. The New Unsecured Notes are registered under the Securities Act of 1933, as amended, and have no transfer restrictions or rights to additional interest. The Initial Unsecured Notes, the New Unsecured Notes and the Secured Notes are collectively referred to as the “Notes”.

- removed (2017-11-07):
[0000106040-17-000013:note_history:59]
The Company is not required to make principal payments on the Notes prior to their respective maturity dates, except that the Company may be required to offer to purchase the Notes upon the occurrence of a change of control (as defined in the indentures governing the Notes) or with the proceeds of certain non-ordinary course asset sales. Interest payments on the Notes are due semi-annually in arrears.

- removed (2017-11-07):
[0000106040-17-000013:note_history:60]
The Notes are guaranteed by the WD Guarantors, and the Secured Notes and related guarantees are secured on an equal and ratable basis by liens on the same assets that secure indebtedness under the Credit Agreement.

- removed (2017-11-07):
[0000106040-17-000013:note_history:61]
Convertible Notes, Exchange Options and Call Options

- removed (2017-11-07):
[0000106040-17-000013:note_history:62]
As of July 1, 2016, the Company had outstanding, through the acquisition of SanDisk, $129 million aggregate principal amount of its 1.5% Convertible Senior Notes due 2017 (the “2017 Notes”) and $310 million aggregate principal amount of its 0.5% Convertible Senior Notes due 2020 (the “2020 Notes” and, together with the 2017 Notes, the “Convertible Notes”). The 2017 Notes mature on August 15, 2017 and the 2020 Notes mature on November 15, 2020.

- removed (2017-11-07):
[0000106040-17-000013:note_history:63]
During the three months ended March 31, 2017, the Company repurchased an immaterial amount of the 2017 Notes. During the nine months ended March 31, 2017, the Company paid to the holders of the Convertible Notes for conversion and repurchase, $494 million of cash and 0.3 million shares of the Company’s common stock with an aggregate value of $16 million.

- removed (2017-11-07):
[0000106040-17-000013:note_history:64]
As of March 31, 2017, $35 million principal amount of the 2020 Notes and an immaterial principal amount of the 2017 Notes were outstanding. For the 2020 Notes that remain outstanding, the conversion rate is 10.9006 units of reference property per $1,000 principal amount of the 2020 Notes, corresponding to 2.6020 shares of the Company’s common stock and $735.79 of cash, subject to adjustments under the indenture. The 2020 Notes are not currently exchangeable into reference property.

- removed (2017-11-07):
[0000106040-17-000013:note_history:65]
The Convertible Notes were bifurcated into a debt host and exchange option for accounting purposes. The exchange options are accounted for as a derivative liability because they are predominantly settled in cash. Changes in the fair value of the exchange options are reported, and will be reported until the Company extinguishes the related debt, in Other income (expense), net in the condensed consolidated statements of operations. The exchange options are measured and reported at fair value on a recurring basis, within Level 3 of the fair value hierarchy. The fair value of the unredeemed and unsettled exchange options was reported in Accrued expenses and Other liabilities in the condensed consolidated balance sheets. See Note 4 to the condensed consolidated financial statements for additional disclosures related to the fair values of the exchange options. For the three and nine months ended March 31, 2017, the change in the fair value of the outstanding exchange options related to the Convertible Notes resulted in an immaterial loss.

- removed (2017-11-07):
[0000106040-17-000013:note_history:66]
In connection with the SanDisk acquisition, the Company assumed the outstanding call options entered into by SanDisk at the inception of the respective Convertible Notes, which were structured to reduce the potential economic dilution associated with the conversion of Convertible Notes. The call options are derivative instruments classified as an asset that result in the Company receiving cash and shares that partially offset the Company’s obligation upon conversion of the Convertible Notes. The fair value of the unredeemed and unsettled call options was reported in Other current assets and Other non-current assets in the condensed consolidated balance sheets. During the nine months ended March 31, 2017, under the call options, the Company received $61 million of cash and 0.1 million shares of the Company’s common stock which had an aggregate value of $11 million. During the three and nine months ended March 31, 2017, the Company recognized an immaterial non-cash loss related to the change in value in the outstanding call options. The value of the call options as of March 31, 2017 was immaterial.

- removed (2017-11-07):
[0000106040-17-000013:note_history:67]
The conversion and repurchase of the Convertible Notes and related settlement of the call options during the three and nine months ended March 31, 2017 resulted in an immaterial net loss.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0000106040-17-000036:note_history:68]
Debt consisted of the following as of September 29, 2017 and June 30, 2017:
  (was, 2017-05-08, similarity 0.8889):
[0000106040-17-000013:note_history:68]
Debt consisted of the following as of March 31, 2017 and July 1, 2016:

- changed (2017-11-07):
[0000106040-17-000036:note_history:69]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,073 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,963 |  |  | 2,970 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 1,031 |  |  | 1,001 |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 35 |  |
| Total debt | 13,327 |  |  | 13,356 |  |
| Issuance costs and debt discounts | (196 | ) |  | (205 | ) |
| Subtotal | 13,131 |  |  | 13,151 |  |
| Less current portion of long-term debt | (258 | ) |  | (233 | ) |
| Long-term debt | $ | 12,873 |  |  | $ | 12,918 |  |
  (was, 2017-05-08, similarity 0.8536):
[0000106040-17-000013:note_history:69]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Variable interest rate Term Loan A maturing 2021 | $ | 4,125 |  |  | $ | 4,125 |  |
| Variable interest rate U.S. Term Loan B maturing 2023 | — |  |  | 3,750 |  |
| Variable interest rate U.S. Term Loan B-2 maturing 2023 | 2,978 |  |  | — |  |
| Variable interest rate Euro Term Loan B maturing 2023(1) | — |  |  | 987 |  |
| Variable interest rate Euro Term Loan B-2 maturing 2023(1) | 938 |  |  | — |  |
| 7.375% senior secured notes due 2023 | 1,875 |  |  | 1,875 |  |
| 10.500% senior unsecured notes due 2024 | 3,350 |  |  | 3,350 |  |
| Convertible senior notes | 35 |  |  | 439 |  |
| Bridge loans | — |  |  | 3,000 |  |
| Total debt | 13,301 |  |  | 17,526 |  |
| Issuance costs and debt discounts | (213 | ) |  | (532 | ) |
| Subtotal | 13,088 |  |  | 16,994 |  |
| Less bridge loans and current portion of long-term debt | (181 | ) |  | (3,334 | ) |
| Long-term debt | $ | 12,907 |  |  | $ | 13,660 |  |

- changed (2017-11-07):
[0000106040-17-000036:note_history:70]
| (1) | Euro Term Loan B-2 outstanding principal amounts as of September 29, 2017 and June 30, 2017 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |
  (was, 2017-05-08, similarity 0.9046):
[0000106040-17-000013:note_history:70]
| (1) | Euro Term Loan B and Euro Term Loan B-2 outstanding principal amounts as of March 31, 2017 and July 1, 2016 were based upon the Euro to U.S. dollar exchange rate as of those respective dates. |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0000106040-17-000036:note_history:71]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of September 29, 2017 and June 30, 2017:
  (was, 2017-05-08, similarity 0.9457):
[0000106040-17-000013:note_history:71]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of March 31, 2017 and July 1, 2016:

- changed (2017-11-07):
[0000106040-17-000036:note_history:72]
|  | September 29, 2017 |  | June 30, 2017 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 365 |  |  | $ | 264 |  |
| Notes receivable, Flash Alliance | 114 |  |  | 119 |  |
| Notes receivable, Flash Forward | 406 |  |  | 379 |  |
| Investment in Flash Partners | 187 |  |  | 187 |  |
| Investment in Flash Alliance | 278 |  |  | 279 |  |
| Investment in Flash Forward | 112 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,462 |  |  | $ | 1,340 |  |
  (was, 2017-05-08, similarity 0.9792):
[0000106040-17-000013:note_history:72]
|  | March 31, 2017 |  | July 1, 2016 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 232 |  |  | $ | 65 |  |
| Notes receivable, Flash Alliance | 126 |  |  | 235 |  |
| Notes receivable, Flash Forward | 354 |  |  | 263 |  |
| Investment in Flash Partners | 187 |  |  | 202 |  |
| Investment in Flash Alliance | 280 |  |  | 306 |  |
| Investment in Flash Forward | 112 |  |  | 100 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,291 |  |  | $ | 1,171 |  |
