# WDC notes — 0000106040-14-000007


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-14-000007:notes:1]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments as of March 28, 2014 (in millions):

[0000106040-14-000007:notes:2]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 149 |  |  | $ | — |  |  | $ | 149 |  |
| U.S. Government agency securities | 98 |  |  | — |  |  | 98 |  |
| Commercial paper | 170 |  |  | — |  |  | 170 |  |
| Other | 53 |  |  | — |  |  | 53 |  |
| Auction-rate securities | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 484 |  |  | $ | — |  |  | $ | 484 |  |
| Included in short-term investments |  |  |  |  | $ | 296 |  |
| Included in other non-current assets |  |  |  |  | 188 |  |
| Total |  |  |  |  | $ | 484 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-14-000007:notes:3]
[same as prior period, unchanged from 0000106040-14-000002:notes:1]

[0000106040-14-000007:notes:4]
[same as prior period, unchanged from 0000106040-14-000002:notes:2]

[0000106040-14-000007:notes:5]
On October 17, 2013, the Company acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. As a result of the acquisition, Virident was fully integrated into the Company's HGST subsidiary and became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash, and $15 million related to the fair value of stock options assumed. The acquisition is expected to further HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures.

[0000106040-14-000007:notes:6]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $505 million to goodwill. The values assigned to the acquired assets and liabilities are based on preliminary estimates of fair value available as of the date of this Quarterly Report on Form 10-Q, and may be adjusted as further information becomes available during the measurement period of up to 12 months from the date of the acquisition. The primary area of the preliminary purchase price allocation that is not yet finalized due to information that may become available subsequently is income taxes, and any changes in fair values could potentially result in material adjustments to goodwill. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements. In addition, pro forma financial information has not been presented as the acquisition did not have a material impact on the Company’s condensed consolidated financial statements for the nine months ended March 28, 2014.

[0000106040-14-000007:notes:7]
[same as prior period, unchanged from 0000106040-14-000002:notes:5]

[0000106040-14-000007:notes:8]
|  | October 17,2013 |
| Tangible assets acquired and liabilities assumed | $ | 59 |  |
| Intangible assets | 49 |  |
| Goodwill | 505 |  |
| Total | $ | 613 |  |

[0000106040-14-000007:notes:9]
The $505 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create server-side flash storage solutions leveraging the core technology acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Virident was immaterial to the Company’s condensed consolidated financial statements for the three and nine months ended March 28, 2014.

[0000106040-14-000007:notes:10]
[same as prior period, unchanged from 0000106040-14-000002:notes:8]

[0000106040-14-000007:notes:11]
On September 12, 2013, the Company completed its acquisition of sTec, a provider of enterprise solid-state drives. As a result of the acquisition, sTec was fully integrated into the Company's HGST subsidiary and became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash, and $11 million related to the fair value of stock options and RSUs assumed. The acquisition is intended to augment HGST's existing solid-state storage capabilities.

[0000106040-14-000007:notes:12]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $88 million to goodwill. The values assigned to the acquired assets and liabilities are based on preliminary estimates of fair value available as of the date of this Quarterly Report on Form 10-Q, and may be adjusted as further information becomes available during the measurement period of up to 12 months from the date of the acquisition. The primary areas of the preliminary purchase price allocation that are not yet finalized due to information that may become available subsequently include contingencies and income taxes, and any changes in these fair values could potentially result in material adjustments to goodwill. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements. In addition, pro forma financial information has not been presented as the acquisition did not have a material impact on the Company’s condensed consolidated financial statements for the nine months ended March 28, 2014.

[0000106040-14-000007:notes:13]
[same as prior period, unchanged from 0000106040-14-000002:notes:11]

[0000106040-14-000007:notes:14]
|  | September 12,2013 |
| Tangible assets acquired and liabilities assumed | $ | 190 |  |
| Intangible assets | 58 |  |
| Goodwill | 88 |  |
| Total | $ | 336 |  |

[0000106040-14-000007:notes:15]
In the three months ended March 28, 2014, the Company recorded a $3 million increase to goodwill to reflect an adjustment to the value of investments acquired in the acquisition of sTec. The $88 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from augmenting HGST's existing solid-state storage capabilities and accelerating its ability to expand its participation in the growing area of enterprise solid-state drives and is not expected to be deductible for tax purposes.  The impact to revenue and net income attributable to sTec was immaterial to the Company’s condensed consolidated financial statements for the three and nine months ended March 28, 2014.

[0000106040-14-000007:notes:16]
[same as prior period, unchanged from 0000106040-14-000002:notes:14]

[0000106040-14-000007:notes:17]
[same as prior period, unchanged from 0000106040-14-000002:notes:15]


## us-gaap:DebtDisclosureTextBlock

[0000106040-14-000007:notes:18]
4. Debt

[0000106040-14-000007:notes:19]
On March 8, 2012 (the “HGST Closing Date”), the Company, in its capacity as the parent entity and guarantor, Western Digital Technologies, Inc. (“WDT”), a wholly owned subsidiary of the Company, and Western Digital Ireland, Ltd. (“WDI”), an indirect wholly owned subsidiary of the Company, entered into a five-year credit agreement (the “Prior Credit Facility”) with Bank of America, N.A., as administrative agent, swing line lender and letter of credit issuer, and certain other participating lenders. The Prior Credit Facility provided for $2.8 billion of unsecured loan facilities consisting of a $2.3 billion term loan facility and a $500 million revolving credit facility. On January 9, 2014 (the "Closing Date”), WDI used existing cash to repay the outstanding term loan balance of $1.8 billion under the Prior Credit Facility, and subsequently, on the Closing Date, the Company, WDT and WDI, entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"); WDT paid the outstanding revolving credit facility balance of $500 million under the Prior Credit Facility; and the Company terminated the Prior Credit Facility. In connection with the repayment of the Prior Credit Facility, $4 million of debt issuance costs associated with lenders that did not enter into the Credit Agreement were written off in the three months ended March 28, 2014, and are included within interest and other expense in the condensed consolidated statements of income. The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT and WDI (the “Borrowers”). The revolving credit facility includes a $100 million sublimit for letters of credit and a $50 million sublimit for swing line loans. Subject to certain conditions, a Borrower may elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. The loans under the Credit Agreement have a five-year term. The obligations of the Borrowers under the Credit Agreement are guaranteed by the Company and its material domestic subsidiaries, and the obligations of WDI under the Credit Agreement are also guaranteed by WDT.

[0000106040-14-000007:notes:20]
As of March 28, 2014, no amounts were outstanding under the revolving credit facility and the term loan facility had an outstanding balance of $2.5 billion and a variable interest rate of 1.66%. The Company is required to make quarterly principal payments on the term loan facility totaling $31 million for the remainder of fiscal 2014, $125 million in fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-14-000007:notes:21]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of March 28, 2014, the Company was in compliance with all covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-14-000007:notes:22]
[same as prior period, unchanged from 0000106040-14-000002:notes:18]

[0000106040-14-000007:notes:23]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for trading purposes. As of March 28, 2014, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-14-000007:notes:24]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three and nine months ended March 28, 2014 and March 29, 2013.

[0000106040-14-000007:notes:25]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of operating expenses. All fair value hedges were determined to be effective. The fair value and the changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three and nine months ended March 28, 2014 and March 29, 2013.

[0000106040-14-000007:notes:26]
As of March 28, 2014, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $15 million. In addition, as of March 28, 2014, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $1.0 billion and $3.7 billion and closed $1.2 billion and $3.8 billion, in foreign exchange contracts in the three and nine months ended March 28, 2014, respectively. The Company opened $2.5 billion and $3.9 billion, and closed $1.4 billion and $3.3 billion, in foreign exchange contracts in the three and nine months ended March 29, 2013, respectively. The fair value and balance sheet location of such contracts were as follows (in millions):

[0000106040-14-000007:notes:27]
|  | Asset Derivatives | Liability Derivatives |
|  | March 28, 2014 | June 28, 2013 | March 28, 2014 | June 28, 2013 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | 1 |  | Other current assets | $ | — |  | Accrued expenses | $ | 21 |  | Accrued expenses | $ | 57 |  |

[0000106040-14-000007:notes:28]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of March 28, 2014 (in millions):

[0000106040-14-000007:notes:29]
|  |  |  |  |  |  |  | Gross Amounts Not Offset in the Balance Sheet |  |  |
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |  | Financial Instruments |  | Cash Collateral Received or Pledged |  | Net Amount |
| Foreign exchange contracts |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 2 |  |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Financial liabilities | (22 | ) |  | 1 |  |  | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Total derivative instruments | $ | (20 | ) |  | $ | — |  |  | $ | (20 | ) |  | $ | — |  |  | $ | — |  |  | $ | (20 | ) |

[0000106040-14-000007:notes:30]
[same as prior period, unchanged from 0000106040-14-000002:notes:26]

[0000106040-14-000007:notes:31]
[same as prior period, unchanged from 0000106040-14-000002:notes:27]

[0000106040-14-000007:notes:32]
[same as prior period, unchanged from 0000106040-14-000002:notes:28]

[0000106040-14-000007:notes:33]
|  | Amount of Gain Recognized inAccumulated OCI on Derivatives | Location ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome | Amount of Gain (Loss) ReclassifiedFrom Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | ThreeMonthsEnded |  | NineMonthsEnded |  | ThreeMonthsEnded |  | NineMonthsEnded | ThreeMonthsEnded |  | NineMonthsEnded |  | ThreeMonthsEnded |  | NineMonthsEnded |
| March 28, 2014 |  | March 29, 2013 | March 28, 2014 |  | March 29, 2013 |
| Foreign exchange contracts | $ | 13 |  |  | $ | 2 |  |  | $ | 18 |  |  | $ | 64 |  | Cost of revenue | $ | (32 | ) |  | $ | (28 | ) |  | $ | 13 |  |  | $ | 32 |  |

[0000106040-14-000007:notes:34]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three and nine months ended March 28, 2014 and March 29, 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000106040-14-000007:notes:35]
[same as prior period, unchanged from 0000106040-14-000002:notes:31]

[0000106040-14-000007:notes:36]
[same as prior period, unchanged from 0000106040-14-000002:notes:32]

[0000106040-14-000007:notes:37]
[same as prior period, unchanged from 0000106040-14-000002:notes:33]

[0000106040-14-000007:notes:38]
During the three and nine months ended March 28, 2014, the Company recognized in expense $24 million and $69 million, respectively, for stock-based compensation related to the vesting of options issued under the Company’s stock plans and the ESPP, as compared to $21 million and $70 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $6 million and $17 million in the three and nine months ended March 28, 2014, respectively, as compared to $6 million and $19 million in the three and nine months ended March 29, 2013, respectively. As of March 28, 2014, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $137 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.3 years.

[0000106040-14-000007:notes:39]
During the three and nine months ended March 28, 2014, the Company recognized in expense $17 million and $56 million, respectively, for stock-based compensation related to the vesting of awards of RSUs issued under the Company's stock plans, as compared to $15 million and $40 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $5 million and $14 million in the three and nine months ended March 28, 2014, respectively, as compared to $4 million and $11 million in the three and nine months ended March 29, 2013. As of March 28, 2014, the aggregate unamortized fair value of all unvested RSUs was $107 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.5 years. RSUs include performance stock unit awards (“PSUs”). The effect of PSUs was immaterial to the condensed consolidated financial statements in the three and nine months ended March 28, 2014 and March 29, 2013.

[0000106040-14-000007:notes:40]
During the three and nine months ended March 28, 2014, the Company recognized in expense $11 million and $35 million, respectively, related to adjustments to market value as well as the vesting of stock appreciation rights (“SARs”), as compared to $12 million and $28 million in the respective prior-year periods. The tax benefit realized as a result of the aforementioned SARs expense was $2 million and $7 million in the three and nine months ended March 28, 2014, respectively, as compared to $3 million and $7 million in the three and nine months ended March 29, 2013, respectively. The SARs will be settled in cash upon exercise. As a result, the Company had a total liability of $75 million related to SARs included in accrued expenses in the condensed consolidated balance sheet as of March 28, 2014. In addition, as of March 28, 2014, total compensation cost related to unvested SARs issued to employees but not yet recognized was $1 million and will be recognized over the remainder of calendar 2014.

[0000106040-14-000007:notes:41]
[same as prior period, unchanged from 0000106040-14-000002:notes:37]

[0000106040-14-000007:notes:42]
[same as prior period, unchanged from 0000106040-14-000002:notes:38]

[0000106040-14-000007:notes:43]
|  | NumberofShares |  | WeightedAverageExercisePricePerShare |  | WeightedAverageRemainingContractualLife(in years) |  | AggregateIntrinsicValue |
| Options outstanding at June 28, 2013 | 11.9 |  |  | $ | 29.47 |  |  |  |  |  |
| Granted | 1.6 |  |  | 68.40 |  |  |  |  |  |
| Assumed in acquisition | 0.4 |  |  | 117.41 |  |  |  |  |  |
| Exercised | (0.7 | ) |  | 30.14 |  |  |  |  |  |
| Canceled or expired | (0.1 | ) |  | 29.93 |  |  |  |  |  |
| Options outstanding at September 27, 2013 | 13.1 |  |  | 36.77 |  |  |  |  |  |
| Assumed in acquisition | 1.3 |  |  | 12.32 |  |  |  |  |  |
| Exercised | (1.6 | ) |  | 25.34 |  |  |  |  |  |
| Canceled or expired | (0.3 | ) |  | 76.28 |  |  |  |  |  |
| Options outstanding at December 27, 2013 | 12.5 |  |  | 34.99 |  |  |  |  |  |
| Exercised | (1.0 | ) |  | 28.15 |  |  |  |  |  |
| Canceled or expired | (0.1 | ) |  | 60.21 |  |  |  |  |  |
| Options outstanding at March 28, 2014 | 11.4 |  |  | $ | 35.32 |  |  | 4.7 |  | $ | 623 |  |
| Exercisable at March 28, 2014 | 5.2 |  |  | $ | 28.48 |  |  | 3.1 |  | $ | 329 |  |
| Vested and expected to vest after March 28, 2014 | 11.2 |  |  | $ | 35.11 |  |  | 4.6 |  | $ | 616 |  |

[0000106040-14-000007:notes:44]
If an option has an exercise price that is less than the quoted price of the Company’s common stock at the particular time, the aggregate intrinsic value of that option at that time is calculated based on the difference between the exercise price of the underlying options and the quoted price of the Company’s common stock at that time. As of March 28, 2014, the Company had options outstanding to purchase an aggregate of 11.2 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $623 million at that date. During the three and nine months ended March 28, 2014, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $60 million and $164 million, respectively, determined as of the date of exercise, as compared to $41 million and $120 million in the respective prior-year periods.

[0000106040-14-000007:notes:45]
[same as prior period, unchanged from 0000106040-14-000002:notes:41]

[0000106040-14-000007:notes:46]
[same as prior period, unchanged from 0000106040-14-000002:notes:42]

[0000106040-14-000007:notes:47]
|  | Numberof Shares |  | Weighted AverageGrant-DateFair Value |
| RSUs outstanding at June 28, 2013 | 3.6 |  |  | $ | 35.82 |  |
| Granted | 1.3 |  |  | 68.41 |  |
| Assumed in acquisition | 0.2 |  |  | 62.73 |  |
| Vested | (0.9 | ) |  | 29.73 |  |
| RSUs outstanding at September 27, 2013 | 4.2 |  |  | 48.39 |  |
| Granted | 0.1 |  |  | 74.54 |  |
| Vested | (0.2 | ) |  | 42.86 |  |
| Forfeited | (0.1 | ) |  | 46.19 |  |
| RSUs outstanding at December 27, 2013 | 4.0 |  |  | 49.10 |  |
| Vested | (0.1 | ) |  | 44.57 |  |
| RSUs outstanding at March 28, 2014 | 3.9 |  |  | $ | 49.29 |  |
| Expected to vest after March 28, 2014 | 3.7 |  |  | $ | 49.02 |  |

[0000106040-14-000007:notes:48]
The fair value of each RSU is the market price of the Company’s stock at the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of vesting of the units. The grant-date fair value of the shares underlying the RSU awards at the date of grant was $93 million in the nine months ended March 28, 2014. These amounts are being recognized to expense over the corresponding vesting periods. The Company has assumed a forfeiture rate of 3.9% and 3.3% for the three and nine months ended March 28, 2014, respectively, based on a historical analysis indicating forfeitures for these types of awards.

[0000106040-14-000007:notes:49]
[same as prior period, unchanged from 0000106040-14-000002:notes:45]

[0000106040-14-000007:notes:50]
The share-based compensation liability for SARs is recognized for the portion of fair value for which service has been rendered at the reporting date. The share-based liability is remeasured at each reporting date, using a binomial option-pricing model, through the requisite service period. As of March 28, 2014, 0.9 million SARs were outstanding with a weighted average exercise price of $7.77. There were no SARs granted and all other SARs activity was immaterial to the condensed consolidated financial statements for the three and nine months ended March 28, 2014.

[0000106040-14-000007:notes:51]
[same as prior period, unchanged from 0000106040-14-000002:notes:47]

[0000106040-14-000007:notes:52]
[same as prior period, unchanged from 0000106040-14-000002:notes:48]

[0000106040-14-000007:notes:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2014 |  | March 29, 2013 |  | March 28, 2014 |  | March 29, 2013 |
| Suboptimal exercise factor | 2.29 |  | 1.99 |  | 2.06 |  | 1.90 |
| Range of risk-free interest rates | 0.13% to 2.31% |  | 0.14% to 1.24% |  | 0.10% to 2.44% |  | 0.14% to 1.24% |
| Range of expected stock price volatility | 0.27 to 0.48 |  | 0.41 to 0.51 |  | 0.27 to 0.50 |  | 0.41 to 0.53 |
| Weighted average expected volatility | 0.39 |  | 0.46 |  | 0.43 |  | 0.49 |
| Post-vesting termination rate | 3.29% |  | 2.92% |  | 3.09% |  | 2.14% |
| Dividend yield | 1.34% |  | 1.99% |  | 1.57% |  | 2.41% |
| Fair value | $28.78 |  | $17.31 |  | $24.06 |  | $15.67 |

[0000106040-14-000007:notes:54]
The weighted average expected term of the Company’s stock options granted during the three and nine months ended March 28, 2014 was 5.6 years and 5.0 years, respectively, compared to 4.5 years and 4.0 years in the respective prior-year periods.

[0000106040-14-000007:notes:55]
[same as prior period, unchanged from 0000106040-14-000002:notes:51]

[0000106040-14-000007:notes:56]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the current ESPP are granted on either June 1st or December 1st of each year. ESPP activity was immaterial to the condensed consolidated financial statements for the three and nine months ended March 28, 2014 and March 29, 2013.

[0000106040-14-000007:notes:57]
[same as prior period, unchanged from 0000106040-14-000002:notes:53]

[0000106040-14-000007:notes:58]
Since May 21, 2012, the Company's Board of Directors has authorized an additional $3.0 billion for the repurchase of its common stock and the extension of its stock repurchase program through September 13, 2017. The Company repurchased 2.8 million and 7.1 million shares for a total cost of $244 million and $544 million during the three and nine months ended March 28, 2014, respectively. The remaining amount available to be purchased under the Company’s stock repurchase program as of March 28, 2014 was $1.4 billion. The Company may continue to repurchase its stock as it deems appropriate and market conditions allow. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows and borrowings under the Company's Credit Agreement.

[0000106040-14-000007:notes:59]
[same as prior period, unchanged from 0000106040-14-000002:notes:55]

[0000106040-14-000007:notes:60]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In the three months ended March 28, 2014, the Company declared a cash dividend of $0.30 per share of the Company’s common stock to shareholders of record as of March 28, 2014, totaling $71 million, which was paid on April 15, 2014. In addition, in the three months ended December 27, 2013 and the three months ended September 27, 2013, the Company declared cash dividends of $0.30 per share and $0.25 per share of the Company's common stock to shareholders of record as of December 27, 2013 and September 30, 2013, respectively, for a total of $71 million and $59 million, which were each paid on January 15, 2014 and October 15, 2013, respectively. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:EarningsPerShareTextBlock

[0000106040-14-000007:notes:61]
[same as prior period, unchanged from 0000106040-14-000002:notes:57]

[0000106040-14-000007:notes:62]
[same as prior period, unchanged from 0000106040-14-000002:notes:58]

[0000106040-14-000007:notes:63]
[same as prior period, unchanged from 0000106040-14-000002:notes:59]

[0000106040-14-000007:notes:64]
|  | Three MonthsEnded |  | Nine Months Ended |
|  | March 28, 2014 |  | March 29, 2013 |  | March 28, 2014 |  | March 29, 2013 |
| Net income | $ | 375 |  |  | $ | 391 |  |  | $ | 1,300 |  |  | $ | 1,245 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 235 |  |  | 239 |  |  | 236 |  |  | 242 |  |
| Employee stock options and other | 7 |  |  | 6 |  |  | 6 |  |  | 6 |  |
| Diluted | 242 |  |  | 245 |  |  | 242 |  |  | 248 |  |
| Income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.60 |  |  | $ | 1.64 |  |  | $ | 5.51 |  |  | $ | 5.14 |  |
| Diluted | $ | 1.55 |  |  | $ | 1.60 |  |  | $ | 5.37 |  |  | $ | 5.02 |  |
| Anti-dilutive potential common shares excluded* | 2 |  |  | 4 |  |  | 1 |  |  | 3 |  |

[0000106040-14-000007:notes:65]
[same as prior period, unchanged from 0000106040-14-000002:notes:61]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-14-000007:notes:66]
[same as prior period, unchanged from 0000106040-14-000002:notes:62]

[0000106040-14-000007:notes:67]
[same as prior period, unchanged from 0000106040-14-000002:notes:63]

[0000106040-14-000007:notes:68]
[same as prior period, unchanged from 0000106040-14-000002:notes:64]

[0000106040-14-000007:notes:69]
[same as prior period, unchanged from 0000106040-14-000002:notes:65]

[0000106040-14-000007:notes:70]
[same as prior period, unchanged from 0000106040-14-000002:notes:66]

[0000106040-14-000007:notes:71]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of March 28, 2014, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0000106040-14-000007:notes:72]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 894 |  |  | $ | — |  |  | $ | — |  |  | $ | 894 |  |
| U.S. Treasury securities | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Commercial paper | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total cash equivalents | 894 |  |  | 30 |  |  | — |  |  | 924 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 73 |  |  | — |  |  | 73 |  |
| Commercial paper | — |  |  | 170 |  |  | — |  |  | 170 |  |
| Other | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Total short-term investments | — |  |  | 296 |  |  | — |  |  | 296 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 149 |  |  | — |  |  | 149 |  |
| U.S. Government agency securities | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Auction-rate securities | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Total long-term investments | — |  |  | 174 |  |  | 14 |  |  | 188 |  |
| Foreign exchange contracts | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets at fair value | $ | 894 |  |  | $ | 501 |  |  | $ | 14 |  |  | $ | 1,409 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0000106040-14-000007:notes:73]
[same as prior period, unchanged from 0000106040-14-000002:notes:69]

[0000106040-14-000007:notes:74]
[same as prior period, unchanged from 0000106040-14-000002:notes:70]

[0000106040-14-000007:notes:75]
[same as prior period, unchanged from 0000106040-14-000002:notes:71]

[0000106040-14-000007:notes:76]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party with original maturities of twelve months or less and are recorded within short-term investments in the condensed consolidated balance sheets. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000007:notes:77]
U.S. Government Agency Securities. The Company’s U.S. Government agency securities are investments in fixed income securities sponsored by the U.S. Government and are held in custody by a third party and recorded within short-term investments or long term other assets in the condensed consolidated balance sheets depending on their original maturities. U.S. Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000007:notes:78]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government, are held in custody by a third party and are recorded within cash and cash equivalents or long-term other assets in the condensed consolidated balance sheets depending on their original maturities. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000007:notes:79]
Other. The Company’s other investments include certificates of deposit and bank acceptances which are held in custody by a third party and recorded within cash and cash equivalents or short-term investments in the condensed consolidated balance sheets depending on their original maturities. Certificates of deposit are valued using fixed interest rates and bank acceptances are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-14-000007:notes:80]
Auction-Rate Securities. The Company’s auction-rate securities have maturity dates through 2050, are primarily backed by insurance products and are accounted for as available-for-sale securities. These investments are classified as long-term investments and recorded within other non-current assets in the condensed consolidated balance sheets. Auction-rate securities are valued by a third party using unobservable inputs including indicative bids on similar securities.

[0000106040-14-000007:notes:81]
[same as prior period, unchanged from 0000106040-14-000002:notes:73]

[0000106040-14-000007:notes:82]
In the three and nine months ended March 28, 2014, there were no transfers between levels and no changes in Level 3 financial assets measured on a recurring basis.

[0000106040-14-000007:notes:83]
[same as prior period, unchanged from 0000106040-14-000002:notes:75]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-14-000007:notes:84]
[same as prior period, unchanged from 0000106040-14-000002:notes:76]

[0000106040-14-000007:notes:85]
The Company’s income tax provision for the three and nine months ended March 28, 2014 was $31 million and $105 million, respectively, as compared to $15 million and $207 million in the respective prior-year periods. The Company’s income tax provision for both the three and nine months ended March 29, 2013 reflected a tax benefit of $34 million as a result of the retroactive extension of the U.S. Federal research and experimentation tax credit (“R&D credit”) that was signed into law on January 2, 2013 as part of the American Taxpayer Relief Act of 2012. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013. In addition, the Company recorded an $88 million charge to reduce its previously recognized California deferred tax assets in the nine months ended March 29, 2013 as a result of the enactment of California Proposition 39. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2014 through 2025 and the current year generation of income tax credits.

[0000106040-14-000007:notes:86]
In the three months ended March 28, 2014, the Company recorded a net increase of $6 million in its liability for unrecognized tax benefits. In the nine months ended March 28, 2014, the Company recorded a net increase of $26 million in its liability for unrecognized tax benefits. In addition, the Company recorded a $9 million increase in its liability for unrecognized tax benefits related to the Virident and sTec acquisitions in the nine months ended March 28, 2014. As of March 28, 2014, the Company had a recorded liability for unrecognized tax benefits of approximately $275 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three and nine months ended March 28, 2014.

[0000106040-14-000007:notes:87]
[same as prior period, unchanged from 0000106040-14-000002:notes:79]

[0000106040-14-000007:notes:88]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of March 28, 2014, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000106040-14-000007:notes:89]
The fair value of the Company’s investments classified as available-for-sale securities at March 28, 2014, by remaining contractual maturity were as follows (in millions):

[0000106040-14-000007:notes:90]
|  | Cost Basis |  | Fair Value |
| Due in less than one year: | $ | 296 |  |  | $ | 296 |  |
| Due in one to five years: | 188 |  |  | 188 |  |
| Due thereafter: | — |  |  | — |  |
| Total | $ | 484 |  |  | $ | 484 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-14-000007:notes:91]
5. Legal Proceedings

[0000106040-14-000007:notes:92]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-14-000007:notes:93]
Solely for purposes of this footnote, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the HGST Closing Date. HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-14-000007:notes:94]
Intellectual Property Litigation

[0000106040-14-000007:notes:95]
On June 20, 2008, plaintiff Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and one other company alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. On October 10, 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. A trial in the matter began on July 18, 2011 and concluded on July 26, 2011 with a verdict against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. WD and HGST have filed post-trial motions challenging the verdict. On January 17, 2014, the Court denied the Company’s motion for judgment as a matter of law on invalidity. The Company will evaluate its options for appeal after the Court rules on the remaining post-trial motions. The Company intends to continue to defend itself vigorously in this matter.

[0000106040-14-000007:notes:96]
On December 7, 2009, plaintiff Nazomi Communications (“Nazomi”) filed a complaint in the Eastern District of Texas against WD and seven other companies alleging infringement of U.S. Patent Nos. 7,080,362 and 7,225,436. Nazomi dismissed the Eastern District of Texas suit after filing a similar complaint in the Central District of California on February 8, 2010. The case was subsequently transferred to the Northern District of California on October 14, 2010. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The asserted patents allegedly relate to processor cores capable of Java hardware acceleration. In August 2012, the Court dismissed WD on summary judgment for non-infringement. Nazomi filed a notice of appeal on January 16, 2013. The Federal Circuit heard oral argument on the appeal on November 4, 2013 and affirmed the Court's grant of summary judgment of non-infringement on January 10, 2014. WD intends to continue to defend itself vigorously in this matter.

[0000106040-14-000007:notes:97]
On August 1, 2011, plaintiff Guzik Technical Enterprises (“Guzik”) filed a complaint in the Northern District of California against WD and various of its subsidiaries alleging infringement of U.S. Patent Nos. 6,023,145 and 6,785,085, breach of contract and misappropriation of trade secrets. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The patents asserted by Guzik allegedly relate to devices used to test hard disk drive heads and media. On November 30, 2013, WD entered into a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company recorded an accrual in the three months ended December 27, 2013. Guzik is disputing the enforceability of the agreement and on December 27, 2013, WD filed a motion to enforce the agreement. The Court heard oral argument on WD’s motion on January 31, 2014.  The Court granted WD’s motion to enforce the settlement agreement on March 21, 2014.  WD intends to continue to defend itself vigorously in this matter.

[0000106040-14-000007:notes:98]
On July 9, 2012, Siemens Aktiengesellschaft (“Siemens”) filed a complaint in German court against WD, Western Digital GmbH, and Digital River International, S.a.r.l. alleging patent infringement of European patent no. EP 674769, which claims an artificial antiferromagnetic (AAF) (aka, synthetic antiferromagnetic) structure for giant magneto-resistive (GMR) sensors.  On March 14-15, 2013, Western Digital GmbH filed a response of non-infringement and also filed a separate nullity action.  Siemens separately served WD on July 15, 2013. On March 25, 2014, Siemens filed an extension of the complaint including WDT as a defendant. On March 28, 2014, Siemens filed its response to WD’s noninfringement submission. WD’s rejoinder and WDT’s response to the extension of the complaint is due on June 27, 2014. Siemens will then have until September 5, 2014 to respond to WD’s submission. The oral hearing on infringement is scheduled for October 2, 2014. The oral hearing on the nullity action to challenge the validity of the patent is scheduled for February 3, 2015. WD intends to defend itself vigorously in this matter.

[0000106040-14-000007:notes:99]
On September 5, 2013, plaintiff Lake Cherokee Hard Drive Technologies, LLC (“Lake Cherokee”) filed a complaint in the Eastern District of Texas against: Marvell Asia PTE, Ltd., Samsung Semiconductor, Inc., Seagate Tech. LLC, Seagate Tech. Int’l., Toshiba Corp., Toshiba Am. Elec. Components, Toshiba Am. Inf. Sys., Inc., Toshiba Am. Inf. Equip. (Philippines), Inc., and WDT alleging infringement of US Patent Nos. 5,844,738 and 5,978,162. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’738 and ’162 patents.  The complaint seeks unspecified monetary damages, fees and costs. WDT intends to defend itself vigorously in this matter.

[0000106040-14-000007:notes:100]
On September 25, 2013, plaintiff Lake Cherokee filed a complaint in the Eastern District of Texas against: Marvell Semiconductor, Inc., Marvell Asia PTE, Ltd., Dell Inc., and WDT alleging infringement of US Patent No. 5,583,706. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’706 patent.  The complaint seeks an injunction, unspecified monetary damages, fees and costs. WDT intends to defend itself vigorously in this matter.

[0000106040-14-000007:notes:101]
On September 9, 2013, plaintiff Garnet Digital, LLC ("Garnet Digital") filed a complaint in the Eastern District of Texas against WDT, alleging infringement of US Patent No. 5,379,421. Garnet Digital alleges that the WD TV Live product infringes the ’421 patent. The complaint seeks unspecified monetary damages, fees and costs.  On January 21, 2014, WDT and Garnet Digital reached a settlement in this matter for an amount that was not material to the Company's financial position, results of operations or cash flows. On February 4, 2014, the United States District Court for the Eastern District of Texas issued an order that all claims against WD are dismissed with prejudice.

[0000106040-14-000007:notes:102]
Seagate Matter

[0000106040-14-000007:notes:103]
On October 4, 2006, plaintiff Seagate Technology LLC (“Seagate”) filed an action in the District Court of Hennepin County, Minnesota, naming as defendants WD and one of its now former employees previously employed by Seagate. The complaint in the action alleged claims based on supposed misappropriation of trade secrets and sought injunctive relief and unspecified monetary damages, fees and costs. On June 19, 2007, WD’s former employee filed a demand for arbitration with the American Arbitration Association. A motion to stay the litigation as against all defendants and to compel arbitration of all Seagate’s claims was granted on September 19, 2007. On September 23, 2010, Seagate filed a motion to amend its claims and add allegations based on the supposed misappropriation of additional confidential information, and the arbitrator granted Seagate’s motion. The arbitration hearing commenced on May 23, 2011 and concluded on July 11, 2011.

[0000106040-14-000007:notes:104]
On November 18, 2011, the sole arbitrator ruled in favor of WD in connection with five of the eight alleged trade secrets at issue, based on evidence that such trade secrets were known publicly at the time the former employee joined WD. Based on a determination that the employee had fabricated evidence, the arbitrator then concluded that WD had to know of the fabrications. As a sanction, the arbitrator precluded any evidence or defense by WD disputing the validity, misappropriation, or use of the three remaining alleged trade secrets by WD, and entered judgment in favor of Seagate with respect to such trade secrets. Using an unjust enrichment theory of damages, the arbitrator issued an interim award against WD in the amount of $525 million plus pre-award interest at the Minnesota statutory rate of 10% per year. In his decision with respect to these three trade secrets, the arbitrator did not question the relevance, veracity or credibility of any of WD’s ten expert and fact witnesses (other than WD’s former employee), nor the authenticity of any other evidence WD presented. On January 23, 2012, the arbitrator issued a final award adding pre-award interest in the amount of $105.4 million for a total final award of $630.4 million. On January 23, 2012, WD filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated. A hearing on the petition to vacate was held on March 1, 2012.

[0000106040-14-000007:notes:105]
On October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award. Specifically, the Court confirmed the arbitration award with respect to each of the five trade secret claims that WD and the former employee had won at the arbitration and vacated the arbitration award with respect to the three trade secret claims that WD and the former employee had lost at the arbitration. The Court ordered that a rehearing be held concerning those three alleged trade secret claims before a new arbitrator.

[0000106040-14-000007:notes:106]
On October 30, 2012, Seagate initiated an appeal of the Court’s decision with the Minnesota Court of Appeals.  On July 22, 2013, the Minnesota Court of Appeals reversed the District Court’s decision and remanded for entry of an order and judgment confirming the arbitration award. The Company strongly disagrees with the decision of the Court of Appeals and believes that the District Court’s decision was correct.   On August 20, 2013, the Company filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, the Company was informed that the Minnesota Supreme Court granted the Company’s petition. The appeal before the Minnesota Supreme Court was fully briefed, and oral argument was held on February 5, 2014. The Company will continue to vigorously defend itself in this matter. In light of uncertainties with respect to this matter, the Company recorded an accrual of $681 million for this matter in its financial statements in the fourth quarter of fiscal 2013 and recorded additional interest totaling $13 million and $39 million in the three and nine months ended March 28, 2014, respectively, which is included within charges related to arbitration award in the condensed consolidated statements of income. This amount is in addition to the $25 million previously accrued in the fourth quarter of fiscal 2011. The total amount accrued of $745 million represents the amount of the final arbitration award, plus interest accrued on the initial arbitration award at the statutory rate of 10% from January 24, 2012 through March 28, 2014.

[0000106040-14-000007:notes:107]
Other Matters

[0000106040-14-000007:notes:108]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties and is therefore not predictable with assurance, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, there can be no assurance with respect to such result, and monetary liability or financial impact to the Company from these other matters could differ materially from those projected.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-14-000007:notes:109]
13. Recent Accounting Pronouncements

[0000106040-14-000007:notes:110]
In February 2013, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2013-02, “Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income” (“ASU 2013-02”). The new standard requires an entity to provide information about the amounts reclassified out of accumulated other comprehensive income by component. The Company adopted this pronouncement in the first quarter of fiscal 2014. Since ASU 2013-02 related only to the presentation and disclosure of information, it did not have a material effect on the Company’s condensed consolidated financial statements.

[0000106040-14-000007:notes:111]
In July 2013, the FASB issued ASU 2013-11, "Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists" ("ASU 2013-11"). The new standard requires the presentation of certain unrecognized tax benefits as reductions to deferred tax assets rather than as liabilities in the condensed consolidated balance sheets when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2013, which for the Company is the first quarter of fiscal 2015. The Company does not expect the adoption of ASU 2013-11 to have a material impact on its condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-14-000007:notes:112]
[same as prior period, unchanged from 0000106040-14-000002:notes:103]

[0000106040-14-000007:notes:113]
The accounting policies followed by Western Digital Corporation (the “Company”) are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the year ended June 28, 2013. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain prior year amounts have been reclassified to conform to the current year presentation. These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the year ended June 28, 2013. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-14-000007:notes:114]
[same as prior period, unchanged from 0000106040-14-000002:notes:105]

[0000106040-14-000007:notes:115]
[same as prior period, unchanged from 0000106040-14-000002:notes:106]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-14-000007:notes:116]
[same as prior period, unchanged from 0000106040-14-000002:notes:107]

[0000106040-14-000007:notes:117]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three and nine months ended March 28, 2014 and March 29, 2013. The expected long-term rate of return on the Japanese plan assets is 3.5%.

[0000106040-14-000007:notes:118]
[same as prior period, unchanged from 0000106040-14-000002:notes:109]

[0000106040-14-000007:notes:119]
|  | March 28, 2014 |  | June 28, 2013 |
| Benefit obligation | $ | 240 |  |  | $ | 234 |  |
| Fair value of plan assets | (178 | ) |  | (167 | ) |
| Unfunded status | $ | 62 |  |  | $ | 67 |  |

[0000106040-14-000007:notes:120]
[same as prior period, unchanged from 0000106040-14-000002:notes:111]

[0000106040-14-000007:notes:121]
|  | March 28, 2014 |  | June 28, 2013 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 61 |  |  | 66 |  |
| Net amount recognized | $ | 62 |  |  | $ | 67 |  |

[0000106040-14-000007:notes:122]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three and nine months ended March 28, 2014 and March 29, 2013. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $13 million in fiscal 2014.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-14-000007:notes:123]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income for the nine months ended March 29, 2013 (in millions):

[0000106040-14-000007:notes:124]
|  | Actuarial Pension Gain (Loss) |  | Foreign Currency Translation Gain (Loss) |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 29, 2012 | $ | (3 | ) |  | $ | 4 |  |  | $ | (16 | ) |  | $ | (15 | ) |
| Other comprehensive income before reclassifications | 7 |  |  | — |  |  | 64 |  |  | 71 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | (4 | ) |  | (32 | ) |  | (36 | ) |
| Net current-period other comprehensive income | 7 |  |  | (4 | ) |  | 32 |  |  | 35 |  |
| Balance at March 29, 2013 | $ | 4 |  |  | $ | — |  |  | $ | 16 |  |  | $ | 20 |  |

[0000106040-14-000007:notes:125]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income for the nine months ended March 28, 2014 (in millions):

[0000106040-14-000007:notes:126]
|  | Actuarial Pension Gain (Loss) |  | Foreign Currency Translation Gain (Loss) |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 28, 2013 | $ | 11 |  |  | $ | — |  |  | $ | (46 | ) |  | $ | (35 | ) |
| Other comprehensive income before reclassifications | — |  |  | — |  |  | 29 |  |  | 29 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Net current-period other comprehensive income | — |  |  | — |  |  | 31 |  |  | 31 |  |
| Balance at March 28, 2014 | $ | 11 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (4 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-14-000007:notes:127]
[same as prior period, unchanged from 0000106040-14-000002:notes:118]

[0000106040-14-000007:notes:128]
|  | Three MonthsEnded |  | Nine MonthsEnded |
|  | March 28, 2014 |  | March 29, 2013 |  | March 28, 2014 |  | March 29, 2013 |
| Warranty accrual, beginning of period | $ | 190 |  |  | $ | 211 |  |  | $ | 187 |  |  | $ | 260 |  |
| Warranty liability assumed as a result of acquisition (see Note 11) | — |  |  | — |  |  | 4 |  |  | — |  |
| Charges to operations | 41 |  |  | 44 |  |  | 125 |  |  | 134 |  |
| Utilization | (56 | ) |  | (56 | ) |  | (162 | ) |  | (167 | ) |
| Changes in estimate related to pre-existing warranties | (2 | ) |  | (7 | ) |  | 19 |  |  | (35 | ) |
| Warranty accrual, end of period | $ | 173 |  |  | $ | 192 |  |  | $ | 173 |  |  | $ | 192 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-14-000007:notes:129]
[same as prior period, unchanged from 0000106040-14-000002:notes:124]

[0000106040-14-000007:notes:130]
[same as prior period, unchanged from 0000106040-14-000002:notes:125]

[0000106040-14-000007:notes:131]
|  | March 28, 2014 |  | June 28,2013 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 204 |  |  | $ | 167 |  |
| Work-in-process | 519 |  |  | 575 |  |
| Finished goods | 554 |  |  | 446 |  |
| Total inventories | $ | 1,277 |  |  | $ | 1,188 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 7,991 |  |  | $ | 7,616 |  |
| Accumulated depreciation | (4,585 | ) |  | (3,916 | ) |
| Property, plant and equipment, net | $ | 3,406 |  |  | $ | 3,700 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 1,016 |  |  | $ | 948 |  |
| Accumulated amortization | (477 | ) |  | (343 | ) |
| Other intangible assets, net | $ | 539 |  |  | $ | 605 |  |

[0000106040-14-000007:notes:132]
[same as prior period, unchanged from 0000106040-14-000002:notes:127]

[0000106040-14-000007:notes:133]
[same as prior period, unchanged from 0000106040-14-000002:notes:128]

[0000106040-14-000007:notes:134]
The long-term portion of the warranty accrual classified in other liabilities was $62 million at March 28, 2014 and $73 million at June 28, 2013.

[0000106040-14-000007:notes:135]
Investments

[0000106040-14-000007:notes:136]
The Company determined no available-for-sale securities were other-than-temporarily impaired in the three and nine months ended March 28, 2014. For more information on the Company's available-for-sale securities, see Note 7 below.

[0000106040-14-000007:notes:137]
[same as prior period, unchanged from 0000106040-14-000002:notes:130]

[0000106040-14-000007:notes:138]
Other comprehensive income (loss) refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss) is comprised of unrealized gains and losses on foreign exchange contracts, foreign currency translation gains and losses, and actuarial gains and losses related to pensions. There were no unrealized gains or losses on the Company's available-for-sale securities in the nine months ended March 28, 2014. In addition, the income tax impact on components of other comprehensive income is immaterial for all periods presented.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-14-000007:notes:139]
[same as prior period, unchanged from 0000106040-14-000002:notes:132]

[0000106040-14-000007:notes:140]
During 2013, the Company incurred charges of $138 million to realign its operations with anticipated market demand. These charges consisted of $109 million of employee termination benefits, $14 million of asset impairment charges and $15 million of contract and other termination charges and were classified as operating expenses and included within employee termination benefits and other charges in the consolidated statements of income. At June 28, 2013, the Company had a liability of $46 million related to these charges. In the nine months ended March 28, 2014, the Company paid $33 million of employee termination benefits and settled $9 million of contract and other termination charges. As a result, the Company's remaining liability totaled $4 million at March 28, 2014 and is expected to be settled by the end of fiscal 2014.
