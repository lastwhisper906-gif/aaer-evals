# WDC MD&A — 0000106040-14-000007


## mdna

[0000106040-14-000007:mdna:1]
[same as prior period, unchanged from 0000106040-14-000002:mdna:1]

[0000106040-14-000007:mdna:2]
[same as prior period, unchanged from 0000106040-14-000002:mdna:2]

[0000106040-14-000007:mdna:3]
[same as prior period, unchanged from 0000106040-14-000002:mdna:3]

[0000106040-14-000007:mdna:4]
[same as prior period, unchanged from 0000106040-14-000002:mdna:4]

[0000106040-14-000007:mdna:5]
| • | expectations regarding industry demand and pricing in the June quarter and the ability of the industry to support this demand; |

[0000106040-14-000007:mdna:6]
[same as prior period, unchanged from 0000106040-14-000002:mdna:6]

[0000106040-14-000007:mdna:7]
[same as prior period, unchanged from 0000106040-14-000002:mdna:7]

[0000106040-14-000007:mdna:8]
[same as prior period, unchanged from 0000106040-14-000002:mdna:8]

[0000106040-14-000007:mdna:9]
[same as prior period, unchanged from 0000106040-14-000002:mdna:9]

[0000106040-14-000007:mdna:10]
[same as prior period, unchanged from 0000106040-14-000002:mdna:10]

[0000106040-14-000007:mdna:11]
[same as prior period, unchanged from 0000106040-14-000002:mdna:11]

[0000106040-14-000007:mdna:12]
[same as prior period, unchanged from 0000106040-14-000002:mdna:12]

[0000106040-14-000007:mdna:13]
[same as prior period, unchanged from 0000106040-14-000002:mdna:13]

[0000106040-14-000007:mdna:14]
[same as prior period, unchanged from 0000106040-14-000002:mdna:14]

[0000106040-14-000007:mdna:15]
[same as prior period, unchanged from 0000106040-14-000002:mdna:15]

[0000106040-14-000007:mdna:16]
[same as prior period, unchanged from 0000106040-14-000002:mdna:16]

[0000106040-14-000007:mdna:17]
[same as prior period, unchanged from 0000106040-14-000002:mdna:17]

[0000106040-14-000007:mdna:18]
[same as prior period, unchanged from 0000106040-14-000002:mdna:18]

[0000106040-14-000007:mdna:19]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0000106040-14-000007:mdna:20]
[same as prior period, unchanged from 0000106040-14-000002:mdna:21]

[0000106040-14-000007:mdna:21]
[same as prior period, unchanged from 0000106040-14-000002:mdna:22]

[0000106040-14-000007:mdna:22]
[same as prior period, unchanged from 0000106040-14-000002:mdna:23]

[0000106040-14-000007:mdna:23]
[same as prior period, unchanged from 0000106040-14-000002:mdna:52]

[0000106040-14-000007:mdna:24]
[same as prior period, unchanged from 0000106040-14-000002:mdna:24]

[0000106040-14-000007:mdna:25]
We are a leading developer and manufacturer of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our principal products are hard disk drives. Our product portfolio also includes solid-state drives ("SSDs"). Hard disk drives are today’s primary storage medium for digital data, with solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.  We currently operate our global business through two independent subsidiaries due to regulatory requirements - HGST and WD.

[0000106040-14-000007:mdna:26]
[same as prior period, unchanged from 0000106040-14-000002:mdna:26]

[0000106040-14-000007:mdna:27]
[same as prior period, unchanged from 0000106040-14-000002:mdna:27]

[0000106040-14-000007:mdna:28]
On October 17, 2013, we acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. Virident was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash and $15 million related to the fair value of stock options assumed. The acquisition is expected to further HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures. The acquisition of Virident did not have a material impact on our condensed consolidated financial statements for the three and nine months ended March 28, 2014.

[0000106040-14-000007:mdna:29]
[same as prior period, unchanged from 0000106040-14-000002:mdna:29]

[0000106040-14-000007:mdna:30]
On September 12, 2013, we completed the acquisition of sTec, a provider of enterprise SSDs. As a result of the acquisition, sTec was fully integrated into our HGST subsidiary and became our wholly owned indirect subsidiary. The acquisition is intended to augment HGST's existing solid-state storage capabilities. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash and $11 million related to the fair value of stock options and RSUs assumed. The acquisition of sTec did not have a material impact on our condensed consolidated financial statements for the three and nine months ended March 28, 2014.

[0000106040-14-000007:mdna:31]
[same as prior period, unchanged from 0000106040-14-000002:mdna:31]

[0000106040-14-000007:mdna:32]
[same as prior period, unchanged from 0000106040-14-000002:mdna:32]

[0000106040-14-000007:mdna:33]
Third Quarter Overview

[0000106040-14-000007:mdna:34]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for Virident, which was acquired on October 17, 2013, sTec, which was acquired on September 12, 2013, and VeloBit, which was acquired on July 10, 2013, are included in our operating results only after the respective dates of acquisition.

[0000106040-14-000007:mdna:35]
For the quarter ended March 28, 2014, we believe that overall hard drive industry shipments totaled approximately 137 million units, up 1% from the prior-year period and down 4% from the December quarter.

[0000106040-14-000007:mdna:36]
[same as prior period, unchanged from 0000106040-14-000002:mdna:36]

[0000106040-14-000007:mdna:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2014 |  | March 29, 2013 |  | March 28, 2014 |  | March 29, 2013 |
| Net revenue | $ | 3,703 |  |  | 100.0 | % |  | $ | 3,764 |  |  | 100.0 | % |  | $ | 11,479 |  |  | 100.0 | % |  | $ | 11,623 |  |  | 100.0 | % |
| Gross profit | 1,060 |  |  | 28.6 |  |  | 1,061 |  |  | 28.2 |  |  | 3,289 |  |  | 28.7 |  |  | 3,313 |  |  | 28.5 |  |
| Total operating expenses | 641 |  |  | 17.3 |  |  | 644 |  |  | 17.1 |  |  | 1,850 |  |  | 16.1 |  |  | 1,826 |  |  | 15.7 |  |
| Operating income | 419 |  |  | 11.3 |  |  | 417 |  |  | 11.1 |  |  | 1,439 |  |  | 12.5 |  |  | 1,487 |  |  | 12.8 |  |
| Net income | 375 |  |  | 10.1 |  |  | 391 |  |  | 10.4 |  |  | 1,300 |  |  | 11.3 |  |  | 1,245 |  |  | 10.7 |  |

[0000106040-14-000007:mdna:38]
The following is a summary of our financial performance for the third quarter of fiscal 2014:

[0000106040-14-000007:mdna:39]
[same as prior period, unchanged from 0000106040-14-000002:mdna:64]

[0000106040-14-000007:mdna:40]
| • | Consolidated net revenue totaled $3.7 billion. |

[0000106040-14-000007:mdna:41]
| • | 53% of our net revenue was derived from non-PC (personal computer) markets, which include enterprise applications, branded products and CE (consumer electronics) products, as compared to 51% in the prior-year period. |

[0000106040-14-000007:mdna:42]
| • | Net revenue derived from enterprise SSDs was $134 million as compared to $92 million in the prior-year period. |

[0000106040-14-000007:mdna:43]
| • | Hard drive unit shipments remained relatively flat from the prior-year period at 60.4 million units. |

[0000106040-14-000007:mdna:44]
| • | Gross margin increased to 28.6%, compared to 28.2% for the prior-year period. |

[0000106040-14-000007:mdna:45]
| • | Operating income was $419 million, an increase of $2 million from the prior-year period. |

[0000106040-14-000007:mdna:46]
| • | We generated $697 million in cash flow from operations in the third quarter of fiscal 2014, and we ended the quarter with $4.6 billion in cash and cash equivalents. |

[0000106040-14-000007:mdna:47]
For the quarter ending June 27, 2014, we expect overall hard drive industry shipments and our revenue to decrease as a result of seasonality.

[0000106040-14-000007:mdna:48]
[same as prior period, unchanged from 0000106040-14-000002:mdna:47]

[0000106040-14-000007:mdna:49]
[same as prior period, unchanged from 0000106040-14-000002:mdna:48]

[0000106040-14-000007:mdna:50]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages andaverage selling price) | March 28, 2014 |  | March 29, 2013 |  | Percentage Change |  | March 28, 2014 |  | March 29, 2013 |  | PercentageChange |
| Net revenue | $ | 3,703 |  |  | $ | 3,764 |  |  | (2 | )% |  | $ | 11,479 |  |  | $ | 11,623 |  |  | (1 | )% |
| Average selling price (per unit)* | $ | 58 |  |  | $ | 61 |  |  | (5 | )% |  | $ | 59 |  |  | $ | 62 |  |  | (5 | )% |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas | 25 | % |  | 27 | % |  |  |  | 26 | % |  | 26 | % |  |  |
| Europe, Middle East and Africa | 21 |  |  | 22 |  |  |  |  | 21 |  |  | 21 |  |  |  |
| Asia | 54 |  |  | 51 |  |  |  |  | 53 |  |  | 53 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEM | 62 | % |  | 60 | % |  |  |  | 63 | % |  | 62 | % |  |  |
| Distributors | 25 |  |  | 26 |  |  |  |  | 24 |  |  | 24 |  |  |  |
| Retailers | 13 |  |  | 14 |  |  |  |  | 13 |  |  | 14 |  |  |  |
| Unit Shipments* |  |  |  |  |  |  |  |  |  |  |  |
| PC | 38.4 |  |  | 39.9 |  |  |  |  | 118.2 |  |  | 121.7 |  |  |  |
| Non-PC | 22.0 |  |  | 20.3 |  |  |  |  | 68.0 |  |  | 60.2 |  |  |  |
| Total units shipped | 60.4 |  |  | 60.2 |  |  | — | % |  | 186.2 |  |  | 181.9 |  |  | 2 | % |

[0000106040-14-000007:mdna:51]
[same as prior period, unchanged from 0000106040-14-000002:mdna:50]

[0000106040-14-000007:mdna:52]
For the quarter ended March 28, 2014, net revenue was $3.7 billion, a decrease of 2% from the prior-year period. For the nine months ended March 28, 2014, net revenue was $11.5 billion, a decrease of 1% from the prior-year period.  These decreases in revenue were primarily due to decreases in average selling prices ("ASPs"), offset in part by increases in total hard drive shipments. Total hard drive shipments increased to 60.4 million units for the quarter ended March 28, 2014 as compared to 60.2 million units in the prior-year period. Total hard drive shipments increased to 186.2 million units for the nine months ended March 28, 2014, as compared to 181.9 million units in the prior-year period. For the quarter ended March 28, 2014, ASP decreased by $3 from the prior-year period, from $61 to $58. For the nine months ended March 28, 2014, ASP decreased by $3 from the prior-year period, from $62 to $59. These decreases in ASP were primarily driven by a competitive pricing environment as well as a change in product mix.

[0000106040-14-000007:mdna:53]
Changes in revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For both the three and nine months ended March 28, 2014, Hewlett-Packard Company accounted for approximately 11% of our net revenue. For the three and nine months ended March 29, 2013, no customer accounted for 10% or more of our net revenue.

[0000106040-14-000007:mdna:54]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended March 28, 2014, these programs represented 8% of gross revenues, flat with both of the respective prior-year

[0000106040-14-000007:mdna:55]
[same as prior period, unchanged from 0000106040-14-000002:mdna:76]

[0000106040-14-000007:mdna:56]
periods. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product.

[0000106040-14-000007:mdna:57]
[same as prior period, unchanged from 0000106040-14-000002:mdna:56]

[0000106040-14-000007:mdna:58]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages) | March 28, 2014 |  | March 29, 2013 |  | Percentage Change |  | March 28, 2014 |  | March 29, 2013 |  | PercentageChange |
| Net revenue | $ | 3,703 |  |  | $ | 3,764 |  |  | (2 | )% |  | $ | 11,479 |  |  | $ | 11,623 |  |  | (1 | )% |
| Gross profit | 1,060 |  |  | 1,061 |  |  | — | % |  | 3,289 |  |  | 3,313 |  |  | (1 | )% |
| Gross margin | 28.6 | % |  | 28.2 | % |  |  |  | 28.7 | % |  | 28.5 | % |  |  |

[0000106040-14-000007:mdna:59]
For the three months ended March 28, 2014, gross margin as a percentage of revenue increased to 28.6% as compared to 28.2% for the prior-year period. For the nine months ended March 28, 2014, gross margin as a percentage of revenue increased slightly to 28.7% as compared to 28.5% for the prior-year period. These increases were primarily due to a change in product mix.

[0000106040-14-000007:mdna:60]
[same as prior period, unchanged from 0000106040-14-000002:mdna:59]

[0000106040-14-000007:mdna:61]
|  | Three MonthsEnded |  |  |  | Nine MonthsEnded |  |  |
| (in millions, except percentages) | March 28, 2014 |  | March 29, 2013 |  | Percentage Change |  | March 28, 2014 |  | March 29, 2013 |  | PercentageChange |
| R&D expense | $ | 426 |  |  | $ | 396 |  |  | 8 | % |  | $ | 1,248 |  |  | $ | 1,170 |  |  | 7 | % |
| SG&A expense | 202 |  |  | 185 |  |  | 9 | % |  | 563 |  |  | 526 |  |  | 7 | % |
| Charges related to arbitration award | 13 |  |  | — |  |  |  |  | 39 |  |  | — |  |  |  |
| Employee termination benefits and other charges | — |  |  | 63 |  |  |  |  | — |  |  | 130 |  |  |  |
| Total operating expenses | $ | 641 |  |  | $ | 644 |  |  |  |  | $ | 1,850 |  |  | $ | 1,826 |  |  |  |

[0000106040-14-000007:mdna:62]
Research and development (“R&D”) expense was $426 million for the three months ended March 28, 2014, an increase of $30 million from the prior-year period. For the nine months ended March 28, 2014, R&D expense was $1.2 billion, an increase of $78 million from the prior-year period. These increases were primarily due to the inclusion of Virident and sTec's R&D expenses from the dates of acquisition, as well as expense related to adjustments to market value on our stock appreciation rights ("SARs"). As a percentage of net revenue, R&D expense increased to 11.5% and 10.9% in both the three and nine months ended March 28, 2014, respectively, compared to 10.5% and 10.1% in the respective prior-year periods.

[0000106040-14-000007:mdna:63]
Selling, general and administrative (“SG&A”) expense was $202 million for the three months ended March 28, 2014, an increase of $17 million from the prior-year period. For the nine months ended March 28, 2014, SG&A expense was $563 million, an increase of $37 million from the prior-year period. These increases were primarily due to the inclusion of Virident and sTec's SG&A expenses from the dates of acquisition, as well as expense related to adjustments to market value on our SARs. SG&A expense as a percentage of net revenue increased to 5.5% and 4.9% in the three and nine months ended March 28, 2014, respectively, compared to 4.9% and 4.5% in the respective prior-year periods.

[0000106040-14-000007:mdna:64]
During the three and nine months ended March 28, 2014, we recorded $13 million and $39 million, respectively, of interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC ("Seagate"), alleging misappropriation of confidential information and trade secrets. For further details see the "Arbitration Award" section below.

[0000106040-14-000007:mdna:65]
During the three months ended March 29, 2013, we recorded charges of $63 million consisting of $54 million of employee termination benefits and $9 million of contract and other termination costs in order to realign our operations with anticipated market demand. During the nine months ended March 29, 2013, we recorded charges of $130 million consisting of $105 million of employee termination benefits, $12 million of asset impairments and $13 million of contract and other termination costs in order to realign our operations with anticipated market demand.

[0000106040-14-000007:mdna:66]
[same as prior period, unchanged from 0000106040-14-000002:mdna:67]

[0000106040-14-000007:mdna:67]
Interest income for the three and nine months ended March 28, 2014 increased $1 million and $2 million, respectively, as compared to the respective prior-year periods primarily due to higher average daily invested cash balances for the periods.

[0000106040-14-000007:mdna:68]
[same as prior period, unchanged from 0000106040-14-000002:mdna:83]

[0000106040-14-000007:mdna:69]
Interest and other expense for the three and nine months ended March 28, 2014 increased $3 million and $1 million, respectively, as compared to the respective prior-year periods primarily due a $4 million write-off of debt issuance costs associated with lenders that extinguished their interest in our newly entered into Credit Agreement (as defined below).

[0000106040-14-000007:mdna:70]
[same as prior period, unchanged from 0000106040-14-000002:mdna:69]

[0000106040-14-000007:mdna:71]
Our income tax provision for the three months ended March 28, 2014 was $31 million as compared to $15 million in the prior-year period. Our income tax provision for the nine months ended March 28, 2014 was $105 million as compared to $207 million in the prior-year period. Our income tax provision for both the three and nine months ended March 29, 2013 reflected a tax benefit of $34 million as a result of the retroactive extension of the U.S. Federal research and experimentation tax credit (“R&D credit”) that was signed into law on January 2, 2013 as part of the American Taxpayer Relief Act of 2012. The R&D credit, which had previously expired on December 31, 2011, was extended through December 31, 2013. In addition, we recorded an $88 million charge to reduce our previously recognized California deferred tax assets in the nine months ended March 29, 2013 as a result of the enactment of California Proposition 39. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2014 through 2025 and the current year generation of income tax credits.

[0000106040-14-000007:mdna:72]
In the three months ended March 28, 2014, we recorded a net increase of $6 million in our liability for unrecognized tax benefits. In the nine months ended March 28, 2014, we recorded a net increase of $26 million in our liability for unrecognized tax benefits. In addition, we recorded a $9 million increase in our liability for unrecognized tax benefits related to the Virident and sTec acquisitions in the nine months ended March 28, 2014. As of March 28, 2014, we had a recorded liability for unrecognized tax benefits of approximately $275 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three and nine months ended March 28, 2014.

[0000106040-14-000007:mdna:73]
[same as prior period, unchanged from 0000106040-14-000002:mdna:72]

[0000106040-14-000007:mdna:74]
We believe that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in our tax audits are resolved in a manner not consistent with management's expectations, we could be required to adjust our provision for income taxes in the period such resolution occurs. As of March 28, 2014, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of our liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of our tax returns.

[0000106040-14-000007:mdna:75]
[same as prior period, unchanged from 0000106040-14-000002:mdna:74]

[0000106040-14-000007:mdna:76]
As disclosed above in Part I, Item 1, Note 5 in the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, on November 18, 2011, a sole arbitrator ruled against us in an arbitration in Minnesota. The arbitration involves claims brought by Seagate against us and a now former employee, alleging misappropriation of confidential information and trade secrets. The arbitrator issued an interim award against us in the amount of $525 million plus pre-award interest. On January 23, 2012, the arbitrator issued a final award adding pre-award interest in the amount of $105.4 million, for a total award of $630.4 million. On January 23, 2012, we filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated, and a hearing on the petition to vacate was held on March 1, 2012. On October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award and ordered that a rehearing be held concerning certain trade secret claims before a new arbitrator. On October 30, 2012, Seagate initiated an appeal of the District Court's decision with the Minnesota Court of Appeals. On July 22, 2013, the Minnesota Court of Appeals reversed the District Court's decision and remanded for entry of an order and judgment confirming the arbitration award. We strongly disagree with the decision of the Court of Appeals and believe that the District Court’s decision was correct. On August 20, 2013, we filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, we were informed that the Minnesota Supreme Court granted our petition.  The appeal before the Minnesota Supreme Court was fully briefed, and oral argument was held on February 5, 2014.  We will continue to vigorously defend ourselves in this matter. In light of uncertainties with respect to

[0000106040-14-000007:mdna:77]
[same as prior period, unchanged from 0000106040-14-000002:mdna:98]

[0000106040-14-000007:mdna:78]
this matter, we recorded an accrual of $681 million for this matter in our financial statements for the three months ended June 28, 2013. This amount was in addition to the $25 million previously accrued in the fourth quarter of fiscal 2011. In the three and nine months ended March 28, 2014, we recorded an additional $13 million and $39 million, respectively, for interest related to the arbitration award. As a result, the total amount accrued of $745 million represents the amount of the final arbitration award, plus interest accrued on the initial arbitration award at the statutory rate of 10% from January 24, 2012 through March 28, 2014.

[0000106040-14-000007:mdna:79]
[same as prior period, unchanged from 0000106040-14-000002:mdna:78]

[0000106040-14-000007:mdna:80]
We ended the first quarter of fiscal 2014 with total cash and cash equivalents of $4.6 billion. The following table summarizes our statements of cash flows (in millions):

[0000106040-14-000007:mdna:81]
|  | Nine Months Ended |
|  | March 28, 2014 |  | March 29, 2013 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 2,104 |  |  | $ | 2,435 |  |
| Investing activities | (1,756 | ) |  | (834 | ) |
| Financing activities | (88 | ) |  | (749 | ) |
| Net increase in cash and cash equivalents | $ | 260 |  |  | $ | 852 |  |

[0000106040-14-000007:mdna:82]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. On January 9, 2014 (the "Closing Date"), the outstanding balance on the existing credit facility entered into on March 8, 2012 (the "Prior Credit Facility") was repaid, the Prior Credit Facility was terminated, and we, along with Western Digital Technologies, Inc. ("WDT") and Western Digital Ireland, Ltd. ("WDI") entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"). The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT, and a $1.5 billion revolving credit facility to WDT and WDI (the "Borrowers"). Subject to certain conditions, a Borrower may also elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. For additional information on the Prior Credit Facility and the Credit Agreement, See Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, stock repurchase and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000106040-14-000007:mdna:83]
A total of $2.8 billion of our cash and cash equivalents was held outside of the United States at both March 28, 2014 and June 28, 2013. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. If we are required to pay the arbitration award described in the section “Arbitration Award” above, the award would be paid from one of our foreign subsidiaries using cash and cash equivalents held outside of the United States. On September 13, 2012, our Board of Directors approved a capital allocation plan which includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-14-000007:mdna:84]
[same as prior period, unchanged from 0000106040-14-000002:mdna:84]

[0000106040-14-000007:mdna:85]
Net cash provided by operating activities was $2.1 billion during the nine months ended March 28, 2014. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash used by working capital changes was $180 million for the nine months ended March 28, 2014 as compared to $77 million provided by working capital changes in the prior-year period.

[0000106040-14-000007:mdna:86]
[same as prior period, unchanged from 0000106040-14-000002:mdna:86]

[0000106040-14-000007:mdna:87]
|  | Three Months Ended |
|  | March 28, 2014 |  | March 29, 2013 |
| Days sales outstanding | 44 |  |  | 41 |  |
| Days in inventory | 44 |  |  | 40 |  |
| Days payables outstanding | (65 | ) |  | (69 | ) |
| Cash conversion cycle | 23 |  |  | 12 |  |

[0000106040-14-000007:mdna:88]
For the three months ended March 28, 2014, our average days sales outstanding (“DSOs”) increased by 3 days, days in inventory (“DIOs”) increased by 4 days, and days payable outstanding (“DPOs”) decreased by 4 days compared to the prior year period. Changes in average DSOs and DIOs are generally related to linearity of shipments and the timing of inventory builds, respectively. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-14-000007:mdna:89]
[same as prior period, unchanged from 0000106040-14-000002:mdna:89]

[0000106040-14-000007:mdna:90]
Cash used in investing activities for the nine months ended March 28, 2014 was $1.8 billion and consisted primarily of $823 million related to acquisitions, net of cash acquired, $470 million of investments in available-for-sale securities and $467 million of capital expenditures, partially offset by a net $4 million for other investing activities, consisting of a flood-related insurance recovery and strategic investments. Cash used in investing activities for the nine months ended March 29, 2013 was $834 million and consisted primarily of $816 million of capital expenditures and $17 million related to the purchase of investments.

[0000106040-14-000007:mdna:91]
Our cash equivalents are invested in highly liquid money market funds that are invested in U.S. Treasury securities and U.S. Government Agency securities. In addition, we invest directly in U.S. Treasury securities, U.S. Government Agency securities, commercial paper, bank acceptances and certificates of deposit. We also have $14 million of auction-rate securities, which are classified as available-for-sale securities in our condensed consolidated balance sheets.

[0000106040-14-000007:mdna:92]
[same as prior period, unchanged from 0000106040-14-000002:mdna:92]

[0000106040-14-000007:mdna:93]
Net cash used in financing activities for the nine months ended March 28, 2014 was $88 million as compared to $749 million in the prior-year period. Net cash used in financing activities for the nine months ended March 28, 2014 consisted of $2.5 billion of debt proceeds related to the term loan facility under the Credit Agreement, net of issuance costs, $500 million of debt proceeds related to the revolving credit facility under the Prior Credit Facility and a net $139 million provided by employee stock plans, offset by $2.5 billion used to make principal payments on the Prior Credit Facility before termination, used to repay the outstanding balance on the Prior Credit Facility at termination, and used to make principal payments on the Credit Agreement, $544 million used to repurchase shares of our common stock and $189 million used to pay dividends on our common stock. Net cash used in financing activities for the nine months ended March 29, 2013 consisted of $607 million used to repurchase shares of our common stock, $121 million used to pay dividends on our common stock and $173 million used to repay long-term debt, offset by a net $152 million provided by employee stock plans.

[0000106040-14-000007:mdna:94]
[same as prior period, unchanged from 0000106040-14-000002:mdna:94]

[0000106040-14-000007:mdna:95]
[same as prior period, unchanged from 0000106040-14-000002:mdna:95]

[0000106040-14-000007:mdna:96]
[same as prior period, unchanged from 0000106040-14-000002:mdna:96]

[0000106040-14-000007:mdna:97]
Long-Term Debt — On March 8, 2012, we, in our capacity as the parent entity and guarantor, WDT and WDI, entered into the Prior Credit Facility. The Prior Credit Facility provided for $2.8 billion of unsecured loan facilities, consisting of a $2.3 billion term loan facility and a $500 million revolving credit facility. On January 9, 2014, the outstanding balance on the Prior Credit Facility was repaid, the Prior Credit Facility was terminated, and the new Credit Agreement was entered into.

[0000106040-14-000007:mdna:98]
As of March 28, 2014, no amounts were outstanding under the revolving credit facility of the Credit Agreement and the term loan facility had an outstanding balance of $2.5 billion and a variable interest rate of 1.66%. We are required to make quarterly principal payments on the term loan facility totaling $31 million for the remainder of fiscal 2014, $125 million in fiscal

[0000106040-14-000007:mdna:99]
2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. For additional information, see Part I, Item 1, Note 4 in the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-14-000007:mdna:100]
[same as prior period, unchanged from 0000106040-14-000002:mdna:101]

[0000106040-14-000007:mdna:101]
[same as prior period, unchanged from 0000106040-14-000002:mdna:102]

[0000106040-14-000007:mdna:102]
[same as prior period, unchanged from 0000106040-14-000002:mdna:103]

[0000106040-14-000007:mdna:103]
[same as prior period, unchanged from 0000106040-14-000002:mdna:104]

[0000106040-14-000007:mdna:104]
[same as prior period, unchanged from 0000106040-14-000002:mdna:105]

[0000106040-14-000007:mdna:105]
[same as prior period, unchanged from 0000106040-14-000002:mdna:106]

[0000106040-14-000007:mdna:106]
[same as prior period, unchanged from 0000106040-14-000002:mdna:107]

[0000106040-14-000007:mdna:107]
Unrecognized Tax Benefits — As of March 28, 2014, the cash portion of our total recorded liability for unrecognized tax benefits was $239 million. We estimate the timing of the future payments of these liabilities to be within the next one to eight years. See Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-14-000007:mdna:108]
Stock Repurchase Program — Since May 21, 2012, our Board of Directors has authorized an additional $3.0 billion for the repurchase of our common stock and the extension of our stock repurchase program until September 13, 2017. We repurchased 2.8 million and 7.1 million shares of our common stock for a total cost of $244 million and $544 million during the three and nine months ended March 28, 2014, respectively. The remaining amount available to be purchased under our stock repurchase program as of March 28, 2014 was $1.4 billion. Subsequent to March 28, 2014 and through May 1, 2014, we repurchased an additional 0.6 million shares of our common stock for a total cost of $52 million. We may continue to repurchase our common stock as we deem appropriate and market conditions allow. Repurchases under our stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect stock repurchases to be funded principally by operating cash flows and borrowings under our Credit Agreement.

[0000106040-14-000007:mdna:109]
Cash Dividend Policy — On September 13, 2012, we announced that our Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of our common stock receive dividends when and as declared by our Board of Directors. In the three months ended March 28, 2014, we declared a cash dividend of $0.30 per share of our common stock to our shareholders of record as of March 28, 2014, totaling $71 million, which we paid on April 15, 2014. In addition, in the three months ended December 27, 2013 and September 27, 2013, the Company declared cash dividends of $0.30 and $0.25 per share, respectively, of the Company's common stock to shareholders of record as of December 27, 2013 and September 30, 2013, respectively, for a total of $71 million and $59 million which were each paid on January 15, 2014 and October 15, 2013, respectively. We may modify, suspend or cancel our cash dividend policy in any manner and at any time.

[0000106040-14-000007:mdna:110]
[same as prior period, unchanged from 0000106040-14-000002:mdna:112]

[0000106040-14-000007:mdna:111]
We have prepared the unaudited condensed consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the year ended June 28, 2013.

[0000106040-14-000007:mdna:112]
[same as prior period, unchanged from 0000106040-14-000002:mdna:114]

[0000106040-14-000007:mdna:113]
In accordance with standard industry practice, we provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions, and we provide resellers and original equipment manufacturers ("OEMs") with other sales incentive programs. At the time we recognize revenue to resellers and OEMs, we record a reduction of revenue for estimated price protection until the resellers sell such inventory to their customers and we also record a reduction of revenue for the other programs in effect. We base these adjustments on several factors including anticipated price decreases during the reseller holding period, resellers’ sell-through and inventory levels, estimated amounts to be reimbursed to qualifying customers, historical pricing information and customer claim processing. If customer demand for our products or market conditions differs from our expectations, our operating results could be materially affected. We also have programs under which we reimburse qualified distributors and retailers for certain marketing expenditures, which are recorded as a reduction of revenue. These amounts generally vary according to several factors including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Generally, total sales incentive and marketing programs range from 7% to 11% of gross revenues per quarter. For the three months ended March 28, 2014, sales incentive and marketing programs were 8% of gross revenues. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.8% of quarterly gross revenue since the first quarter of fiscal 2013. Customer sales incentive and marketing programs are recorded as a reduction of revenue.

[0000106040-14-000007:mdna:114]
[same as prior period, unchanged from 0000106040-14-000002:mdna:116]

[0000106040-14-000007:mdna:115]
[same as prior period, unchanged from 0000106040-14-000002:mdna:117]

[0000106040-14-000007:mdna:116]
[same as prior period, unchanged from 0000106040-14-000002:mdna:118]

[0000106040-14-000007:mdna:117]
We record an accrual for estimated warranty costs when revenue is recognized. We generally warrant our products for a period of one to five years. Our warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. We use a statistical warranty tracking model to help prepare our estimates and assist us in exercising judgment in determining the underlying estimates. Our statistical tracking model captures specific detail on hard drive reliability, such as factory test data, historical field return rates, and costs to repair by product type. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base our warranty estimates. We review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period

[0000106040-14-000007:mdna:118]
gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from our estimates, our future results of operations could be materially affected. For a summary of historical changes in estimates related to pre-existing warranty provisions, refer to Part I, Item 1, Note 2 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-14-000007:mdna:119]
[same as prior period, unchanged from 0000106040-14-000002:mdna:121]

[0000106040-14-000007:mdna:120]
[same as prior period, unchanged from 0000106040-14-000002:mdna:122]

[0000106040-14-000007:mdna:121]
[same as prior period, unchanged from 0000106040-14-000002:mdna:123]

[0000106040-14-000007:mdna:122]
Litigation and Other Contingencies

[0000106040-14-000007:mdna:123]
When we become aware of a claim or potential claim, we assess the likelihood of any loss or exposure. We disclose information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. Refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-14-000007:mdna:124]
[same as prior period, unchanged from 0000106040-14-000002:mdna:126]

[0000106040-14-000007:mdna:125]
[same as prior period, unchanged from 0000106040-14-000002:mdna:127]

[0000106040-14-000007:mdna:126]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-14-000007:mdna:127]
[same as prior period, unchanged from 0000106040-14-000002:mdna:129]

[0000106040-14-000007:mdna:128]
We account for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of all stock options and SARs granted are estimated using a binomial option-pricing model, and the fair values of all Employee Stock Purchase Plan purchase rights are estimated using the Black-Scholes-Merton option-pricing model. We account for SARs as liability awards based upon our intention to settle such awards in cash. The SARs liability is recognized for that portion of fair value for the

[0000106040-14-000007:mdna:129]
service period rendered at the reporting date. The share-based liability is remeasured at each reporting date through the requisite service period. Both the binomial and the Black-Scholes-Merton models require the input of highly subjective assumptions. We are required to use judgment in estimating the amount of stock-based awards that are expected to be forfeited. If actual forfeitures differ significantly from the original estimate, stock-based compensation expense and our results of operations could be materially affected.

[0000106040-14-000007:mdna:130]
[same as prior period, unchanged from 0000106040-14-000002:mdna:131]

[0000106040-14-000007:mdna:131]
[same as prior period, unchanged from 0000106040-14-000002:mdna:132]

[0000106040-14-000007:mdna:132]
[same as prior period, unchanged from 0000106040-14-000002:mdna:133]

[0000106040-14-000007:mdna:133]
[same as prior period, unchanged from 0000106040-14-000002:mdna:134]

[0000106040-14-000007:mdna:134]
[same as prior period, unchanged from 0000106040-14-000002:mdna:135]

[0000106040-14-000007:mdna:135]
[same as prior period, unchanged from 0000106040-14-000002:mdna:136]

[0000106040-14-000007:mdna:136]
[same as prior period, unchanged from 0000106040-14-000002:mdna:137]
