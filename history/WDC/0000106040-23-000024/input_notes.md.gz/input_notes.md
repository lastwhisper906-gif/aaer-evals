# WDC notes — 0000106040-23-000024


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000106040-23-000024:notes:1]
Part III incorporates by reference certain information from the registrant’s definitive proxy statement (the “Proxy Statement”) for the 2023 Annual Meeting of Stockholders, which will be filed with the Securities and Exchange Commission within 120 days after the end of the 2023 fiscal year. Except with respect to information specifically incorporated by reference in this Form 10-K, the Proxy Statement is not deemed to be filed as part hereof.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-23-000024:notes:2]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both NAND flash and hard disk drive technologies.

[0000106040-23-000024:notes:3]
The Company’s broad portfolio of technology and products address the following key end markets: Cloud, Client and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property (“IP”) portfolio, which is included in each of these three end market categories.

[0000106040-23-000024:notes:4]
Basis of Presentation

[0000106040-23-000024:notes:5]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-23-000024:notes:6]
Fiscal Year

[0000106040-23-000024:notes:7]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, 2022, and 2021, which ended on June 30, 2023, July 1, 2022 and July 2, 2021, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated basis.

[0000106040-23-000024:notes:8]
Segment Reporting

[0000106040-23-000024:notes:9]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”).

[0000106040-23-000024:notes:10]
The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), evaluates the performance of the Company and makes decisions regarding the allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are either not available or not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000106040-23-000024:notes:11]
Basis of Consolidation

[0000106040-23-000024:notes:12]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from the remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in Accumulated other comprehensive loss, a component of shareholders’ equity.

[0000106040-23-000024:notes:13]
Use of Estimates

[0000106040-23-000024:notes:14]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of current macroeconomic conditions. However, actual results could differ materially from these estimates.

[0000106040-23-000024:notes:15]
Cash Equivalents

[0000106040-23-000024:notes:16]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. These deposits are typically in excess of U.S. insured limits. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.

[0000106040-23-000024:notes:17]
Equity Investments

[0000106040-23-000024:notes:18]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income, net, in the Consolidated Statements of Operations and were immaterial for all years presented.

[0000106040-23-000024:notes:19]
If the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over the operating and financial policies of the investee, the Company accounts for these investments at fair value, or if these equity securities do not have a readily determinable fair value, these securities are measured and recorded using the measurement alternative under Accounting Standards Update (“ASU”) No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities,” which is cost minus impairment, if any, plus or minus changes resulting from observable price changes. Previously, these investments were accounted for under the cost method of accounting. These investments are recorded within Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-23-000024:notes:20]
Variable Interest Entities

[0000106040-23-000024:notes:21]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-23-000024:notes:22]
Fair Value of Financial Instruments

[0000106040-23-000024:notes:23]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The carrying value of notes receivable from Flash Ventures also approximates fair value for all periods presented because they bear variable market rates of interest. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-23-000024:notes:24]
Inventories

[0000106040-23-000024:notes:25]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-23-000024:notes:26]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write-down of inventory that could materially affect operating results.

[0000106040-23-000024:notes:27]
Property, Plant and Equipment

[0000106040-23-000024:notes:28]
Property, plant, and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings and improvements are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-23-000024:notes:29]
Goodwill and Other Long-Lived Assets

[0000106040-23-000024:notes:30]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company’s assessment resulted in no impairment of goodwill in 2023, 2022, or 2021.

[0000106040-23-000024:notes:31]
The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on the results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-23-000024:notes:32]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test at least annually or whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment on the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-23-000024:notes:33]
Other long-lived assets are depreciated or amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow. See Note 5, Supplemental Financial Statement Data, for additional disclosures related to the Company’s other intangible assets.

[0000106040-23-000024:notes:34]
Revenue and Accounts Receivable

[0000106040-23-000024:notes:35]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not considered constrained based on the Company’s history with similar transactions and the fact that uncertainties are resolved in a fairly short period of time.

[0000106040-23-000024:notes:36]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes professional service arrangements and post-contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right-to-use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right-to-access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-23-000024:notes:37]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-23-000024:notes:38]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics.

[0000106040-23-000024:notes:39]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed-upon sales incentive programs. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0000106040-23-000024:notes:40]
Marketing development program costs are typically recorded as a reduction of the transaction price and, therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-23-000024:notes:41]
For contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. If applicable, the Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices.

[0000106040-23-000024:notes:42]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency or other collection issues. In addition, the Company routinely analyzes the various receivable aging categories to establish reserves based on a combination of past-due receivables and expected future losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss trajectory changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-23-000024:notes:43]
Warranty

[0000106040-23-000024:notes:44]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0000106040-23-000024:notes:45]
Litigation and Other Contingencies

[0000106040-23-000024:notes:46]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 17, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-23-000024:notes:47]
Advertising Expense

[0000106040-23-000024:notes:48]
Advertising costs are expensed as incurred and amounted to $69 million, $88 million and $84 million in 2023, 2022 and 2021, respectively. These expenses are included in Selling, general and administrative in the Consolidated Statements of Operations.

[0000106040-23-000024:notes:49]
Research and Development Expense

[0000106040-23-000024:notes:50]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-23-000024:notes:51]
Income Taxes

[0000106040-23-000024:notes:52]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-23-000024:notes:53]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.

[0000106040-23-000024:notes:54]
Net Income (Loss) Per Common Share

[0000106040-23-000024:notes:55]
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.

[0000106040-23-000024:notes:56]
The Company computes basic income (loss) per common share by dividing net income (loss) attributable to common shareholders by the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed by using diluted net income (loss) attributable to common shareholders, the weighted average number of common shares and potentially dilutive securities outstanding during the period using the treasury stock method or the “if-converted” method based on the nature of the securities. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”) and restricted stock unit awards with performance conditions or market conditions (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”), shares issuable in connection with the 1.50% convertible notes due 2024, and the convertible preferred stock.

[0000106040-23-000024:notes:57]
Stock-based Compensation

[0000106040-23-000024:notes:58]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of RSUs and PSUs with a performance condition are determined based on the closing market price of the Company’s stock on the date of the grant. The fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model and require the input of highly subjective assumptions. The fair values of PSUs with a market condition are estimated using a Monte Carlo simulation model. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance or market conditions. Once these conditions are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs with a performance condition will be earned and records the related stock-based compensation expense over the service period. Compensation expense for PSUs with market conditions is recognized ratably over the required service period regardless of expected or actual achievement.

[0000106040-23-000024:notes:59]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-23-000024:notes:60]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is primarily comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-23-000024:notes:61]
Derivative Contracts

[0000106040-23-000024:notes:62]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. Substantially all of these contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Thai baht, Korean won and Israeli shekel, which had an aggregate notional amount of $5.66 billion and $6.07 billion at June 30, 2023 and July 1, 2022, respectively.

[0000106040-23-000024:notes:63]
If the derivative is designated as a cash flow hedge and is determined to be highly effective, the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in Cost of revenue and Operating expenses, and presented within cash flows from operating activities. The Company previously had interest rate swaps which were accounted for as designated cash flow hedges to mitigate variations in interest payments under a portion of its variable rate term loans. The Company paid interest monthly at a fixed rate and received interest monthly at the applicable index rate on the notional amount of the contract with realized gains or losses recognized in Interest expense. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-23-000024:notes:64]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income, net.

[0000106040-23-000024:notes:65]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-23-000024:notes:66]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with actuarial changes in the funded status recognized through accumulated other comprehensive loss in the year in which such changes occur.

[0000106040-23-000024:notes:67]
The Company reports the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are presented in Other income, net in the Consolidated Statements of Operations.

[0000106040-23-000024:notes:68]
Leases

[0000106040-23-000024:notes:69]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-23-000024:notes:70]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-23-000024:notes:71]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. The Company adopted the new standard effective July 2, 2022, the first day of the year ending June 30, 2023, using the modified retrospective method. On the date of adoption, the Company recorded a reduction in Additional paid-in capital of $128 million, a reduction of unamortized debt discount of $48 million, a reduction of deferred income tax liabilities of $11 million, and an increase to retained earnings of $91 million for 2023 for the after-tax impact of previously recognized amortization of the debt discount associated with the Company’s convertible senior notes. Amortization of debt discount included in Interest expense in the Consolidated Statements of Operations, under the previous accounting method was $29 million and $27 million in 2022 and 2021, respectively.

[0000106040-23-000024:notes:72]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. The Company adopted this standard on July 2, 2022, the first day of fiscal 2023 and the adoption did not have a material impact on its Consolidated Financial Statements.

[0000106040-23-000024:notes:73]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-23-000024:notes:74]
In September 2022, the FASB issued ASU No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”. This guidance requires entities that use supplier finance programs in connection with the purchase of goods and services to provide interim disclosures of the amount of outstanding supplier-financed purchases and annual disclosure of rollforward information related to those programs. The ASU is effective for fiscal years beginning after December 15, 2022, which for the Company is the first quarter of 2024 (except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023, which for the Company is the first quarter of 2025), with early adoption permitted. The Company is currently compiling the information required for these disclosures.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-23-000024:notes:75]
Business Segments, Geographic Information, and Concentrations of Risk 
The following table summarizes the operating performance of the Company’s reportable segments:

[0000106040-23-000024:notes:76]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Flash | $ | 6,063 |  |  | $ | 9,753 |  |  | $ | 8,706 |  |
| HDD | 6,255 |  |  | 9,040 |  |  | 8,216 |  |
| Total net revenue | $ | 12,318 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |
| Gross profit: |  |  |  |  |  |
| Flash | $ | 433 |  |  | $ | 3,527 |  |  | $ | 2,611 |  |
| HDD | 1,505 |  |  | 2,661 |  |  | 2,221 |  |
| Total gross profit for segments | 1,938 |  |  | 6,188 |  |  | 4,832 |  |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation expense | (49) |  |  | (48) |  |  | (55) |  |
| Amortization of acquired intangible assets | — |  |  | (66) |  |  | (331) |  |
| Contamination related charges | — |  |  | (207) |  |  | — |  |
| Recoveries from a power outage incident | — |  |  | 7 |  |  | 75 |  |
| Other | (2) |  |  | — |  |  | — |  |
| Total unallocated corporate items | (51) |  |  | (314) |  |  | (311) |  |
| Consolidated gross profit | $ | 1,887 |  |  | $ | 5,874 |  |  | $ | 4,521 |  |
| Gross margin: |  |  |  |  |  |
| Flash | 7.1 | % |  | 36.2 | % |  | 30.0 | % |
| HDD | 24.1 | % |  | 29.4 | % |  | 27.0 | % |
| Consolidated gross margin | 15.3 | % |  | 31.3 | % |  | 26.7 | % |

[0000106040-23-000024:notes:77]
Disaggregated Revenue

[0000106040-23-000024:notes:78]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-23-000024:notes:79]
The Company’s disaggregated revenue information is as follows:

[0000106040-23-000024:notes:80]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |
| Cloud | $ | 5,252 |  |  | $ | 8,017 |  |  | $ | 5,723 |  |
| Client | 4,328 |  |  | 7,076 |  |  | 7,281 |  |
| Consumer | 2,738 |  |  | 3,700 |  |  | 3,918 |  |
| Total Revenue | $ | 12,318 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |

[0000106040-23-000024:notes:81]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe, the Middle East, and Africa. The following tables summarize the Company’s operations by geographic area:

[0000106040-23-000024:notes:82]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Net revenue (1) |  |  |  |  |  |
| United States | $ | 3,810 |  |  | $ | 5,411 |  |  | $ | 3,789 |  |
| China | 2,773 |  |  | 4,525 |  |  | 4,339 |  |
| Hong Kong | 1,829 |  |  | 3,645 |  |  | 3,624 |  |
| Rest of Asia | 1,444 |  |  | 1,884 |  |  | 1,492 |  |
| Europe, Middle East and Africa | 2,100 |  |  | 2,872 |  |  | 3,061 |  |
| Other | 362 |  |  | 456 |  |  | 617 |  |
| Total | $ | 12,318 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |

[0000106040-23-000024:notes:83]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee.

[0000106040-23-000024:notes:84]
|  | 2023 |  | 2022 |
|  | (in millions) |
| Long-lived assets (1) |  |  |  |
| United States | $ | 1,071 |  |  | $ | 1,130 |  |
| Malaysia | 861 |  |  | 831 |  |
| China | 397 |  |  | 441 |  |
| Thailand | 851 |  |  | 816 |  |
| Rest of Asia | 393 |  |  | 406 |  |
| Europe, Middle East and Africa | 47 |  |  | 46 |  |
| Total | $ | 3,620 |  |  | $ | 3,670 |  |

[0000106040-23-000024:notes:85]
(1)    Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located.

[0000106040-23-000024:notes:86]
Customer Concentration and Credit Risk

[0000106040-23-000024:notes:87]
The Company sells its products to computer manufacturers and OEMs, cloud service providers, resellers, distributors and retailers throughout the world. For each of 2023, 2022 and 2021, no customer accounted for 10% or more of the Company’s net revenue. For 2023, 2022 and 2021, the Company’s top 10 customers accounted for 43%, 45%, and 39%, respectively, of the Company’s net revenue.

[0000106040-23-000024:notes:88]
The Company performs ongoing credit evaluations of its customers’ financial condition to manage collection risk, in some cases supplemented by collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of June 30, 2023, the Company had net accounts receivable of $1.60 billion, and two customers, Arrow Electronics, Inc. and Apple, Inc., accounted for 15% and 13%, respectively, of the Company’s outstanding accounts receivable. As of July 1, 2022, the Company had net accounts receivable of $2.80 billion, and no customer accounted for more than 10% or more of the Company’s net accounts receivable. Reserves for potential credit losses were not material as of each period end.

[0000106040-23-000024:notes:89]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-23-000024:notes:90]
Supplier Concentration

[0000106040-23-000024:notes:91]
All of the Company’s Flash require silicon wafers for the memory and controller components. The Company’s flash memory wafers are currently supplied almost entirely from Flash Ventures (as defined in Note 10) and the Company’s controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-23-000024:notes:92]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect on its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.

[0000106040-23-000024:notes:93]
Goodwill

[0000106040-23-000024:notes:94]
The following table provides a summary of goodwill activity for the period:

[0000106040-23-000024:notes:95]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at July 1, 2022 | $ | 5,718 |  |  | $ | 4,323 |  |  | $ | 10,041 |  |
| Foreign currency translation adjustment | (2) |  |  | (2) |  |  | (4) |  |
| Balance at June 30, 2023 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |

[0000106040-23-000024:notes:96]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more-likely-than-not-impaired, the Company is required to perform a quantitative approach to determine the amount of impairment.

[0000106040-23-000024:notes:97]
Management performed its annual goodwill impairment assessment for both reporting units as of the first day of its fourth quarter ended June 30, 2023. During 2023, after considering changes in industry and macroeconomic conditions, management performed quantitative analyses of impairments for both the Flash and HDD reporting units as of the end of the first and second quarter of 2023 and again as part of its annual impairment assessment as of the first day of the Company’s fourth quarter ended June 30, 2023. In each of these analyses, the fair value of each operating segment was based on a weighting of two valuation methodologies: an income approach and a market approach.

[0000106040-23-000024:notes:98]
The income approach was based on the present value of the projected discounted cash flows (“DCF”) expected to be generated by the operating segment. Those projections required the use of significant estimates and assumptions specific to the reporting unit as well as those based on general economic conditions, which included, among other factors, revenue growth rates, gross margins, operating costs, capital expenditures, assumed tax rates and other assumptions deemed reasonable by management. The present value was based on applying a weighted average cost of capital (“WACC”) which considered long-term interest rates and cost of equity based on the Company’s risk profile.

[0000106040-23-000024:notes:99]
The market approach was based on a guideline company method, which analyzed market multiples of revenue and earnings before interest, taxes, depreciation and amortization (“EBITDA”) for a group of comparable public companies.

[0000106040-23-000024:notes:100]
The Company reconciled the aggregated estimated fair value of both operating segments to the Company’s market capitalization, including consideration of a control premium representing the estimated amount a market participant would pay to obtain a controlling interest in the Company.

[0000106040-23-000024:notes:101]
In connection with the Company’s annual goodwill impairment assessment performed as of the first day of the fourth quarter ended June 30, 2023, the fair value derived from those valuation methodologies exceeded the carrying value by 20% and 35% for Flash and HDD, respectively. Accordingly, there were no impairment charges recorded in 2023. The Company also did not incur any impairment charges for 2022 or 2021.

[0000106040-23-000024:notes:102]
The Company is required to use judgment when assessing goodwill for impairment, including evaluating the impact of industry and macroeconomic conditions, the determination of the fair value of each reporting unit and the assignment of assets and liabilities to reporting units. In addition, the estimates used to determine the fair value of reporting units as well as their actual carrying value may change based on future changes in the Company’s results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen or the Company’s stock price decreases for a sustained period of time, goodwill could become impaired, which could result in an impairment charge and materially adversely affect the Company’s financial condition and results of operations.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-23-000024:notes:103]
Revenues
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either June 30, 2023 or July 1, 2022. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of June 30, 2023 and July 1, 2022 and changes in contract liabilities during 2023 and 2022 were not material.

[0000106040-23-000024:notes:104]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

[0000106040-23-000024:notes:105]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of June 30, 2023 was not material.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-23-000024:notes:106]
Supplemental Financial Statement Data
Accounts receivable, net

[0000106040-23-000024:notes:107]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. In 2023, 2022 and 2021, the Company sold trade accounts receivable aggregating $776 million, $400 million and $233 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Consolidated Statements of Operations. As of June 30, 2023 and July 1, 2022, the amount of factored receivables that remained outstanding was $150 million and $300 million, respectively.

[0000106040-23-000024:notes:108]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 2,096 |  |  | $ | 1,603 |  |
| Work-in-process | 979 |  |  | 1,162 |  |
| Finished goods | 623 |  |  | 873 |  |
| Total inventories | $ | 3,698 |  |  | $ | 3,638 |  |

[0000106040-23-000024:notes:109]
Property, plant and equipment, net

[0000106040-23-000024:notes:110]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 269 |  |  | $ | 269 |  |
| Buildings and improvements | 1,955 |  |  | 1,920 |  |
| Machinery and equipment | 8,704 |  |  | 8,642 |  |
| Computer equipment and software | 470 |  |  | 494 |  |
| Furniture and fixtures | 54 |  |  | 54 |  |
| Construction-in-process | 798 |  |  | 591 |  |
| Property, plant and equipment, gross | 12,250 |  |  | 11,970 |  |
| Accumulated depreciation | (8,630) |  |  | (8,300) |  |
| Property, plant and equipment, net | $ | 3,620 |  |  | $ | 3,670 |  |

[0000106040-23-000024:notes:111]
Depreciation expense for property, plant and equipment totaled $695 million, $708 million and $726 million in 2023, 2022 and 2021, respectively.

[0000106040-23-000024:notes:112]
Intangible assets

[0000106040-23-000024:notes:113]
The following tables present intangible assets as of June 30, 2023 and July 1, 2022:

[0000106040-23-000024:notes:114]
|  | June 30, 2023 |  |  |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |  |
|  | (in years) |  | (in millions) |  |  |
| Finite-lived: |  |  |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,231 |  |  | $ | (4,231) |  |  | $ | — |  |  |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (648) |  |  | — |  |  |  |
| Customer relationships | 6 |  | 611 |  |  | (611) |  |  | — |  |  |  |
| Leasehold interests | 31 |  | 1 |  |  | (1) |  |  | — |  |  |  |
| Total finite intangible assets |  |  | 5,491 |  |  | (5,491) |  |  | — |  |  |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |  |  |
| Total intangible assets |  |  | $ | 5,571 |  |  | $ | (5,491) |  |  | $ | 80 |  |  |  |

[0000106040-23-000024:notes:115]
|  | July 1, 2022 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite-lived: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,231 |  |  | $ | (4,231) |  |  | $ | — |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (573) |  |  | 75 |  |
| Customer relationships | 6 |  | 613 |  |  | (555) |  |  | 58 |  |
| Leasehold interests | 31 |  | 1 |  |  | (1) |  |  | — |  |
| Total finite intangible assets |  |  | 5,493 |  |  | (5,360) |  |  | 133 |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |
| Total intangible assets |  |  | $ | 5,573 |  |  | $ | (5,360) |  |  | $ | 213 |  |

[0000106040-23-000024:notes:116]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-23-000024:notes:117]
During 2023, 2022 and 2021, the Company did not record any impairment charges related to intangible assets.

[0000106040-23-000024:notes:118]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Amortization expense for intangible assets subject to amortization totaled $133 million, $221 million, and $486 million in 2023, 2022 and 2021, respectively. As of June 30, 2023, all finite-lived intangible assets were fully amortized.

[0000106040-23-000024:notes:119]
Product warranty liability

[0000106040-23-000024:notes:120]
Changes in the warranty accrual were as follows:

[0000106040-23-000024:notes:121]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| Warranty accrual, beginning of period |  |  |  |  | $ | 345 |  |  | $ | 363 |  |  | $ | 408 |  |
| Charges to operations |  |  |  |  | 106 |  |  | 146 |  |  | 137 |  |
| Utilization |  |  |  |  | (169) |  |  | (103) |  |  | (106) |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (38) |  |  | (61) |  |  | (76) |  |
| Warranty accrual, end of period |  |  |  |  | $ | 244 |  |  | $ | 345 |  |  | $ | 363 |  |

[0000106040-23-000024:notes:122]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-23-000024:notes:123]
|  | 2023 |  | 2022 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 97 |  |  | $ | 162 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 147 |  |  | 183 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 244 |  |  | $ | 345 |  |  |  |  |  |  |  |

[0000106040-23-000024:notes:124]
Other liabilities

[0000106040-23-000024:notes:125]
|  | 2023 |  | 2022 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 464 |  |  | $ | 659 |  |
| Non-current portion of unrecognized tax benefits | 408 |  |  | 477 |  |
| Other non-current liabilities | 543 |  |  | 643 |  |
| Total other liabilities | $ | 1,415 |  |  | $ | 1,779 |  |

[0000106040-23-000024:notes:126]
Accumulated other comprehensive loss

[0000106040-23-000024:notes:127]
Accumulated other comprehensive loss (“AOCL”), net of tax, refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCL:

[0000106040-23-000024:notes:128]
|  | Actuarial Pension Losses |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Losses on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at July 2, 2021 | $ | (35) |  |  | $ | (38) |  |  |  |  |  |  | $ | (124) |  |  | $ | (197) |  |
| Other comprehensive income (loss) before reclassifications | 26 |  |  | (239) |  |  |  |  |  |  | (352) |  |  | (565) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 172 |  |  | 172 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (2) |  |  | — |  |  |  |  |  |  | 38 |  |  | 36 |  |
| Net current-period other comprehensive income (loss) | 24 |  |  | (239) |  |  |  |  |  |  | (142) |  |  | (357) |  |
| Balance at July 1, 2022 | (11) |  |  | (277) |  |  |  |  |  |  | (266) |  |  | (554) |  |
| Other comprehensive income (loss) before reclassifications | 12 |  |  | (81) |  |  |  |  |  |  | (213) |  |  | (282) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 351 |  |  | 351 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (3) |  |  | 1 |  |  |  |  |  |  | (29) |  |  | (31) |  |
| Net current-period other comprehensive income (loss) | 9 |  |  | (80) |  |  |  |  |  |  | 109 |  |  | 38 |  |
| Balance at June 30, 2023 | $ | (2) |  |  | $ | (357) |  |  |  |  |  |  | $ | (157) |  |  | $ | (516) |  |

[0000106040-23-000024:notes:129]
During 2023 and 2022, the amounts reclassified out of AOCL included gains of $10 million and losses of $47 million, respectively, related to interest rate swaps and losses of $361 million and $125 million, respectively, related to foreign exchange contracts. The gains and losses related to interest rate swaps were charged to interest expense and losses related to foreign contracts were substantially all charged to Cost of revenue in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-23-000024:notes:130]
Fair Value Measurements and Investments
Financial Instruments Carried at Fair Value

[0000106040-23-000024:notes:131]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-23-000024:notes:132]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0000106040-23-000024:notes:133]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-23-000024:notes:134]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-23-000024:notes:135]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 30, 2023 and July 1, 2022, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-23-000024:notes:136]
|  | June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents – Money market funds | $ | 371 |  |  | $ | — |  |  | $ | — |  |  | $ | 371 |  |
| Foreign exchange contracts | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total assets at fair value | $ | 371 |  |  | $ | 35 |  |  | $ | — |  |  | $ | 406 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |

[0000106040-23-000024:notes:137]
|  | July 1, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents – Money market funds | $ | 266 |  |  | $ | — |  |  | $ | — |  |  | $ | 266 |  |
| Foreign exchange contracts | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Interest rate swap contracts | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets at fair value | $ | 266 |  |  | $ | 64 |  |  | $ | — |  |  | $ | 330 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 316 |  |  | $ | — |  |  | $ | 316 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 316 |  |  | $ | — |  |  | $ | 316 |  |

[0000106040-23-000024:notes:138]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-23-000024:notes:139]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 7, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheet under Other current assets and Accrued expenses, respectively.

[0000106040-23-000024:notes:140]
Interest Rate Swaps. The Company’s interest rate swaps were long-term contracts to hedge the Company’s variable rate debt risk. Interest rate swaps were valued based on estimated present value of future cash flows model. The market-based observable inputs for the model include interest rate curves and credit valuation adjustments based on published credit default swap curves.

[0000106040-23-000024:notes:141]
During 2023 and 2022, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-23-000024:notes:142]
Financial Instruments Not Carried at Fair Value

[0000106040-23-000024:notes:143]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2023 and the fourth quarter of 2022, respectively.

[0000106040-23-000024:notes:144]
|  | June 30, 2023 |  | July 1, 2022 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,099 |  |  | $ | 1,067 |  |  | $ | 1,048 |  |  | $ | 1,040 |  |
| 4.75% senior unsecured notes due 2026 | 2,293 |  |  | 2,193 |  |  | 2,291 |  |  | 2,205 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,687 |  |  | 2,661 |  |  | 2,693 |  |  | 2,621 |  |
| 2.85% senior notes due 2029 | 496 |  |  | 400 |  |  | 495 |  |  | 412 |  |
| 3.10% senior notes due 2032 | 495 |  |  | 371 |  |  | 495 |  |  | 389 |  |
| Total | $ | 7,070 |  |  | $ | 6,692 |  |  | $ | 7,022 |  |  | $ | 6,667 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-23-000024:notes:145]
Derivative Instruments and Hedging Activities
As of June 30, 2023, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. As of June 30, 2023, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-23-000024:notes:146]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign-currency denominated monetary assets and liabilities. For each of 2023, 2022 and 2021, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-23-000024:notes:147]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data - Accumulated other comprehensive loss.

[0000106040-23-000024:notes:148]
Netting Arrangements

[0000106040-23-000024:notes:149]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 30, 2023 and July 1, 2022, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-23-000024:notes:150]
Debt
Debt consisted of the following as of June 30, 2023 and July 1, 2022:

[0000106040-23-000024:notes:151]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | 1,100 |  |  | $ | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,700 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,100 |  |  | 7,100 |  |
| Issuance costs and debt discounts | (30) |  |  | (78) |  |
| Subtotal | 7,070 |  |  | 7,022 |  |
| Less current portion of long-term debt | (1,213) |  |  | — |  |
| Long-term debt | $ | 5,857 |  |  | $ | 7,022 |  |

[0000106040-23-000024:notes:152]
During the year ended June 30, 2023, the Company entered into a first amendment (“Amendment No. 1”) and a second amendment (“Amendment No. 2”, and together with Amendment No. 1, the “Credit Agreement Amendments”) to the Company’s Amended and Restated Loan Agreement, dated as of January 7, 2022 which governs the Term-Loan A-2 and the revolving credit facility maturing in January 2027 (as amended, the “Credit Agreement”).

[0000106040-23-000024:notes:153]
The Credit Agreement Amendments, among other things, (a) modified the leverage ratio requirements, and (b) introduced a minimum liquidity covenant applicable through the Company’s quarter ending September 27, 2024 and a minimum free cash flow requirement applicable through the Company’s quarter ending December 29, 2023.

[0000106040-23-000024:notes:154]
The Credit Agreement Amendments also accelerate the due date for amounts outstanding under the Credit Agreement from January 7, 2027 to November 2, 2023 if, as of that date, the Company does not have cash and cash equivalents plus available unused capacity under its 2027 Revolving Facility (as defined below) that is at least $1.40 billion plus the aggregate principal amount of indebtedness that matures within 12 months of such date (including the 2024 Convertible Notes and the Delayed Draw Term Loan (as such terms are defined below)).

[0000106040-23-000024:notes:155]
As amended, the Company is required to comply with maintaining a maximum ratio (“Leverage Ratio”) of total funded debt to Consolidated Adjusted EBITDA (as defined in the Credit Agreement) at the end of each quarter as follows:

[0000106040-23-000024:notes:156]
| Quarter ending | Leverage ratio |
| June 30, 2023 | 5.50 to 1.00 |
| September 29, 2023 | N/A(1) to 1.00 |
| December 29, 2023 | N/A(1) to 1.00 |
| March 29, 2024 | 6.25 to 1.00 |
| June 28, 2024 | 5.25 to 1.00 |
| September 27, 2024 | 5.00 to 1.00 |
| December 27, 2024 | 4.50 to 1.00 |
| March 28, 2025 | 4.00 to 1.00 |
| June 25, 2025 | 3.75 to 1.00 |
| Thereafter | 3.25 to 1.00 |

[0000106040-23-000024:notes:157]
(1)    Leverage ratio is not required.

[0000106040-23-000024:notes:158]
For the purpose of the Leverage Ratio, Consolidated Adjusted EBITDA is calculated on a trailing twelve-month basis, except that for the quarters ending March 29, 2024, June 28, 2024 and September 27, 2024, Consolidated Adjusted EBITDA shall be: (a) for the quarter ending March 29, 2024, Consolidated Adjusted EBITDA for such quarter multiplied by four, (b) for the quarter ending June 28, 2024, Consolidated Adjusted EBITDA for such quarter and the immediately preceding quarter multiplied by two and (c) for the quarter ending September 27, 2024, Consolidated Adjusted EBITDA for such quarter and the two immediately preceding quarters multiplied by four-thirds.

[0000106040-23-000024:notes:159]
In addition, the Credit Agreement requires the Company and its subsidiaries to maintain minimum liquidity (defined as the sum of cash and cash equivalents plus available unused capacity under its 2027 Revolving Facility less the aggregate principal amount of indebtedness that matures within 12 months of such date, excluding indebtedness under the Delayed Draw Term Loan Agreement (as defined below)) of $2.00 billion at the end of each quarter through September 23, 2024, and Free Cash Flow (as defined in the Credit Agreement) of no less than $(550) million as of June 30, 2023, $(500) million as of September 29, 2023 and $(500) million as of December 29, 2023; provided that if Free Cash Flow is greater than the amount noted as of the applicable quarter end date, the amount by which Free Cash Flow exceeds the stated amount may be carried forward to subsequent quarters such that the minimum Free Cash Flow amount for such fiscal quarter is increased by the amount of such excess. As of June 30, 2023, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-23-000024:notes:160]
The Credit Agreement also requires the Company to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements.

[0000106040-23-000024:notes:161]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. During 2022, the Company made scheduled and voluntary principal payments aggregating $300 million on its Term Loan A-2. $150 million was applied toward scheduled amortization through the quarter ending September 29, 2023 and the remainder towards the principal due at maturity. The annualized interest rate for Term Loan A-2 as of June 30, 2023 was 6.557%. As of June 30, 2023, the remaining balance of Term Loan A-2 amortizes in quarterly installments of $38 million per quarter beginning with the quarter ending December 29, 2023, and the remaining balance is payable at maturity on January 7, 2027. Issuance costs for Term Loan A-2 are amortized to Interest expense over its term and unamortized costs were $13 million as of June 30, 2023.

[0000106040-23-000024:notes:162]
During the year ended June 30, 2023, the Company drew and repaid $1.18 billion principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”).

[0000106040-23-000024:notes:163]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

[0000106040-23-000024:notes:164]
In January 2023, the Company entered into a loan agreement (the “Delayed Draw Term Loan Agreement”), which allowed the Company to draw a single loan of up to $875 million through June 30, 2023. In June 2023, the Company entered into a first amendment and a second amendment to the Delayed Draw Term Loan Agreement (as amended, the “Amended Delayed Draw Term Loan Agreement”), which together extended the term loan commitments under the Delayed Draw Term Loan Agreement until August 14, 2023, and reduced the term loan commitments from $875 million to $600 million (the “Delayed Draw Term Loan”). As of June 30, 2023, the Company had not drawn on the Delayed Draw Term Loan.

[0000106040-23-000024:notes:165]
In August 2023, the Company drew the Delayed Draw Term Loan in the amount of $600 million. The principal amount of the Delayed Draw Term Loan will mature on June 28, 2024. However, the due date will be accelerated to November 2, 2023, if, as of that date, the Company does not have cash and cash equivalents plus available unused capacity under its 2027 Revolving Facility that is at least $1.40 billion plus the aggregate principal amount of indebtedness that matures within 12 months (including the 2024 Convertible Notes (as defined below) and the Delayed Draw Term Loan).

[0000106040-23-000024:notes:166]
The Delayed Draw Term Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR Rate (as defined in the Amended Delayed Draw Term Loan Agreement) plus an applicable margin varying from 1.750% to 2.625% or (y) a base rate plus an applicable margin varying from 0.750% to 1.625%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies (as defined in the Amended Delayed Draw Term Loan Agreement). The Company pays an unused commitment fee on the Delayed Draw Term Loan Agreement of 0.200%.

[0000106040-23-000024:notes:167]
The key covenants, limitations and requirements provided under the Credit Agreement noted above also apply to the Amended Delayed Draw Term Loan Agreement.

[0000106040-23-000024:notes:168]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior notes due February 1, 2029 (the “2029 Senior Notes”) and issued $500 million aggregate principal amount of 3.100% senior notes due February 1, 2032 (the “2032 Senior Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Senior Notes Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “Senior Notes First Supplemental Indenture”) between the Company and the Senior Notes Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the Senior Notes First Supplemental Indenture. Interest for both the 2029 Senior Notes and 2032 Senior Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Senior Notes or 2032 Senior Notes prior to their maturity dates.

[0000106040-23-000024:notes:169]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date.

[0000106040-23-000024:notes:170]
Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date at an initial conversion price of $121.91 per share of common stock. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events. The Company is required to settle any conversion value with the principal amount of the 2024 Convertible Notes settled in cash and any excess value in cash, shares of the Company’s common stock, or a combination thereof, pursuant to the terms of an indenture, dated as of February 13, 2018 between the Company, HGST, Inc., WD Media, LLC, Western Digital (Fremont), LLC, Western Digital Technologies, Inc. and U.S. Bank National Association, as trustee (the “ Convertible Notes Trustee”), as supplemented by the first supplemental indenture dated as of June 30, 2022 between the Company and the Convertible Notes Trustee. As of June 30, 2023, none of the conditions allowing holders of the Convertible Notes to convert had been met. Since February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

[0000106040-23-000024:notes:171]
As described in Note 2, Recent Accounting Pronouncements, the Company adopted ASU 2020-06 effective July 2, 2022, using a modified retrospective method, which resulted in the elimination of the originally recorded debt discount associated with the conversion feature on the 2024 Convertible Notes. As of June 30, 2023, debt discount and issuance costs of $2 million remained unamortized.

[0000106040-23-000024:notes:172]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. Issuance costs for the 2026 Senior Unsecured Notes are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of June 30, 2023, issuance costs of $7 million remained unamortized.

[0000106040-23-000024:notes:173]
The indentures and supplemental indentures, as applicable, governing the Company’s 2029 Senior Notes, 2032 Senior Notes, 2026 Senior Unsecured Notes and the 2024 Convertible Notes each contain various restrictive covenants, which can include limitations on the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness, and are subject to a number of limitations and exceptions.

[0000106040-23-000024:notes:174]
In connection with the amendments discussed above, the 2027 Revolving Facility, Term Loan A-2, and the Delayed Draw Term Loan (the “Credit Facilities”) have been unconditionally guaranteed by Western Digital Technologies, Inc. (the “Initial Guarantor”) and are secured on a first-priority basis (subject to permitted liens) by a lien on substantially all assets and properties of the Company and the Initial Guarantor (the “Collateral”), subject to certain exceptions. Furthermore, the obligations under the Company’s 2.850% Senior Notes due 2029 and 3.100% Senior Notes due 2032 have been secured by the Collateral on an equal and ratable basis to the obligations under the Credit Facilities for so long as and to the extent required under the terms of the Indenture, and the obligations under the Company’s 2026 Senior Unsecured Notes have been guaranteed by the Initial Guarantor pursuant to the First Supplemental Indenture dated as of June 20, 2023 (the “2026 Senior Notes First Supplemental Indenture”) for so long as and to the extent required under the terms of the indenture governing such notes and the 2026 Senior Notes First Supplemental Indenture.

[0000106040-23-000024:notes:175]
Future Debt Payments

[0000106040-23-000024:notes:176]
As of June 30, 2023, the required annual future debt payments were as follows:

[0000106040-23-000024:notes:177]
|  |  | Future Debt Payments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2024 |  | $ | 1,213 |  |
| 2025 |  | 150 |  |
| 2026 |  | 2,450 |  |
| 2027 |  | 2,287 |  |
| 2028 |  | — |  |
| 2029 and thereafter |  | 1,000 |  |
| Total debt maturities |  | 7,100 |  |
| Issuance costs and debt discounts |  | (30) |  |
| Net carrying value |  | $ | 7,070 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-23-000024:notes:178]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand and the Philippines. All pension and other post-retirement benefit plans outside of the Company’s Japan, Thailand and the Philippines defined benefit pension plans (the “Pension Plans”) are immaterial to the Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans’ assets is 2.5%.

[0000106040-23-000024:notes:179]
Obligations and Funded Status

[0000106040-23-000024:notes:180]
The following table presents the unfunded status of the benefit obligations for the Pension Plans:

[0000106040-23-000024:notes:181]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 294 |  |  | $ | 359 |  |  | $ | 366 |  |
| Service cost | 14 |  |  | 15 |  |  | 16 |  |
| Interest cost | 6 |  |  | 5 |  |  | 5 |  |
| Plan amendments | — |  |  | 9 |  |  | — |  |
| Actuarial loss (gain) | (6) |  |  | (31) |  |  | (5) |  |
| Benefits paid | (8) |  |  | (9) |  |  | (11) |  |
| Settlement/curtailment | (15) |  |  | — |  |  | — |  |
| Non-U.S. currency movement | (12) |  |  | (54) |  |  | (12) |  |
| Projected benefit obligation at end of period | 273 |  |  | 294 |  |  | 359 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 189 |  |  | 227 |  |  | 215 |  |
| Actual return on plan assets | 7 |  |  | — |  |  | 20 |  |
| Employer contributions | 9 |  |  | 10 |  |  | 11 |  |
| Benefits paid | (8) |  |  | (7) |  |  | (11) |  |
| Non-U.S. currency movement | (12) |  |  | (41) |  |  | (8) |  |
| Fair value of plan assets at end of period | 185 |  |  | 189 |  |  | 227 |  |
| Unfunded status | $ | 88 |  |  | $ | 105 |  |  | $ | 132 |  |

[0000106040-23-000024:notes:182]
The following table presents the unfunded amounts related to the Pension Plans as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-23-000024:notes:183]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 87 |  |  | 104 |  |
| Net amount recognized | $ | 88 |  |  | $ | 105 |  |

[0000106040-23-000024:notes:184]
The accumulated benefit obligation for the Pension Plans was $273 million at June 30, 2023. As of June 30, 2023, the accumulated other income pension balance was $2 million. There were no material prior service credits for the Pension Plans recognized in Accumulated other comprehensive loss in the Consolidated Balance Sheet as of June 30, 2023.

[0000106040-23-000024:notes:185]
Net periodic benefit costs were not material for 2023, 2022, and 2021.

[0000106040-23-000024:notes:186]
Assumptions

[0000106040-23-000024:notes:187]
Weighted-Average Assumptions

[0000106040-23-000024:notes:188]
The weighted-average actuarial assumptions used to determine the projected benefit obligations for the Pension Plans were as follows:

[0000106040-23-000024:notes:189]
|  | 2023 |  | 2022 |  | 2021 |
| Discount rate | 2.2 | % |  | 2.3 | % |  | 1.4 | % |
| Rate of compensation increase | 2.4 | % |  | 2.3 | % |  | 2.0 | % |

[0000106040-23-000024:notes:190]
The weighted-average actuarial assumptions used to determine benefit costs for the Pension Plans were as follows:

[0000106040-23-000024:notes:191]
|  | 2023 |  | 2022 |  | 2021 |
| Discount rate | 2.3 | % |  | 1.4 | % |  | 1.1 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 2.3 | % |  | 2.0 | % |  | 2.0 | % |

[0000106040-23-000024:notes:192]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management then matches the benefit payments to high quality bonds which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-23-000024:notes:193]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in each plan as well as the investment portfolio applicable to the plan depending on each plan’s economic environment. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates. As of June 30, 2023, the Pension Plans’ assets materially consisted of plan assets related to the Japan pension plan and as such the assumption used herein is primarily related to the Japan pension plan.

[0000106040-23-000024:notes:194]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-23-000024:notes:195]
Plan Assets

[0000106040-23-000024:notes:196]
Investment Policies and Strategies

[0000106040-23-000024:notes:197]
The investment policy in the Pension Plans is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 55% in debt securities, 30% in equity securities, and the remaining 15% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-23-000024:notes:198]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-23-000024:notes:199]
Fair Value Measurements

[0000106040-23-000024:notes:200]
The following tables present the Pension Plans’ major asset categories and their associated fair values and net asset values as of June 30, 2023 and July 1, 2022:

[0000106040-23-000024:notes:201]
|  | June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Net plan assets subject to leveling | — |  |  | 155 |  |  | — |  |  | 155 |  |
| Real estate investment trust at net asset value |  |  |  |  |  |  | 30 |  |
| Total investments at fair value | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 185 |  |

[0000106040-23-000024:notes:202]
|  | July 1, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 63 |  |  | $ | — |  |  | $ | 63 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 95 |  |  | — |  |  | 95 |  |
| Net plan assets subject to leveling | — |  |  | 158 |  |  | — |  |  | 158 |  |
| Real estate investment trust at net asset value |  |  |  |  |  |  | 31 |  |
| Total investments at fair value | $ | — |  |  | $ | 158 |  |  | $ | — |  |  | $ | 189 |  |

[0000106040-23-000024:notes:203]
(1)    Commingled funds represent pooled institutional investments.

[0000106040-23-000024:notes:204]
(2)    Equity mutual funds invest primarily in equity securities.

[0000106040-23-000024:notes:205]
(3)    Fixed income mutual funds invest primarily in fixed income securities.

[0000106040-23-000024:notes:206]
There were no significant movements of assets between any level categories in 2023 or 2022.

[0000106040-23-000024:notes:207]
Fair Value Valuation Techniques

[0000106040-23-000024:notes:208]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-23-000024:notes:209]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics and is generally classified as Level 2.

[0000106040-23-000024:notes:210]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-23-000024:notes:211]
Cash Flows

[0000106040-23-000024:notes:212]
The Company’s expected employer contributions for 2024 and annual benefit payments over the next five years for its Pension Plans are not expected to be material.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-23-000024:notes:213]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-23-000024:notes:214]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and Kioxia has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Kioxia collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by Kioxia at its wafer fabrication facilities located in Japan using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from Kioxia at cost and then resells those wafers to the Company and Kioxia at cost plus a markup.

[0000106040-23-000024:notes:215]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of Kioxia’s “Y3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-23-000024:notes:216]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of Kioxia’s “Y4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-23-000024:notes:217]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of Kioxia’s “Y5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Y5 was built in two phases of approximately equal size.

[0000106040-23-000024:notes:218]
New Y2. The Company has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “New Y2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Y2 primarily provided additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Y2 started in 2016.

[0000106040-23-000024:notes:219]
Y6. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “Y6” 300-millimeter wafer fabrication facility in Yokkaichi, Japan. Y6 is primarily intended to provide clean room space to continue the transition of existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. Production of flash-based wafers in Y6 started in 2018.

[0000106040-23-000024:notes:220]
K1. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company has made prepayments toward future K1 building depreciation. As of June 30, 2023, approximately $220 million of such prepayments were available to be credited against future wafer charges.

[0000106040-23-000024:notes:221]
Y7. In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. The first phase of construction of Y7 is now complete and has commenced output. The Company is committed to pay, among other things, the remainder of prepayments toward future Y7 building depreciation aggregating approximately $21 million in 2024. The prepayments can be used as credit against future wafer charges. As of June 30, 2023, approximately $355 million of prepayments were available to be credited against future wafer charges.

[0000106040-23-000024:notes:222]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-23-000024:notes:223]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of June 30, 2023 and July 1, 2022:

[0000106040-23-000024:notes:224]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 37 |  |  | $ | 27 |  |
| Notes receivable, Flash Alliance | 48 |  |  | 55 |  |
| Notes receivable, Flash Forward | 709 |  |  | 793 |  |
| Investment in Flash Partners | 160 |  |  | 166 |  |
| Investment in Flash Alliance | 234 |  |  | 243 |  |
| Investment in Flash Forward | 109 |  |  | 112 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,297 |  |  | $ | 1,396 |  |

[0000106040-23-000024:notes:225]
During 2023, 2022 and 2021, the Company made net payments to Flash Ventures of $4.20 billion, $4.70 billion and $4.36 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-23-000024:notes:226]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-23-000024:notes:227]
As of June 30, 2023 and July 1, 2022, the Company had Accounts payable balances due to Flash Ventures of $292 million and $320 million, respectively.

[0000106040-23-000024:notes:228]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 30, 2023, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-23-000024:notes:229]
|  | June 30,2023 |
|  | (in millions) |
| Notes receivable | $ | 794 |  |
| Equity investments | 503 |  |
| Operating lease guarantees | 1,694 |  |
| Inventory and prepayments | 1,147 |  |
| Maximum estimable loss exposure | $ | 4,138 |  |

[0000106040-23-000024:notes:230]
As of June 30, 2023 and July 1, 2022, the Company’s retained earnings included cumulative undistributed earnings of Flash Ventures of $55 million and $43 million, respectively.

[0000106040-23-000024:notes:231]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-23-000024:notes:232]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2023, as a result of flash business conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. In 2023, the Company incurred costs of $286 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue.

[0000106040-23-000024:notes:233]
In February 2022, contamination of certain material used in manufacturing processes occurred at both the Yokkaichi and Kitakami, Japan fabrication facilities, resulting in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue, which primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs.

[0000106040-23-000024:notes:234]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-23-000024:notes:235]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-23-000024:notes:236]
Off-Balance Sheet Liabilities

[0000106040-23-000024:notes:237]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-23-000024:notes:238]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 30, 2023.

[0000106040-23-000024:notes:239]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 245 |  |  | $ | 1,694 |  |

[0000106040-23-000024:notes:240]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of June 30, 2023 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 30, 2023:

[0000106040-23-000024:notes:241]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| 2024 |  | $ | 467 |  |  | $ | 90 |  |  | $ | 557 |  |
| 2025 |  | 269 |  |  | 82 |  |  | 351 |  |
| 2026 |  | 309 |  |  | 125 |  |  | 434 |  |
| 2027 |  | 115 |  |  | 106 |  |  | 221 |  |
| 2028 |  | 29 |  |  | 102 |  |  | 131 |  |
| Total guarantee obligations |  | $ | 1,189 |  |  | $ | 505 |  |  | $ | 1,694 |  |

[0000106040-23-000024:notes:242]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of June 30, 2023, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-23-000024:notes:243]
Unis Venture

[0000106040-23-000024:notes:244]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the years ended June 30, 2023, July 1, 2022 and July 2, 2021, the Company recognized approximately 3%, 4%, and 3% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 8% and 5% of Accounts receivable, net as of June 30, 2023 and July 1, 2022, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-23-000024:notes:245]
Leases and Other Commitments 
Leases

[0000106040-23-000024:notes:246]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of June 30, 2023:

[0000106040-23-000024:notes:247]
The following table summarizes supplemental balance sheet information related to operating leases as of June 30, 2023:

[0000106040-23-000024:notes:248]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by year: | (in millions) |  |  |  |  |  |  |  |  |
| 2024 | $ | 49 |  |  |  |  |  |  |  |  |  |
| 2025 | 47 |  |  |  |  |  |  |  |  |  |
| 2026 | 47 |  |  |  |  |  |  |  |  |  |
| 2027 | 42 |  |  |  |  |  |  |  |  |  |
| 2028 | 35 |  |  |  |  |  |  |  |  |  |
| Thereafter | 114 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 334 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | 50 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 284 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 40 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 244 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 260 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 7.6 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 4.2 | % |  |  |  |  |  |  |  |  |

[0000106040-23-000024:notes:249]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases for the year ended June 30, 2023:

[0000106040-23-000024:notes:250]
|  |  |  | June 30,2023 |  |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |  |  |  |
| Cost of operating leases |  |  | $ | 57 |  |  |  |  |  |  |  |
| Cash paid for operating leases |  |  | 51 |  |  |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities |  |  | 17 |  |  |  |  |  |  |  |

[0000106040-23-000024:notes:251]
Cost of operating leases was as follows:

[0000106040-23-000024:notes:252]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Cost of operating leases | $ | 57 |  |  | $ | 58 |  |  | $ | 50 |  |

[0000106040-23-000024:notes:253]
Purchase Agreements and Other Commitments

[0000106040-23-000024:notes:254]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of June 30, 2023, the Company had the following minimum long-term commitments:

[0000106040-23-000024:notes:255]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2024 |  | $ | 275 |  |
| 2025 |  | 253 |  |
| 2026 |  | 61 |  |
| 2027 |  | 47 |  |
| 2028 |  | 20 |  |
| Thereafter |  | 130 |  |
| Total |  | $ | 786 |  |


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-23-000024:notes:256]
Western Digital Corporation 401(k) Plan 
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire unless the individual is covered by a collective bargaining agreement, provides services as a consultant, intern, independent contractor, leased or temporary employee, or otherwise is not treated as a common-law employee.

[0000106040-23-000024:notes:257]
Through December 31, 2021, eligible employees were generally able to contribute up to 75% of their eligible compensation on a combined pre-tax and Roth basis, 10% on a combined pre-tax catch-up and Roth catch-up basis, and 10% on a non-Roth after-tax basis subject to Internal Revenue Service (“IRS”) limitations. Effective January 1, 2022, eligible employees are generally able to contribute up to 85% of their eligible compensation on a combined pre-tax and Roth basis regardless of age, and 10% of their eligible compensation on an after-tax basis by payroll withholding. The Company may make a basic matching contribution equal to 50% of each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. Furthermore, the Company’s employer matching contributions vest immediately. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-23-000024:notes:258]
Effective February 18, 2023, the Company announced its decision to suspend matching contributions. The Company may resume matching contributions at any time at its discretion.

[0000106040-23-000024:notes:259]
For 2023, 2022 and 2021, the Company made Plan contributions of $22 million, $36 million and $34 million, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-23-000024:notes:260]
Shareholders’ Equity and Convertible Preferred Stock
2021 Long-Term Incentive Plan

[0000106040-23-000024:notes:261]
In November 2021, stockholders approved the Western Digital Corporation 2021 Long-Term Incentive Plan (the “2021 Plan”). Upon the effective date of the 2021 Plan, no new awards were granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (the “2017 Plan”). The 2021 Plan was amended in 2023 to increase the number of shares available for issuance under the plan by 2.8 million shares of common stock. The aggregate maximum number of shares of the Company’s common stock that may be issued pursuant to awards from the 2021 Plan may not exceed (a) 12.0 million shares of common stock plus (b) any shares of common stock subject to outstanding awards under a prior plan as of the effective date that on or after the effective date are forfeited, terminated, expire, lapse without being exercised (to the extent applicable), or are otherwise reacquired by the Company. Any shares subject to awards under the 2017 Plan that are cancelled, forfeited, or otherwise terminate without having vested or been exercised, as applicable, will become available for award grants under the 2021 Plan. The types of awards that may be granted under the 2021 Plan include stock options, stock appreciation rights (“SARs”), RSUs, PSUs, restricted stock and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash awards. Persons eligible to receive awards under the 2021 Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2021 Plan and the 2017 Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs is ten years after the grant date of the award. RSUs typically vest over periods ranging from two to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance conditions or market conditions and completion of requisite service periods. Once the performance conditions or market conditions are met, vesting of PSUs is generally subject to continued service by the employee. As of June 30, 2023, there were outstanding awards that may vest under the 2017 Plan as well as outstanding awards of stock options under the SanDisk Corporation 2013 Incentive Plan, a plan assumed in connection with the acquisition of SanDisk Corporation, which may affect dilution.

[0000106040-23-000024:notes:262]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-23-000024:notes:263]
As of June 30, 2023, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2021 Plan was 17.0 million shares, which includes shares of common stock subject to outstanding awards under certain prior plans as of the effective date of the 2021 Plan that have been forfeited, terminated, expired, lapsed without being exercised or were otherwise reacquired by the Company. Shares issued in respect of all awards granted under the 2021 Plan count against the 2021 Plan’s share limit on a one-for-one basis, whereas under the 2017 Plan, shares issued in respect of awards other than stock options and SARs granted count against the 2017 Plan’s share limit as 1.72 shares for every one share issued in connection with such award. The 2021 Plan will terminate on November 22, 2031, unless terminated earlier by the Company’s Board of Directors.

[0000106040-23-000024:notes:264]
Employee Stock Purchase Plan

[0000106040-23-000024:notes:265]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock either at the beginning of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-23-000024:notes:266]
During 2023, 2022 and 2021, the Company issued 2.7 million, 2.1 million, and 3.2 million shares, respectively, under the ESPP for aggregate purchase amounts of $92 million, $113 million and $115 million, respectively.

[0000106040-23-000024:notes:267]
To the extent available, the Company may issue shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-23-000024:notes:268]
Stock-based Compensation Expense

[0000106040-23-000024:notes:269]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-23-000024:notes:270]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| RSUs and PSUs |  |  |  |  | $ | 283 |  |  | $ | 286 |  |  | $ | 282 |  |
| ESPP |  |  |  |  | 35 |  |  | 40 |  |  | 36 |  |
| Total |  |  |  |  | $ | 318 |  |  | $ | 326 |  |  | $ | 318 |  |

[0000106040-23-000024:notes:271]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| Cost of revenue |  |  |  |  | $ | 49 |  |  | $ | 48 |  |  | $ | 55 |  |
| Research and development |  |  |  |  | 152 |  |  | 167 |  |  | 158 |  |
| Selling, general and administrative |  |  |  |  | 117 |  |  | 111 |  |  | 105 |  |
| Subtotal |  |  |  |  | 318 |  |  | 326 |  |  | 318 |  |
| Tax benefit |  |  |  |  | (43) |  |  | (48) |  |  | (47) |  |
| Total |  |  |  |  | $ | 275 |  |  | $ | 278 |  |  | $ | 271 |  |

[0000106040-23-000024:notes:272]
Any shortfalls or excess windfall tax benefits related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-23-000024:notes:273]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 30, 2023:

[0000106040-23-000024:notes:274]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 464 |  |  | 2.2 |
| ESPP | 67 |  |  | 1.4 |
| Total unamortized compensation cost | $ | 531 |  |  |  |

[0000106040-23-000024:notes:275]
(1)    Weighted average service period assumes the performance conditions are met for the PSUs.

[0000106040-23-000024:notes:276]
Plan Activities

[0000106040-23-000024:notes:277]
Stock Options

[0000106040-23-000024:notes:278]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-23-000024:notes:279]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 3, 2020 | 2.7 |  |  | $ | 69.16 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 44.34 |  |  |  |  | $ | 6 |  |
| Canceled or expired | (0.8) |  |  | 75.42 |  |  |  |  |  |
| Options outstanding at July 2, 2021 | 1.5 |  |  | 72.84 |  |  |  |  |  |
| Exercised | (0.2) |  |  | 43.80 |  |  |  |  | $ | 3 |  |
| Canceled or expired | (0.4) |  |  | 97.65 |  |  |  |  |  |
| Options outstanding at July 1, 2022 | 0.9 |  |  | 66.76 |  |  |  |  |  |
| Canceled or expired | (0.6) |  |  | 80.72 |  |  |  |  |  |
| Options outstanding at June 30, 2023 | 0.3 |  |  | $ | 44.95 |  |  | 0.10 |  |  |

[0000106040-23-000024:notes:280]
No options were granted in 2023, 2022 or 2021. All outstanding options were exercisable at June 30, 2023.

[0000106040-23-000024:notes:281]
RSUs and PSUs

[0000106040-23-000024:notes:282]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-23-000024:notes:283]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 3, 2020 | 13.3 |  |  | $ | 60.92 |  |  |  |
| Granted | 8.8 |  |  | 40.40 |  |  |  |
| Vested | (4.5) |  |  | 60.18 |  |  | $ | 196 |  |
| Forfeited | (1.5) |  |  | 55.74 |  |  |  |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | 50.12 |  |  |  |
| Granted | 6.9 |  |  | 60.00 |  |  |  |
| Vested | (5.2) |  |  | 54.27 |  |  | $ | 317 |  |
| Forfeited | (2.4) |  |  | 52.14 |  |  |  |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | 52.89 |  |  |  |
| Granted | 6.6 |  |  | 41.27 |  |  |  |
| Vested | (6.6) |  |  | 54.05 |  |  | $ | 274 |  |
| Forfeited | (1.6) |  |  | 54.56 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | $ | 46.56 |  |  |  |

[0000106040-23-000024:notes:284]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-23-000024:notes:285]
Fair Value Valuation Assumptions

[0000106040-23-000024:notes:286]
RSU and PSU Grants

[0000106040-23-000024:notes:287]
The fair value of the Company’s RSU and PSU awards with a performance condition is determined based upon the closing price of the Company’s stock price on the date of grant. The fair value of PSU awards with a market condition is estimated using a Monte Carlo simulation model on the date of grant.

[0000106040-23-000024:notes:288]
ESPP — Black-Scholes-Merton Model

[0000106040-23-000024:notes:289]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-23-000024:notes:290]
The fair values of ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-23-000024:notes:291]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
| Weighted-average expected term (in years) |  |  |  |  | 1.25 |  | 1.25 |  | 1.25 |
| Risk-free interest rate |  |  |  |  | 4.52% |  | 1.42% |  | 0.10% |
| Stock price volatility |  |  |  |  | 0.46 |  | 0.48 |  | 0.56 |
| Dividend yield |  |  |  |  | —% |  | —% |  | —% |
| Fair value |  |  |  |  | $9.70 |  | $15.56 |  | $21.59 |

[0000106040-23-000024:notes:292]
Convertible Preferred Stock

[0000106040-23-000024:notes:293]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million.

[0000106040-23-000024:notes:294]
Dividend provisions

[0000106040-23-000024:notes:295]
The Preferred Shares will have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. As of June 30, 2023, (i) no dividends have been declared or paid since the issuance of the Preferred Shares, and (ii) unpaid and cumulative dividends payable with respect to the Preferred Shares were $24 million.

[0000106040-23-000024:notes:296]
Conversion rights

[0000106040-23-000024:notes:297]
The Preferred Shares will be convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate sum of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the holder upon the earlier of on January 31, 2024, and the date a specified spin-off transaction is completed, unless the Company enters into a definitive agreement with respect to a sale, merger or combination of the spun-off entity, in which case the twelve (12) month period will be extended until the earlier of the consummation of such transaction or the termination of the definitive agreement. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately prior to the Company’s conversion notice. As of June 30, 2023, the Preferred Shares outstanding would have been convertible, if otherwise permitted, into 19 million shares of common stock.

[0000106040-23-000024:notes:298]
Redemption

[0000106040-23-000024:notes:299]
After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares for an amount in cash equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares.

[0000106040-23-000024:notes:300]
The Preferred Shares has been classified as mezzanine equity in the Company’s Condensed Consolidated Balance Sheets because, in the event of certain fundamental change in the business that are not solely within the control of the Company, the Preferred Shares would become redeemable at the option of the holders. The Company did not adjust the carrying values of the Preferred Shares to the current redemption value of such shares since a liquidation event was not probable at any of the balance sheet dates. Subsequent adjustments to increase or decrease the carrying values to the ultimate redemption value will be made only if and when it becomes probable that such a fundamental change in the business will occur.

[0000106040-23-000024:notes:301]
Voting right

[0000106040-23-000024:notes:302]
The Preferred Shares will vote, to the extent permitted under the Nasdaq listing rules, on an as-converted equivalent basis along with holders of the Company’s common stock.

[0000106040-23-000024:notes:303]
Liquidation preference

[0000106040-23-000024:notes:304]
In the event of any voluntary or involuntary liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock and the liquidation preference is the greater of (i) the sum of an amount in cash equal to 110% of the Accumulated Stated Value plus accrued and unpaid dividends and (ii) the payment that the holders of Preferred Shares would have received had all Preferred Shares been converted into common stock immediately prior to such liquidation, before any distributions are made to common shareholders and all other classes of junior capital stock of the Company. As of June 30, 2023, the total aggregate liquidation preference was $924 million.

[0000106040-23-000024:notes:305]
Stock Repurchase Program

[0000106040-23-000024:notes:306]
The Company’s Board of Directors previously authorized a stock repurchase program for the repurchase of up to $5.00 billion of the Company’s common stock, which expired on July 25, 2023. For the year ended June 30, 2023, and through the expiration date of the program, the Company did not make any stock repurchases.

[0000106040-23-000024:notes:307]
Stock Reserved for Issuance

[0000106040-23-000024:notes:308]
The following table summarizes all common stock reserved for issuance at June 30, 2023:

[0000106040-23-000024:notes:309]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 24 |  |
| ESPP | 7 |  |
| Total | 31 |  |

[0000106040-23-000024:notes:310]
Dividends to Shareholders
The Company issued a quarterly cash dividend from the first quarter of 2013 up to the third quarter of 2020. In April 2020, the Company suspended its dividend to reinvest in the business and to support its ongoing deleveraging efforts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-23-000024:notes:311]
Income Tax Expense
Income (loss) Before Taxes

[0000106040-23-000024:notes:312]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0000106040-23-000024:notes:313]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Foreign | $ | (2,029) |  |  | $ | 1,384 |  |  | $ | 218 |  |
| Domestic | 469 |  |  | 739 |  |  | 709 |  |
| Income (loss) before taxes | $ | (1,560) |  |  | $ | 2,123 |  |  | $ | 927 |  |

[0000106040-23-000024:notes:314]
Income Tax Expense

[0000106040-23-000024:notes:315]
The components of the income tax expense were as follows:

[0000106040-23-000024:notes:316]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 153 |  |  | $ | 143 |  |  | $ | 195 |  |
| Domestic - Federal | 33 |  |  | 341 |  |  | 154 |  |
| Domestic - State | (6) |  |  | 25 |  |  | (1) |  |
|  | 180 |  |  | 509 |  |  | 348 |  |
| Deferred: |  |  |  |  |  |
| Foreign | 8 |  |  | 27 |  |  | (20) |  |
| Domestic - Federal | (36) |  |  | 84 |  |  | (208) |  |
| Domestic - State | (6) |  |  | 3 |  |  | (14) |  |
|  | (34) |  |  | 114 |  |  | (242) |  |
| Income tax expense | $ | 146 |  |  | $ | 623 |  |  | $ | 106 |  |

[0000106040-23-000024:notes:317]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of 2019. However, the U.S. Treasury and the Internal Revenue Services (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-23-000024:notes:318]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The corporate alternative minimum tax will be effective for the Company beginning with 2024 and the Company is currently evaluating the potential effects of these legislative changes.

[0000106040-23-000024:notes:319]
Deferred Taxes

[0000106040-23-000024:notes:320]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-23-000024:notes:321]
|  | June 30,2023 |  | July 1,2022 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 52 |  |  | $ | 71 |  |
| Accrued compensation and benefits not currently deductible | 88 |  |  | 114 |  |
| Net operating loss carryforward | 183 |  |  | 195 |  |
| Business credit carryforward | 478 |  |  | 483 |  |
| Long-lived assets | 56 |  |  | 72 |  |
| Other | 171 |  |  | 178 |  |
| Total deferred tax assets | 1,028 |  |  | 1,113 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (48) |  |  | (128) |  |
| Unremitted earnings of certain non-U.S. entities | (297) |  |  | (288) |  |
| Other | (7) |  |  | (17) |  |
| Total deferred tax liabilities | (352) |  |  | (433) |  |
| Valuation allowances | (565) |  |  | (580) |  |
| Deferred tax assets, net | $ | 111 |  |  | $ | 100 |  |

[0000106040-23-000024:notes:322]
The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-23-000024:notes:323]
The Company is permanently reinvested with respect to certain foreign earnings. There is no unrecognized deferred tax liability associated with the repatriation of these foreign undistributed earnings as it can be achieved without additional federal tax consequences.

[0000106040-23-000024:notes:324]
Effective Tax Rate

[0000106040-23-000024:notes:325]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-23-000024:notes:326]
|  | 2023 |  | 2022 |  | 2021 |
| U.S. Federal statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| Tax rate differential on international income | (33) |  |  | (9) |  |  | 8 |  |
| Tax effect of U.S. foreign income inclusion | (1) |  |  | — |  |  | 5 |  |
| Tax effect of U.S. foreign minimum tax | — |  |  | 5 |  |  | 1 |  |
| Tax effect of U.S. foreign derived intangible income | 4 |  |  | (1) |  |  | (14) |  |
| Tax effect of U.S. non-deductible stock-based compensation | (1) |  |  | 1 |  |  | 1 |  |
| Tax effect of U.S. permanent differences | — |  |  | — |  |  | 1 |  |
| IRS Tentative Settlement | 1 |  |  | 15 |  |  | — |  |
| Change in valuation allowance | 1 |  |  | 1 |  |  | (7) |  |
| Unremitted earnings of certain non-U.S. entities | (1) |  |  | 1 |  |  | 6 |  |
| Foreign income tax credits | — |  |  | (3) |  |  | (5) |  |
| R&D tax credits | 5 |  |  | (4) |  |  | (8) |  |
| U.S. return to provision | (2) |  |  | — |  |  | (3) |  |
| Other | (3) |  |  | 2 |  |  | 5 |  |
| Effective tax rate | (9) | % |  | 29 | % |  | 11 | % |

[0000106040-23-000024:notes:327]
Tax Holidays and Carryforwards

[0000106040-23-000024:notes:328]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines and Thailand operate under various tax holidays and tax incentive programs, which will expire in whole or in part at various dates during 2024 through 2031. Certain tax holidays and tax incentive programs may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $140 million, or $0.44 per diluted share, $566 million, or $1.79 per diluted share, and $390 million, or $1.26 per diluted share, in 2023, 2022, and 2021, respectively.

[0000106040-23-000024:notes:329]
As of June 30, 2023, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-23-000024:notes:330]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 594 |  |  | 2024 to 2038 |
| State NOL | 374 |  |  | 2032 to 2043 |
| Federal tax credits | 51 |  |  | 2024 to 2032 |
| State tax credits | 725 |  |  | No expiration |

[0000106040-23-000024:notes:331]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal and state NOLs ultimately realized will be reduced as a result of these provisions by $116 million and $240 million, respectively. The Company expects the total amount of federal and state credits ultimately realized will be reduced as a result of these provisions by $27 million and $2 million, respectively.

[0000106040-23-000024:notes:332]
As of June 30, 2023, the Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-23-000024:notes:333]
| Jurisdiction | NOL Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Malaysia | $ | 106 |  |  | 2025 to 2028 |
| Belgium | 106 |  |  | No expiration |
| Japan | 72 |  |  | 2024 to 2031 |
| Spain | 45 |  |  | No expiration |
| Netherlands | 12 |  |  | 2025 to 2026 |

[0000106040-23-000024:notes:334]
Uncertain Tax Positions

[0000106040-23-000024:notes:335]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets.

[0000106040-23-000024:notes:336]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-23-000024:notes:337]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 1,047 |  |  | $ | 748 |  |  | $ | 717 |  |
| Gross increases related to current year tax positions | 7 |  |  | 12 |  |  | 21 |  |
| Gross increases related to prior year tax positions | 22 |  |  | 358 |  |  | 46 |  |
| Gross decreases related to prior year tax positions | (47) |  |  | (65) |  |  | (20) |  |
| Settlements | (5) |  |  | (1) |  |  | (9) |  |
| Lapse of statute of limitations | (3) |  |  | (5) |  |  | (7) |  |
| Unrecognized tax benefit, ending balance | $ | 1,021 |  |  | $ | 1,047 |  |  | $ | 748 |  |

[0000106040-23-000024:notes:338]
As of June 30, 2023, July 1, 2022 and July 2, 2021, the portion of the gross unrecognized tax benefits, if recognized, that would affect the effective tax rate is $855 million, $903 million, and $612 million, respectively. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 30, 2023, July 1, 2022 and July 2, 2021 was $289 million, $254 million and $138 million, respectively. As of June 30, 2023, July 1, 2022 and July 2, 2021, the Company’s payables related to unrecognized tax benefits, including accrued interest and penalties, were $1.14 billion, $1.16 billion, and $750 million, respectively. The Company believes it is reasonably likely that payments of approximately $720 million to $760 million may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on the Consolidated Balance Sheets as of June 30, 2023. The remaining payables related to unrecognized tax benefits are included in Other liabilities on the Consolidated Balance Sheets as of June 30, 2023, July 1, 2022 and July 2, 2021.

[0000106040-23-000024:notes:339]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for 2013 through 2020. The Company is no longer subject to examination by the IRS for periods prior to 2012, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the following major foreign jurisdictions where there is no tax holiday, the Company could be subject to examination as noted below:

[0000106040-23-000024:notes:340]
| Jurisdiction |  | Period Subject to Examination |
| China (calendar) |  | 2013-2022 |
| Ireland (fiscal) |  | 2019-2022 |
| India (fiscal) |  | 2009-2022 |
| Israel (fiscal) |  | 2014-2022 |
| Japan (fiscal) |  | 2016-2022 |
| Malaysia (fiscal) |  | 2015-2022 |
| Thailand (fiscal) |  | 2013-2022 |
| Singapore (fiscal) |  | 2019-2022 |
| United Kingdom (fiscal) |  | 2021-2022 |

[0000106040-23-000024:notes:341]
The Company reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012. In addition, the Company has tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. As of June 30, 2023, the Company has recognized a liability for tax and interest of $753 million related to all years from 2008 through 2015. The Company expects to pay $523 million in the first quarter of 2024 with respect to years 2008 and 2012 and expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000024:notes:342]
In connection with settlements for years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $160 million to $180 million.

[0000106040-23-000024:notes:343]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 30, 2023, with the exception of the tentative settlement with the IRS, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information relating to the examination of the Company’s tax returns.


## us-gaap:SummaryOfOperatingLossCarryforwardsTextBlock

[0000106040-23-000024:notes:344]
Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-23-000024:notes:345]
The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:


## us-gaap:EarningsPerShareTextBlock

[0000106040-23-000024:notes:346]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-23-000024:notes:347]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions, except per share data) |
| Net income (loss) |  |  |  |  | $ | (1,706) |  |  | $ | 1,500 |  |  | $ | 821 |  |
| Less: cumulative dividends allocated to preferred shareholders |  |  |  |  | 24 |  |  | — |  |  | — |  |
| Net income (loss) attributable to common shareholders |  |  |  |  | $ | (1,730) |  |  | $ | 1,500 |  |  | $ | 821 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 318 |  |  | 312 |  |  | 305 |  |
| Employee stock options, RSUs, PSUs and ESPP |  |  |  |  | — |  |  | 4 |  |  | 4 |  |
| Diluted |  |  |  |  | 318 |  |  | 316 |  |  | 309 |  |
| Income (loss) per common share: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | (5.44) |  |  | $ | 4.81 |  |  | $ | 2.69 |  |
| Diluted |  |  |  |  | $ | (5.44) |  |  | $ | 4.75 |  |  | $ | 2.66 |  |
| Anti-dilutive potential common shares excluded |  |  |  |  | 14 |  |  | 3 |  |  | 5 |  |

[0000106040-23-000024:notes:348]
Basic income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income (loss) per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The “if-converted” method is used to determine the dilutive impact for the shares issuable in connection with the 1.50% convertible notes due 2024 and the convertible preferred stock, and the treasury stock method is used to determine the dilutive impact of outstanding employee stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP.

[0000106040-23-000024:notes:349]
For 2023, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for the period because their impact would have been anti-dilutive. For 2022 and 2021, the Company excluded common shares subject to certain outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during those periods.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-23-000024:notes:350]
Employee Termination, Asset Impairment, and Other Charges
Business Realignment

[0000106040-23-000024:notes:351]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. The Company recognized gains related to the disposition of assets associated with these activities of $8 million, $7 million and $75 million for 2023, 2022 and 2021, respectively. The Company recorded the following charges related to these actions:

[0000106040-23-000024:notes:352]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| Employee termination benefits |  |  |  |  | $ | 176 |  |  | $ | 50 |  |  | $ | 28 |  |
| Asset impairments and other charges (gains) |  |  |  |  | 17 |  |  | (7) |  |  | (75) |  |
| Total employee termination, asset impairment, and other charges |  |  |  |  | $ | 193 |  |  | $ | 43 |  |  | $ | (47) |  |

[0000106040-23-000024:notes:353]
The following table presents an analysis of the components of these activities against the reserve during the year ended June 30, 2023:

[0000106040-23-000024:notes:354]
|  | Employee Termination Benefits |  |
|  | (in millions) |
| Accrual balance at July 1, 2022 | $ | 17 |  |  |
| Charges | 176 |  |  |
| Cash payments | (162) |  |  |
| Accrual balance at June 30, 2023 | $ | 31 |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-23-000024:notes:355]
Legal Proceedings
Tax

[0000106040-23-000024:notes:356]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and the status of resolution with respect to certain matters, see Note 14, Income Tax Expense.

[0000106040-23-000024:notes:357]
Other Matters

[0000106040-23-000024:notes:358]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
