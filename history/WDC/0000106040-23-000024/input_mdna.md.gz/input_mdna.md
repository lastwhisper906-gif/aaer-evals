# WDC MD&A — 0000106040-23-000024


## mdna

[0000106040-23-000024:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-23-000024:mdna:2]
Our Company

[0000106040-23-000024:mdna:3]
We are on a mission to unlock the potential of data by harnessing the possibility to use it. We are a leading developer, manufacturer, and provider of data storage devices based on both NAND flash and hard disk drive technologies. With dedicated flash-based products (“Flash”) and hard disk drives (“HDD”) business units driving advancements in storage technologies, our broad and ever-expanding portfolio delivers powerful Flash and HDD storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-23-000024:mdna:4]
Our broad portfolio of technology and products address our multiple end markets: “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers, which we believe we are uniquely positioned to address as the only provider of both Flash and HDD. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-23-000024:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2023, 2022, and 2021, which ended on June 30, 2023, July 1, 2022, and July 2, 2021, respectively, each comprised 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-23-000024:mdna:6]
Key Developments

[0000106040-23-000024:mdna:7]
Network Security Incident

[0000106040-23-000024:mdna:8]
As previously disclosed, on March 26, 2023, we identified a network security incident in which an unauthorized third party gained access to a number of our systems. Upon discovery of the incident, we implemented incident response efforts, which included taking various systems and services offline as a proactive measure to secure our business operations and initiating an investigation with the assistance of leading outside security and forensic experts. In collaboration with outside forensic experts, we confirmed that an unauthorized party obtained a copy of a Western Digital database used for our online store that contained some personal information of our online store customers. This information included customer names, billing and shipping addresses, email addresses and telephone numbers. In addition, the database contained, in encrypted format, hashed and salted passwords and partial credit card numbers. We have provided notifications to impacted customers and relevant governmental authorities.

[0000106040-23-000024:mdna:9]
The incident, together with the incident response efforts discussed above, resulted in some disruptions to our business operations, including manufacturing, sales, fulfillment and general corporate activities. We were able to stabilize core operations after a short period of time and brought impacted systems back online in order of operational priority. The incident did not have a material impact on the financial results in 2023.

[0000106040-23-000024:mdna:10]
Investigation, recovery, and remediation expenses, including costs for forensics activities, third-party consulting and service providers, outside legal advisors, and other IT professionals, as a result of the network security incident were not material to the Consolidated Financial Statements. We maintain cyber insurance, subject to certain deductibles and policy limitations, typical for our size and industry.

[0000106040-23-000024:mdna:11]
Strategic Alternatives

[0000106040-23-000024:mdna:12]
In June 2022, we announced that we are reviewing potential strategic alternatives aimed at further optimizing long-term value for stockholders. The Executive Committee of our Board of Directors is overseeing the assessment process and evaluating a range of alternatives, including options for separating our Flash and HDD business units. As of June 30, 2023, we are still actively working with financial advisors and our legal counsel in this strategic review process.

[0000106040-23-000024:mdna:13]
Tax Resolution

[0000106040-23-000024:mdna:14]
As disclosed in previous periods, we have received statutory notices of deficiency and notices of proposed adjustments from the Internal Revenue Service (“IRS”) with respect to 2008 through 2015. During the third quarter of 2023, we and the IRS reached an agreement on the federal tax and interest calculations with respect to the years 2008 through 2012 and a tentative settlement for the years 2013 through 2015. Additional information is provided in our discussion of Income tax expense in our results of operations below, as well as in Part II, Item 8, Note 14, Income Tax Expense, of the Notes to the Consolidated Financial Statements, and in the “Short- and Long-Term Liquidity - Unrecognized Tax Benefits” section below.

[0000106040-23-000024:mdna:15]
Financing Activities

[0000106040-23-000024:mdna:16]
In December 2022 and in June 2023, we amended the loan agreement governing our Term Loan A-2 and revolving credit facility to provide additional financial flexibility as we navigate through the current dynamic economic environment. The amendments modified our financial covenant requirements, including modifying the leverage ratio requirements, and introducing a minimum liquidity covenant applicable through the quarter ending September 27, 2024 and a minimum free cash flow requirement applicable through the quarter ending December 29, 2023.

[0000106040-23-000024:mdna:17]
The amendment also accelerates the due date for amounts outstanding under the loan agreement from January 7, 2027 to November 2, 2023 if, as of that date, our cash and cash equivalents plus available unused capacity under our credit facilities do not exceed by $1.40 billion the sum of the outstanding balance of our 1.50% convertible notes due 2024 plus the outstanding principal amount of any other debt maturing within twelve months.

[0000106040-23-000024:mdna:18]
In January 2023, we entered into a new delayed draw term loan agreement, which was then amended in June 2023. As amended, the agreement allowed us to draw a loan of up to $600 million which we exercised in full in August 2023 (the “Delayed Draw Term Loan”). Borrowings on this loan will mature on June 28, 2024 or such earlier date that conditions for acceleration of amounts due under the loan agreement governing our Term Loan A-2 and revolving credit facility have been triggered as described above.

[0000106040-23-000024:mdna:19]
Also in January, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. We believe these transactions will provide us with greater financial flexibility to manage our business.

[0000106040-23-000024:mdna:20]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, and additional information on the terms of our convertible preferred shares is included in Part II, Item 8, Note 8, Debt, and Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:21]
Operational Update

[0000106040-23-000024:mdna:22]
Macroeconomic factors such as inflation, higher interest rates and recession concerns have softened demand for our products, with certain customers reducing purchases as they adjust their production levels and right-size their inventories. As a result, we and our industry are experiencing a supply-demand imbalance, which has resulted in reduced shipments and negatively impacted pricing, particularly in Flash. While supply-demand imbalance has somewhat stabilized beginning in the third quarter of 2023, particularly in Client and Consumer, we continue to face a dynamic market environment. To adapt to these conditions, since the beginning of 2023, we have scaled back on capital expenditures, consolidated production lines and reduced bit growth to align with market demand and implemented measures to reduce operating expenses. This has resulted in incremental charges for employee termination, asset impairment and other charges and manufacturing underutilization charges in Flash and HDD in 2023, and is expected to impact near-term results. However, we believe digital transformation will continue to drive long-term growth for data storage in both Flash and HDD and believe that the actions we are taking will position us to capitalize on market conditions when they improve to address long-term growth opportunities in data storage across all our end markets.

[0000106040-23-000024:mdna:23]
We will continue to actively monitor developments impacting our business and may take additional responsive actions that we determine to be in the best interest of our business and stakeholders.

[0000106040-23-000024:mdna:24]
We believe we have made significant progress in strengthening our product portfolio to meet our customers’ growing and evolving storage needs. Our new industry-leading 22-terabyte conventional magnetic recording drives and 26-terabyte shingled magnetic recording drives, utilizing OptiNAND technology, have commenced commercial shipments. We also have commenced product sampling of our latest 28-terabyte Ultra SMR drive, which built upon proven ePMR and UltraSMR technology, with full feature and performance compatibility, as well as the reliability trusted by our customers worldwide. During 2023, we announced BiCS8 node, the newest 3D-flash memory technology based on a chip-bonded-to-array architecture.

[0000106040-23-000024:mdna:25]
See Part I, Item 1A, Risk Factors, of this Annual Report on Form 10-K for more information regarding the risks we face as a result of macroeconomic conditions, and supply chain disruptions.

[0000106040-23-000024:mdna:26]
35

[0000106040-23-000024:mdna:27]
Results of Operations

[0000106040-23-000024:mdna:28]
Summary Comparison of 2023, 2022 and 2021

[0000106040-23-000024:mdna:29]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-23-000024:mdna:30]
|  |  |  |  |  |  |  |  |  | 2023 |  | 2022 |  |  |  | 2021 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 12,318 |  |  | 100.0 | % |  | $ | 18,793 |  |  | 100.0 | % |  |  |  | $ | 16,922 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 10,431 |  |  | 84.7 |  |  | 12,919 |  |  | 68.7 |  |  |  |  | 12,401 |  |  | 73.3 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 1,887 |  |  | 15.3 |  |  | 5,874 |  |  | 31.3 |  |  |  |  | 4,521 |  |  | 26.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 2,009 |  |  | 16.3 |  |  | 2,323 |  |  | 12.4 |  |  |  |  | 2,243 |  |  | 13.3 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 970 |  |  | 7.9 |  |  | 1,117 |  |  | 5.9 |  |  |  |  | 1,105 |  |  | 6.5 |  |
| Employee termination, asset impairment, and other charges |  |  |  |  |  |  |  |  |  |  |  |  | 193 |  |  | 1.6 |  |  | 43 |  |  | 0.2 |  |  |  |  | (47) |  |  | (0.3) |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 3,172 |  |  | 25.8 |  |  | 3,483 |  |  | 18.5 |  |  |  |  | 3,301 |  |  | 19.5 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (1,285) |  |  | (10.4) |  |  | 2,391 |  |  | 12.7 |  |  |  |  | 1,220 |  |  | 7.2 |  |
| Interest and other income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 24 |  |  | 0.2 |  |  | 6 |  |  | — |  |  |  |  | 7 |  |  | — |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (312) |  |  | (2.5) |  |  | (304) |  |  | (1.6) |  |  |  |  | (326) |  |  | (1.9) |  |
| Other income, net |  |  |  |  |  |  |  |  |  |  |  |  | 13 |  |  | 0.1 |  |  | 30 |  |  | 0.2 |  |  |  |  | 26 |  |  | 0.2 |  |
| Total interest and other income, net |  |  |  |  |  |  |  |  |  |  |  |  | (275) |  |  | (2.2) |  |  | (268) |  |  | (1.4) |  |  |  |  | (293) |  |  | (1.7) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | (1,560) |  |  | (12.7) |  |  | 2,123 |  |  | 11.3 |  |  |  |  | 927 |  |  | 5.5 |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 146 |  |  | 1.2 |  |  | 623 |  |  | 3.3 |  |  |  |  | 106 |  |  | 0.6 |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (1,706) |  |  | (13.8) |  |  | 1,500 |  |  | 8.0 |  |  |  |  | 821 |  |  | 4.9 |  |
| Less: cumulative dividends allocated to preferred shareholders |  |  |  |  |  |  |  |  |  |  |  |  | 24 |  |  | 0.2 |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Net income (loss) attributable to common shareholders |  |  |  |  |  |  |  |  |  |  |  |  | $ | (1,730) |  |  | (14.0) | % |  | $ | 1,500 |  |  | 8.0 | % |  |  |  | $ | 821 |  |  | 4.9 | % |

[0000106040-23-000024:mdna:31]
(1)Percentage may not total due to rounding.

[0000106040-23-000024:mdna:32]
The following table sets forth, for the periods presented, a summary of our segment information:

[0000106040-23-000024:mdna:33]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Flash | $ | 6,063 |  | $ | 9,753 |  | $ | 8,706 |
| HDD | 6,255 |  | 9,040 |  | 8,216 |
| Total net revenue | $ | 12,318 |  | $ | 18,793 |  | $ | 16,922 |
| Gross profit: |  |  |  |  |  |
| Flash | $ | 433 |  | $ | 3,527 |  | $ | 2,611 |
| HDD | 1,505 |  | 2,661 |  | 2,221 |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation expense | (49) |  | (48) |  | (55) |
| Amortization of acquired intangible assets | — |  | (66) |  | (331) |
| Contamination related charges | — |  | (207) |  | — |
| Recoveries from a power outage incident | — |  | 7 |  | 75 |
| Other | (2) |  | — |  | — |
| Total unallocated corporate items | (51) |  | (314) |  | (311) |
| Consolidated gross profit | $ | 1,887 |  | $ | 5,874 |  | $ | 4,521 |
| Gross margin: |  |  |  |  |  |
| Flash | 7.1% |  | 36.2% |  | 30.0% |
| HDD | 24.1% |  | 29.4% |  | 27.0% |
| Consolidated gross margin | 15.3% |  | 31.3% |  | 26.7% |

[0000106040-23-000024:mdna:34]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0000106040-23-000024:mdna:35]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  |  |  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 5,252 |  |  | $ | 8,017 |  |  | $ | 5,723 |  |
| Client |  |  |  |  | 4,328 |  |  | 7,076 |  |  | 7,281 |  |
| Consumer |  |  |  |  | 2,738 |  |  | 3,700 |  |  | 3,918 |  |
| Total Revenue |  |  |  |  | $ | 12,318 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 6,046 |  |  | $ | 10,054 |  |  | $ | 9,455 |  |
| Americas |  |  |  |  | 4,172 |  |  | 5,867 |  |  | 4,406 |  |
| Europe, Middle East and Africa |  |  |  |  | 2,100 |  |  | 2,872 |  |  | 3,061 |  |
| Total Revenue |  |  |  |  | $ | 12,318 |  |  | $ | 18,793 |  |  | $ | 16,922 |  |
| Exabytes Shipped |  |  |  |  | 501 |  |  | 645 |  |  | 541 |  |

[0000106040-23-000024:mdna:36]
Net Revenue

[0000106040-23-000024:mdna:37]
Net revenue decreased 34% in 2023 compared to 2022, primarily reflecting the supply-demand imbalance and macroeconomic pressures described in the “Operational Update” above.

[0000106040-23-000024:mdna:38]
Flash revenue decreased 38% in 2023 compared to 2022, substantially all driven by a decline in the average selling prices per gigabyte across all our end markets.

[0000106040-23-000024:mdna:39]
37

[0000106040-23-000024:mdna:40]
HDD revenue decreased 31% in 2023, compared to 2022, primarily driven by an approximately 26% decrease in exabytes sold and a decline in the average selling prices. The decrease in exabytes sold was primarily driven by lower shipments to customers in our Cloud end market and to a lesser extent in Client and Consumer end markets.

[0000106040-23-000024:mdna:41]
The 34% decrease in Cloud revenue in 2023 compared to 2022, reflects approximately 25 percentage points driven by a decline in HDD revenue as customers reduced purchases to right-size their inventories, and approximately 9 percentage points driven by a decline in Flash revenue resulting primarily from a decrease in shipments, as well as from lower average selling prices of our flash-based products. In Client, the 39% decrease in revenue in 2023 compared to 2022 reflects approximately 34 percentage points driven by a decline in Flash revenue due to pricing pressure across Flash and approximately 5 percentage points driven by a decline in HDD shipments. In Consumer, the 26% decrease in revenues in 2023 compared to 2022, was relatively evenly split between decreases in average selling price per gigabyte in Flash and a decline in retail HDD shipments.

[0000106040-23-000024:mdna:42]
The changes in net revenue by geography in 2023, compared to 2022, primarily reflect a larger decline in Asia from lower Client revenue from OEMs in this region as they reduced purchases to align with current market demand, as well as routine variations in the mix of business.

[0000106040-23-000024:mdna:43]
For 2023, 2022 and 2021, our top 10 customers accounted for 43%, 45% and 39%, respectively, of our net revenue. For each of 2023, 2022 and 2021, no single customer accounted for 10% or more of our net revenue.

[0000106040-23-000024:mdna:44]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2023, 2022 and 2021, these programs represented 20%, 17% and 19%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue over the last three years. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-23-000024:mdna:45]
Gross Profit and Gross Margin

[0000106040-23-000024:mdna:46]
Consolidated gross profit decreased $3.99 billion, or 68%, in 2023 compared to 2022, which reflected the decrease in revenue described above as well as an aggregate of approximately $605 million for manufacturing underutilization and related charges and a write-down of certain Flash inventory to the lower of cost or market value ($404 million in Flash and $201 million in HDD), partially offset by $207 million of charges related to a contamination event in the Flash Ventures’ fabrication facilities incurred in the prior year, and a $66 million decrease in charges related to amortization expense on acquired intangible assets, some of which became fully amortized in 2023. Consolidated gross margin decreased 16 percentage points over the prior year with approximately 4 percentage points of the decline due to the net charges noted above and the remainder driven by the lower average selling prices per gigabyte in Flash. Flash gross margin decreased by 29.1 percentage points year over year, substantially driven by lower average selling prices per gigabyte in Flash with approximately 4 percentage points driven by year-over-year changes in the charges noted above. HDD gross margin decreased by 5.3 percentage points year over year, with approximately 3 percentage points of the decline due to the underutilization charges noted above and the remainder primarily reflecting lower average selling prices per gigabyte and variation in the mix of products.

[0000106040-23-000024:mdna:47]
Operating Expenses

[0000106040-23-000024:mdna:48]
R&D expense decreased $314 million or 14% in 2023 compared to 2022, which reflects reductions in headcount and variable compensation expense as well as savings resulting from our actions to reduce expenses in the current dynamic economic environment.

[0000106040-23-000024:mdna:49]
Selling, general and administrative (“SG&A”) expense decreased $147 million or 13% in 2023 compared to 2022, which reflects reductions in headcount, variable compensation expense and professional fees as well as savings resulting from our actions to reduce expenses in the current dynamic economic environment.

[0000106040-23-000024:mdna:50]
Employee termination, asset impairment and other charges increased $150 million compared to 2022, primarily due to restructuring actions taken to adjust our cost structure to align with the current demand environment. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 16, Employee Termination, Asset Impairment, and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:51]
Interest and Other Income

[0000106040-23-000024:mdna:52]
The total interest and other income, net in 2023 was relatively flat compared to 2022, which reflected higher interest expense as a result of increases in interest rates and lower other income, partially offset by $29 million of lower amortization of the debt discount as a result of the adoption of ASU 2020-06 (as defined and described in Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K) and higher interest income on our cash and investments due to higher interest rates.

[0000106040-23-000024:mdna:53]
Income Tax Expense

[0000106040-23-000024:mdna:54]
The Tax Cuts and Jobs Act (the “2017 Act”) includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-23-000024:mdna:55]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The CAMT will be effective for us beginning with fiscal year 2024. We are currently evaluating the potential effects of these legislative changes.

[0000106040-23-000024:mdna:56]
The following table sets forth Income tax information from our Consolidated Statement of Operations by dollar and effective tax rate:

[0000106040-23-000024:mdna:57]
|  |  |  |  |  | 2023 |  | 2022 |  | 2021 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | (1,560) |  |  | $ | 2,123 |  |  | $ | 927 |  |
| Income tax expense |  |  |  |  | 146 |  |  | 623 |  |  | 106 |  |
| Effective tax rate |  |  |  |  | (9) | % |  | 29 | % |  | 11 | % |

[0000106040-23-000024:mdna:58]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in Income tax expense, but did not have a material impact on our effective tax rate.

[0000106040-23-000024:mdna:59]
The primary drivers of the difference between the effective tax rate for 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031.

[0000106040-23-000024:mdna:60]
The primary drivers of the difference between the effective tax rate for 2022 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2024 through 2031. In addition, the effective tax rate for 2022 includes a net increase of $352 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of our discussions with various taxing authorities. This amount includes $324 million related to the effects of the final settlement with the IRS resolving the statutory notices of deficiency with respect to 2008 through 2012 and the tentative settlement reached with the IRS resolving the notices of proposed adjustments with respect to 2013 through 2015.

[0000106040-23-000024:mdna:61]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. Our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-23-000024:mdna:62]
For additional information regarding Income tax expense, see Part II, Item 8, Note 14, Income Tax Expense, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:63]
A discussion of our results of operations for 2021, including a comparison of such results of operations to 2022, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, included in our Annual Report on Form 10-K for the year ended July 1, 2022 filed with the Securities and Exchange Commission on August 25, 2022.

[0000106040-23-000024:mdna:64]
40

[0000106040-23-000024:mdna:65]
Liquidity and Capital Resources

[0000106040-23-000024:mdna:66]
The following table summarizes our statements of cash flows:

[0000106040-23-000024:mdna:67]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (408) |  |  | $ | 1,880 |  |  | $ | 1,898 |  |
| Investing activities | (762) |  |  | (1,192) |  |  | (765) |  |
| Financing activities | 875 |  |  | (1,718) |  |  | (817) |  |
| Effect of exchange rate changes on cash | (9) |  |  | (13) |  |  | 6 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (304) |  |  | $ | (1,043) |  |  | $ | 322 |  |

[0000106040-23-000024:mdna:68]
We reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012. In addition, we have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. As of June 30, 2023, we have recognized a liability for tax and interest of $753 million related to all years from 2008 through 2015. We expect to pay $523 million in the first quarter of 2024 with respect to years 2008 through 2012 and expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000024:mdna:69]
In connection with settlements for years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $160 million to $180 million. See Part I, Item 1, Note 14, Income Tax Expense for further details.

[0000106040-23-000024:mdna:70]
The $1.10 billion principal amount of our 1.50% convertible notes due 2024 will mature on February 1, 2024, and we are required to settle any conversion value with the principal amount settled in cash and any excess in cash, shares of the Company’s common stock, or a combination thereof pursuant to the terms of the indenture, dated as of February 13, 2018. See Part I, Item 1, Note 8, Debt for further details.

[0000106040-23-000024:mdna:71]
As further described under “Key Developments - Financing Activities” above, in December 2022 and June 2023, we modified certain financial covenant requirements in the loan agreement governing our Term Loan A-2 and revolving credit facility. In addition, in January 2023, we entered into a delayed draw term loan agreement, which was then amended in June 2023 and fully drawn in the amount of $600 million in August 2023. In January 2023, we also issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. We believe these transactions will provide us with greater financial flexibility to manage our business.

[0000106040-23-000024:mdna:72]
We have an existing shelf registration statement (the “Shelf Registration Statement”) filed with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-23-000024:mdna:73]
As noted previously, we have been scaling back on capital expenditures, consolidating production lines and reducing bit growth to align with market demand. We reduced our expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to approximately $1.4 billion in 2023 from approximately $1.5 billion in 2022. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we reduced our net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to $793 million in 2023 from $1.2 billion in 2022. We expect the capital expenditures for 2024 to be less than 2023.

[0000106040-23-000024:mdna:74]
We believe our cash, and cash equivalents including the proceeds from the drawdown of the Delayed Draw Term Loan, as discussed in “Key Developments - Financing Activities” above, as well as our available revolving credit facility, will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter, as we navigate the current market downturn before returning to profitable operations and positive cash flows when the market normalizes. We believe we can also access the various capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:75]
A total of $1.28 billion and $1.82 billion of our cash and cash equivalents were held outside of the U.S. as of June 30, 2023 and July 1, 2022, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-23-000024:mdna:76]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-23-000024:mdna:77]
Operating Activities

[0000106040-23-000024:mdna:78]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash provided by changes in operating assets and liabilities was $90 million for 2023, as compared to $1.08 billion for 2022, which reflects the reduction in the volume of our business. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. At the end of the respective fourth quarters, the cash conversion cycles were as follows (in days):

[0000106040-23-000024:mdna:79]
|  | 2023 |  | 2022 |  | 2021 |
|  | (in days) |
| Days sales outstanding | 54 |  |  | 56 |  |  | 42 |  |
| Days in inventory | 130 |  |  | 107 |  |  | 98 |  |
| Days payables outstanding | (56) |  |  | (66) |  |  | (63) |  |
| Cash conversion cycle | 128 |  |  | 97 |  |  | 77 |  |

[0000106040-23-000024:mdna:80]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-23-000024:mdna:81]
DSO decreased by 2 days over the prior year, reflecting timing of shipments and customer collections. DIO increased by 23 days over the prior year, primarily reflecting a decline in products shipped in light of the current market environment. DPO decreased 10 days over the prior year, primarily due to reductions in production volume and capital expenditures as well as routine variations in the timing of purchases and payments during the period.

[0000106040-23-000024:mdna:82]
Investing Activities

[0000106040-23-000024:mdna:83]
Net cash used in investing activities in 2023 primarily consisted of $821 million in capital expenditures, partially offset by a $14 million net decrease in notes receivable issuance to Flash Ventures and $14 million in net proceeds from the sale of property, plant, and equipment. Net cash used in investing activities in 2022 primarily consisted of a $1.12 billion of capital expenditures, partially offset by a $91 million net increase in notes receivable issuances to Flash Ventures.

[0000106040-23-000024:mdna:84]
Financing Activities

[0000106040-23-000024:mdna:85]
During 2023, net cash provided by financing activities primarily consisted of $881 million from the issuance of Series A Preferred Stock and $93 million from issuance of stock under employee stock plans, partially offset by $80 million used for taxes paid on vested stock awards under employee stock plans. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the period. Cash used in financing activities in 2022 primarily consisted of $3.62 billion for repayment of debt, as well as $122 million for taxes paid on vested stock awards under employee stock plans, partially offset by net proceeds of $1.87 billion from the issuance of new debt and $90 million from the issuance of stock under employee stock plans.

[0000106040-23-000024:mdna:86]
A discussion of our cash flows for the year ended July 2, 2021 is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended July 1, 2022 filed with the Securities and Exchange Commission on August 25, 2022.

[0000106040-23-000024:mdna:87]
42

[0000106040-23-000024:mdna:88]
Off-Balance Sheet Arrangements

[0000106040-23-000024:mdna:89]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity - Indemnifications” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:90]
43

[0000106040-23-000024:mdna:91]
Short- and Long-term Liquidity

[0000106040-23-000024:mdna:92]
Material Cash Requirements

[0000106040-23-000024:mdna:93]
In addition to cash requirements for unrecognized tax benefits and dividend rights with respect to the Series A Preferred Stock discussed below, the following is a summary of our known material cash requirements, including those for capital expenditures, as of June 30, 2023:

[0000106040-23-000024:mdna:94]
|  | Total |  | 1 Year (2024) |  | 2-3 Years (2025-2026) |  | 4-5 Years (2027-2028) |  | More than 5 Years (Beyond 2028) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,100 |  |  | $ | 1,213 |  |  | $ | 2,600 |  |  | $ | 2,287 |  |  | $ | 1,000 |  |
| Interest on debt | 1,091 |  |  | 342 |  |  | 555 |  |  | 118 |  |  | 76 |  |
| Flash Ventures related commitments(2) | 3,912 |  |  | 1,859 |  |  | 1,613 |  |  | 537 |  |  | (97) |  |
| Operating leases | 334 |  |  | 49 |  |  | 94 |  |  | 77 |  |  | 114 |  |
| Purchase obligations and other commitments | 3,102 |  |  | 2,589 |  |  | 316 |  |  | 67 |  |  | 130 |  |
| Mandatory deemed repatriation tax | 663 |  |  | 199 |  |  | 464 |  |  | — |  |  | — |  |
| Total | $ | 16,202 |  |  | $ | 6,251 |  |  | $ | 5,642 |  |  | $ | 3,086 |  |  | $ | 1,223 |  |

[0000106040-23-000024:mdna:95]
(1)Principal portion of debt, excluding discounts and issuance costs.

[0000106040-23-000024:mdna:96]
(2)Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0000106040-23-000024:mdna:97]
Dividend rights

[0000106040-23-000024:mdna:98]
On January 31, 2023, we issued an aggregate of 900,000 shares of Series A Preferred Stock for an aggregate purchase price of $900 million. These shares are entitled to cumulative preferred dividends. See Part II, Item 8, Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information regarding the dividend provisions.

[0000106040-23-000024:mdna:99]
Debt

[0000106040-23-000024:mdna:100]
In addition to our existing debt, as of June 30, 2023, we had $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. Furthermore, we drew the Delayed Draw Term Loan in the amount of $600 million as noted in “Key Developments - Financing Activities”. The agreements governing these credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. Our delayed draw term loan agreement and the loan agreement governing our revolving credit facility and our term loan A-2 due 2027 require us to comply with certain financial covenants, consisting of a leverage ratio, a minimum liquidity and a free cash flow requirements. As of June 30, 2023, we were in compliance with these financial covenants.

[0000106040-23-000024:mdna:101]
Flash Ventures

[0000106040-23-000024:mdna:102]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements, of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of June 30, 2023, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0000106040-23-000024:mdna:103]
Purchase Obligations and Other Commitments

[0000106040-23-000024:mdna:104]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0000106040-23-000024:mdna:105]
Mandatory Deemed Repatriation Tax

[0000106040-23-000024:mdna:106]
The following is a summary of our estimated mandatory deemed repatriation tax obligations under the 2017 Act that are payable in the following years (in millions):

[0000106040-23-000024:mdna:107]
|  |  | June 30,2023 |
| 2024 |  | $ | 199 |  |
| 2025 |  | 206 |  |
| 2026 |  | 258 |  |
| Total |  | $ | 663 |  |

[0000106040-23-000024:mdna:108]
For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part II, Item 8, Note 13, Income Tax Expense, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the year ended June 28, 2019.

[0000106040-23-000024:mdna:109]
Unrecognized Tax Benefits

[0000106040-23-000024:mdna:110]
As of June 30, 2023, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $1.02 billion. Accrued interest and penalties related to unrecognized tax benefits as of June 30, 2023, were approximately $289 million. Of these amounts, approximately $1.14 billion could result in potential cash payments.

[0000106040-23-000024:mdna:111]
As noted above, we reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012. In addition, we have tentatively reached a basis for resolving the notices of proposed adjustments with respect to years 2013 through 2015. As of June 30, 2023, we have recognized a liability for tax and interest of $753 million related to all years from 2008 through 2015. We expect to pay $523 million in the first quarter of 2024 with respect to years 2008 through 2012 and expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-23-000024:mdna:112]
In connection with settlements for years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $160 million to $180 million. See Part I, Item 1, Note 14, Income Tax Expense for further details.

[0000106040-23-000024:mdna:113]
Mandatory Research and Development Expense Capitalization

[0000106040-23-000024:mdna:114]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize research and development expenses rather than expensing them in the year incurred, which is expected to result in higher cash tax payments once we return to profitability.

[0000106040-23-000024:mdna:115]
Foreign Exchange Contracts

[0000106040-23-000024:mdna:116]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 8, Note 7, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:117]
Indemnifications

[0000106040-23-000024:mdna:118]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-23-000024:mdna:119]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-23-000024:mdna:120]
Cash Dividend

[0000106040-23-000024:mdna:121]
We issued a quarterly cash dividend from the first quarter of 2013 up to the third quarter of 2020. In April 2020, we suspended our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-23-000024:mdna:122]
Recent Accounting Pronouncements

[0000106040-23-000024:mdna:123]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-23-000024:mdna:124]
Critical Accounting Policies and Estimates

[0000106040-23-000024:mdna:125]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0000106040-23-000024:mdna:126]
Revenue

[0000106040-23-000024:mdna:127]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0000106040-23-000024:mdna:128]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgment and differences between the estimated and actual amounts of variable consideration can be significant.

[0000106040-23-000024:mdna:129]
Inventories

[0000106040-23-000024:mdna:130]
We value inventories at the lower of cost or net realizable value (“NRV”), with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to lower of cost or net realizable value or for obsolete or excess inventory based on assumptions, which requires significant judgement. The determination of NRV involves estimating the average selling prices less any selling expenses of inventory based on market conditions and customer demand. To estimate the average selling prices and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0000106040-23-000024:mdna:131]
We periodically perform an excess and obsolete analysis of our inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. If in any period, we can sell inventories that had been written down to a level below the realized selling price in previous period, higher gross profit would be recognized in that period. While adjustments to these reserves have generally not been material, in 2023, we recorded a charge to Cost of revenue of $130 million, primarily to reduce component inventory to net realizable value as a result of a sudden change in demand for certain products.

[0000106040-23-000024:mdna:132]
Income Taxes

[0000106040-23-000024:mdna:133]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized. The assessment of valuation allowances against our deferred tax assets requires estimations and significant judgment. We continue to assess and adjust its valuation allowance based on operating results and market conditions. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-23-000024:mdna:134]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-23-000024:mdna:135]
Goodwill

[0000106040-23-000024:mdna:136]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently if events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fourth quarter for each reporting unit. As disclosed in Part II, Item 8. Note 3, Business Segments, Geographic Information, and Concentrations of Risk, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K, our management identified several factors that warranted a quantitative analysis of impairment for both the Flash and HDD reporting units during 2023. As disclosed, we are required to use judgment when applying the goodwill impairment test, including in the identification of our reporting units. We also make judgments and assumptions in the assignment of assets and liabilities to our reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each of our reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations. Our recent assessments have indicated that fair value exceeds carrying value by a reasonable margin and we have not identified any impairment indicators for our reporting units.
