# WDC 10-K controls and the auditor's report


## auditors_report

[0000106040-23-000024:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000106040-23-000024:auditors_report:2]
To the Shareholders and Board of Directors

[0000106040-23-000024:auditors_report:3]
Western Digital Corporation:

[0000106040-23-000024:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0000106040-23-000024:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Western Digital Corporation and subsidiaries (the Company) as of June 30, 2023 and July 1, 2022, the related consolidated statements of operations, comprehensive income (loss), cash flows, convertible preferred stock and shareholders’ equity for each of the years in the three-year period ended June 30, 2023, and the related notes (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0000106040-23-000024:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of June 30, 2023 and July 1, 2022, and the results of its operations and its cash flows for each of the years in the three-year period ended June 30, 2023, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0000106040-23-000024:auditors_report:7]
Change in Accounting Principle

[0000106040-23-000024:auditors_report:8]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for convertible debt instruments and convertible preferred stock as of July 2, 2022 due to the adoption of Accounting Standards Update No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity”.

[0000106040-23-000024:auditors_report:9]
Basis for Opinions

[0000106040-23-000024:auditors_report:10]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Item 9A Controls and Procedures - Management's Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000106040-23-000024:auditors_report:11]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000106040-23-000024:auditors_report:12]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000106040-23-000024:auditors_report:13]
Definition and Limitations of Internal Control Over Financial Reporting

[0000106040-23-000024:auditors_report:14]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally

[0000106040-23-000024:auditors_report:15]
50

[0000106040-23-000024:auditors_report:16]
accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000106040-23-000024:auditors_report:17]
Critical Audit Matters

[0000106040-23-000024:auditors_report:18]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000106040-23-000024:auditors_report:19]
Assessment of variable consideration for sales to resellers

[0000106040-23-000024:auditors_report:20]
As discussed in Note 1 to the consolidated financial statements, the Company provides resellers with price protection and other sales incentive programs. The Company uses judgment in its assessment of variable consideration related to these items in contracts to be included in the transaction price. The Company’s estimate of variable consideration for sales to resellers is based on several factors, including historical pricing information, current pricing trends, and channel inventory levels.

[0000106040-23-000024:auditors_report:21]
We identified the assessment of variable consideration for sales to resellers as a critical audit matter. A high degree of subjective auditor judgment was required to evaluate the Company’s historical pricing information and the level of channel inventory used to determine variable consideration for sales to resellers.

[0000106040-23-000024:auditors_report:22]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s process for determining the variable consideration, including certain controls related to historical pricing information and the level of channel inventory. We evaluated historical pricing by inspecting a sample of customer contracts with resellers and comparing the sales incentives earned during the year to the sales incentive program terms and conditions and recalculating amounts paid to the resellers. We tested the channel inventory levels by comparing the on-hand inventory amounts for a sample of resellers to information obtained from the resellers and evaluated the reasonableness of reconciling items.

[0000106040-23-000024:auditors_report:23]
Goodwill Impairment Assessment of the Company’s Reporting Units

[0000106040-23-000024:auditors_report:24]
As discussed in Note 3 to the consolidated financial statements, the goodwill balance as of June 30, 2023 was $10,037 million. The Company tests goodwill for impairment on an annual basis as of the beginning of its fourth quarter or more frequently if events or changes in circumstances indicate that the goodwill may be impaired. The Company performed a quantitative assessment as of the end of the first and second quarters of fiscal 2023 and again as of its annual goodwill impairment test date, and the fair value of each reporting unit was measured based on a combination of valuation techniques, including an income approach and a market approach. Based on the Company’s analysis, the fair value of both reporting units was in excess of the carrying values and therefore, did not result in any goodwill impairment.

[0000106040-23-000024:auditors_report:25]
We identified the assessment of goodwill for impairment for the Company’s reporting units as a critical audit matter. A high degree of subjective auditor judgment was required to evaluate the forecasted revenue, including revenue growth rates, forecasted cost of goods sold, and the company-specific risk premium assumptions used in the income approach to estimate the fair value of the reporting units. The assessment of these assumptions was challenging due to the degree of uncertainty related to future market and economic conditions. Differences in judgment used to determine these assumptions could have a significant effect on the Company’s assessment of the fair value of the reporting units. Additionally, evaluating the company-specific risk premium assumption required specialized skills and knowledge.

[0000106040-23-000024:auditors_report:26]
51

[0000106040-23-000024:auditors_report:27]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s goodwill impairment process, including controls over the development of the forecasted revenue, forecasted cost of goods sold, and the company-specific risk premium assumptions. We evaluated the Company’s forecasted revenue by comparing it to historical results and revenue growth rates projected for peer companies and the industry. We evaluated the Company’s forecasted cost of goods sold by comparing it to historical results and by comparing the forecasted gross margin to historical gross margin for peer companies and the industry. In addition, we involved valuation professionals with specialized skills and knowledge, who assisted in evaluating the company-specific risk premium by comparing management’s financial projections to publicly available forecasts of comparable companies and the Company’s actual operating results in prior years.

[0000106040-23-000024:auditors_report:28]
/s/ KPMG LLP

[0000106040-23-000024:auditors_report:29]
We have served as the Company’s auditor since 1970.

[0000106040-23-000024:auditors_report:30]
Santa Clara, California

[0000106040-23-000024:auditors_report:31]
August 21, 2023

[0000106040-23-000024:auditors_report:32]
52

[0000106040-23-000024:auditors_report:33]
WESTERN DIGITAL CORPORATION


## item_9a

[0000106040-23-000024:item_9a:1]
Item 9A.    Controls and Procedures

[0000106040-23-000024:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000106040-23-000024:item_9a:3]
As required by Rule 13a‑15(b) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Annual Report on Form 10‑K.

[0000106040-23-000024:item_9a:4]
Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Annual Report on Form 10‑K, our disclosure controls and procedures were effective.

[0000106040-23-000024:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0000106040-23-000024:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a‑15(f) and 15d‑15(f) of the Exchange Act) to provide reasonable assurance regarding the reliability of our financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that in reasonable detail accurately and fairly reflect the transactions and dispositions of our assets; (ii) provide reasonable assurance that the transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and our directors; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the financial statements.

[0000106040-23-000024:item_9a:7]
Our management evaluated the effectiveness of our internal control over financial reporting using the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control — Integrated Framework (2013). Based on this evaluation, our management concluded that our internal control over financial reporting was effective as of the end of the period covered by this Annual Report on Form 10‑K. KPMG LLP, our independent registered public accounting firm, which audited the Consolidated Financial Statements included in this Annual Report on Form 10-K, has issued an audit report on our internal control over financial reporting. See Report of Independent Registered Public Accounting Firm herein.

[0000106040-23-000024:item_9a:8]
Changes in Internal Control over Financial Reporting

[0000106040-23-000024:item_9a:9]
There has been no change in our internal control over financial reporting during the fourth quarter ended June 30, 2023, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000106040-23-000024:item_9a:10]
Inherent Limitations of Effectiveness of Controls

[0000106040-23-000024:item_9a:11]
Our management, including our Chief Executive Officer and our Chief Financial Officer, does not expect our internal controls over financial reporting will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the benefits of controls must be considered relative to their costs. Because of the inherent limitations in a system of internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of simple error or mistake. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the control. The design of any system of controls is also based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.

[0000106040-23-000024:item_9a:12]
107
