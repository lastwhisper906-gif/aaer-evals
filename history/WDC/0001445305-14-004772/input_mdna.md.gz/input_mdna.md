# WDC MD&A — 0001445305-14-004772


## mdna

[0001445305-14-004772:mdna:1]
[same as prior period, unchanged from 0000106040-14-000007:mdna:1]

[0001445305-14-004772:mdna:2]
This information should be read in conjunction with the unaudited condensed consolidated financial statements and the notes thereto included in this Quarterly Report on Form 10-Q, and the audited consolidated financial statements and notes thereto and Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, contained in our Annual Report on Form 10-K for the year ended June 27, 2014.

[0001445305-14-004772:mdna:3]
[same as prior period, unchanged from 0000106040-14-000007:mdna:3]

[0001445305-14-004772:mdna:4]
[same as prior period, unchanged from 0000106040-14-000007:mdna:4]

[0001445305-14-004772:mdna:5]
| • | expectations regarding industry demand and pricing in the December quarter and the ability of the industry to support this demand; |

[0001445305-14-004772:mdna:6]
[same as prior period, unchanged from 0000106040-14-000007:mdna:6]

[0001445305-14-004772:mdna:7]
| • | demand for our products in the various markets and factors contributing to such demand; |

[0001445305-14-004772:mdna:8]
[same as prior period, unchanged from 0000106040-14-000007:mdna:8]

[0001445305-14-004772:mdna:9]
[same as prior period, unchanged from 0000106040-14-000007:mdna:9]

[0001445305-14-004772:mdna:10]
[same as prior period, unchanged from 0000106040-14-000007:mdna:10]

[0001445305-14-004772:mdna:11]
| • | emergence of new storage markets for our products; |

[0001445305-14-004772:mdna:12]
[same as prior period, unchanged from 0000106040-14-000007:mdna:12]

[0001445305-14-004772:mdna:13]
[same as prior period, unchanged from 0000106040-14-000007:mdna:13]

[0001445305-14-004772:mdna:14]
[same as prior period, unchanged from 0000106040-14-000007:mdna:14]

[0001445305-14-004772:mdna:15]
[same as prior period, unchanged from 0000106040-14-000007:mdna:15]

[0001445305-14-004772:mdna:16]
[same as prior period, unchanged from 0000106040-14-000007:mdna:16]

[0001445305-14-004772:mdna:17]
[same as prior period, unchanged from 0000106040-14-000007:mdna:17]

[0001445305-14-004772:mdna:18]
[same as prior period, unchanged from 0000106040-14-000007:mdna:18]

[0001445305-14-004772:mdna:19]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0001445305-14-004772:mdna:20]
[same as prior period, unchanged from 0000106040-14-000007:mdna:20]

[0001445305-14-004772:mdna:21]
| • | contributions to our pension plans in fiscal 2015; and |

[0001445305-14-004772:mdna:22]
[same as prior period, unchanged from 0000106040-14-000007:mdna:22]

[0001445305-14-004772:mdna:23]
[same as prior period, unchanged from 0000106040-14-000007:mdna:24]

[0001445305-14-004772:mdna:24]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes

[0001445305-14-004772:mdna:25]
hard disk drives (“HDDs”) and solid-state drives ("SSDs"), direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST, WD and G-Technology brand names.  We currently operate our global business through two independent subsidiaries due to regulatory requirements - HGST and WD.

[0001445305-14-004772:mdna:26]
First Quarter Overview

[0001445305-14-004772:mdna:27]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for Virident, which was acquired on October 17, 2013, sTec, which was acquired on September 12, 2013, and VeloBit, which was acquired on July 9, 2013, are included in our operating results only after the respective dates of acquisition.

[0001445305-14-004772:mdna:28]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal first quarters ended October 3, 2014 and September 27, 2013 consisted of 14 weeks and 13 weeks, respectively. Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0001445305-14-004772:mdna:29]
For the quarter ended October 3, 2014, we believe that overall hard drive industry shipments totaled approximately 147 million units, up 5% from the prior-year period and up 7% from the June quarter.

[0001445305-14-004772:mdna:30]
[same as prior period, unchanged from 0000106040-14-000007:mdna:36]

[0001445305-14-004772:mdna:31]
|  | Three Months Ended |
|  | October 3, 2014 |  | September 27, 2013 |
| Net revenue | $ | 3,943 |  |  | 100.0 | % |  | $ | 3,804 |  |  | 100.0 | % |
| Gross profit | 1,149 |  |  | 29.1 |  |  | 1,099 |  |  | 28.9 |  |
| Total operating expenses | 680 |  |  | 17.2 |  |  | 557 |  |  | 14.6 |  |
| Operating income | 469 |  |  | 11.9 |  |  | 542 |  |  | 14.2 |  |
| Net income | 423 |  |  | 10.7 |  |  | 495 |  |  | 13.0 |  |

[0001445305-14-004772:mdna:32]
The following is a summary of our financial performance for the first quarter of fiscal 2015:

[0001445305-14-004772:mdna:33]
| • | Consolidated net revenue totaled $3.9 billion. |

[0001445305-14-004772:mdna:34]
| • | 55% of our net revenue was derived from non-PC (personal computer) markets, which include enterprise applications, branded products and CE (consumer electronics) products, as compared to 53% in the prior-year period. |

[0001445305-14-004772:mdna:35]
| • | Net revenue derived from enterprise SSDs was $156 million as compared to $106 million in the prior-year period. |

[0001445305-14-004772:mdna:36]
| • | Hard drive unit shipments increased 3% from the prior-year period to 64.7 million units. |

[0001445305-14-004772:mdna:37]
| • | Gross margin increased to 29.1%, compared to 28.9% for the prior-year period. |

[0001445305-14-004772:mdna:38]
| • | Operating income was $469 million, a decrease of $73 million from the prior-year period. |

[0001445305-14-004772:mdna:39]
| • | We generated $827 million in cash flow from operations and we ended the quarter with $5.2 billion in cash and cash equivalents. |

[0001445305-14-004772:mdna:40]
For the quarter ending January 2, 2015, we expect overall hard drive industry shipments and our revenue to decrease moderately as a result of a 13-week December quarter as compared to the 14-week September quarter.

[0001445305-14-004772:mdna:41]
[same as prior period, unchanged from 0000106040-14-000007:mdna:39]

[0001445305-14-004772:mdna:42]
[same as prior period, unchanged from 0000106040-14-000007:mdna:48]

[0001445305-14-004772:mdna:43]
[same as prior period, unchanged from 0000106040-14-000007:mdna:49]

[0001445305-14-004772:mdna:44]
|  | Three MonthsEnded |  |  |
| (in millions, except percentages andaverage selling price) | October 3, 2014 |  | September 27, 2013 |  | Percentage Change |
| Net revenue | $ | 3,943 |  |  | $ | 3,804 |  |  | 4 | % |
| Average selling price (per unit)* | $ | 58 |  |  | $ | 58 |  |  | — | % |
| Revenues by Geography (%) |  |  |  |  |  |
| Americas | 27 | % |  | 26 | % |  |  |
| Europe, Middle East and Africa | 21 |  |  | 20 |  |  |  |
| Asia | 52 |  |  | 54 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |
| OEM | 63 | % |  | 64 | % |  |  |
| Distributors | 24 |  |  | 24 |  |  |  |
| Retailers | 13 |  |  | 12 |  |  |  |
| Unit Shipments* |  |  |  |  |  |
| PC | 39.7 |  |  | 40.2 |  |  |  |
| Non-PC | 25.0 |  |  | 22.4 |  |  |  |
| Total units shipped | 64.7 |  |  | 62.6 |  |  | 3 | % |

[0001445305-14-004772:mdna:45]
[same as prior period, unchanged from 0000106040-14-000007:mdna:51]

[0001445305-14-004772:mdna:46]
For the quarter ended October 3, 2014, net revenue was $3.9 billion, an increase of 4% from the prior-year period. This increase in revenue was primarily due to an increase in total hard drive shipments and an additional week of revenue due to a 14-week quarter. Total hard drive shipments increased to 64.7 million units for the quarter ended October 3, 2014 as compared to 62.6 million units in the prior-year period. For the quarter ended October 3, 2014, average selling price ("ASP") remained flat with the prior-year period at $58.

[0001445305-14-004772:mdna:47]
Changes in revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For the three months ended October 3, 2014, and September 27, 2013, Hewlett-Packard Company accounted for approximately 11% and 13% of our net revenue, respectively.

[0001445305-14-004772:mdna:48]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Generally, total sales incentive and marketing programs range from 7% to 11% of gross revenues per quarter. For the three months ended October 3, 2014, these programs represented 9% of gross revenues, as compared to 7% in the prior-year period. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.7% of quarterly gross revenue since the first quarter of fiscal 2013.

[0001445305-14-004772:mdna:49]
[same as prior period, unchanged from 0000106040-14-000007:mdna:57]

[0001445305-14-004772:mdna:50]
|  | Three MonthsEnded |  |  |
| (in millions, except percentages) | October 3, 2014 |  | September 27, 2013 |  | Percentage Change |
| Net revenue | $ | 3,943 |  |  | $ | 3,804 |  |  | 4 | % |
| Gross profit | 1,149 |  |  | 1,099 |  |  | 5 | % |
| Gross margin | 29.1 | % |  | 28.9 | % |  |  |

[0001445305-14-004772:mdna:51]
For the three months ended October 3, 2014, gross margin as a percentage of revenue increased to 29.1% as compared to 28.9% for the prior-year period. This increase was primarily due to a stronger, seasonal product mix and strength in our capacity enterprise business.

[0001445305-14-004772:mdna:52]
[same as prior period, unchanged from 0000106040-14-000007:mdna:60]

[0001445305-14-004772:mdna:53]
|  | Three MonthsEnded |  |  |
| (in millions, except percentages) | October 3, 2014 |  | September 27, 2013 |  | Percentage Change |
| R&D expense | $ | 437 |  |  | $ | 401 |  |  | 9 | % |
| SG&A expense | 220 |  |  | 132 |  |  | 67 | % |
| Charges related to arbitration award | 14 |  |  | 13 |  |  | 8 | % |
| Employee termination, asset impairment and other charges | 9 |  |  | 11 |  |  | (18 | )% |
| Total operating expenses | $ | 680 |  |  | $ | 557 |  |  |  |

[0001445305-14-004772:mdna:54]
Research and development (“R&D”) expense was $437 million for the three months ended October 3, 2014, an increase of $36 million from the prior-year period. This increase was primarily due to the inclusion of Virident and sTec's R&D expenses and an additional week of operating expenses due to a 14-week quarter. As a percentage of net revenue, R&D expense increased to 11.1% in the three months ended October 3, 2014, as compared to 10.5% in the prior-year period.

[0001445305-14-004772:mdna:55]
Selling, general and administrative (“SG&A”) expense was $220 million for the three months ended October 3, 2014, an increase of $88 million from the prior-year period. This increase was primarily due to the inclusion of Virident and sTec's SG&A expenses, an additional week of operating expenses due to a 14-week quarter and a $65 million flood-related insurance recovery in the prior-year period. SG&A expense as a percentage of net revenue increased to 5.6% in the three months ended October 3, 2014, as compared to 3.5% in the prior-year period.

[0001445305-14-004772:mdna:56]
During the three months ended October 3, 2014, we recorded $14 million of interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC ("Seagate") as compared to $13 million in the prior-year period. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:57]
During the three months ended October 3, 2014, we recorded employee termination, asset impairment and other charges of $9 million in order to realign our operations with anticipated market demand as compared to $11 million in the prior-year period.

[0001445305-14-004772:mdna:58]
[same as prior period, unchanged from 0000106040-14-000007:mdna:66]

[0001445305-14-004772:mdna:59]
Interest income for the three months ended October 3, 2014 increased $1 million as compared to the prior-year period primarily due to a higher average daily invested cash balance for the period. Interest and other expense for the three months ended October 3, 2014 remained flat at $13 million when compared to the prior-year period.

[0001445305-14-004772:mdna:60]
[same as prior period, unchanged from 0000106040-14-000007:mdna:70]

[0001445305-14-004772:mdna:61]
Our income tax provision for both the three months ended October 3, 2014 and September 27, 2013 was $37 million. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits. For additional information, see Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:62]
[same as prior period, unchanged from 0000106040-14-000007:mdna:75]

[0001445305-14-004772:mdna:63]
In relation to our litigation matter with Seagate, on October 8, 2014, the Minnesota Supreme Court affirmed the decision of the Minnesota Court of Appeals, and as a result, on October 14, 2014, we paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 13, 2014. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:64]
[same as prior period, unchanged from 0000106040-14-000007:mdna:68]

[0001445305-14-004772:mdna:65]
[same as prior period, unchanged from 0000106040-14-000007:mdna:79]

[0001445305-14-004772:mdna:66]
We ended the first quarter of fiscal 2015 with total cash and cash equivalents of $5.2 billion. The following table summarizes our statements of cash flows (in millions):

[0001445305-14-004772:mdna:67]
|  | Three months ended |
|  | October 3, 2014 |  | September 27, 2013 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 827 |  |  | $ | 680 |  |
| Investing activities | (126 | ) |  | (360 | ) |
| Financing activities | (346 | ) |  | 240 |  |
| Net increase in cash and cash equivalents | $ | 355 |  |  | $ | 560 |  |

[0001445305-14-004772:mdna:68]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. On January 9, 2014, Western Digital Ireland, Ltd. ("WDI")used existing cash to repay the outstanding term loan balance of $1.8 billion, and we, along with Western Digital Technologies, Inc. ("WDT") and WDI entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"). The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT, and a $1.5 billion revolving credit facility to WDT and WDI (the "Borrowers"). Subject to certain conditions, a Borrower may also elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. For additional information, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, stock repurchase and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:69]
A total of $4.0 billion and $3.5 billion of our cash and cash equivalents was held outside of the United States at October 3, 2014 and June 27, 2014, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. As described in the section "Arbitration Award" above, the amount of $773.4 million was paid on October 14, 2014 from one of our foreign subsidiaries using cash held outside the United States. On September 13, 2012, our Board of Directors approved a capital allocation plan which includes repurchases of our common stock and the adoption of a quarterly cash dividend policy. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or capital allocation plan. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0001445305-14-004772:mdna:70]
[same as prior period, unchanged from 0000106040-14-000007:mdna:84]

[0001445305-14-004772:mdna:71]
Net cash provided by operating activities was $827 million during the three months ended October 3, 2014. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. Net cash provided by working capital changes was $61 million for the three months ended October 3, 2014 as compared to $101 million used by working capital changes in the prior-year period.

[0001445305-14-004772:mdna:72]
[same as prior period, unchanged from 0000106040-14-000007:mdna:86]

[0001445305-14-004772:mdna:73]
|  | Three Months Ended |
|  | October 3, 2014 |  | September 27, 2013 |
| Days sales outstanding | 48 |  |  | 43 |  |
| Days in inventory | 45 |  |  | 42 |  |
| Days payables outstanding | (71 | ) |  | (69 | ) |
| Cash conversion cycle* | 22 |  |  | 16 |  |

[0001445305-14-004772:mdna:74]
| * | Cash conversion cycle for the first quarter of 2015 was calculated using 98 days as a result of a 14-week quarter. |

[0001445305-14-004772:mdna:75]
For the three months ended October 3, 2014, our average days sales outstanding (“DSOs”) increased by 5 days, days in inventory (“DIOs”) increased by 3 days, and days payable outstanding (“DPOs”) increased by 2 days compared to the prior year period. Changes in average DSOs and DIOs are generally related to linearity of shipments and the timing of inventory builds,

[0001445305-14-004772:mdna:76]
[same as prior period, unchanged from 0000106040-14-000007:mdna:77]

[0001445305-14-004772:mdna:77]
respectively. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0001445305-14-004772:mdna:78]
[same as prior period, unchanged from 0000106040-14-000007:mdna:89]

[0001445305-14-004772:mdna:79]
Cash used in investing activities for the three months ended October 3, 2014 was $126 million and consisted primarily of $160 million of capital expenditures, $120 million related to the purchase of investments and $12 million of other investing activities, offset by $166 million of proceeds from sales and maturities of investments. Cash used in investing activities for the three months ended September 27, 2013 was $360 million and consisted primarily of $263 million related to acquisitions, net of cash acquired and $136 million of capital expenditures, offset by a net $39 million for other investing activities, consisting of a flood-related insurance recovery and a strategic investment. For additional information on our cash equivalents and investments, refer to Part I, Item 1, Note 2 and 7 of the Notes to the Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:80]
[same as prior period, unchanged from 0000106040-14-000007:mdna:92]

[0001445305-14-004772:mdna:81]
Net cash used in financing activities for the three months ended October 3, 2014 was $346 million as compared to $240 million provided by financing activities in the prior-year period. Net cash used in financing activities for the three months ended October 3, 2014 consisted of $223 million used to repurchase shares of our common stock, $31 million used to make principal payments on the Credit Agreement and $94 million used to pay dividends on our common stock, offset by a net $2 million provided by employee stock plans. Net cash provided by financing activities for the three months ended September 27, 2013 consisted of $500 million of debt proceeds under the revolving credit facility and a net $7 million provided by employee stock plans, offset by $150 million used to repurchase shares of our common stock, $59 million used to pay dividends on our common stock and $58 million used to repay long-term debt.

[0001445305-14-004772:mdna:82]
[same as prior period, unchanged from 0000106040-14-000007:mdna:94]

[0001445305-14-004772:mdna:83]
[same as prior period, unchanged from 0000106040-14-000007:mdna:95]

[0001445305-14-004772:mdna:84]
[same as prior period, unchanged from 0000106040-14-000007:mdna:96]

[0001445305-14-004772:mdna:85]
Long-Term Debt — On January 9, 2014, Western Digital Ireland, Ltd. (“WDI”) used existing cash to repay the outstanding term loan balance of $1.8 billion, and we, in our capacity as the parent entity and guarantor, and the Borrowers, entered into the new Credit Agreement.

[0001445305-14-004772:mdna:86]
As of October 3, 2014, no amounts were outstanding under the revolving credit facility of the Credit Agreement and the term loan facility had an outstanding balance of $2.4 billion with a variable interest rate of 1.66%. We are required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. For additional information, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:87]
[same as prior period, unchanged from 0000106040-14-000007:mdna:100]

[0001445305-14-004772:mdna:88]
We have entered into long-term purchase agreements with various component suppliers, containing minimum quantity requirements. However, the dollar amount of the purchases may depend on the specific products ordered, achievement of pre-defined quantity or quality specifications or future price negotiations. We have also entered into long-term purchase agreements

[0001445305-14-004772:mdna:89]
with various component suppliers that carry fixed volumes and pricing which obligate us to make certain future purchases, contingent on certain conditions of performance, quality and technology of the vendor’s components.

[0001445305-14-004772:mdna:90]
[same as prior period, unchanged from 0000106040-14-000007:mdna:102]

[0001445305-14-004772:mdna:91]
See Part II, Item 7, "Management’s Discussion and Analysis of Financial Condition and Results of Operations — Contractual Obligations and Commitments” in our Annual Report on Form 10-K for the year ended June 27, 2014, for further discussion of our purchase orders and purchase agreements and the associated dollar amounts. See Part II, Item 1A of this Quarterly Report on Form 10-Q for a discussion of the risks associated with these commitments.

[0001445305-14-004772:mdna:92]
[same as prior period, unchanged from 0000106040-14-000007:mdna:104]

[0001445305-14-004772:mdna:93]
[same as prior period, unchanged from 0000106040-14-000007:mdna:105]

[0001445305-14-004772:mdna:94]
[same as prior period, unchanged from 0000106040-14-000007:mdna:106]

[0001445305-14-004772:mdna:95]
Unrecognized Tax Benefits — As of October 3, 2014, the cash portion of our total recorded liability for unrecognized tax benefits was $252 million. We estimate the timing of the future payments of these liabilities to be within the next one to eight years. For additional information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:96]
Stock Repurchase Program — We repurchased 2.2 million shares of our common stock for a total cost of $223 million during the three months ended October 3, 2014. Subsequent to October 3, 2014 and through November 4, 2014, we repurchased an additional 1.9 million shares of our common stock for a total cost of $175 million. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:97]
Cash Dividend Policy — During the three months ended October 3, 2014, we declared a cash dividend of $0.40 per share of our common stock to our shareholders of record as of October 3, 2014, totaling $94 million, which we paid on October 15, 2014. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0001445305-14-004772:mdna:98]
[same as prior period, unchanged from 0000106040-14-000007:mdna:110]

[0001445305-14-004772:mdna:99]
We have prepared the unaudited condensed consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. We believe the following are our most critical accounting policies that affect significant areas and involve judgment and estimates made by us. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the year ended June 27, 2014. Please refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 27, 2014 for a discussion of our critical accounting policies and estimates.

[0001445305-14-004772:mdna:100]
[same as prior period, unchanged from 0000106040-14-000007:mdna:135]

[0001445305-14-004772:mdna:101]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, refer to Part I, Item 1, Note 13 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.
