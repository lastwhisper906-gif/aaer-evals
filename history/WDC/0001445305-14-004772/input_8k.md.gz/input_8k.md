# WDC 8-K — 0001193125-14-385079 filed 2014-10-28

## item codes, every 8-K on or before 2014-11-04

- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2014-11-04

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-385079:8k_2_02:1]
EX-99.1
2
d812534dex991.htm
EX-99.1

[0001193125-14-385079:8k_2_02:2]
EX-99.1

[0001193125-14-385079:8k_2_02:3]
Exhibit 99.1

[0001193125-14-385079:8k_2_02:4]
Company contacts:

[0001193125-14-385079:8k_2_02:5]
Bob Blair

[0001193125-14-385079:8k_2_02:6]
Western Digital Investor Relations

[0001193125-14-385079:8k_2_02:7]
949.672.7834

[0001193125-14-385079:8k_2_02:8]
robert.blair@wdc.com

[0001193125-14-385079:8k_2_02:9]
Steve Shattuck

[0001193125-14-385079:8k_2_02:10]
Western Digital Public Relations

[0001193125-14-385079:8k_2_02:11]
949.672.7817

[0001193125-14-385079:8k_2_02:12]
steve.shattuck@wdc.com

[0001193125-14-385079:8k_2_02:13]
FOR IMMEDIATE RELEASE:

[0001193125-14-385079:8k_2_02:14]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0001193125-14-385079:8k_2_02:15]
FIRST QUARTER FISCAL 2015

[0001193125-14-385079:8k_2_02:16]
IRVINE, Calif.
— Oct. 28, 2014 — Western Digital® Corp. (NASDAQ: WDC) today reported revenue of $3.9 billion and net income of $423 million, or $1.76 per share, for its first fiscal quarter ended
Oct. 3, 2014. On a non-GAAP basis, net income was $504 million or $2.10 per share. In the year-ago quarter, the company reported revenue of $3.8 billion and net income of $495 million, or $2.05 per share. Non-GAAP net income in the year-ago quarter
was $514 million, or $2.12 per share.

[0001193125-14-385079:8k_2_02:17]
The company generated $827 million in cash from operations during the September quarter, ending
with total cash and cash equivalents of $5.2 billion. During the September quarter, the company utilized $223 million to repurchase 2.2 million shares of common stock. On Aug. 5, the company declared a $0.40 per common-share dividend, which was
paid on Oct. 15.

[0001193125-14-385079:8k_2_02:18]
“We achieved solid revenue, gross margins and EPS in the September quarter, along with continued strong cash flow
generation, as the company continued its crisp execution and consistent financial performance,” said Steve Milligan, president and chief executive officer of Western Digital. “We were pleased to see strength and momentum in our capacity
enterprise hard drive and flash platform solutions businesses. Our client and branded products businesses were seasonally strong as expected and our performance enterprise business was steady. Overall, we believe industry dynamics are stable in
terms of supply and demand and inventory levels.”

[0001193125-14-385079:8k_2_02:19]
Western Digital Announces Financial Results For First Quarter Fiscal 2015

[0001193125-14-385079:8k_2_02:20]
The investment community conference call to discuss these results will be broadcast live over
the Internet today at 2 p.m. Pacific/5 p.m. Eastern. The live and archived conference call webcast can be accessed online at investor.wdc.com. The telephone replay number is 1-800-839-2325 in the U.S. or +1-402-998-1125 for international
callers.

[0001193125-14-385079:8k_2_02:21]
About Western Digital

[0001193125-14-385079:8k_2_02:22]
Founded in 1970, Western Digital Corp. (NASDAQ: WDC), Irvine, Calif., is an industry-leading developer and manufacturer of storage solutions
that enable people to create, manage, experience and preserve digital content. Its HGST and WD® subsidiaries are long-time innovators in the storage industry. Western Digital Corporation is
responding to changing market needs by providing a full portfolio of compelling, high-quality storage products with effective technology deployment, high efficiency, flexibility and speed. Our products are marketed under the HGST, WD and
G-Technology™ brands to OEMs, distributors, resellers, cloud infrastructure providers and consumers. Financial and investor information is available on the company’s Investor Relations website at investor.wdc.com.

[0001193125-14-385079:8k_2_02:23]
Western Digital Announces Financial Results For First Quarter Fiscal 2015

[0001193125-14-385079:8k_2_02:24]
uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Form 10-K filed with the SEC on Aug. 15, 2014,
to which your attention is directed. Readers are cautioned not to place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update these forward-looking statements
to reflect subsequent events or circumstances.

[0001193125-14-385079:8k_2_02:25]
###

[0001193125-14-385079:8k_2_02:26]
Western Digital, WD and the WD logo are registered trademarks in the U.S. and other countries. HGST trademarks are intended and authorized for use only in
countries and jurisdictions in which HGST has obtained the rights to use, market and advertise the brand. Other marks may be mentioned herein that belong to other companies.

[0001193125-14-385079:8k_2_02:27]
WESTERN DIGITAL CORPORATION

[0001193125-14-385079:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-385079:8k_2_02:29]
(in millions; unaudited)

[0001193125-14-385079:8k_2_02:30]
|  |  | Oct. 3,2014 |  |  | Jun. 27,2014 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,159 |  |  | $ | 4,804 |  |
| Short-term investments |  |  | 222 |  |  |  | 284 |  |
| Accounts receivable, net |  |  | 1,915 |  |  |  | 1,989 |  |
| Inventories |  |  | 1,272 |  |  |  | 1,226 |  |
| Other current assets |  |  | 422 |  |  |  | 417 |  |
| Total current assets |  |  | 8,990 |  |  |  | 8,720 |  |
| Property, plant and equipment, net |  |  | 3,202 |  |  |  | 3,293 |  |
| Goodwill |  |  | 2,559 |  |  |  | 2,559 |  |
| Other intangible assets, net |  |  | 406 |  |  |  | 454 |  |
| Other non-current assets |  |  | 495 |  |  |  | 473 |  |
| Total assets |  | $ | 15,652 |  |  | $ | 15,499 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 2,016 |  |  | $ | 1,971 |  |
| Accrued arbitration award |  |  | 772 |  |  |  | 758 |  |
| Accrued expenses |  |  | 433 |  |  |  | 412 |  |
| Accrued compensation |  |  | 438 |  |  |  | 460 |  |
| Accrued warranty |  |  | 134 |  |  |  | 119 |  |
| Current portion of long-term debt |  |  | 125 |  |  |  | 125 |  |
| Total current liabilities |  |  | 3,918 |  |  |  | 3,845 |  |
| Long-term debt |  |  | 2,281 |  |  |  | 2,313 |  |
| Other liabilities |  |  | 490 |  |  |  | 499 |  |
| Total liabilities |  |  | 6,689 |  |  |  | 6,657 |  |
| Total shareholders’ equity |  |  | 8,963 |  |  |  | 8,842 |  |
| Total liabilities and shareholders’ equity |  | $ | 15,652 |  |  | $ | 15,499 |  |

[0001193125-14-385079:8k_2_02:31]
WESTERN DIGITAL CORPORATION

[0001193125-14-385079:8k_2_02:32]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001193125-14-385079:8k_2_02:33]
(in millions, except per share amounts; unaudited)

[0001193125-14-385079:8k_2_02:34]
|  |  | Three Months Ended |  |
|  |  | Oct. 3,2014 |  |  | Sept. 27,2013 |  |
| Revenue, net |  | $ | 3,943 |  |  | $ | 3,804 |  |
| Cost of revenue |  |  | 2,794 |  |  |  | 2,705 |  |
| Gross profit |  |  | 1,149 |  |  |  | 1,099 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 437 |  |  |  | 401 |  |
| Selling, general and administrative |  |  | 220 |  |  |  | 132 |  |
| Charges related to arbitration award |  |  | 14 |  |  |  | 13 |  |
| Employee termination, asset impairment and other charges |  |  | 9 |  |  |  | 11 |  |
| Total operating expenses |  |  | 680 |  |  |  | 557 |  |
| Operating income |  |  | 469 |  |  |  | 542 |  |
| Net interest and other |  |  | (9 | ) |  |  | (10 | ) |
| Income before income taxes |  |  | 460 |  |  |  | 532 |  |
| Income tax provision |  |  | 37 |  |  |  | 37 |  |
| Net income |  | $ | 423 |  |  | $ | 495 |  |
| Income per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.81 |  |  | $ | 2.10 |  |
| Diluted |  | $ | 1.76 |  |  | $ | 2.05 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 234 |  |  |  | 236 |  |
| Diluted |  |  | 240 |  |  |  | 242 |  |

[0001193125-14-385079:8k_2_02:35]
WESTERN DIGITAL CORPORATION

[0001193125-14-385079:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-385079:8k_2_02:37]
(in millions; unaudited)

[0001193125-14-385079:8k_2_02:38]
|  |  | Three Months Ended |  |
|  |  | Oct. 3, |  |  | Sept. 27, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 423 |  |  | $ | 495 |  |
| Adjustments to reconcile net income to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 289 |  |  |  | 312 |  |
| Stock-based compensation |  |  | 39 |  |  |  | 42 |  |
| Deferred income taxes |  |  | 10 |  |  |  | (10 | ) |
| Gain from insurance recovery |  |  | — |  |  |  | (65 | ) |
| Loss on disposal of assets |  |  | 4 |  |  |  | — |  |
| Non-cash portion of employee termination, asset impairment and other charges |  |  | 1 |  |  |  | 7 |  |
| Changes in operating assets and liabilities, net |  |  | 61 |  |  |  | (101 | ) |
| Net cash provided by operating activities |  |  | 827 |  |  |  | 680 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (160 | ) |  |  | (136 | ) |
| Acquisitions, net of cash acquired |  |  | — |  |  |  | (263 | ) |
| Purchases of investments |  |  | (120 | ) |  |  | — |  |
| Proceeds from sales of investments |  |  | 166 |  |  |  | — |  |
| Other investing activities, net |  |  | (12 | ) |  |  | 39 |  |
| Net cash used in investing activities |  |  | (126 | ) |  |  | (360 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Employee stock plans, net |  |  | 2 |  |  |  | 7 |  |
| Repurchases of common stock |  |  | (223 | ) |  |  | (150 | ) |
| Dividends to shareholders |  |  | (94 | ) |  |  | (59 | ) |
| Proceeds from debt, net of issuance costs |  |  | — |  |  |  | 500 |  |
| Repayment of debt |  |  | (31 | ) |  |  | (58 | ) |
| Net cash provided by (used in) financing activities |  |  | (346 | ) |  |  | 240 |  |
| Net increase in cash and cash equivalents |  |  | 355 |  |  |  | 560 |  |
| Cash and cash equivalents, beginning of period |  |  | 4,804 |  |  |  | 4,309 |  |
| Cash and cash equivalents, end of period |  | $ | 5,159 |  |  | $ | 4,869 |  |

[0001193125-14-385079:8k_2_02:39]
WESTERN DIGITAL CORPORATION

[0001193125-14-385079:8k_2_02:40]
GAAP TO NON-GAAP RECONCILIATION

[0001193125-14-385079:8k_2_02:41]
(in millions, except per share amounts; unaudited)

[0001193125-14-385079:8k_2_02:42]
|  |  | Three Months Ended |  |
|  |  | Oct. 3, |  |  | Sept. 27, |  |
|  |  | 2014 |  |  | 2013 |  |
| GAAP net income |  | $ | 423 |  |  | $ | 495 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  | 46 |  |  |  | 47 |  |
| Employee termination, asset impairment and other charges |  |  | 9 |  |  |  | 11 |  |
| Charges related to arbitration award |  |  | 14 |  |  |  | 13 |  |
| Acquisition-related expense |  |  | — |  |  |  | 13 |  |
| Flood-related insurance recovery |  |  | — |  |  |  | (65 | ) |
| Other expense, net |  |  | 12 |  |  |  | — |  |
| Non-GAAP net income |  | $ | 504 |  |  | $ | 514 |  |
| Diluted net income per common share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.76 |  |  | $ | 2.05 |  |
| Non-GAAP |  | $ | 2.10 |  |  | $ | 2.12 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Diluted |  |  | 240 |  |  |  | 242 |  |

[0001193125-14-385079:8k_2_02:43]
The table above sets forth non-GAAP net income and non-GAAP diluted net income per common share. These non-GAAP net income and
diluted net income per common share measures exclude amortization of intangibles related to acquisitions, certain employee termination, asset impairment and other charges, certain charges related to an arbitration award and other charges that are
unusual, non-recurring or may not be indicative of ongoing operations. The Company believes that non-GAAP net income and non-GAAP earnings per share are useful measures to investors as an alternative method for measuring the Company’s earnings
performance and comparing it against prior periods. The presentation of these adjusted amounts vary from numbers presented in accordance with U.S. GAAP and therefore may not be comparable to amounts reported by other companies.
