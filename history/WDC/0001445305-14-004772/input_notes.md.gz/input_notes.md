# WDC notes — 0001445305-14-004772


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001445305-14-004772:notes:1]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments as of October 3, 2014 (in millions):

[0001445305-14-004772:notes:2]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 203 |  |  | $ | — |  |  | $ | 203 |  |
| U.S. Government agency securities | 79 |  |  | — |  |  | 79 |  |
| Commercial paper | 119 |  |  | — |  |  | 119 |  |
| Certificates of deposit | 53 |  |  | — |  |  | 53 |  |
| Total | $ | 454 |  |  | $ | — |  |  | $ | 454 |  |
| Short-term investments |  |  |  |  | $ | 222 |  |
| Included in other non-current assets |  |  |  |  | 232 |  |
| Total |  |  |  |  | $ | 454 |  |

[0001445305-14-004772:notes:3]
The following table summarizes, by major type, the fair value and cost basis of the Company’s investments as of June 27, 2014 (in millions):

[0001445305-14-004772:notes:4]
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |
| U.S. Government agency securities | 88 |  |  | — |  |  | 88 |  |
| Commercial paper | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | 66 |  |  | — |  |  | 66 |  |
| Total | $ | 499 |  |  | $ | — |  |  | $ | 499 |  |
| Short-term investments |  |  |  |  | $ | 284 |  |
| Included in other non-current assets |  |  |  |  | 215 |  |
| Total |  |  |  |  | $ | 499 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001445305-14-004772:notes:5]
[same as prior period, unchanged from 0000106040-14-000007:notes:3]

[0001445305-14-004772:notes:6]
[same as prior period, unchanged from 0000106040-14-000007:notes:4]

[0001445305-14-004772:notes:7]
On October 17, 2013, the Company acquired Virident, a provider of server-side flash storage solutions for virtualization, database, cloud computing and webscale applications. As a result of the acquisition, Virident has been fully integrated into the Company's HGST subsidiary and become a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $613 million, consisting of $598 million which was funded with available cash, and $15 million related to the fair value of stock options assumed. The acquisition furthered HGST's strategy to address the rapidly changing needs of enterprise customers by delivering intelligent storage solutions that maximize application performance by leveraging the tightly coupled server, storage and network resources of today’s converged datacenter infrastructures.

[0001445305-14-004772:notes:8]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $506 million to goodwill. The values assigned to the acquired assets and liabilities were finalized during the three months ended June 27, 2014. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements.

[0001445305-14-004772:notes:9]
The final purchase price allocation for Virident was as follows (in millions):

[0001445305-14-004772:notes:10]
| Tangible assets acquired and liabilities assumed | $ | 58 |  |
| Intangible assets | 49 |  |
| Goodwill | 506 |  |
| Total | $ | 613 |  |

[0001445305-14-004772:notes:11]
The $506 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create server-side flash storage solutions leveraging the core technology acquired and is not expected to be deductible for tax purposes.

[0001445305-14-004772:notes:12]
[same as prior period, unchanged from 0000106040-14-000007:notes:10]

[0001445305-14-004772:notes:13]
On September 12, 2013, the Company completed its acquisition of sTec, a provider of enterprise solid-state drives. As a result of the acquisition, sTec has been fully integrated into the Company's HGST subsidiary and become a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $336 million, consisting of $325 million which was funded with available cash, and $11 million related to the fair value of stock options and RSUs assumed. The acquisition augmented HGST's existing solid-state storage capabilities.

[0001445305-14-004772:notes:14]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $89 million to goodwill. The values assigned to the acquired assets and liabilities were finalized during the three months ended October 3, 2014. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements.

[0001445305-14-004772:notes:15]
The final purchase price allocation for sTec was as follows (in millions):

[0001445305-14-004772:notes:16]
| Tangible assets acquired and liabilities assumed | $ | 189 |  |
| Intangible assets | 58 |  |
| Goodwill | 89 |  |
| Total | $ | 336 |  |

[0001445305-14-004772:notes:17]
The $89 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from augmenting HGST's existing solid-state storage capabilities and accelerating its ability to expand its participation in the growing area of enterprise solid-state drives and is not expected to be deductible for tax purposes.

[0001445305-14-004772:notes:18]
[same as prior period, unchanged from 0000106040-14-000007:notes:16]

[0001445305-14-004772:notes:19]
On July 9, 2013, the Company acquired VeloBit, a privately held provider of high-performance storage I/O optimization software. As a result of the acquisition, VeloBit was fully integrated into the Company's HGST subsidiary and became a wholly owned indirect subsidiary of the Company. The acquisition is intended to build on HGST's strategy to enhance the overall value of datacenter storage by integrating HGST SSDs with software. The acquisition was not material to the Company's condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock

[0001445305-14-004772:notes:20]
4. Debt

[0001445305-14-004772:notes:21]
On January 9, 2014, Western Digital Ireland, Ltd. (“WDI”) used existing cash to repay the outstanding term loan balance of $1.8 billion, and the Company, Western Digital Technologies, Inc. (“WDT”) and WDI  entered into a new credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and the lenders party thereto (the "Credit Agreement"). The Credit Agreement provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility to WDT and a $1.5 billion revolving credit facility to WDT and WDI (the “Borrowers”). The revolving credit facility includes a $100 million sublimit for letters of credit and a $50 million sublimit for swing line loans. Subject to certain conditions, a Borrower may elect to expand the credit facilities by, or obtain incremental term loans of, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments. The loans under the Credit Agreement have a five-year term. The obligations of the Borrowers under the Credit Agreement are guaranteed by the Company and its material domestic subsidiaries, and the obligations of WDI under the Credit Agreement are also guaranteed by WDT.

[0001445305-14-004772:notes:22]
As of October 3, 2014, no amounts were outstanding under the revolving credit facility and the term loan facility had an outstanding balance of $2.4 billion and a variable interest rate of 1.66%. The Company is required to make quarterly principal payments on the term loan facility totaling $94 million for the remainder of fiscal 2015, $156 million in fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0001445305-14-004772:notes:23]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default. As of October 3, 2014, the Company was in compliance with all covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001445305-14-004772:notes:24]
[same as prior period, unchanged from 0000106040-14-000007:notes:22]

[0001445305-14-004772:notes:25]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for trading purposes. As of October 3, 2014, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0001445305-14-004772:notes:26]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three months ended October 3, 2014 and September 27, 2013.

[0001445305-14-004772:notes:27]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of operating expenses. All fair value hedges were determined to be effective. The fair value and the changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three months ended October 3, 2014 and September 27, 2013.

[0001445305-14-004772:notes:28]
As of October 3, 2014, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $21 million. In addition, as of October 3, 2014, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $1.0 billion and $1.0 billion, and closed $1.0 billion and $1.4 billion, in foreign exchange contracts in the three months ended October 3, 2014 and September 27, 2013, respectively. The fair value and balance sheet location of the Company's foreign exchange contracts as of October 3, 2014 and June 27, 2014 were as follows (in millions):

[0001445305-14-004772:notes:29]
|  | Asset Derivatives | Liability Derivatives |
|  | October 3, 2014 | June 27, 2014 | October 3, 2014 | June 27, 2014 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | — |  | Other current assets | $ | 7 |  | Accrued expenses | $ | 24 |  | Accrued expenses | $ | 2 |  |

[0001445305-14-004772:notes:30]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of October 3, 2014 (in millions):

[0001445305-14-004772:notes:31]
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 2 |  |  | $ | (2 | ) |  | $ | — |  |
| Financial liabilities | (26 | ) |  | 2 |  |  | (24 | ) |
| Total derivative instruments | $ | (24 | ) |  | $ | — |  |  | $ | (24 | ) |

[0001445305-14-004772:notes:32]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of June 27, 2014 (in millions):

[0001445305-14-004772:notes:33]
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 9 |  |  | $ | (2 | ) |  | $ | 7 |  |
| Financial liabilities | (4 | ) |  | 2 |  |  | (2 | ) |
| Total derivative instruments | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |

[0001445305-14-004772:notes:34]
[same as prior period, unchanged from 0000106040-14-000007:notes:32]

[0001445305-14-004772:notes:35]
|  | Amount of Loss Recognized inAccumulated OCI on Derivatives | Location of(Gain) LossReclassifiedfromAccumulatedOCI intoIncome | Amount of (Gain) Loss ReclassifiedFrom Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | ThreeMonthsEnded |  | ThreeMonthsEnded | ThreeMonthsEnded |  | ThreeMonthsEnded |
| October 3, 2014 |  | September 27, 2013 | October 3, 2014 |  | September 27, 2013 |
| Foreign exchange contracts | $ | (22 | ) |  | $ | (11 | ) | Cost of revenue | $ | (4 | ) |  | $ | 27 |  |

[0001445305-14-004772:notes:36]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three months ended October 3, 2014 and September 27, 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-14-004772:notes:37]
[same as prior period, unchanged from 0000106040-14-000007:notes:35]

[0001445305-14-004772:notes:38]
[same as prior period, unchanged from 0000106040-14-000007:notes:37]

[0001445305-14-004772:notes:39]
During the three months ended October 3, 2014, the Company recognized in expense $19 million for stock-based compensation related to the vesting of options issued under the Company’s stock plans and the ESPP, as compared to $21 million in the prior-year period. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $5 million in both the three months ended October 3, 2014 and September 27, 2013. As of October 3, 2014, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $145 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.3 years.

[0001445305-14-004772:notes:40]
During the three months ended October 3, 2014, the Company recognized in expense $20 million for stock-based compensation related to the vesting of awards of RSUs issued under the Company's stock plans, as compared to $21 million in the prior-year period. The tax benefit realized as a result of the aforementioned stock-based compensation expense was $5 million in the three months ended October 3, 2014, as compared to $4 million in the prior-year period. As of October 3, 2014, the aggregate unamortized fair value of all unvested RSUs was $179 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 1.9 years. RSUs include performance stock unit awards (“PSUs”). The effect of PSUs was immaterial to the condensed consolidated financial statements during the three months ended October 3, 2014 and September 27, 2013.

[0001445305-14-004772:notes:41]
During both the three months ended October 3, 2014 and September 27, 2013, the Company recognized in expense $4 million related to adjustments to market value as well as the vesting of stock appreciation rights (“SARs”). The tax benefit realized as a result of the aforementioned SARs expense was $1 million in both the three months ended October 3, 2014 and September 27, 2013. The SARs will be settled in cash upon exercise. As a result, the Company had a total liability of $58 million and $61 million related to SARs included in accrued expenses in the condensed consolidated balance sheets, as of October 3, 2014 and June 27, 2014, respectively. As of October 3, 2014, total compensation cost related to unvested SARs issued to employees but not yet recognized was not material to the Company's consolidated statement of income.

[0001445305-14-004772:notes:42]
[same as prior period, unchanged from 0000106040-14-000007:notes:41]

[0001445305-14-004772:notes:43]
[same as prior period, unchanged from 0000106040-14-000007:notes:42]

[0001445305-14-004772:notes:44]
|  | NumberofShares |  | WeightedAverageExercisePricePerShare |  | WeightedAverageRemainingContractualLife(in years) |  | AggregateIntrinsicValue |
| Options outstanding at June 27, 2014 | 10.1 |  |  | $ | 37.03 |  |  |  |  |  |
| Granted | 1.2 |  |  | 100.06 |  |  |  |  |  |
| Exercised | (1.3 | ) |  | 31.04 |  |  |  |  |  |
| Options outstanding at October 3, 2014 | 10.0 |  |  | $ | 45.16 |  |  | 4.7 |  | $ | 514 |  |
| Exercisable at October 3, 2014 | 4.5 |  |  | $ | 32.19 |  |  | 3.3 |  | $ | 290 |  |
| Vested and expected to vest after October 3, 2014 | 9.8 |  |  | $ | 44.56 |  |  | 4.7 |  | $ | 509 |  |

[0001445305-14-004772:notes:45]
If an option has an exercise price that is less than the quoted price of the Company’s common stock at the particular time, the aggregate intrinsic value of that option at that time is calculated based on the difference between the exercise price of the underlying options and the quoted price of the Company’s common stock at that time. As of October 3, 2014, the Company had options outstanding to purchase an aggregate of 8.7 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $514 million at that date. During the three months ended October 3, 2014, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $86 million, determined as of the date of exercise, as compared to $27 million in the prior-year period.

[0001445305-14-004772:notes:46]
[same as prior period, unchanged from 0000106040-14-000007:notes:45]

[0001445305-14-004772:notes:47]
[same as prior period, unchanged from 0000106040-14-000007:notes:46]

[0001445305-14-004772:notes:48]
|  | Numberof Shares |  | Weighted AverageGrant-DateFair Value |
| RSUs outstanding at June 27, 2014 | 3.7 |  |  | $ | 49.77 |  |
| Granted | 1.1 |  |  | 100.07 |  |
| Vested | (1.5 | ) |  | 40.57 |  |
| RSUs outstanding at October 3, 2014 | 3.3 |  |  | 70.88 |  |
| Expected to vest after October 3, 2014 | 3.1 |  |  | $ | 70.38 |  |

[0001445305-14-004772:notes:49]
The fair value of each RSU is the market price of the Company’s stock at the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of vesting of the units. The grant-date fair value of the shares underlying the RSU awards at the date of grant was $113 million in the three months ended October 3, 2014. These amounts are being recognized to expense over the corresponding vesting periods. The Company has assumed a forfeiture rate of 4.4% for the three months ended October 3, 2014, based on a historical analysis indicating forfeitures for these types of awards.

[0001445305-14-004772:notes:50]
[same as prior period, unchanged from 0000106040-14-000007:notes:49]

[0001445305-14-004772:notes:51]
The share-based compensation liability for SARs is recognized for the portion of fair value for which service has been rendered at the reporting date. The share-based liability is remeasured at each reporting date, using a binomial option-pricing model, through the requisite service period. As of October 3, 2014, 0.7 million SARs were outstanding with a weighted average exercise price of $8.06. There were no SARs granted and all other SARs activity was immaterial to the condensed consolidated financial statements for the three months ended October 3, 2014 and September 27, 2013.

[0001445305-14-004772:notes:52]
[same as prior period, unchanged from 0000106040-14-000007:notes:51]

[0001445305-14-004772:notes:53]
[same as prior period, unchanged from 0000106040-14-000007:notes:52]

[0001445305-14-004772:notes:54]
|  | Three Months Ended |
|  | October 3, 2014 |  | September 27, 2013 |
| Suboptimal exercise factor | 2.51 |  | 2.06 |
| Range of risk-free interest rates | 0.11% to 2.16% |  | 0.10% to 2.02% |
| Range of expected stock price volatility | 0.24 to 0.47 |  | 0.31 to 0.50 |
| Weighted average expected volatility | 0.36 |  | 0.43 |
| Post-vesting termination rate | 1.25% |  | 3.09% |
| Dividend yield | 1.68% |  | 1.58% |
| Fair value | $32.29 |  | $24.00 |

[0001445305-14-004772:notes:55]
The weighted average expected term of the Company’s stock options granted during the three months ended October 3, 2014 was 5.8 years, as compared to 5.0 years in the prior-year period.

[0001445305-14-004772:notes:56]
[same as prior period, unchanged from 0000106040-14-000007:notes:55]

[0001445305-14-004772:notes:57]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the current ESPP are granted on either June 1st or December 1st of each year. ESPP activity was immaterial to the condensed consolidated financial statements for the three months ended October 3, 2014 and September 27, 2013.

[0001445305-14-004772:notes:58]
[same as prior period, unchanged from 0000106040-14-000007:notes:57]

[0001445305-14-004772:notes:59]
Since May 18, 2012, the Company's Board of Directors has authorized $3.0 billion for the repurchase of its common stock and approved the extension of its stock repurchase program to September 13, 2017. The Company repurchased 2.2 million shares for a total cost of $223 million during the three months ended October 3, 2014. The remaining amount available to be purchased under the Company’s stock repurchase program as of October 3, 2014 was $931 million. The Company may continue to repurchase its stock as it deems appropriate and market conditions allow. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows and borrowings under the Company's Credit Agreement.

[0001445305-14-004772:notes:60]
[same as prior period, unchanged from 0000106040-14-000007:notes:59]

[0001445305-14-004772:notes:61]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In the three months ended October 3, 2014, the Company declared a cash dividend of $0.40 per share of the Company’s common stock to shareholders of record as of October 3, 2014, totaling $94 million, which was paid on October 15, 2014. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.


## us-gaap:EarningsPerShareTextBlock

[0001445305-14-004772:notes:62]
[same as prior period, unchanged from 0000106040-14-000007:notes:61]

[0001445305-14-004772:notes:63]
[same as prior period, unchanged from 0000106040-14-000007:notes:62]

[0001445305-14-004772:notes:64]
[same as prior period, unchanged from 0000106040-14-000007:notes:63]

[0001445305-14-004772:notes:65]
|  | Three MonthsEnded |
|  | October 3, 2014 |  | September 27, 2013 |
| Net income | $ | 423 |  |  | $ | 495 |  |
| Weighted average shares outstanding: |  |  |  |
| Basic | 234 |  |  | 236 |  |
| Employee stock options and other | 6 |  |  | 6 |  |
| Diluted | 240 |  |  | 242 |  |
| Income per common share: |  |  |  |
| Basic | $ | 1.81 |  |  | $ | 2.10 |  |
| Diluted | $ | 1.76 |  |  | $ | 2.05 |  |
| Anti-dilutive potential common shares excluded* | — |  |  | 1 |  |

[0001445305-14-004772:notes:66]
[same as prior period, unchanged from 0000106040-14-000007:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-004772:notes:67]
[same as prior period, unchanged from 0000106040-14-000007:notes:66]

[0001445305-14-004772:notes:68]
[same as prior period, unchanged from 0000106040-14-000007:notes:67]

[0001445305-14-004772:notes:69]
[same as prior period, unchanged from 0000106040-14-000007:notes:68]

[0001445305-14-004772:notes:70]
[same as prior period, unchanged from 0000106040-14-000007:notes:69]

[0001445305-14-004772:notes:71]
[same as prior period, unchanged from 0000106040-14-000007:notes:70]

[0001445305-14-004772:notes:72]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of October 3, 2014, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0001445305-14-004772:notes:73]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245 |  |
| Commercial paper | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Total cash equivalents | 1,245 |  |  | 53 |  |  | — |  |  | 1,298 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Commercial paper | — |  |  | 119 |  |  | — |  |  | 119 |  |
| Certificates of deposit | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Total short-term investments | — |  |  | 222 |  |  | — |  |  | 222 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 203 |  |  | — |  |  | 203 |  |
| U.S. Government agency securities | — |  |  | 29 |  |  | — |  |  | 29 |  |
| Total long-term investments | — |  |  | 232 |  |  | — |  |  | 232 |  |
| Total assets at fair value | $ | 1,245 |  |  | $ | 507 |  |  | $ | — |  |  | $ | 1,752 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |

[0001445305-14-004772:notes:74]
The following table presents information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 27, 2014, and indicates the fair value hierarchy of the valuation techniques utilized to determine such value (in millions):

[0001445305-14-004772:notes:75]
|  | Fair Value Measurements atReporting Date Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 756 |  |  | $ | — |  |  | $ | — |  |  | $ | 756 |  |
| Bank acceptances | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total cash equivalents | 756 |  |  | 1 |  |  | — |  |  | 757 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Government agency securities | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Commercial paper | — |  |  | 165 |  |  | — |  |  | 165 |  |
| Certificates of deposit | — |  |  | 66 |  |  | — |  |  | 66 |  |
| Total short-term investments | — |  |  | 284 |  |  | — |  |  | 284 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 180 |  |  | — |  |  | 180 |  |
| U.S. Government agency securities | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total long-term investments | — |  |  | 215 |  |  | — |  |  | 215 |  |
| Foreign exchange contracts | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total assets at fair value | $ | 756 |  |  | $ | 507 |  |  | $ | — |  |  | $ | 1,263 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0001445305-14-004772:notes:76]
[same as prior period, unchanged from 0000106040-14-000007:notes:75]

[0001445305-14-004772:notes:77]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party and recorded within short-term investments in the condensed consolidated balance sheets. Certificates of deposit are valued using fixed interest rates.

[0001445305-14-004772:notes:78]
Commercial Paper. The Company’s commercial paper securities are investment grade debt issued by corporations which are held in custody by a third party with original maturities of twelve months or less and are recorded within cash and cash equivalents or short-term investments in the condensed consolidated balance sheets depending on their original maturities. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0001445305-14-004772:notes:79]
[same as prior period, unchanged from 0000106040-14-000007:notes:77]

[0001445305-14-004772:notes:80]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government, are held in custody by a third party and are recorded within long-term other assets in the condensed consolidated balance sheets. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0001445305-14-004772:notes:81]
Bank Acceptances. The Company’s bank acceptances are held in custody by a third party and recorded within cash and cash equivalents in the condensed consolidated balance sheets. Bank acceptances are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0001445305-14-004772:notes:82]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are classified within other current assets and liabilities in the condensed consolidated balance sheets. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the condensed consolidated balance sheets. For more information on the Company's foreign exchange contracts, see Note 8. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates.

[0001445305-14-004772:notes:83]
[same as prior period, unchanged from 0000106040-14-000007:notes:83]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-004772:notes:84]
[same as prior period, unchanged from 0000106040-14-000007:notes:84]

[0001445305-14-004772:notes:85]
The Company’s income tax provision for both the three months ended October 3, 2014 and September 27, 2013 was $37 million. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2015 through 2025 and the current year generation of income tax credits.

[0001445305-14-004772:notes:86]
In the three months ended October 3, 2014, the Company recorded a net increase of $7 million in its liability for unrecognized tax benefits. As of October 3, 2014, the Company's liability for unrecognized tax benefits was approximately $307 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three months ended October 3, 2014.

[0001445305-14-004772:notes:87]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company’s federal income tax returns for fiscal years 2006 and 2007, and the Company and the IRS reached agreement with respect to all matters except on the proposed adjustments to income before income taxes relating to intercompany payable balances. The proposed adjustments relating to intercompany payable balances for fiscal years 2006 and 2007 will be addressed in conjunction with the IRS’s examination of the Company’s fiscal years 2008 and 2009, which commenced in January 2012. In addition, in January 2012, the IRS commenced an examination of the 2007 fiscal period ended September 5, 2007 of Komag, Incorporated, which was acquired by the Company on September 5, 2007.  The Company anticipates that the IRS fieldwork will be completed in the fourth quarter of fiscal year 2015.  With respect to the 2008 and 2009 audit, the Company received a notice of proposed adjustment from the IRS relating to intercompany payable balances. The proposed adjustments to income before income taxes relating to intercompany payable balances for fiscal years 2006, 2007, 2008 and 2009 total approximately $200 million. The Company disagrees with the proposed adjustments, believes that its tax position is properly supported and will vigorously contest the position taken by the IRS. The IRS examined calendar years 2010 and 2011 of HGST, which was acquired by the Company on March 8, 2012, and completed the examination with no material adjustments.

[0001445305-14-004772:notes:88]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax audits cannot be predicted with certainty. If any issues addressed in the Company’s tax audits are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of October 3, 2014, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001445305-14-004772:notes:89]
The fair value of the Company’s investments classified as available-for-sale securities at June 27, 2014, by remaining contractual maturity, were as follows (in millions):

[0001445305-14-004772:notes:90]
|  | Cost Basis |  | Fair Value |
| Due in less than one year: | $ | 284 |  |  | $ | 284 |  |
| Due in one to five years: | 215 |  |  | 215 |  |
| Total | $ | 499 |  |  | $ | 499 |  |

[0001445305-14-004772:notes:91]
The fair value of the Company’s investments classified as available-for-sale securities at October 3, 2014, by remaining contractual maturity, were as follows (in millions):

[0001445305-14-004772:notes:92]
|  | Cost Basis |  | Fair Value |
| Due in less than one year: | $ | 222 |  |  | $ | 222 |  |
| Due in one to five years: | 232 |  |  | 232 |  |
| Total | $ | 454 |  |  | $ | 454 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001445305-14-004772:notes:93]
5. Legal Proceedings

[0001445305-14-004772:notes:94]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0001445305-14-004772:notes:95]
Solely for purposes of this footnote, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the HGST Closing Date. HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0001445305-14-004772:notes:96]
Intellectual Property Litigation

[0001445305-14-004772:notes:97]
On June 20, 2008, plaintiff Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and one other company alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. On October 10, 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. A trial in the matter began on July 18, 2011 and concluded on July 26, 2011 with a verdict against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. WD and HGST have filed post-trial motions challenging the verdict. On January 17, 2014, the Court denied the Company’s motion for judgment as a matter of law on invalidity. On May 20, 2014, the Court ordered supplemental briefing on post-trial motions related to infringement.  Convolve and the Company filed their supplemental briefs on May 30, 2014 and June 6, 2014, respectively.  Additional post-trial motions are pending, and the Company will evaluate its options for appeal after the Court rules on the remaining post-trial motions. The Company intends to continue to defend itself vigorously in this matter.

[0001445305-14-004772:notes:98]
On August 1, 2011, plaintiff Guzik Technical Enterprises (“Guzik”) filed a complaint in the Northern District of California against WD and various of its subsidiaries alleging infringement of U.S. Patent Nos. 6,023,145 and 6,785,085, breach of contract and misappropriation of trade secrets. The complaint seeks injunctive relief and unspecified monetary damages, fees and costs. The patents asserted by Guzik allegedly relate to devices used to test hard disk drive heads and media. On November 30, 2013, WD entered into a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company recorded an accrual in the three months ended December 27, 2013. Guzik is disputing the enforceability of the agreement and on December 27, 2013, WD filed a motion to enforce the agreement. The Court heard oral argument on WD’s motion on January 23, 2014.  The Court granted WD’s motion to enforce the settlement agreement on March 21, 2014.  On April 14, 2014, Guzik filed a Notice of Appeal to the Federal Circuit.  On June 17, 2014, Guzik filed its opening appellate brief.  WD filed its appellate brief on August 14, 2014. On September 11, 2014, Guzik filed its reply brief in support of its opening appellate brief. WD intends to continue to defend itself vigorously in this matter.

[0001445305-14-004772:notes:99]
On July 9, 2012, Siemens Aktiengesellschaft (“Siemens”) filed a complaint in German court against WD, Western Digital GmbH, and Digital River International, S.a.r.l. alleging patent infringement of European patent no. EP 674769, which claims an artificial antiferromagnetic (AAF) (aka, synthetic antiferromagnetic) structure for magneto-resistive sensors.  On March 14-15, 2013, Western Digital GmbH filed a response of non-infringement and also filed a separate nullity action.  Siemens separately served WD with the complaint on July 15, 2013. The patent expired on December 16, 2013 and, on March 10, 2014, Siemens withdrew its motion for injunctive relief. On March 7, 2014, Siemens extended the complaint including WDT as a defendant.  On August 25, 2014, the parties reached a settlement agreement for an amount that is not material to the Company’s financial position, results of operations or cash flows, which the Company recorded in the three months ended October 3, 2014. On August 27, 2014, the Company withdrew the nullity action which was confirmed by the Federal Patent Court on August 29, 2014.  On August 27, 2014 Siemens withdrew the infringement action which was confirmed by the infringement court on September 3, 2014. This matter is now closed.

[0001445305-14-004772:notes:100]
On September 5, 2013, plaintiff Lake Cherokee Hard Drive Technologies, LLC (“Lake Cherokee”) filed a complaint in the Eastern District of Texas against: Marvell Asia PTE, Ltd., Samsung Semiconductor, Inc., Seagate Tech. LLC, Seagate Tech. Int’l., Toshiba Corp., Toshiba Am. Elec. Components, Toshiba Am. Inf. Sys., Inc., Toshiba Am. Inf. Equip. (Philippines), Inc., and WDT alleging infringement of US Patent Nos. 5,844,738 and 5,978,162. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’738 and ’162 patents.  The complaint seeks unspecified monetary damages, fees and costs. On April 3, 2014, Lake Cherokee and Marvell Semiconductor, Inc. (“MSI”) engaged in mediation which resulted in a settlement-in-principle on April 8, 2014.  On April 21, 2014, Lake Cherokee and MSI filed a motion to stay deadlines while the parties finalized a settlement agreement.  In this motion, Lake Cherokee and MSI represented to the Court that the settlement between Lake Cherokee and MSI will result in a with-prejudice dismissal of Lake Cherokee’s claims against each of the defendants, including WDT, with respect to their sale or use of Marvell chips.  On April 23, 2014, the Court granted a stay of deadlines.  The parties submitted a Joint Stipulation of Dismissal with Prejudice, and on September 5, 2014, the Court ordered that the Stipulation of Dismissal is granted and that the claims are dismissed with prejudice. This matter is now closed.

[0001445305-14-004772:notes:101]
On September 25, 2013, plaintiff Lake Cherokee filed a complaint in the Eastern District of Texas against: Marvell Semiconductor, Inc., Marvell Asia PTE, Ltd., Dell Inc., and WDT alleging infringement of US Patent No. 5,583,706. Lake Cherokee alleges that WDT’s hard disk drive products that contain Marvell read channel systems-on-a-chip (SOCs) infringe its ’706 patent.  The complaint seeks an injunction, unspecified monetary damages, fees and costs. On April 3, 2014, Lake Cherokee and MSI engaged in mediation which resulted in a settlement-in-principle on April 8, 2014.  On April 21, 2014, Lake Cherokee and MSI filed a motion to stay deadlines while the parties finalized a settlement agreement.  In this motion, Lake Cherokee and MSI represented to the Court that the settlement between Lake Cherokee and MSI will result in a with-prejudice dismissal of Lake Cherokee’s claims against each of the defendants, including WDT, with respect to their sale or use of Marvell chips.  On April 23, 2014, the Court granted a stay of deadlines.  The parties submitted a Joint Stipulation of Dismissal with Prejudice, and on August 27, 2014, the Court ordered that the Stipulation of Dismissal is granted and that the claims are dismissed with prejudice. This matter is now closed.

[0001445305-14-004772:notes:102]
On March 24, 2014, plaintiff Steven F. Reiber (“Reiber”) filed a complaint in the Eastern District of California against the Company, alleging infringement of U.S. Patent Nos. 7,124,927 and 7,389,905. On September 16, 2014, Reiber filed an amended complaint in the Eastern District of California against the Company alleging infringement of three additional patents-U.S. Patent Nos. 6,935,548, 6,651,864, and 6,354,479.  Reiber alleges that WD products (including hard disk drive heads, head gimbal assemblies, head stack assemblies and SSDs) infringe these patents based on the allegation that the manufacturing of these products involves the use of certain bonding tools (e.g., wire-bonding tips, capillary tips, and flip-chip handling tools) that have electrically “dissipative” properties, and which are used when bonding components, such as leads, wires and flip chips. The complaint seeks an injunction, unspecified monetary damages, interests, fees and costs. On September 30, 2014, the Company filed a motion to dismiss Reiber’s claims for induced infringement and contributory infringement. The parties' initial case management conference is set for February 5, 2015. The Company intends to defend itself vigorously in this matter.

[0001445305-14-004772:notes:103]
On October 20, 2014, plaintiff SOTA Semiconductor LLC (“SOTA”) filed a complaint in the Central District of California against the Company, Marvell Semiconductor, Inc., Belkin International, Inc., Dell Inc., Hewlett-Packard Company, Hisense USA Corp., Konica Minolta Business Solutions U.S.A., Inc., Lenovo (United States) Inc., Netgear, Inc., Samsung Electronics America, Inc., and Seagate Technology LLC, alleging infringement of U.S. Patent No. 5,991,545 (“’545 patent”).  SOTA alleges that the Company’s devices that incorporate Marvell Thumb Processors, including WD’s My Cloud EX2 network attached storage devices, which include model numbers WDBVKW0080JCH, WDBVKW0060JCH, WDBVKW0040JCH and WDBVKW0000NCH, infringe the ’545 patent.  The complaint seeks unspecified monetary damages, interests, fees, costs and expenses. The Company intends to defend itself vigorously in this matter.

[0001445305-14-004772:notes:104]
Seagate Matter

[0001445305-14-004772:notes:105]
On October 4, 2006, plaintiff Seagate Technology LLC (“Seagate”) filed an action in the District Court of Hennepin County, Minnesota, naming as defendants WD and one of its now former employees previously employed by Seagate. The complaint in the action alleged claims based on supposed misappropriation of trade secrets and sought injunctive relief and unspecified monetary damages, interests, fees and costs. On June 19, 2007, WD’s former employee filed a demand for arbitration with the American Arbitration Association. A motion to stay the litigation as against all defendants and to compel arbitration of all Seagate’s claims was granted on September 19, 2007. On September 23, 2010, Seagate filed a motion to amend its claims and add allegations based on the supposed misappropriation of additional confidential information, and the arbitrator granted Seagate’s motion. The arbitration hearing commenced on May 23, 2011 and concluded on July 11, 2011.

[0001445305-14-004772:notes:106]
On November 18, 2011, the sole arbitrator ruled in favor of WD in connection with five of the eight alleged trade secrets at issue, based on evidence that such trade secrets were known publicly at the time the former employee joined WD. Based on a determination that the employee had fabricated evidence, the arbitrator then concluded that WD had to know of the fabrications. As a sanction, the arbitrator precluded any evidence or defense by WD disputing the validity, misappropriation, or use of the three remaining alleged trade secrets by WD, and entered judgment in favor of Seagate with respect to such trade secrets. Using an unjust enrichment theory of damages, the arbitrator issued an interim award against WD in the amount of $525 million plus pre-award interest at the Minnesota statutory rate of 10% per year. In his decision with respect to these three trade secrets, the arbitrator did not question the relevance, veracity or credibility of any of WD’s ten expert and fact witnesses (other than WD’s former employee), nor the authenticity of any other evidence WD presented. On January 23, 2012, the arbitrator issued a final award adding pre-award interest in the amount of $105.4 million for a total final award of $630.4 million. On January 23, 2012, WD filed a petition in the District Court of Hennepin County, Minnesota to have the final arbitration award vacated. A hearing on the petition to vacate was held on March 1, 2012.

[0001445305-14-004772:notes:107]
On October 12, 2012, the District Court of Hennepin County, Minnesota vacated, in full, the $630.4 million final arbitration award. Specifically, the Court confirmed the arbitration award with respect to each of the five trade secret claims that WD and the former employee had won at the arbitration and vacated the arbitration award with respect to the three trade secret claims that WD and the former employee had lost at the arbitration. The Court ordered that a rehearing be held concerning those three alleged trade secret claims before a new arbitrator.

[0001445305-14-004772:notes:108]
On October 30, 2012, Seagate initiated an appeal of the Court’s decision with the Minnesota Court of Appeals.  On July 22, 2013, the Minnesota Court of Appeals reversed the District Court’s decision and remanded for entry of an order and judgment confirming the arbitration award. On August 20, 2013, the Company filed a petition for review with the Minnesota Supreme Court and, on October 15, 2013, the Minnesota Supreme Court granted the Company’s petition. The appeal before the Minnesota Supreme Court was fully briefed, and oral argument was held on February 5, 2014. On October 8, 2014, the Minnesota Supreme Court affirmed the decision of the Minnesota Court of Appeals; the Minnesota Supreme Court’s decision is not subject to appeal. As a result, on October 14, 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 13, 2014.  This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0001445305-14-004772:notes:109]
Seagate disputes the method the Company used for calculating post-award interest.  If not resolved, the interest dispute, which involves an amount that is not material to the Company's financial position, results of operations or cash flows, will be determined by the Minnesota courts.

[0001445305-14-004772:notes:110]
Other Matters

[0001445305-14-004772:notes:111]
On December 22, 2011 the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several levy collecting societies, submitted a pleading to the Copyright Arbitration Board (“CAB”) in Munich claiming retroactive copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD from January 2008 through December 2010.  The CAB was required to issue a settlement proposal within one year of the initiation of the action, failed to do so and requested the parties to consent to continue the deadline.  WD declined to provide consent and, on February 1, 2013, WD filed a declaratory relief against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. On May 22, 2014, oral argument on the pleadings occurred.  A decision from the Higher Court is expected by January 15, 2015, which either party may appeal. WD intends to defend itself vigorously in this matter.

[0001445305-14-004772:notes:112]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties and is therefore not predictable with assurance, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, there can be no assurance with respect to such result, and monetary liability or financial impact to the Company from these other matters could differ materially from those projected.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-004772:notes:113]
13. Recent Accounting Pronouncements

[0001445305-14-004772:notes:114]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11, "Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists" ("ASU 2013-11"). The new standard requires the presentation of certain unrecognized tax benefits as reductions to deferred tax assets rather than as liabilities in the consolidated balance sheets when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2013, which for the Company was the first quarter of fiscal 2015. The Company adopted this pronouncement in the first quarter of fiscal 2015. The adoption of this pronouncement did not have a material effect on the Company’s condensed consolidated financial statements.

[0001445305-14-004772:notes:115]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification Topic 605, "Revenue Recognition", to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years beginning after December 15, 2016, which for the Company is the first quarter of fiscal 2018. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001445305-14-004772:notes:116]
[same as prior period, unchanged from 0000106040-14-000007:notes:112]

[0001445305-14-004772:notes:117]
The accounting policies followed by Western Digital Corporation (the “Company”) are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the year ended June 27, 2014. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the year ended June 27, 2014. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year. The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal first quarters ended October 3, 2014 and September 27, 2013 consisted of 14 weeks and 13 weeks, respectively. Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0001445305-14-004772:notes:118]
The Company acquired Virident Systems, Inc. ("Virident") on October 17, 2013, sTec, Inc. (“sTec”) on September 12, 2013, and VeloBit, Inc. ("VeloBit") on July 9, 2013. These acquisitions are further described in Note 11 below. In connection with the acquisitions, Virident, sTec and VeloBit became indirect wholly-owned subsidiaries of the Company. Virident, sTec and VeloBit’s results of operations since their respective dates of acquisition are included in the condensed consolidated financial statements.

[0001445305-14-004772:notes:119]
[same as prior period, unchanged from 0000106040-14-000007:notes:115]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001445305-14-004772:notes:120]
[same as prior period, unchanged from 0000106040-14-000007:notes:116]

[0001445305-14-004772:notes:121]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three months ended October 3, 2014 and September 27, 2013. The expected long-term rate of return on the Japanese plan assets is 3.5%.

[0001445305-14-004772:notes:122]
[same as prior period, unchanged from 0000106040-14-000007:notes:118]

[0001445305-14-004772:notes:123]
|  | October 3, 2014 |  | June 27, 2014 |
| Benefit obligation | $ | 240 |  |  | $ | 255 |  |
| Fair value of plan assets | (182 | ) |  | (191 | ) |
| Unfunded status | $ | 58 |  |  | $ | 64 |  |

[0001445305-14-004772:notes:124]
[same as prior period, unchanged from 0000106040-14-000007:notes:120]

[0001445305-14-004772:notes:125]
|  | October 3, 2014 |  | June 27, 2014 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 57 |  |  | 63 |  |
| Net amount recognized | $ | 58 |  |  | $ | 64 |  |

[0001445305-14-004772:notes:126]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three months ended October 3, 2014 and September 27, 2013. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $12 million in fiscal 2015.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001445305-14-004772:notes:127]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the three months ended October 3, 2014 (in millions):

[0001445305-14-004772:notes:128]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | 5 |  |  | $ | 12 |  |
| Other comprehensive income (loss) before reclassifications | — |  |  | (22 | ) |  | (22 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | (4 | ) |  | (4 | ) |
| Net current-period other comprehensive income (loss) | — |  |  | (26 | ) |  | (26 | ) |
| Balance at October 3, 2014 | $ | 7 |  |  | $ | (21 | ) |  | $ | (14 | ) |

[0001445305-14-004772:notes:129]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive income (loss) for the three months ended September 27, 2013 (in millions):

[0001445305-14-004772:notes:130]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 28, 2013 | $ | 11 |  |  | $ | (46 | ) |  | $ | (35 | ) |
| Other comprehensive income (loss) before reclassifications | — |  |  | (11 | ) |  | (11 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 27 |  |  | 27 |  |
| Net current-period other comprehensive income | — |  |  | 16 |  |  | 16 |  |
| Balance at September 27, 2013 | $ | 11 |  |  | $ | (30 | ) |  | $ | (19 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001445305-14-004772:notes:131]
[same as prior period, unchanged from 0000106040-14-000007:notes:127]

[0001445305-14-004772:notes:132]
|  | Three MonthsEnded |
|  | October 3, 2014 |  | September 27, 2013 |
| Warranty accrual, beginning of period | $ | 182 |  |  | $ | 187 |  |
| Warranty liability assumed as a result of acquisition | — |  |  | 3 |  |
| Charges to operations | 49 |  |  | 40 |  |
| Utilization | (49 | ) |  | (49 | ) |
| Changes in estimate related to pre-existing warranties | 19 |  |  | 14 |  |
| Warranty accrual, end of period | $ | 201 |  |  | $ | 195 |  |


## us-gaap:SubsequentEventsTextBlock

[0001445305-14-004772:notes:133]
14.  Subsequent Event

[0001445305-14-004772:notes:134]
In relation to the Company’s litigation matter with Seagate, on October 8, 2014, the Minnesota Supreme Court affirmed the decision of the Minnesota Court of Appeals, and as a result, on October 14, 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 13, 2014. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001445305-14-004772:notes:135]
[same as prior period, unchanged from 0000106040-14-000007:notes:129]

[0001445305-14-004772:notes:136]
[same as prior period, unchanged from 0000106040-14-000007:notes:130]

[0001445305-14-004772:notes:137]
|  | October 3, 2014 |  | June 27, 2014 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 178 |  |  | $ | 168 |  |
| Work-in-process | 509 |  |  | 493 |  |
| Finished goods | 585 |  |  | 565 |  |
| Total inventories | $ | 1,272 |  |  | $ | 1,226 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 8,244 |  |  | $ | 8,123 |  |
| Accumulated depreciation | (5,042 | ) |  | (4,830 | ) |
| Property, plant and equipment, net | $ | 3,202 |  |  | $ | 3,293 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 980 |  |  | $ | 984 |  |
| Accumulated amortization | (574 | ) |  | (530 | ) |
| Other intangible assets, net | $ | 406 |  |  | $ | 454 |  |

[0001445305-14-004772:notes:138]
[same as prior period, unchanged from 0000106040-14-000007:notes:132]

[0001445305-14-004772:notes:139]
[same as prior period, unchanged from 0000106040-14-000007:notes:133]

[0001445305-14-004772:notes:140]
The long-term portion of the warranty accrual classified in other liabilities was $67 million at October 3, 2014 and $63 million at June 27, 2014.

[0001445305-14-004772:notes:141]
[same as prior period, unchanged from 0000106040-14-000007:notes:135]

[0001445305-14-004772:notes:142]
The Company determined no available-for-sale securities were other-than-temporarily impaired in the three months ended October 3, 2014. For more information on the Company's available-for-sale securities, see Note 7 below.

[0001445305-14-004772:notes:143]
In addition, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the consolidated balance sheets and were not material to the condensed consolidated financial statements as of October 3, 2014 and June 27, 2014.

[0001445305-14-004772:notes:144]
[same as prior period, unchanged from 0000106040-14-000007:notes:137]

[0001445305-14-004772:notes:145]
Other comprehensive income (loss) refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss) is comprised of unrealized gains and losses on foreign exchange contracts. There were no unrealized gains or losses on the Company's available-for-sale securities or actuarial gains and losses related to pensions in the three months ended October 3, 2014. In addition, the income tax impact on components of other comprehensive income (loss) is immaterial for all periods presented.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0001445305-14-004772:notes:146]
12. Employee Termination, Asset Impairment and Other Charges

[0001445305-14-004772:notes:147]
During the three months ended October 3, 2014, the Company recorded employee termination, asset impairment and other charges of $9 million in order to realign its operations with anticipated market demand, as compared to $11 million in the prior-year period. These charges were classified as operating expenses and included in Employee termination, asset impairment and other charges on the condensed consolidated statements of income.
