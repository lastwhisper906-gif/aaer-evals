# WDC MD&A — 0000106040-24-000031


## mdna

[0000106040-24-000031:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-24-000031:mdna:2]
Our Company

[0000106040-24-000031:mdna:3]
We are a leading developer, manufacturer, and provider of data storage devices based on both HDD and NAND flash technologies. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful HDD and Flash storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data.

[0000106040-24-000031:mdna:4]
Our broad portfolio of technology and products addresses our multiple end markets: “Cloud,” “Client” and “Consumer”. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our OEM and channel customers a broad array of high-performance HDD and Flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-24-000031:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2024, 2023, and 2022, which ended on June 28, 2024, June 30, 2023, and July 1, 2022, respectively, each comprised 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-24-000031:mdna:6]
Key Developments

[0000106040-24-000031:mdna:7]
Separation of Business Units

[0000106040-24-000031:mdna:8]
On October 30, 2023, we announced that our Board of Directors had completed its strategic review of our business and, after evaluating a comprehensive range of alternatives, authorized us to pursue a plan to separate our HDD and Flash business units to create two independent, public companies. We believe the separation will better position each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, and operate more efficiently with distinct capital structures. The completion of the planned separation is subject to certain conditions, including final approval by our Board of Directors. Significant effort is underway and extensive progress has been made with respect to the separation as we continue to drive towards completing the work required to separate the businesses by the end of calendar year 2024.

[0000106040-24-000031:mdna:9]
Operational Update

[0000106040-24-000031:mdna:10]
Macroeconomic factors such as inflation, higher interest rates and recession concerns had softened demand for our products in recent years, with certain customers reducing purchases as they adjusted their production levels and right-sized their inventories. As a result, we and our industry experienced a supply-demand imbalance, which resulted in reduced shipments and negatively impacted pricing. To adapt to these conditions, since the beginning of 2023, we have been implementing measures to reduce operating expenses, and to proactively manage supply and inventory to align with demand and improve our capital efficiency while continuing to deploy innovative products. These actions have enabled us to scale back on capital expenditures, consolidate production lines and reduce production bit growth. In 2024 and 2023, these actions have resulted in incremental charges for employee termination, asset impairment and other charges as well as charges for unabsorbed manufacturing overhead costs in HDD and Flash as a result of the underutilization of facilities as we temporarily scaled back production.

[0000106040-24-000031:mdna:11]
In the latter half of 2024, we began to see an improvement in the supply and demand dynamic, leading to improved revenues. The increased demand resulted in improved pricing and gross margin across our segments and end markets compared to 2023. We anticipate that digital transformation, including AI data-cycle, will continue driving improved market conditions in the near- and long-term for data storage, encompassing both HDD and Flash technologies. Leveraging our expertise and innovation in both areas, we believe we are well-positioned to capitalize on this improved market condition.

[0000106040-24-000031:mdna:12]
34

[0000106040-24-000031:mdna:13]
Tax Resolution

[0000106040-24-000031:mdna:14]
As disclosed in previous periods, we had previously reached a final agreement with the Internal Revenue Service (“IRS”) and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the twelve months ended June 28, 2024, we made payments aggregating $524 million for tax and interest with respect to years 2008 through 2012 and have a remaining liability of $185 million as of June 28, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months. Additional information is provided in our discussion in our “Results of Operations – Income Tax Expense,” and the “Short- and Long-term Liquidity – Unrecognized Tax Benefits” section below, and in Part II, Item 8, Note 13, Income Tax Expense, of the Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:15]
Financing Activities

[0000106040-24-000031:mdna:16]
On November 3, 2023, we issued $1.60 billion aggregate principal amount of convertible senior notes, which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). We received net proceeds of approximately $1.56 billion after issuance costs. Contemporaneously with the issuance of the 2028 Convertible Notes, we entered into individually negotiated transactions with certain holders of our existing 1.50% convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”) to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount using net proceeds from the offering of the 2028 Convertible Notes. In connection with the issuance of the 2028 Convertible Notes, we also used approximately $155 million of the net proceeds from the offering to pay the cost of entering into capped call contracts with a cap price of approximately $70.26 to hedge the potential dilution impact of the conversion feature. On February 1, 2024, we used a portion of the remaining net proceeds from the offering of the 2028 Convertible Notes to settle the remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-24-000031:mdna:17]
During 2024, we drew and repaid $600 million principal amount (the “Delayed Draw Term Loan”) under a loan agreement we entered into in January 2023 and amended in June 2023. Proceeds from this loan were primarily used for payments on our tax liability to the IRS for the years 2008 through 2012.

[0000106040-24-000031:mdna:18]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, and additional information on the terms of our convertible preferred shares is included in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:19]
See Part I, Item 1A, Risk Factors, of this Annual Report on Form 10-K for more information regarding the risks we face as a result of macroeconomic conditions, and supply chain disruptions.

[0000106040-24-000031:mdna:20]
Agreement to Sell a Majority Interest in a Subsidiary

[0000106040-24-000031:mdna:21]
In March 2024, our wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) entered into an Equity Purchase Agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), our indirect wholly-owned subsidiary, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a joint venture between SanDisk China and JCET (the “Transaction”). Closing of the Transaction is subject to the satisfaction or waiver of certain conditions, after which JCET will own 80% of the equity interest in SDSS, with SanDisk China owning the remaining 20%. Following the closing, we expect to enter into various ancillary agreements, including (i) a shareholders agreement governing the joint venture relationships from and after the closing; (ii) a supply agreement (“Supply Agreement”) with the joint venture to supply us with certain flash-based products currently produced by SDSS, which may include flash memory cards, embedded flash products, and flash components; and (iii) an intellectual property license agreement granting SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on our behalf for the term of and pursuant to the Supply Agreement.

[0000106040-24-000031:mdna:22]
Sale-Leaseback

[0000106040-24-000031:mdna:23]
In September 2023, we completed a sale and leaseback of our facility in Milpitas, California. We received net proceeds of $191 million in cash and recorded a gain of $85 million on the sale. We are leasing back the facility at an annual lease rate of $16 million for the first year, increasing by 3% per year thereafter through January 1, 2039. The lease includes three 5-year renewal options and one 4-year renewal option for the ability to extend through December 2057.

[0000106040-24-000031:mdna:24]
Asset Impairment and Contract Termination Costs

[0000106040-24-000031:mdna:25]
In connection with the cost-saving actions described in “Operational Update” above, we reassessed our existing capacity development plans and made decisions during 2024 to cancel certain projects, including projects to expand capacity in our Penang, Malaysia facility. This resulted in a $146 million impairment of existing construction in progress and other assets and recognition of $34 million for certain contract termination costs during the year ended June 28, 2024.

[0000106040-24-000031:mdna:26]
36

[0000106040-24-000031:mdna:27]
Results of Operations

[0000106040-24-000031:mdna:28]
Summary Comparison of 2024, 2023 and 2022

[0000106040-24-000031:mdna:29]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-24-000031:mdna:30]
|  |  |  |  |  |  |  |  |  | 2024 |  | 2023 |  |  |  | 2022 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 13,003 |  |  | 100.0 | % |  | $ | 12,318 |  |  | 100.0 | % |  |  |  | $ | 18,793 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 10,058 |  |  | 77.4 |  |  | 10,431 |  |  | 84.7 |  |  |  |  | 12,919 |  |  | 68.7 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 2,945 |  |  | 22.6 |  |  | 1,887 |  |  | 15.3 |  |  |  |  | 5,874 |  |  | 31.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 1,907 |  |  | 14.7 |  |  | 2,009 |  |  | 16.3 |  |  |  |  | 2,323 |  |  | 12.4 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 828 |  |  | 6.4 |  |  | 970 |  |  | 7.9 |  |  |  |  | 1,117 |  |  | 5.9 |  |
| Litigation matter |  |  |  |  |  |  |  |  |  |  |  |  | 291 |  |  | 2.2 |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Employee termination, asset impairment, and other |  |  |  |  |  |  |  |  |  |  |  |  | 139 |  |  | 1.1 |  |  | 193 |  |  | 1.6 |  |  |  |  | 43 |  |  | 0.2 |  |
| Business separation costs |  |  |  |  |  |  |  |  |  |  |  |  | 97 |  |  | 0.7 |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 3,262 |  |  | 25.1 |  |  | 3,172 |  |  | 25.8 |  |  |  |  | 3,483 |  |  | 18.5 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (317) |  |  | (2.4) |  |  | (1,285) |  |  | (10.4) |  |  |  |  | 2,391 |  |  | 12.7 |  |
| Interest and other income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 39 |  |  | 0.3 |  |  | 24 |  |  | 0.2 |  |  |  |  | 6 |  |  | — |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (417) |  |  | (3.2) |  |  | (312) |  |  | (2.5) |  |  |  |  | (304) |  |  | (1.6) |  |
| Other income, net |  |  |  |  |  |  |  |  |  |  |  |  | 34 |  |  | 0.3 |  |  | 23 |  |  | 0.2 |  |  |  |  | 78 |  |  | 0.4 |  |
| Total interest and other income, net |  |  |  |  |  |  |  |  |  |  |  |  | (344) |  |  | (2.6) |  |  | (265) |  |  | (2.2) |  |  |  |  | (220) |  |  | (1.2) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | (661) |  |  | (5.1) |  |  | (1,550) |  |  | (12.6) |  |  |  |  | 2,171 |  |  | 11.6 |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 137 |  |  | 1.1 |  |  | 134 |  |  | 1.1 |  |  |  |  | 625 |  |  | 3.3 |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | (798) |  |  | (6.1) |  |  | (1,684) |  |  | (13.7) |  |  |  |  | 1,546 |  |  | 8.2 |  |
| Less: cumulative dividends allocated to preferred shareholders |  |  |  |  |  |  |  |  |  |  |  |  | 54 |  |  | 0.4 |  |  | 24 |  |  | 0.2 |  |  |  |  | — |  |  | — |  |
| Net income (loss) attributable to common shareholders |  |  |  |  |  |  |  |  |  |  |  |  | $ | (852) |  |  | (6.6) | % |  | $ | (1,708) |  |  | (13.9) | % |  |  |  | $ | 1,546 |  |  | 8.2 | % |

[0000106040-24-000031:mdna:31]
(1)Percentage may not total due to rounding.

[0000106040-24-000031:mdna:32]
37

[0000106040-24-000031:mdna:33]
The following table sets forth, for the periods presented, a summary of our segment information:

[0000106040-24-000031:mdna:34]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |
| Flash | $ | 6,687 |  | $ | 6,063 |  | $ | 9,753 |
| HDD | 6,316 |  | 6,255 |  | 9,040 |
| Total net revenue | $ | 13,003 |  | $ | 12,318 |  | $ | 18,793 |
| Gross profit: |  |  |  |  |  |
| Flash | $ | 1,079 |  | $ | 433 |  | $ | 3,527 |
| HDD | 1,881 |  | 1,505 |  | 2,661 |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation expense | (49) |  | (49) |  | (48) |
| Amortization of acquired intangible assets | (3) |  | — |  | (66) |
| Recovery from contamination incident | 37 |  | — |  | — |
| Contamination related charges | — |  | — |  | (207) |
| Recoveries from a power outage incident | — |  | — |  | 7 |
| Other | — |  | (2) |  | — |
| Total unallocated corporate items | (15) |  | (51) |  | (314) |
| Consolidated gross profit | $ | 2,945 |  | $ | 1,887 |  | $ | 5,874 |
| Gross margin: |  |  |  |  |  |
| Flash | 16.1% |  | 7.1% |  | 36.2% |
| HDD | 29.8% |  | 24.1% |  | 29.4% |
| Consolidated gross margin | 22.6% |  | 15.3% |  | 31.3% |

[0000106040-24-000031:mdna:35]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0000106040-24-000031:mdna:36]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 5,378 |  |  | $ | 5,252 |  |  | $ | 8,017 |  |
| Client |  |  |  |  | 4,647 |  |  | 4,328 |  |  | 7,076 |  |
| Consumer |  |  |  |  | 2,978 |  |  | 2,738 |  |  | 3,700 |  |
| Total revenue |  |  |  |  | $ | 13,003 |  |  | $ | 12,318 |  |  | $ | 18,793 |  |
| Revenue by geography |  |  |  |  |  |  |  |  |  |
| Asia |  |  |  |  | $ | 6,902 |  |  | $ | 6,046 |  |  | $ | 10,054 |  |
| Americas |  |  |  |  | 3,971 |  |  | 4,172 |  |  | 5,867 |  |
| Europe, Middle East and Africa |  |  |  |  | 2,130 |  |  | 2,100 |  |  | 2,872 |  |
| Total revenue |  |  |  |  | $ | 13,003 |  |  | $ | 12,318 |  |  | $ | 18,793 |  |
| Exabytes shipped |  |  |  |  | 550 |  |  | 501 |  |  | 645 |  |

[0000106040-24-000031:mdna:37]
Net Revenue

[0000106040-24-000031:mdna:38]
Net revenue increased 6% in 2024 compared to 2023, primarily due to increased exabytes sold, and improved supply-demand balance conditions in the second half of the year as described in the “Key Developments – Operational Update” section above and as discussed in more detail by business units below.

[0000106040-24-000031:mdna:39]
38

[0000106040-24-000031:mdna:40]
Flash revenue increased 10% in 2024 compared to 2023, primarily driven by a 21% increase in exabytes sold, partially offset by an 8% decline in ASPs per gigabyte. The increase in exabytes sold was primarily driven by improved demand from our OEM customers in our Client end market, and higher shipments of SSDs to our customers in our Consumer end market, partially offset by lower shipments in our Cloud end market. The decrease in ASPs per gigabyte was primarily driven by the supply-demand imbalance in the first half of the year, prior to the recent improvement in supply-demand conditions as described above.

[0000106040-24-000031:mdna:41]
HDD revenue was relatively flat in 2024 compared to 2023, primarily reflecting an 8% increase in exabytes sold, largely offset by a 5% decline in ASPs per gigabyte. The increase in exabytes sold was driven by an increase in shipments of our high-capacity enterprise drives. The decline in ASPs per gigabyte was primarily due to a shift in the product mix to larger capacity drives.

[0000106040-24-000031:mdna:42]
Cloud revenue increased 2% in 2024 compared to 2023, primarily driven by a 12% increase in exabytes sold, largely offset by a 7% decline in ASPs per gigabyte. The increase in exabytes sold was driven by higher shipments of our high-capacity enterprise HDD products. The decline in ASPs per gigabyte was primarily due to a shift in product mix to larger capacity drives, and pricing pressure driven by the supply-demand imbalance in the first half of the year as described above. Client revenue increased 7% in 2024 compared to 2023, primarily driven by a 6% increase in exabytes sold and a 2% increase in ASPs per gigabyte. The increase in exabytes sold was driven by an increase in SSD shipments into PC applications, partially offset by lower HDD shipments. Consumer revenue increased 9% in 2024 compared to 2023, primarily driven by a 6% increase in ASPs per gigabyte and a 3% increase in exabytes sold. The increase in ASPs per gigabyte was primarily driven by a favorable shift in product mix. The increase in exabytes sold was primarily due to increased shipments across all Flash products, partially offset by lower shipments of HDD products.

[0000106040-24-000031:mdna:43]
The changes in net revenue by geography in 2024 compared to 2023, primarily reflected larger growth in Asia from OEMs in this region as their production levels increased as well as routine variations in the mix of business.

[0000106040-24-000031:mdna:44]
For 2024, 2023 and 2022, our top 10 customers accounted for 39%, 43% and 45%, respectively, of our net revenue. For each of 2024, 2023 and 2022, no single customer accounted for 10% or more of our net revenue.

[0000106040-24-000031:mdna:45]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2024, 2023 and 2022, these programs represented 15%, 20% and 17%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-24-000031:mdna:46]
Gross Profit and Gross Margin

[0000106040-24-000031:mdna:47]
Consolidated gross profit increased $1.06 billion in 2024 compared to 2023. The increase was largely due to higher revenues from both Flash and HDD, cost reductions due to cost efficiencies achieved through improved manufacturing operations and cost-saving actions, and a more favorable product mix. The increase also reflected charges of approximately $407 million ($252 million in Flash and $155 million in HDD) for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity in 2024, compared to approximately $497 million of such costs ($296 million in Flash and $201 million in HDD) in 2023. In addition, we incurred charges of approximately $50 million in 2024 to write down Flash inventory as a result of the decreases in market pricing, compared to charges of $108 million of such costs in 2023. Consolidated gross margin increased 7.3 percentage points in 2024 compared to 2023, with approximately 2 percentage points of the increase due to the lower net charges in the current period and the remainder driven by the same factors as noted above. Flash gross margin increased by 9.0 percentage points year over year, driven by improving pricing, cost reduction initiatives and a favorable shift in product mix. HDD gross margin increased by 5.7 percentage points year over year driven by improving pricing and cost reduction initiatives.

[0000106040-24-000031:mdna:48]
Operating Expenses

[0000106040-24-000031:mdna:49]
R&D expense decreased $102 million or 5% in 2024 compared to 2023, which was primarily driven by a $31 million decrease in compensation and benefits, a $30 million decrease in depreciation and amortization and a $13 million decrease in outside services. The decrease in compensation and benefits was due to a reduction in headcount. The reduction in depreciation and amortization is attributed to lower capital expenditures in 2024 compared to 2023.

[0000106040-24-000031:mdna:50]
39

[0000106040-24-000031:mdna:51]
Selling, general and administrative (“SG&A”) expense decreased $142 million or 15% in 2024 compared to 2023. This decrease was primarily driven by a $133 million decrease in intangible amortization expense and a $13 million decrease in sales and marketing expenses, partially offset by an increase of $18 million in material purchases. The reduction in intangible amortization expense was due to most of our intangible assets becoming fully amortized in the previous year.

[0000106040-24-000031:mdna:52]
Litigation matter of $291 million for the year ended June 28, 2024 was related to a judgment in an intellectual property dispute as disclosed in Part II Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:53]
Employee termination, asset impairment, and other decreased $54 million or 28% in 2024 compared to 2023, reflecting fewer restructuring actions taken in the current period and a gain on the sale-leaseback of our Milpitas, California facility, partially offset by higher contract termination charges and asset impairments caused by project cancellations. For additional information regarding employee termination, asset impairment, and other, see Part II, Item 8, Note 15, Employee Termination, Asset Impairment, and Other, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:54]
Business separation costs were $97 million for the year ended June 28, 2024, primarily reflecting $33 million of charges incurred for stamp duties associated with establishing new legal entities, with the remaining charges attributable to fees to outside professional service providers to support the planned separation of our Flash and HDD businesses.

[0000106040-24-000031:mdna:55]
Interest and Other Income

[0000106040-24-000031:mdna:56]
Total interest and other income, net increased $79 million or 30% in 2024 compared to 2023, primarily reflecting a $105 million of higher interest expense resulting from increases in interest rates and higher outstanding debt balance, partially offset by higher other income, net, of $11 million, driven primarily by a net gain on our strategic investments, and $15 million of higher interest income due to higher interest rates.

[0000106040-24-000031:mdna:57]
Income Tax Expense

[0000106040-24-000031:mdna:58]
The Tax Cuts and Jobs Act (the “2017 Act”) includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-24-000031:mdna:59]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The CAMT is effective for us beginning with fiscal year 2024. We are not subject to the CAMT of 15% for fiscal year 2024 as our average annual AFSI did not exceed $1.00 billion for the preceding three-year period.

[0000106040-24-000031:mdna:60]
The following table sets forth Income tax information from our Consolidated Statements of Operations by dollar and effective tax rate:

[0000106040-24-000031:mdna:61]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | (661) |  |  | $ | (1,550) |  |  | $ | 2,171 |  |
| Income tax expense |  |  |  |  | 137 |  |  | 134 |  |  | 625 |  |
| Effective tax rate |  |  |  |  | (21) | % |  | (9) | % |  | 29 | % |

[0000106040-24-000031:mdna:62]
Beginning in 2023, the 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. The tax effects related to the capitalization of R&D expenses are included in the effective tax rate for fiscal years 2023 and 2024.

[0000106040-24-000031:mdna:63]
40

[0000106040-24-000031:mdna:64]
The primary drivers of the difference between the effective tax rate for 2024 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2025 through 2031. On November 1, 2023, one of our tax holidays in Malaysia expired. We have applied for an extension and anticipate this extension, if granted, will be applied retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, we are applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, we will make an adjustment to our effective tax rate in that period.

[0000106040-24-000031:mdna:65]
The primary drivers of the difference between the effective tax rate for 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during years 2025 through 2031.

[0000106040-24-000031:mdna:66]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. The 2017 Act requires us to capitalize and amortize R&D expenses rather than expensing them in the year incurred. As described above, these capitalized expenses are included in our effective tax rate for 2024, but did not have a material impact on the effective tax rate due to our reduced profitability. Mandatory capitalization of R&D is expected to materially increase our effective tax rate and taxes paid in future periods, if not repealed or otherwise modified. In addition, our total tax expense in future years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-24-000031:mdna:67]
On December 20, 2021, the OECD/G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two Model Rules”). Several non-US jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of the Pillar Two Model Rules, which may be effective for us as early as 2025. When effective, this legislation could materially increase our tax obligations in certain jurisdictions. We continue to evaluate the tax impact of enacted and future legislation concerning the Pillar Two Model Rules in the non-US tax jurisdictions we operate in.

[0000106040-24-000031:mdna:68]
For additional information regarding Income tax expense, see Part II, Item 8, Note 13, Income Tax Expense, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:69]
A discussion of our results of operations for 2022, including a comparison of such results of operations to 2023, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, included in our Annual Report on Form 10-K for the year ended June 30, 2023 filed with the SEC on August 22, 2023.

[0000106040-24-000031:mdna:70]
Liquidity and Capital Resources

[0000106040-24-000031:mdna:71]
The following table summarizes our statements of cash flows:

[0000106040-24-000031:mdna:72]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | (294) |  |  | $ | (408) |  |  | $ | 1,880 |  |
| Investing activities | (27) |  |  | (762) |  |  | (1,192) |  |
| Financing activities | 187 |  |  | 875 |  |  | (1,718) |  |
| Effect of exchange rate changes on cash | (10) |  |  | (9) |  |  | (13) |  |
| Net decrease in cash and cash equivalents | $ | (144) |  |  | $ | (304) |  |  | $ | (1,043) |  |

[0000106040-24-000031:mdna:73]
We had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012 and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the twelve months ended June 28, 2024, we made payments of $363 million for tax and $161 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $185 million as of June 28, 2024, related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000031:mdna:74]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $165 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules. See Part II, Item 8, Note 13, Income Tax Expense, of the Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:75]
We have an existing shelf registration statement (the “Shelf Registration Statement”) filed with the SEC, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. The Shelf Registration Statement expires in late August 2024, and we plan to renew the Shelf Registration Statement at that time. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-24-000031:mdna:76]
As noted previously, in 2024, we had scaled back on capital expenditures, consolidating production lines and reducing bit growth to align with market demand. We reduced our expenditures for property, plant and equipment and our portion of the Flash Ventures’ capital expenditures for its operations to approximately $825 million in 2024 from approximately $2.22 billion in 2023. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we reduced our net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to $53 million in 2024 from $794 million in 2023. We continue to be cautious in our capital investment and expect our cash capital expenditures in 2025 to remain below 2023 expenditures.

[0000106040-24-000031:mdna:77]
We believe our cash and cash equivalents as well as our available revolving credit facility will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:78]
A total of $1.43 billion and $1.28 billion of our cash and cash equivalents were held outside of the U.S. as of June 28, 2024 and June 30, 2023, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-24-000031:mdna:79]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-24-000031:mdna:80]
Operating Activities

[0000106040-24-000031:mdna:81]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $307 million for 2024, as compared to $92 million of net cash provided by such changes for 2023, which largely reflects payments made on the IRS matter and an increase in net operating assets and liabilities resulting from the increase in the volume of our business. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. At the end of the respective fourth quarters, the cash conversion cycles were as follows (in days):

[0000106040-24-000031:mdna:82]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in days) |
| Days sales outstanding | 52 |  |  | 54 |  |  | 56 |  |
| Days in inventory | 126 |  |  | 130 |  |  | 107 |  |
| Days payables outstanding | (65) |  |  | (56) |  |  | (66) |  |
| Cash conversion cycle | 113 |  |  | 128 |  |  | 97 |  |

[0000106040-24-000031:mdna:83]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments to and collections from customers. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds and shipments to customers. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we make payment term modifications with vendors through negotiations with them or by granting to, or receiving from, our vendors payment term accommodations. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances.

[0000106040-24-000031:mdna:84]
In 2024, DSO decreased by 2 days over the prior year, reflecting timing of shipments and customer collections, partially offset by a 5-day increase from lower accounts receivable factoring. DIO decreased by 4 days over the prior year, primarily reflecting an increase in products shipped. DPO increased 9 days over the prior year, primarily due to more favorable payment terms and routine variations in the timing of purchases and payments during the period.

[0000106040-24-000031:mdna:85]
Investing Activities

[0000106040-24-000031:mdna:86]
Net cash used in investing activities in 2024 primarily consisted of $487 million in capital expenditures, partially offset by $239 million in net notes receivable proceeds from (issuances to) Flash Ventures and $195 million in proceeds from the sale of property, plant and equipment. Net cash used in investing activities in 2023 primarily consisted of $821 million of capital expenditures, partially offset by $14 million in net notes receivable proceeds from (issuances to) Flash Ventures.

[0000106040-24-000031:mdna:87]
Financing Activities

[0000106040-24-000031:mdna:88]
During 2024, net cash provided by financing activities primarily consisted of $3.00 billion in proceeds from the issuance of the 2028 Convertible Notes, the drawdown of the Delayed Draw Term Loan and draws on the revolving credit facility. These sources were partially offset by $2.10 billion used for the repayment of draws on the revolving credit facility, repayments of the Delayed Draw Term Loan, scheduled payments on the Term Loan A-2, and settlement of the remaining 2024 Convertible Notes; $505 million used to repurchase a portion of the 2024 Convertible Notes and $155 million for the purchase of capped calls to hedge the potential dilution impact of the conversion feature of the 2028 Convertible Notes. Net cash provided by financing activities in 2023 primarily consisted of $881 million from the issuance of Series A Preferred Stock and $93 million from issuance of stock under employee stock plans, partially offset by $80 million used for taxes paid on vested stock awards under employee stock plans. In addition, we drew and repaid $1.18 billion under our revolving credit facility within the period.

[0000106040-24-000031:mdna:89]
A discussion of our cash flows for 2022, including a comparison of such cash flows to 2023, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations – Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended June 30, 2023 filed with the SEC on August 22, 2023.

[0000106040-24-000031:mdna:90]
43

[0000106040-24-000031:mdna:91]
Off-Balance Sheet Arrangements

[0000106040-24-000031:mdna:92]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short- and Long-term Liquidity – Indemnifications” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:93]
44

[0000106040-24-000031:mdna:94]
Short- and Long-term Liquidity

[0000106040-24-000031:mdna:95]
Material Cash Requirements

[0000106040-24-000031:mdna:96]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of June 28, 2024. In addition, see the discussions further below related to unrecognized tax benefits, the intellectual property litigation, dividend rights with respect to the Series A Preferred Stock, foreign exchange contracts and indemnifications.

[0000106040-24-000031:mdna:97]
|  | Total |  | 1 Year (2025) |  | 2-3 Years (2026-2027) |  | 4-5 Years (2028-2029) |  | More than 5 Years (Beyond 2029) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,488 |  |  | $ | 1,750 |  |  | $ | 4,738 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 1,076 |  |  | 371 |  |  | 527 |  |  | 132 |  |  | 46 |  |
| Flash Ventures related commitments(2) | 4,168 |  |  | 2,021 |  |  | 1,526 |  |  | 522 |  |  | 99 |  |
| Operating leases | 499 |  |  | 60 |  |  | 107 |  |  | 78 |  |  | 254 |  |
| Purchase obligations and other commitments | 477 |  |  | 172 |  |  | 155 |  |  | 40 |  |  | 110 |  |
| Mandatory deemed repatriation tax | 466 |  |  | 265 |  |  | 201 |  |  | — |  |  | — |  |
| Total | $ | 14,174 |  |  | $ | 4,639 |  |  | $ | 7,254 |  |  | $ | 1,272 |  |  | $ | 1,009 |  |

[0000106040-24-000031:mdna:98]
(1)Principal portion of debt, excluding discounts and issuance costs based on contractual maturity. As of June 28, 2024, $1.60 billion of our 2028 Convertible Notes are currently convertible at the option of the holders through September 30, 2024, at which point the trading price of our common stock price will be re-evaluated to determine if the 2028 Convertible Notes will continue to be convertible in the subsequent calendar quarter.

[0000106040-24-000031:mdna:99]
(2)Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0000106040-24-000031:mdna:100]
Unrecognized Tax Benefits

[0000106040-24-000031:mdna:101]
As of June 28, 2024, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $721 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties related to unrecognized tax benefits as of June 28, 2024, were approximately $181 million. Of these amounts, approximately $736 million could result in potential cash payments.

[0000106040-24-000031:mdna:102]
As noted above, we had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the twelve months ended June 28, 2024, we made payments of $363 million for tax and $161 million for interest with respect to years 2008 through 2012 and recorded adjustments to align with IRS calculations, resulting in a remaining liability of $185 million as of June 28, 2024 related to all years from 2008 through 2015. We expect to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000031:mdna:103]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $165 million. Of this amount, $34 million of interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules. See Part II, Item 8, Note 13, Income Tax Expense of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:104]
Intellectual Property Litigation

[0000106040-24-000031:mdna:105]
As of June 28, 2024, we have recognized an aggregate liability of $384 million within Accrued expenses on our Consolidated Balance Sheets as of June 28, 2024, for the potential loss from a litigation matter, as discussed in Part II, Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. Of that amount, $291 million was recognized as Litigation matter under Operating expenses on our Consolidated Statements of Operations for the year ended June 28, 2024 and $93 million recognized within Other non-current assets on the our Consolidated Balance Sheets as June 28, 2024, to be amortized over the remaining lives of the MRT Patents. See Part II, Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information.

[0000106040-24-000031:mdna:106]
Dividends

[0000106040-24-000031:mdna:107]
As of June 28, 2024, 235,000 shares of our Series A Preferred Stock remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information regarding these dividend provisions.

[0000106040-24-000031:mdna:108]
In April 2020, we suspended the payment of dividends to common shareholders and intend to utilize cash from operations to reinvest in the business and to support our ongoing deleveraging efforts.

[0000106040-24-000031:mdna:109]
Debt

[0000106040-24-000031:mdna:110]
As described in “Key Developments – Financing Activities” above, we undertook several financing actions during 2024, including the issuance of the 2028 Convertible Notes and the repurchase and/or settlement of our 2024 Convertible Notes.

[0000106040-24-000031:mdna:111]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000031:mdna:112]
During the 30 trading-day period ended June 28, 2024, the last trading day of the applicable calendar quarter, the trading price of our common stock was greater than or equal to 130% of the then-applicable conversion price for the 2028 Convertible Notes for at least 20 trading days. As such, the conditional conversion feature of the 2028 Convertible Notes was triggered and the 2028 Convertible Notes are convertible through September 30, 2024, at which point the trading price of our common stock price will be re-evaluated to determine if the 2028 Convertible Notes will continue to be convertible in the subsequent calendar quarter.

[0000106040-24-000031:mdna:113]
In addition to our existing debt, as of June 28, 2024, we had $2.22 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. The loan agreement governing our revolving credit facility and our Term Loan A-2 due 2027 require us to comply with certain financial covenants, consisting of a minimum leverage ratio covenant and a minimum liquidity covenant. As of June 28, 2024, we were in compliance with these financial covenants.

[0000106040-24-000031:mdna:114]
46

[0000106040-24-000031:mdna:115]
Flash Ventures

[0000106040-24-000031:mdna:116]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements, of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of June 28, 2024, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0000106040-24-000031:mdna:117]
Purchase Obligations and Other Commitments

[0000106040-24-000031:mdna:118]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0000106040-24-000031:mdna:119]
Mandatory Deemed Repatriation Tax

[0000106040-24-000031:mdna:120]
The following is a summary of our estimated mandatory deemed repatriation tax obligations that are payable in the following years (in millions):

[0000106040-24-000031:mdna:121]
|  |  | June 28,2024 |
| 2025 |  | $ | 265 |  |
| 2026 |  | 201 |  |
| Total |  | $ | 466 |  |

[0000106040-24-000031:mdna:122]
Mandatory Research and Development Expense Capitalization

[0000106040-24-000031:mdna:123]
Since the beginning of 2023, the 2017 Act has required us to capitalize and amortize R&D expenses rather than expensing them in the year incurred, which is expected to result in materially higher cash tax payments in future profitable periods, if not repealed or otherwise modified.

[0000106040-24-000031:mdna:124]
Foreign Exchange Contracts

[0000106040-24-000031:mdna:125]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 8, Note 6, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:126]
Indemnifications

[0000106040-24-000031:mdna:127]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-24-000031:mdna:128]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-24-000031:mdna:129]
Recent Accounting Pronouncements

[0000106040-24-000031:mdna:130]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-24-000031:mdna:131]
Critical Accounting Policies and Estimates

[0000106040-24-000031:mdna:132]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0000106040-24-000031:mdna:133]
Revenue

[0000106040-24-000031:mdna:134]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. We record estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. We constrain variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0000106040-24-000031:mdna:135]
For sales to OEMs, our methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from us or other agreed-upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgement and the estimated amount of variable consideration can differ from the actual amount.

[0000106040-24-000031:mdna:136]
Inventories

[0000106040-24-000031:mdna:137]
We value inventories at the lower of cost or net realizable value (“NRV”), with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to lower of cost or net realizable value or for obsolete or excess inventory based on assumptions, which requires significant judgement. The determination of NRV involves estimating the ASPs less any selling expenses of inventory based on market conditions and customer demand. To estimate the ASPs and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0000106040-24-000031:mdna:138]
We periodically perform an excess and obsolete analysis of our inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. If in any period, we can sell inventories that had been written down to a level below the realized selling price in previous period, higher gross profit would be recognized in that period. While adjustments to these reserves have generally not been material to the years presented, in 2023, we recorded a charge to Cost of revenue of approximately $130 million, primarily to reduce component inventory to net realizable value as a result of a sudden change in demand for certain products.

[0000106040-24-000031:mdna:139]
Income Taxes

[0000106040-24-000031:mdna:140]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized. The assessment of valuation allowances against our deferred tax assets requires estimations and significant judgment. We continue to assess and adjust our valuation allowance based on operating results and market conditions. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-24-000031:mdna:141]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the Consolidated Financial Statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the Consolidated Financial Statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-24-000031:mdna:142]
Goodwill

[0000106040-24-000031:mdna:143]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fourth quarter for each reporting unit. We use qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to perform a quantitative assessment to determine the amount of impairment. We are required to use judgment when applying the goodwill impairment test, including in the identification of our reporting units. We also make judgments and assumptions in the assignment of assets and liabilities to our reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each of our reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations. We have not identified any impairment indicators for our reporting units as of June 28, 2024. We also did not incur any impairment charges for 2023 or 2022.

[0000106040-24-000031:mdna:144]
Litigation and Contingencies

[0000106040-24-000031:mdna:145]
We disclose information regarding claims and contingencies where the likelihood of a material loss is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose the matter and an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves significant judgments about the merits of the claim, applicable law, potential outcomes, estimates and inherent uncertainties. We engage relevant subject matter experts to assist us with our assessment of available information to reach conclusions on the likelihood and amount, or range, of potential loss. The actual outcome of such matters could differ materially from our estimates.
