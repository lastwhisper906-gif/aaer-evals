# WDC notes — 0000106040-24-000031


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000106040-24-000031:notes:1]
Part III incorporates by reference certain information from the registrant’s definitive proxy statement (the “Proxy Statement”) for the 2024 Annual Meeting of Stockholders, which will be filed with the Securities and Exchange Commission within 120 days after the end of the 2024 fiscal year. Except with respect to information specifically incorporated by reference in this Form 10-K, the Proxy Statement is not deemed to be filed as part hereof.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-24-000031:notes:2]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both hard disk drives and NAND flash technologies.

[0000106040-24-000031:notes:3]
The Company’s broad portfolio of technology and products addresses the following key end markets: Cloud, Client and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property (“IP”) portfolio, which is included in each of these three end market categories.

[0000106040-24-000031:notes:4]
Basis of Presentation

[0000106040-24-000031:notes:5]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-24-000031:notes:6]
Fiscal Year

[0000106040-24-000031:notes:7]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2024, 2023, and 2022, which ended on June 28, 2024, June 30, 2023 and July 1, 2022, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated basis.

[0000106040-24-000031:notes:8]
Segment Reporting

[0000106040-24-000031:notes:9]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: hard disk drives (“HDD”) and flash-based products (“Flash”).

[0000106040-24-000031:notes:10]
The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), evaluates the performance of the Company and makes decisions regarding the allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are either not available or not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000106040-24-000031:notes:11]
Basis of Consolidation

[0000106040-24-000031:notes:12]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from the remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in Accumulated other comprehensive loss, a component of shareholders’ equity.

[0000106040-24-000031:notes:13]
Business Separation Costs

[0000106040-24-000031:notes:14]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of its business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company has incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses. The separation and transition costs are recorded within Business separation costs in the Consolidated Statements of Operations.

[0000106040-24-000031:notes:15]
Use of Estimates

[0000106040-24-000031:notes:16]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

[0000106040-24-000031:notes:17]
Cash Equivalents

[0000106040-24-000031:notes:18]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. These deposits are typically in excess of U.S. insured limits. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.

[0000106040-24-000031:notes:19]
Equity Investments

[0000106040-24-000031:notes:20]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority, or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income, net, in the Consolidated Statements of Operations and were immaterial for all years presented.

[0000106040-24-000031:notes:21]
If the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over the operating and financial policies of the investee, the Company accounts for these investments at fair value, or if these equity securities do not have a readily determinable fair value, these securities are measured and recorded using the measurement alternative under Accounting Standards Update (“ASU”) No. 2016-01, “Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities,” which is cost minus impairment, if any, plus or minus changes resulting from observable price changes. These investments are recorded within Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-24-000031:notes:22]
Variable Interest Entities

[0000106040-24-000031:notes:23]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company would consolidate such entity and reflect the non-controlling interest of other beneficiaries of that entity. For the periods presented, the Company determined that it did not have any VIEs that are required to be consolidated.

[0000106040-24-000031:notes:24]
Fair Value of Financial Instruments

[0000106040-24-000031:notes:25]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The carrying value of notes receivable from Flash Ventures also approximates fair value for all periods presented because they bear variable market rates of interest. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-24-000031:notes:26]
Inventories

[0000106040-24-000031:notes:27]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-24-000031:notes:28]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write-down of inventory that could materially affect operating results.

[0000106040-24-000031:notes:29]
Property, Plant and Equipment

[0000106040-24-000031:notes:30]
Property, plant, and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings and improvements are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-24-000031:notes:31]
Goodwill and Other Long-Lived Assets

[0000106040-24-000031:notes:32]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company’s assessment resulted in no impairment of goodwill in 2024, 2023 or 2022.

[0000106040-24-000031:notes:33]
The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on the results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-24-000031:notes:34]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test at least annually or whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment on the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The Company’s assessment resulted in no impairment of IPR&D in 2024, 2023 or 2022.

[0000106040-24-000031:notes:35]
Other long-lived assets are depreciated or amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable from undiscounted cash flows. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow. See Note 4, Supplemental Financial Statement Data, for additional disclosures related to the Company’s other long-lived assets.

[0000106040-24-000031:notes:36]
Revenue and Accounts Receivable

[0000106040-24-000031:notes:37]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not considered constrained based on the Company’s history with similar transactions and the fact that uncertainties are resolved in a fairly short period of time.

[0000106040-24-000031:notes:38]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue is immaterial, and mainly includes professional service arrangements and post-contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right-to-use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right-to-access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-24-000031:notes:39]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

[0000106040-24-000031:notes:40]
The Company also applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The transaction price allocated to the Company’s remaining performance obligations as of June 28, 2024 and June 30, 2023, was not material.

[0000106040-24-000031:notes:41]
The contract assets and contract liabilities for the years ended June 28, 2024 and June 30, 2023 were not material.

[0000106040-24-000031:notes:42]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-24-000031:notes:43]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics.

[0000106040-24-000031:notes:44]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed-upon sales incentive programs. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0000106040-24-000031:notes:45]
Marketing development program costs are typically recorded as a reduction of the transaction price and, therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-24-000031:notes:46]
For contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. If applicable, the Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices.

[0000106040-24-000031:notes:47]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency or other collection issues. In addition, the Company routinely analyzes the various receivable aging categories to establish reserves based on a combination of past-due receivables and expected future losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss trajectory changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-24-000031:notes:48]
Warranty

[0000106040-24-000031:notes:49]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0000106040-24-000031:notes:50]
Litigation and Other Contingencies

[0000106040-24-000031:notes:51]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each claim where the likelihood of a material loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 17, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-24-000031:notes:52]
Advertising Expense

[0000106040-24-000031:notes:53]
Advertising costs are expensed as incurred and amounted to $56 million, $69 million and $88 million in 2024, 2023 and 2022, respectively. These expenses are included in Selling, general and administrative in the Consolidated Statements of Operations.

[0000106040-24-000031:notes:54]
Research and Development Expense

[0000106040-24-000031:notes:55]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-24-000031:notes:56]
Income Taxes

[0000106040-24-000031:notes:57]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-24-000031:notes:58]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.

[0000106040-24-000031:notes:59]
Net Income (Loss) Per Common Share

[0000106040-24-000031:notes:60]
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.

[0000106040-24-000031:notes:61]
The Company computes basic income (loss) per common share by dividing net income (loss) attributable to common shareholders by the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed by using diluted net income (loss) attributable to common shareholders, the weighted average number of common shares and potentially dilutive securities outstanding during the period using the treasury stock method or the “if-converted” method based on the nature of the securities. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”) and restricted stock unit awards with performance conditions or market conditions (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”), shares issuable in connection with the Company’s convertible notes and convertible preferred stock.

[0000106040-24-000031:notes:62]
Stock-Based Compensation

[0000106040-24-000031:notes:63]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of RSUs and PSUs with a performance condition are determined based on the closing market price of the Company’s stock on the date of the grant. The fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option pricing model and require the input of highly subjective assumptions. The fair values of PSUs with a market condition are estimated using a Monte Carlo simulation model. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance or market conditions and completion of a requisite service period. At the end of each reporting period, the Company evaluates the probability that PSUs with a performance condition will be earned and records the related stock-based compensation expense over the service period. Compensation expense for PSUs with market conditions is recognized ratably over the required service period regardless of expected or actual achievement.

[0000106040-24-000031:notes:64]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-24-000031:notes:65]
Other comprehensive income (loss), net of tax refers to gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is primarily comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-24-000031:notes:66]
Derivative Contracts

[0000106040-24-000031:notes:67]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. Substantially all of these contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Thai baht, Korean won and Israeli shekel, which had an aggregate notional amount of $3.86 billion and $5.66 billion at June 28, 2024 and June 30, 2023, respectively.

[0000106040-24-000031:notes:68]
If the derivative is designated as a cash flow hedge and is determined to be highly effective, the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in Cost of revenue and Operating expenses, and presented within cash flows from operating activities. The Company previously had interest rate swaps which were accounted for as designated cash flow hedges to mitigate variations in interest payments under a portion of its variable rate term loans. The Company paid interest monthly at a fixed rate and received interest monthly at the applicable index rate on the notional amount of the contract with realized gains or losses recognized in Interest expense. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-24-000031:notes:69]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income, net.

[0000106040-24-000031:notes:70]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-24-000031:notes:71]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with actuarial changes in the funded status recognized through accumulated other comprehensive loss in the year in which such changes occur.

[0000106040-24-000031:notes:72]
The Company reports the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are presented in Other income, net in the Consolidated Statements of Operations.

[0000106040-24-000031:notes:73]
Leases

[0000106040-24-000031:notes:74]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2039. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0000106040-24-000031:notes:75]
Revision of Previously Issued Financial Statements

[0000106040-24-000031:notes:76]
As previously disclosed in the Company’s Quarterly Reports on Form 10-Q for the periods ended December 29, 2023 and March 29, 2024, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. (collectively, “Flash Ventures”). The errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.

[0000106040-24-000031:notes:77]
Based on an analysis of quantitative and qualitative factors in accordance with SAB No. 99, “Materiality,” and SAB No. 108, “Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements,” and as described further in Note 18, Revision of Previously Issued Financial Statements, the Company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred, but that correcting the cumulative errors in the period detected would have been material to the Company's results of operations for that period. Accordingly, the Company has revised previously reported financial information presented herein for such immaterial errors. A summary of revisions to the Condensed Consolidated Financial Statements presented herein is included for comparative purposes in Note 18, Revision of Previously Issued Financial Statements.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-24-000031:notes:78]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-24-000031:notes:79]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. The ASU requires the Company to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 and to provide certain rollforward information related to those obligations beginning in the Company’s first fiscal quarter of 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. The Company adopted the guidance on the first day of fiscal year 2024, except for the rollforward information, which the Company is compiling and intends to provide beginning in fiscal year 2025. See Note 16, Supplier Finance Program, of the Notes to Consolidated Financial Statements for information regarding the supplier finance program.

[0000106040-24-000031:notes:80]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-24-000031:notes:81]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures”, which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. The ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity's CODM, a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.

[0000106040-24-000031:notes:82]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures”. The ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The amendments are effective for the Company’s fiscal year 2026, with early adoption permitted. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending June 27, 2025. The Company expects to provide any required disclosures at that time.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-24-000031:notes:83]
Business Segments, Geographic Information, and Concentrations of Risk 
The following table summarizes the operating performance of the Company’s reportable segments:

[0000106040-24-000031:notes:84]
|  | 2024 |  | 2023 |  | 2022 |  |  |
|  | (in millions, except percentages) |  |  |
| Revenue, net: |  |  |  |  |  |  |  |
| Flash | $ | 6,687 |  |  | $ | 6,063 |  |  | $ | 9,753 |  |  |  |
| HDD | 6,316 |  |  | 6,255 |  |  | 9,040 |  |  |  |
| Total net revenue | $ | 13,003 |  |  | $ | 12,318 |  |  | $ | 18,793 |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 1,079 |  |  | $ | 433 |  |  | $ | 3,527 |  |  |  |
| HDD | 1,881 |  |  | 1,505 |  |  | 2,661 |  |  |  |
| Total gross profit for segments | 2,960 |  |  | 1,938 |  |  | 6,188 |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (49) |  |  | (49) |  |  | (48) |  |  |  |
| Amortization of acquired intangible assets | (3) |  |  | — |  |  | (66) |  |  |  |
| Recovery from contamination incident | 37 |  |  | — |  |  | — |  |  |  |
| Contamination related charges | — |  |  | — |  |  | (207) |  |  |  |
| Recoveries from a power outage incident | — |  |  | — |  |  | 7 |  |  |  |
| Other | — |  |  | (2) |  |  | — |  |  |  |
| Total unallocated corporate items | (15) |  |  | (51) |  |  | (314) |  |  |  |
| Consolidated gross profit | $ | 2,945 |  |  | $ | 1,887 |  |  | $ | 5,874 |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 16.1 | % |  | 7.1 | % |  | 36.2 | % |  |  |
| HDD | 29.8 | % |  | 24.1 | % |  | 29.4 | % |  |  |
| Consolidated gross margin | 22.6 | % |  | 15.3 | % |  | 31.3 | % |  |  |

[0000106040-24-000031:notes:85]
Disaggregated Revenue

[0000106040-24-000031:notes:86]
The Company’s broad portfolio of technology and products address multiple end markets. Cloud is comprised primarily of products for public or private cloud environments and end customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD and Flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-24-000031:notes:87]
The Company’s disaggregated revenue information is as follows:

[0000106040-24-000031:notes:88]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |
| Cloud | $ | 5,378 |  |  | $ | 5,252 |  |  | $ | 8,017 |  |
| Client | 4,647 |  |  | 4,328 |  |  | 7,076 |  |
| Consumer | 2,978 |  |  | 2,738 |  |  | 3,700 |  |
| Total revenue | $ | 13,003 |  |  | $ | 12,318 |  |  | $ | 18,793 |  |

[0000106040-24-000031:notes:89]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe, the Middle East and Africa. The following tables summarize the Company’s operations by geographic area:

[0000106040-24-000031:notes:90]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Net revenue (1) |  |  |  |  |  |
| United States | $ | 3,585 |  |  | $ | 3,810 |  |  | $ | 5,411 |  |
| China | 3,037 |  |  | 2,773 |  |  | 4,525 |  |
| Hong Kong | 2,375 |  |  | 1,829 |  |  | 3,645 |  |
| Rest of Asia | 1,490 |  |  | 1,444 |  |  | 1,884 |  |
| Europe, Middle East and Africa | 2,130 |  |  | 2,100 |  |  | 2,872 |  |
| Other | 386 |  |  | 362 |  |  | 456 |  |
| Total | $ | 13,003 |  |  | $ | 12,318 |  |  | $ | 18,793 |  |

[0000106040-24-000031:notes:91]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee.

[0000106040-24-000031:notes:92]
|  | 2024 |  | 2023 |
|  | (in millions) |
| Long-lived assets (1) |  |  |  |
| United States | $ | 897 |  |  | $ | 1,071 |  |
| Malaysia | 718 |  |  | 861 |  |
| China | 338 |  |  | 397 |  |
| Thailand | 825 |  |  | 851 |  |
| Rest of Asia | 353 |  |  | 393 |  |
| Europe, Middle East and Africa | 36 |  |  | 47 |  |
| Total | $ | 3,167 |  |  | $ | 3,620 |  |

[0000106040-24-000031:notes:93]
(1)    Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located.

[0000106040-24-000031:notes:94]
Customer Concentration and Credit Risk

[0000106040-24-000031:notes:95]
The Company sells its products to computer manufacturers and OEMs, cloud service providers, resellers, distributors and retailers throughout the world. For 2024, 2023 and 2022, no customer accounted for 10% or more of the Company’s net revenue. For 2024, 2023 and 2022, the Company’s top 10 customers accounted for 39%, 43% and 45%, respectively, of the Company’s net revenue.

[0000106040-24-000031:notes:96]
The Company performs ongoing credit evaluations of its customers’ financial condition to manage collection risk, in some cases supplemented by collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial condition. As of June 28, 2024 and June 30, 2023, net accounts receivable were $2.17 billion and $1.60 billion, respectively, and reserves for potential credit losses were not material. As of June 28, 2024, one customer accounted for 15% of the Company’s net accounts receivable and as of June 30, 2023, two customers accounted for 15% and 13% of the Company’s net accounts receivable.

[0000106040-24-000031:notes:97]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-24-000031:notes:98]
Supplier Concentration

[0000106040-24-000031:notes:99]
All of the Company’s Flash require silicon wafers for the memory and controller components. The Company’s flash memory wafers are currently supplied almost entirely from Flash Ventures and the Company’s controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-24-000031:notes:100]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect on its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.

[0000106040-24-000031:notes:101]
Goodwill

[0000106040-24-000031:notes:102]
The following table provides a summary of goodwill activity for the period:

[0000106040-24-000031:notes:103]
|  | Flash |  | HDD |  | Total |
|  | (in millions) |
| Balance at June 30, 2023 | $ | 5,716 |  |  | $ | 4,321 |  |  | $ | 10,037 |  |
| Foreign currency translation adjustment | (3) |  |  | (2) |  |  | (5) |  |
| Balance at June 28, 2024 | $ | 5,713 |  |  | $ | 4,319 |  |  | $ | 10,032 |  |

[0000106040-24-000031:notes:104]
Management performed its annual goodwill impairment assessment for both reporting units as of the first day of its fourth quarter ended June 28, 2024 and concluded that there were no impairment indicators as of June 28, 2024. The Company also did not incur any impairment charges for 2023 or 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-24-000031:notes:105]
Supplemental Financial Statement Data
Accounts receivable, net

[0000106040-24-000031:notes:106]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. In 2024, 2023 and 2022, the Company sold trade accounts receivable aggregating $623 million, $776 million and $400 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Consolidated Statements of Operations. No factored receivables were outstanding as of June 28, 2024, and $150 million of factored receivables remained outstanding as of June 30, 2023.

[0000106040-24-000031:notes:107]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,727 |  |  | $ | 2,096 |  |
| Work-in-process | 1,066 |  |  | 979 |  |
| Finished goods | 549 |  |  | 623 |  |
| Total inventories | $ | 3,342 |  |  | $ | 3,698 |  |

[0000106040-24-000031:notes:108]
Property, plant and equipment, net

[0000106040-24-000031:notes:109]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 235 |  |  | $ | 269 |  |
| Buildings and improvements | 1,820 |  |  | 1,955 |  |
| Machinery and equipment | 8,646 |  |  | 8,704 |  |
| Computer equipment and software | 471 |  |  | 470 |  |
| Furniture and fixtures | 54 |  |  | 54 |  |
| Construction-in-process | 797 |  |  | 798 |  |
| Property, plant and equipment, gross | 12,023 |  |  | 12,250 |  |
| Accumulated depreciation | (8,856) |  |  | (8,630) |  |
| Property, plant and equipment, net | $ | 3,167 |  |  | $ | 3,620 |  |

[0000106040-24-000031:notes:110]
Depreciation expense for property, plant and equipment totaled $566 million, $695 million and $708 million in 2024, 2023 and 2022, respectively.

[0000106040-24-000031:notes:111]
Other intangible assets, net

[0000106040-24-000031:notes:112]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of June 28, 2024 and June 30, 2023, IPR&D included in intangible assets, net was $72 million and $80 million, respectively. During the year ended June 28, 2024, one IPR&D project reached technological feasibility and $8 million was reclassified from IPR&D to existing technology and commenced amortization over an estimated useful life of three years. During 2024, 2023 and 2022, the Company did not record any impairment charges related to IPR&D.

[0000106040-24-000031:notes:113]
Amortizable intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. As of June 28, 2024 and June 29, 2023, intangible assets had been substantially fully amortized and were not material. Amortization expense for intangible assets subject to amortization totaled $3 million, $133 million and $221 million in 2024, 2023 and 2022, respectively.

[0000106040-24-000031:notes:114]
Product warranty liability

[0000106040-24-000031:notes:115]
Changes in the warranty accrual were as follows:

[0000106040-24-000031:notes:116]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| Warranty accrual, beginning of period |  |  |  |  | $ | 244 |  |  | $ | 345 |  |  | $ | 363 |  |
| Charges to operations |  |  |  |  | 107 |  |  | 106 |  |  | 146 |  |
| Utilization |  |  |  |  | (154) |  |  | (169) |  |  | (103) |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (8) |  |  | (38) |  |  | (61) |  |
| Warranty accrual, end of period |  |  |  |  | $ | 189 |  |  | $ | 244 |  |  | $ | 345 |  |

[0000106040-24-000031:notes:117]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-24-000031:notes:118]
|  | 2024 |  | 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 36 |  |  | $ | 97 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 153 |  |  | 147 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 189 |  |  | $ | 244 |  |  |  |  |  |  |  |

[0000106040-24-000031:notes:119]
Other liabilities

[0000106040-24-000031:notes:120]
|  | 2024 |  | 2023 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 201 |  |  | $ | 464 |  |
| Non-current portion of unrecognized tax benefits | 565 |  |  | 408 |  |
| Other non-current liabilities | 604 |  |  | 543 |  |
| Total other liabilities | $ | 1,370 |  |  | $ | 1,415 |  |

[0000106040-24-000031:notes:121]
Accumulated other comprehensive loss

[0000106040-24-000031:notes:122]
Accumulated other comprehensive loss (“AOCL”), net of tax, refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCL:

[0000106040-24-000031:notes:123]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at July 1, 2022 | $ | (11) |  |  | $ | (302) |  |  |  |  |  |  | $ | (266) |  |  | $ | (579) |  |
| Other comprehensive income (loss) before reclassifications | 12 |  |  | (88) |  |  |  |  |  |  | (213) |  |  | (289) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 351 |  |  | 351 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (3) |  |  | 1 |  |  |  |  |  |  | (29) |  |  | (31) |  |
| Net current-period other comprehensive income (loss) | 9 |  |  | (87) |  |  |  |  |  |  | 109 |  |  | 31 |  |
| Balance at June 30, 2023 | (2) |  |  | (389) |  |  |  |  |  |  | (157) |  |  | (548) |  |
| Other comprehensive income (loss) before reclassifications | 23 |  |  | (115) |  |  |  |  |  |  | (331) |  |  | (423) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 244 |  |  | 244 |  |
| Income tax benefit (expense) related to items of other comprehensive loss | (7) |  |  | (1) |  |  |  |  |  |  | 23 |  |  | 15 |  |
| Net current-period other comprehensive loss | 16 |  |  | (116) |  |  |  |  |  |  | (64) |  |  | (164) |  |
| Balance at June 28, 2024 | $ | 14 |  |  | $ | (505) |  |  |  |  |  |  | $ | (221) |  |  | $ | (712) |  |

[0000106040-24-000031:notes:124]
During 2024, the amounts reclassified out of AOCL included losses of $244 million related to foreign exchange contracts.

[0000106040-24-000031:notes:125]
During 2023, the amounts reclassified out of AOCL included losses of $361 million related to foreign exchange contracts, and gains of $10 million related to interest rate swaps.

[0000106040-24-000031:notes:126]
The gains and losses related to interest rate swaps were charged to Interest expense and losses related to foreign contracts were substantially all charged to Cost of revenue in the Consolidated Statements of Operations.
As of June 28, 2024, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-24-000031:notes:127]
Fair Value Measurements and Investments
Financial Instruments Carried at Fair Value

[0000106040-24-000031:notes:128]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-24-000031:notes:129]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0000106040-24-000031:notes:130]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-24-000031:notes:131]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-24-000031:notes:132]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 28, 2024 and June 30, 2023, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-24-000031:notes:133]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents – Money market funds | $ | 416 |  |  | $ | — |  |  | $ | — |  |  | $ | 416 |  |
| Foreign exchange contracts | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total assets at fair value | $ | 416 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 424 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |

[0000106040-24-000031:notes:134]
|  | June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents – Money market funds | $ | 371 |  |  | $ | — |  |  | $ | — |  |  | $ | 371 |  |
| Foreign exchange contracts | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total assets at fair value | $ | 371 |  |  | $ | 35 |  |  | $ | — |  |  | $ | 406 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 192 |  |  | $ | — |  |  | $ | 192 |  |

[0000106040-24-000031:notes:135]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-24-000031:notes:136]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 6, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheets under Other current assets and Accrued expenses, respectively.

[0000106040-24-000031:notes:137]
During 2024 and 2023, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-24-000031:notes:138]
Financial Instruments Not Carried at Fair Value

[0000106040-24-000031:notes:139]
The following table contains the related carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) and fair value (which is based on quoted market prices) for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2024 and the fourth quarter of 2023, respectively.

[0000106040-24-000031:notes:140]
|  | June 28, 2024 |  | June 30, 2023 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | — |  |  | $ | 1,099 |  |  | $ | 1,067 |  |
| 3.00% convertible notes due 2028 | 1,568 |  |  | 2,556 |  |  | — |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,296 |  |  | 2,253 |  |  | 2,293 |  |  | 2,193 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,578 |  |  | 2,539 |  |  | 2,687 |  |  | 2,661 |  |
| 2.85% senior notes due 2029 | 496 |  |  | 434 |  |  | 496 |  |  | 400 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 407 |  |  | 495 |  |  | 371 |  |
| Total | $ | 7,434 |  |  | $ | 8,189 |  |  | $ | 7,070 |  |  | $ | 6,692 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-24-000031:notes:141]
Derivative Instruments and Hedging Activities
As of June 28, 2024, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed twelve months. As of June 28, 2024, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0000106040-24-000031:notes:142]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign-currency denominated monetary assets and liabilities. For each of 2024, 2023 and 2022, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-24-000031:notes:143]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 4, Supplemental Financial Statement Data – Accumulated other comprehensive loss.

[0000106040-24-000031:notes:144]
Netting Arrangements

[0000106040-24-000031:notes:145]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 28, 2024 and June 30, 2023, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-24-000031:notes:146]
Debt
Debt consisted of the following as of June 28, 2024 and June 30, 2023:

[0000106040-24-000031:notes:147]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| 1.50% convertible notes due 2024 | $ | — |  |  | $ | 1,100 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | — |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,588 |  |  | 2,700 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,488 |  |  | 7,100 |  |
| Issuance costs | (54) |  |  | (30) |  |
| Subtotal | 7,434 |  |  | 7,070 |  |
| Less: current portion of long-term debt | (1,750) |  |  | (1,213) |  |
| Long-term debt | $ | 5,684 |  |  | $ | 5,857 |  |

[0000106040-24-000031:notes:148]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are jointly and severally guaranteed by each of the Company’s wholly-owned subsidiaries that guarantees the 4.75% senior unsecured notes due 2026 (currently, Western Digital Technologies, Inc., Sandisk Technologies, Inc. and Sandisk Corporation).

[0000106040-24-000031:notes:149]
The 2028 Convertible Notes are convertible at the option of any holder beginning on August 15, 2028 at an initial conversion price of approximately $52.20 per share of common stock. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-24-000031:notes:150]
During the three months ended June 28, 2024, the conditional conversion feature above of the 2028 Convertible Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then-applicable conversion price for the 2028 Convertible Notes for at least 20 trading days during the period of 30 consecutive trading days ending on June 28, 2024, the last trading day of the applicable calendar quarter. Accordingly, the 2028 Convertible Notes are convertible through September 30, 2024, at which point the common stock price will be re-evaluated to determine if the 2028 Convertible Notes will continue to be convertible in the subsequent calendar quarter. The Company has classified the 2028 Convertible Notes as current liabilities in the Company’s Consolidated Financial Statements as of June 28, 2024.

[0000106040-24-000031:notes:151]
Net proceeds from the 2028 Convertible Notes were approximately $1.56 billion after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes. As of June 28, 2024, issuance costs of $32 million remained unamortized.

[0000106040-24-000031:notes:152]
For the year ended June 28, 2024, the total interest expense was $37 million with coupon interest expense of $32 million and the amortization of debt discount and issuance costs of $5 million, respectively.

[0000106040-24-000031:notes:153]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions, and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in stockholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to Additional paid-in capital on the Company’s Consolidated Balance Sheets.

[0000106040-24-000031:notes:154]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bore interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. Contemporaneously with the issuance of the 2028 Convertible Notes as noted above, the Company entered into individually negotiated transactions with certain holders of the Company’s 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount. On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-24-000031:notes:155]
During the year ended June 28, 2024, the Company entered into a third amendment (“Amendment No. 3”) to the Company’s Amended and Restated Loan Agreement, dated as of January 7, 2022 which governs the Term-Loan A-2 and the revolving credit facility maturing in January 2027 (as amended, the “Credit Agreement”). Amendment No. 3 extended the time period during which certain real property is excluded from the collateral package supporting the obligations under the Credit Agreement.

[0000106040-24-000031:notes:156]
The Credit Agreement requires the Company to maintain a ratio (“Leverage Ratio”) of total funded debt to Consolidated Adjusted EBITDA (as defined in the Credit Agreement) below a maximum at the end of each quarter as follows:

[0000106040-24-000031:notes:157]
| Quarter ending | Leverage ratio |
| June 28, 2024 | 5.25 to 1.00 |
| September 27, 2024 | 5.00 to 1.00 |
| December 27, 2024 | 4.50 to 1.00 |
| March 28, 2025 | 4.00 to 1.00 |
| June 25, 2025 | 3.75 to 1.00 |
| Thereafter | 3.25 to 1.00 |

[0000106040-24-000031:notes:158]
For the purpose of the Leverage Ratio, Consolidated Adjusted EBITDA is calculated on a trailing twelve-month basis, except that for the quarters ended June 28, 2024 and September 27, 2024, Consolidated Adjusted EBITDA shall be (i) for the quarter ending June 28, 2024, Consolidated Adjusted EBITDA for such quarter and the immediately preceding quarter multiplied by two and (ii) for the quarter ending September 27, 2024, Consolidated Adjusted EBITDA for such quarter and the two immediately preceding quarters multiplied by four-thirds.

[0000106040-24-000031:notes:159]
In addition, as of June 28, 2024, the Credit Agreement requires the Company and its subsidiaries to maintain minimum liquidity (defined as the sum of cash and cash equivalents plus available unused capacity under its 2027 Revolving Facility less the aggregate principal amount of indebtedness that matures within 12 months of such date) of $2.00 billion at the end of each quarter through September 27, 2024. As of June 28, 2024, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-24-000031:notes:160]
The Credit Agreement also requires the Company to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolution, asset sales, dividends and distribution, and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements.

[0000106040-24-000031:notes:161]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an interest rate of Adjusted Term SOFR plus 1.500%. The annualized interest rate for Term Loan A-2 as of June 28, 2024 was 6.942%. During the year ending June 28, 2024, the Company made scheduled payments aggregating $113 million on its Term Loan A-2. As of June 28, 2024, the remaining balance of Term Loan A-2 amortizes in quarterly installments of $38 million per quarter beginning with the quarter ending September 27, 2024, and the remaining balance is payable at maturity on January 7, 2027. Issuance costs for Term Loan A-2 are amortized to Interest expense over its term and unamortized costs were $9 million as of June 28, 2024.

[0000106040-24-000031:notes:162]
During the year ended June 28, 2024, the Company drew and repaid $800 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”).

[0000106040-24-000031:notes:163]
The Company has issued standby letters of credit of $33 million as of June 28, 2024, which reduced the Company’s 2027 Revolving Facility’s capacity by the same amount to $2.22 billion as of that date.

[0000106040-24-000031:notes:164]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an interest rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

[0000106040-24-000031:notes:165]
Under the term of the Credit Agreement, the 2027 Revolving Facility and Term Loan A-2 (the “Credit Facilities”) are unconditionally guaranteed by Western Digital Technologies, Inc., Sandisk Technologies, Inc. and Sandisk Corporation (the “Guarantors”) and are secured on a first-priority basis (subject to permitted liens) by a lien on substantially all assets and properties of the Company and the Guarantors (the “Collateral”), subject to certain exceptions. Furthermore, the obligations under the Company’s 2.850% Senior Notes due 2029 and 3.100% Senior Notes due 2032 have been secured by the Collateral on an equal and ratable basis to the obligations under the Credit Facilities for so long as and to the extent required under the terms of the Indenture, and the obligations under the Company’s 2026 Senior Unsecured Notes have been guaranteed by the Guarantors pursuant to the First Supplemental Indenture dated as of June 20, 2023 and the Second Supplemental Indenture dated as of April 26, 2024 (the “2026 Senior Notes Supplemental Indentures”) for so long as and to the extent required under the terms of the indenture governing such notes and the 2026 Senior Notes Supplemental Indentures.

[0000106040-24-000031:notes:166]
In August 2023, the Company drew $600 million under a delayed draw term loan agreement, which was repaid in full in June 2024. That delayed draw term loan agreement is now terminated. Borrowings under that delayed draw term loan agreement bore interest, at a rate based on SOFR Rate plus an applicable margin.

[0000106040-24-000031:notes:167]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior notes due February 1, 2029 (the “2029 Senior Notes”) and issued $500 million aggregate principal amount of 3.100% senior notes due February 1, 2032 (the “2032 Senior Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Senior Notes Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “Senior Notes First Supplemental Indenture”) between the Company and the Senior Notes Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the Senior Notes First Supplemental Indenture. Interest for both the 2029 Senior Notes and 2032 Senior Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Senior Notes or 2032 Senior Notes prior to their maturity dates.

[0000106040-24-000031:notes:168]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. Issuance costs for the 2026 Senior Unsecured Notes are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of June 28, 2024, issuance costs of $4 million remained unamortized.

[0000106040-24-000031:notes:169]
The indentures and supplemental indentures, as applicable, governing the Company’s 2029 Senior Notes, 2032 Senior Notes, 2026 Senior Unsecured Notes and the 2028 Convertible Notes each contain various restrictive covenants, which can include limitations on the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness, and are subject to a number of limitations and exceptions.

[0000106040-24-000031:notes:170]
Maturity of Debt

[0000106040-24-000031:notes:171]
As of June 28, 2024, the Company is subject to required principal payment or earlier conversion at the option of the holder as follows:

[0000106040-24-000031:notes:172]
|  |  | Contractual Maturity (1) |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2025 |  | $ | 1,750 |  |
| 2026 |  | 2,450 |  |
| 2027 |  | 2,288 |  |
| 2028 |  | — |  |
| 2029 |  | 500 |  |
| 2030 and thereafter |  | 500 |  |
| Total debt maturities |  | 7,488 |  |
| Issuance costs |  | (54) |  |
| Net carrying value |  | $ | 7,434 |  |

[0000106040-24-000031:notes:173]
(1)    As of June 28, 2024, the holders of the 2028 Convertible Notes have the option to convert the notes through September 30, 2024. As such, the principal portion of these notes is reflected as current in the table above.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-24-000031:notes:174]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand and the Philippines (the “Pension Plans”). All other pension and other post-retirement benefit plans are immaterial to the Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans’ assets is 2.5%.

[0000106040-24-000031:notes:175]
Obligations and Funded Status

[0000106040-24-000031:notes:176]
The following table presents the unfunded status of the benefit obligations for the Pension Plans:

[0000106040-24-000031:notes:177]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 273 |  |  | $ | 294 |  |  | $ | 359 |  |
| Service cost | 9 |  |  | 14 |  |  | 15 |  |
| Interest cost | 6 |  |  | 6 |  |  | 5 |  |
| Plan amendments | — |  |  | — |  |  | 9 |  |
| Actuarial gain | (17) |  |  | (6) |  |  | (31) |  |
| Benefits paid | (7) |  |  | (8) |  |  | (9) |  |
| Settlement/curtailment | 2 |  |  | (15) |  |  | — |  |
| Non-U.S. currency movement | (22) |  |  | (12) |  |  | (54) |  |
| Projected benefit obligation at end of period | 244 |  |  | 273 |  |  | 294 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 185 |  |  | 189 |  |  | 227 |  |
| Actual return on plan assets | 12 |  |  | 7 |  |  | — |  |
| Employer contributions | 13 |  |  | 9 |  |  | 10 |  |
| Benefits paid | (7) |  |  | (8) |  |  | (7) |  |
| Non-U.S. currency movement | (19) |  |  | (12) |  |  | (41) |  |
| Fair value of plan assets at end of period | 184 |  |  | 185 |  |  | 189 |  |
| Unfunded status | $ | 60 |  |  | $ | 88 |  |  | $ | 105 |  |

[0000106040-24-000031:notes:178]
The following table presents the unfunded amounts related to the Pension Plans as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-24-000031:notes:179]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 59 |  |  | 87 |  |
| Net amount recognized | $ | 60 |  |  | $ | 88 |  |

[0000106040-24-000031:notes:180]
The accumulated benefit obligation for the Pension Plans was $244 million at June 28, 2024. As of June 28, 2024, the accumulated other income pension balance was $23 million. There were no material prior service credits for the Pension Plans recognized in Accumulated other comprehensive income (loss) in the Consolidated Balance Sheet as of June 28, 2024.

[0000106040-24-000031:notes:181]
Net periodic benefit costs were not material for 2024, 2023 and 2022.

[0000106040-24-000031:notes:182]
Assumptions

[0000106040-24-000031:notes:183]
Weighted-Average Assumptions

[0000106040-24-000031:notes:184]
The weighted-average actuarial assumptions used to determine the projected benefit obligations for the Pension Plans were as follows:

[0000106040-24-000031:notes:185]
|  | 2024 |  | 2023 |  | 2022 |
| Discount rate | 3.0 | % |  | 2.2 | % |  | 2.3 | % |
| Rate of compensation increase | 2.7 | % |  | 2.4 | % |  | 2.3 | % |

[0000106040-24-000031:notes:186]
The weighted-average actuarial assumptions used to determine benefit costs for the Pension Plans were as follows:

[0000106040-24-000031:notes:187]
|  | 2024 |  | 2023 |  | 2022 |
| Discount rate | 2.2 | % |  | 2.3 | % |  | 1.4 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 2.4 | % |  | 2.3 | % |  | 2.0 | % |

[0000106040-24-000031:notes:188]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management then matches the benefit payments to high quality bonds which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-24-000031:notes:189]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in each plan as well as the investment portfolio applicable to the plan depending on each plan’s economic environment. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates. As of June 28, 2024, the Pension Plans’ assets materially consisted of plan assets related to the Japan pension plan and as such the assumption used herein is primarily related to the Japan pension plan.

[0000106040-24-000031:notes:190]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-24-000031:notes:191]
Plan Assets

[0000106040-24-000031:notes:192]
Investment Policies and Strategies

[0000106040-24-000031:notes:193]
The investment policy in the Pension Plans is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 55% in debt securities, 30% in equity securities, and the remaining 15% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-24-000031:notes:194]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-24-000031:notes:195]
Fair Value Measurements

[0000106040-24-000031:notes:196]
The following tables present the Pension Plans’ major asset categories and their associated fair values and net asset values as of June 28, 2024 and June 30, 2023:

[0000106040-24-000031:notes:197]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 58 |  |  | $ | — |  |  | $ | 58 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Net plan assets subject to leveling | — |  |  | 157 |  |  | — |  |  | 157 |  |
| Real estate investment trust at net asset value |  |  |  |  |  |  | 27 |  |
| Total investments at fair value | $ | — |  |  | $ | 157 |  |  | $ | — |  |  | $ | 184 |  |

[0000106040-24-000031:notes:198]
|  | June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Net plan assets subject to leveling | — |  |  | 155 |  |  | — |  |  | 155 |  |
| Real estate investment trust at net asset value |  |  |  |  |  |  | 30 |  |
| Total investments at fair value | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 185 |  |

[0000106040-24-000031:notes:199]
(1)    Commingled funds represent pooled institutional investments.

[0000106040-24-000031:notes:200]
(2)    Equity mutual funds invest primarily in equity securities.

[0000106040-24-000031:notes:201]
(3)    Fixed income mutual funds invest primarily in fixed income securities.

[0000106040-24-000031:notes:202]
There were no significant movements of assets between any level categories in 2024 or 2023.

[0000106040-24-000031:notes:203]
Fair Value Valuation Techniques

[0000106040-24-000031:notes:204]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-24-000031:notes:205]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics and is generally classified as Level 2.

[0000106040-24-000031:notes:206]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-24-000031:notes:207]
Cash Flows

[0000106040-24-000031:notes:208]
The Company’s expected employer contributions for 2025 and annual benefit payments over the next five years for its Pension Plans are not expected to be material.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0000106040-24-000031:notes:209]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-24-000031:notes:210]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and Kioxia has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Kioxia collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by Kioxia at its wafer fabrication facilities located in Japan using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from Kioxia at cost and then resells those wafers to the Company and Kioxia at cost plus a markup.

[0000106040-24-000031:notes:211]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of Kioxia’s “Y3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-24-000031:notes:212]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of Kioxia’s “Y4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-24-000031:notes:213]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of Kioxia’s “Y5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Y5 was built in two phases of approximately equal size.

[0000106040-24-000031:notes:214]
New Y2. The Company has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “New Y2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Y2 primarily provided additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Y2 started in 2016.

[0000106040-24-000031:notes:215]
Y6. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “Y6” 300-millimeter wafer fabrication facility in Yokkaichi, Japan. Y6 is primarily intended to provide clean room space to continue the transition of existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. Production of flash-based wafers in Y6 started in 2018.

[0000106040-24-000031:notes:216]
K1. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Production of flash-based wafers in K1 started in 2019.

[0000106040-24-000031:notes:217]
Y7. In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. Production of flash-based wafers in Y7 started in 2022.

[0000106040-24-000031:notes:218]
K2. In June 2024, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility in Kitakami, Japan, referred to as “K2”. The primary purpose of K2 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. Output from K2 is expected to begin in the first half of fiscal year 2026.

[0000106040-24-000031:notes:219]
In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of June 28, 2024, $523 million remain to be credited against future building depreciation charges. As of June 28, 2024, the Company is also committed to make additional building depreciation prepayments of $610 million, based on Japanese yen to U.S. dollars exchange rate of 160.44 as of such date, payable as follows: $372 million in fiscal year 2025, $29 million in fiscal year 2026, $109 million in fiscal year 2027, $87 million in fiscal year 2028 and $13 million in fiscal year 2029. As of June 28, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $290 million at varying dates through fiscal year 2035.

[0000106040-24-000031:notes:220]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-24-000031:notes:221]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of June 28, 2024 and June 30, 2023:

[0000106040-24-000031:notes:222]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 1 |  |  | $ | 37 |  |
| Notes receivable, Flash Alliance | 5 |  |  | 48 |  |
| Notes receivable, Flash Forward | 485 |  |  | 709 |  |
| Investment in Flash Partners | 149 |  |  | 161 |  |
| Investment in Flash Alliance | 216 |  |  | 276 |  |
| Investment in Flash Forward | 135 |  |  | 179 |  |
| Total notes receivable and investments in Flash Ventures | $ | 991 |  |  | $ | 1,410 |  |

[0000106040-24-000031:notes:223]
During 2024, 2023 and 2022, the Company made net payments to Flash Ventures of $3.35 billion, $4.20 billion and $4.70 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-24-000031:notes:224]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-24-000031:notes:225]
As of June 28, 2024 and June 30, 2023, the Company had Accounts payable balances due to Flash Ventures of $313 million and $292 million, respectively.

[0000106040-24-000031:notes:226]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 28, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-24-000031:notes:227]
|  | June 28,2024 |
|  | (in millions) |
| Notes receivable | $ | 491 |  |
| Equity investments | 500 |  |
| Operating lease guarantees | 1,299 |  |
| Inventory and prepayments | 1,069 |  |
| Maximum estimable loss exposure | $ | 3,359 |  |

[0000106040-24-000031:notes:228]
As of June 28, 2024 and June 30, 2023, the Company’s retained earnings included cumulative undistributed earnings of Flash Ventures of $158 million and $219 million, respectively.

[0000106040-24-000031:notes:229]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers.  In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is also committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-24-000031:notes:230]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2024 and 2023, as a result of flash business conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. In 2024 and 2023, the Company incurred costs of $249 million and $286 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue.

[0000106040-24-000031:notes:231]
In February 2022, contamination of certain material used in manufacturing processes occurred at Flash Ventures’ fabrication facilities in both Yokkaichi and Kitakami, Japan which resulted in damage to inventory units in production, a temporary disruption to production operations and a reduction in the Company’s flash wafer availability. During 2022, the Company incurred charges of $207 million related to this contamination incident that were recorded in Cost of revenue and primarily consisted of scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, as well as charges for under absorption of overhead costs. During 2024, the Company received a recovery of $36 million related to this incident from its insurance carriers, which was recorded in Cost of revenue. The Company continues to pursue recovery of its remaining losses associated with this event; however, the total amount of recovery cannot be estimated at this time.

[0000106040-24-000031:notes:232]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-24-000031:notes:233]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-24-000031:notes:234]
Off-Balance Sheet Liabilities

[0000106040-24-000031:notes:235]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-24-000031:notes:236]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 28, 2024.

[0000106040-24-000031:notes:237]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 208,382 |  |  | $ | 1,299 |  |

[0000106040-24-000031:notes:238]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of June 28, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 28, 2024:

[0000106040-24-000031:notes:239]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| 2025 |  | $ | 285 |  |  | $ | 74 |  |  | $ | 359 |  |
| 2026 |  | 359 |  |  | 111 |  |  | 470 |  |
| 2027 |  | 164 |  |  | 95 |  |  | 259 |  |
| 2028 |  | 58 |  |  | 92 |  |  | 150 |  |
| 2029 |  | 11 |  |  | 50 |  |  | 61 |  |
| Total guarantee obligations |  | $ | 877 |  |  | $ | 422 |  |  | $ | 1,299 |  |

[0000106040-24-000031:notes:240]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of June 28, 2024, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-24-000031:notes:241]
Unis Venture

[0000106040-24-000031:notes:242]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the years ended June 28, 2024, June 30, 2023 and July 1, 2022, the Company recognized approximately 3%, 3% and 4% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from the Unis Venture were 7% and 8% of Accounts receivable, net as of June 28, 2024 and June 30, 2023, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-24-000031:notes:243]
Leases and Other Commitments 
Leases

[0000106040-24-000031:notes:244]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2039. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term.

[0000106040-24-000031:notes:245]
The following table presents right-of-use lease assets and lease liabilities included in the Company’s Consolidated Balance Sheets:

[0000106040-24-000031:notes:246]
|  | June 28,2024 |  | June 30,2023 |  |  |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 326 |  |  | $ | 260 |  |  |  |
| Operating lease liabilities: |  |  |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 42 |  |  | 40 |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | 307 |  |  | 244 |  |  |  |
| Total operating lease liabilities | $ | 349 |  |  | $ | 284 |  |  |  |

[0000106040-24-000031:notes:247]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases:

[0000106040-24-000031:notes:248]
|  |  |  | June 28,2024 |  |  |  | June 30,2023 |  | July 1,2022 |
|  |  |  | (in millions) |
| Cost of operating leases |  |  | $ | 64 |  |  |  |  | $ | 57 |  |  | $ | 58 |  |
| Cash paid for operating leases |  |  | 69 |  |  |  |  | 51 |  |  | 51 |  |
| Operating lease assets obtained in exchange for operating lease liabilities |  |  | 178 |  |  |  |  | 17 |  |  | 137 |  |
| Decrease in operating lease liabilities and right-of-use assets due to lease remeasurement |  |  | 71 |  |  |  |  | — |  |  | — |  |

[0000106040-24-000031:notes:249]
The weighted average remaining lease term and discount rate for the Company’s operating leases were as follows:

[0000106040-24-000031:notes:250]
|  | 2024 |  | 2023 |  |  |
| Weighted average remaining lease term in years | 10.4 |  | 7.6 |  |  |
| Weighted average discount rate | 6.6 | % |  | 4.2 | % |  |  |

[0000106040-24-000031:notes:251]
As of June 28, 2024, minimum lease payments were as follows:

[0000106040-24-000031:notes:252]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| 2025 | $ | 60 |  |  |  |  |  |  |  |  |  |
| 2026 | 57 |  |  |  |  |  |  |  |  |  |
| 2027 | 50 |  |  |  |  |  |  |  |  |  |
| 2028 | 42 |  |  |  |  |  |  |  |  |  |
| 2029 | 36 |  |  |  |  |  |  |  |  |  |
| Thereafter | 254 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 499 |  |  |  |  |  |  |  |  |  |
| Less: imputed interest | 150 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 349 |  |  |  |  |  |  |  |  |  |

[0000106040-24-000031:notes:253]
Sale-Leaseback

[0000106040-24-000031:notes:254]
During the year ended June 28, 2024, the Company completed a sale and leaseback of its facility in Milpitas, California. The Company received net proceeds of $191 million in cash and recorded a gain of $85 million on the sale. In connection with the sale, the Company agreed to lease back the facility at an annual lease rate of $16 million for the first year, increasing by 3% per year thereafter through January 1, 2039. The lease includes three 5-year renewal options and one 4-year renewal option for the ability to extend through December 2057. The supplemental balance sheet information and supplemental disclosures of operating cost and cash flow information related to the lease are included in the tables above.

[0000106040-24-000031:notes:255]
Purchase Agreements and Other Commitments

[0000106040-24-000031:notes:256]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of June 28, 2024, the Company had the following minimum long-term commitments:

[0000106040-24-000031:notes:257]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2025 |  | $ | 172 |  |
| 2026 |  | 96 |  |
| 2027 |  | 59 |  |
| 2028 |  | 20 |  |
| 2029 |  | 20 |  |
| Thereafter |  | 110 |  |
| Total |  | $ | 477 |  |


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-24-000031:notes:258]
Western Digital Corporation 401(k) Plan 
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire. Eligible employees do not include individuals that are covered by a collective bargaining agreement, provide services as a consultant, interns, independent contractors, leased or temporary employees, or who otherwise are not treated as common-law employees.

[0000106040-24-000031:notes:259]
Eligible employees are able to contribute up to 85% of their eligible compensation on a combined pre-tax and Roth basis regardless of age, and 10% of their eligible compensation on an after-tax basis, all subject to Internal Revenue Service limitations. The Company may make a basic matching contribution equal to 50% of each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. Furthermore, the Company’s employer matching contributions vest immediately. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-24-000031:notes:260]
Effective February 18, 2023, the Company announced its decision to suspend its previous practice of matching contributions. The Company later resumed matching contributions effective January 1, 2024.

[0000106040-24-000031:notes:261]
For 2024, 2023 and 2022, the Company made Plan contributions of $13 million, $22 million and $36 million, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-24-000031:notes:262]
Shareholders’ Equity and Convertible Preferred Stock
2021 Long-Term Incentive Plan

[0000106040-24-000031:notes:263]
In November 2021, stockholders approved the Western Digital Corporation 2021 Long-Term Incentive Plan, (as amended and restated, the “2021 Plan”). Upon the effective date of the 2021 Plan, no new awards were granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (the “2017 Plan”). The types of awards that may be granted under the 2021 Plan include stock options, stock appreciation rights (“SARs”), RSUs, PSUs, restricted stock and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash awards. Persons eligible to receive awards under the 2021 Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2021 Plan and the 2017 Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs is ten years after the grant date of the award. RSUs typically vest over periods ranging from two to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance conditions or market conditions and completion of requisite service periods. Once the performance conditions or market conditions are met, the employee’s vesting of PSUs is generally subject to continued service.

[0000106040-24-000031:notes:264]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-24-000031:notes:265]
As of June 28, 2024, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2021 Plan was 21.3 million shares. The 2021 Plan will terminate on November 22, 2031, unless terminated earlier by the Company’s Board of Directors.

[0000106040-24-000031:notes:266]
Employee Stock Purchase Plan

[0000106040-24-000031:notes:267]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock either at the beginning of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-24-000031:notes:268]
During 2024, 2023 and 2022, the Company issued 2.4 million, 2.7 million and 2.1 million shares, respectively, under the ESPP for aggregate purchase amounts of $81 million, $92 million and $113 million, respectively.

[0000106040-24-000031:notes:269]
To the extent available, the Company may issue shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-24-000031:notes:270]
Stock-based Compensation Expense

[0000106040-24-000031:notes:271]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-24-000031:notes:272]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| RSUs and PSUs |  |  |  |  | $ | 262 |  |  | $ | 283 |  |  | $ | 286 |  |
| ESPP |  |  |  |  | 33 |  |  | 35 |  |  | 40 |  |
| Total |  |  |  |  | $ | 295 |  |  | $ | 318 |  |  | $ | 326 |  |

[0000106040-24-000031:notes:273]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| Cost of revenue |  |  |  |  | $ | 49 |  |  | $ | 49 |  |  | $ | 48 |  |
| Research and development |  |  |  |  | 133 |  |  | 152 |  |  | 167 |  |
| Selling, general and administrative |  |  |  |  | 113 |  |  | 117 |  |  | 111 |  |
| Subtotal |  |  |  |  | 295 |  |  | 318 |  |  | 326 |  |
| Tax benefit |  |  |  |  | (41) |  |  | (43) |  |  | (48) |  |
| Total |  |  |  |  | $ | 254 |  |  | $ | 275 |  |  | $ | 278 |  |

[0000106040-24-000031:notes:274]
Any shortfalls or excess windfall tax benefits related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-24-000031:notes:275]
Compensation cost related to unvested RSUs, PSUs and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 28, 2024:

[0000106040-24-000031:notes:276]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 442 |  |  | 2.2 |
| ESPP | 23 |  |  | 0.5 |
| Total unamortized compensation cost | $ | 465 |  |  |  |

[0000106040-24-000031:notes:277]
(1)    Weighted average service period assumes the performance conditions are met for the PSUs.

[0000106040-24-000031:notes:278]
Plan Activities

[0000106040-24-000031:notes:279]
Stock Options

[0000106040-24-000031:notes:280]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-24-000031:notes:281]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 2, 2021 | 1.5 |  |  | $ | 72.84 |  |  |  |  |  |
| Exercised | (0.2) |  |  | 43.80 |  |  |  |  | $ | 3 |  |
| Canceled or expired | (0.4) |  |  | 97.65 |  |  |  |  |  |
| Options outstanding at July 1, 2022 | 0.9 |  |  | 66.76 |  |  |  |  |  |
| Canceled or expired | (0.6) |  |  | 80.72 |  |  |  |  |  |
| Options outstanding at June 30, 2023 | 0.3 |  |  | 44.95 |  |  | 0.10 |  |  |
| Canceled or expired | (0.3) |  |  | 44.95 |  |  |  |  |  |
| Options outstanding at June 28, 2024 | — |  |  | $ | — |  |  |  |  |  |

[0000106040-24-000031:notes:282]
No options were granted in 2024, 2023 or 2022. As of June 28, 2024, there were no remaining outstanding options.

[0000106040-24-000031:notes:283]
RSUs and PSUs

[0000106040-24-000031:notes:284]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-24-000031:notes:285]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | $ | 50.12 |  |  |  |
| Granted | 6.9 |  |  | 60.00 |  |  |  |
| Vested | (5.2) |  |  | 54.27 |  |  | $ | 317 |  |
| Forfeited | (2.4) |  |  | 52.14 |  |  |  |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | 52.89 |  |  |  |
| Granted | 6.6 |  |  | 41.27 |  |  |  |
| Vested | (6.6) |  |  | 54.05 |  |  | $ | 274 |  |
| Forfeited | (1.6) |  |  | 54.56 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | 46.56 |  |  |  |
| Granted | 6.6 |  |  | 42.29 |  |  |  |
| Vested | (5.8) |  |  | 48.26 |  |  | $ | 297 |  |
| Forfeited | (1.6) |  |  | 45.62 |  |  |  |
| RSUs and PSUs outstanding at June 28, 2024 | 13.0 |  |  | $ | 44.42 |  |  |  |

[0000106040-24-000031:notes:286]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-24-000031:notes:287]
Fair Value Valuation Assumptions

[0000106040-24-000031:notes:288]
RSU and PSU Grants

[0000106040-24-000031:notes:289]
The fair value of the Company’s RSU and PSU awards with a performance condition is determined based upon the closing price of the Company’s stock price on the date of grant. The fair value of PSU awards with a market condition is estimated using a Monte Carlo simulation model on the date of grant.

[0000106040-24-000031:notes:290]
ESPP – Black-Scholes-Merton Model

[0000106040-24-000031:notes:291]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option pricing model. The Black-Scholes-Merton option pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-24-000031:notes:292]
The fair values of ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option pricing model with the following weighted average assumptions:

[0000106040-24-000031:notes:293]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
| Weighted-average expected term (in years) |  |  |  |  | 1.25 |  | 1.25 |  | 1.25 |
| Risk-free interest rate |  |  |  |  | 4.93% |  | 4.52% |  | 1.42% |
| Stock price volatility |  |  |  |  | 0.39 |  | 0.46 |  | 0.48 |
| Dividend yield |  |  |  |  | —% |  | —% |  | —% |
| Fair value |  |  |  |  | $15.08 |  | $9.70 |  | $15.56 |

[0000106040-24-000031:notes:294]
Convertible Preferred Stock

[0000106040-24-000031:notes:295]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million. During the year ended June 28, 2024, 665,000 of the Preferred Shares were converted into approximately 15 million shares of common stock in accordance with the original term of the agreement. As of June 28, 2024 and June 30, 2023, 235,000 and 900,000 of the Preferred Shares were outstanding, respectively.

[0000106040-24-000031:notes:296]
Dividend provisions

[0000106040-24-000031:notes:297]
The Preferred Shares have a stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. No dividends have been declared or paid since the issuance of the Preferred Shares. As of June 28, 2024 and June 30, 2023, unpaid and undeclared cumulative dividends payable with respect to the Preferred Shares were $22 million and $24 million, respectively.

[0000106040-24-000031:notes:298]
During the year ended June 28, 2024, $56 million in unpaid and undeclared cumulative dividends payable were included in the aggregate liquidation preference of the 665,000 of the Preferred Shares that were converted into approximately 15 million shares of common stock, as noted above.

[0000106040-24-000031:notes:299]
Conversion rights

[0000106040-24-000031:notes:300]
The Preferred Shares are convertible into shares of the Company’s common stock at an initial conversion rate of $47.75 per share (the “Conversion Price”) (subject to anti-dilution adjustments and certain other one-time adjustments upon the occurrence of various specified spin-off transactions) applied to the aggregate sum of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the event of a standalone spin-off transaction, the holders of the Preferred Shares may have one third of their Preferred Shares converted to a similar class of preferred shares of the spin-off entity. The Preferred Shares will be convertible at the option of the Company after January 31, 2026 if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately prior to the Company’s conversion notice.

[0000106040-24-000031:notes:301]
As of June 28, 2024 and June 30, 2023, the Preferred Shares outstanding would have been convertible, if otherwise permitted, into 5 million and 19 million shares of common stock, respectively.

[0000106040-24-000031:notes:302]
Redemption

[0000106040-24-000031:notes:303]
After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares for an amount in cash equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares.

[0000106040-24-000031:notes:304]
The Preferred Shares has been classified as mezzanine equity in the Company’s Consolidated Balance Sheets because, in the event of certain fundamental change in the business that are not solely within the control of the Company, the Preferred Shares would become redeemable at the option of the holders. The Company did not adjust the carrying values of the Preferred Shares to the current redemption value of such shares since a liquidation event was not probable at any of the balance sheet dates. Subsequent adjustments to increase or decrease the carrying values to the ultimate redemption value will be made only if and when it becomes probable that such a fundamental change in the business will occur.

[0000106040-24-000031:notes:305]
Voting right

[0000106040-24-000031:notes:306]
The Preferred Shares will vote, to the extent permitted under the Nasdaq listing rules, on an as-converted equivalent basis along with holders of the Company’s common stock.

[0000106040-24-000031:notes:307]
Liquidation preference

[0000106040-24-000031:notes:308]
In the event of any voluntary or involuntary liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock and the liquidation preference is the greater of (i) the sum of an amount in cash equal to 110% of the Accumulated Stated Value plus accrued and unpaid dividends and (ii) the payment that the holders of the Preferred Shares would have received had all the Preferred Shares been converted into common stock immediately prior to such liquidation, before any distributions are made to common shareholders and all other classes of junior capital stock of the Company. As of June 28, 2024 and June 30, 2023, the total aggregate liquidation preference was $257 million and $924 million, respectively.

[0000106040-24-000031:notes:309]
Stock Reserved for Issuance

[0000106040-24-000031:notes:310]
The following table summarizes all common stock reserved for issuance at June 28, 2024:

[0000106040-24-000031:notes:311]
|  | Number of Shares |
|  | (in millions) |
| Convertible notes | 40 |  |
| Outstanding awards and shares available for award grants | 22 |  |
| Convertible preferred stock | 10 |  |
| ESPP | 5 |  |
| Total | 77 |  |

[0000106040-24-000031:notes:312]
Dividends to Shareholders
The Company issued a quarterly cash dividend from the first quarter of 2013 up to the third quarter of 2020. In April 2020, the Company suspended its dividend to reinvest in the business and to support its ongoing deleveraging efforts


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-24-000031:notes:313]
Income Tax Expense
Income (Loss) Before Taxes

[0000106040-24-000031:notes:314]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0000106040-24-000031:notes:315]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Foreign | $ | (351) |  |  | $ | (2,019) |  |  | $ | 1,432 |  |
| Domestic | (310) |  |  | 469 |  |  | 739 |  |
| Income (loss) before taxes | $ | (661) |  |  | $ | (1,550) |  |  | $ | 2,171 |  |

[0000106040-24-000031:notes:316]
Income Tax Expense

[0000106040-24-000031:notes:317]
The components of the income tax expense were as follows:

[0000106040-24-000031:notes:318]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 260 |  |  | $ | 153 |  |  | $ | 143 |  |
| Domestic - Federal | 34 |  |  | 35 |  |  | 341 |  |
| Domestic - State | 4 |  |  | (6) |  |  | 25 |  |
|  | 298 |  |  | 182 |  |  | 509 |  |
| Deferred: |  |  |  |  |  |
| Foreign | 13 |  |  | (6) |  |  | 29 |  |
| Domestic - Federal | (152) |  |  | (36) |  |  | 84 |  |
| Domestic - State | (22) |  |  | (6) |  |  | 3 |  |
|  | (161) |  |  | (48) |  |  | 116 |  |
| Income tax expense | $ | 137 |  |  | $ | 134 |  |  | $ | 625 |  |

[0000106040-24-000031:notes:319]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of 2019. However, the U.S. Treasury and the Internal Revenue Services (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-24-000031:notes:320]
On August 16, 2022, President Biden signed into law the Inflation Reduction Act of 2022, which contained significant law changes related to tax, climate, energy and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The corporate alternative minimum tax is effective for the Company beginning with 2024. The Company is not subject to the CAMT of 15% for fiscal year 2024 as its average annual AFSI did not exceed $1.00 billion for the preceding three-year period.

[0000106040-24-000031:notes:321]
Deferred Taxes

[0000106040-24-000031:notes:322]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-24-000031:notes:323]
|  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 66 |  |  | $ | 69 |  |
| Accrued compensation and benefits not currently deductible | 116 |  |  | 88 |  |
| Net operating loss carryforward | 175 |  |  | 183 |  |
| Business credit carryforward | 528 |  |  | 478 |  |
| Long-lived assets | 75 |  |  | 72 |  |
| Interest and hedging costs not currently deductible | 254 |  |  | 76 |  |
| Other | 59 |  |  | 71 |  |
| Total deferred tax assets | 1,273 |  |  | 1,037 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (46) |  |  | (57) |  |
| Unremitted earnings of certain non-U.S. entities | (286) |  |  | (291) |  |
| Other | (33) |  |  | (7) |  |
| Total deferred tax liabilities | (365) |  |  | (355) |  |
| Valuation allowances | (582) |  |  | (565) |  |
| Deferred tax assets, net | $ | 326 |  |  | $ | 117 |  |

[0000106040-24-000031:notes:324]
The increase in the deferred tax assets is attributable primarily to the IRS interest payments made in connection with the notice of deficiency received for years 2008 through 2011 that are not currently deductible under §163(j) of the Internal Revenue Code of 1986, as amended, and the unamortized original issue discount (“OID”) related to the premium paid to purchase Capped Calls in connection with the offering of the 2028 Convertible Notes. As described in Note 7, Debt, the deferred tax asset related to the unamortized OID was recorded as a decrease to Additional paid-in capital. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize its deferred tax assets except for certain loss and credit carryforwards.

[0000106040-24-000031:notes:325]
The Company is permanently reinvested with respect to certain foreign earnings. There is no unrecognized deferred tax liability associated with the repatriation of these foreign undistributed earnings as it can be achieved without additional federal tax consequences.

[0000106040-24-000031:notes:326]
Effective Tax Rate

[0000106040-24-000031:notes:327]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-24-000031:notes:328]
|  | 2024 |  | 2023 |  | 2022 |
| U.S. Federal statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| Tax rate differential on international income | (46) |  |  | (33) |  |  | (9) |  |
| Tax effect of U.S. foreign income inclusion | (2) |  |  | (1) |  |  | — |  |
| Tax effect of U.S. foreign minimum tax | — |  |  | — |  |  | 5 |  |
| Tax effect of U.S. foreign derived intangible income | 3 |  |  | 4 |  |  | (1) |  |
| Tax effect of U.S. non-deductible stock-based compensation | (1) |  |  | (1) |  |  | 1 |  |
| Tax effect of U.S. permanent differences | 1 |  |  | — |  |  | — |  |
| IRS Settlement | (1) |  |  | 1 |  |  | 15 |  |
| Change in valuation allowance | (3) |  |  | 1 |  |  | 1 |  |
| Unremitted earnings of certain non-U.S. entities | (4) |  |  | — |  |  | 1 |  |
| Foreign income tax credits | 1 |  |  | — |  |  | (3) |  |
| R&D tax credits | 8 |  |  | 5 |  |  | (4) |  |
| U.S. return to provision | — |  |  | (2) |  |  | — |  |
| Tax reserves | 1 |  |  | (1) |  |  | 2 |  |
| Other | 1 |  |  | (3) |  |  | — |  |
| Effective tax rate | (21) | % |  | (9) | % |  | 29 | % |

[0000106040-24-000031:notes:329]
Tax Holidays and Carryforwards

[0000106040-24-000031:notes:330]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines and Thailand operate under various tax holidays and tax incentive programs, which will expire in whole or in part at various dates during 2025 through 2031. Certain tax holidays and tax incentive programs may be extended if specific conditions are met. On November 1, 2023, one of the Company’s tax holidays in Malaysia expired. The Company has applied for an extension and anticipates this extension, if granted, will be applied retroactively and begin on November 2, 2023. Because the exact terms of the extension are not currently known, the Company is applying the Malaysia corporate statutory tax rate on the expired tax holiday income. If a retroactive extension is granted, the Company will make an adjustment to its effective tax rate in that period.

[0000106040-24-000031:notes:331]
The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $209 million, or $0.64 per diluted share, $140 million, or $0.44 per diluted share, and $566 million, or $1.79 per diluted share, in 2024, 2023 and 2022, respectively.

[0000106040-24-000031:notes:332]
As of June 28, 2024, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-24-000031:notes:333]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 578 |  |  | 2026 to 2038 |
| State NOL | 342 |  |  | 2037 to 2045 |
| Federal tax credits | 61 |  |  | 2025 to 2044 |
| State tax credits | 746 |  |  | No expiration |

[0000106040-24-000031:notes:334]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal and state NOLs ultimately realized will be reduced as a result of these provisions by $116 million and $240 million, respectively. The Company expects the total amount of federal and state credits ultimately realized will be reduced as a result of these provisions by $27 million and $2 million, respectively.

[0000106040-24-000031:notes:335]
As of June 28, 2024, the Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-24-000031:notes:336]
| Jurisdiction | NOL Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Belgium | $ | 114 |  |  | No expiration |
| Malaysia | 108 |  |  | 2028 to 2030 |
| Japan | 61 |  |  | 2025 to 2026 |
| Spain | 46 |  |  | No expiration |
| Netherlands | 12 |  |  | 2026 |

[0000106040-24-000031:notes:337]
Uncertain Tax Positions

[0000106040-24-000031:notes:338]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets.

[0000106040-24-000031:notes:339]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-24-000031:notes:340]
|  | 2024 |  | 2023 |  | 2022 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 1,021 |  |  | $ | 1,047 |  |  | $ | 748 |  |
| Gross increases related to current year tax positions | 25 |  |  | 7 |  |  | 12 |  |
| Gross increases related to prior year tax positions | 73 |  |  | 22 |  |  | 358 |  |
| Gross decreases related to prior year tax positions | (32) |  |  | (47) |  |  | (65) |  |
| Settlements | (363) |  |  | (5) |  |  | (1) |  |
| Lapse of statute of limitations | (3) |  |  | (3) |  |  | (5) |  |
| Unrecognized tax benefit, ending balance | $ | 721 |  |  | $ | 1,021 |  |  | $ | 1,047 |  |

[0000106040-24-000031:notes:341]
As of June 28, 2024, June 30, 2023 and July 1, 2022, the portion of the gross unrecognized tax benefits, if recognized, that would affect the effective tax rate is $555 million, $855 million and $903 million, respectively. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 28, 2024, June 30, 2023 and July 1, 2022 was $181 million, $289 million and $254 million, respectively. As of June 28, 2024, June 30, 2023 and July 1, 2022, the Company’s payables related to unrecognized tax benefits, including accrued interest and penalties, were $736 million, $1.14 billion and $1.16 billion, respectively. Of these amounts, the Company believes it is reasonably likely that payments of $185 million may be made within the next twelve months and have classified that portion of these unrecognized tax benefits, including interest, in Income taxes payable on the Consolidated Balance Sheets as of June 28, 2024. The remaining payables related to unrecognized tax benefits are included in Other liabilities on the Consolidated Balance Sheets as of June 28, 2024, June 30, 2023 and July 1, 2022.

[0000106040-24-000031:notes:342]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for 2016 through 2023. The Company is no longer subject to examination by the IRS for periods prior to 2016, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the following major foreign jurisdictions where there is no tax holiday, the Company could be subject to examination as noted below:

[0000106040-24-000031:notes:343]
| Jurisdiction |  | Period Subject to Examination |
| China (calendar) |  | 2014-2023 |
| Ireland (fiscal) |  | 2020-2023 |
| India (fiscal) |  | 2009-2023 |
| Israel (fiscal) |  | 2014-2023 |
| Japan (fiscal) |  | 2015-2023 |
| Malaysia (fiscal) |  | 2017-2023 |
| Thailand (fiscal) |  | 2014-2023 |
| Singapore (fiscal) |  | 2020-2023 |
| United Kingdom (fiscal) |  | 2022-2023 |

[0000106040-24-000031:notes:344]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During 2024, the Company made payments of $363 million for tax and $161 million for interest with respect to years 2008 through 2012 and recognized adjustments to align with IRS calculations, resulting in a remaining liability of $185 million related to all years from 2008 through 2015. The Company expects to pay any remaining balance with respect to this matter within the next twelve months.

[0000106040-24-000031:notes:345]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $165 million. Of this amount, $34 million of the interest savings from the interest paid with respect to years 2008 through 2012 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-24-000031:notes:346]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 28, 2024, with the exception of the final agreement with the IRS, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information relating to the examination of the Company’s tax returns.


## us-gaap:SummaryOfOperatingLossCarryforwardsTextBlock

[0000106040-24-000031:notes:347]
Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-24-000031:notes:348]
The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:


## us-gaap:EarningsPerShareTextBlock

[0000106040-24-000031:notes:349]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-24-000031:notes:350]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions, except per share data) |
| Net income (loss) |  |  |  |  | $ | (798) |  |  | $ | (1,684) |  |  | $ | 1,546 |  |
| Less: cumulative dividends allocated to preferred shareholders |  |  |  |  | 54 |  |  | 24 |  |  | — |  |
| Net income (loss) attributable to common shareholders |  |  |  |  | $ | (852) |  |  | $ | (1,708) |  |  | $ | 1,546 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 326 |  |  | 318 |  |  | 312 |  |
| Employee stock options, RSUs, PSUs and ESPP |  |  |  |  | — |  |  | — |  |  | 4 |  |
| Diluted |  |  |  |  | 326 |  |  | 318 |  |  | 316 |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | (2.61) |  |  | $ | (5.37) |  |  | $ | 4.96 |  |
| Diluted |  |  |  |  | $ | (2.61) |  |  | $ | (5.37) |  |  | $ | 4.89 |  |
| Anti-dilutive potential common shares excluded |  |  |  |  | 22 |  |  | 14 |  |  | 3 |  |

[0000106040-24-000031:notes:351]
Basic income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income (loss) per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The "if-converted" method is used to determine the dilutive impact for the convertible notes and the Preferred Shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-24-000031:notes:352]
For 2024 and 2023, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for the period because their impact would have been anti-dilutive. For 2022, the Company excluded common shares subject to certain outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during those periods.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-24-000031:notes:353]
Employee Termination, Asset Impairment, and Other
Business Realignment

[0000106040-24-000031:notes:354]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. In this regard, in 2024, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress, other assets and the recognition of a liability for certain contract termination costs. The Company has also taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California in 2024.

[0000106040-24-000031:notes:355]
The Company recorded the following charges related to these actions:

[0000106040-24-000031:notes:356]
|  |  |  |  |  | 2024 |  | 2023 |  | 2022 |
|  |  |  |  |  | (in millions) |
| Employee termination benefits |  |  |  |  | $ | 44 |  |  | $ | 176 |  |  | $ | 50 |  |
| Asset impairments |  |  |  |  | 146 |  |  | 20 |  |  | — |  |
| Other charges (gains): |  |  |  |  |  |  |  |  |  |
| Gain on disposition of assets and other charges |  |  |  |  | — |  |  | (8) |  |  | (7) |  |
| Contract termination and other |  |  |  |  | 34 |  |  | 5 |  |  | — |  |
| Gain on sale-leaseback of facility |  |  |  |  | (85) |  |  | — |  |  | — |  |
| Total employee termination, asset impairment, and other |  |  |  |  | $ | 139 |  |  | $ | 193 |  |  | $ | 43 |  |

[0000106040-24-000031:notes:357]
The following table presents an analysis of the components of these activities against the reserve during the year ended June 28, 2024:

[0000106040-24-000031:notes:358]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 30, 2023 | $ | 31 |  |  | $ | 5 |  |  | $ | 36 |  |
| Charges | 44 |  |  | 34 |  |  | 78 |  |
| Cash payments | (75) |  |  | (11) |  |  | (86) |  |
| Accrual balance at June 28, 2024 | $ | — |  |  | $ | 28 |  |  | $ | 28 |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-24-000031:notes:359]
Supplier Finance Program
The Company maintains a voluntary supplier finance program that provides participating suppliers with enhanced receivable options. The program allows participating suppliers of the Company, at their sole discretion and cost, to sell their receivables due from the Company to a third-party financial institution and receive early payment at terms negotiated between the supplier and the third-party financial institution. The Company’s vendor payment terms and amounts are not impacted by a supplier’s decision to participate in this program.

[0000106040-24-000031:notes:360]
The Company’s current payment terms with its suppliers under these programs generally range from 60 to 90 days and payment terms that the Company negotiates with its suppliers are not impacted by whether a supplier participates in the program. The Company does not provide any guarantees to any third parties and no assets are pledged in connection with the arrangements.

[0000106040-24-000031:notes:361]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $37 million and $38 million as of  June 28, 2024 and June 30, 2023, respectively, and are included within Accounts payable on the Company’s Consolidated Balance Sheets.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-24-000031:notes:362]
Legal Proceedings
Tax

[0000106040-24-000031:notes:363]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, and the status of resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-24-000031:notes:364]
Intellectual Property Litigation

[0000106040-24-000031:notes:365]
Unless otherwise stated, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-24-000031:notes:366]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial on the remaining two patents (together, the “MRT Patents”). The trial commenced on July 16, 2024 and concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. We anticipate that MRT will also request costs, attorney’s fees and post-judgment interest. The Company has recognized an aggregate liability for this matter of $384 million within Accrued expenses on the Company’s Consolidated Balance Sheets as of June 28, 2024. Of this amount, $291 million was recognized as Litigation matter under Operating expenses on the Company’s Consolidated Statements of Operations for the year ended June 28, 2024 and $93 million recognized within Other non-current assets on the Company’s Consolidated Balance Sheets as of June 28, 2024, to be amortized over the remaining lives of the MRT Patents. The Company believes it has meritorious defenses, plans to file post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

[0000106040-24-000031:notes:367]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to three claims under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. Trial is scheduled to commence on October 8, 2024, and the Company intends to defend itself vigorously.

[0000106040-24-000031:notes:368]
Other Matters

[0000106040-24-000031:notes:369]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.


## us-gaap:ErrorCorrectionTextBlock

[0000106040-24-000031:notes:370]
Revision of Previously Issued Financial Statements
As described in Note 1, in connection with the preparation of its Condensed Consolidated Financial Statements as of and for the three and six months ended December 29, 2023, the Company identified certain errors related to the Company’s reporting and recording of its interests in its equity method investments in Flash Ventures. These errors related to unadjusted differences between the Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the Company in Other income (expense), net and the carrying value of the Company’s equity method investments in Flash Ventures.

[0000106040-24-000031:notes:371]
The following tables provide a summary of the revisions made to the Company’s Condensed Consolidated Financial Statements for the periods presented.

[0000106040-24-000031:notes:372]
|  |  | Year Ended July 1, 2022 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating income |  | $ | 2,391 |  |  | $ | — |  |  | $ | 2,391 |  |
| Interest and other income: |  |  |  |  |  |  |
| Interest income |  | 6 |  |  | — |  |  | 6 |  |
| Interest expense |  | (304) |  |  | — |  |  | (304) |  |
| Other income, net |  | 30 |  |  | 48 |  |  | 78 |  |
| Total interest and other income, net |  | (268) |  |  | 48 |  |  | (220) |  |
| Income before taxes |  | 2,123 |  |  | 48 |  |  | 2,171 |  |
| Income tax expense |  | 623 |  |  | 2 |  |  | 625 |  |
| Net income |  | $ | 1,500 |  |  | $ | 46 |  |  | $ | 1,546 |  |
| Net income per common share: |  |  |  |  |  |  |
| Basic |  | $ | 4.81 |  |  | $ | 0.15 |  |  | $ | 4.96 |  |
| Diluted |  | $ | 4.75 |  |  | $ | 0.14 |  |  | $ | 4.89 |  |

[0000106040-24-000031:notes:373]
|  |  | Year Ended June 30, 2023 |
| Condensed Consolidated Statement of Operations |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions, except per share amounts) |
| Operating loss |  | $ | (1,285) |  |  | $ | — |  |  | $ | (1,285) |  |
| Interest and other income: |  |  |  |  |  |  |
| Interest income |  | 24 |  |  | — |  |  | 24 |  |
| Interest expense |  | (312) |  |  | — |  |  | (312) |  |
| Other income, net |  | 13 |  |  | 10 |  |  | 23 |  |
| Total interest and other income, net |  | (275) |  |  | 10 |  |  | (265) |  |
| Loss before taxes |  | (1,560) |  |  | 10 |  |  | (1,550) |  |
| Income tax expense |  | 146 |  |  | (12) |  |  | 134 |  |
| Net loss |  | (1,706) |  |  | 22 |  |  | (1,684) |  |
| Less: cumulative dividends allocated to preferred shareholders |  | 24 |  |  | — |  |  | 24 |  |
| Net loss attributable to common shareholders |  | $ | (1,730) |  |  | $ | 22 |  |  | $ | (1,708) |  |
| Net loss per common share: |  |  |  |  |  |  |
| Basic |  | $ | (5.44) |  |  | $ | 0.07 |  |  | $ | (5.37) |  |
| Diluted |  | $ | (5.44) |  |  | $ | 0.07 |  |  | $ | (5.37) |  |

[0000106040-24-000031:notes:374]
|  |  | Year Ended July 1, 2022 |
| Condensed Consolidated Statement of Comprehensive Income |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net income |  | $ | 1,500 |  |  | $ | 46 |  |  | $ | 1,546 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |
| Actuarial pension gain |  | 26 |  |  | — |  |  | 26 |  |
| Foreign currency translation adjustment |  | (239) |  |  | (23) |  |  | (262) |  |
| Net unrealized loss on derivative contracts |  | (180) |  |  | — |  |  | (180) |  |
| Total other comprehensive loss, before tax |  | (393) |  |  | (23) |  |  | (416) |  |
| Income tax benefit related to items of other comprehensive loss, before tax |  | 36 |  |  | — |  |  | 36 |  |
| Other comprehensive loss, net of tax |  | (357) |  |  | (23) |  |  | (380) |  |
| Total comprehensive income |  | $ | 1,143 |  |  | $ | 23 |  |  | $ | 1,166 |  |

[0000106040-24-000031:notes:375]
|  |  | Year Ended June 30, 2023 |
| Condensed Consolidated Statement of Comprehensive Loss |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Net loss |  | $ | (1,706) |  |  | $ | 22 |  |  | $ | (1,684) |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |
| Actuarial pension gain |  | 12 |  |  | — |  |  | 12 |  |
| Foreign currency translation adjustment |  | (81) |  |  | (7) |  |  | (88) |  |
| Net unrealized gain on derivative contracts |  | 138 |  |  | — |  |  | 138 |  |
| Total other comprehensive income, before tax |  | 69 |  |  | (7) |  |  | 62 |  |
| Income tax expense related to items of other comprehensive income, before tax |  | (31) |  |  | — |  |  | (31) |  |
| Other comprehensive income, net of tax |  | 38 |  |  | (7) |  |  | 31 |  |
| Total comprehensive loss |  | $ | (1,668) |  |  | $ | 15 |  |  | $ | (1,653) |  |

[0000106040-24-000031:notes:376]
|  |  | Year Ended July 1, 2022 |
| Condensed Consolidated Statement of Cash Flows |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |
| Net income |  | $ | 1,500 |  |  | $ | 46 |  |  | $ | 1,546 |  |
| Deferred income taxes |  | 114 |  |  | 2 |  |  | 116 |  |
| Other non-cash operating activities, net |  | 67 |  |  | (48) |  |  | 19 |  |
| Other assets and liabilities, net |  | (349) |  |  | — |  |  | (349) |  |
| Net cash provided by operating activities |  | 1,880 |  |  | — |  |  | 1,880 |  |

[0000106040-24-000031:notes:377]
|  |  | Year Ended June 30, 2023 |
| Condensed Consolidated Statement of Cash Flows |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Cash flows from operating activities |  |  |  |  |  |  |
| Net loss |  | $ | (1,706) |  |  | $ | 22 |  |  | $ | (1,684) |  |
| Deferred income taxes |  | (34) |  |  | (14) |  |  | (48) |  |
| Other non-cash operating activities, net |  | 71 |  |  | (10) |  |  | 61 |  |
| Other assets and liabilities, net |  | (185) |  |  | 2 |  |  | (183) |  |
| Net cash used in operating activities |  | (408) |  |  | — |  |  | (408) |  |

[0000106040-24-000031:notes:378]
| Condensed Consolidated Statement of Shareholders’ Equity |  | As Previously Reported |  | Adjustment |  | As Revised |
|  |  | (in millions) |
| Retained earnings as of: |  |  |  |  |  |  |
| July 2, 2021 |  | $ | 7,539 |  |  | $ | 81 |  |  | $ | 7,620 |  |
| Accumulated other comprehensive loss as of: |  |  |  |  |  |  |
| July 2, 2021 |  | (197) |  |  | (2) |  |  | (199) |  |
| Foreign currency translation adjustment for the year ended June 30, 2023 |  | (80) |  |  | (7) |  |  | (87) |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000106040-24-000031:notes:379]
Kimberly E. Alexy, a director of the Company, adopted a Rule 10b5-1 Plan on May 24, 2024. Under this plan, beginning on August 23, 2024, up to an aggregate of 4,963 shares of the Company’s common stock may be sold before the plan expires on February 24, 2025.

[0000106040-24-000031:notes:380]
Matthew E. Massengill, a director of the Company, adopted a Rule 10b5-1 Plan on May 30, 2024. Under this plan, beginning on August 29, 2024, up to an aggregate of 23,593 shares of the Company’s common stock may be sold before the plan expires on December 6, 2024.

[0000106040-24-000031:notes:381]
David Goeckeler, Chief Executive Officer of the Company adopted a Rule 10b5-1 Plan on June 6, 2024. Under this plan, beginning on September 5, 2024, up to an aggregate of 300,000 shares of the Company’s common stock may be sold before the plan expires on December 31, 2024.
