# WDC 8-K — 0000106040-24-000026 filed 2024-07-31

## item codes, every 8-K on or before 2024-08-20

- 2024-07-31 0000106040-24-000026 — 2.02, 9.01
- 2024-05-24 0001193125-24-147062 — 5.02
- 2024-05-14 0001193125-24-138274 — 3.03, 5.03, 5.07, 9.01
- 2024-04-25 0000106040-24-000020 — 2.02, 9.01
- 2024-03-05 0001193125-24-059385 — 8.01, 9.01
- 2024-03-04 0001193125-24-056949 — 1.01, 8.01
- 2024-01-25 0000106040-24-000003 — 2.02, 9.01
- 2024-01-04 0001193125-24-002432 — 5.02
- 2023-12-26 0001193125-23-302249 — 8.01, 9.01
- 2023-11-17 0001193125-23-279782 — 5.02, 5.07, 9.01
- 2023-11-03 0001193125-23-270415 — 1.01, 2.03, 3.02, 9.01
- 2023-11-01 0001193125-23-267654 — 7.01, 9.01
- 2023-10-30 0001193125-23-266188 — 7.01, 9.01
- 2023-10-30 0001193125-23-265708 — 7.01, 9.01
- 2023-10-30 0000106040-23-000032 — 2.02, 9.01
- 2023-10-10 0001193125-23-253508 — 1.01, 9.01
- 2023-07-31 0000106040-23-000020 — 2.02, 5.02, 9.01
- 2023-06-21 0001193125-23-171211 — 1.01, 9.01
- 2023-05-08 0000106040-23-000014 — 2.02, 9.01
- 2023-05-05 0001193125-23-137241 — 8.01, 9.01
- 2023-04-03 0001193125-23-088802 — 8.01, 9.01
- 2023-02-07 0001193125-23-026907 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01 — amendment of 0001193125-23-020502
- 2023-02-01 0001193125-23-020502 — 1.01, 3.02, 5.02, 5.03, 7.01, 9.01
- 2023-01-31 0000106040-23-000006 — 1.01, 2.02, 2.03, 9.01
- 2022-12-23 0001193125-22-311796 — 1.01, 9.01
- 2022-11-18 0001193125-22-288992 — 5.02, 5.07, 9.01
- 2022-10-27 0000106040-22-000061 — 2.02, 9.01
- 2022-08-05 0000106040-22-000049 — 2.02, 9.01
- 2022-07-01 0001193125-22-187239 — 1.01, 9.01
- 2022-06-17 0001193125-22-176478 — 5.02, 9.01
- 2022-06-08 0001193125-22-169552 — 1.01, 7.01, 8.01, 9.01
- 2022-04-28 0000106040-22-000030 — 2.02, 9.01
- 2022-01-27 0001193125-22-019801 — 5.02, 7.01, 9.01
- 2022-01-27 0000106040-22-000010 — 2.02, 9.01
- 2022-01-07 0001193125-22-004434 — 1.01, 2.03, 7.01
- 2021-12-10 0001193125-21-353971 — 1.01, 2.03, 7.01, 8.01, 9.01
- 2021-12-06 0001193125-21-348304 — 7.01
- 2021-11-19 0001193125-21-335120 — 5.04, 9.01
- 2021-11-18 0001193125-21-332703 — 5.02
- 2021-10-28 0000106040-21-000046 — 2.02, 9.01
- 2021-08-04 0000106040-21-000032 — 2.02, 9.01
- 2021-07-08 0001193125-21-210370 — 5.02
- 2021-04-29 0000106040-21-000016 — 2.02, 9.01
- 2021-02-12 0001193125-21-041457 — 5.03, 9.01
- 2021-01-28 0000106040-21-000006 — 2.02, 9.01
- 2020-11-19 0001193125-20-298121 — 5.02, 5.07, 9.01
- 2020-10-28 0000106040-20-000054 — 2.02, 9.01
- 2020-08-17 0001193125-20-222434 — 5.02
- 2020-08-05 0000106040-20-000038 — 9.01
- 2020-06-23 0001193125-20-176152 — 5.02
- 2020-05-08 0001193125-20-137565 — 5.02
- 2020-04-30 0000106040-20-000017 — 2.02, 9.01
- 2020-04-03 0001193125-20-098162 — 5.02
- 2020-03-06 0001193125-20-065100 — 5.02, 7.01, 9.01
- 2020-01-30 0000106040-20-000005 — 2.02, 9.01
- 2019-11-14 0001193125-19-292358 — 5.02, 5.07, 9.01
- 2019-10-30 0001193125-19-278976 — 5.02, 7.01, 9.01
- 2019-10-30 0000106040-19-000067 — 2.02, 9.01
- 2019-08-08 0001193125-19-216911 — 5.02
- 2019-07-31 0000106040-19-000050 — 2.02, 9.01
- 2019-06-28 0001193125-19-184926 — 7.01, 9.01
- 2019-06-21 0001193125-19-178750 — 5.02
- 2019-06-07 0001193125-19-168168 — 5.02
- 2019-05-17 0001193125-19-149855 — 1.01, 7.01, 9.01
- 2019-04-29 0001193125-19-125124 — 1.01
- 2019-04-29 0000106040-19-000017 — 2.02, 9.01
- 2019-04-18 0001193125-19-109942 — 5.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045374 — 5.02
- 2019-02-15 0001193125-19-041754 — 5.02, 7.01, 9.01
- 2019-01-24 0001193125-19-015948 — 2.02, 9.01
- 2018-11-29 0001193125-18-338051 — 5.02
- 2018-11-27 0001193125-18-335186 — 5.02, 7.01, 9.01
- 2018-11-07 0001193125-18-320967 — 5.02, 5.07, 9.01
- 2018-10-25 0001193125-18-307751 — 2.02, 9.01
- 2018-08-28 0001193125-18-260645 — 5.02
- 2018-08-02 0001193125-18-235342 — 7.01, 9.01
- 2018-07-26 0001193125-18-227786 — 2.02, 9.01
- 2018-05-15 0001193125-18-164083 — 1.01, 2.03, 7.01, 9.01
- 2018-05-07 0001193125-18-153458 — 5.03, 8.01, 9.01
- 2018-05-03 0001193125-18-149119 — 7.01, 9.01
- 2018-04-26 0001193125-18-134881 — 2.02, 9.01
- 2018-03-21 0001193125-18-090680 — 5.07 — amendment of 0001193125-17-331827
- 2018-03-02 0001193125-18-069057 — 1.02, 3.03, 7.01, 9.01
- 2018-02-27 0001193125-18-061179 — 1.01, 2.03, 7.01, 9.01
- 2018-02-20 0001193125-18-049178 — 3.02
- 2018-02-13 0001193125-18-042423 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2018-02-02 0001193125-18-030964 — 8.01, 9.01
- 2018-01-31 0001193125-18-026287 — 7.01, 9.01
- 2018-01-30 0001193125-18-024204 — 7.01, 9.01
- 2018-01-29 0001193125-18-022593 — 7.01, 9.01
- 2018-01-25 0001193125-18-019751 — 2.02, 8.01, 9.01
- 2017-12-12 0001193125-17-367561 — 1.01, 7.01, 8.01, 9.01
- 2017-11-29 0001193125-17-355698 — 1.01, 2.03, 7.01, 9.01
- 2017-11-20 0001193125-17-347218 — 7.01, 9.01
- 2017-11-13 0001193125-17-339171 — 7.01, 9.01
- 2017-11-08 0001193125-17-337353 — 1.01, 2.03, 7.01, 9.01
- 2017-11-03 0001193125-17-331827 — 5.02, 5.07, 9.01
- 2017-11-02 0001193125-17-330175 — 7.01, 9.01
- 2017-10-26 0001193125-17-321234 — 2.02, 9.01
- 2017-10-10 0001193125-17-306512 — 7.01, 9.01
- 2017-09-26 0001193125-17-293568 — 7.01, 9.01
- 2017-09-21 0001193125-17-289689 — 7.01, 9.01
- 2017-09-20 0001193125-17-289003 — 7.01, 9.01
- 2017-09-13 0001193125-17-283341 — 7.01, 9.01
- 2017-08-07 0001193125-17-249194 — 7.01, 9.01
- 2017-08-03 0001193125-17-247200 — 7.01, 9.01
- 2017-08-03 0001193125-17-246657 — 7.01, 9.01
- 2017-08-03 0001193125-17-246645 — 7.01, 9.01
- 2017-07-31 0001193125-17-241033 — 7.01, 9.01
- 2017-07-27 0001193125-17-238544 — 2.02, 9.01
- 2017-07-17 0001193125-17-228724 — 7.01, 9.01
- 2017-06-29 0001193125-17-217566 — 7.01, 9.01
- 2017-06-26 0001193125-17-213357 — 7.01, 9.01
- 2017-06-21 0001193125-17-208676 — 7.01, 9.01
- 2017-06-15 0001193125-17-203929 — 7.01, 9.01
- 2017-06-02 0001193125-17-192771 — 8.01, 9.01
- 2017-05-15 0001193125-17-169477 — 7.01, 9.01
- 2017-05-04 0001193125-17-156614 — 7.01, 9.01
- 2017-04-27 0001193125-17-143039 — 2.02, 9.01
- 2017-03-23 0001193125-17-093192 — 1.01, 2.03, 7.01, 9.01
- 2017-03-14 0001193125-17-081848 — 1.01, 2.03, 7.01, 9.01
- 2017-02-09 0001193125-17-036193 — 5.02, 7.01, 9.01
- 2017-02-07 0001193125-17-032547 — 8.01, 9.01
- 2017-02-02 0001193125-17-027912 — 7.01, 9.01
- 2017-01-25 0001193125-17-018049 — 2.02, 9.01
- 2017-01-09 0001193125-17-004726 — 8.01, 9.01
- 2016-12-22 0000106040-16-000044 — 8.01, 9.01
- 2016-12-06 0001193125-16-786394 — 7.01, 9.01
- 2016-11-04 0001193125-16-760020 — 5.07
- 2016-11-04 0001193125-16-759295 — 7.01, 9.01
- 2016-10-26 0001193125-16-747970 — 2.02, 9.01
- 2016-09-22 0001193125-16-717057 — 1.01, 2.03, 7.01, 9.01
- 2016-09-07 0001193125-16-702689 — 7.01, 9.01
- 2016-08-18 0001193125-16-684785 — 1.01, 2.03, 7.01, 9.01
- 2016-08-08 0001193125-16-674174 — 5.02
- 2016-08-04 0001193125-16-670845 — 7.01, 9.01
- 2016-07-28 0001193125-16-662249 — 2.02, 9.01
- 2016-07-25 0000106040-16-000028 — 9.01 — amendment, the index does not say of what
- 2016-07-21 0001193125-16-653784 — 8.01
- 2016-07-06 0001193125-16-642507 — 2.02, 5.02, 7.01, 9.01
- 2016-06-29 0001193125-16-635376 — 5.02
- 2016-06-13 0001193125-16-619652 — 3.02, 8.01, 9.01
- 2016-06-10 0001193125-16-618327 — 1.01, 9.01
- 2016-06-08 0001193125-16-615994 — 8.01, 9.01
- 2016-05-26 0001193125-16-604453 — 7.01, 9.01
- 2016-05-12 0001193125-16-588382 — 1.01, 1.02, 2.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2016-05-10 0001193125-16-584771 — 8.01, 9.01
- 2016-05-04 0001193125-16-576310 — 7.01, 9.01
- 2016-04-29 0001193125-16-570122 — 1.01, 2.03, 9.01
- 2016-04-28 0001193125-16-563792 — 2.02, 9.01
- 2016-04-14 0001193125-16-540569 — 1.01, 2.03, 3.03, 8.01, 9.01
- 2016-04-05 0001193125-16-530045 — 8.01, 9.01
- 2016-03-31 0001193125-16-524270 — 8.01, 9.01
- 2016-03-18 0001193125-16-509411 — 8.01, 9.01
- 2016-03-15 0001193125-16-504958 — 5.07, 8.01, 9.01
- 2016-03-08 0001193125-16-495962 — 8.01, 9.01
- 2016-03-03 0001193125-16-491763 — 8.01, 9.01
- 2016-02-29 0001193125-16-484769 — 8.01, 9.01
- 2016-02-25 0001193125-16-476830 — 8.01, 9.01
- 2016-02-23 0001193125-16-472515 — 1.02, 8.01, 9.01
- 2016-02-11 0001193125-16-457909 — 7.01, 9.01
- 2016-02-04 0001193125-16-450418 — 8.01
- 2016-01-28 0001193125-16-441861 — 2.02, 9.01
- 2016-01-22 0001193125-16-434942 — 2.05, 2.06
- 2016-01-19 0001193125-16-431601 — 8.01
- 2015-11-17 0001193125-15-378771 — 7.01, 9.01
- 2015-11-12 0001193125-15-373795 — 8.01
- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2024-08-20

- 2024-02-08 0000106040-24-000011 — NT 10-Q, for the period ended 2023-12-29
- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000106040-24-000026:8k_2_02:1]
EX-99.1
2
a4ex991-pressreleaseq424.htm
EX-99.1

[0000106040-24-000026:8k_2_02:2]
Document

[0000106040-24-000026:8k_2_02:3]
Exhibit 99.1

[0000106040-24-000026:8k_2_02:4]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:5]
News Summary

[0000106040-24-000026:8k_2_02:6]
•Fourth quarter revenue was $3.76 billion, up 9% sequentially (QoQ). Cloud revenue increased 21% (QoQ), Client revenue increased 3% (QoQ) and Consumer revenue decreased 7% (QoQ). Fiscal year 2024 revenue was $13.00 billion.

[0000106040-24-000026:8k_2_02:7]
•Fourth quarter GAAP earnings per share (EPS) was $0.88 and Non-GAAP EPS was $1.44. Fiscal year 2024 GAAP EPS was $(1.72) and Non-GAAP EPS was $(0.20).

[0000106040-24-000026:8k_2_02:8]
•Expect fiscal first quarter 2025 revenue to be in the range of $4.00 billion to $4.20 billion.

[0000106040-24-000026:8k_2_02:9]
•Expect Non-GAAP EPS in the range of $1.55 to $1.85.

[0000106040-24-000026:8k_2_02:10]
SAN JOSE, Calif., — July 31, 2024 — Western Digital Corp. (Nasdaq: WDC) today reported fiscal fourth quarter and fiscal year 2024 financial results.

[0000106040-24-000026:8k_2_02:11]
“Our fourth quarter and fiscal year 2024 results are reflective of the diverse and innovative portfolio we have developed in alignment with our strategic roadmap. Together, with the structural changes we have made to strengthen our operations, we are benefitting from the broad recovery we are seeing across our end markets and structurally improving through-cycle profitability for both Flash and HDD,” said David Goeckeler, Western Digital CEO.

[0000106040-24-000026:8k_2_02:12]
“The emergence of the AI Data Cycle marks a transformational period within our industry that will drive fundamental shifts across our end markets, increasing the need for storage and creating new demand drivers. As we look ahead, we are confident in our ability to leverage our technology leadership position to capitalize on these exciting growth opportunities and deliver value for our customers,” continued David Goeckeler.

[0000106040-24-000026:8k_2_02:13]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:14]
Q4 2024 Financial Highlights

[0000106040-24-000026:8k_2_02:15]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q4 2024 | Q3 2024 | Q/Q |  | Q4 2024 | Q3 2024 | Q/Q |
| Revenue ($M) |  | $3,764 | $3,457 | up 9% |  | $3,764 | $3,457 | up 9% |
| Gross Margin |  | 35.9% | 29.0% | up 6.9 ppt |  | 36.3% | 29.3% | up 7.0 ppt |
| Operating Expenses ($M) |  | $846 | $728 | up 16% |  | $700 | $632 | up 11% |
| Operating Income ($M) |  | $507 | $273 | up 86% |  | $666 | $380 | up 75% |
| Diluted Net Income Attributable to Common Shareholders ($M) |  | $308 | $113 | up 173% |  | $504 | $210 | up 140% |
| Net Income Per Share |  | $0.88 | $0.34 | up 159% |  | $1.44 | $0.63 | up 129% |

[0000106040-24-000026:8k_2_02:16]
* not a meaningful figure

[0000106040-24-000026:8k_2_02:17]
|  |  | GAAP |  | Non-GAAP |
|  |  | Q4 2024 | Q4 2023 | Y/Y |  | Q4 2024 | Q4 2023 | Y/Y |
| Revenue ($M) |  | $3,764 | $2,672 | up 41% |  | $3,764 | $2,672 | up 41% |
| Gross Margin |  | 35.9% | 3.4% | up 32.5 ppt |  | 36.3% | 3.9% | up 32.4 ppt |
| Operating Expenses ($M) |  | $846 | $742 | up 14% |  | $700 | $582 | up 20% |
| Operating Income (Loss) ($M) |  | $507 | $(650) | * |  | $666 | $(478) | * |
| Diluted Net Income (Loss) Attributable to Common Shareholders ($M) |  | $308 | $(724) | * |  | $504 | ($640) | * |
| Net Income (Loss) Per Share |  | $0.88 | $(2.26) | * |  | $1.44 | $(1.99) | * |

[0000106040-24-000026:8k_2_02:18]
* not a meaningful figure

[0000106040-24-000026:8k_2_02:19]
The company had an operating cash inflow of $366 million and ended the quarter with $1.88 billion of total cash and cash equivalents.

[0000106040-24-000026:8k_2_02:20]
Fiscal Year 2024 Financial Highlights

[0000106040-24-000026:8k_2_02:21]
|  |  | GAAP |  | Non-GAAP |
|  |  | 2024 | 2023 | Y/Y |  | 2024 | 2023 | Y/Y |
| Revenue ($M) |  | $13,003 | $12,318 | up 6% |  | $13,003 | $12,318 | up 6% |
| Gross Margin |  | 22.6% | 15.3% | up 7.3 ppt |  | 22.8% | 15.7% | up 7.1 ppt |
| Operating Expenses ($M) |  | $2,971 | $3,172 | down 6% |  | $2,448 | $2,532 | down 3% |
| Operating Income (Loss) ($M) |  | $(26) | $(1,285) | down 98% |  | $512 | $(594) | * |
| Diluted Net Loss Attributable to Common Shareholders ($M) |  | $(561) | $(1,708) | down 67% |  | $(65) | $(1,133) | down 94% |
| Net Loss Per Share |  | $(1.72) | $(5.37) | down 68% |  | $(0.20) | $(3.56) | down 94% |

[0000106040-24-000026:8k_2_02:22]
* not a meaningful figure

[0000106040-24-000026:8k_2_02:23]
Additional details can be found within the company’s earnings presentation, which is accessible online at investor.wdc.com.

[0000106040-24-000026:8k_2_02:24]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:25]
End Market Summary

[0000106040-24-000026:8k_2_02:26]
| Revenue ($M) | Q4 2024 | Q3 2024 | Q/Q |  |  | Q4 2023 | Y/Y | 2024 | 2023 | Y/Y |
| Cloud | $1,882 | $1,553 | up 21% |  |  | $994 | up 89% | $5,378 | $5,252 | up 2% |
| Client | 1,204 | 1,174 | up 3% |  |  | 1,035 | up 16% | 4,647 | 4,328 | up 7% |
| Consumer | 678 | 730 | down 7% |  |  | 643 | up 5% | 2,978 | 2,738 | up 9% |
| Total Revenue | $3,764 | $3,457 | up 9% |  |  | $2,672 | up 41% | $13,003 | $12,318 | up 6% |

[0000106040-24-000026:8k_2_02:27]
In the fiscal fourth quarter:

[0000106040-24-000026:8k_2_02:28]
•Cloud represented 50% of total revenue. The sequential growth is attributed to higher nearline shipments and pricing in HDD, coupled with increased bit shipments and pricing in enterprise SSDs. The year-over-year increase was due to higher shipments and price per unit in nearline HDDs, along with higher enterprise SSD bit shipments.

[0000106040-24-000026:8k_2_02:29]
•Client represented 32% of total revenue. The sequential increase was due to the increase in flash ASPs offsetting a decline in flash bit shipments while HDD revenue decreased slightly. The year-over-year growth was driven by higher flash ASPs.

[0000106040-24-000026:8k_2_02:30]
•Consumer represented 18% of total revenue. Sequentially, the decrease was due to lower flash and HDD bit shipments partially offset by higher ASPs in both flash and HDD. The year-over-year increase was driven by improved flash ASPs and bit shipments.

[0000106040-24-000026:8k_2_02:31]
In fiscal year 2024:

[0000106040-24-000026:8k_2_02:32]
•Cloud represented 41% of total revenue. The year-over-year increase was due to higher demand for capacity enterprise HDDs and improved pricing.

[0000106040-24-000026:8k_2_02:33]
•Client represented 36% of total revenue. The year-over-year increase was due to higher flash bit shipments.

[0000106040-24-000026:8k_2_02:34]
•Consumer represented 23% of total revenue. The year-over-year increase was due to higher flash bit shipments.

[0000106040-24-000026:8k_2_02:35]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:36]
Business Outlook for Fiscal First Quarter of 2025

[0000106040-24-000026:8k_2_02:37]
|  | Three Months Ending |
|  | September 27, 2024 |
|  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) | $4.00 - $4.20 |  | $4.00 - $4.20 |
| Gross margin | 36.5% - 38.5% |  | 37.0% - 39.0% |
| Operating expenses ($M) | $845 - $885 |  | $695 - $715 |
| Interest and other expense, net ($M) | ~ $110 |  | ~ $110 |
| Tax rate % (2) | N/A |  | 15% - 17% |
| Diluted earnings per share | N/A |  | $1.55 - $1.85 |
| Diluted shares outstanding (in millions) | ~ 360 |  | ~ 360 |

[0000106040-24-000026:8k_2_02:38]
(1) Non-GAAP gross margin guidance excludes amortization of acquired intangible assets and stock-based compensation expense of approximately $10 million to $20 million. The company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense and expenses related to business separation costs, totaling approximately $150 million to $170 million. In the aggregate, Non-GAAP diluted earnings per share guidance excludes these items totaling approximately $160 million to $190 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, and Non-GAAP diluted earnings per share cannot be further allocated or quantified with certainty. The timing and amount of additional charges the company excludes from its Non-GAAP income tax expense and Non-GAAP diluted earnings per share depend on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP income tax expense and Non-GAAP diluted earnings per share to the most directly comparable GAAP financial measures (GAAP gross profit, GAAP operating expenses, income tax expense and diluted earnings per share, respectively) are not available without unreasonable effort.

[0000106040-24-000026:8k_2_02:39]
(2) Non-GAAP tax rate is determined based on a percentage of Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax rate may differ from our GAAP tax rate (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax rate for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0000106040-24-000026:8k_2_02:40]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:41]
Accounting Assessment for Recent Development in Litigation Matter

[0000106040-24-000026:8k_2_02:42]
On July 26, 2024, a jury awarded a lump sum of $262 million against a subsidiary of the company in a patent infringement action. The company respectfully disagrees with the jury’s verdict, continues to believe it has meritorious arguments to the judgment, and plans to appeal. In addition to the lump sum amount, the company anticipates that the plaintiff will request costs, attorney’s fees and interest.

[0000106040-24-000026:8k_2_02:43]
The company is currently evaluating the appropriate accounting treatment for this matter, and the financial information reported in this press release does not include the impact of these recent developments, pending completion of that assessment. The company expects to complete its accounting assessment in connection with the preparation of its Annual Report on Form 10-K, which it expects to file on or before August 27, 2024. As a result, the company expects that the financial information included in that report will differ from the preliminary fiscal fourth quarter US GAAP financial results reported in this press release. The company does not expect a change to its reported Non-GAAP financial results in connection with its assessment of this matter.

[0000106040-24-000026:8k_2_02:44]
Revisions to Prior Period Financial Results

[0000106040-24-000026:8k_2_02:45]
As previously reported, in connection with the preparation of its condensed consolidated financial statements as of and for the three and six months ended December 29, 2023, the company identified certain errors related to the company’s reporting and recording of its interests in its equity method investments in Flash Ventures. These errors related to unadjusted differences between Flash Ventures’ application of Japanese generally accepted accounting principles to certain lease-related transactions compared to the applicable U.S. generally accepted accounting principles. These unadjusted differences resulted in differences in the equity in earnings from these entities recognized by the company in Other income (expense), net and the carrying value of the company’s equity method investments in Flash Ventures in the unaudited condensed consolidated financial statements. The company evaluated the errors and determined the related impacts were not material to its financial statements for the prior periods when they occurred. The company has revised previously reported financial information for such immaterial errors, and the unaudited preliminary condensed consolidated financial statements included in this press release incorporate revisions made to correct these errors for the periods presented. Please refer to the tables outlining revisions to results of operations in the company’s earnings presentation, which is accessible online at investor.wdc.com, and to the company’s upcoming Annual Report on Form 10-K for the fiscal year ended June 28, 2024, for additional information related to these revisions.

[0000106040-24-000026:8k_2_02:46]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:47]
Investor Communications

[0000106040-24-000026:8k_2_02:48]
The investment community conference call to discuss these results and the company’s business outlook for the fiscal first quarter of 2025 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.wdc.com.

[0000106040-24-000026:8k_2_02:49]
About Western Digital

[0000106040-24-000026:8k_2_02:50]
Western Digital is on a mission to unlock the potential of data by harnessing the possibility to use it. With Flash and HDD franchises, underpinned by advancements in storage technologies, we create breakthrough innovations and powerful data storage solutions that enable the world to actualize its aspirations. Core to our values, we recognize the urgency to combat climate change and have committed to ambitious carbon reduction goals approved by the Science Based Targets initiative. Learn more about Western Digital and the Western Digital®, SanDisk® and WD® brands at www.westerndigital.com.

[0000106040-24-000026:8k_2_02:51]
Forward-Looking Statements

[0000106040-24-000026:8k_2_02:52]
Western Digital Reports Fiscal Fourth Quarter and Fiscal Year 2024 Financial Results

[0000106040-24-000026:8k_2_02:53]
HDD and Flash businesses; the final approval of the separation by the company’s board of directors; inflation; increase in interest rates and economic recession; future responses to and effects of global health crises; the impact of business and market conditions; the outcome and impact of the company’s announced separation transaction, including with respect to customer and supplier relationships, regulatory and contractual restrictions, stock price volatility and the diversion of management’s attention from ongoing business operations and opportunities; the impact of competitive products and pricing; the company’s development and introduction of products based on new technologies and expansion into new data storage markets; risks associated with cost saving initiatives, restructurings, acquisitions, divestitures, mergers, joint ventures and the company’s strategic relationships; difficulties or delays in manufacturing or other supply chain disruptions; hiring and retention of key employees; the company’s level of debt and other financial obligations; changes to the company’s relationships with key customers; compromise, damage or interruption from cybersecurity incidents or other data system security risks; actions by competitors; the company’s ability to achieve its GHG emissions reduction and other ESG goals; the impact of international conflicts; risks associated with compliance with changing legal and regulatory requirements and the outcome of legal proceedings; and other risks and uncertainties listed in the company’s filings with the Securities and Exchange Commission (the “SEC”), including the company’s Annual Report on Form 10-K filed with the SEC on August 22, 2023 and Quarterly Reports on Form 10-Q filed with the SEC on November 7, 2023 and February 12, 2024, to which your attention is directed. You should not place undue reliance on these forward-looking statements, which speak only as of the date hereof, and the company undertakes no obligation to update or revise these forward-looking statements to reflect new information or events, except as required by law.

[0000106040-24-000026:8k_2_02:54]
###

[0000106040-24-000026:8k_2_02:55]
Western Digital, the Western Digital logo, SanDisk and WD are registered trademarks or trademarks of Western Digital Corporation or its affiliates in the US and/or other countries.

[0000106040-24-000026:8k_2_02:56]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:57]
PRELIMINARY CONDENSED CONSOLIDATED BALANCE SHEETS

[0000106040-24-000026:8k_2_02:58]
(in millions; unaudited; on a US GAAP basis)

[0000106040-24-000026:8k_2_02:59]
|  | June 28,2024 |  | June 30,2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,879 |  |  | $ | 2,023 |  |
| Accounts receivable, net | 2,166 |  |  | 1,598 |  |
| Inventories | 3,342 |  |  | 3,698 |  |
| Other current assets | 673 |  |  | 567 |  |
| Total current assets | 8,060 |  |  | 7,886 |  |
| Property, plant and equipment, net | 3,167 |  |  | 3,620 |  |
| Notes receivable and investments in Flash Ventures | 991 |  |  | 1,410 |  |
| Goodwill | 10,032 |  |  | 10,037 |  |
| Other intangible assets, net | 78 |  |  | 80 |  |
| Other non-current assets | 1,767 |  |  | 1,513 |  |
| Total assets | $ | 24,095 |  |  | $ | 24,546 |  |
| LIABILITIES, CONVERTIBLE PREFERRED STOCK AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,411 |  |  | $ | 1,293 |  |
| Accounts payable to related parties | 313 |  |  | 292 |  |
| Accrued expenses | 1,096 |  |  | 1,288 |  |
| Income taxes payable | 525 |  |  | 999 |  |
| Accrued compensation | 608 |  |  | 349 |  |
| Current portion of long-term debt | 1,750 |  |  | 1,213 |  |
| Total current liabilities | 5,703 |  |  | 5,434 |  |
| Long-term debt | 5,684 |  |  | 5,857 |  |
| Other liabilities | 1,370 |  |  | 1,415 |  |
| Total liabilities | 12,757 |  |  | 12,706 |  |
| Convertible preferred stock, aggregate liquidation preference of $257 and $924, respectively | 229 |  |  | 876 |  |
| Total shareholders’ equity | 11,109 |  |  | 10,964 |  |
| Total liabilities, convertible preferred stock and shareholders’ equity | $ | 24,095 |  |  | $ | 24,546 |  |

[0000106040-24-000026:8k_2_02:60]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:61]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000106040-24-000026:8k_2_02:62]
(in millions, except per share amounts; unaudited; on a US GAAP basis)

[0000106040-24-000026:8k_2_02:63]
|  | Three Months Ended |  | Years Ended |  |  |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Revenue, net | $ | 3,764 |  |  | $ | 2,672 |  |  | $ | 13,003 |  |  | $ | 12,318 |  |  |  |
| Cost of revenue | 2,411 |  |  | 2,580 |  |  | 10,058 |  |  | 10,431 |  |  |  |
| Gross profit | 1,353 |  |  | 92 |  |  | 2,945 |  |  | 1,887 |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 538 |  |  | 458 |  |  | 1,907 |  |  | 2,009 |  |  |  |
| Selling, general and administrative | 220 |  |  | 231 |  |  | 828 |  |  | 970 |  |  |  |
| Employee termination, asset impairment, and other | 50 |  |  | 53 |  |  | 139 |  |  | 193 |  |  |  |
| Business separation costs | 38 |  |  | — |  |  | 97 |  |  | — |  |  |  |
| Total operating expenses | 846 |  |  | 742 |  |  | 2,971 |  |  | 3,172 |  |  |  |
| Operating income (loss) | 507 |  |  | (650) |  |  | (26) |  |  | (1,285) |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |
| Interest income | 9 |  |  | 9 |  |  | 39 |  |  | 24 |  |  |  |
| Interest expense | (103) |  |  | (89) |  |  | (417) |  |  | (312) |  |  |  |
| Other income (expense), net | (20) |  |  | (4) |  |  | 34 |  |  | 23 |  |  |  |
| Interest and other income (expense) | (114) |  |  | (84) |  |  | (344) |  |  | (265) |  |  |  |
| Income (loss) before taxes | 393 |  |  | (734) |  |  | (370) |  |  | (1,550) |  |  |  |
| Income tax expense (benefit) | 63 |  |  | (25) |  |  | 137 |  |  | 134 |  |  |  |
| Net income (loss) | 330 |  |  | (709) |  |  | (507) |  |  | (1,684) |  |  |  |
| Less: cumulative dividends allocated to preferred shareholders | 10 |  |  | 15 |  |  | 54 |  |  | 24 |  |  |  |
| Less: income attributable to preferred shareholders | 13 |  |  | — |  |  | — |  |  | — |  |  |  |
| Net income (loss) attributable to common shareholders | $ | 307 |  |  | $ | (724) |  |  | $ | (561) |  |  | $ | (1,708) |  |  |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.92 |  |  | $ | (2.26) |  |  | $ | (1.72) |  |  | $ | (5.37) |  |  |  |
| Diluted | $ | 0.88 |  |  | $ | (2.26) |  |  | $ | (1.72) |  |  | $ | (5.37) |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 333 |  |  | 321 |  |  | 326 |  |  | 318 |  |  |  |
| Diluted | 349 |  |  | 321 |  |  | 326 |  |  | 318 |  |  |  |

[0000106040-24-000026:8k_2_02:64]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:65]
PRELIMINARY CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000106040-24-000026:8k_2_02:66]
(in millions; unaudited; on a US GAAP basis)

[0000106040-24-000026:8k_2_02:67]
|  | Three Months Ended |  | Years Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | 330 |  |  | $ | (709) |  |  | $ | (507) |  |  | $ | (1,684) |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 138 |  |  | 185 |  |  | 568 |  |  | 828 |  |
| Stock-based compensation | 69 |  |  | 72 |  |  | 295 |  |  | 318 |  |
| Deferred income taxes | (41) |  |  | (78) |  |  | (161) |  |  | (48) |  |
| Gain on disposal of assets | — |  |  | — |  |  | (87) |  |  | (7) |  |
| Non-cash asset impairment | 59 |  |  | 1 |  |  | 158 |  |  | 19 |  |
| Amortization of debt issuance costs and discounts | 5 |  |  | 4 |  |  | 19 |  |  | 13 |  |
| Other non-cash operating activities, net | (1) |  |  | 69 |  |  | 19 |  |  | 61 |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (366) |  |  | (7) |  |  | (568) |  |  | 1,206 |  |
| Inventories | (127) |  |  | 281 |  |  | 356 |  |  | (60) |  |
| Accounts payable | 33 |  |  | (17) |  |  | 244 |  |  | (459) |  |
| Accounts payable to related parties | 3 |  |  | 26 |  |  | 21 |  |  | (28) |  |
| Accrued expenses | 123 |  |  | 132 |  |  | (187) |  |  | (352) |  |
| Income taxes payable | 50 |  |  | (14) |  |  | (474) |  |  | 130 |  |
| Accrued compensation | 162 |  |  | 7 |  |  | 259 |  |  | (162) |  |
| Other assets and liabilities, net | (71) |  |  | (20) |  |  | (249) |  |  | (183) |  |
| Net cash provided by (used in) operating activities | 366 |  |  | (68) |  |  | (294) |  |  | (408) |  |
| Investing Activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (116) |  |  | (119) |  |  | (292) |  |  | (807) |  |
| Activity related to Flash Ventures, net | 32 |  |  | (32) |  |  | 239 |  |  | 14 |  |
| Strategic investments and other, net | 26 |  |  | 9 |  |  | 26 |  |  | 31 |  |
| Net cash used in investing activities | (58) |  |  | (142) |  |  | (27) |  |  | (762) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Employee stock plans, net | 18 |  |  | 33 |  |  | (8) |  |  | 13 |  |
| Proceeds from convertible preferred stock, net of issuance costs | — |  |  | (1) |  |  | (5) |  |  | 881 |  |
| Purchase of capped calls | — |  |  | — |  |  | (155) |  |  | — |  |
| Repurchases of debt | — |  |  | — |  |  | (505) |  |  | — |  |
| Proceeds from debt, net of repayments | (337) |  |  | — |  |  | 896 |  |  | — |  |
| Debt issuance costs | — |  |  | (13) |  |  | (36) |  |  | (19) |  |
| Net cash provided by (used in) financing activities | (319) |  |  | 19 |  |  | 187 |  |  | 875 |  |
| Effect of exchange rate changes on cash | (4) |  |  | (6) |  |  | (10) |  |  | (9) |  |
| Net decrease in cash and cash equivalents | (15) |  |  | (197) |  |  | (144) |  |  | (304) |  |
| Cash and cash equivalents, beginning of period | 1,894 |  |  | 2,220 |  |  | 2,023 |  |  | 2,327 |  |
| Cash and cash equivalents, end of period | $ | 1,879 |  |  | $ | 2,023 |  |  | $ | 1,879 |  |  | $ | 2,023 |  |

[0000106040-24-000026:8k_2_02:68]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:69]
SUPPLEMENTAL OPERATING SEGMENT RESULTS

[0000106040-24-000026:8k_2_02:70]
(in millions; except percentages; unaudited)

[0000106040-24-000026:8k_2_02:71]
|  | Three Months Ended |  | Years Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Net revenue: |  |  |  |  |  |  |  |
| Flash | $ | 1,761 |  |  | $ | 1,377 |  |  | $ | 6,687 |  |  | $ | 6,063 |  |
| HDD | 2,003 |  |  | 1,295 |  |  | 6,316 |  |  | 6,255 |  |
| Total net revenue | $ | 3,764 |  |  | $ | 2,672 |  |  | $ | 13,003 |  |  | $ | 12,318 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Flash | $ | 642 |  |  | $ | (164) |  |  | $ | 1,079 |  |  | $ | 433 |  |
| HDD | 724 |  |  | 268 |  |  | 1,881 |  |  | 1,505 |  |
| Total gross profit for segments | 1,366 |  |  | 104 |  |  | 2,960 |  |  | 1,938 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation expense | (12) |  |  | (11) |  |  | (49) |  |  | (49) |  |
| Amortization of acquired intangible assets | (1) |  |  | 1 |  |  | (3) |  |  | — |  |
| Recovery from contamination incident | — |  |  | — |  |  | 37 |  |  | — |  |
| Other | — |  |  | (2) |  |  | — |  |  | (2) |  |
| Total unallocated corporate items | (13) |  |  | (12) |  |  | (15) |  |  | (51) |  |
| Consolidated gross profit | $ | 1,353 |  |  | $ | 92 |  |  | $ | 2,945 |  |  | $ | 1,887 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Flash | 36.5 | % |  | (11.9) | % |  | 16.1 | % |  | 7.1 | % |
| HDD | 36.1 | % |  | 20.7 | % |  | 29.8 | % |  | 24.1 | % |
| Total gross margin for segments | 36.3 | % |  | 3.9 | % |  | 22.8 | % |  | 15.7 | % |
| Consolidated gross margin | 35.9 | % |  | 3.4 | % |  | 22.6 | % |  | 15.3 | % |

[0000106040-24-000026:8k_2_02:72]
The company manages and reports under two reportable segments: flash-based products (“Flash”) and hard disk drives (“HDD”). In the table above, total gross profit for segments and total gross margin for segments are Non-GAAP financial measures, which are also referred to herein as Non-GAAP gross profit and Non-GAAP gross margin, respectively.

[0000106040-24-000026:8k_2_02:73]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:74]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-24-000026:8k_2_02:75]
(in millions; unaudited)

[0000106040-24-000026:8k_2_02:76]
|  | Three Months Ended |  | Years Ended |
|  | June 28,2024 |  | March 29,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| GAAP gross profit | $ | 1,353 |  |  | $ | 1,001 |  |  | $ | 92 |  |  | $ | 2,945 |  |  | $ | 1,887 |  |
| Stock-based compensation expense | 12 |  |  | 11 |  |  | 11 |  |  | 49 |  |  | 49 |  |
| Amortization of acquired intangible assets | 1 |  |  | 1 |  |  | (1) |  |  | 3 |  |  | — |  |
| Recovery from contamination incident | — |  |  | (1) |  |  | — |  |  | (37) |  |  | — |  |
| Other | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Non-GAAP gross profit | $ | 1,366 |  |  | $ | 1,012 |  |  | $ | 104 |  |  | $ | 2,960 |  |  | $ | 1,938 |  |
| GAAP operating expenses | $ | 846 |  |  | $ | 728 |  |  | $ | 742 |  |  | $ | 2,971 |  |  | $ | 3,172 |  |
| Stock-based compensation expense | (57) |  |  | (66) |  |  | (61) |  |  | (246) |  |  | (269) |  |
| Business separation costs | (38) |  |  | (23) |  |  | — |  |  | (97) |  |  | — |  |
| Employee termination, asset impairment, and other | (50) |  |  | (8) |  |  | (53) |  |  | (139) |  |  | (193) |  |
| Strategic review | — |  |  | — |  |  | (27) |  |  | (37) |  |  | (42) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (17) |  |  | — |  |  | (133) |  |
| Other | (1) |  |  | 1 |  |  | (2) |  |  | (4) |  |  | (3) |  |
| Non-GAAP operating expenses | $ | 700 |  |  | $ | 632 |  |  | $ | 582 |  |  | $ | 2,448 |  |  | $ | 2,532 |  |
| GAAP operating income (loss) | $ | 507 |  |  | $ | 273 |  |  | $ | (650) |  |  | $ | (26) |  |  | $ | (1,285) |  |
| Gross profit adjustments | 13 |  |  | 11 |  |  | 12 |  |  | 15 |  |  | 51 |  |
| Operating expense adjustments | 146 |  |  | 96 |  |  | 160 |  |  | 523 |  |  | 640 |  |
| Non-GAAP operating income (loss) | $ | 666 |  |  | $ | 380 |  |  | $ | (478) |  |  | $ | 512 |  |  | $ | (594) |  |
| GAAP interest and other income (expense), net | $ | (114) |  |  | $ | (95) |  |  | $ | (84) |  |  | $ | (344) |  |  | $ | (265) |  |
| Other | — |  |  | 3 |  |  | (6) |  |  | (61) |  |  | (13) |  |
| Non-GAAP interest and other income (expense), net | $ | (114) |  |  | $ | (92) |  |  | $ | (90) |  |  | $ | (405) |  |  | $ | (278) |  |
| GAAP income tax expense (benefit) | $ | 63 |  |  | $ | 43 |  |  | $ | (25) |  |  | $ | 137 |  |  | $ | 134 |  |
| Income tax adjustments | (46) |  |  | 8 |  |  | 82 |  |  | (19) |  |  | 103 |  |
| Non-GAAP income tax expense | $ | 17 |  |  | $ | 51 |  |  | $ | 57 |  |  | $ | 118 |  |  | $ | 237 |  |

[0000106040-24-000026:8k_2_02:77]
WESTERN DIGITAL CORPORATION

[0000106040-24-000026:8k_2_02:78]
PRELIMINARY RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0000106040-24-000026:8k_2_02:79]
(in millions, except per share amounts; unaudited)

[0000106040-24-000026:8k_2_02:80]
|  | Three Months Ended |  | Years Ended |
|  | June 28,2024 |  | March 29,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| GAAP net income (loss) | $ | 330 |  |  | $ | 135 |  |  | $ | (709) |  |  | $ | (507) |  |  | $ | (1,684) |  |
| Stock-based compensation expense | 69 |  |  | 77 |  |  | 72 |  |  | 295 |  |  | 318 |  |
| Business separation costs | 38 |  |  | 23 |  |  | — |  |  | 97 |  |  | — |  |
| Employee termination, asset impairment and other | 50 |  |  | 8 |  |  | 53 |  |  | 139 |  |  | 193 |  |
| Strategic review | — |  |  | — |  |  | 27 |  |  | 37 |  |  | 42 |  |
| Amortization of acquired intangible assets | 1 |  |  | 1 |  |  | 16 |  |  | 3 |  |  | 133 |  |
| Recovery from contamination incident | — |  |  | (1) |  |  | — |  |  | (37) |  |  | — |  |
| Other | 1 |  |  | 2 |  |  | (2) |  |  | (57) |  |  | (8) |  |
| Income tax adjustments | 46 |  |  | (8) |  |  | (82) |  |  | 19 |  |  | (103) |  |
| Non-GAAP net income (loss) | 535 |  |  | 237 |  |  | (625) |  |  | (11) |  |  | (1,109) |  |
| Less: amount allocated to preferred shareholders | 31 |  |  | 27 |  |  | 15 |  |  | 54 |  |  | 24 |  |
| Non-GAAP diluted net income (loss) attributable to common shareholders | $ | 504 |  |  | $ | 210 |  |  | $ | (640) |  |  | $ | (65) |  |  | $ | (1,133) |  |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 0.88 |  |  | $ | 0.34 |  |  | $ | (2.26) |  |  | $ | (1.72) |  |  | $ | (5.37) |  |
| Non-GAAP | $ | 1.44 |  |  | $ | 0.63 |  |  | $ | (1.99) |  |  | $ | (0.20) |  |  | $ | (3.56) |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 349 |  |  | 335 |  |  | 321 |  |  | 326 |  |  | 318 |  |
| Non-GAAP | 349 |  |  | 335 |  |  | 321 |  |  | 326 |  |  | 318 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 366 |  |  | $ | 58 |  |  | $ | (68) |  |  | $ | (294) |  |  | $ | (408) |  |
| Purchases of property, plant and equipment, net | (116) |  |  | (95) |  |  | (119) |  |  | (292) |  |  | (807) |  |
| Activity related to Flash Ventures, net | 32 |  |  | 128 |  |  | (32) |  |  | 239 |  |  | 14 |  |
| Free cash flow | $ | 282 |  |  | $ | 91 |  |  | $ | (219) |  |  | $ | (347) |  |  | $ | (1,201) |  |

[0000106040-24-000026:8k_2_02:81]
To supplement the condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), the table above sets forth Non-GAAP gross profit; Non-GAAP gross margin; Non-GAAP operating expenses; Non-GAAP operating income and loss; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income and loss; Non-GAAP diluted income and loss per common share and free cash flow (“Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from Non-GAAP measures used by other companies. The company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the company’s earnings performance and comparing it against prior periods. Specifically, the company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains and losses that the company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense, business separation costs, employee termination, asset impairment, and other, expenses related to our strategic review, amortization of acquired intangible assets, recovery from contamination incident, other adjustments, and income tax adjustments, and the company believes these measures along with the related reconciliations to the GAAP measures provide additional detail and comparability for assessing the company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0000106040-24-000026:8k_2_02:82]
As described above, the company excludes the following items from its Non-GAAP measures:

[0000106040-24-000026:8k_2_02:83]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the company’s control, the company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0000106040-24-000026:8k_2_02:84]
Business separation cost. The company incurred expenses associated with the separation of its HDD and Flash business units to create two independent, public companies. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-24-000026:8k_2_02:85]
Employee termination, asset impairment, and other. From time-to-time, in order to realign the company’s operations with anticipated market demand or to achieve cost synergies from the integration of acquisitions, the company may terminate employees and/or restructure its operations. From time-to-time, the company may also incur charges from the impairment of intangible assets and other long-lived assets. In addition, the company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods. In addition, the company has taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the company believes they are not indicative of the underlying performance of its business.

[0000106040-24-000026:8k_2_02:86]
Strategic review. The company incurred expenses associated with its review of strategic alternatives that resulted in the planned separation of its HDD and Flash business units to create two independent, public companies. The company believes these charges do not reflect the company’s operating results and that they are not indicative of the underlying performance of its business.

[0000106040-24-000026:8k_2_02:87]
Amortization of acquired intangible assets. The company incurs expenses from the amortization of acquired intangible assets over their economic lives. Such charges are significantly impacted by the timing and magnitude of the company’s acquisitions and any related impairment charges.

[0000106040-24-000026:8k_2_02:88]
Recovery from contamination incident. In February 2022, a contamination of certain materials used in the company’s manufacturing process occurred and affected production operations at the flash-based memory manufacturing facilities in Yokkaichi and Kitakami, Japan, which are operated through the company’s joint business ventures with Kioxia Corporation (collectively, "Flash Ventures"). The contamination resulted in scrapped inventory and rework costs, decontamination and other costs needed to restore the facilities to normal capacity, and under absorption of overhead costs which were expensed as incurred. During the quarters ended December 29, 2023 and March 29, 2024, the company received recoveries of these losses from other parties. The contamination charges and the related recoveries were inconsistent in amount and frequency, and the company believes they were not part of the ongoing production operation of its business.

[0000106040-24-000026:8k_2_02:89]
Other adjustments. From time-to-time, the company sells or impairs investments or other assets which are not considered necessary to its business operations, or incurs other charges or gains that the company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0000106040-24-000026:8k_2_02:90]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include adjustments to estimates related to the current status of the rules and regulations governing the transition to the Tax Cuts and Jobs Act and the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the company believes that they are not indicative of the underlying performance of its ongoing business.

[0000106040-24-000026:8k_2_02:91]
Additionally, free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and the activity related to Flash Ventures, net. The company considers free cash flow generated in any period to be a useful indicator of cash that is available for strategic opportunities including, among others, investing in the company’s business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0000106040-24-000026:8k_2_02:92]
___________________

[0000106040-24-000026:8k_2_02:93]
Contacts:

[0000106040-24-000026:8k_2_02:94]
Western Digital Corp.

[0000106040-24-000026:8k_2_02:95]
| Investor Contact: |  | Media Contact: |
| T. Peter Andrew |  | Media Relations |
| 949.672.9655 |  | 408.801.0021 |
| peter.andrew@wdc.com |  | WD.Mediainquiries@wdc.com |
| investor@wdc.com |  |  |
