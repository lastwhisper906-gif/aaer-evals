# WDC note change history — 0000106040-25-000026 → 0001628280-25-047613


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001628280-25-047613:note_history:1]
Legal Proceedings
Intellectual Property Litigation
  (was, 2025-05-02, similarity 0.7805):
[0000106040-25-000026:note_history:1]
Intellectual Property Litigation

- changed (2025-10-31):
[0001628280-25-047613:note_history:2]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of October 3, 2025.
  (was, 2025-05-02, similarity 0.6603):
[0000106040-25-000026:note_history:2]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company is contesting the judgment and, based on available arguments, the Company believes the judgment, including any prejudgment interest and legal costs will be reversed, amended or vacated based on the Company’s motions for judgment as a matter of law in the district court or when the Company presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of March 28, 2025.

- removed (2025-10-31):
[0000106040-25-000026:note_history:3]
Legal Proceedings
Tax

- removed (2025-10-31):
[0000106040-25-000026:note_history:4]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Taxes.

- removed (2025-10-31):
[0000106040-25-000026:note_history:5]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to hard disk drive media. As the case progressed, MRT dropped its claims with respect to U.S. Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

- removed (2025-10-31):
[0000106040-25-000026:note_history:6]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives.

- removed (2025-10-31):
[0000106040-25-000026:note_history:7]
Subsequent to March 28, 2025, pursuant to a confidential agreement effective as of April 17, 2025, MRT and the Company reached a global settlement of $130 million for all pending legal disputes. The settlement results in the dismissal of the MRT matter, as well as a second patent litigation matter MRT filed on August 22, 2024 against the Company. As a result of the settlement, the Company reversed $201 million of previously recorded charges in Operating expense under Litigation matter and $6 million of post-judgment interest previously recorded in Other income (expense), net.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001628280-25-047613:note_history:8]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drives (“HDD”) technologies.
  (was, 2025-05-02, similarity 0.9895):
[0000106040-25-000026:note_history:8]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology.

- added (2025-10-31):
[0001628280-25-047613:note_history:9]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.

- changed (2025-10-31):
[0001628280-25-047613:note_history:10]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 27, 2025 (the “2025 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2025 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2025-05-02, similarity 0.9943):
[0000106040-25-000026:note_history:10]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024 (the “2024 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2024 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2025-10-31):
[0001628280-25-047613:note_history:11]
Information provided herein for the three months ended September 27, 2024 is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 4, Discontinued Operations.
  (was, 2025-05-02, similarity 0.9114):
[0000106040-25-000026:note_history:11]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 3, Discontinued Operations.

- added (2025-10-31):
[0001628280-25-047613:note_history:12]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2026, which will end on July 3, 2026, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated continuing operations basis.

- added (2025-10-31):
[0001628280-25-047613:note_history:13]
The Company’s Chief Executive Officer is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income from continuing operations and Total assets. The Company has, therefore, determined that it has one reportable segment.

- changed (2025-10-31):
[0001628280-25-047613:note_history:14]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented; however, actual results could differ materially.
  (was, 2025-05-02, similarity 0.9617):
[0000106040-25-000026:note_history:14]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented. However, actual results could differ materially from these estimates.

- removed (2025-10-31):
[0000106040-25-000026:note_history:15]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- removed (2025-10-31):
[0000106040-25-000026:note_history:16]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

- removed (2025-10-31):
[0000106040-25-000026:note_history:17]
Historically, the Company had been managed and operated under two reportable segments: hard disk drives (“HDD”) and Flash-based products (“Flash”). As a result of the Separation (as defined in Note 3, Discontinued Operations) and disposition of the Flash segment, the Company’s continuing operations now consist of a single reportable segment, HDD. The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), now evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s consolidated results.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001628280-25-047613:note_history:18]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,617 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,717 |  |  | 4,749 |  |
| Issuance costs | (34) |  |  | (38) |  |
| Subtotal | 4,683 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,457 |  |  | $ | 2,485 |  |
  (was, 2025-05-02, similarity 0.9101):
[0000106040-25-000026:note_history:18]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,480 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,380 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,333 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,426) |  |  | (1,750) |  |
| Long-term debt | $ | 4,907 |  |  | $ | 5,684 |  |

- added (2025-10-31):
[0001628280-25-047613:note_history:19]
During the three months ended October 3, 2025, the Company made scheduled repayments of $31 million under the Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”). The Term Loan A-3 bears interest, at the Company’s option, at a base rate plus an applicable margin (as defined in the loan agreement governing the Term Loan A-3, which the Company refers to as the “Loan Agreement”). The all-in interest rate for Term Loan A-3 as of October 3, 2025 was 5.774%.

- added (2025-10-31):
[0001628280-25-047613:note_history:20]
As of October 3, 2025, the Company had no outstanding standby letters of credit and the available capacity under the revolving credit facility maturing in January 2027 was $1.25 billion as of that date.

- changed (2025-10-31):
[0001628280-25-047613:note_history:21]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of October 3, 2025, the Company was in compliance with the financial covenant.
  (was, 2025-05-02, similarity 0.9701):
[0000106040-25-000026:note_history:21]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of March 28, 2025, the Company was in compliance with the financial covenant.

- changed (2025-10-31):
[0001628280-25-047613:note_history:22]
As of October 3, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).
  (was, 2025-05-02, similarity 0.9818):
[0000106040-25-000026:note_history:22]
As of March 28, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

- changed (2025-10-31):
[0001628280-25-047613:note_history:23]
As of October 3, 2025, the 2028 Convertible Notes were convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.77 per share of common stock (as adjusted in accordance with the Indenture as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.
  (was, 2025-05-02, similarity 0.708):
[0000106040-25-000026:note_history:23]
The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.89 per share of common stock (which conversion price has been adjusted from its original conversion price of approximately $52.20 in accordance with the Indenture as a result of the Separation). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028, upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- added (2025-10-31):
[0001628280-25-047613:note_history:24]
During the calendar quarters ended September 30, 2025 and June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holders of the 2028 Convertible Notes have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through December 31, 2025. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of October 3, 2025 and June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.

- changed (2025-10-31):
[0001628280-25-047613:note_history:25]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). As of October 3, 2025, the Capped Calls each have a strike price of approximately $37.77 per share, as adjusted in accordance with the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $50.47 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.
  (was, 2025-05-02, similarity 0.8641):
[0000106040-25-000026:note_history:25]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $37.89 per share, which has been adjusted from its original conversion price of approximately $52.20 per share according to the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $51.00 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 11 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.

- removed (2025-10-31):
[0000106040-25-000026:note_history:26]
On February 20, 2025, the Company entered into a fourth amendment to the loan agreement governing the Company’s revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”) and term loan facility, dated as of January 7, 2022 (as amended, the “Loan Agreement”) that, among other changes, (a) permitted the Separation, (b) provided for the automatic release, in connection with the Separation, of guarantees and liens on collateral provided by Sandisk (as defined below) and Sandisk Technologies, Inc. under the Loan Agreement, (c) provided for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a noncash exchange to replace the Company’s previously existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”), (d) facilitates a potential future debt for equity exchange with respect to the Term Loan A-3 in connection with the Sandisk retained interest, and (e) in connection with the Separation, reduced the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion.

- removed (2025-10-31):
[0000106040-25-000026:note_history:27]
During the three and nine months ended March 28, 2025, the Company made scheduled repayments of $32 million and $107 million, respectively, under the Term Loan Facility. The Term Loan A-3 bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies (as defined in the Loan Agreement), with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-3 as of March 28, 2025 was 5.927%.

- removed (2025-10-31):
[0000106040-25-000026:note_history:28]
During the nine months ended March 28, 2025, the Company drew and repaid $150 million principal amount under the 2027 Revolving Credit Facility. As of March 28, 2025, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $1.25 billion as of that date.

- removed (2025-10-31):
[0000106040-25-000026:note_history:29]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended March 31, 2025 and accordingly, the holders of the 2028 Convertible Notes do not have the right to convert the notes during the succeeding calendar quarter ending June 30, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of March 28, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

- removed (2025-10-31):
[0000106040-25-000026:note_history:30]
Subsequent to March 28, 2025, the Company redeemed, at its election, $1.80 billion aggregate principal amount of its 4.75% senior unsecured notes due 2026 (the “2026 Notes”) at par plus accrued interest. Following such redemption, $500 million aggregate principal amount of the 2026 Notes remained outstanding.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001628280-25-047613:note_history:31]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,617 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,717 |  |  | 4,749 |  |
| Issuance costs | (34) |  |  | (38) |  |
| Subtotal | 4,683 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,457 |  |  | $ | 2,485 |  |
  (was, 2025-05-02, similarity 0.9101):
[0000106040-25-000026:note_history:31]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,480 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,380 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,333 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,426) |  |  | (1,750) |  |
| Long-term debt | $ | 4,907 |  |  | $ | 5,684 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-31):
[0001628280-25-047613:note_history:32]
The following table summarizes the Company’s disaggregated revenue:

- changed (2025-10-31):
[0001628280-25-047613:note_history:33]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,510 |  |  | $ | 1,909 |  |  |  |  |  |
| Client | 146 |  |  | 139 |  |  |  |  |  |
| Consumer | 162 |  |  | 164 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Asia | $ | 1,175 |  |  | $ | 686 |  |  |  |  |  |
| Americas | 1,100 |  |  | 1,247 |  |  |  |  |  |
| Europe, Middle East and Africa | 543 |  |  | 279 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
  (was, 2025-05-02, similarity 0.7993):
[0000106040-25-000026:note_history:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,007 |  |  | $ | 1,455 |  |  | $ | 6,012 |  |  | $ | 3,340 |  |
| Client | 137 |  |  | 140 |  |  | 416 |  |  | 440 |  |
| Consumer | 150 |  |  | 157 |  |  | 487 |  |  | 533 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 753 |  |  | $ | 600 |  |  | $ | 2,349 |  |  | $ | 1,677 |  |
| Americas | 1,182 |  |  | 882 |  |  | 3,468 |  |  | 1,844 |  |
| Europe, Middle East and Africa | 359 |  |  | 270 |  |  | 1,098 |  |  | 792 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |

- added (2025-10-31):
[0001628280-25-047613:note_history:34]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer.

- removed (2025-10-31):
[0000106040-25-000026:note_history:35]
The Company’s disaggregated revenue information was as follows:
