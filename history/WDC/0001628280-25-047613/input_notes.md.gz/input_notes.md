# WDC notes — 0001628280-25-047613


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-25-047613:notes:1]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drives (“HDD”) technologies.

[0001628280-25-047613:notes:2]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.

[0001628280-25-047613:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 27, 2025 (the “2025 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2025 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0001628280-25-047613:notes:4]
Information provided herein for the three months ended September 27, 2024 is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 4, Discontinued Operations.

[0001628280-25-047613:notes:5]
[same as prior period, unchanged from 0000106040-25-000026:notes:5]

[0001628280-25-047613:notes:6]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2026, which will end on July 3, 2026, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated continuing operations basis.

[0001628280-25-047613:notes:7]
[same as prior period, unchanged from 0000106040-25-000026:notes:7]

[0001628280-25-047613:notes:8]
The Company’s Chief Executive Officer is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income from continuing operations and Total assets. The Company has, therefore, determined that it has one reportable segment.

[0001628280-25-047613:notes:9]
[same as prior period, unchanged from 0000106040-25-000026:notes:9]

[0001628280-25-047613:notes:10]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented; however, actual results could differ materially.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-25-047613:notes:11]
Recent Accounting Pronouncements
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001628280-25-047613:notes:12]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued accounting standards update (“ASU”) No. 2025-07, “Derivatives and Hedging (Topic 815) and Revenue from Contracts with Customers (Topic 606): Derivatives Scope Refinements and Scope Clarification for Share-Based Noncash Consideration from a Customer in a Revenue Contract. (“ASU 2025-07”) which (i) expands the scope exception of Topic 815 to exclude certain contracts with a variable that is based on operations or activities specific to one of the parties to the contract and (ii) clarifies the scope of share-based payments from a customer in a revenue contract. ASU 2025-07 is effective for the year beginning July 3, 2027, and interim periods within that year. Early adoption is permitted and must be applied as of the beginning of the fiscal year that includes the interim period. The Company currently does not expect this standard to have a material impact on its condensed consolidated financial statements and related disclosures.

[0001628280-25-047613:notes:13]
In September 2025, the FASB issued ASU No. 2025-06, “Intangibles – Goodwill and Other – Internal-Use Software (Topic 350): Targeted Improvements to the Accounting for Internal-Use Software” (“ASU 2025-06”). ASU 2025-06 amends existing references to prescriptive and sequential software development stages to better align with current software development methods, such as agile development. Under the new standard, entities will begin to capitalize eligible software costs when (i) management has authorized and committed to funding the software project, and (ii) it is probable that the project will be completed and the software will be used to perform the function intended. ASU 2025-06 is effective for the year beginning July 1, 2028, and interim periods within that year, with early adoption permitted. The Company is currently assessing the impact of this standard on its condensed consolidated financial statements and related disclosures.

[0001628280-25-047613:notes:14]
In November 2024, the FASB issued ASU No. 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses” (“ASU 2024-03”), which is intended to improve disclosures about the expenses of public entities. The new guidance requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement, within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This standard is effective on either a prospective or retrospective basis with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption and expects to adopt the guidance for annual reporting periods in its annual report for the year ending June 30, 2028.

[0001628280-25-047613:notes:15]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” (“ASU 2023-09”). ASU 2023-09 calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. This standard is effective on either a prospective or retrospective basis. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026. The Company is currently compiling the information required for these disclosures and expects to provide any required disclosures in its annual report for the year ending July 3, 2026.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001628280-25-047613:notes:16]
Disaggregated Revenue, Geographic Information, Concentrations of Risk, and Segment Reporting
The following table summarizes the Company’s disaggregated revenue:

[0001628280-25-047613:notes:17]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,510 |  |  | $ | 1,909 |  |  |  |  |  |
| Client | 146 |  |  | 139 |  |  |  |  |  |
| Consumer | 162 |  |  | 164 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Asia | $ | 1,175 |  |  | $ | 686 |  |  |  |  |  |
| Americas | 1,100 |  |  | 1,247 |  |  |  |  |  |
| Europe, Middle East and Africa | 543 |  |  | 279 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |

[0001628280-25-047613:notes:18]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer.

[0001628280-25-047613:notes:19]
The Company’s top 10 customers accounted for 77% of its net revenue for the three months ended October 3, 2025, compared to 65% of its net revenue for the three months ended September 27, 2024. For the three months ended October 3, 2025, three customers accounted for 18%, 16%, and 14%, respectively, of the Company’s net revenue, and for the three months ended September 27, 2024, one customer accounted for 18% of the Company’s net revenue.

[0001628280-25-047613:notes:20]
As of October 3, 2025 and June 27, 2025, net accounts receivable were $1.36 billion and $1.49 billion, respectively, and reserves for potential credit losses were not material. As of October 3, 2025, five customers accounted for 17%, 16%, 12%, 12%, and 10%, respectively, of the Company’s net accounts receivable, and as of June 27, 2025, three customers accounted for 20%, 19%, and 12%, respectively, of the Company’s net accounts receivable.

[0001628280-25-047613:notes:21]
The following table is a reconciliation of the Company’s measure of segment profit or loss, significant segment expenses and other segment items:

[0001628280-25-047613:notes:22]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue, net | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
| Less: Significant expenses and other segment items |  |  |  |  |  |  |  |
| Cost of revenue(1) | 1,581 |  |  | 1,386 |  |  |  |  |  |
| Research and development(1) | 270 |  |  | 243 |  |  |  |  |  |
| Selling, general and administrative(1) | 111 |  |  | 176 |  |  |  |  |  |
| Litigation matter | — |  |  | 14 |  |  |  |  |  |
| Business realignment charges | 3 |  |  | 3 |  |  |  |  |  |
| Stock-based compensation | 53 |  |  | 57 |  |  |  |  |  |
| Interest expense, net | 42 |  |  | 92 |  |  |  |  |  |
| Gain on retained interest in Sandisk | (611) |  |  | — |  |  |  |  |  |
| Other expense, net | 2 |  |  | (4) |  |  |  |  |  |
| Other segment items(2) | 30 |  |  | 2 |  |  |  |  |  |
| Income tax expense | 155 |  |  | 90 |  |  |  |  |  |
| Net income from continuing operations | $ | 1,182 |  |  | $ | 153 |  |  |  |  |  |

[0001628280-25-047613:notes:23]
(1)    Excludes amounts related to stock-based compensation and other segment items which are presented separately in the table above.

[0001628280-25-047613:notes:24]
(2)    Other segment items include strategic investment activity and other charges.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-25-047613:notes:25]
Discontinued Operations
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. In connection with the Separation (as defined below), the Company incurred separation and transition costs, which are recorded as Business separation costs within discontinued operations in the Company’s Condensed Consolidated Financial Statements, as further detailed in the summary of Net income from discontinued operations, net of taxes, below.

[0001628280-25-047613:notes:26]
On February 21, 2025, the Company completed the separation of its Flash business (the “Separation”) through a pro rata distribution of 80.1% of the outstanding shares of Sandisk Corporation (“Sandisk”) to Western Digital stockholders. The Separation is intended to be tax-free for U.S. federal income tax purposes. To reflect the completion of the Separation, the Company recorded a decrease in shareholders’ equity for the net book value of applicable assets and liabilities derecognized in connection with the Separation, net of the Company’s retained ownership interest, which was initially 19.9% and was based on the net book value of the applicable assets and liabilities derecognized. As a result of the Separation, Sandisk became an independent public company and Western Digital no longer consolidates Sandisk into the Company’s financial results. The historical results of operations of Sandisk are now reported in the Company’s Condensed Consolidated Financial Statements as discontinued operations for all periods prior to the Separation on February 21, 2025. Following the Separation, as the Company no longer controls or has the ability to exert significant influence over Sandisk, the Company measures, at fair value on a recurring basis, its retained ownership interest in Sandisk common stock (see additional information in Note 6, Fair Value Measurements and Investments). In June 2025, the Company disposed of 21.3 million shares of its Sandisk common stock, along with $4 million in cash, in a tax-free exchange for $800 million principal amount of the Company’s Term Loan A-3. The Company expects to monetize its remaining stake in Sandisk within one year from the Separation date.

[0001628280-25-047613:notes:27]
[same as prior period, unchanged from 0000106040-25-000026:notes:19]

[0001628280-25-047613:notes:28]
The following table provides a summary of the historical results of Sandisk for the three months ended September 27, 2024 which have been reflected as Net income from discontinued operations, net of taxes in the Condensed Consolidated Statements of Operations:

[0001628280-25-047613:notes:29]
| Net Income from Discontinued Operations, Net of Taxes |  |  |  | September 27,2024 |  |  |  |  |  |  |
|  |  |  |  | (in millions) |  |  |
| Revenue, net |  |  |  | $ | 1,883 |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  | 1,138 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  | 257 |  |  |  |  |  |  |  |
| Selling, general and administrative |  |  |  | 38 |  |  |  |  |  |  |  |
| Business separation costs |  |  |  | 43 |  |  |  |  |  |  |  |
| Business realignment charges |  |  |  | (1) |  |  |  |  |  |  |  |
| Operating income |  |  |  | 408 |  |  |  |  |  |  |  |
| Total interest and other expense, net |  |  |  | (23) |  |  |  |  |  |  |  |
| Income before taxes |  |  |  | 385 |  |  |  |  |  |  |  |
| Income tax expense |  |  |  | 45 |  |  |  |  |  |  |  |
| Net income from discontinued operations, net of taxes |  |  |  | $ | 340 |  |  |  |  |  |  |  |

[0001628280-25-047613:notes:30]
[same as prior period, unchanged from 0000106040-25-000026:notes:25]

[0001628280-25-047613:notes:31]
|  |  |  |  | Three Months Ended |
| Select Cash Flow Information from Discontinued Operations |  |  |  | September 27,2024 |
|  |  |  |  | (in millions) |
| Depreciation and amortization |  |  |  | $ | 55 |  |
| Purchases of property, plant and equipment |  |  |  | 67 |  |
| Stock-based compensation |  |  |  | 27 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001628280-25-047613:notes:32]
[same as prior period, unchanged from 0000106040-25-000026:notes:30]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-047613:notes:33]
Supplemental Financial Statement Data
Inventories

[0001628280-25-047613:notes:34]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 238 |  |  | $ | 227 |  |
| Work-in-process | 793 |  |  | 785 |  |
| Finished goods | 362 |  |  | 279 |  |
| Total inventories | $ | 1,393 |  |  | $ | 1,291 |  |

[0001628280-25-047613:notes:35]
[same as prior period, unchanged from 0000106040-25-000026:notes:40]

[0001628280-25-047613:notes:36]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 225 |  |  | $ | 225 |  |
| Buildings and improvements | 1,576 |  |  | 1,550 |  |
| Machinery and equipment | 6,548 |  |  | 6,488 |  |
| Computer equipment and software | 263 |  |  | 257 |  |
| Furniture and fixtures | 35 |  |  | 33 |  |
| Construction-in-process | 486 |  |  | 532 |  |
| Property, plant and equipment, gross | 9,133 |  |  | 9,085 |  |
| Accumulated depreciation | (6,788) |  |  | (6,742) |  |
| Property, plant and equipment, net | $ | 2,345 |  |  | $ | 2,343 |  |

[0001628280-25-047613:notes:37]
[same as prior period, unchanged from 0000106040-25-000026:notes:44]

[0001628280-25-047613:notes:38]
|  | October 3,2025 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Non-current assets: |  |  |  |  |  |  |  |  |  |
| Deferred tax assets | $ | 953 |  |  | $ | 1,007 |  |  |  |  |  |  |  |
| Other non-current assets | 467 |  |  | 477 |  |  |  |  |  |  |  |
| Total non-current assets | $ | 1,420 |  |  | $ | 1,484 |  |  |  |  |  |  |  |

[0001628280-25-047613:notes:39]
[same as prior period, unchanged from 0000106040-25-000026:notes:46]

[0001628280-25-047613:notes:40]
[same as prior period, unchanged from 0000106040-25-000026:notes:47]

[0001628280-25-047613:notes:41]
|  | Three Months Ended |  |  |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 152 |  |  | $ | 142 |  |  |  |  |  |  |  |
| Charges to operations | 27 |  |  | 24 |  |  |  |  |  |  |  |
| Utilization | (24) |  |  | (30) |  |  |  |  |  |  |  |
| Changes in estimate related to pre-existing warranties | 5 |  |  | (17) |  |  |  |  |  |  |  |
| Warranty accrual, end of period | $ | 160 |  |  | $ | 119 |  |  |  |  |  |  |  |

[0001628280-25-047613:notes:42]
[same as prior period, unchanged from 0000106040-25-000026:notes:49]

[0001628280-25-047613:notes:43]
|  | October 3,2025 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 45 |  |  | $ | 57 |  |  |  |  |  |  |  |
| Long-term portion | 115 |  |  | 95 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 160 |  |  | $ | 152 |  |  |  |  |  |  |  |

[0001628280-25-047613:notes:44]
[same as prior period, unchanged from 0000106040-25-000026:notes:51]

[0001628280-25-047613:notes:45]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current portion of unrecognized tax benefits | $ | 193 |  |  | $ | 163 |  |
| Other non-current liabilities | 419 |  |  | 396 |  |
| Total other liabilities | $ | 612 |  |  | $ | 559 |  |

[0001628280-25-047613:notes:46]
[same as prior period, unchanged from 0000106040-25-000026:notes:53]

[0001628280-25-047613:notes:47]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed goodwill impairment assessments and concluded there were no impairments for the three month periods ended October 3, 2025 and September 27, 2024. The carrying amount of goodwill was $4.32 billion as of both October 3, 2025 and June 27, 2025.

[0001628280-25-047613:notes:48]
Accumulated other comprehensive income

[0001628280-25-047613:notes:49]
Accumulated other comprehensive income refers to expenses, gains, and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The components of Accumulated other comprehensive income were as follows:

[0001628280-25-047613:notes:50]
|  | Actuarial Pension Gains |  | Foreign Currency Translation Adjustment |  |  |  | Unrealized Gains on Derivative Contracts |  | Total Accumulated Other Comprehensive Income |
|  | (in millions) |
| Balance at June 27, 2025 | $ | 16 |  |  | $ | (2) |  |  |  |  | $ | 6 |  |  | $ | 20 |  |
| Other comprehensive loss before reclassifications | — |  |  | — |  |  |  |  | (4) |  |  | (4) |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  |  |  | (3) |  |  | (3) |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | — |  |  |  |  | 1 |  |  | 1 |  |
| Net current-period other comprehensive loss | — |  |  | — |  |  |  |  | (6) |  |  | (6) |  |
| Balance at October 3, 2025 | $ | 16 |  |  | $ | (2) |  |  |  |  | $ | — |  |  | $ | 14 |  |

[0001628280-25-047613:notes:51]
During the three months ended October 3, 2025, the amounts reclassified out of Accumulated other comprehensive income were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001628280-25-047613:notes:52]
As of October 3, 2025, all existing net gains related to cash flow hedges recorded in Accumulated other comprehensive income are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-047613:notes:53]
[same as prior period, unchanged from 0000106040-25-000026:notes:60]

[0001628280-25-047613:notes:54]
[same as prior period, unchanged from 0000106040-25-000026:notes:61]

[0001628280-25-047613:notes:55]
[same as prior period, unchanged from 0000106040-25-000026:notes:62]

[0001628280-25-047613:notes:56]
[same as prior period, unchanged from 0000106040-25-000026:notes:63]

[0001628280-25-047613:notes:57]
[same as prior period, unchanged from 0000106040-25-000026:notes:64]

[0001628280-25-047613:notes:58]
[same as prior period, unchanged from 0000106040-25-000026:notes:65]

[0001628280-25-047613:notes:59]
|  | October 3, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Retained interest in Sandisk | $ | 965 |  |  | $ | — |  |  | $ | — |  |  | $ | 965 |  |
| Cash equivalents - Money market funds | 140 |  |  | — |  |  | — |  |  | 140 |  |
| Foreign exchange contracts | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets at fair value | $ | 1,105 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1,109 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |

[0001628280-25-047613:notes:60]
|  | June 27, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Retained interest in Sandisk | $ | 354 |  |  | $ | — |  |  | $ | — |  |  | $ | 354 |  |
| Cash equivalents - Money market funds | 285 |  |  | — |  |  | — |  |  | 285 |  |
| Foreign exchange contracts | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets at fair value | $ | 639 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 649 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0001628280-25-047613:notes:61]
[same as prior period, unchanged from 0000106040-25-000026:notes:68]

[0001628280-25-047613:notes:62]
[same as prior period, unchanged from 0000106040-25-000026:notes:69]

[0001628280-25-047613:notes:63]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below were categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the first quarter of 2026 and the fourth quarter of 2025, respectively.

[0001628280-25-047613:notes:64]
|  | October 3, 2025 |  | June 27, 2025 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |  | $ | 500 |  |  | $ | 499 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,612 |  |  | 1,622 |  |  | 1,642 |  |  | 1,655 |  |
| 3.00% convertible notes due 2028 | 1,577 |  |  | 5,598 |  |  | 1,575 |  |  | 2,849 |  |
| 2.85% senior notes due 2029 | 498 |  |  | 472 |  |  | 498 |  |  | 463 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 454 |  |  | 496 |  |  | 442 |  |
| Total | $ | 4,683 |  |  | $ | 8,646 |  |  | $ | 4,711 |  |  | $ | 5,908 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-047613:notes:65]
Debt
Debt consisted of the following:

[0001628280-25-047613:notes:66]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,617 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,717 |  |  | 4,749 |  |
| Issuance costs | (34) |  |  | (38) |  |
| Subtotal | 4,683 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,457 |  |  | $ | 2,485 |  |

[0001628280-25-047613:notes:67]
During the three months ended October 3, 2025, the Company made scheduled repayments of $31 million under the Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”). The Term Loan A-3 bears interest, at the Company’s option, at a base rate plus an applicable margin (as defined in the loan agreement governing the Term Loan A-3, which the Company refers to as the “Loan Agreement”). The all-in interest rate for Term Loan A-3 as of October 3, 2025 was 5.774%.

[0001628280-25-047613:notes:68]
As of October 3, 2025, the Company had no outstanding standby letters of credit and the available capacity under the revolving credit facility maturing in January 2027 was $1.25 billion as of that date.

[0001628280-25-047613:notes:69]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of October 3, 2025, the Company was in compliance with the financial covenant.

[0001628280-25-047613:notes:70]
As of October 3, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

[0001628280-25-047613:notes:71]
As of October 3, 2025, the 2028 Convertible Notes were convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.77 per share of common stock (as adjusted in accordance with the Indenture as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.

[0001628280-25-047613:notes:72]
During the calendar quarters ended September 30, 2025 and June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holders of the 2028 Convertible Notes have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through December 31, 2025. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of October 3, 2025 and June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.

[0001628280-25-047613:notes:73]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). As of October 3, 2025, the Capped Calls each have a strike price of approximately $37.77 per share, as adjusted in accordance with the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $50.47 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-25-047613:notes:74]
[same as prior period, unchanged from 0000106040-25-000026:notes:95]

[0001628280-25-047613:notes:75]
[same as prior period, unchanged from 0000106040-25-000026:notes:96]

[0001628280-25-047613:notes:76]
[same as prior period, unchanged from 0000106040-25-000026:notes:97]

[0001628280-25-047613:notes:77]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 116 |  |  | $ | 123 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 29 |  |  | 31 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 103 |  |  | 110 |  |
| Total operating lease liabilities | $ | 132 |  |  | $ | 141 |  |

[0001628280-25-047613:notes:78]
[same as prior period, unchanged from 0000106040-25-000026:notes:99]

[0001628280-25-047613:notes:79]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Cost of operating leases | $ | 9 |  |  | $ | 10 |  |  |  |  |  |
| Cash paid for operating leases | 10 |  |  | 11 |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities | — |  |  | 5 |  |  |  |  |  |

[0001628280-25-047613:notes:80]
[same as prior period, unchanged from 0000106040-25-000026:notes:101]

[0001628280-25-047613:notes:81]
|  | October 3,2025 |  | June 27,2025 |  |  |
| Weighted average remaining lease term in years | 6.0 |  | 6.1 |  |  |
| Weighted average discount rate | 5.0 | % |  | 5.0 | % |  |  |

[0001628280-25-047613:notes:82]
As of October 3, 2025, minimum lease payments were as follows:

[0001628280-25-047613:notes:83]
|  | Lease Amounts |
|  | (in millions) |
| Remaining nine months of 2026 | $ | 25 |  |
| 2027 | 30 |  |
| 2028 | 23 |  |
| 2029 | 18 |  |
| 2030 | 12 |  |
| Thereafter | 46 |  |
| Total future minimum lease payments | 154 |  |
| Less: imputed interest | 22 |  |
| Present value of lease liabilities | $ | 132 |  |

[0001628280-25-047613:notes:84]
Purchase Obligations and Other Commitments

[0001628280-25-047613:notes:85]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions, such as performance, quality and technology of the vendor’s components. As of October 3, 2025, the Company had the following minimum long-term commitments:

[0001628280-25-047613:notes:86]
|  | Long-Term Commitments |
|  | (in millions) |
| Remaining nine months of 2026 | $ | 35 |  |
| 2027 | 27 |  |
| Total | $ | 62 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-047613:notes:87]
Income Taxes
Previously, the Tax Cuts and Jobs Act of 2017 (“TCJA”) eliminated the ability to deduct research and development (“R&D”) expenditures in the year incurred, requiring capitalization and amortization under Internal Revenue Code Section 174. On July 4, 2025, the One Big Beautiful Bill Act of 2025 (“OBBBA”) was signed into law, which includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with 2026. The legislation also includes favorable modifications to international tax provisions, including changes to the Global Intangible Low-Taxed Income regime and enhancements to the Foreign-Derived Deduction Eligible Income (“FDDEI”) deduction that will become effective for the Company in 2027.

[0001628280-25-047613:notes:88]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. Although CAMT became effective for the Company beginning with 2024, the Company was not subject to CAMT in 2024 and 2025. The Company does not expect to be subject to CAMT in 2026 as its average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0001628280-25-047613:notes:89]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”). For 2026, the Company is subject to GMT in Thailand and the Philippines.

[0001628280-25-047613:notes:90]
The following table presents the Company’s Income tax expense and the effective tax rate:

[0001628280-25-047613:notes:91]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | ($ in millions) |
| Income before taxes | $ | 1,337 |  | $ | 243 |  |  |  |  |
| Income tax expense | 155 |  | 90 |  |  |  |  |
| Effective tax rate | 12 | % |  | 37 | % |  |  |  |  |

[0001628280-25-047613:notes:92]
The primary drivers of the difference between the effective tax rate for the three months ended October 3, 2025 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for FDDEI, tax credits and the gain on the retained Sandisk interest being tax-free due to the Separation of the Flash business. These resulted in decreases to the Company’s effective tax rate below the U.S. statutory rate for the three months ended October 3, 2025. The Company’s income tax provision for the three months ended October includes GMT taxes for Thailand and the Philippines, countries for which the Company maintains tax holidays.

[0001628280-25-047613:notes:93]
The primary drivers of the difference between the effective tax rate for the three months ended September 27, 2024 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, tax credits, and tax holidays in Thailand and the Philippines. In addition, the effective tax rate for the three months ended September 27, 2024 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with U.S. Internal Revenue Service (“IRS”) calculations.

[0001628280-25-047613:notes:94]
Liability for Uncertain Tax Positions

[0001628280-25-047613:notes:95]
[same as prior period, unchanged from 0000106040-25-000026:notes:137]

[0001628280-25-047613:notes:96]
The following is a reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the three months ended October 3, 2025 (in millions):

[0001628280-25-047613:notes:97]
| Accrual balance at June 27, 2025 | $ | 569 |  |
| Gross increases related to current year tax positions | 8 |  |
| Gross increases related to prior year tax positions | 24 |  |
| Gross decreases related to prior year tax positions | (1) |  |
| Lapse of statute of limitations | (2) |  |
| Accrual balance at October 3, 2025 | $ | 598 |  |

[0001628280-25-047613:notes:98]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of October 3, 2025 was $93 million. Of the aggregate unrecognized tax benefits, including interest and penalties, approximately $130 million could result in potential cash payments to be made within the next twelve months.

[0001628280-25-047613:notes:99]
The Company believes that an adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0001628280-25-047613:notes:100]
Business Realignment Charges
The Company periodically incurs charges to realign its business operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure, and focus its resources. These actions may result in charges for employee termination benefits or charges from the impairment of intangible assets and other long-lived assets.

[0001628280-25-047613:notes:101]
[same as prior period, unchanged from 0000106040-25-000026:notes:150]

[0001628280-25-047613:notes:102]
|  | Three Months Ended |  |  |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 3 |  |  | $ | — |  |  |  |  |  |  |  |
| Contract termination and other | — |  |  | 3 |  |  |  |  |  |  |  |
| Total business realignment charges | $ | 3 |  |  | $ | 3 |  |  |  |  |  |  |  |

[0001628280-25-047613:notes:103]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the three months ended October 3, 2025:

[0001628280-25-047613:notes:104]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at June 27, 2025 | $ | 1 |  |  | $ | 9 |  |  | $ | 10 |  |  |  |  |  |
| Charges | 3 |  |  | — |  |  | 3 |  |  |  |  |  |
| Cash payments | (2) |  |  | (1) |  |  | (3) |  |  |  |  |  |
| Accrual balance at October 3, 2025 | $ | 2 |  |  | $ | 8 |  |  | $ | 10 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-25-047613:notes:105]
[same as prior period, unchanged from 0000106040-25-000026:notes:88]

[0001628280-25-047613:notes:106]
[same as prior period, unchanged from 0000106040-25-000026:notes:89]

[0001628280-25-047613:notes:107]
[same as prior period, unchanged from 0000106040-25-000026:notes:90]

[0001628280-25-047613:notes:108]
|  | October 3,2025 |  | June 27,2025 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 262 |  |  | $ | 272 |  |  |  |
| Less: Fair value of plan assets at end of period | 191 |  |  | 204 |  |  |  |
| Unfunded status | $ | 71 |  |  | $ | 68 |  |  |  |

[0001628280-25-047613:notes:109]
[same as prior period, unchanged from 0000106040-25-000026:notes:92]

[0001628280-25-047613:notes:110]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Current liabilities (included in Accrued expenses) | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities (included in Other liabilities) | 70 |  |  | 67 |  |
| Net amount recognized | $ | 71 |  |  | $ | 68 |  |

[0001628280-25-047613:notes:111]
Net periodic benefit costs were immaterial for the three months ended October 3, 2025 and September 27, 2024.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001628280-25-047613:notes:112]
[same as prior period, unchanged from 0000106040-25-000026:notes:108]

[0001628280-25-047613:notes:113]
[same as prior period, unchanged from 0000106040-25-000026:notes:110]

[0001628280-25-047613:notes:114]
|  | Three Months Ended |  |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 49 |  |  | $ | 49 |  |  |  |  |  |  |
| ESPP | 4 |  |  | 8 |  |  |  |  |  |  |
| Total | $ | 53 |  |  | $ | 57 |  |  |  |  |  |  |

[0001628280-25-047613:notes:115]
|  | Three Months Ended |  |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |  |
|  | (in millions) |
| Cost of revenue | $ | 9 |  |  | $ | 10 |  |  |  |  |  |  |
| Research and development | 23 |  |  | 20 |  |  |  |  |  |  |
| Selling, general and administrative | 21 |  |  | 27 |  |  |  |  |  |  |
| Subtotal | 53 |  |  | 57 |  |  |  |  |  |  |
| Tax benefit | (7) |  |  | (6) |  |  |  |  |  |  |
| Total | $ | 46 |  |  | $ | 51 |  |  |  |  |  |  |

[0001628280-25-047613:notes:116]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were immaterial for the periods presented.

[0001628280-25-047613:notes:117]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of October 3, 2025:

[0001628280-25-047613:notes:118]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 382 |  |  | 2.2 |
| ESPP | 19 |  |  | 1.2 |
| Total unamortized compensation cost | $ | 401 |  |  |  |

[0001628280-25-047613:notes:119]
[same as prior period, unchanged from 0000106040-25-000026:notes:116]

[0001628280-25-047613:notes:120]
[same as prior period, unchanged from 0000106040-25-000026:notes:117]

[0001628280-25-047613:notes:121]
[same as prior period, unchanged from 0000106040-25-000026:notes:118]

[0001628280-25-047613:notes:122]
[same as prior period, unchanged from 0000106040-25-000026:notes:119]

[0001628280-25-047613:notes:123]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 27, 2025 | 9.7 |  |  | $ | 33.56 |  |  |  |
| Granted | 2.4 |  |  | 70.89 |  |  |  |
| Vested | (2.0) |  |  | 34.49 |  |  | $ | 154 |  |
| Forfeited | (0.1) |  |  | 24.71 |  |  |  |
| RSUs and PSUs outstanding at October 3, 2025 | 10.0 |  |  | $ | 43.12 |  |  |  |

[0001628280-25-047613:notes:124]
[same as prior period, unchanged from 0000106040-25-000026:notes:121]

[0001628280-25-047613:notes:125]
[same as prior period, unchanged from 0000106040-25-000026:notes:124]

[0001628280-25-047613:notes:126]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing 5,000,000 authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement. As of October 3, 2025 and June 27, 2025, 235,000 of the Preferred Shares were outstanding.

[0001628280-25-047613:notes:127]
The Preferred Shares have an initial stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. Such dividends are payable on a quarterly basis in cash or in-kind through an increase to the stated value. Through December 27, 2024, the Company paid quarterly dividends on the Preferred Shares in-kind through an increase to the stated value. Subsequently, quarterly dividends on the Preferred Shares have been made in cash, including $4 million paid in the three months ended October 3, 2025. As of October 3, 2025 and June 27, 2025, the Preferred Shares outstanding had an aggregate liquidation preference, including previous dividends paid in-kind, of $265 million as of each date, and would have been convertible, if otherwise permitted, into approximately 7 million shares of common stock as of each date. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis.

[0001628280-25-047613:notes:128]
As of October 3, 2025, the Preferred Shares are convertible into shares of the Company’s common stock at a conversion rate of approximately $35.51 per share, as adjusted in accordance with the Certificate of Designations for the Preferred Shares (the “Conversion Price”). This rate is subject to future anti-dilution adjustments and certain other one-time adjustments in the event of various specified spin-off transactions. The conversion applies to the total of the stated value of the Preferred Shares, including dividends paid in-kind. In the case of future standalone spin-off transactions, holders of the Preferred Shares may convert one-third of their shares into a similar class of preferred shares of the spin-off entity. The Company may opt to convert the Preferred Shares after January 31, 2026, if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately before the Company's conversion notice.

[0001628280-25-047613:notes:129]
Share Repurchase Program

[0001628280-25-047613:notes:130]
On May 9, 2025, the Company’s Board of Directors authorized a share repurchase program for the repurchase of up to $2.0 billion of the Company’s common stock (the “Share Repurchase Program”). There is no expiration date for the Share Repurchase Program. During the three months ended October 3, 2025, the Company repurchased 6.4 million shares under the Share Repurchase Program for a total cash cost of $553 million plus $4 million for accrued excise taxes. As of October 3, 2025 the Company had $1.30 billion available for purchases pursuant to the Share Repurchase Program. Repurchases under the Share Repurchase Program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects shares repurchased under the Share Repurchase Program to be funded principally by operating cash flows. The amount and timing of share repurchases will depend on market conditions and other corporate considerations. The Company may suspend or discontinue the Share Repurchase Program at any time.

[0001628280-25-047613:notes:131]
Dividends to Common Shareholders

[0001628280-25-047613:notes:132]
On April 29, 2025, the Company’s Board of Directors authorized the adoption of a cash dividend program. Under the cash dividend program, holders of the Company’s common stock will receive dividends when and as declared by the Board of Directors. During the three months ended October 3, 2025, the Company paid cash dividends of $0.10 per share of its outstanding common stock, totaling $34 million, plus $1 million paid to holders of the Company’s Preferred Shares in accordance with their participation rights.

[0001628280-25-047613:notes:133]
Subsequent to quarter-end, on October 29, 2025, the Board of Directors declared a cash dividend of $0.125 per share of the Company’s common stock, which will be paid on December 18, 2025 to shareholders of record as of the close of business on December 4, 2025.

[0001628280-25-047613:notes:134]
The Company may modify, suspend, or cancel its cash dividend program in any matter and at any time. The amount of future dividends under the Company’s cash dividend program, and the declaration and payment thereof, will be based upon all relevant factors, including the Company’s financial position, results of operations, cash flows, capital requirements and restrictions under the Company’s Loan Agreement and other financing agreements, and shall be in compliance with applicable law.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-047613:notes:135]
Net Income Per Common Share
The following table presents the computation of basic and diluted income per common share:

[0001628280-25-047613:notes:136]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  |  | September 27,2024 |  |  |  |  |
|  | (in millions, except per share data) |
| Net income from continuing operations | $ | 1,182 |  |  |  | $ | 153 |  |  |  |  |  |
| Dividends allocated to preferred shareholders | (5) |  |  |  | (2) |  |  |  |  |  |
| Income attributable to participating securities(1) | (25) |  |  |  | (2) |  |  |  |  |  |
| Net income from continuing operations attributable to common shareholders - basic | 1,152 |  |  |  | 149 |  |  |  |  |  |
| Net income from discontinued operations, net of taxes, attributable to common shareholders | — |  |  |  | 332 |  |  |  |  |  |
| Net income attributable to common shareholders - basic | $ | 1,152 |  |  |  | $ | 481 |  |  |  |  |  |
| Net income from continuing operations attributable to common shareholders - basic | $ | 1,152 |  |  |  | $ | 149 |  |  |  |  |  |
| Re-allocation of participating securities considered potentially dilutive | 2 |  |  |  | — |  |  |  |  |  |
| Net income from continuing operations attributable to common shareholders - diluted | 1,154 |  |  |  | 149 |  |  |  |  |  |
| Net income from discontinued operations, net of taxes, attributable to common shareholders | — |  |  |  | 332 |  |  |  |  |  |
| Net income attributable to common shareholders - diluted | $ | 1,154 |  |  |  | $ | 481 |  |  |  |  |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |
| Basic | 345 |  |  |  | 344 |  |  |  |  |  |
| RSUs, PSUs, ESPP, and convertible notes | 31 |  |  |  | 13 |  |  |  |  |  |
| Diluted | 376 |  |  |  | 357 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 3.34 |  |  |  | $ | 0.43 |  |  |  |  |  |
| Discontinued operations | — |  |  |  | 0.97 |  |  |  |  |  |
| Net income per common share | 3.34 |  |  |  | 1.40 |  |  |  |  |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations | 3.07 |  |  |  | 0.42 |  |  |  |  |  |
| Discontinued operations | — |  |  |  | 0.93 |  |  |  |  |  |
| Net income per common share | 3.07 |  |  |  | 1.35 |  |  |  |  |  |

[0001628280-25-047613:notes:137]
(1)     Participating securities consist of preferred stock because it participates on a pro rata basis in any dividends declared on shares of common stock.

[0001628280-25-047613:notes:138]
Basic net income per common share is computed using (i) net income less (ii) dividends allocated to preferred shareholders less (iii) net income attributable to participating securities divided by (iv) basic weighted average shares outstanding. Diluted net income per common share is computed as (i) basic net income attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) diluted weighted average shares outstanding. The “if-converted” method is used to determine the dilutive impact for the convertible notes and the preferred shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.
Potentially dilutive common shares include dilutive outstanding RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and Preferred Shares. For the three months ended October 3, 2025 and September 27, 2024, based on the Company’s average stock price during the period, an insignificant number of common shares subject to outstanding equity awards were anti-dilutive.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001628280-25-047613:notes:139]
Legal Proceedings
Intellectual Property Litigation

[0001628280-25-047613:notes:140]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of October 3, 2025.

[0001628280-25-047613:notes:141]
Other Matters

[0001628280-25-047613:notes:142]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.

[0001628280-25-047613:notes:143]
The ability to predict the ultimate outcome of any legal proceeding involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-25-047613:notes:144]
Martin I. Cole, a director of the Company, adopted a Rule 10b5-1 Plan on August 1, 2025. Under this plan, up to an aggregate of 22,000 shares of the Company’s common stock may be sold before the plan expires on October 30, 2026.
