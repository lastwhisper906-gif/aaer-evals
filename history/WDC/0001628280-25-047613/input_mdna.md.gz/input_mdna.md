# WDC MD&A — 0001628280-25-047613


## mdna

[0001628280-25-047613:mdna:1]
[same as prior period, unchanged from 0000106040-25-000026:mdna:1]

[0001628280-25-047613:mdna:2]
[same as prior period, unchanged from 0000106040-25-000026:mdna:2]

[0001628280-25-047613:mdna:3]
[same as prior period, unchanged from 0000106040-25-000026:mdna:3]

[0001628280-25-047613:mdna:4]
We are a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology. We leverage our capability in the HDD industry primarily for the cloud and hyperscale data center markets. HDDs are critical components in the worldwide data infrastructure market, powering the digital economy. HDDs provide reliable, cost-effective, high-capacity storage needs for a wide range of applications, ranging from cloud data centers, enterprise storage systems, edge computing, video surveillance to client and consumer.

[0001628280-25-047613:mdna:5]
Our broad portfolio of technology and products addresses our customers’ storage needs through multiple end markets: “Cloud,” “Client” and “Consumer”. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0001628280-25-047613:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2026, which will end on July 3, 2026, will be comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with all quarters presented consisting of 13 weeks.

[0001628280-25-047613:mdna:7]
[same as prior period, unchanged from 0000106040-25-000026:mdna:7]

[0001628280-25-047613:mdna:8]
[same as prior period, unchanged from 0000106040-25-000026:mdna:8]

[0001628280-25-047613:mdna:9]
On February 21, 2025 (the “Separation Date”), we completed the separation of our HDD and Flash business units (the “Separation”) to create two independent public companies, with Western Digital continuing our existing HDD business and Sandisk Corporation (“Sandisk”), formerly a wholly-owned subsidiary of the Company, holding the Flash business. We believe the Separation has better positioned us as a pure-play HDD company that can execute innovative technology and product development, capitalize on unique growth opportunities, extend our leadership position, operate more efficiently, and pursue capital allocation strategies to maximize long-term shareholder value. As part of the Separation, we initially retained 28.8 million shares of Sandisk common stock, of which 21.3 million shares were used in the three months ended June 27, 2025 in a tax-free exchange to reduce approximately $800 million principal amount of our term loan A-3. We expect to monetize our remaining stake in Sandisk within one year from the Separation Date.

[0001628280-25-047613:mdna:10]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation. See Part I, Item 1, Note 4, Discontinued Operations, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information regarding the Separation.

[0001628280-25-047613:mdna:11]
Macroeconomic Conditions and Outlook

[0001628280-25-047613:mdna:12]
The increasing long-term demand for data storage in the cloud is benefiting our HDD business. The adoption of artificial intelligence (“AI”) and data-driven workloads is driving growth in data storage as well. This creates an accelerated demand for high-capacity drives, resulting in greater manufacturing complexity and longer production lead times. In response, customers are partnering with us earlier to support their future growth requirements and are extending the duration of their commercial arrangements.

[0001628280-25-047613:mdna:13]
The United States has been making changes to its trade policy, including increasing tariffs on imports, in some cases significantly. Several of these tariff actions have been followed by announcements of limited exemptions, temporary pauses or other changes. These actions have caused substantial uncertainty and have also resulted in retaliatory measures. Our business and results of operations have not been materially impacted through the first quarter of 2026 as a result of the recent tariff actions, but we are actively monitoring developments and exploring opportunities to mitigate potential future tariff and retaliatory actions. For additional information, please see Part I, Item 1A, Risk Factors, included in our 2025 Annual Report on Form 10-K.

[0001628280-25-047613:mdna:14]
37

[0001628280-25-047613:mdna:15]
[same as prior period, unchanged from 0000106040-25-000026:mdna:19]

[0001628280-25-047613:mdna:16]
First Quarter Overview

[0001628280-25-047613:mdna:17]
[same as prior period, unchanged from 0000106040-25-000026:mdna:21]

[0001628280-25-047613:mdna:18]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | $ in millions |  |  |
| Revenue, net | $ | 2,818 |  |  | 100.0 | % |  | $ | 2,212 |  |  | 100.0 | % |  | $ | 606 |  |  | 27 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 1,591 |  |  | 56.5 |  |  | 1,406 |  |  | 63.6 |  |  | 185 |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,227 |  |  | 43.5 |  |  | 806 |  |  | 36.4 |  |  | 421 |  |  | 52 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 294 |  |  | 10.4 |  |  | 262 |  |  | 11.8 |  |  | 32 |  |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 138 |  |  | 4.9 |  |  | 204 |  |  | 9.2 |  |  | (66) |  |  | (32) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Litigation matter | — |  |  | — |  |  | 3 |  |  | 0.1 |  |  | (3) |  |  | (100) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business realignment charges | 3 |  |  | 0.1 |  |  | 3 |  |  | 0.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 435 |  |  | 15.4 |  |  | 472 |  |  | 21.3 |  |  | (37) |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 792 |  |  | 28.1 |  |  | 334 |  |  | 15.1 |  |  | 458 |  |  | 137 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 17 |  |  | 0.6 |  |  | 7 |  |  | 0.3 |  |  | 10 |  |  | 143 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (59) |  |  | (2.1) |  |  | (99) |  |  | (4.5) |  |  | 40 |  |  | (40) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on retained interest in Sandisk | 611 |  |  | 21.7 |  |  | — |  |  | — |  |  | 611 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (24) |  |  | (0.9) |  |  | 1 |  |  | — |  |  | (25) |  |  | (2,500) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other income (expense), net | 545 |  |  | 19.3 |  |  | (91) |  |  | (4.1) |  |  | 636 |  |  | (699) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 1,337 |  |  | 47.4 |  |  | 243 |  |  | 11.0 |  |  | 1,094 |  |  | 450 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 155 |  |  | 5.5 |  |  | 90 |  |  | 4.1 |  |  | 65 |  |  | 72 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,182 |  |  | 41.9 | % |  | $ | 153 |  |  | 6.9 | % |  | $ | 1,029 |  |  | 673 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-25-047613:mdna:19]
[same as prior period, unchanged from 0000106040-25-000026:mdna:23]

[0001628280-25-047613:mdna:20]
[same as prior period, unchanged from 0000106040-25-000026:mdna:27]

[0001628280-25-047613:mdna:21]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,510 |  |  | $ | 1,909 |  |  |  |  |  |
| Client | 146 |  |  | 139 |  |  |  |  |  |
| Consumer | 162 |  |  | 164 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,175 |  |  | $ | 686 |  |  |  |  |  |
| Americas | 1,100 |  |  | 1,247 |  |  |  |  |  |
| Europe, Middle East and Africa | 543 |  |  | 279 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |

[0001628280-25-047613:mdna:22]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer.

[0001628280-25-047613:mdna:23]
[same as prior period, unchanged from 0000106040-25-000026:mdna:29]

[0001628280-25-047613:mdna:24]
Comparison of Three Months Ended October 3, 2025 to Three Months Ended September 27, 2024

[0001628280-25-047613:mdna:25]
Net revenue increased by 27% for the three months ended October 3, 2025 from the comparable period in the prior year, primarily driven by a 3% increase in units sold and a 19% increase in average selling price per unit, primarily as a result of a shift in product mix to higher capacity drives. In addition, approximately 4 percentage points of growth was due to an increase in data storage systems revenues.

[0001628280-25-047613:mdna:26]
Cloud revenue increased by 31% for the three months ended October 3, 2025 from the comparable period in the prior year, primarily driven by a 5% increase in units sold and a 19% increase in average selling price per unit. The increase in units sold was driven by higher shipments of our high-capacity enterprise products. The increase in average selling price per unit was primarily due to a shift in product mix to higher capacity drives. In addition, approximately 6 percentage points of growth was due to an increase in data storage systems revenues.

[0001628280-25-047613:mdna:27]
Client revenue increased by 5% for the three months ended October 3, 2025 from the comparable period in the prior year, primarily driven by an 11% increase in average selling price per unit, partially offset by a 6% decrease in units sold. The increase in average selling price per unit and decrease in units were both due to a shift in product mix to higher capacity drives.

[0001628280-25-047613:mdna:28]
Consumer revenue for the three months ended October 3, 2025 was relatively flat compared to the comparable period in the prior year with both volume and pricing being relatively consistent.

[0001628280-25-047613:mdna:29]
Net revenue by geography for the three months ended October 3, 2025 compared to the prior year period reflects higher revenue in the Asia and Europe, Middle East and Africa regions as customers expand data center capacity in these regions.

[0001628280-25-047613:mdna:30]
Our top 10 customers accounted for 77% of our net revenue for the three months ended October 3, 2025, compared to 65% of our net revenue for the three months ended September 27, 2024. For the three months ended October 3, 2025, three customers accounted for 18%, 16% and 14%, respectively, of our net revenue, and for the three months ended September 27, 2024, one customer accounted for 18% of our net revenue.

[0001628280-25-047613:mdna:31]
[same as prior period, unchanged from 0000106040-25-000026:mdna:38]

[0001628280-25-047613:mdna:32]
Gross profit increased by $421 million for the three months ended October 3, 2025 from the comparable period in the prior year, primarily due to higher product shipments and improved pricing. Gross margin increased by 7 percentage points year over year, primarily due to higher volumes, product cost reductions and improved pricing.

[0001628280-25-047613:mdna:33]
[same as prior period, unchanged from 0000106040-25-000026:mdna:41]

[0001628280-25-047613:mdna:34]
Research and development (“R&D”) expense increased by $32 million for the three months ended October 3, 2025 from the comparable period in the prior year. The increase was driven by higher variable compensation and continued investment for innovation, technology and product development.

[0001628280-25-047613:mdna:35]
Selling, general and administrative (“SG&A”) expense decreased by $66 million for the three months ended October 3, 2025 from the comparable period in the prior year. The decrease primarily reflects $37 million lower compensation and benefits, which was driven by certain general corporate overhead roles in the prior year that have since transferred to Sandisk and were not backfilled after the Separation. The decrease also reflects $30 million lower service fees resulting from reduced marketing activities and legal costs.

[0001628280-25-047613:mdna:36]
For information regarding litigation matters, see Part I, Item 1, Note 14, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-25-047613:mdna:37]
For information regarding Business realignment charges, see Part I, Item 1, Note 10, Business Realignment Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-25-047613:mdna:38]
Interest and Other Income (Expense)

[0001628280-25-047613:mdna:39]
Total interest and other income (expense), changed by $636 million for the three months ended October 3, 2025 from the comparable period in the prior year. The change primarily reflects an unrealized gain of $611 million on our retained interest in Sandisk based on the mark-to-market value as of October 3, 2025, and lower interest expense of $40 million, which reflects the reduction in our debt.

[0001628280-25-047613:mdna:40]
[same as prior period, unchanged from 0000106040-25-000026:mdna:48]

[0001628280-25-047613:mdna:41]
Previously, the Tax Cuts and Jobs Act of 2017 (“TCJA”) eliminated the ability to deduct R&D expenditures in the year incurred, requiring capitalization and amortization under Internal Revenue Code Section 174. On July 4, 2025, the One Big Beautiful Bill Act of 2025 (“OBBBA”) was signed into law, which includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with 2026. The legislation also includes favorable modifications to international tax provisions, including changes to the Global Intangible Low-Taxed Income regime and enhancements to the Foreign-Derived Deduction Eligible Income (FDDEI) deduction that will become effective for us in 2027.

[0001628280-25-047613:mdna:42]
On August 16, 2022, the Inflation Reduction Act of 2022, was signed into law, which contained, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. Although CAMT became effective for us beginning with 2024, we were not subject to the CAMT of 15% for 2024 and 2025. We do not expect to be subject to CAMT in 2026 as our annual average AFSI did not exceed $1.0 billion for the preceding three-year period.

[0001628280-25-047613:mdna:43]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”). For 2026, we are subject to GMT in Thailand and the Philippines.

[0001628280-25-047613:mdna:44]
The following table presents our Income tax expense and the effective tax rate:

[0001628280-25-047613:mdna:45]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | $ in millions |
| Income before taxes | $ | 1,337 |  | $ | 243 |  |  |  |  |
| Income tax expense | 155 |  | 90 |  |  |  |  |
| Effective tax rate | 12% |  | 37% |  |  |  |  |

[0001628280-25-047613:mdna:46]
The primary drivers of the difference between the effective tax rate for the three months ended October 3, 2025 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for FDDEI, tax credits and the gain on the retained Sandisk interest being tax-free due to the Separation of the Flash business. These resulted in decreases to our effective tax rate below the U.S. Federal statutory rate for the three months ended October 3, 2025. Our income tax provision for the three months ended October 3, 2025 includes GMT taxes for Thailand and the Philippines, countries for which we maintain tax holidays.

[0001628280-25-047613:mdna:47]
The primary drivers of the difference between the effective tax rate for the three months ended September 27, 2024 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, tax credits, and tax holidays in Thailand and the Philippines. In addition, the effective tax rate for the three months ended September 27, 2024 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with IRS calculations.

[0001628280-25-047613:mdna:48]
40

[0001628280-25-047613:mdna:49]
[same as prior period, unchanged from 0000106040-25-000026:mdna:59]

[0001628280-25-047613:mdna:50]
The following table summarizes our statements of cash flows. Cash flows for the prior year period are presented on a consolidated basis and activity related to discontinued operations has not been segregated. See Part I, Item 1, Note 4, Discontinued Operations, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional cash flow information related to our discontinued operations.

[0001628280-25-047613:mdna:51]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 672 |  |  | $ | 34 |  |  |  |
| Investing activities | (57) |  |  | (45) |  |  |  |
| Financing activities | (678) |  |  | (102) |  |  |  |
| Effect of exchange rate changes on cash | (3) |  |  | 10 |  |  |  |
| Cash and cash equivalents reclassified to assets held for sale | — |  |  | (71) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (66) |  |  | $ | (174) |  |  |  |

[0001628280-25-047613:mdna:52]
[same as prior period, unchanged from 0000106040-25-000026:mdna:64]

[0001628280-25-047613:mdna:53]
We currently expect our capital expenditures for 2026 to be approximately 4% to 6% of our net revenue.

[0001628280-25-047613:mdna:54]
We believe our cash and cash equivalents and our available 2027 Revolving Credit Facility (as defined below) will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt and equity capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our 2025 Annual Report on Form 10-K.

[0001628280-25-047613:mdna:55]
A total of $1.23 billion and $0.98 billion of our cash and cash equivalents was held by our foreign subsidiaries as of October 3, 2025 and June 27, 2025, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0001628280-25-047613:mdna:56]
[same as prior period, unchanged from 0000106040-25-000026:mdna:68]

[0001628280-25-047613:mdna:57]
[same as prior period, unchanged from 0000106040-25-000026:mdna:70]

[0001628280-25-047613:mdna:58]
Net cash provided by operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $99 million for the three months ended October 3, 2025, compared to $753 million for the three months ended September 27, 2024. The year over year decrease largely reflects a $423 million improvement in timing and collection of accounts receivable, a $132 million improvement from accrued expenses resulting from a significant reduction in our derivative hedging activities since the Separation of the Flash business, and a $501 million improvement in other assets and liabilities driven by the timing of recognition and realization of income taxes receivable. These were partially offset by a $426 million increase in cash used driven by the timing of recognition and payment of income taxes.

[0001628280-25-047613:mdna:59]
[same as prior period, unchanged from 0000106040-25-000026:mdna:76]

[0001628280-25-047613:mdna:60]
Net cash used in investing activities for the three months ended October 3, 2025 primarily consisted of $73 million in capital expenditures, net of proceeds from disposals of assets. Net cash used in investing activities for the three months ended September 27, 2024 primarily consisted of $95 million in capital expenditures, net of proceeds from disposals of assets, partially offset by $47 million in net proceeds from activity related to Flash Ventures.

[0001628280-25-047613:mdna:61]
[same as prior period, unchanged from 0000106040-25-000026:mdna:78]

[0001628280-25-047613:mdna:62]
Net cash used in financing activities for the three months ended October 3, 2025 primarily consisted of $553 million for share repurchases, $39 million for dividends on our common stock and Preferred Shares, $55 million for taxes paid on vested stock awards under employee stock plans and $31 million for scheduled repayments on our term loan. Net cash used in financing activities for the three months ended September 27, 2024 primarily consisted of $64 million for taxes paid on vested stock awards under employee stock plans and $38 million for scheduled repayments on our term loan. During the three months ended September 27, 2024, we also drew and repaid $150 million under our 2027 Revolving Credit Facility.

[0001628280-25-047613:mdna:63]
[same as prior period, unchanged from 0000106040-25-000026:mdna:80]

[0001628280-25-047613:mdna:64]
[same as prior period, unchanged from 0000106040-25-000026:mdna:81]

[0001628280-25-047613:mdna:65]
[same as prior period, unchanged from 0000106040-25-000026:mdna:83]

[0001628280-25-047613:mdna:66]
[same as prior period, unchanged from 0000106040-25-000026:mdna:84]

[0001628280-25-047613:mdna:67]
The following is a summary of our known material cash requirements as of October 3, 2025. In addition, see the discussions further below related to liability for unrecognized tax benefits, litigation matters, cash dividend program, dividend rights with respect to the Preferred Shares, global minimum tax, foreign exchange contracts and indemnifications.

[0001628280-25-047613:mdna:68]
|  | Total |  | 1 Year (Remaining Nine Months of 2026) |  | 2-3 Years (2027-2028) |  | 4-5 Years (2029-2030) |  | More than 5 Years (Beyond 2030) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 4,717 |  |  | $ | 2,194 |  |  | $ | 1,523 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 448 |  |  | 146 |  |  | 202 |  |  | 69 |  |  | 31 |  |
| Operating leases | 154 |  |  | 25 |  |  | 53 |  |  | 30 |  |  | 46 |  |
| Purchase obligations and other commitments | 62 |  |  | 35 |  |  | 27 |  |  | — |  |  | — |  |
| Total | $ | 5,381 |  |  | $ | 2,400 |  |  | $ | 1,805 |  |  | $ | 599 |  |  | $ | 577 |  |

[0001628280-25-047613:mdna:69]
[same as prior period, unchanged from 0000106040-25-000026:mdna:87]

[0001628280-25-047613:mdna:70]
Liability for Unrecognized Tax Benefits

[0001628280-25-047613:mdna:71]
As of October 3, 2025, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $598 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of October 3, 2025 was $93 million. Of these amounts, approximately $130 million could result in potential cash payments to be made within the next twelve months.

[0001628280-25-047613:mdna:72]
Litigation Matters

[0001628280-25-047613:mdna:73]
For additional information on our litigation matters, see Part I, Item 1, Note 14, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-25-047613:mdna:74]
[same as prior period, unchanged from 0000106040-25-000026:mdna:94]

[0001628280-25-047613:mdna:75]
On April 29, 2025, our Board of Directors authorized the adoption of a cash dividend program. Under the cash dividend program, holders of our common stock will receive dividends when and as declared by our Board of Directors. During the three months ended October 3, 2025, we paid cash dividends of $0.10 per share of our outstanding common stock, totaling $34 million, plus $1 million paid to holders of our Preferred Shares in accordance with their participation rights.

[0001628280-25-047613:mdna:76]
Subsequent to quarter-end, on October 29, 2025, our Board of Directors declared a cash dividend of $0.125 per share of our common stock, which will be paid on December 18, 2025 to our shareholders of record as of the close of business on December 4, 2025.

[0001628280-25-047613:mdna:77]
We may modify, suspend, or cancel our cash dividend program in any manner and at any time. The amount of future dividends under our cash dividend program, and the declaration and payment thereof, will be based upon all relevant factors, including our financial position, results of operations, cash flows, capital requirements and restrictions under our Loan Agreement and other financing agreements, and shall be in compliance with applicable law.

[0001628280-25-047613:mdna:78]
[same as prior period, unchanged from 0000106040-25-000026:mdna:96]

[0001628280-25-047613:mdna:79]
As of October 3, 2025, 235,000 shares of our Preferred Shares remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in our 2025 Annual Report on Form 10-K and Part I, Item 1, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0001628280-25-047613:mdna:80]
[same as prior period, unchanged from 0000106040-25-000026:mdna:98]

[0001628280-25-047613:mdna:81]
As described in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, the Company issued $1.60 billion aggregate principal amount of convertible senior notes in November 2023, which bear interest at an annual rate of 3.00% and mature on November 15, 2028 (the “2028 Convertible Notes”). The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028 at a conversion price of approximately $37.77 per share of common stock (as adjusted in accordance with the indenture as a result of the Separation and the payment of dividends on the Company’s common stock). Prior to August 15, 2028, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, we may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at our option, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of our redemption notice.

[0001628280-25-047613:mdna:82]
The sale price conditional conversion feature of the 2028 Convertible Notes was triggered during the calendar quarter ended September 30, 2025 and, accordingly, the holders of the 2028 Convertible Notes have the right to convert the notes during the succeeding calendar quarter ending December 31, 2025. As a result, the 2028 Convertible Notes have been classified as Current portion of long-term debt in the Condensed Consolidated Financial Statements as of October 3, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

[0001628280-25-047613:mdna:83]
In addition to our outstanding debt, as of October 3, 2025, we had $1.25 billion available for borrowing under our revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”), subject to customary conditions under the Loan Agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. The Loan Agreement requires us to comply with a financial leverage ratio covenant. As of October 3, 2025, we were in compliance with the financial covenant. Additional information regarding our indebtedness, including information about availability under our 2027 Revolving Credit Facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our 2025 Annual Report on Form 10-K and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001628280-25-047613:mdna:84]
[same as prior period, unchanged from 0000106040-25-000026:mdna:104]

[0001628280-25-047613:mdna:85]
[same as prior period, unchanged from 0000106040-25-000026:mdna:105]

[0001628280-25-047613:mdna:86]
[same as prior period, unchanged from 0000106040-25-000026:mdna:106]

[0001628280-25-047613:mdna:87]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Current assets | $ | 3,115 |  |  | $ | 2,992 |  |
| Non-current assets | 4,502 |  |  | 4,553 |  |
| Net intercompany payables to non-guarantor subsidiaries | (1,679) |  |  | (1,543) |  |
| Current liabilities | 3,317 |  |  | 3,800 |  |
| Non-current liabilities | 2,848 |  |  | 2,873 |  |

[0001628280-25-047613:mdna:88]
[same as prior period, unchanged from 0000106040-25-000026:mdna:108]

[0001628280-25-047613:mdna:89]
|  | Three Months Ended |  | Year Ended |
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Net sales | $ | 1,158 |  |  | $ | 5,249 |  |
| Gross profit | 459 |  |  | 1,941 |  |
| Operating income | 107 |  |  | 279 |  |
| Net income (loss) | 550 |  |  | (320) |  |

[0001628280-25-047613:mdna:90]
[same as prior period, unchanged from 0000106040-25-000026:mdna:110]

[0001628280-25-047613:mdna:91]
|  | Three Months Ended |  | Year Ended |
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Intercompany revenue | $ | 1,715 |  |  | $ | 1,378 |  |
| Net intercompany interest (income) expense | — |  |  | (4) |  |
| Intercompany dividend income | 33 |  |  | 2,215 |  |

[0001628280-25-047613:mdna:92]
[same as prior period, unchanged from 0000106040-25-000026:mdna:113]

[0001628280-25-047613:mdna:93]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions, such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0001628280-25-047613:mdna:94]
Global Minimum Tax

[0001628280-25-047613:mdna:95]
As of October 3, 2025, we have accrued GMT taxes of $21 million that are not expected to be paid until the second quarter of 2028.

[0001628280-25-047613:mdna:96]
[same as prior period, unchanged from 0000106040-25-000026:mdna:119]

[0001628280-25-047613:mdna:97]
[same as prior period, unchanged from 0000106040-25-000026:mdna:120]

[0001628280-25-047613:mdna:98]
[same as prior period, unchanged from 0000106040-25-000026:mdna:121]

[0001628280-25-047613:mdna:99]
[same as prior period, unchanged from 0000106040-25-000026:mdna:122]

[0001628280-25-047613:mdna:100]
[same as prior period, unchanged from 0000106040-25-000026:mdna:123]

[0001628280-25-047613:mdna:101]
[same as prior period, unchanged from 0000106040-25-000026:mdna:124]

[0001628280-25-047613:mdna:102]
[same as prior period, unchanged from 0000106040-25-000026:mdna:125]

[0001628280-25-047613:mdna:103]
[same as prior period, unchanged from 0000106040-25-000026:mdna:126]

[0001628280-25-047613:mdna:104]
[same as prior period, unchanged from 0000106040-25-000026:mdna:127]

[0001628280-25-047613:mdna:105]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our 2025 Annual Report on Form 10‑K. Please refer to Part II, Item 7 of our 2025 Annual Report on Form 10‑K for a discussion of our critical accounting policies and estimates.

[0001628280-25-047613:mdna:106]
[same as prior period, unchanged from 0000106040-25-000026:mdna:58]
