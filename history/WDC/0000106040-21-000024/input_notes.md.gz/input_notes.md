# WDC notes — 0000106040-21-000024


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-21-000024:notes:1]
[same as prior period, unchanged from 0000106040-21-000011:notes:1]

[0000106040-21-000024:notes:2]
[same as prior period, unchanged from 0000106040-21-000011:notes:2]

[0000106040-21-000024:notes:3]
[same as prior period, unchanged from 0000106040-21-000011:notes:3]

[0000106040-21-000024:notes:4]
[same as prior period, unchanged from 0000106040-21-000011:notes:4]

[0000106040-21-000024:notes:5]
[same as prior period, unchanged from 0000106040-21-000011:notes:5]

[0000106040-21-000024:notes:6]
[same as prior period, unchanged from 0000106040-21-000011:notes:6]

[0000106040-21-000024:notes:7]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, including the effects of ongoing vaccination efforts, how quickly and to what extent normal economic and operating activity can resume, and the severity and duration of the global economic downturn that results from the pandemic.

[0000106040-21-000024:notes:8]
[same as prior period, unchanged from 0000106040-21-000011:notes:8]

[0000106040-21-000024:notes:9]
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker, announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). To align with the new operating model and business structure, the Company is making management organizational changes and implementing new reporting modules and processes to provide discrete information to manage the business.  Management expects to finalize its assessment of its operating segments when the implementations and transitions are completed, which is expected to be in the first quarter of fiscal 2022.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-21-000024:notes:10]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-21-000024:notes:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Updates (“ASU”) No. 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2019, which for the Company is the first quarter of fiscal 2021. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-21-000024:notes:12]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted Accounting Standards Codification (ASC) 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its Condensed Consolidated Financial Statements.

[0000106040-21-000024:notes:13]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-21-000024:notes:14]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2020, which for the Company is the first quarter of fiscal 2022. Early adoption is permitted. The Company does not expect this update to have a material impact on its Condensed Consolidated Financial Statements.

[0000106040-21-000024:notes:15]
In August 2020, the FASB issued ASU No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. For instruments that do not have a component mandatorily settled in cash, the change will likely result in a higher amount of share dilution in the calculation of earnings per share. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of fiscal 2023, with early adoption permitted beginning in the first quarter of fiscal 2022. The Company is currently assessing the impact and timing of adoption of this ASU.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-21-000024:notes:16]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either April 2, 2021 or July 3, 2020.

[0000106040-21-000024:notes:17]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of April 2, 2021 and July 3, 2020 as well as the related amortization for the three and nine months ended April 2, 2021 and April 3, 2020 were not material.

[0000106040-21-000024:notes:18]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of April 2, 2021 and July 3, 2020, contract liabilities were not material.

[0000106040-21-000024:notes:19]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of April 2, 2021 was $81 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $10 million during the remainder of fiscal 2021, $40 million in fiscal 2022, and $31 million in fiscal 2023 and thereafter.

[0000106040-21-000024:notes:20]
[same as prior period, unchanged from 0000106040-21-000011:notes:19]

[0000106040-21-000024:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,962 |  |  | $ | 2,114 |  |  | $ | 5,715 |  |  | $ | 6,918 |  |  |  |
| Flash-based | 2,175 |  |  | 2,061 |  |  | 6,287 |  |  | 5,531 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,012 |  |  | $ | 1,831 |  |  | $ | 6,089 |  |  | $ | 5,244 |  |  |  |
| Data Center Devices & Solutions | 1,237 |  |  | 1,523 |  |  | 3,173 |  |  | 4,544 |  |  |  |
| Client Solutions | 888 |  |  | 821 |  |  | 2,740 |  |  | 2,661 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,009 |  |  | $ | 1,325 |  |  | $ | 3,033 |  |  | $ | 3,934 |  |  |  |
| Europe, Middle East and Africa | 913 |  |  | 770 |  |  | 2,267 |  |  | 2,360 |  |  |  |
| Asia | 2,215 |  |  | 2,080 |  |  | 6,702 |  |  | 6,155 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |

[0000106040-21-000024:notes:22]
The Company’s top 10 customers accounted for 42% and 40% of its net revenue for the three and nine months ended April 2, 2021, respectively, and 44% of its net revenue for both the three and nine months ended April 3, 2020. For the three and nine months ended April 2, 2021 and April 3, 2020, no single customer accounted for 10% or more of the Company’s net revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-21-000024:notes:23]
[same as prior period, unchanged from 0000106040-21-000011:notes:22]

[0000106040-21-000024:notes:24]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. During the nine months ended April 2, 2021 and April 3, 2020, the Company sold trade accounts receivable and received cash proceeds of $233 million and $298 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income (expense), net in the Condensed Consolidated Statements of Operations. As of April 2, 2021 and July 3, 2020, the amount of factored receivables that remained outstanding was $60 million and $113 million, respectively.

[0000106040-21-000024:notes:25]
[same as prior period, unchanged from 0000106040-21-000011:notes:24]

[0000106040-21-000024:notes:26]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,570 |  |  | $ | 1,306 |  |
| Work-in-process | 1,109 |  |  | 956 |  |
| Finished goods | 1,004 |  |  | 808 |  |
| Total inventories | $ | 3,683 |  |  | $ | 3,070 |  |

[0000106040-21-000024:notes:27]
[same as prior period, unchanged from 0000106040-21-000011:notes:26]

[0000106040-21-000024:notes:28]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 278 |  |  | $ | 294 |  |
| Buildings and improvements | 1,820 |  |  | 1,837 |  |
| Machinery and equipment | 7,832 |  |  | 7,391 |  |
| Computer equipment and software | 456 |  |  | 429 |  |
| Furniture and fixtures | 52 |  |  | 52 |  |
| Construction-in-process | 411 |  |  | 297 |  |
| Property, plant and equipment, gross | 10,849 |  |  | 10,300 |  |
| Accumulated depreciation | (7,788) |  |  | (7,446) |  |
| Property, plant and equipment, net | $ | 3,061 |  |  | $ | 2,854 |  |

[0000106040-21-000024:notes:29]
[same as prior period, unchanged from 0000106040-21-000011:notes:28]

[0000106040-21-000024:notes:30]
|  | Carrying Amount |
|  | (in millions) |
| Balance at July 3, 2020 | $ | 10,067 |  |
| Foreign currency translation adjustment | (1) |  |
| Balance at April 2, 2021 | $ | 10,066 |  |

[0000106040-21-000024:notes:31]
[same as prior period, unchanged from 0000106040-21-000011:notes:30]

[0000106040-21-000024:notes:32]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,507 |  |  | $ | 5,541 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,068) |  |  | (4,680) |  |
| Intangible assets, net | $ | 519 |  |  | $ | 941 |  |

[0000106040-21-000024:notes:33]
[same as prior period, unchanged from 0000106040-21-000011:notes:32]

[0000106040-21-000024:notes:34]
[same as prior period, unchanged from 0000106040-21-000011:notes:33]

[0000106040-21-000024:notes:35]
[same as prior period, unchanged from 0000106040-21-000011:notes:34]

[0000106040-21-000024:notes:36]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 366 |  |  | $ | 378 |  |  | $ | 408 |  |  | $ | 350 |  |  |  |
| Charges to operations | 27 |  |  | 45 |  |  | 86 |  |  | 144 |  |  |  |
| Utilization | (27) |  |  | (41) |  |  | (82) |  |  | (124) |  |  |  |
| Changes in estimate related to pre-existing warranties | (9) |  |  | 1 |  |  | (55) |  |  | 13 |  |  |  |
| Warranty accrual, end of period | $ | 357 |  |  | $ | 383 |  |  | $ | 357 |  |  | $ | 383 |  |  |  |

[0000106040-21-000024:notes:37]
[same as prior period, unchanged from 0000106040-21-000011:notes:36]

[0000106040-21-000024:notes:38]
|  | April 2,2021 |  | July 3,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 163 |  |  | $ | 205 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 194 |  |  | 203 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 357 |  |  | $ | 408 |  |  |  |  |  |  |  |

[0000106040-21-000024:notes:39]
[same as prior period, unchanged from 0000106040-21-000011:notes:38]

[0000106040-21-000024:notes:40]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 694 |  |  | $ | 815 |  |
| Payables related to unrecognized tax benefits | 743 |  |  | 720 |  |
| Other non-current liabilities | 844 |  |  | 881 |  |
| Total other liabilities | $ | 2,281 |  |  | $ | 2,416 |  |

[0000106040-21-000024:notes:41]
[same as prior period, unchanged from 0000106040-21-000011:notes:40]

[0000106040-21-000024:notes:42]
[same as prior period, unchanged from 0000106040-21-000011:notes:41]

[0000106040-21-000024:notes:43]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 3, 2020 | $ | (58) |  |  | $ | (2) |  |  |  |  |  |  | $ | (97) |  |  | $ | (157) |  |
| Other comprehensive loss before reclassifications | 4 |  |  | (29) |  |  |  |  |  |  | (39) |  |  | (64) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 5 |  |  | 5 |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | — |  |  |  |  |  |  | 6 |  |  | 6 |  |
| Net current-period other comprehensive loss | 4 |  |  | (29) |  |  |  |  |  |  | (28) |  |  | (53) |  |
| Balance at April 2, 2021 | $ | (54) |  |  | $ | (31) |  |  |  |  |  |  | $ | (125) |  |  | $ | (210) |  |

[0000106040-21-000024:notes:44]
During the three and nine months ended April 2, 2021, the amounts reclassified out of AOCI related to interest rate swap contracts were losses of $13 million and $37 million, respectively, and were charged to Interest expense.  These were offset by gains of $14 million and $32 million, respectively, related to foreign exchange contracts that were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations. During the three and nine months ended April 3, 2020, the amounts reclassified out of AOCI primarily related to foreign exchange contracts and were substantially all charged to Cost of revenue in the Condensed Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-21-000024:notes:45]
[same as prior period, unchanged from 0000106040-21-000011:notes:44]

[0000106040-21-000024:notes:46]
[same as prior period, unchanged from 0000106040-21-000011:notes:45]

[0000106040-21-000024:notes:47]
[same as prior period, unchanged from 0000106040-21-000011:notes:46]

[0000106040-21-000024:notes:48]
[same as prior period, unchanged from 0000106040-21-000011:notes:47]

[0000106040-21-000024:notes:49]
[same as prior period, unchanged from 0000106040-21-000011:notes:48]

[0000106040-21-000024:notes:50]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of April 2, 2021 and July 3, 2020, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-21-000024:notes:51]
|  | April 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 784 |  |  | $ | — |  |  | $ | — |  |  | $ | 784 |  |
| Foreign exchange contracts | — |  |  | 52 |  |  | — |  |  | 52 |  |
| Total assets at fair value | $ | 784 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 836 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 113 |  |  | $ | — |  |  | $ | 113 |  |
| Interest rate swap contract | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 204 |  |  | $ | — |  |  | $ | 204 |  |

[0000106040-21-000024:notes:52]
[same as prior period, unchanged from 0000106040-21-000011:notes:51]

[0000106040-21-000024:notes:53]
During the three and nine months ended April 2, 2021 and April 3, 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-21-000024:notes:54]
[same as prior period, unchanged from 0000106040-21-000011:notes:53]

[0000106040-21-000024:notes:55]
The carrying value of the Company’s revolving credit facility approximates its fair value given the revolving nature of the balance and the variable market interest rate. For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the third quarter of fiscal 2021 and the fourth quarter of fiscal 2020, respectively.

[0000106040-21-000024:notes:56]
|  | April 2, 2021 |  | July 3, 2020 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | 30 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,389 |  |  | 4,405 |  |  | 4,576 |  |  | 4,474 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,243 |  |  | 1,244 |  |  | 1,692 |  |  | 1,656 |  |
| 1.50% convertible notes due 2024 | 1,010 |  |  | 1,142 |  |  | 987 |  |  | 1,036 |  |
| 4.75% senior unsecured notes due 2026 | 2,287 |  |  | 2,534 |  |  | 2,286 |  |  | 2,428 |  |
| Total | $ | 8,929 |  |  | $ | 9,325 |  |  | $ | 9,575 |  |  | $ | 9,624 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-21-000024:notes:57]
Derivative Instruments and Hedging Activities
As of April 2, 2021, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-21-000024:notes:58]
As of April 2, 2021, the amount of existing net losses related to cash flow hedges recorded in AOCI included $42 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of April 2, 2021, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-21-000024:notes:59]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and nine months ended April 2, 2021 and April 3, 2020, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-21-000024:notes:60]
[same as prior period, unchanged from 0000106040-21-000011:notes:59]

[0000106040-21-000024:notes:61]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of April 2, 2021 and July 3, 2020, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-21-000024:notes:62]
Debt
Debt consisted of the following as of April 2, 2021 and July 3, 2020:

[0000106040-21-000024:notes:63]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,394 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,243 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 9,037 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (108) |  |  | (136) |  |
| Subtotal | 8,929 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,678 |  |  | $ | 9,289 |  |

[0000106040-21-000024:notes:64]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 2, 2021, the Company was in compliance with these financial covenants.

[0000106040-21-000024:notes:65]
During the three and nine months ended April 2, 2021, the Company made voluntary prepayments totaling $150 million and $450 million, respectively, on its Term Loan B-4. In October 2020, the 0.50% convertible senior notes due 2020 were settled in full in accordance with their terms. On April 30, 2021, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-21-000024:notes:66]
[same as prior period, unchanged from 0000106040-21-000011:notes:64]

[0000106040-21-000024:notes:67]
[same as prior period, unchanged from 0000106040-21-000011:notes:65]

[0000106040-21-000024:notes:68]
[same as prior period, unchanged from 0000106040-21-000011:notes:66]

[0000106040-21-000024:notes:69]
|  | April 2,2021 |  | July 3,2020 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 366 |  |  | $ | 366 |  |  |  |
| Fair value of plan assets at end of period | 213 |  |  | 215 |  |  |  |
| Unfunded status | $ | 153 |  |  | $ | 151 |  |  |  |

[0000106040-21-000024:notes:70]
[same as prior period, unchanged from 0000106040-21-000011:notes:68]

[0000106040-21-000024:notes:71]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 152 |  |  | 150 |  |
| Net amount recognized | $ | 153 |  |  | $ | 151 |  |

[0000106040-21-000024:notes:72]
Net periodic benefit costs were not material for the three and nine months ended April 2, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-21-000024:notes:73]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-21-000024:notes:74]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-21-000024:notes:75]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of April 2, 2021 and July 3, 2020:

[0000106040-21-000024:notes:76]
|  | April 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 289 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 228 |  |  | 301 |  |
| Notes receivable, Flash Forward | 554 |  |  | 670 |  |
| Investment in Flash Partners | 200 |  |  | 203 |  |
| Investment in Flash Alliance | 294 |  |  | 300 |  |
| Investment in Flash Forward | 129 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,694 |  |  | $ | 1,875 |  |

[0000106040-21-000024:notes:77]
During the three and nine months ended April 2, 2021 and during the three and nine months ended April 3, 2020, the Company made net payments to Flash Ventures of $1.14 billion and $3.33 billion, and $842 million and $2.36 billion, respectively, for purchased flash-based memory wafers and net loans and investments.

[0000106040-21-000024:notes:78]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-21-000024:notes:79]
As of April 2, 2021 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $397 million and $407 million, respectively.

[0000106040-21-000024:notes:80]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 2, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-21-000024:notes:81]
|  | April 2,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,071 |  |
| Equity investments | 623 |  |
| Operating lease guarantees | 1,993 |  |
| Inventory and prepayments | 656 |  |
| Maximum estimable loss exposure | $ | 4,343 |  |

[0000106040-21-000024:notes:82]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-21-000024:notes:83]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million for the nine months ended April 3, 2020, which were recorded in Cost of revenue and primarily consisted of unabsorbed manufacturing overhead costs. During the nine months ended April 2, 2021, the Company recovered $75 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000024:notes:84]
In May 2019, the Company entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 2, 2021, remaining committed prepayments totaled $108 million.

[0000106040-21-000024:notes:85]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-21-000024:notes:86]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-21-000024:notes:87]
Off-Balance Sheet Liabilities

[0000106040-21-000024:notes:88]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-21-000024:notes:89]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 2, 2021.

[0000106040-21-000024:notes:90]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 221 |  |  | $ | 1,993 |  |

[0000106040-21-000024:notes:91]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of April 2, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 2, 2021:

[0000106040-21-000024:notes:92]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining three months of 2021 |  | $ | 146 |  |  | $ | 22 |  |  | $ | 168 |  |
| 2022 |  | 531 |  |  | 48 |  |  | 579 |  |
| 2023 |  | 419 |  |  | 65 |  |  | 484 |  |
| 2024 |  | 260 |  |  | 117 |  |  | 377 |  |
| 2025 |  | 96 |  |  | 108 |  |  | 204 |  |
| Thereafter |  | 45 |  |  | 136 |  |  | 181 |  |
| Total guarantee obligations |  | $ | 1,497 |  |  | $ | 496 |  |  | $ | 1,993 |  |

[0000106040-21-000024:notes:93]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of April 2, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-21-000024:notes:94]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and nine months ended April 2, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For both the three and nine months ended April 3, 2020, the Company recognized approximately 1% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 6% and 4% of Accounts receivable, net as of April 2, 2021 and July 3, 2020, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-21-000024:notes:95]
[same as prior period, unchanged from 0000106040-21-000011:notes:93]

[0000106040-21-000024:notes:96]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of April 2, 2021:

[0000106040-21-000024:notes:97]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | ($ in millions) |  |  |  |  |  |  |  |  |
| Remaining three months of 2021 | $ | 12 |  |  |  |  |  |  |  |  |  |
| 2022 | 40 |  |  |  |  |  |  |  |  |  |
| 2023 | 33 |  |  |  |  |  |  |  |  |  |
| 2024 | 33 |  |  |  |  |  |  |  |  |  |
| 2025 | 31 |  |  |  |  |  |  |  |  |  |
| Thereafter | 147 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 296 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | (50) |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 246 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 35 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 211 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 232 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.5 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.8 | % |  |  |  |  |  |  |  |  |

[0000106040-21-000024:notes:98]
[same as prior period, unchanged from 0000106040-21-000011:notes:96]

[0000106040-21-000024:notes:99]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
|  | (in millions) |
| Cost of operating leases | $ | 12 |  |  | $ | 12 |  |  | $ | 37 |  |  | $ | 42 |  |
| Cash paid for operating leases | 12 |  |  | 12 |  |  | 38 |  |  | 41 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 1 |  |  | 1 |  |  | 28 |  |  | 51 |  |

[0000106040-21-000024:notes:100]
[same as prior period, unchanged from 0000106040-21-000011:notes:98]

[0000106040-21-000024:notes:101]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of April 2, 2021, the Company had the following minimum long-term commitments:

[0000106040-21-000024:notes:102]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining three months of 2021 |  | $ | 106 |  |
| 2022 |  | 583 |  |
| 2023 |  | 498 |  |
| 2024 |  | 314 |  |
| 2025 |  | 148 |  |
| Thereafter |  | 190 |  |
| Total |  | $ | 1,839 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-21-000024:notes:103]
[same as prior period, unchanged from 0000106040-21-000011:notes:101]

[0000106040-21-000024:notes:104]
[same as prior period, unchanged from 0000106040-21-000011:notes:102]

[0000106040-21-000024:notes:105]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Options | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |  |  |
| RSUs and PSUs | 73 |  |  | 68 |  |  | 212 |  |  | 204 |  |  |  |
| ESPP | 10 |  |  | 9 |  |  | 27 |  |  | 23 |  |  |  |
| Total | $ | 83 |  |  | $ | 78 |  |  | $ | 239 |  |  | $ | 232 |  |  |  |

[0000106040-21-000024:notes:106]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 14 |  |  | $ | 13 |  |  | $ | 41 |  |  | $ | 38 |  |  |  |
| Research and development | 41 |  |  | 41 |  |  | 120 |  |  | 123 |  |  |  |
| Selling, general and administrative | 28 |  |  | 24 |  |  | 78 |  |  | 71 |  |  |  |
| Subtotal | 83 |  |  | 78 |  |  | 239 |  |  | 232 |  |  |  |
| Tax benefit | (11) |  |  | (9) |  |  | (35) |  |  | (32) |  |  |  |
| Total | $ | 72 |  |  | $ | 69 |  |  | $ | 204 |  |  | $ | 200 |  |  |  |

[0000106040-21-000024:notes:107]
[same as prior period, unchanged from 0000106040-21-000011:notes:105]

[0000106040-21-000024:notes:108]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of April 2, 2021:

[0000106040-21-000024:notes:109]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 586 |  |  | 2.6 |
| ESPP | 12 |  |  | 0.4 |
| Total unamortized compensation cost | $ | 598 |  |  |  |

[0000106040-21-000024:notes:110]
[same as prior period, unchanged from 0000106040-21-000011:notes:108]

[0000106040-21-000024:notes:111]
[same as prior period, unchanged from 0000106040-21-000011:notes:109]

[0000106040-21-000024:notes:112]
[same as prior period, unchanged from 0000106040-21-000011:notes:110]

[0000106040-21-000024:notes:113]
[same as prior period, unchanged from 0000106040-21-000011:notes:111]

[0000106040-21-000024:notes:114]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 3, 2020 | 2.7 |  |  | $ | 69.16 |  |  | 2.1 |  | $ | — |  |
| Exercised | (0.4) |  |  | 44.16 |  |  |  |  | $ | 5 |  |
| Canceled or expired | (0.7) |  |  | 75.09 |  |  |  |  |  |
| Options outstanding at April 2, 2021 | 1.6 |  |  | 72.26 |  |  | 1.45 |  | $ | 17 |  |
| Exercisable at April 2, 2021 | 1.6 |  |  | $ | 72.26 |  |  | 1.45 |  | $ | 17 |  |

[0000106040-21-000024:notes:115]
[same as prior period, unchanged from 0000106040-21-000011:notes:113]

[0000106040-21-000024:notes:116]
[same as prior period, unchanged from 0000106040-21-000011:notes:114]

[0000106040-21-000024:notes:117]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 3, 2020 | 13.3 |  |  | $ | 60.92 |  |  |  |
| Granted | 8.2 |  |  | 38.31 |  |  |  |
| Vested | (4.2) |  |  | 60.89 |  |  | $ | 178 |  |
| Forfeited | (1.2) |  |  | 57.20 |  |  |  |
| RSUs and PSUs outstanding at April 2, 2021 | 16.1 |  |  | 49.42 |  |  |  |

[0000106040-21-000024:notes:118]
[same as prior period, unchanged from 0000106040-21-000011:notes:116]

[0000106040-21-000024:notes:119]
[same as prior period, unchanged from 0000106040-21-000011:notes:117]

[0000106040-21-000024:notes:120]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the nine months ended April 2, 2021 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of April 2, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.

[0000106040-21-000024:notes:121]
[same as prior period, unchanged from 0000106040-21-000011:notes:119]

[0000106040-21-000024:notes:122]
[same as prior period, unchanged from 0000106040-21-000011:notes:120]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-21-000024:notes:123]
Income Tax Expense
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-21-000024:notes:124]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted in response to the COVID-19 pandemic in the U.S. The CARES Act, among other things, allows net operating losses arising in tax years 2018, 2019, and 2020 to be carried back to each of the five preceding taxable years to generate a refund of previously paid income taxes and increases the business interest expense limitation from 30% to 50% of adjusted taxable income for tax years 2019 and 2020. Additionally, countries around the world continue to implement emergency tax measures to provide relief similar to the CARES Act. The Company at present does not expect that any of the provisions of the CARES Act or the emergency tax measures around the world would result in a material cash benefit.

[0000106040-21-000024:notes:125]
On December 27, 2020, the Consolidated Appropriations Act (the “Appropriations Act”) was enacted to fund the federal government through their fiscal year, extend certain expiring tax provisions and provide additional emergency relief to individuals and businesses related to the COVID-19 pandemic in the U.S. The Company at present does not expect any of the provisions of the Appropriations Act to have a material impact on its Consolidated Financial Statements.

[0000106040-21-000024:notes:126]
On March 11, 2021, the American Rescue Plan Act of 2021 (the “Rescue Act”) was enacted to provide additional emergency relief to individuals and businesses related to the COVID-19 pandemic in the U.S. The Rescue Act includes certain business-related provisions, which the Company at present does not expect to have a material impact on its Consolidated Financial Statements. The Company continues to monitor and evaluate the regulatory and interpretive guidance related to the CARES Act, the Appropriations Act and the Rescue Act, as well as legislation in other jurisdictions.

[0000106040-21-000024:notes:127]
[same as prior period, unchanged from 0000106040-21-000011:notes:124]

[0000106040-21-000024:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
|  | ($ in millions) |
| Income (loss) before taxes | $ | 249 |  |  | $ | 46 |  |  | $ | 331 |  |  | $ | (231) |  |
| Income tax expense | 52 |  |  | 29 |  |  | 132 |  |  | 167 |  |
| Effective tax rate | 21 | % |  | 63 | % |  | 40 | % |  | (72) | % |

[0000106040-21-000024:notes:129]
The primary drivers of the effective tax rate for the three and nine months ended April 2, 2021, which resulted in a difference in the effective tax rate for the nine months ended April 2, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2031. In addition, the effective tax rate for the three and nine months ended April 2, 2021 includes discrete effects for increases to unrecognized tax benefits of $35 million as a result of ongoing discussions with various taxing authorities that are offset in part by a release of certain unrecognized tax benefits of $22 million as a result of business realignment activities. The effective tax rate for the nine months ended April 2, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes paid by the Company.

[0000106040-21-000024:notes:130]
The primary drivers of the difference between the effective tax rate for the three and nine months ended April 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-21-000024:notes:131]
As previously disclosed, the IRS issued statutory notices of deficiency with respect to adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The statutory notices of deficiency seek to increase the Company’s U.S. taxable income relating to the disputed items by an amount that would result in additional federal tax totaling approximately $516 million through fiscal year 2009 and totaling approximately $535 million for fiscal years 2010 through 2012, subject to interest and penalties. The Company filed petitions with the U.S. Tax Court with respect to the statutory notices of deficiency for fiscal years 2008 through 2009 and the fiscal years 2010 through 2012. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. In May 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2012. In September 2020 and December 2020, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2013 through 2015 that, if sustained, would result in additional federal tax totaling approximately $343 million. In March 2021, the IRS asserted penalties totaling $109 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2013 through 2015. The Company disagrees with the proposed adjustments relating to transfer pricing and related penalties, and continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS. Also in March 2021, the Company and the IRS tentatively reached a basis for resolving the intercompany payable balances matter for all fiscal years at issue and the impact was not material to the Consolidated Financial Statements.

[0000106040-21-000024:notes:132]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of April 2, 2021, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-21-000024:notes:133]
As of April 2, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $750 million. Accrued interest and penalties related to unrecognized tax benefits as of April 2, 2021 was approximately $133 million. Of these amounts, approximately $743 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-21-000024:notes:134]
[same as prior period, unchanged from 0000106040-21-000011:notes:131]

[0000106040-21-000024:notes:135]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
|  | (in millions, except per share data) |
| Net income (loss) | $ | 197 |  |  | $ | 17 |  |  | $ | 199 |  |  | $ | (398) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 306 |  |  | 299 |  |  | 305 |  |  | 298 |  |
| Employee stock options, RSUs, PSUs and ESPP | 7 |  |  | 4 |  |  | 3 |  |  | — |  |
| Basic and diluted | 313 |  |  | 303 |  |  | 308 |  |  | 298 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.06 |  |  | $ | 0.65 |  |  | $ | (1.34) |  |
| Diluted | $ | 0.63 |  |  | $ | 0.06 |  |  | $ | 0.65 |  |  | $ | (1.34) |  |
| Anti-dilutive potential common shares excluded | 1 |  |  | 3 |  |  | 7 |  |  | 15 |  |

[0000106040-21-000024:notes:136]
The Company computes basic income (loss) per common share using Net income (loss) and the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For the nine months ended April 3, 2020, the Company recorded net loss, and all shares subject to outstanding equity awards have been excluded for this period because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-21-000024:notes:137]
[same as prior period, unchanged from 0000106040-21-000011:notes:134]

[0000106040-21-000024:notes:138]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |  |  |
| Business Realignment | 2 |  |  | 7 |  |  | 27 |  |  | 37 |  |  |  |
| Total employee termination and other charges | 2 |  |  | 8 |  |  | 27 |  |  | 42 |  |  |  |
| Gain on disposition of assets: |  |  |  |  |  |  |  |  |  |
| Business Realignment | (70) |  |  | — |  |  | (70) |  |  | (17) |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | (68) |  |  | $ | 8 |  |  | $ | (43) |  |  | $ | 25 |  |  |  |

[0000106040-21-000024:notes:139]
[same as prior period, unchanged from 0000106040-21-000011:notes:136]

[0000106040-21-000024:notes:140]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. The Company recognized gains related to the disposition of assets associated with these activities of $70 million in the three and nine months ended April 2, 2021 and $17 million in the nine months ended April 3, 2020.

[0000106040-21-000024:notes:141]
The following table presents an analysis of the components of these activities against the reserve during the nine months ended April 2, 2021:

[0000106040-21-000024:notes:142]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 3, 2020 | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Charges | 24 |  |  | 3 |  |  | 27 |  |
| Cash payments | (34) |  |  | (3) |  |  | (37) |  |
| Accrual balance at April 2, 2021 | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-21-000024:notes:143]
[same as prior period, unchanged from 0000106040-21-000011:notes:140]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-21-000024:notes:144]
Legal Proceedings
Tax

[0000106040-21-000024:notes:145]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and a tentative resolution with respect to certain matters, see Note 12, Income Tax Expense.

[0000106040-21-000024:notes:146]
Other Matters

[0000106040-21-000024:notes:147]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
