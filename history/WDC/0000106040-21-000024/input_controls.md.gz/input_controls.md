# WDC 10-Q controls and the auditor's report


## item_4_controls

[0000106040-21-000024:item_4_controls:1]
Item 4.    Controls and Procedures

[0000106040-21-000024:item_4_controls:2]
As required by Rule 13a-15(b) promulgated by the Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Quarterly Report on Form 10-Q, our disclosure controls and procedures were effective.

[0000106040-21-000024:item_4_controls:3]
In the third quarter of fiscal 2021, we substantially completed the initial implementation of our enterprise resource planning system on a worldwide basis. These system changes resulted in the modification of certain processes and controls, but no changes materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. Going forward, we expect to make routine enhancements and modifications in the normal course of business. In addition, as noted previously, we are implementing new reporting modules and processes to provide more discrete information to support our new organizational structure. As we implement these enhancements and modifications in future periods, we will continue to assess the impact on our internal control over financial reporting.

[0000106040-21-000024:item_4_controls:4]
49
