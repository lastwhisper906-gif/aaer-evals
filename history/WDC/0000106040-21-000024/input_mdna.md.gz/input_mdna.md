# WDC MD&A — 0000106040-21-000024


## mdna

[0000106040-21-000024:mdna:1]
[same as prior period, unchanged from 0000106040-21-000011:mdna:1]

[0000106040-21-000024:mdna:2]
[same as prior period, unchanged from 0000106040-21-000011:mdna:2]

[0000106040-21-000024:mdna:3]
[same as prior period, unchanged from 0000106040-21-000011:mdna:3]

[0000106040-21-000024:mdna:4]
[same as prior period, unchanged from 0000106040-21-000011:mdna:4]

[0000106040-21-000024:mdna:5]
[same as prior period, unchanged from 0000106040-21-000011:mdna:5]

[0000106040-21-000024:mdna:6]
[same as prior period, unchanged from 0000106040-21-000011:mdna:6]

[0000106040-21-000024:mdna:7]
[same as prior period, unchanged from 0000106040-21-000011:mdna:7]

[0000106040-21-000024:mdna:8]
[same as prior period, unchanged from 0000106040-21-000011:mdna:8]

[0000106040-21-000024:mdna:9]
Late in the first quarter of fiscal 2021, we announced a decision to reorganize our business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. In the second fiscal quarter, to align with the new operating model and business structure, we began making management organizational changes and are implementing new reporting modules and processes to provide discrete information to manage the business. We are evaluating the impact of these changes on our discussion and analysis of our financial condition and results of operations and expect to modify our disclosures to align with this structure when the implementations and assessments are completed, which is expected to be in the first quarter of fiscal 2022.

[0000106040-21-000024:mdna:10]
COVID-19 Pandemic and Operational Update

[0000106040-21-000024:mdna:11]
As a result of the ongoing COVID-19 pandemic, governments and other authorities around the world, including federal, state and local authorities in the United States, have imposed measures intended to reduce its spread, including restrictions on freedom of movement and business operations such as travel bans, border closings, business limitations and closures (subject to exceptions for essential operations and businesses), quarantines and shelter-in-place orders. Although some of these governmental restrictions have since been lifted or scaled back, periodic surges of COVID-19 infections have resulted in the re-imposition of certain restrictions and may lead to other restrictions being re-implemented in response to efforts to reduce the spread of COVID-19. These measures may remain in place for a significant amount of time, and the effects of ongoing vaccination efforts and the emergence of new strains of the virus remain uncertain. In light of these events, we have taken actions to protect the health and safety of our employees while continuing to serve our global customers as an essential business. We have implemented more thorough sanitation practices as outlined by health organizations and instituted social distancing policies at our locations around the world, including working from home, limiting the number of employees attending meetings, reducing the number of people in our sites at any one time, and suspending employee travel. In addition, the

[0000106040-21-000024:mdna:12]
responses to COVID-19 taken by others in the supply chain have impacted our operations. As a result, we incurred charges of approximately $33 million and $94 million during the three and nine months ended April 2, 2021, respectively, primarily related to higher logistics costs, which were recorded in cost of revenue.

[0000106040-21-000024:mdna:13]
As an essential business, we continue to provide products and solutions that enable the proliferation of data and facilitate the sharing of information remotely, which has become more critical as much of the world is interacting from areas of self-isolation. Generally, demand for our products has remained solid during the pandemic. During the nine months ended April 2, 2021, we experienced lower sales in some of our capacity enterprise and Client Devices products as customers absorbed purchases made in recent quarters, but we also experienced increased sales in retail as COVID-19 restrictions eased, more brick and mortar businesses resumed operations. Continued work-from-home, distance learning, and at-home entertainment also supported demand.

[0000106040-21-000024:mdna:14]
Looking forward, we see positive indications of the progression of 5G ramp and the growth of gaming. We are making progress on completing customer qualifications and we expect revenue to increase as we progress through calendar 2021, led by the ramp of our 18-terabyte hard drives, as well as broad-based growth in flash. However, the COVID-19 environment remains dynamic and we cannot predict the duration of the pandemic and how demand may change as it continues to develop.

[0000106040-21-000024:mdna:15]
[same as prior period, unchanged from 0000106040-21-000011:mdna:14]

[0000106040-21-000024:mdna:16]
[same as prior period, unchanged from 0000106040-21-000011:mdna:15]

[0000106040-21-000024:mdna:17]
[same as prior period, unchanged from 0000106040-21-000011:mdna:16]

[0000106040-21-000024:mdna:18]
Since its inception, Flash Ventures’ primary manufacturing site has been located in Yokkaichi, Japan, which currently includes five wafer fabrication facilities. Production levels at the Yokkaichi site were temporarily reduced as a result of an unexpected power outage incident that occurred in the Yokkaichi region on June 15, 2019. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production. The incident resulted in a reduction of our flash wafer availability by approximately 4 exabytes. As a result of this power outage incident, we incurred aggregate charges of $68 million recorded in Cost of revenue in the nine months ended April 3, 2020, which primarily consisted of unabsorbed manufacturing overhead costs. During the nine months ended April 2, 2021, we recovered $75 million related to this incident from our insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000024:mdna:19]
In May 2019, we entered into additional agreements with Kioxia to extend Flash Ventures to a new wafer fabrication facility, known as “K1,” located in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, we agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of April 2, 2021, remaining committed prepayments totaled $108 million.

[0000106040-21-000024:mdna:20]
[same as prior period, unchanged from 0000106040-21-000011:mdna:19]

[0000106040-21-000024:mdna:21]
[same as prior period, unchanged from 0000106040-21-000011:mdna:20]

[0000106040-21-000024:mdna:22]
Third Quarter and Nine Month Overview

[0000106040-21-000024:mdna:23]
[same as prior period, unchanged from 0000106040-21-000011:mdna:22]

[0000106040-21-000024:mdna:24]
|  | Three Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 4,137 |  |  | 100.0 | % |  | $ | 4,175 |  |  | 100.0 | % |  | $ | (38) |  |  | (1) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,046 |  |  | 73.6 |  |  | 3,170 |  |  | 75.9 |  |  | (124) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,091 |  |  | 26.4 |  |  | 1,005 |  |  | 24.1 |  |  | 86 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 555 |  |  | 13.4 |  |  | 563 |  |  | 13.5 |  |  | (8) |  |  | (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 287 |  |  | 6.9 |  |  | 281 |  |  | 6.7 |  |  | 6 |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | (68) |  |  | (1.6) |  |  | 8 |  |  | 0.2 |  |  | (76) |  |  | (950) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 774 |  |  | 18.7 |  |  | 852 |  |  | 20.4 |  |  | (78) |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 317 |  |  | 7.7 |  |  | 153 |  |  | 3.7 |  |  | 164 |  |  | 107 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 2 |  |  | — |  |  | 6 |  |  | 0.1 |  |  | (4) |  |  | (67) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (81) |  |  | (2.0) |  |  | (99) |  |  | (2.4) |  |  | 18 |  |  | (18) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 11 |  |  | 0.3 |  |  | (14) |  |  | (0.3) |  |  | 25 |  |  | (179) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (68) |  |  | (1.6) |  |  | (107) |  |  | (2.6) |  |  | 39 |  |  | (36) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 249 |  |  | 6.0 |  |  | 46 |  |  | 1.1 |  |  | 203 |  |  | 441 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 52 |  |  | 1.3 |  |  | 29 |  |  | 0.7 |  |  | 23 |  |  | 79 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 197 |  |  | 4.8 |  |  | $ | 17 |  |  | 0.4 |  |  | 180 |  |  | 1,059 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000024:mdna:25]
[same as prior period, unchanged from 0000106040-21-000011:mdna:24]

[0000106040-21-000024:mdna:26]
[same as prior period, unchanged from 0000106040-21-000011:mdna:25]

[0000106040-21-000024:mdna:27]
|  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 12,002 |  |  | 100.0 | % |  | $ | 12,449 |  |  | 100.0 | % |  | $ | (447) |  |  | (4) | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 9,047 |  |  | 75.4 |  |  | 9,751 |  |  | 78.3 |  |  | (704) |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 2,955 |  |  | 24.6 |  |  | 2,698 |  |  | 21.7 |  |  | 257 |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,645 |  |  | 13.7 |  |  | 1,715 |  |  | 13.8 |  |  | (70) |  |  | (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 808 |  |  | 6.7 |  |  | 884 |  |  | 7.1 |  |  | (76) |  |  | (9) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | (43) |  |  | (0.4) |  |  | 25 |  |  | 0.2 |  |  | (68) |  |  | (272) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 2,410 |  |  | 20.1 |  |  | 2,624 |  |  | 21.1 |  |  | (214) |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 545 |  |  | 4.5 |  |  | 74 |  |  | 0.6 |  |  | 471 |  |  | 636 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 6 |  |  | — |  |  | 26 |  |  | 0.2 |  |  | (20) |  |  | (77) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (246) |  |  | (2.0) |  |  | (326) |  |  | (2.6) |  |  | 80 |  |  | (25) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 26 |  |  | 0.2 |  |  | (5) |  |  | — |  |  | 31 |  |  | (620) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (214) |  |  | (1.8) |  |  | (305) |  |  | (2.4) |  |  | 91 |  |  | (30) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before taxes | 331 |  |  | 2.8 |  |  | (231) |  |  | (1.9) |  |  | 562 |  |  | (243) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 132 |  |  | 1.1 |  |  | 167 |  |  | 1.3 |  |  | (35) |  |  | (21) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 199 |  |  | 1.7 |  |  | $ | (398) |  |  | (3.2) |  |  | 597 |  |  | (150) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-21-000024:mdna:28]
[same as prior period, unchanged from 0000106040-21-000011:mdna:27]

[0000106040-21-000024:mdna:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD | $ | 1,962 |  |  | $ | 2,114 |  |  | $ | 5,715 |  |  | $ | 6,918 |  |  |  |
| Flash-based | 2,175 |  |  | 2,061 |  |  | 6,287 |  |  | 5,531 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices | $ | 2,012 |  |  | $ | 1,831 |  |  | $ | 6,089 |  |  | $ | 5,244 |  |  |  |
| Data Center Devices & Solutions | 1,237 |  |  | 1,523 |  |  | 3,173 |  |  | 4,544 |  |  |  |
| Client Solutions | 888 |  |  | 821 |  |  | 2,740 |  |  | 2,661 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,009 |  |  | $ | 1,325 |  |  | $ | 3,033 |  |  | $ | 3,934 |  |  |  |
| Europe, Middle East and Africa | 913 |  |  | 770 |  |  | 2,267 |  |  | 2,360 |  |  |  |
| Asia | 2,215 |  |  | 2,080 |  |  | 6,702 |  |  | 6,155 |  |  |  |
| Total Revenue | $ | 4,137 |  |  | $ | 4,175 |  |  | $ | 12,002 |  |  | $ | 12,449 |  |  |  |

[0000106040-21-000024:mdna:30]
39

[0000106040-21-000024:mdna:31]
[same as prior period, unchanged from 0000106040-21-000011:mdna:29]

[0000106040-21-000024:mdna:32]
Comparison of Three Months Ended April 2, 2021 to Three Months Ended April 3, 2020

[0000106040-21-000024:mdna:33]
Net revenue decreased 1% for the three months ended April 2, 2021 compared to the three months ended April 3, 2020, which reflects declines in revenue of approximately 8 percentage points and 2 percentage points related to pricing per gigabyte of flash and HDD, respectively, largely offset by an increase in exabyte volume of flash sold.

[0000106040-21-000024:mdna:34]
Client Devices revenue increased 10% year over year. Higher volumes of flash contributed approximately 17 percentage points of growth. Continued strength in notebook and desktop PC demand, along with new game console ramps, drove solid revenue growth. These increases were slightly offset by lower average pricing per gigabyte on flash products. Client Devices revenue for HDD products were relatively flat.

[0000106040-21-000024:mdna:35]
Data Center Devices and Solutions revenue declined 19% year over year, with approximately 12 percentage points of decline related to volume, primarily in HDD, and 7 percentage points driven by lower pricing per gigabyte in both HDD and flash products. Year-over-year volume was impacted by cloud digestion, which we believe is abating, and China shipment restrictions. However, we experienced growth with our second generation, NVMe enterprise SSD at a cloud titan. In addition, many cloud customers are utilizing NAND flash for their consumer product lines, creating additional end-market opportunities for us as we continue to diversify and balance the end markets served. Qualifications of our energy-assisted hard drives have also been completed with nearly all cloud and enterprise customers, including all cloud titans.

[0000106040-21-000024:mdna:36]
Client Solutions revenue increased 8% year over year with approximately 13 percentage points driven by volume growth. This remains a high performing end market, reflecting our brand recognition, broad product portfolio, and extensive distribution channels which continue to distinguish us from our competitors. This growth was partially offset by lower pricing.

[0000106040-21-000024:mdna:37]
Comparison of Nine Months Ended April 2, 2021 to Nine Months Ended April 3, 2020

[0000106040-21-000024:mdna:38]
Net revenue decreased 4% for the nine months ended April 2, 2021 from the comparable period in the prior year, reflecting an approximate 11 percentage point decline related to pricing per gigabyte for both HDD and flash products, partially offset by higher volumes in flash. Client Devices revenue increased 16% year over year, with approximately 27 percentage points of growth coming from higher volumes of flash, for the same reasons noted above for the quarter. This increase was partially offset by lower average selling prices per gigabyte in both flash and HDD as well as lower volumes of HDD. Revenue for Data Center Devices and Solutions declined 30% year over year, with approximately 26 percentage points attributed to lower volumes, which also reflects the drivers noted above for the quarter, with the remainder primarily attributable to lower pricing.  Client Solutions revenue increased 3% year over year, reflecting approximately 9 percentage points of increase from higher volumes with solid retail demand, partially offset by an approximate 6 percentage point decline related to lower pricing.

[0000106040-21-000024:mdna:39]
The changes in net revenue by geography for both the three- and nine-month periods reflect an increase in Asia due to our increased sales of mobility products to manufacturers in the Asia region, and a decrease in the Americas driven by lower sales of capacity enterprise products.

[0000106040-21-000024:mdna:40]
Our top 10 customers accounted for 42% and 40% of our net revenue for the three and nine months ended April 2, 2021, respectively, and 44% for both the three and nine months ended April 3, 2020. For the three and nine months ended April 2, 2021 and April 3, 2020, no single customer accounted for 10% or more of our net revenue.

[0000106040-21-000024:mdna:41]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three and nine months ended April 2, 2021 and April 3, 2020, these programs represented 18% and 19% and 15% and 16%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The increase in adjustments year over year reflects the current competitive environment. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-21-000024:mdna:42]
40

[0000106040-21-000024:mdna:43]
[same as prior period, unchanged from 0000106040-21-000011:mdna:38]

[0000106040-21-000024:mdna:44]
Gross profit increased by $86 million for the three months ended April 2, 2021 from the comparable period in the prior year, which reflects a $106 million decrease in charges in the current year related to amortization expense on acquired intangible assets, partially offset by lower contribution from lower revenues.

[0000106040-21-000024:mdna:45]
Gross margin increased approximately 2 percentage points for the three months ended April 2, 2021 from the comparable period in the prior year, substantially all of which is attributed to the impacts of the lower charges for amortization of acquired intangible assets.

[0000106040-21-000024:mdna:46]
Gross profit increased by $257 million for the nine months ended April 2, 2021 from the comparable period in the prior year, which reflects the power outage charges of $68 million incurred in the prior year compared to the $75 million partial recovery in the current year and a $173 million decrease in charges in the current year related to amortization expense on acquired intangible assets, partially offset by lower contribution from lower revenues.

[0000106040-21-000024:mdna:47]
Gross margin increased approximately 3 percentage points for the nine months ended April 2, 2021 from the comparable period in the prior year, substantially all of which is attributed to the impacts of the charges related to the power outage incident in the prior year, the insurance recovery in the current year and the lower charges for amortization of acquired intangible assets noted above. Over the near term, we expect flash gross margin to benefit from improved pricing and cost reductions while HDD gross margin is expected to improve as we ramp production on higher capacity drives.

[0000106040-21-000024:mdna:48]
[same as prior period, unchanged from 0000106040-21-000011:mdna:43]

[0000106040-21-000024:mdna:49]
Research and development (“R&D”) expense decreased $8 million for the three months ended April 2, 2021 from the comparable period in the prior year. The decrease was driven by lower materials expenses of approximately $20 million and lower travel and entertainment expenses due to the COVID-19 restrictions of approximately $10 million, partially offset by higher variable compensation costs as a result of improved earnings. R&D expense decreased $70 million for the nine months ended April 2, 2021 from the comparable period in the prior year. The decrease was driven by lower materials expenses of approximately $40 million, lower travel and entertainment expenses due to the COVID-19 restrictions of approximately $20 million and lower variable compensation in the first half of the year.

[0000106040-21-000024:mdna:50]
Selling, general and administrative (“SG&A”) expense increased $6 million for the three months ended April 2, 2021 from the comparable period in the prior year. The increase was driven by higher variable compensation costs of approximately $15 million as a result of improved earnings, partially offset by lower travel and entertainment as a result of COVID-19 restrictions and lower consulting and marketing expenses due to event cancellations. SG&A expense decreased $76 million for the nine months ended April 2, 2021 from the comparable period in the prior year. The decline was primarily driven by approximately $40 million from lower travel and entertainment as a result of COVID-19 restrictions, lower consulting and lower marketing expenses due to event cancellations; approximately $15 million from lower variable compensation costs; and approximately $10 million of additional expense in the prior year related to the additional week.

[0000106040-21-000024:mdna:51]
The higher gains recognized in Employee termination, asset impairment and other charges compared to the prior year primarily reflect gains on the disposal of assets associated with our business realignment activities. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 14, Employee Termination, Asset Impairment and Other Charges, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000024:mdna:52]
[same as prior period, unchanged from 0000106040-21-000011:mdna:47]

[0000106040-21-000024:mdna:53]
The decreases in total interest and other expense, net for the three and nine months ended April 2, 2021 reflect lower interest expense resulting from lower index rates and the pay-down of principal on our debt.

[0000106040-21-000024:mdna:54]
[same as prior period, unchanged from 0000106040-21-000011:mdna:49]

[0000106040-21-000024:mdna:55]
[same as prior period, unchanged from 0000106040-21-000011:mdna:50]

[0000106040-21-000024:mdna:56]
[same as prior period, unchanged from 0000106040-21-000011:mdna:51]

[0000106040-21-000024:mdna:57]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |  |
|  | ($ in millions) |  |
| Income (loss) before taxes | $ | 249 |  |  | $ | 46 |  |  | $ | 331 |  |  | $ | (231) |  |  |
| Income tax expense | 52 |  |  | 29 |  |  | 132 |  |  | 167 |  |  |
| Effective tax rate | 21 | % |  | 63 | % |  | 40 | % |  | (72) | % |  |

[0000106040-21-000024:mdna:58]
The primary drivers of the effective tax rate for the three and nine months ended April 2, 2021, which resulted in a difference in the effective tax rate for the nine months ended April 2, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2031. In addition, the effective tax rate for the three and nine months ended April 2, 2021 includes discrete effects for increases to unrecognized tax benefits of $35 million as a result of ongoing discussions with various taxing authorities that are offset in part by a release of certain unrecognized tax benefits of $22 million as a result of business realignment activities. The effective tax rate for the nine months ended April 2, 2021 also includes the discrete effects of net tax deficiencies from shortfalls of $11 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of deferred tax liabilities due to restructuring activities, which have no impact on the amount of income taxes paid by us.

[0000106040-21-000024:mdna:59]
The primary driver of the difference between the effective tax rate for the three and nine months ended April 3, 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand that expired or will expire at various dates during fiscal years 2020 through 2030.

[0000106040-21-000024:mdna:60]
[same as prior period, unchanged from 0000106040-21-000011:mdna:55]

[0000106040-21-000024:mdna:61]
[same as prior period, unchanged from 0000106040-21-000011:mdna:56]

[0000106040-21-000024:mdna:62]
[same as prior period, unchanged from 0000106040-21-000011:mdna:60]

[0000106040-21-000024:mdna:63]
[same as prior period, unchanged from 0000106040-21-000011:mdna:57]

[0000106040-21-000024:mdna:64]
[same as prior period, unchanged from 0000106040-21-000011:mdna:58]

[0000106040-21-000024:mdna:65]
|  | Nine Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 904 |  |  | $ | 652 |  |  |  |
| Investing activities | (562) |  |  | 192 |  |  |  |
| Financing activities | (662) |  |  | (1,354) |  |  |  |
| Effect of exchange rate changes on cash | 6 |  |  | (2) |  |  |  |
| Net decrease in cash and cash equivalents | $ | (314) |  |  | $ | (512) |  |  |  |

[0000106040-21-000024:mdna:66]
[same as prior period, unchanged from 0000106040-21-000011:mdna:61]

[0000106040-21-000024:mdna:67]
During fiscal 2021, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $2.9 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $800 million during fiscal 2021. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-21-000024:mdna:68]
[same as prior period, unchanged from 0000106040-21-000011:mdna:63]

[0000106040-21-000024:mdna:69]
A total of $1.85 billion and $2.14 billion of our Cash and cash equivalents was held outside of the U.S. as of April 2, 2021 and April 3, 2020, respectively. As a result of the change in our permanent reinvestment assertion, there are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-21-000024:mdna:70]
[same as prior period, unchanged from 0000106040-21-000011:mdna:65]

[0000106040-21-000024:mdna:71]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $393 million for the nine months ended April 2, 2021, as compared to $331 million of net cash used for changes in operating assets and liabilities for the nine months ended April 3, 2020. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows:

[0000106040-21-000024:mdna:72]
|  | Three Months Ended |  |  |
|  | April 2,2021 |  | April 3,2020 |  |  |  |  |
|  | (in days) |
| Days sales outstanding | 42 |  |  | 43 |  |  |  |  |  |
| Days in inventory | 110 |  |  | 89 |  |  |  |  |  |
| Days payables outstanding | (66) |  |  | (63) |  |  |  |  |  |
| Cash conversion cycle | 86 |  |  | 69 |  |  |  |  |  |

[0000106040-21-000024:mdna:73]
43

[0000106040-21-000024:mdna:74]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we negotiate to modify the timing of payments to our vendors to manage our vendor relationships and to manage our cash flows, including our cash balances.

[0000106040-21-000024:mdna:75]
For the three months ended April 2, 2021, DSO decreased by 1 day over the prior year, primarily reflecting the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO increased by 21 days over the prior year, primarily reflecting higher stocking levels of HDD inventory to serve anticipated demand growth and better output from Flash Ventures as production ramped up at the new fabrication site. With supply chains experiencing constraint as a result of COVID-19 and certain key component supply tightness, we are taking actions to ensure that we have the components we need to build products and are stocking higher levels of inventory so that we can ship by ocean and reduce higher cost air freight. DPO increased by 3 days over the prior year, primarily reflecting resumptions of flash production volumes as well as routine variations in the timing of purchases and payments during the period.

[0000106040-21-000024:mdna:76]
[same as prior period, unchanged from 0000106040-21-000011:mdna:70]

[0000106040-21-000024:mdna:77]
Net cash used in investing activities for the nine months ended April 2, 2021 primarily consisted of $820 million in capital expenditures, partially offset by a $129 million net decrease in notes receivable issuances to Flash Ventures and proceeds of $121 million from the disposal of property, plant and equipment, primarily related to our business realignment activities. Net cash provided by investing activities for the nine months ended April 3, 2020 primarily consisted of a $627 million net decrease in notes receivable issuances to Flash Ventures to fund its capital expansion, partially offset by $432 million of capital expenditures.

[0000106040-21-000024:mdna:78]
[same as prior period, unchanged from 0000106040-21-000011:mdna:72]

[0000106040-21-000024:mdna:79]
[same as prior period, unchanged from 0000106040-21-000011:mdna:73]

[0000106040-21-000024:mdna:80]
During the nine months ended April 2, 2021, net cash used in financing activities primarily consisted of $673 million for repayment of debt, which included $450 million in voluntary prepayments on our Term Loan B-4. Net cash used in financing activities for the nine months ended April 3, 2020 primarily consisted of $919 million for the repayment of our debt and $445 million to pay dividends on our common stock. On April 30, 2021, we made an incremental voluntary prepayment of $150 million on our Term Loan B-4.

[0000106040-21-000024:mdna:81]
[same as prior period, unchanged from 0000106040-21-000011:mdna:75]

[0000106040-21-000024:mdna:82]
[same as prior period, unchanged from 0000106040-21-000011:mdna:76]

[0000106040-21-000024:mdna:83]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-21-000024:mdna:84]
[same as prior period, unchanged from 0000106040-21-000011:mdna:78]

[0000106040-21-000024:mdna:85]
[same as prior period, unchanged from 0000106040-21-000011:mdna:79]

[0000106040-21-000024:mdna:86]
[same as prior period, unchanged from 0000106040-21-000011:mdna:80]

[0000106040-21-000024:mdna:87]
The following is a summary of our known contractual cash obligations and commercial commitments as of April 2, 2021:

[0000106040-21-000024:mdna:88]
|  | Total |  | Remaining three months of 2021 |  | 2022-2023 |  | 2024-2025 |  | Beyond 2025 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 9,037 |  |  | $ | 63 |  |  | $ | 5,574 |  |  | $ | 1,100 |  |  | $ | 2,300 |  |
| Interest on debt | 882 |  |  | 38 |  |  | 500 |  |  | 235 |  |  | 109 |  |
| Flash Ventures related commitments(2) | 5,602 |  |  | 1,041 |  |  | 2,989 |  |  | 1,340 |  |  | 232 |  |
| Operating leases | 296 |  |  | 12 |  |  | 73 |  |  | 64 |  |  | 147 |  |
| Purchase obligations and other commitments | 4,277 |  |  | 1,975 |  |  | 1,566 |  |  | 545 |  |  | 191 |  |
| Mandatory Deemed Repatriation Tax | 925 |  |  | — |  |  | 210 |  |  | 417 |  |  | 298 |  |
| Total | $ | 21,019 |  |  | $ | 3,129 |  |  | $ | 10,912 |  |  | $ | 3,701 |  |  | $ | 3,277 |  |

[0000106040-21-000024:mdna:89]
[same as prior period, unchanged from 0000106040-21-000011:mdna:83]

[0000106040-21-000024:mdna:90]
[same as prior period, unchanged from 0000106040-21-000011:mdna:84]

[0000106040-21-000024:mdna:91]
[same as prior period, unchanged from 0000106040-21-000011:mdna:85]

[0000106040-21-000024:mdna:92]
In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020. The credit agreement governing our revolving credit facility and Term Loan A-1 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of April 2, 2021, we were in compliance with these financial covenants.

[0000106040-21-000024:mdna:93]
[same as prior period, unchanged from 0000106040-21-000011:mdna:87]

[0000106040-21-000024:mdna:94]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of April 2, 2021, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-21-000024:mdna:95]
[same as prior period, unchanged from 0000106040-21-000011:mdna:89]

[0000106040-21-000024:mdna:96]
[same as prior period, unchanged from 0000106040-21-000011:mdna:90]

[0000106040-21-000024:mdna:97]
46

[0000106040-21-000024:mdna:98]
[same as prior period, unchanged from 0000106040-21-000011:mdna:91]

[0000106040-21-000024:mdna:99]
[same as prior period, unchanged from 0000106040-21-000011:mdna:92]

[0000106040-21-000024:mdna:100]
|  |  | April 2,2021 |
| 2022 |  | $ | 106 |  |
| 2023 |  | 104 |  |
| 2024 |  | 179 |  |
| 2025 |  | 238 |  |
| 2026 |  | 298 |  |
| Total |  | $ | 925 |  |

[0000106040-21-000024:mdna:101]
[same as prior period, unchanged from 0000106040-21-000011:mdna:94]

[0000106040-21-000024:mdna:102]
[same as prior period, unchanged from 0000106040-21-000011:mdna:95]

[0000106040-21-000024:mdna:103]
As of April 2, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $750 million. Accrued interest and penalties related to unrecognized tax benefits as of April 2, 2021 was approximately $133 million. Of these amounts, approximately $743 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-21-000024:mdna:104]
[same as prior period, unchanged from 0000106040-21-000011:mdna:97]

[0000106040-21-000024:mdna:105]
We have generally held a balance of fixed and variable rate debt. At April 2, 2021, we had $5.64 billion of variable rate debt, comprising 62% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $3.64 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual interest expense by $36 million.

[0000106040-21-000024:mdna:106]
[same as prior period, unchanged from 0000106040-21-000011:mdna:99]

[0000106040-21-000024:mdna:107]
[same as prior period, unchanged from 0000106040-21-000011:mdna:100]

[0000106040-21-000024:mdna:108]
[same as prior period, unchanged from 0000106040-21-000011:mdna:101]

[0000106040-21-000024:mdna:109]
[same as prior period, unchanged from 0000106040-21-000011:mdna:102]

[0000106040-21-000024:mdna:110]
[same as prior period, unchanged from 0000106040-21-000011:mdna:103]

[0000106040-21-000024:mdna:111]
[same as prior period, unchanged from 0000106040-21-000011:mdna:105]

[0000106040-21-000024:mdna:112]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the nine months ended April 2, 2021 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of April 2, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-21-000024:mdna:113]
[same as prior period, unchanged from 0000106040-21-000011:mdna:107]

[0000106040-21-000024:mdna:114]
[same as prior period, unchanged from 0000106040-21-000011:mdna:108]

[0000106040-21-000024:mdna:115]
[same as prior period, unchanged from 0000106040-21-000011:mdna:109]

[0000106040-21-000024:mdna:116]
[same as prior period, unchanged from 0000106040-21-000011:mdna:110]

[0000106040-21-000024:mdna:117]
[same as prior period, unchanged from 0000106040-21-000011:mdna:111]

[0000106040-21-000024:mdna:118]
[same as prior period, unchanged from 0000106040-21-000011:mdna:112]

[0000106040-21-000024:mdna:119]
[same as prior period, unchanged from 0000106040-21-000011:mdna:113]
