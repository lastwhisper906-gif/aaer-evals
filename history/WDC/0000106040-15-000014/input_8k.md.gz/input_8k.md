# WDC 8-K — 0001193125-15-356330 filed 2015-10-28

## item codes, every 8-K on or before 2015-11-10

- 2015-11-05 0001193125-15-366646 — 5.02, 5.07, 9.01
- 2015-11-04 0001193125-15-364631 — 7.01, 9.01
- 2015-10-28 0001193125-15-356330 — 2.02, 9.01
- 2015-10-26 0001193125-15-352265 — 1.01, 9.01
- 2015-10-21 0001193125-15-349064 — 7.01, 8.01, 9.01
- 2015-10-21 0001193125-15-348802 — 2.02, 9.01
- 2015-10-19 0001193125-15-346141 — 5.02, 7.01, 9.01
- 2015-09-30 0001193125-15-333216 — 1.01, 3.02, 7.01, 9.01
- 2015-08-05 0001193125-15-276886 — 7.01, 9.01
- 2015-07-29 0001193125-15-268317 — 2.02, 9.01
- 2015-05-06 0001193125-15-172571 — 7.01, 9.01
- 2015-04-28 0001193125-15-152989 — 2.02, 9.01
- 2015-02-05 0001299933-15-000203 — 5.02
- 2015-02-04 0001193125-15-032071 — 7.01, 9.01
- 2015-01-27 0001193125-15-021884 — 2.02, 9.01
- 2015-01-26 0001299933-15-000111 — 5.02
- 2014-12-01 0001193125-14-429007 — 5.02, 7.01, 9.01
- 2014-11-13 0001193125-14-410707 — 5.02, 8.01, 9.01
- 2014-11-07 0001193125-14-401459 — 7.01, 9.01
- 2014-11-06 0001193125-14-399004 — 5.07
- 2014-11-05 0001193125-14-398664 — 7.01, 9.01
- 2014-11-05 0001193125-14-396729 — 7.01, 9.01
- 2014-10-28 0001193125-14-385079 — 2.02, 9.01
- 2014-10-08 0001299933-14-001552 — 7.01
- 2014-08-25 0001193125-14-320073 — 5.02, 7.01, 9.01
- 2014-08-06 0001299933-14-001208 — 5.02
- 2014-08-05 0001193125-14-294753 — 7.01, 9.01
- 2014-07-30 0001193125-14-286995 — 2.02, 9.01
- 2014-07-07 0001193125-14-261985 — 5.02, 7.01, 9.01
- 2014-05-15 0001299933-14-000769 — 7.01, 9.01
- 2014-04-30 0001193125-14-172219 — 2.02, 9.01
- 2014-02-10 0001299933-14-000205 — 5.02
- 2014-02-07 0001193125-14-039342 — 7.01, 9.01
- 2014-01-23 0001299933-14-000096 — 5.02
- 2014-01-22 0001193125-14-017314 — 2.02, 9.01
- 2014-01-09 0001193125-14-006778 — 1.01, 1.02, 2.03, 9.01
- 2013-11-14 0001193125-13-442240 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2013-11-14 0001193125-13-440645 — 7.01, 9.01
- 2013-11-06 0001193125-13-429460 — 8.01, 9.01
- 2013-11-01 0001193125-13-421582 — 7.01, 9.01
- 2013-10-30 0001193125-13-418750 — 7.01, 9.01
- 2013-10-24 0001193125-13-409911 — 2.02, 9.01
- 2013-10-17 0001193125-13-402509 — 7.01, 9.01
- 2013-10-16 0001193125-13-400467 — 7.01
- 2013-09-25 0001299933-13-001706 — 5.02, 7.01, 9.01
- 2013-09-20 0001193125-13-372177 — 5.02, 7.01, 9.01
- 2013-09-13 0001193125-13-365470 — 7.01, 9.01
- 2013-09-09 0001193125-13-360566 — 7.01, 9.01
- 2013-08-16 0001193125-13-336942 — 2.02, 5.02, 9.01
- 2013-07-24 0001193125-13-300571 — 2.02, 9.01
- 2013-07-23 0001299933-13-001324 — 5.02
- 2013-07-22 0001299933-13-001306 — 7.01
- 2013-06-24 0001299933-13-001167 — 7.01, 9.01
- 2013-05-16 0001299933-13-000921 — 7.01, 9.01
- 2013-04-24 0001193125-13-170526 — 2.02, 9.01
- 2013-03-29 0001299933-13-000589 — 2.05 — amendment, the index does not say of what
- 2013-02-19 0001299933-13-000333 — 5.02
- 2013-02-14 0001299933-13-000306 — 7.01, 9.01
- 2013-01-25 0001299933-13-000158 — 5.02
- 2013-01-23 0001299933-13-000136 — 2.05
- 2013-01-23 0001193125-13-020765 — 2.02, 9.01
- 2012-12-04 0001299933-12-002683 — 7.01, 9.01
- 2012-11-13 0001193125-12-467500 — 5.02, 5.07, 9.01
- 2012-10-22 0001193125-12-430195 — 2.02, 9.01
- 2012-10-15 0001299933-12-002299 — 7.01
- 2012-09-14 0001299933-12-002137 — 7.01, 9.01
- 2012-09-10 0001299933-12-002110 — 5.02, 7.01, 9.01
- 2012-08-21 0001299933-12-001969 — 5.02
- 2012-08-10 0001299933-12-001904 — 5.02
- 2012-07-25 0001299933-12-001734 — 5.02, 7.01, 9.01
- 2012-07-25 0001193125-12-314508 — 2.02, 9.01
- 2012-05-23 0001299933-12-001291 — 5.02
- 2012-05-21 0001299933-12-001255 — 3.01, 7.01, 9.01
- 2012-05-11 0001193125-12-226323 — 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-186083 — 2.02, 9.01
- 2012-03-09 0001299933-12-000597 — 1.01
- 2012-03-09 0001193125-12-105275 — 1.01, 1.02, 2.01, 2.03, 3.02, 5.02, 7.01, 9.01
- 2012-03-07 0001299933-12-000568 — 7.01, 9.01
- 2012-02-29 0001299933-12-000504 — 7.01, 9.01
- 2012-02-24 0001299933-12-000465 — 5.02
- 2012-01-24 0001299933-12-000166 — 7.01
- 2012-01-23 0001193125-12-020400 — 2.02, 9.01
- 2011-12-02 0001299933-11-003467 — 7.01, 9.01
- 2011-11-21 0001299933-11-003389 — 7.01, 9.01
- 2011-11-16 0001299933-11-003353 — 1.01
- 2011-11-14 0000950123-11-098500 — 5.07
- 2011-10-20 0001299933-11-003081 — 7.01, 9.01
- 2011-10-19 0000950123-11-090715 — 2.02, 9.01
- 2011-10-17 0001299933-11-003037 — 7.01, 9.01
- 2011-10-12 0001299933-11-002993 — 7.01, 9.01
- 2011-09-19 0001299933-11-002815 — 5.02
- 2011-08-19 0001299933-11-002570 — 8.01
- 2011-08-15 0001299933-11-002529 — 5.02
- 2011-07-21 0000950123-11-067197 — 2.02, 9.01
- 2011-05-31 0000950123-11-055158 — 8.01, 9.01
- 2011-04-25 0000950123-11-038754 — 8.01
- 2011-04-20 0000950123-11-037289 — 2.02, 9.01
- 2011-03-09 0000950123-11-023726 — 1.01 — amendment of 0000950123-11-022445
- 2011-03-07 0000950123-11-022445 — 1.01, 3.02, 5.02, 7.01, 9.01
- 2011-02-15 0000950123-11-014255 — 5.02
- 2011-01-18 0000950123-11-003426 — 2.02, 9.01
- 2010-12-06 0000950123-10-111169 — 5.02
- 2010-11-12 0000950123-10-104989 — 5.07
- 2010-10-19 0000950123-10-094183 — 2.02, 9.01
- 2010-08-31 0000950123-10-082712 — 5.02, 7.01, 9.01
- 2010-08-17 0000950123-10-078570 — 5.02, 7.01, 9.01
- 2010-07-21 0000950123-10-066852 — 2.02, 9.01
- 2010-07-14 0001299933-10-002669 — 5.02
- 2010-04-22 0000950123-10-037178 — 2.02, 9.01
- 2010-04-01 0000950123-10-031547 — 5.02
- 2010-02-05 0001299933-10-000488 — 5.02
- 2010-01-21 0000950123-10-004095 — 2.02, 9.01
- 2009-11-16 0000950123-09-062571 — 5.02, 8.01, 9.01
- 2009-10-23 0001299933-09-004187 — 5.02
- 2009-10-22 0000950123-09-052334 — 2.02, 9.01
- 2009-08-25 0001299933-09-003496 — 5.02
- 2009-07-28 0000950123-09-026355 — 2.02, 9.01
- 2009-05-28 0000950134-09-011526 — 7.01
- 2009-04-23 0000950134-09-008239 — 2.02, 9.01
- 2009-01-28 0000892569-09-000035 — 2.02, 9.01
- 2008-12-17 0000950134-08-022277 — 2.05, 2.06, 5.02, 7.01, 9.01
- 2008-11-12 0000950134-08-020337 — 8.01
- 2008-10-23 0000950137-08-012942 — 2.02, 9.01
- 2008-09-17 0000892569-08-001315 — 5.02
- 2008-09-03 0001299933-08-004167 — 7.01
- 2008-08-12 0000950137-08-010558 — 5.02
- 2008-07-24 0000892569-08-001019 — 2.02, 9.01
- 2008-04-24 0000892569-08-000662 — 2.02, 9.01
- 2008-04-03 0000950124-08-001720 — 7.01, 9.01
- 2008-03-21 0001299933-08-001545 — 2.05, 2.06, 9.01
- 2008-02-27 0000950124-08-000884 — 7.01
- 2008-02-12 0000950137-08-002046 — 1.01, 1.02, 2.03, 9.01
- 2008-01-25 0001299933-08-000431 — 5.02
- 2008-01-23 0000892569-08-000064 — 2.02, 9.01
- 2007-12-05 0000950134-07-024942 — 7.01, 8.01
- 2007-11-19 0000950137-07-017481 — 9.01 — amendment of 0000950134-07-019562
- 2007-11-08 0000950137-07-016823 — 5.03, 8.01, 9.01
- 2007-11-01 0000950137-07-016398 — 2.02, 9.01
- 2007-09-17 0001299933-07-005463 — 5.02
- 2007-09-10 0001299933-07-005332 — 7.01, 9.01
- 2007-09-05 0000950134-07-019562 — 2.01, 2.03, 8.01, 9.01
- 2007-08-31 0000950134-07-019339 — 1.01, 2.03, 9.01
- 2007-08-28 0001299933-07-005122 — 5.02
- 2007-08-27 0000950137-07-013086 — 2.02
- 2007-08-01 0000892569-07-000992 — 5.02, 9.01
- 2007-07-26 0000892569-07-000981 — 2.02, 9.01
- 2007-06-29 0000950137-07-009562 — 1.01, 1.02, 9.01
- 2007-06-15 0001299933-07-003686 — 5.02
- 2007-05-21 0001299933-07-003133 — 7.01
- 2007-04-26 0000892569-07-000517 — 2.02, 5.02, 7.01, 9.01
- 2007-02-28 0001299933-07-001214 — 7.01
- 2007-01-25 0000892569-07-000044 — 2.02, 9.01
- 2006-12-01 0001299933-06-007820 — 5.02, 8.01
- 2006-11-20 0001299933-06-007607 — 5.04
- 2006-11-14 0001299933-06-007455 — 5.02
- 2006-11-02 0000892569-06-001320 — 1.01, 2.02, 5.02, 9.01
- 2006-10-27 0001299933-06-006938 — 5.04, 8.01
- 2006-10-23 0000892569-06-001271 — 8.01, 9.01
- 2006-10-05 0001299933-06-006416 — 3.01
- 2006-09-20 0001299933-06-006080 — 1.01
- 2006-07-27 0000892569-06-000910 — 2.02, 7.01, 9.01
- 2006-07-19 0001299933-06-004766 — 1.01
- 2006-06-23 0001299933-06-004354 — 1.01
- 2006-06-12 0001299933-06-004119 — 7.01
- 2006-05-16 0001299933-06-003478 — 1.01, 5.02, 5.03, 9.01
- 2006-05-15 0001299933-06-003456 — 7.01, 9.01
- 2006-04-27 0000892569-06-000596 — 2.02, 9.01
- 2006-04-05 0000892569-06-000469 — 1.02, 9.01
- 2006-03-14 0000950134-06-004983 — 7.01
- 2006-02-27 0001299933-06-001301 — 7.01
- 2006-02-22 0000950137-06-002118 — 1.01, 9.01
- 2006-02-02 0001299933-06-000773 — 1.01
- 2006-01-26 0000950137-06-000916 — 2.02, 9.01
- 2005-12-02 0001299933-05-006268 — 1.01
- 2005-11-28 0001299933-05-006183 — 7.01
- 2005-11-28 0001299933-05-006181 — 7.01
- 2005-11-23 0000892569-05-001090 — 1.01, 5.02, 9.01
- 2005-11-21 0001299933-05-006087 — 7.01, 9.01
- 2005-10-27 0000892569-05-000934 — 2.02
- 2005-10-26 0001299933-05-005449 — 1.01, 9.01 — amendment of 0000902595-05-000054
- 2005-09-26 0000892569-05-000822 — 5.03, 9.01
- 2005-09-08 0001299933-05-004531 — 7.01
- 2005-08-26 0000902595-05-000054 — 1.01, 5.02
- 2005-08-22 0001299933-05-004278 — 1.01
- 2005-07-28 0000950137-05-009230 — 2.02
- 2005-07-25 0001299933-05-003693 — 1.01
- 2005-07-13 0001299933-05-003451 — 7.01
- 2005-06-13 0000950137-05-007312 — 7.01
- 2005-06-08 0001299933-05-002784 — 1.01
- 2005-05-23 0001299933-05-002514 — 1.01
- 2005-04-21 0000950137-05-004728 — 2.02
- 2005-03-30 0001299933-05-001472 — 7.01
- 2005-03-23 0001299933-05-001395 — 1.01, 2.03
- 2005-02-23 0001299933-05-000897 — 7.01
- 2005-01-27 0000950137-05-000797 — 2.02
- 2005-01-26 0001299933-05-000361 — 1.01
- 2005-01-05 0001299933-05-000044 — 1.02
- 2004-11-30 0000950137-04-010566 — 7.01
- 2004-11-23 0000950137-04-010359 — 1.01, 5.02, 9.01
- 2004-10-25 0000950137-04-008936 — 2.02
- 2004-09-27 0001299933-04-000903 — 5.02, 9.01
- 2004-09-15 0001019687-04-002071 — 7.01
- 2004-07-29 0001019687-04-001633 — 12
- 2004-06-07 0001019687-04-001262 — 9
- 2004-04-22 0001019687-04-000871 — 12, 7
- 2004-02-24 0001019687-04-000378 — 9
- 2004-02-05 0001019687-04-000227 — 9
- 2004-01-22 0001019687-04-000122 — 12
- 2003-12-15 0000892569-03-002834 — 9
- 2003-12-04 0000892569-03-002769 — 9
- 2003-11-17 0000892569-03-002674 — 9
- 2003-10-23 0000892569-03-002399 — 12
- 2003-08-26 0000892569-03-002072 — 12
- 2003-08-15 0000892569-03-002012 — 2, 7
- 2003-07-24 0000892569-03-001744 — 7, 9
- 2003-06-11 0000892569-03-001478 — 9
- 2003-05-07 0000892569-03-001195 — 9
- 2003-04-24 0000892569-03-001063 — 7, 9
- 2003-03-18 0000892569-03-000680 — 5, 7
- 2003-03-05 0000892569-03-000584 — 9
- 2003-02-20 0000892569-03-000485 — 5, 7
- 2002-12-05 0000892569-02-002472 — 9
- 2002-08-06 0000892569-02-001635 — 5, 7
- 2002-02-26 0000892569-02-000410 — 5, 7
- 2002-01-28 0000892569-02-000153 — 5, 7
- 2002-01-17 0000892569-02-000069 — 5, 7
- 2001-10-25 0000892569-01-500814 — 5, 7
- 2001-07-30 0000892569-01-500614 — 5, 7
- 2001-06-14 0000892569-01-500470 — 5
- 2001-04-30 0001095811-01-501629 — 5, 7
- 2001-04-09 0001095811-01-002107 — 5, 7
- 2001-04-06 0001095811-01-501018 — 5, 7
- 2001-02-05 0001095811-01-000648 — 7, 9
- 2001-01-26 0001095811-01-000449 — 5, 7
- 2000-10-27 0001095811-00-004127 — 5, 7
- 2000-10-18 0001095811-00-003953 — 5
- 2000-08-02 0001095811-00-002214 — 5, 7
- 2000-05-04 0001095811-00-001253 — 5, 7
- 2000-01-31 0001095811-00-000084 — 5, 7
- 2000-01-21 0001095811-00-000047 — 5, 7
- 2000-01-19 0000892569-00-000088 — 5, 7
- 1999-11-18 0000892569-99-003133 — 5
- 1999-10-21 0000892569-99-002738 — 5, 7
- 1999-10-07 0000892569-99-002630 — 5
- 1999-10-04 0000892569-99-002587 — 5
- 1999-09-28 0000892569-99-002543 — 5, 7
- 1999-09-27 0000892569-99-002529 — 5, 7
- 1999-09-09 0000892569-99-002393 — 5
- 1999-08-19 0000892569-99-002308 — 5, 7
- 1999-07-14 0000892569-99-001913 — 5, 7
- 1999-01-19 0000950150-99-000055 — 5, 7
- 1998-11-19 0000892569-98-003159 — 5, 7
- 1998-10-26 0000892569-98-002830 — 5, 7
- 1998-08-10 0000892569-98-002173 — 5, 7
- 1998-08-10 0000892569-98-002171 — 5, 7
- 1998-02-12 0000892569-98-000322 — 5, 7
- 1997-02-05 0000892569-97-000266 — 5, 7
- 1995-05-26 0000892569-95-000258 — 5, 7
- 1994-07-18 0000892569-94-000196 — 5, 7
- 1994-03-16 0000892569-94-000081 — 2
- 1994-01-05 0000892569-94-000006 — 2

## late-filing notifications on or before 2015-11-10

- 2006-11-08 0000950137-06-012051 — NT 10-Q, for the period ended 2006-09-29
- 2006-09-13 0000892569-06-001095 — NT 10-K, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-356330:8k_2_02:1]
EX-99.1
2
d32109dex991.htm
EX-99.1

[0001193125-15-356330:8k_2_02:2]
EX-99.1

[0001193125-15-356330:8k_2_02:3]
Exhibit 99.1

[0001193125-15-356330:8k_2_02:4]
Company contacts:

[0001193125-15-356330:8k_2_02:5]
Bob Blair

[0001193125-15-356330:8k_2_02:6]
Western Digital Investor Relations

[0001193125-15-356330:8k_2_02:7]
949.672.7834

[0001193125-15-356330:8k_2_02:8]
robert.blair@wdc.com

[0001193125-15-356330:8k_2_02:9]
Jim Pascoe

[0001193125-15-356330:8k_2_02:10]
Western Digital Corporation

[0001193125-15-356330:8k_2_02:11]
408.717.5950

[0001193125-15-356330:8k_2_02:12]
jim.pascoe@wdc.com

[0001193125-15-356330:8k_2_02:13]
FOR IMMEDIATE RELEASE:

[0001193125-15-356330:8k_2_02:14]
WESTERN DIGITAL ANNOUNCES FINANCIAL RESULTS FOR

[0001193125-15-356330:8k_2_02:15]
FIRST QUARTER FISCAL 2016

[0001193125-15-356330:8k_2_02:16]
IRVINE, Calif.
— Oct. 28, 2015 — Western Digital® Corp. (NASDAQ: WDC) today reported revenue of $3.4 billion and net income of $283 million, or $1.21 per share, for its first fiscal quarter ended
Oct. 2, 2015. On a non-GAAP basis, net income was $366 million, or $1.56 per share. In the year-ago quarter, the company reported revenue of $3.9 billion and net income of $423 million, or $1.76 per share. Non-GAAP net income in the year-ago quarter
was $504 million, or $2.10 per share.

[0001193125-15-356330:8k_2_02:17]
The company generated $545 million in cash from operations during the first fiscal quarter, ending
with total cash and cash equivalents of $5.1 billion. It utilized $60 million to repurchase 0.7 million shares of its common stock. On Aug. 4, the company declared a cash dividend of $0.50 per share of its common stock, which was paid on
Oct. 15.

[0001193125-15-356330:8k_2_02:18]
“I am pleased with our execution and performance in the first fiscal quarter,” said Steve Milligan, chief
executive officer of Western Digital. “We continue to benefit from our strong product and technology positioning in today’s storage market. I am very excited about our future and ability to create long term value in the evolving storage
ecosystem, especially in light of our three recent announcements regarding the planned investment in our company by Unisplendour, the MOFCOM decision and our planned acquisition of SanDisk.”

[0001193125-15-356330:8k_2_02:19]
Western Digital Announces Financial Results for First Quarter Fiscal 2016

[0001193125-15-356330:8k_2_02:20]
The investment community conference call to discuss these results and our current outlook
will be broadcast live over the Internet today at 2 p.m. Pacific/5 p.m. Eastern. The live and archived conference call webcast can be accessed online at investor.wdc.com. A quarterly fact sheet including our guidance for the second quarter fiscal
2016 will also be posted on our website at investor.wdc.com. The telephone replay number is 1-800-947-5189 in the U.S. or +1-203-369-3554 for international callers.

[0001193125-15-356330:8k_2_02:21]
About Western Digital

[0001193125-15-356330:8k_2_02:22]
Founded in 1970,
Western Digital Corp. (NASDAQ: WDC), Irvine, Calif., is an industry-leading developer and manufacturer of storage solutions that enable people to create, manage, experience and preserve digital content. It is a long-time innovator in the storage
industry. Western Digital Corporation is responding to changing market needs by providing a full portfolio of compelling, high-quality storage products with effective technology deployment, high efficiency, flexibility and speed. Its products are
marketed under the HGST and WD brands to OEMs, distributors, resellers, cloud infrastructure providers and consumers. Financial and investor information is available on the company’s Investor Relations website at investor.wdc.com.

[0001193125-15-356330:8k_2_02:23]
Forward-Looking Statements

[0001193125-15-356330:8k_2_02:24]
Western Digital Announces Financial Results for First Quarter Fiscal 2016

[0001193125-15-356330:8k_2_02:25]
“potential,” “plan,” “forecast,” “approximate,” “intend,” “upside,” and the like, or the use of future tense. Statements contained
herein concerning the business outlook or future economic performance, anticipated profitability, revenues, expenses, dividends or other financial items, and product or services line growth of Western Digital (and the combined businesses of Western
Digital and SanDisk), together with other statements that are not historical facts, are forward-looking statements that are estimates reflecting the best judgment of Western Digital based upon currently available information. Statements concerning
current conditions may also be forward-looking if they imply a continuation of current conditions.

[0001193125-15-356330:8k_2_02:26]
Western Digital Announces Financial Results for First Quarter Fiscal 2016

[0001193125-15-356330:8k_2_02:27]
Risks and uncertainties related to the proposed merger include, but are not limited to, the
risk that SanDisk’s stockholders do not approve the merger or that Western Digital’s stockholders do not approve the issuance of stock in the merger (to the extent such approval is required), potential adverse reactions or changes to
business relationships resulting from the announcement, pendency or completion of the merger, uncertainties as to the timing of the merger, the possibility that the closing conditions to the proposed merger may not be satisfied or waived, including
that a governmental entity may prohibit, delay or refuse to grant a necessary approval, adverse effects on Western Digital’s stock price resulting from the announcement or completion of the merger, competitive responses to the announcement or
completion of the merger, costs and difficulties related to the integration of SanDisk’s businesses and operations with Western Digital’s businesses and operations, the inability to obtain, or delays in obtaining, cost savings and
synergies from the merger, uncertainties as to whether the completion of the merger or any transaction will have the accretive effect on Western Digital’s earnings or cash flows that it expects, unexpected costs, liabilities, charges or
expenses resulting from the merger, litigation relating to the merger, the inability to retain key personnel, and any changes in general economic and/or industry-specific conditions. In addition to the factors set forth above, other factors that may
affect Western Digital’s or SanDisk’s plans, results or stock price are set forth in Western Digital’s and SanDisk’s respective filings with the SEC, including Western Digital’s and SanDisk’s most recent Annual Reports
on Form 10-K, Quarterly Reports on Form 10-Q and Current Reports on Form 8-K. Many of these factors are beyond Western Digital’s and SanDisk’s control. Western Digital and SanDisk caution investors that any forward-looking statements made
by Western Digital or SanDisk are not guarantees of future performance. Neither Western Digital nor SanDisk intend, or undertake any obligation, to publish revised forward-looking statements to reflect events or circumstances after the date of this
document or to reflect the occurrence of unanticipated events.

[0001193125-15-356330:8k_2_02:28]
Western Digital Announces Financial Results for First Quarter Fiscal 2016

[0001193125-15-356330:8k_2_02:29]
Important Additional Information and Where to find It

[0001193125-15-356330:8k_2_02:30]
This communication does not constitute an offer to sell or the solicitation of an offer to buy any securities or a solicitation of any vote or
approval. This communication may be deemed to be solicitation material in respect of the proposed merger between Western Digital and SanDisk. In connection with the proposed merger, Western Digital intends to file a registration statement on Form
S-4 with the SEC that contains a preliminary joint proxy statement of SanDisk and Western Digital that also constitutes a preliminary prospectus of Western Digital. After the registration statement is declared effective, Western Digital and SanDisk
will mail the definitive joint proxy statement/prospectus to their respective stockholders. This material is not a substitute for the joint proxy statement/prospectus or registration statement or for any other document that Western Digital or
SanDisk may file with the SEC and send to Western Digital’s and/or SanDisk’s stockholders in connection with the proposed merger. INVESTORS AND SECURITY HOLDERS OF WESTERN DIGITAL AND SANDISK ARE URGED TO READ ALL RELEVANT DOCUMENTS FILED
WITH THE SEC, INCLUDING THE JOINT PROXY STATEMENT/PROSPECTUS, BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED MERGER. Investors and security holders will be able to obtain copies of the joint proxy statement/prospectus (when
filed) as well as other filings containing information about Western Digital and SanDisk, without charge, at the SEC’s website, http://www.sec.gov. Copies of the documents filed with the SEC by Western Digital will be available free of charge
on Western Digital’s website at http://www.wdc.com. Copies of the documents filed with the SEC by SanDisk will be available free of charge on SanDisk’s website at http://www.sandisk.com.

[0001193125-15-356330:8k_2_02:31]
Participants in Solicitation

[0001193125-15-356330:8k_2_02:32]
Western
Digital, SanDisk and their respective directors, executive officers and certain other members of management and employees may be soliciting proxies from their respective stockholders in favor of the proposed transaction. Information regarding the
persons who may, under the rules of the SEC, be considered participants in the solicitation of stockholders in connection with the proposed transaction will be set forth in the joint proxy statement/prospectus

[0001193125-15-356330:8k_2_02:33]
Western Digital Announces Financial Results for First Quarter Fiscal 2016

[0001193125-15-356330:8k_2_02:34]
when it is filed with the SEC. You can find information about Western Digital’s executive officers and directors in Western Digital’s definitive proxy statement filed with the SEC on
Sept. 23, 2015. You can find information about SanDisk’s executive officers and directors in its definitive proxy statement filed with the SEC on April 27, 2015. You can obtain free copies of these documents from Western Digital and
SanDisk, respectively, using the contact information above. Investors may obtain additional information regarding the interest of such participants by reading the joint proxy statement/prospectus regarding the proposed merger when it becomes
available.

[0001193125-15-356330:8k_2_02:35]
###

[0001193125-15-356330:8k_2_02:36]
Western Digital, WD and the
WD logo are registered trademarks in the U.S. and other countries. HGST trademarks are intended and authorized for use only in countries and jurisdictions in which HGST has obtained the rights to use, market and advertise the brand. Other marks may
be mentioned herein that belong to other companies.

[0001193125-15-356330:8k_2_02:37]
WESTERN DIGITAL CORPORATION

[0001193125-15-356330:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-356330:8k_2_02:39]
(in millions; unaudited)

[0001193125-15-356330:8k_2_02:40]
|  |  | Oct. 2,2015 |  |  | July 3,2015 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,081 |  |  | $ | 5,024 |  |
| Short-term investments |  |  | 347 |  |  |  | 262 |  |
| Accounts receivable, net |  |  | 1,616 |  |  |  | 1,532 |  |
| Inventories |  |  | 1,260 |  |  |  | 1,368 |  |
| Other current assets |  |  | 351 |  |  |  | 331 |  |
| Total current assets |  |  | 8,655 |  |  |  | 8,517 |  |
| Property, plant and equipment, net |  |  | 2,890 |  |  |  | 2,965 |  |
| Goodwill |  |  | 2,766 |  |  |  | 2,766 |  |
| Other intangible assets, net |  |  | 319 |  |  |  | 332 |  |
| Other non-current assets |  |  | 631 |  |  |  | 601 |  |
| Total assets |  | $ | 15,261 |  |  | $ | 15,181 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 1,799 |  |  | $ | 1,881 |  |
| Accrued expenses |  |  | 528 |  |  |  | 470 |  |
| Accrued compensation |  |  | 336 |  |  |  | 330 |  |
| Accrued warranty |  |  | 141 |  |  |  | 150 |  |
| Revolving credit facility |  |  | 255 |  |  |  | 255 |  |
| Current portion of long-term debt |  |  | 172 |  |  |  | 156 |  |
| Total current liabilities |  |  | 3,231 |  |  |  | 3,242 |  |
| Long-term debt |  |  | 2,109 |  |  |  | 2,156 |  |
| Other liabilities |  |  | 585 |  |  |  | 564 |  |
| Total liabilities |  |  | 5,925 |  |  |  | 5,962 |  |
| Total shareholders’ equity |  |  | 9,336 |  |  |  | 9,219 |  |
| Total liabilities and shareholders’ equity |  | $ | 15,261 |  |  | $ | 15,181 |  |

[0001193125-15-356330:8k_2_02:41]
WESTERN DIGITAL CORPORATION

[0001193125-15-356330:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001193125-15-356330:8k_2_02:43]
(in millions, except per share amounts; unaudited)

[0001193125-15-356330:8k_2_02:44]
|  |  | Three Months Ended |  |
|  |  | Oct. 2,2015 |  |  | Oct. 3,2014 |  |
| Revenue, net |  | $ | 3,360 |  |  | $ | 3,943 |  |
| Cost of revenue |  |  | 2,405 |  |  |  | 2,794 |  |
| Gross profit |  |  | 955 |  |  |  | 1,149 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 385 |  |  |  | 437 |  |
| Selling, general and administrative |  |  | 192 |  |  |  | 220 |  |
| Charges related to arbitration award |  |  | — |  |  |  | 14 |  |
| Employee termination, asset impairment and other charges |  |  | 56 |  |  |  | 9 |  |
| Total operating expenses |  |  | 633 |  |  |  | 680 |  |
| Operating income |  |  | 322 |  |  |  | 469 |  |
| Net interest and other |  |  | (8 | ) |  |  | (9 | ) |
| Income before income taxes |  |  | 314 |  |  |  | 460 |  |
| Income tax provision |  |  | 31 |  |  |  | 37 |  |
| Net income |  | $ | 283 |  |  | $ | 423 |  |
| Income per common share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.23 |  |  | $ | 1.81 |  |
| Diluted |  | $ | 1.21 |  |  | $ | 1.76 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 231 |  |  |  | 234 |  |
| Diluted |  |  | 234 |  |  |  | 240 |  |

[0001193125-15-356330:8k_2_02:45]
WESTERN DIGITAL CORPORATION

[0001193125-15-356330:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-356330:8k_2_02:47]
(in millions; unaudited)

[0001193125-15-356330:8k_2_02:48]
|  |  | Three Months Ended |  |
|  |  | Oct. 2,2015 |  |  | Oct. 3,2014 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 283 |  |  | $ | 423 |  |
| Adjustments to reconcile net income to net cash provided by operations: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 236 |  |  |  | 289 |  |
| Stock-based compensation |  |  | 42 |  |  |  | 39 |  |
| Deferred income taxes |  |  | (7 | ) |  |  | 10 |  |
| Loss on disposal of assets |  |  | — |  |  |  | 4 |  |
| Non-cash portion of employee termination, asset impairment and other charges |  |  | 18 |  |  |  | 1 |  |
| Changes in operating assets and liabilities, net |  |  | (27 | ) |  |  | 61 |  |
| Net cash provided by operating activities |  |  | 545 |  |  |  | 827 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (151 | ) |  |  | (160 | ) |
| Purchases of investments |  |  | (236 | ) |  |  | (120 | ) |
| Proceeds from sales and maturities of investments |  |  | 124 |  |  |  | 166 |  |
| Other investing activities, net |  |  | (10 | ) |  |  | (12 | ) |
| Net cash used in investing activities |  |  | (273 | ) |  |  | (126 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Employee stock plans, net |  |  | (9 | ) |  |  | 2 |  |
| Repurchases of common stock |  |  | (60 | ) |  |  | (223 | ) |
| Dividends paid to shareholders |  |  | (115 | ) |  |  | (94 | ) |
| Repayment of debt |  |  | (31 | ) |  |  | (31 | ) |
| Net cash used in financing activities |  |  | (215 | ) |  |  | (346 | ) |
| Net increase in cash and cash equivalents |  |  | 57 |  |  |  | 355 |  |
| Cash and cash equivalents, beginning of period |  |  | 5,024 |  |  |  | 4,804 |  |
| Cash and cash equivalents, end of period |  | $ | 5,081 |  |  | $ | 5,159 |  |

[0001193125-15-356330:8k_2_02:49]
WESTERN DIGITAL CORPORATION

[0001193125-15-356330:8k_2_02:50]
GAAP TO NON-GAAP NET INCOME RECONCILIATION

[0001193125-15-356330:8k_2_02:51]
(in millions, except per share amounts; unaudited)

[0001193125-15-356330:8k_2_02:52]
|  |  | Three Months Ended |  |
|  |  | Oct. 2,2015 |  |  | Oct. 3,2014 |  |
| GAAP net income |  | $ | 283 |  |  | $ | 423 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 25 |  |  |  | 46 |  |
| Employee termination, asset impairment and other charges |  |  | 56 |  |  |  | 9 |  |
| Charges related to arbitration award |  |  | — |  |  |  | 14 |  |
| Other |  |  | 2 |  |  |  | 12 |  |
| Non-GAAP net income |  | $ | 366 |  |  | $ | 504 |  |
| Diluted net income per common share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 1.21 |  |  | $ | 1.76 |  |
| Non-GAAP |  | $ | 1.56 |  |  | $ | 2.10 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Diluted |  |  | 234 |  |  |  | 240 |  |

[0001193125-15-356330:8k_2_02:53]
The table above sets forth non-GAAP net income and non-GAAP diluted net income per common share. These non-GAAP net income and
diluted net income per common share measures exclude amortization of intangible assets related to acquisitions, certain employee termination, asset impairment and other charges, certain charges related to an arbitration award and other charges that
are unusual, non-recurring or may not be indicative of ongoing operations. The company believes that non-GAAP net income and non-GAAP earnings per share are useful measures to investors as an alternative method for measuring the company’s
earnings performance and comparing it against prior periods. The presentation of these adjusted amounts vary from numbers presented in accordance with U.S. GAAP and therefore may not be comparable to amounts reported by other companies. The tax
effect of the aforementioned items was not material to the condensed consolidated statements of income for the three months ended October 2, 2015 and October 3, 2014.
