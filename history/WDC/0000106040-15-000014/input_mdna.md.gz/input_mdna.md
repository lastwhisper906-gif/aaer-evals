# WDC MD&A — 0000106040-15-000014


## mdna

[0000106040-15-000014:mdna:1]
[same as prior period, unchanged from 0001628280-15-004065:mdna:1]

[0000106040-15-000014:mdna:2]
You should read this information in conjunction with the unaudited condensed consolidated financial statements and the notes thereto included in this Quarterly Report on Form 10-Q, and the audited consolidated financial statements and notes thereto and Part II, Item 7, contained in our Annual Report on Form 10-K for the year ended July 3, 2015.

[0000106040-15-000014:mdna:3]
[same as prior period, unchanged from 0001628280-15-004065:mdna:3]

[0000106040-15-000014:mdna:4]
[same as prior period, unchanged from 0001628280-15-004065:mdna:4]

[0000106040-15-000014:mdna:5]
| • | expectations concerning our planned acquisition of SanDisk Corporation (“SanDisk”); |

[0000106040-15-000014:mdna:6]
| • | expectations regarding the planned equity investment by Unisplendour Corporation Limited (“Unis”); |

[0000106040-15-000014:mdna:7]
| • | expectations regarding the integration of our HGST and WD subsidiaries following the decision by the Ministry of Commerce of the People’s Republic of China (“MOFCOM”) in October 2015; |

[0000106040-15-000014:mdna:8]
| • | expectations regarding the growth of digital data and demand for digital storage; |

[0000106040-15-000014:mdna:9]
| • | our plans to develop and invest in new products and expand into new storage markets and into emerging economic markets; |

[0000106040-15-000014:mdna:10]
| • | expectations regarding the PC market and the emergence of new storage markets for our products; |

[0000106040-15-000014:mdna:11]
[same as prior period, unchanged from 0001628280-15-004065:mdna:14]

[0000106040-15-000014:mdna:12]
| • | expectations regarding the outcome of legal proceedings in which we are involved; |

[0000106040-15-000014:mdna:13]
| • | expectations regarding the repatriation of funds from our foreign operations; |

[0000106040-15-000014:mdna:14]
[same as prior period, unchanged from 0001628280-15-004065:mdna:21]

[0000106040-15-000014:mdna:15]
| • | our beliefs regarding the sufficiency of our available liquidity to meet our working capital, debt, dividend and capital expenditure needs; and |

[0000106040-15-000014:mdna:16]
| • | expectations regarding our debt financing plans. |

[0000106040-15-000014:mdna:17]
[same as prior period, unchanged from 0001628280-15-004065:mdna:24]

[0000106040-15-000014:mdna:18]
We are a leading developer, manufacturer and provider of data storage solutions that enable consumers, businesses, governments and other organizations to create, manage, experience and preserve digital content. Our product portfolio includes hard disk drives (“HDDs”), solid state drives ("SSDs"), direct attached storage solutions, personal cloud network attached storage solutions, and public and private cloud data center storage solutions. HDDs are our principal products and are today’s primary storage medium for the vast majority of digital content, with the use of solid-state storage products growing rapidly. Our products are marketed under the HGST and WD brand names.

[0000106040-15-000014:mdna:19]
In accordance with accounting principles generally accepted in the United States (“U.S. GAAP”), operating results for Amplidata NV ("Amplidata"), which we acquired on March 9, 2015, are included in our operating results only after the date of acquisition.

[0000106040-15-000014:mdna:20]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, we report a 53-week fiscal year to align our fiscal year with the foregoing policy. Our fiscal first quarters ended October 2, 2015 and October 3, 2014 consisted of 13 and 14 weeks, respectively. Fiscal 2015 was comprised of 53 weeks and ended on July 3, 2015. Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016.

[0000106040-15-000014:mdna:21]
Recent Developments

[0000106040-15-000014:mdna:22]
Joint Venture

[0000106040-15-000014:mdna:23]
On November 9, 2015, we announced an agreement to form a joint venture with Unis to market and sell our current data center storage systems in China and to develop data storage systems for the Chinese market in the future.  The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by us.  The joint venture is expected to become operational by the fourth quarter of fiscal 2016, pending regulatory approvals.

[0000106040-15-000014:mdna:24]
Planned Acquisition of SanDisk

[0000106040-15-000014:mdna:25]
On October 21, 2015, we entered into an Agreement and Plan of Merger with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of our company will merge with and into SanDisk, with SanDisk surviving as a wholly owned subsidiary of our company. The planned acquisition is primarily intended to deepen our expertise in non-volatile memory and enable us to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-15-000014:mdna:26]
The merger agreement values SanDisk's outstanding common stock at a value of $86.50 per share, or a total equity value of approximately $18.9 billion, based on the volume weighted average price of our common stock for the five trading days ending on October 20, 2015. If the Unis Investment (see "Investment by Unis" below) closes prior to the acquisition, we will pay $85.10 per share in cash and issue 0.0176 shares of our common stock per share of SanDisk’s common stock; and if the Unis Investment has not occurred or has been terminated, we will pay $67.50 per share in cash and issue 0.2387 shares of our common stock per share of SanDisk’s common stock. The above allocation between cash and shares of our common stock is subject to reallocation, at our election, if the amount of cash that SanDisk has available at the closing of the planned merger falls below certain thresholds.

[0000106040-15-000014:mdna:27]
The planned acquisition will be financed by a mix of cash, new debt financing and issuance of our common stock. In connection with the planned acquisition, we expect to enter into new debt facilities totaling $18.1 billion. The proceeds from the new debt facilities are expected to be used to pay part of the purchase price, refinance existing debt of both our company and SanDisk and pay transaction related fees and expenses.

[0000106040-15-000014:mdna:28]
Consummation of the merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and, if the Unis Investment has not occurred or has been terminated, approval by our

[0000106040-15-000014:mdna:29]
21

[0000106040-15-000014:mdna:30]
shareholders; (ii) the expiration or early termination of the waiting period applicable to the consummation of the merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the receipt of regulatory clearance under certain foreign antitrust laws, including the European Union and China; and (iii) if the Unis Investment has not been terminated and is a “covered transaction” for U.S. Committee on Foreign Investment in the United States ("CFIUS") purposes, or if CFIUS otherwise requests or requires a filing with respect to the merger, the approval of CFIUS. In certain circumstances, a termination fee may be payable by either us or SanDisk upon termination of the transaction as more fully described in the merger agreement. The acquisition is expected to close in the first quarter of fiscal 2017.

[0000106040-15-000014:mdna:31]
MOFCOM Decision

[0000106040-15-000014:mdna:32]
In connection with the regulatory approval process of the Hitachi Global Storage Technologies Holdings Pte. Ltd. ("HGST") acquisition, which closed on March 8, 2012, we agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, we have operated our global business through two independent subsidiaries — HGST and WD. In March 2014, we submitted an application to MOFCOM to lift the condition it imposed on us to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to our application that permits us to integrate our HGST and WD subsidiaries, except that we committed to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision. We began integration planning activities immediately following the MOFCOM decision and integration is expected to occur in phases through October 2017.

[0000106040-15-000014:mdna:33]
Investment by Unis

[0000106040-15-000014:mdna:34]
On September 30, 2015, we announced that we had entered into an agreement with Unis and Unis Union Information System Ltd., a subsidiary of Unis ("Investor"), pursuant to which Investor will make a $3.8 billion equity investment in our company (the "Unis Investment"). Under the terms of the agreement for the Unis Investment, Investor has agreed to purchase 40,814,802 shares of newly issued common stock at a price of $92.50 per share and has agreed to a five-year position standstill, voting restrictions, and a five-year lock-up on its shares, with a limited number becoming available for transfer each year. Following the closing of the investment, Unis will have the right to nominate one representative for election to our Board of Directors, so long as Unis holds more than 10% of the issued and outstanding shares of our common stock. The performance of Investor’s obligations pursuant to the agreement, including payment of the purchase price for the shares, is guaranteed by Unis. The closing of the Unis Investment is subject to clearance by CFIUS, the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, approval of the transaction by shareholders of Unis and other customary closing conditions. The investment is expected to close in the second or third quarter of fiscal 2016.

[0000106040-15-000014:mdna:35]
First Quarter Overview

[0000106040-15-000014:mdna:36]
For the quarter ended October 2, 2015, we believe that overall HDD industry shipments totaled approximately 119 million units, down 19% from the prior-year period and up 7% from the quarter ended July 3, 2015.

[0000106040-15-000014:mdna:37]
[same as prior period, unchanged from 0001628280-15-004065:mdna:31]

[0000106040-15-000014:mdna:38]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Net revenue | $ | 3,360 |  |  | 100.0 | % |  | $ | 3,943 |  |  | 100.0 | % |
| Gross profit | 955 |  |  | 28.4 |  |  | 1,149 |  |  | 29.1 |  |
| Total operating expenses | 633 |  |  | 18.8 |  |  | 680 |  |  | 17.2 |  |
| Operating income | 322 |  |  | 9.6 |  |  | 469 |  |  | 11.9 |  |
| Net income | 283 |  |  | 8.4 |  |  | 423 |  |  | 10.7 |  |

[0000106040-15-000014:mdna:39]
The following is a summary of our financial performance for the first quarter of fiscal 2016:

[0000106040-15-000014:mdna:40]
| • | Consolidated net revenue totaled $3.4 billion. |

[0000106040-15-000014:mdna:41]
| • | Net revenue derived from enterprise SSDs was $233 million as compared to $156 million in the prior-year period. |

[0000106040-15-000014:mdna:42]
| • | HDD shipments decreased 20% from the prior-year period to 51.7 million units. |

[0000106040-15-000014:mdna:43]
| • | Gross margin decreased to 28.4% as compared to 29.1% in the prior-year period. |

[0000106040-15-000014:mdna:44]
[same as prior period, unchanged from 0001628280-15-004065:mdna:11]

[0000106040-15-000014:mdna:45]
| • | Operating income decreased to $322 million as compared to $469 million in the prior-year period. |

[0000106040-15-000014:mdna:46]
| • | We generated $545 million in cash flow from operations and ended the quarter with $5.1 billion in cash and cash equivalents. |

[0000106040-15-000014:mdna:47]
[same as prior period, unchanged from 0001628280-15-004065:mdna:40]

[0000106040-15-000014:mdna:48]
[same as prior period, unchanged from 0001628280-15-004065:mdna:41]

[0000106040-15-000014:mdna:49]
|  | Three Months Ended |  |  |
| (in millions, except percentages andaverage selling price) | October 2, 2015 |  | October 3, 2014 |  | Percentage Change |
| Net revenue | $ | 3,360 |  |  | $ | 3,943 |  |  | (15 | )% |
| Average selling price (per unit)* | $ | 60 |  |  | $ | 58 |  |  | 3 | % |
| Revenues by Geography (%) |  |  |  |  |  |
| Americas | 30 | % |  | 27 | % |  |  |
| Europe, Middle East and Africa | 21 |  |  | 21 |  |  |  |
| Asia | 49 |  |  | 52 |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |
| OEM | 67 | % |  | 63 | % |  |  |
| Distributors | 21 |  |  | 24 |  |  |  |
| Retailers | 12 |  |  | 13 |  |  |  |
| Unit Shipments* |  |  |  |  |  |
| PC | 27.5 |  |  | 39.7 |  |  |  |
| Non-PC | 24.2 |  |  | 25.0 |  |  |  |
| Total units shipped | 51.7 |  |  | 64.7 |  |  | (20 | )% |

[0000106040-15-000014:mdna:50]
| * | Based on sales of HDD units only. |

[0000106040-15-000014:mdna:51]
For the quarter ended October 2, 2015, net revenue was $3.4 billion, a decrease of 15% from the prior-year period. This decrease in revenue was primarily the result of a softer demand environment largely driven by a decline in PC markets, partially offset by an increase in the average selling price ("ASP") for HDDs due to changes in product mix. Total hard drive shipments decreased to 51.7 million units for the quarter ended October 2, 2015 as compared to 64.7 million units in the prior-year period. For the quarter ended October 2, 2015, the ASP for HDDs increased to $60 compared to the prior-year period ASP for HDDs of $58.

[0000106040-15-000014:mdna:52]
Changes in net revenue by geography and channel generally reflect normal fluctuations in market demand and competitive dynamics. For the three months ended October 2, 2015 and October 3, 2014, Hewlett-Packard Company accounted for approximately 13% and 11% of our net revenue, respectively.

[0000106040-15-000014:mdna:53]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. Generally, total sales incentive and marketing programs range from 7% to 11% of gross revenues per quarter. For the three months ended October 2, 2015, these programs represented 11% of gross revenues, as compared to 9% in the prior-year period. These amounts generally vary according to several factors, including industry conditions, seasonal demand, competitor actions, channel mix and overall availability of product. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue from the current range. Adjustments to revenues due to changes in accruals for these programs related to revenues reported in prior periods have averaged 0.6% of quarterly gross revenue since the first quarter of fiscal 2014.

[0000106040-15-000014:mdna:54]
[same as prior period, unchanged from 0001628280-15-004065:mdna:30]

[0000106040-15-000014:mdna:55]
[same as prior period, unchanged from 0001628280-15-004065:mdna:49]

[0000106040-15-000014:mdna:56]
|  | Three Months Ended |  |  |
| (in millions, except percentages) | October 2, 2015 |  | October 3, 2014 |  | Percentage Change |
| Net revenue | $ | 3,360 |  |  | $ | 3,943 |  |  | (15 | )% |
| Gross profit | 955 |  |  | 1,149 |  |  | (17 | )% |
| Gross margin | 28.4 | % |  | 29.1 | % |  |  |

[0000106040-15-000014:mdna:57]
For the three months ended October 2, 2015, gross margin decreased to 28.4%, as compared to 29.1% for the prior-year period. This decrease in gross margin was primarily the result of a change in product mix.

[0000106040-15-000014:mdna:58]
[same as prior period, unchanged from 0001628280-15-004065:mdna:52]

[0000106040-15-000014:mdna:59]
|  | Three Months Ended |  |  |
| (in millions, except percentages) | October 2, 2015 |  | October 3, 2014 |  | Percentage Change |
| R&D expense | $ | 385 |  |  | $ | 437 |  |  | (12 | )% |
| SG&A expense | 192 |  |  | 220 |  |  | (13 | )% |
| Charges related to arbitration award | — |  |  | 14 |  |  | (100 | )% |
| Employee termination, asset impairment and other charges | 56 |  |  | 9 |  |  | 522 | % |
| Total operating expenses | $ | 633 |  |  | $ | 680 |  |  |  |

[0000106040-15-000014:mdna:60]
Research and development (“R&D”) expense was $385 million for the three months ended October 2, 2015, a decrease of $52 million from the prior-year period. This decrease was primarily the result of an additional week of operating expenses during the first fiscal quarter of the prior-year period and lower incentive compensation in the three months ended October 2, 2015 as compared to the prior-year period. As a percentage of net revenue, R&D expense was 11.5% in the three months ended October 2, 2015, as compared to 11.1% in the prior-year period.

[0000106040-15-000014:mdna:61]
Selling, general and administrative (“SG&A”) expense was $192 million for the three months ended October 2, 2015, a decrease of $28 million from the prior-year period. This decrease was primarily the result of an additional week of operating expenses during the first fiscal quarter of the prior-year period and lower incentive compensation in the three months ended October 2, 2015 as compared to the prior-year period. SG&A expense as a percentage of net revenue was 5.7% in the three months ended October 2, 2015, as compared to 5.6% in the prior-year period.

[0000106040-15-000014:mdna:62]
During the three months ended October 3, 2014, we recorded $14 million of interest charges related to an arbitration award for claims brought against us and a now former employee of ours by Seagate Technology LLC. In October 2014, we paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 2014. For additional information, refer to Part I, Item 1, Note 5 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:63]
During the three months ended October 2, 2015, we recorded employee termination, asset impairment and other charges of $56 million in order to realign our operations with anticipated market demand, as compared to $9 million in the prior-year period. For additional information, refer to Part I, Item 1, Note 12 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:64]
[same as prior period, unchanged from 0001628280-15-004065:mdna:60]

[0000106040-15-000014:mdna:65]
Other expense, net for the three months ended October 2, 2015 was $8 million, as compared to $9 million in the prior-year period. This decrease was a result of a slight increase in interest and other income due to a higher average daily invested cash balance, as compared to the prior-year period. Interest and other expense remained flat compared to the prior-year period.

[0000106040-15-000014:mdna:66]
[same as prior period, unchanged from 0001628280-15-004065:mdna:62]

[0000106040-15-000014:mdna:67]
Our income tax provision for the three months ended October 2, 2015 was $31 million, as compared to $37 million in the prior-year period. This decrease was primarily a result of lower income before income taxes. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits. For additional

[0000106040-15-000014:mdna:68]
[same as prior period, unchanged from 0001628280-15-004065:mdna:45]

[0000106040-15-000014:mdna:69]
information, refer to Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:70]
[same as prior period, unchanged from 0001628280-15-004065:mdna:64]

[0000106040-15-000014:mdna:71]
We ended the first quarter of fiscal 2016 with total cash and cash equivalents of $5.1 billion. The following table summarizes our statements of cash flows (in millions):

[0000106040-15-000014:mdna:72]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Net cash flow provided by (used in): |  |  |  |
| Operating activities | $ | 545 |  |  | $ | 827 |  |
| Investing activities | (273 | ) |  | (126 | ) |
| Financing activities | (215 | ) |  | (346 | ) |
| Net increase in cash and cash equivalents | $ | 57 |  |  | $ | 355 |  |

[0000106040-15-000014:mdna:73]
Our investment policy is to manage our investment portfolio to preserve principal and liquidity while maximizing return through the full investment of available funds. We believe our current cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt, dividend, and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:74]
As discussed above under Recent Developments, in connection with our planned acquisition of SanDisk, we expect to enter into new debt facilities totaling $18.1 billion. We have received commitments for a $1.0 billion revolving credit facility, $3.0 billion in amortizing term loans, $6.0 billion in other term loans and $8.1 billion in secured and unsecured bridge facilities. We expect to issue approximately $5.1 billion in secured and unsecured notes in lieu of drawing the bridge facilities at close, with the balance of the bridge facilities to be repaid with available cash. The proceeds from the new debt facilities are expected to be used to pay a portion of the purchase price for our planned acquisition of SanDisk, refinance existing debt of both our company and SanDisk and pay transaction related fees and expenses. Also as discussed above under Recent Developments, on September 29, 2015, we entered into an agreement with Unis under which a subsidiary of Unis will make a $3.8 billion equity investment in our company, which we expect will close in the second or third quarter of fiscal 2016.

[0000106040-15-000014:mdna:75]
A total of $4.5 billion and $4.3 billion of our cash and cash equivalents was held outside of the United States as of October 2, 2015 and July 3, 2015, respectively. Substantially all of the amounts held outside of the United States are intended to be indefinitely reinvested in foreign operations. Our current plans do not anticipate that we will need funds generated from foreign operations to fund our domestic operations or dividends to our shareholders pursuant to our quarterly cash dividend policy. In the event funds from foreign operations are needed in the United States, any repatriation could result in the accrual and payment of additional U.S. income tax.

[0000106040-15-000014:mdna:76]
[same as prior period, unchanged from 0001628280-15-004065:mdna:71]

[0000106040-15-000014:mdna:77]
Net cash provided by operating activities was $545 million during the three months ended October 2, 2015 as compared to $827 million provided by operating activities in the prior-year period. Cash flow from operating activities consists of net income, adjusted for non-cash charges, plus or minus working capital changes. This represents our principal source of cash. The decline in cash provided by operating activities compared to the prior-year period was primarily attributable to the lower net income in the current period. Net cash used by working capital changes was $27 million for the three months ended October 2, 2015 as compared to $61 million provided by working capital changes in the prior-year period.

[0000106040-15-000014:mdna:78]
[same as prior period, unchanged from 0001628280-15-004065:mdna:73]

[0000106040-15-000014:mdna:79]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Days sales outstanding | 44 |  |  | 48 |  |
| Days in inventory | 48 |  |  | 45 |  |
| Days payables outstanding | (68 | ) |  | (71 | ) |
| Cash conversion cycle | 24 |  |  | 22 |  |

[0000106040-15-000014:mdna:80]
For the three months ended October 2, 2015, our days sales outstanding (“DSOs”) decreased by 4 days, days in inventory (“DIOs”) increased by 3 days, and days payable outstanding (“DPOs”) decreased by 3 days compared to the prior year period. Changes in DSOs are generally due to both the linearity of shipments and the sale of trade receivables in connection with our factoring agreement. Changes in DIOs are generally related to the timing of inventory builds. Changes in DPOs are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-15-000014:mdna:81]
[same as prior period, unchanged from 0001628280-15-004065:mdna:76]

[0000106040-15-000014:mdna:82]
Net cash used in investing activities for the three months ended October 2, 2015 was $273 million as compared to $126 million used in investing activities in the prior-year period. Net cash used in investing activities for the three months ended October 2, 2015 consisted of $236 million related to the purchase of investments, $151 million of capital expenditures and a net $10 million of other investing activities, partially offset by $124 million of proceeds from sales and maturities of investments. Net cash used in investing activities for the three months ended October 3, 2014 consisted of $160 million of capital expenditures, $120 million related to the purchase of investments and a net $12 million of other investing activities, offset by $166 million of proceeds from sales and maturities of investments.

[0000106040-15-000014:mdna:83]
[same as prior period, unchanged from 0001628280-15-004065:mdna:78]

[0000106040-15-000014:mdna:84]
Net cash used in financing activities for the three months ended October 2, 2015 was $215 million as compared to $346 million used in financing activities in the prior-year period. Net cash used in financing activities for the three months ended October 2, 2015 consisted of $115 million used to pay dividends on our common stock, $60 million used to repurchase shares of our common stock, $31 million used to make principal payments on the term loan facility and a net $9 million used by employee stock plans. Net cash used in financing activities for the three months ended October 3, 2014 consisted of $223 million used to repurchase shares of our common stock, $31 million used to make principal payments on the term loan and $94 million used to pay dividends on our common stock, offset by a net $2 million provided by employee stock plans.

[0000106040-15-000014:mdna:85]
[same as prior period, unchanged from 0001628280-15-004065:mdna:80]

[0000106040-15-000014:mdna:86]
[same as prior period, unchanged from 0001628280-15-004065:mdna:81]

[0000106040-15-000014:mdna:87]
[same as prior period, unchanged from 0001628280-15-004065:mdna:83]

[0000106040-15-000014:mdna:88]
Debt — As of October 2, 2015, we had $255 million outstanding on our revolving credit facility and $2.3 billion outstanding on our term loan facility. We are required to make quarterly principal payments on the term loan facility totaling $125 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019. As of October 2, 2015, under our credit agreement, we were in compliance with all covenants. In connection with our planned acquisition of SanDisk, we expect to enter into debt facilities totaling $18.1 billion, including a $1.0 billion revolving credit facility. The proceeds from the debt facilities are expected to be used to pay a portion of the purchase price for our planned acquisition of SanDisk, refinance existing debt of both our company and SanDisk and pay transaction-related fees and expenses. For additional information on our outstanding debt, refer to Part I, Item 1, Note 4 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:89]
[same as prior period, unchanged from 0001628280-15-004065:mdna:86]

[0000106040-15-000014:mdna:90]
[same as prior period, unchanged from 0001628280-15-004065:mdna:87]

[0000106040-15-000014:mdna:91]
[same as prior period, unchanged from 0001628280-15-004065:mdna:88]

[0000106040-15-000014:mdna:92]
Refer to Part II, Item 7 of our Annual Report on Form 10-K for the year ended July 3, 2015, for further discussion of our purchase orders and purchase agreements and the associated dollar amounts. See Part II, Item 1A of this Quarterly Report on Form 10-Q for a discussion of the risks associated with these commitments.

[0000106040-15-000014:mdna:93]
[same as prior period, unchanged from 0001628280-15-004065:mdna:90]

[0000106040-15-000014:mdna:94]
[same as prior period, unchanged from 0001628280-15-004065:mdna:91]

[0000106040-15-000014:mdna:95]
[same as prior period, unchanged from 0001628280-15-004065:mdna:92]

[0000106040-15-000014:mdna:96]
Unrecognized Tax Benefits — As of October 2, 2015, the amount of unrecognized tax benefits was $360 million, of which $299 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations. See Part I, Item 1, Note 6 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our total tax liability for unrecognized tax benefits.

[0000106040-15-000014:mdna:97]
[same as prior period, unchanged from 0001628280-15-004065:mdna:82]

[0000106040-15-000014:mdna:98]
Stock Repurchase Program — Our Board of Directors previously authorized a stock repurchase program. Effective October 21, 2015, in connection with our planned acquisition of SanDisk, we suspended this stock repurchase program. For additional information, refer to Part II, Item 2, Issuer Purchases of Equity Securities in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:99]
Cash Dividend Policy — During the three months ended October 2, 2015, we declared a cash dividend of $0.50 per share of our common stock to shareholders of record as of October 2, 2015, totaling $116 million, which we paid on October 15, 2015. Subsequent to October 2, 2015, on November 3, 2015, we declared a cash dividend of $0.50 per share of our common stock to shareholders of record as of January 1, 2016, which will be paid on January 15, 2016. We may modify, suspend or cancel our cash dividend policy in any manner and at any time. For additional information, refer to Part I, Item 1, Note 9 of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q.

[0000106040-15-000014:mdna:100]
[same as prior period, unchanged from 0001628280-15-004065:mdna:97]

[0000106040-15-000014:mdna:101]
We have prepared the unaudited condensed consolidated financial statements in accordance with U.S. GAAP. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the condensed consolidated financial statements may be material. There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K for the year ended July 3, 2015. Please refer to Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 3, 2015 for a discussion of our critical accounting policies and estimates.

[0000106040-15-000014:mdna:102]
[same as prior period, unchanged from 0001628280-15-004065:mdna:99]

[0000106040-15-000014:mdna:103]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, refer to Part I, Item 1, Note 13 of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.
