# WDC notes — 0000106040-15-000014


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000106040-15-000014:notes:1]
The following tables summarize, by major type, the fair value and cost basis of the Company’s investments (in millions):

[0000106040-15-000014:notes:2]
|  | As of October 2, 2015 |
|  | Cost Basis |  | Unrealized Gains |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | 279 |  |  | 1 |  |  | 280 |  |
| U.S. Government agency securities | 116 |  |  | — |  |  | 116 |  |
| Commercial paper | 86 |  |  | — |  |  | 86 |  |
| Certificates of deposit | 221 |  |  | — |  |  | 221 |  |
| Total | $ | 702 |  |  | $ | 1 |  |  | $ | 703 |  |

[0000106040-15-000014:notes:3]
|  | As of July 3, 2015 |
|  | Cost Basis |  | Unrealized Gains (Losses) |  | Fair Value |
| Available-for-sale securities: |  |  |  |  |  |
| U.S. Treasury securities | $ | 287 |  |  | $ | — |  |  | $ | 287 |  |
| U.S. Government agency securities | 95 |  |  | — |  |  | 95 |  |
| Commercial paper | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | 99 |  |  | — |  |  | 99 |  |
| Total | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000106040-15-000014:notes:4]
[same as prior period, unchanged from 0001628280-15-004065:notes:5]

[0000106040-15-000014:notes:5]
The condensed consolidated financial statements include the results of operations of acquired companies commencing after their respective acquisition dates.

[0000106040-15-000014:notes:6]
[same as prior period, unchanged from 0001628280-15-004065:notes:7]

[0000106040-15-000014:notes:7]
On March 9, 2015, the Company acquired Amplidata NV (“Amplidata”), a developer of object storage software for public and private cloud data centers. As a result of the acquisition, Amplidata was fully integrated and became a wholly owned indirect subsidiary of the Company. The purchase price of the acquisition was approximately $267 million, consisting of $245 million funded with available cash at the time of the acquisition, $19 million related to the fair value of a previously-held cost method investment and $3 million related to the fair value of stock options assumed. The acquisition furthers the Company's strategy to expand into higher value data storage platforms and systems that address the growth in storage requirements in cloud data centers.

[0000106040-15-000014:notes:8]
The Company identified and recorded the assets acquired and liabilities assumed at their estimated fair values at the date of acquisition, and allocated the remaining value of $215 million to goodwill. The values assigned to the acquired assets and liabilities are based on preliminary estimates of fair value available as of the date of this Quarterly Report on Form 10-Q, and may be adjusted during the measurement period of up to 12 months from the date of the acquisition as further information becomes available with any changes in the fair values potentially resulting in adjustments to goodwill. The individual tangible and intangible assets acquired as well as the liabilities assumed in the acquisition were immaterial to the Company's condensed consolidated financial statements.

[0000106040-15-000014:notes:9]
The preliminary purchase price allocation for Amplidata is as follows (in millions):

[0000106040-15-000014:notes:10]
|  | March 9, 2015 |
| Tangible assets acquired and liabilities assumed | $ | (24 | ) |
| Intangible assets | 76 |  |
| Goodwill | 215 |  |
| Total | $ | 267 |  |

[0000106040-15-000014:notes:11]
Since the date of acquisition, the Company recorded an increase of $42 million to goodwill which primarily related to an adjustment to the value of deferred taxes acquired, an adjustment to the value of intangible assets acquired, and an adjustment for the fair value of stock options assumed in the acquisition of Amplidata. The primary area of the preliminary purchase price allocation that is not yet finalized due to information that may become available subsequently is income taxes. Any changes in the fair value could potentially result in adjustments to goodwill.

[0000106040-15-000014:notes:12]
The $215 million of goodwill recognized is primarily attributable to the benefits the Company expects to derive from an ability to create HDD storage solutions leveraging the core software acquired and is not expected to be deductible for tax purposes. The impact to revenue and net income attributable to Amplidata was immaterial to the Company’s condensed consolidated financial statements for the three months ended October 2, 2015.


## us-gaap:DebtDisclosureTextBlock

[0000106040-15-000014:notes:13]
4. Debt

[0000106040-15-000014:notes:14]
The Company's credit agreement, which was entered into in January 2014 and subsequently amended (the "Credit Agreement"), provides for $4.0 billion of unsecured loan facilities consisting of a $2.5 billion term loan facility and a $1.5 billion revolving credit facility. The loans under the Credit Agreement have a five-year term. Subject to certain conditions, the credit facilities may be expanded by, or incremental term loans may be obtained for, up to $1.0 billion if existing or new lenders provide additional term or revolving commitments.

[0000106040-15-000014:notes:15]
The term loans and the revolving credit loans may be prepaid in whole or in part at any time without premium or penalty, subject to certain conditions. As of October 2, 2015, the revolving credit facility had a variable interest rate of 1.7% and an outstanding balance of $255 million. The revolving credit facility is classified within current liabilities as of October 2, 2015 due to the Company's intent to repay the borrowings within the next 12 months. As of October 2, 2015, the term loan facility had a variable interest rate of 1.7% and a remaining outstanding balance of $2.3 billion. The Company is required to make quarterly principal payments on the term loan facility totaling $125 million for the remainder of fiscal 2016, $219 million in fiscal 2017, $250 million in fiscal 2018 and the remaining balance of $1.7 billion in fiscal 2019.

[0000106040-15-000014:notes:16]
The Credit Agreement requires the Company to comply with a leverage ratio and an interest coverage ratio calculated on a consolidated basis for the Company and its subsidiaries. In addition, the Credit Agreement contains customary covenants, including covenants that limit or restrict the Company’s and its subsidiaries’ ability to incur liens, incur indebtedness, make certain restricted payments, merge or consolidate and enter into certain speculative hedging arrangements, and customary events of default.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-15-000014:notes:17]
[same as prior period, unchanged from 0001628280-15-004065:notes:26]

[0000106040-15-000014:notes:18]
Although the majority of the Company’s transactions are in U.S. dollars, some transactions are based in various foreign currencies. The Company purchases short-term, foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. These contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. As of October 2, 2015, the Company had outstanding foreign exchange contracts with commercial banks for British Pound Sterling, Euro, Japanese Yen, Malaysian Ringgit, Philippine Peso, Singapore Dollar and Thai Baht, which were designated as either cash flow or fair value hedges.

[0000106040-15-000014:notes:19]
If the derivative is designated as a cash flow hedge, the effective portion of the change in fair value of the derivative is initially deferred in other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts entered into for manufacturing-related activities are reported in cost of revenue and presented within cash flow from operations. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the condensed consolidated financial statements for the three months ended October 2, 2015 and October 3, 2014.

[0000106040-15-000014:notes:20]
A change in the fair value of fair value hedges is recognized in earnings in the period incurred and is reported as a component of cost of revenue or operating expenses, depending on the nature of the underlying hedged item. All fair value hedges were determined to be effective as of October 2, 2015 and July 3, 2015. The changes in fair value on these contracts were immaterial to the condensed consolidated financial statements during the three months ended October 2, 2015 and October 3, 2014.

[0000106040-15-000014:notes:21]
As of October 2, 2015, the net amount of unrealized losses with respect to the Company’s foreign exchange contracts that is expected to be reclassified into earnings within the next 12 months was $50 million. In addition, as of October 2, 2015, the Company did not have any foreign exchange contracts with credit-risk-related contingent features. The Company opened $1.0 billion and closed $1.0 billion in foreign exchange contracts during each of the three months ended October 2, 2015 and October 3, 2014. The fair value and balance sheet location of the Company's foreign exchange contracts as of October 2, 2015 and July 3, 2015 were as follows (in millions):

[0000106040-15-000014:notes:22]
|  | Asset Derivatives | Liability Derivatives |
|  | October 2, 2015 | July 3, 2015 | October 2, 2015 | July 3, 2015 |
| Derivatives Designated asHedging Instruments | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue | Balance SheetLocation | FairValue |
| Foreign exchange contracts | Other current assets | $ | 1 |  | Other current assets | $ | — |  | Accrued expenses | $ | 62 |  | Accrued expenses | $ | 31 |  |

[0000106040-15-000014:notes:23]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting arrangements with the Company's various counterparties, and the net amounts recognized in the condensed consolidated balance sheet as of October 2, 2015 (in millions):

[0000106040-15-000014:notes:24]
| Derivatives Designated asHedging Instruments | Gross Amounts of Recognized Assets (Liabilities) |  | Gross Amounts Offset in the Balance Sheet |  | Net Amounts of Assets (Liabilities) Presented in the Balance Sheet |
| Foreign exchange contracts |  |  |  |  |  |
| Financial assets | $ | 2 |  |  | $ | (1 | ) |  | $ | 1 |  |
| Financial liabilities | (63 | ) |  | 1 |  |  | (62 | ) |
| Total derivative instruments | $ | (61 | ) |  | $ | — |  |  | $ | (61 | ) |

[0000106040-15-000014:notes:25]
The Company had a gross and net liability of $31 million related to its derivative instruments outstanding at July 3, 2015. There were no amounts offset due to master netting arrangements in place at July 3, 2015.

[0000106040-15-000014:notes:26]
[same as prior period, unchanged from 0001628280-15-004065:notes:36]

[0000106040-15-000014:notes:27]
|  | Amount of Loss Recognized inAccumulated OCI on Derivatives | Location ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome | Amount of Gain (Loss) ReclassifiedFrom Accumulated OCI into Income |
| Derivatives in CashFlow Hedging Relationships | Three Months Ended |  | Three Months Ended | Three Months Ended |  | Three Months Ended |
| October 2, 2015 |  | October 3, 2014 | October 2, 2015 | October 3, 2014 |
| Foreign exchange contracts | $ | (53 | ) |  | $ | (22 | ) | Cost of revenue | $ | 28 |  |  | $ | (4 | ) |

[0000106040-15-000014:notes:28]
The total net realized transaction and foreign exchange contract currency gains and losses were not material to the condensed consolidated financial statements during the three months ended October 2, 2015 and October 3, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000106040-15-000014:notes:29]
9. Shareholders' Equity

[0000106040-15-000014:notes:30]
[same as prior period, unchanged from 0001628280-15-004065:notes:40]

[0000106040-15-000014:notes:31]
The following table presents the Company's stock-based compensation and related tax benefit for the three months ended October 2, 2015 and October 3, 2014 (in millions):

[0000106040-15-000014:notes:32]
|  | Three Months Ended |  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
|  | Expense |  | Tax Benefit |  | Expense |  | Tax Benefit |
| Options and ESPP | $ | 19 |  |  | $ | 4 |  |  | $ | 19 |  |  | $ | 5 |  |
| RSUs | 23 |  |  | 6 |  |  | 20 |  |  | 5 |  |
| Total | $ | 42 |  |  | $ | 10 |  |  | $ | 39 |  |  | $ | 10 |  |

[0000106040-15-000014:notes:33]
As of October 2, 2015, total compensation cost related to unvested stock options and ESPP rights issued to employees but not yet recognized was $118 million and will be amortized on a straight-line basis over a weighted average service period of approximately 2.5 years.

[0000106040-15-000014:notes:34]
For purposes of this footnote, references to RSUs include performance stock unit awards. As of October 2, 2015, the aggregate unamortized fair value of all unvested RSUs was $181 million, which will be recognized on a straight-line basis over a weighted average vesting period of approximately 2.1 years.

[0000106040-15-000014:notes:35]
[same as prior period, unchanged from 0001628280-15-004065:notes:44]

[0000106040-15-000014:notes:36]
[same as prior period, unchanged from 0001628280-15-004065:notes:45]

[0000106040-15-000014:notes:37]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life (in years) |  | Aggregate Intrinsic Value |
| Options outstanding at July 3, 2015 | 6.8 |  |  | $ | 50.00 |  |  |  |  |  |
| Granted | 1.6 |  |  | 84.41 |  |  |  |  |  |
| Exercised | (0.5 | ) |  | 29.49 |  |  |  |  |  |
| Forfeited or expired | (0.1 | ) |  | 49.08 |  |  |  |  |  |
| Options outstanding at October 2, 2015 | 7.8 |  |  | $ | 58.58 |  |  | 4.7 |  | $ | 201 |  |
| Exercisable at October 2, 2015 | 3.6 |  |  | $ | 41.37 |  |  | 3.4 |  | $ | 149 |  |
| Vested and expected to vest after October 2, 2015 | 7.6 |  |  | $ | 57.89 |  |  | 4.7 |  | $ | 201 |  |

[0000106040-15-000014:notes:38]
Options granted during the three months ended October 2, 2015 had a weighted average fair value per share of $23.09. As of October 2, 2015, the Company had options outstanding to purchase an aggregate of 4.9 million shares with an exercise price below the quoted price of the Company’s stock on that date resulting in an aggregate intrinsic value of $201 million at that date. During the three months ended October 2, 2015, the aggregate intrinsic value of options exercised under the Company’s stock option plans was $27 million, determined as of the date of exercise, as compared to $86 million in the prior-year period.

[0000106040-15-000014:notes:39]
[same as prior period, unchanged from 0001628280-15-004065:notes:48]

[0000106040-15-000014:notes:40]
[same as prior period, unchanged from 0001628280-15-004065:notes:49]

[0000106040-15-000014:notes:41]
|  | Number ofShares |  | Weighted AverageGrant-DateFair Value |
| RSUs outstanding at July 3, 2015 | 3.0 |  |  | $ | 73.80 |  |
| Granted | 1.2 |  |  | 84.39 |  |
| Vested | (1.5 | ) |  | 62.14 |  |
| Forfeited | (0.1 | ) |  | 81.55 |  |
| RSUs outstanding at October 2, 2015 | 2.6 |  |  | 84.43 |  |
| Expected to vest after October 2, 2015 | 2.5 |  |  | $ | 84.24 |  |

[0000106040-15-000014:notes:42]
The fair value of each RSU is the market price of the Company’s stock on the date of grant. RSUs are generally payable in an equal number of shares of the Company’s common stock at the time of vesting of the units. The fair value of the shares underlying the RSU awards at the date of grant or assumption was $99 million for awards granted in the three months ended October 2, 2015. These amounts are being recognized to expense over the corresponding vesting periods.

[0000106040-15-000014:notes:43]
[same as prior period, unchanged from 0001628280-15-004065:notes:53]

[0000106040-15-000014:notes:44]
During the three months ended October 2, 2015, the Company recognized a $1 million benefit related to adjustments to fair market value as well as the vesting of stock appreciation rights ("SARs"), as compared to $4 million of expense in the prior-year period. There was no tax expense or benefit realized as a result of the aforementioned SARs benefit during the three months ended October 2, 2015, as compared to $1 million during the three months ended October 3, 2014. The Company's SARs will be settled in cash upon exercise. The Company had a total liability of $40 million related to SARs included in accrued expenses in the condensed consolidated balance sheet as of October 2, 2015. As of October 2, 2015, all SARs issued to employees were fully vested, and the fair values are now solely subject to market price fluctuations. As of October 2, 2015, 0.6 million SARs were outstanding with a weighted average exercise price of $7.89. There were no SARs granted during the three months ended October 2, 2015.

[0000106040-15-000014:notes:45]
[same as prior period, unchanged from 0001628280-15-004065:notes:61]

[0000106040-15-000014:notes:46]
The Company's Board of Directors previously authorized $5.0 billion for the repurchase of the Company's common stock and approved the extension of its stock repurchase program to February 3, 2020. The Company repurchased 0.7 million for a total cost of $60 million during the three months ended October 2, 2015. The remaining amount available to be purchased under the Company’s stock repurchase program as of October 2, 2015 was $2.1 billion. Effective October 21, 2015, in connection with the Company's planned acquisition of SanDisk Corporation ("SanDisk"), the stock repurchase program has been suspended.

[0000106040-15-000014:notes:47]
[same as prior period, unchanged from 0001628280-15-004065:notes:63]

[0000106040-15-000014:notes:48]
On September 13, 2012, the Company announced that its Board of Directors had authorized the adoption of a quarterly cash dividend policy. Under the cash dividend policy, holders of the Company’s common stock receive dividends when and as declared by the Company’s Board of Directors. In the three months ended October 2, 2015, the Company declared a cash dividend of $0.50 per share to shareholders of record as of October 2, 2015, totaling $116 million, which was paid on October 15, 2015. Subsequent to October 2, 2015, on November 3, 2015, the Company declared a cash dividend of $0.50 per share of its common stock to shareholders of record as of January 1, 2016, which will be paid on January 15, 2016. The Company may modify, suspend or cancel its cash dividend policy in any manner and at any time.

[0000106040-15-000014:notes:49]
Investment by Unisplendour Corporation Limited ("Unis")

[0000106040-15-000014:notes:50]
On September 30, 2015, the Company announced that it had entered into an agreement with Unis and Unis Union Information System Ltd., a subsidiary of Unis ("Investor"), pursuant to which Investor will make a $3.8 billion equity investment in the Company (the "Unis Investment"). Under the terms of the agreement for the Unis Investment, Investor has agreed to purchase 40,814,802 shares of newly issued common stock of the Company at a price of $92.50 per share and has agreed to a five-year position standstill, voting restrictions, and a five-year lock-up on its shares, with a limited number becoming available for transfer each year. Following the closing of the investment, Unis will have the right to nominate one representative for election to the Company's Board of Directors, so long as Unis holds more than 10% of the issued and outstanding shares of the Company's common stock. The performance of Investor’s obligations pursuant to the agreement, including payment of the purchase price for the shares, is guaranteed by Unis. The closing of the Unis Investment is subject to clearance by the U.S. Committee on Foreign Investment in the United States ("CFIUS"), the receipt of requisite regulatory approvals, including clearance by U.S. antitrust authorities and certain Chinese regulatory approvals, approval of the transaction by shareholders of Unis and other customary closing conditions.


## us-gaap:EarningsPerShareTextBlock

[0000106040-15-000014:notes:51]
[same as prior period, unchanged from 0001628280-15-004065:notes:65]

[0000106040-15-000014:notes:52]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and restricted stock unit awards (“RSUs”).

[0000106040-15-000014:notes:53]
[same as prior period, unchanged from 0001628280-15-004065:notes:67]

[0000106040-15-000014:notes:54]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Net income | $ | 283 |  |  | $ | 423 |  |
| Weighted average shares outstanding: |  |  |  |
| Basic | 231 |  |  | 234 |  |
| Employee stock options and other | 3 |  |  | 6 |  |
| Diluted | 234 |  |  | 240 |  |
| Income per common share: |  |  |  |
| Basic | $ | 1.23 |  |  | $ | 1.81 |  |
| Diluted | $ | 1.21 |  |  | $ | 1.76 |  |
| Anti-dilutive potential common shares excluded* | 4 |  |  | — |  |

[0000106040-15-000014:notes:55]
[same as prior period, unchanged from 0001628280-15-004065:notes:69]


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-15-000014:notes:56]
[same as prior period, unchanged from 0001628280-15-004065:notes:70]

[0000106040-15-000014:notes:57]
[same as prior period, unchanged from 0001628280-15-004065:notes:71]

[0000106040-15-000014:notes:58]
[same as prior period, unchanged from 0001628280-15-004065:notes:72]

[0000106040-15-000014:notes:59]
[same as prior period, unchanged from 0001628280-15-004065:notes:73]

[0000106040-15-000014:notes:60]
[same as prior period, unchanged from 0001628280-15-004065:notes:74]

[0000106040-15-000014:notes:61]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of October 2, 2015 and July 3, 2015, respectively, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values (in millions):

[0000106040-15-000014:notes:62]
|  | Fair Value Measurements at |  |  |
|  | October 2, 2015 |  |  |
|  | Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 643 |  |  | $ | — |  |  | $ | — |  |  | $ | 643 |  |
| Total cash equivalents | 643 |  |  | — |  |  | — |  |  | 643 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 39 |  |  | — |  |  | 39 |  |
| U.S. Government agency securities | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Commercial paper | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Certificates of deposit | — |  |  | 221 |  |  | — |  |  | 221 |  |
| Total short-term investments | — |  |  | 347 |  |  | — |  |  | 347 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 241 |  |  | — |  |  | 241 |  |
| U.S. Government agency securities | — |  |  | 115 |  |  | — |  |  | 115 |  |
| Total long-term investments | — |  |  | 356 |  |  | — |  |  | 356 |  |
| Foreign exchange contracts | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets at fair value | $ | 643 |  |  | $ | 704 |  |  | $ | — |  |  | $ | 1,347 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |

[0000106040-15-000014:notes:63]
|  | Fair Value Measurements at |  |  |
|  | July 3, 2015 |  |  |
|  | Using |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 135 |  |  | $ | — |  |  | $ | — |  |  | $ | 135 |  |
| Total cash equivalents | 135 |  |  | — |  |  | — |  |  | 135 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 50 |  |  | — |  |  | 50 |  |
| U.S. Government agency securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Commercial paper | — |  |  | 109 |  |  | — |  |  | 109 |  |
| Certificates of deposit | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Total short-term investments | — |  |  | 262 |  |  | — |  |  | 262 |  |
| Long-term investments: |  |  |  |  |  |  |  |
| U.S. Treasury securities | — |  |  | 237 |  |  | — |  |  | 237 |  |
| U.S. Government agency securities | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Total long-term investments | — |  |  | 328 |  |  | — |  |  | 328 |  |
| Total assets at fair value | $ | 135 |  |  | $ | 590 |  |  | $ | — |  |  | $ | 725 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000106040-15-000014:notes:64]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government Agency securities. Money market funds are valued based on quoted market prices.

[0000106040-15-000014:notes:65]
U.S. Treasury Securities. The Company’s U.S. Treasury securities are direct obligations of the U.S. federal government and are held in custody by a third party. U.S. Treasury securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000014:notes:66]
U.S. Government Agency Securities. The Company’s U.S. Government agency securities are investments in fixed income securities sponsored by the U.S. Government and are held in custody by a third party. U.S. Government agency securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000014:notes:67]
Commercial Paper. The Company’s commercial paper securities are investments issued by corporations which are held in custody by a third party. Commercial paper securities are valued using a market approach which is based on observable inputs including market interest rates from multiple pricing sources.

[0000106040-15-000014:notes:68]
Certificates of Deposit. The Company’s certificates of deposit are investments which are held in custody by a third party. Certificates of deposit are valued using fixed interest rates.

[0000106040-15-000014:notes:69]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. For contracts that have a right of offset by its individual counterparties under master netting arrangements, the Company presents its foreign exchange contracts on a net basis by counterparty in the consolidated balance sheets. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company's foreign exchange contracts, see Note 8 to these condensed consolidated financial statements.

[0000106040-15-000014:notes:70]
In the three months ended October 2, 2015, there were no transfers between levels. The carrying amounts of cash, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The carrying amount of debt approximates fair value because of its variable interest rate.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-15-000014:notes:71]
[same as prior period, unchanged from 0001628280-15-004065:notes:87]

[0000106040-15-000014:notes:72]
The Company’s income tax provision for the three months ended October 2, 2015 was $31 million as compared to $37 million in the prior-year period. This decrease was primarily a result of lower income before income taxes. The differences between the effective tax rate and the U.S. Federal statutory rate are primarily due to tax holidays in Malaysia, the Philippines, Singapore and Thailand that expire at various dates from 2016 through 2025 and the current year generation of income tax credits.

[0000106040-15-000014:notes:73]
In the three months ended October 2, 2015, the Company recorded a net increase of $10 million in its liability for unrecognized tax benefits. As of October 2, 2015, the Company's liability for unrecognized tax benefits was approximately $360 million. Interest and penalties recognized on such amounts were not material to the condensed consolidated financial statements during the three months ended October 2, 2015.

[0000106040-15-000014:notes:74]
The Internal Revenue Service (“IRS”) previously completed its field examination of the Company's federal income tax returns for fiscal years 2006 through 2009 and proposed certain adjustments. The Company has received Revenue Agent Reports (“RARs”) from the IRS that seek to increase the Company's U.S. taxable income which would result in additional federal tax expense totaling approximately $795 million, subject to interest. The issues in dispute relate primarily to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances. The Company disagrees with the proposed adjustments and in September 2015, filed a protest with the IRS Appeals Office. The Company believes that its tax positions are properly supported and will vigorously contest the position taken by the IRS. In September 2015, the IRS commenced an examination of the Company’s fiscal years 2010 through 2012. During the three months ended October 2, 2015, the IRS completed the examination of the fiscal period ended September 5, 2007 of Komag, Incorporated, which the Company acquired on September 5, 2007, with no material adjustments.

[0000106040-15-000014:notes:75]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of October 2, 2015, it is not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000106040-15-000014:notes:76]
The fair value of the Company’s investments classified as available-for-sale securities at October 2, 2015, by remaining contractual maturity, were as follows (in millions):

[0000106040-15-000014:notes:77]
|  | Cost Basis |  | Fair Value |
| Due in less than one year (short-term investments): | $ | 347 |  |  | $ | 347 |  |
| Due in one to five years (included in other non-current assets): | 355 |  |  | 356 |  |
| Total | $ | 702 |  |  | $ | 703 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-15-000014:notes:78]
5. Legal Proceedings

[0000106040-15-000014:notes:79]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows.

[0000106040-15-000014:notes:80]
Unless otherwise stated below, for each of the matters described below, the Company has either recorded an accrual for losses that are probable and reasonably estimable or has determined that, while a loss is reasonably possible (including potential losses in excess of the amounts accrued by the Company), a reasonable estimate of the amount of loss or range of possible losses with respect to the claim or in excess of amounts already accrued by the Company cannot be made. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates.

[0000106040-15-000014:notes:81]
Solely for purposes of this note, “WD” refers to Western Digital Corporation or one or more of its subsidiaries excluding HGST prior to the closing of the Company's acquisition of HGST on March 8, 2012 (the “HGST Closing Date”). HGST refers to Hitachi Global Storage Technologies Holdings Pte. Ltd. or one or more of its subsidiaries as of the HGST Closing Date, and “the Company” refers to Western Digital Corporation and all of its subsidiaries on a consolidated basis including HGST.

[0000106040-15-000014:notes:82]
Intellectual Property Litigation

[0000106040-15-000014:notes:83]
In June 2008, Convolve, Inc. (“Convolve”) filed a complaint in the Eastern District of Texas against WD, HGST, and two other companies alleging infringement of U.S. Patent Nos. 6,314,473 and 4,916,635. The complaint sought unspecified monetary damages and injunctive relief. In October 2008, Convolve amended its complaint to allege infringement of only the ‘473 patent. The ‘473 patent allegedly relates to interface technology to select between certain modes of a disk drive’s operations relating to speed and noise. In July 2011, a verdict was rendered against WD and HGST in an amount that is not material to the Company’s financial position, results of operations or cash flows, for which the Company previously recorded an accrual. In March 2015, WD and HGST filed Notices of Appeal with the United States District Court for the Federal Circuit (“Federal Circuit”). In April 2015, Convolve filed a motion for reconsideration of the final judgment, and in May 2015, the Federal Circuit deactivated the appeal pending the Court’s decision on reconsideration. WD and HGST intend to continue to defend themselves vigorously in this matter.

[0000106040-15-000014:notes:84]
Seagate Matter

[0000106040-15-000014:notes:85]
In October 2006, Seagate Technology LLC (“Seagate”) brought an action against the Company and a now former employee, alleging misappropriation of confidential information and trade secrets. In January 2012, an arbitrator issued a final award against the Company, including pre-award interest, of $630.4 million. The matter was appealed and, in October 2014, the Minnesota Supreme Court upheld the arbitrator’s award. In October 2014, the Company paid Seagate $773.4 million to satisfy the full amount of the final arbitration award plus interest accrued through October 2014. This amount was paid by one of the Company’s foreign subsidiaries using cash held outside of the United States.

[0000106040-15-000014:notes:86]
Seagate disputes the method the Company used for calculating post-award interest and contends that the Company owes Seagate approximately $29 million in additional interest.  The Company denies Seagate’s contention and believes it calculated interest properly in accordance with the arbitration award.  In April 2015, the District Court declared that all amounts due and owing from the Company to Seagate have been paid, and a corresponding judgment was entered. In May 2015, Seagate appealed the decision and judgment to the Minnesota Court of Appeals, where the matter remains pending. The Company intends to continue to defend itself vigorously in this matter.

[0000106040-15-000014:notes:87]
Other Matters

[0000106040-15-000014:notes:88]
In December 2011, the German Central Organization for Private Copying Rights (Zentralstelle für private Überspielungsrechte), (“ZPÜ”), an organization consisting of several copyright collecting societies, instituted arbitration proceedings against Western Digital's German subsidiary (“WD Germany”) before the Copyright Arbitration Board (“CAB”) claiming copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany from January 2008 through December 2010.  In February 2013, WD Germany filed a declaratory relief action against ZPÜ in the Higher Regional Court of Munich (the “Higher Court”), seeking an order from the court to determine the copyright levy issue.  On May 21, 2013, ZPÜ filed a counter-claim against WD Germany with the Higher Court, seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce from January 2008 through December 2010 based on tariffs published by ZPÜ on November 3, 2011. In January 2015, the Higher Court ruled in favor of ZPÜ. In its ruling, the Higher Court declared that WD Germany must pay certain levies on certain WD products which it sold in Germany between January 2008 and December 2010. The judgment specifies levy amounts on certain WD products sold from January 2008 through December 2010 and directs WD Germany to provide applicable sales data to the ZPÜ. The exact amount of the judgment has not been determined. ZPÜ and WD Germany filed appeals with the German Federal Court of Justice in February 2015. WD intends to defend itself vigorously in this matter.

[0000106040-15-000014:notes:89]
In December 2014, ZPÜ submitted a pleading to the CAB seeking copyright levies for multimedia hard drives, external hard drives and network hard drives sold or introduced into commerce in Germany by WD Germany between January 2012 and December 2013. WD intends to defend itself vigorously in this matter.

[0000106040-15-000014:notes:90]
The Company has recorded an accrual for German copyright levies in an amount that is not material to the Company’s financial position, results of operations or cash flows.  It is reasonably possible that the Company may incur losses totaling up to $101 million, including the amounts accrued.

[0000106040-15-000014:notes:91]
In the normal course of business, the Company is subject to other legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these other matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these other matters could differ materially from the Company's expectations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-15-000014:notes:92]
13. Recent Accounting Pronouncements

[0000106040-15-000014:notes:93]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2015-16, “Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments” (ASU 2015-16”), which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Acquirers must recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. This ASU is effective for fiscal years beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. Earlier adoption is permitted for any interim and annual financial statements that have not yet been issued. The Company is currently evaluating the impact ASU 2015-16 will have on its consolidated financial statements and related disclosures.

[0000106040-15-000014:notes:94]
In April 2015, the FASB issued ASU 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs" ("ASU 2015-03"). The new standard requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The new standard is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2015, which for the Company is the first quarter of fiscal 2017. The Company is currently evaluating the impact ASU 2015-03 will have on its consolidated financial statements and related disclosures.

[0000106040-15-000014:notes:95]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09"), which amends the guidance in former Accounting Standards Codification Topic 605, "Revenue Recognition," to provide a single, comprehensive revenue recognition model for all contracts with customers. The new standard requires an entity to recognize revenue in a manner that depicts the transfer of promised goods or services to customers in amounts that reflect the consideration to which an entity expects to be entitled in exchange for those goods or services. The new standard also requires entities to enhance disclosures about the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of this ASU by one year. The new standard allows for either a full retrospective or a modified retrospective transition method and is effective for fiscal years and interim periods within those years beginning after December 15, 2017, which for the Company is the first quarter of fiscal 2019, and early adoption is permitted beginning after December 15, 2016. The Company has not yet selected a transition method and is currently evaluating the impact ASU 2014-09 will have on its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000106040-15-000014:notes:96]
[same as prior period, unchanged from 0001628280-15-004065:notes:118]

[0000106040-15-000014:notes:97]
The accounting policies followed by Western Digital Corporation (the “Company”) are set forth in Part II, Item 8, Note 1 of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10-K for the year ended July 3, 2015. In the opinion of management, all adjustments necessary to fairly state the unaudited condensed consolidated financial statements have been made. All such adjustments are of a normal, recurring nature. Certain information and footnote disclosures normally included in the consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the year ended July 3, 2015. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0000106040-15-000014:notes:98]
The Company's fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every six years, the Company reports a 53-week fiscal year to align its fiscal year with the foregoing policy. The Company's fiscal first quarters ended October 2, 2015 and October 3, 2014 consisted of 13 and 14 weeks, respectively. Fiscal 2015 was comprised of 53 weeks and ended on July 3, 2015. Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016.

[0000106040-15-000014:notes:99]
[same as prior period, unchanged from 0001628280-15-004065:notes:120]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-15-000014:notes:100]
[same as prior period, unchanged from 0001628280-15-004065:notes:121]

[0000106040-15-000014:notes:101]
The Company’s principal pension and other post-retirement benefit plans are in Japan. All pension and other post-retirement benefit plans outside of the Company’s Japanese plans were immaterial to the Company’s condensed consolidated financial statements for the three months ended October 2, 2015 and October 3, 2014. The expected long-term rate of return on the Japanese plan assets is 2.5%.

[0000106040-15-000014:notes:102]
[same as prior period, unchanged from 0001628280-15-004065:notes:123]

[0000106040-15-000014:notes:103]
|  | October 2, 2015 |  | July 3, 2015 |
| Benefit obligation | $ | 239 |  |  | $ | 231 |  |
| Fair value of plan assets | (193 | ) |  | (185 | ) |
| Unfunded status | $ | 46 |  |  | $ | 46 |  |

[0000106040-15-000014:notes:104]
[same as prior period, unchanged from 0001628280-15-004065:notes:125]

[0000106040-15-000014:notes:105]
|  | October 2, 2015 |  | July 3, 2015 |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 45 |  |  | 45 |  |
| Net amount recognized | $ | 46 |  |  | $ | 46 |  |

[0000106040-15-000014:notes:106]
The net periodic benefit cost of the Company’s pension plans was not material to the condensed consolidated financial statements for the three months ended October 2, 2015 and October 3, 2014. The Company’s expected employer contribution for its Japanese defined benefit pension plans is $10 million in fiscal 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000106040-15-000014:notes:107]
[same as prior period, unchanged from 0001628280-15-004065:notes:128]

[0000106040-15-000014:notes:108]
[same as prior period, unchanged from 0001628280-15-004065:notes:129]

[0000106040-15-000014:notes:109]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Employee termination benefits | $ | 38 |  |  | $ | 8 |  |
| Impairment of assets | 8 |  |  | 1 |  |
| Contract termination and other | 10 |  |  | — |  |
| Total | $ | 56 |  |  | $ | 9 |  |

[0000106040-15-000014:notes:110]
Impairment charges during the three months ended October 2, 2015 primarily relate to equipment.

[0000106040-15-000014:notes:111]
The following table provides those amounts recorded as liabilities within the Company's condensed consolidated balance sheets:

[0000106040-15-000014:notes:112]
|  | July 3, 2015 |  | Accruals |  | Payments |  | October 2, 2015 |
| Employee termination benefits | $ | 10 |  |  | $ | 38 |  |  | $ | (12 | ) |  | $ | 36 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000106040-15-000014:notes:113]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive loss for the three months ended October 2, 2015 (in millions):

[0000106040-15-000014:notes:114]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Unrealized Gain on Available for Sale Securities |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 3, 2015 | $ | 5 |  |  | $ | (25 | ) |  | $ | — |  |  | $ | (20 | ) |
| Other comprehensive loss before reclassifications | — |  |  | (53 | ) |  | 1 |  |  | (52 | ) |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Net current-period other comprehensive loss | — |  |  | (25 | ) |  | 1 |  |  | (24 | ) |
| Balance at October 2, 2015 | $ | 5 |  |  | $ | (50 | ) |  | $ | 1 |  |  | $ | (44 | ) |

[0000106040-15-000014:notes:115]
The following table illustrates the changes in the balances of each component of accumulated other comprehensive loss for the three months ended October 3, 2014 (in millions):

[0000106040-15-000014:notes:116]
|  | Actuarial Pension Gain |  | Unrealized Gain (Loss) on Foreign Exchange Contracts |  | Unrealized Gain (Loss) on Available for Sale Securities |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at June 27, 2014 | $ | 7 |  |  | $ | 5 |  |  | $ | — |  |  | $ | 12 |  |
| Other comprehensive loss before reclassifications | — |  |  | (22 | ) |  | — |  |  | (22 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net current-period other comprehensive loss | — |  |  | (26 | ) |  | — |  |  | (26 | ) |
| Balance at October 3, 2014 | $ | 7 |  |  | $ | (21 | ) |  | $ | — |  |  | $ | (14 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000106040-15-000014:notes:117]
[same as prior period, unchanged from 0001628280-15-004065:notes:137]

[0000106040-15-000014:notes:118]
|  | Three Months Ended |
|  | October 2, 2015 |  | October 3, 2014 |
| Warranty accrual, beginning of period | $ | 221 |  |  | $ | 182 |  |
| Charges to operations | 45 |  |  | 49 |  |
| Utilization | (54 | ) |  | (49 | ) |
| Changes in estimate related to pre-existing warranties | 6 |  |  | 19 |  |
| Warranty accrual, end of period | $ | 218 |  |  | $ | 201 |  |


## us-gaap:SubsequentEventsTextBlock

[0000106040-15-000014:notes:119]
14. Subsequent Events

[0000106040-15-000014:notes:120]
Joint Venture

[0000106040-15-000014:notes:121]
On November 9, 2015, the Company announced an agreement to form a joint venture with Unis to market and sell the Company's current data center storage systems in China and to develop data storage systems for the Chinese market in the future.  The joint venture will be 51% owned by Unis and its subsidiary, Unissoft (Wuxi) Group Co. Ltd., and 49% by the Company.  The joint venture is expected to become operational by the fourth quarter of fiscal 2016, pending regulatory approvals.

[0000106040-15-000014:notes:122]
Planned Acquisition of SanDisk

[0000106040-15-000014:notes:123]
On October 21, 2015, the Company entered into an Agreement and Plan of Merger with SanDisk, a global leader in NAND flash storage solutions, pursuant to which a subsidiary of the Company will merge with and into SanDisk, with SanDisk surviving as a wholly owned subsidiary of the Company. The planned acquisition is primarily intended to deepen the Company's expertise in non-volatile memory and enable the Company to vertically integrate into NAND, securing long-term access to solid state technology at a lower cost.

[0000106040-15-000014:notes:124]
The merger agreement values SanDisk’s outstanding common stock at a value of $86.50 per share, or a total equity value of approximately $18.9 billion, based on the volume weighted average price of the Company’s common stock for the five trading days ending on October 20, 2015. If the Unis Investment closes prior to the acquisition, the Company will pay $85.10 per share in cash and issue 0.0176 shares of its common stock per share of SanDisk’s common stock; and if the Unis Investment has not occurred or has been terminated, the Company will pay $67.50 per share in cash and issue 0.2387 shares of its common stock per share of SanDisk’s common stock. The above allocation between cash and shares of the Company’s common stock is subject to reallocation, at the Company’s election, if the amount of cash that SanDisk has available at the closing of the planned merger falls below certain thresholds.

[0000106040-15-000014:notes:125]
The planned acquisition will be financed by a mix of cash, new debt financing and issuance of the Company’s common stock. In connection with the planned acquisition, the Company expects to enter into new debt facilities totaling $18.1 billion. The Company has received commitments for a $1 billion revolving credit facility, $3 billion in amortizing term loans, $6 billion in other term loans and $8.1 billion in secured and unsecured bridge facilities.  The Company expects to issue approximately $5.1 billion in secured and unsecured notes in lieu of drawing the bridge facilities at close, with the balance of the bridge facilities to be repaid with available cash. The proceeds from the new debt facilities are expected to be used to pay part of the purchase price, refinance existing debt of both the Company and SanDisk and pay transaction related fees and expenses.

[0000106040-15-000014:notes:126]
Consummation of the merger is subject to customary closing conditions, including without limitation: (i) the required approval by SanDisk shareholders and, if the Unis Investment has not occurred or has been terminated, approval by the Company’s shareholders; (ii) the expiration or early termination of the waiting period applicable to the consummation of the merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the receipt of regulatory clearance under certain foreign antitrust laws, including the European Union and China; and (iii) if the Unis Investment has not been terminated and is a “covered transaction” for CFIUS purposes, or if CFIUS otherwise requests or requires a filing with respect to the merger, the approval of CFIUS. In certain circumstances, a termination fee may be payable by either the Company or SanDisk upon termination of the transaction as more fully described in the merger agreement.

[0000106040-15-000014:notes:127]
Ministry of Commerce of the People’s Republic of China (“MOFCOM”) Decision

[0000106040-15-000014:notes:128]
In connection with the regulatory approval process of the Hitachi Global Storage Technologies Holdings Pte. Ltd. ("HGST") acquisition, which closed on March 8, 2012, the Company agreed to certain conditions required by MOFCOM, including adopting measures to maintain HGST as an independent competitor until MOFCOM agreed otherwise. Accordingly, since March 2012, the Company has operated its global business through two independent subsidiaries — HGST and WD.  In March 2014, the Company submitted an application to MOFCOM to lift the condition it imposed on the Company to operate these businesses separately. On October 19, 2015, MOFCOM issued a decision in response to the Company’s application that permits the Company to integrate its HGST and WD subsidiaries, except that the Company committed to continue to maintain two sales teams that will separately offer products under the WD or HGST brands for two years from the date of the decision.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-15-000014:notes:129]
[same as prior period, unchanged from 0001628280-15-004065:notes:139]

[0000106040-15-000014:notes:130]
Accounts Receivable

[0000106040-15-000014:notes:131]
From time to time, in connection with a factoring agreement, the Company sells trade accounts receivable without recourse to a third party purchaser in exchange for cash. The Company sold trade accounts receivable and received cash proceeds of $200 million during the three months ended October 2, 2015. The Company did not sell trade accounts receivable during the three months ended October 3, 2014. The discounts on the sales of trade accounts receivable were not material and were recorded within interest and other expense in the condensed consolidated statements of income.

[0000106040-15-000014:notes:132]
[same as prior period, unchanged from 0001628280-15-004065:notes:140]

[0000106040-15-000014:notes:133]
|  | October 2, 2015 |  | July 3, 2015 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 135 |  |  | $ | 168 |  |
| Work-in-process | 507 |  |  | 500 |  |
| Finished goods | 618 |  |  | 700 |  |
| Total inventories | $ | 1,260 |  |  | $ | 1,368 |  |
| Property, plant and equipment: |  |  |  |
| Property, plant and equipment | $ | 8,635 |  |  | $ | 8,604 |  |
| Accumulated depreciation | (5,745 | ) |  | (5,639 | ) |
| Property, plant and equipment, net | $ | 2,890 |  |  | $ | 2,965 |  |
| Other intangible assets: |  |  |  |
| Other intangible assets | $ | 1,018 |  |  | $ | 1,008 |  |
| Accumulated amortization | (699 | ) |  | (676 | ) |
| Other intangible assets, net | $ | 319 |  |  | $ | 332 |  |

[0000106040-15-000014:notes:134]
[same as prior period, unchanged from 0001628280-15-004065:notes:142]

[0000106040-15-000014:notes:135]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs, and estimated costs for customer compensatory claims related to product quality issues, if any. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates, and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair. If actual product return trends, costs to repair returned products or costs of customer compensatory claims differ significantly from estimates, future results of operations could be materially affected. Changes in the warranty accrual were as follows (in millions):

[0000106040-15-000014:notes:136]
The long-term portion of the warranty accrual classified in other liabilities was $77 million as of October 2, 2015 and $71 million as of July 3, 2015.

[0000106040-15-000014:notes:137]
[same as prior period, unchanged from 0001628280-15-004065:notes:145]

[0000106040-15-000014:notes:138]
The Company determined no available-for-sale securities were other-than-temporarily impaired during the three months ended October 2, 2015 and October 3, 2014. For more information on the Company's available-for-sale securities, see Note 7 to these condensed consolidated financial statements.

[0000106040-15-000014:notes:139]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments are recorded at cost within other non-current assets in the condensed consolidated balance sheets and were not material to the condensed consolidated financial statements as of October 2, 2015 and July 3, 2015.

[0000106040-15-000014:notes:140]
Other Comprehensive Loss, Net of Tax

[0000106040-15-000014:notes:141]
Other comprehensive loss, net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The income tax impact on components of other comprehensive income is immaterial for all periods presented.
