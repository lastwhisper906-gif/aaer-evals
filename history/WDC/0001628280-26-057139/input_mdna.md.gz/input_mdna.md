# WDC MD&A — 0001628280-26-057139


## mdna

[0001628280-26-057139:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-26-057139:mdna:2]
Our Company

[0001628280-26-057139:mdna:3]
We are a leading developer, manufacturer, and provider of data storage devices and solutions based on HDD technology. HDDs are critical components of the global data infrastructure market and play an essential role in enabling the AI-driven data economy. They provide reliable, cost-effective, high-capacity storage for a broad range of applications, including cloud data centers, enterprise storage systems, edge computing, smart video, client and consumer devices.

[0001628280-26-057139:mdna:4]
Our broad portfolio of technology and products, sold under the Western Digital® and WD® brands, addresses our customers’ storage needs through multiple end markets: “Cloud,” “Client” and “Consumer”. Cloud is our largest and fastest growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market offers a comprehensive portfolio of HDD external storage products that we offer globally through our retail and channel partners.

[0001628280-26-057139:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2026, which ended on July 3, 2026, comprised 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks. Fiscal years 2025 and 2024, which ended on June 27, 2025 and June 28, 2024, respectively, each comprised 52 weeks, with all quarters presented consisting of 13 weeks.

[0001628280-26-057139:mdna:6]
Key Developments

[0001628280-26-057139:mdna:7]
Market Conditions and Outlook

[0001628280-26-057139:mdna:8]
The increasing long-term demand for data storage in the cloud is benefiting our HDD business. The adoption of AI and workloads driven by hybrid data are propelling growth in data storage as well. This creates an accelerated demand for higher-capacity drives, which have greater manufacturing complexity and longer production lead times. In response, customers are partnering with us earlier to support their future growth requirements and are extending the duration of their commercial arrangements, which improves our long-term visibility of demand.

[0001628280-26-057139:mdna:9]
Separation of Business Units and Monetization of Sandisk Shares

[0001628280-26-057139:mdna:10]
In the previous fiscal year, on February 21, 2025, we completed the Separation to create two independent public companies, with WD continuing our existing HDD business and Sandisk, formerly a wholly-owned subsidiary of the Company, operating the Flash business. We believe the Separation has better positioned us as a pure-play HDD company that can execute innovative technology and product development, capitalize on unique growth opportunities, extend our leadership position, operate more efficiently, and pursue capital allocation strategies to maximize long-term shareholder value. As part of the Separation, we initially retained 28.8 million shares of Sandisk common stock. In June 2025, we used 21.3 million shares of Sandisk common stock in a tax-free exchange to reduce approximately $800 million in principal amount of our term loan A-3 (the “Term Loan A-3”). In February 2026, we executed a series of transactions pursuant to which we used 5.8 million shares of Sandisk common stock to further reduce our debt and fully redeem our previously outstanding 4.75% senior unsecured notes due 2026, 2.85% senior notes due 2029, 3.10% senior notes due 2032 and Term Loan A-3 through a tax-free exchange. In the fourth quarter of 2026, we completed two separate equity-for-equity exchanges, which used our remaining 1.7 million shares of Sandisk common stock to acquire 4.8 million shares of our common stock, thereby reducing our share count. As of July 3, 2026, we no longer held shares of Sandisk common stock.

[0001628280-26-057139:mdna:11]
Capital Allocation Actions

[0001628280-26-057139:mdna:12]
In addition to the actions taken to monetize our initial retained interest in shares of Sandisk, as noted above, we have continued to take significant actions to deleverage our business, reduce dilution and return capital to our investors.

[0001628280-26-057139:mdna:13]
In February 2026, we converted all remaining outstanding shares of our Preferred Shares, in accordance with their terms, into 7 million shares of our common stock.

[0001628280-26-057139:mdna:14]
In June 2026, we fully settled the conversion obligation on $32 million in aggregate principal amount of our 2028 Convertible Notes that were tendered in March 2026 (the “Tendered Notes”). We used $32 million of cash to settle the principal amount of the Tendered Notes, as required by the indenture, and elected to use an additional $328 million of cash to settle the conversion premium instead of settling the premium with 0.8 million shares of our common stock.

[0001628280-26-057139:mdna:15]
Also in June 2026, we entered into separate, privately negotiated exchange agreements with certain holders of $858 million in aggregate principal of our 2028 Convertible Notes. Pursuant to these agreements, we fully settled the obligation for $860 million in cash (which reflected principal amount and a small inducement cost) and 21.3 million shares of our common stock.

[0001628280-26-057139:mdna:16]
During our previous fiscal year, our Board of Directors authorized the adoption of a quarterly cash dividend program. Under the cash dividend program, holders of our common stock will receive dividends when and as declared by our Board of Directors. During the year ended July 3, 2026, we paid aggregate cash dividends of $0.50 per share of our outstanding common stock, totaling $174 million, plus $2 million paid to holders of our then-outstanding Preferred Shares in accordance with their participation rights.

[0001628280-26-057139:mdna:17]
Subsequent to year-end, on August 4, 2026, our Board of Directors declared a cash dividend of $0.15 per share of our common stock, which will be paid on September 17, 2026 to our shareholders of record as of the close of business on September 8, 2026.

[0001628280-26-057139:mdna:18]
33

[0001628280-26-057139:mdna:19]
During our previous fiscal year, our Board of Directors authorized a Share Repurchase Program for the repurchase of up to $2.0 billion of our common stock, and in February 2026, our Board of Directors authorized the repurchase of up to an additional $4.0 billion of our common stock. During the year ended July 3, 2026, we repurchased 14.7 million shares for a total cost of $2.59 billion. As of July 3, 2026, we had $3.26 billion available for repurchases under the Share Repurchase Program. Repurchases under the Share Repurchase Program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect shares repurchased under the Share Repurchase Program to be funded primarily by operating cash flows.

[0001628280-26-057139:mdna:20]
During the year ended July 3, 2026, our repurchases under our Share Repurchase Program and our election to settle the conversion premium on the Tendered Notes in cash, instead of shares of common stock, aggregated $2.92 billion, which resulted in an effective impact to our outstanding shares of common stock of approximately 15.5 million shares.

[0001628280-26-057139:mdna:21]
Information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, and additional information on the terms of our Preferred Shares is included in Part II, Item 8, Note 7, Debt, and Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:22]
34

[0001628280-26-057139:mdna:23]
Results of Operations

[0001628280-26-057139:mdna:24]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation. See Part II, Item 8, Note 4, Discontinued Operations, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information regarding the Separation.

[0001628280-26-057139:mdna:25]
Summary Comparison of 2026, 2025 and 2024

[0001628280-26-057139:mdna:26]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0001628280-26-057139:mdna:27]
|  |  |  |  |  |  |  |  |  | 2026 |  | 2025 |  |  |  | 2024 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 12,919 |  |  | 100.0 | % |  | $ | 9,520 |  |  | 100.0 | % |  |  |  | $ | 6,317 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 6,608 |  |  | 51.1 |  |  | 5,828 |  |  | 61.2 |  |  |  |  | 4,544 |  |  | 71.9 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 6,311 |  |  | 48.9 |  |  | 3,692 |  |  | 38.8 |  |  |  |  | 1,773 |  |  | 28.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 1,161 |  |  | 9.0 |  |  | 994 |  |  | 10.4 |  |  |  |  | 950 |  |  | 15.0 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 551 |  |  | 4.3 |  |  | 568 |  |  | 6.0 |  |  |  |  | 726 |  |  | 11.5 |  |
| Litigation matter |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  | (198) |  |  | (2.1) |  |  |  |  | 291 |  |  | 4.6 |  |
| Business realignment charges (credits) |  |  |  |  |  |  |  |  |  |  |  |  | 146 |  |  | 1.1 |  |  | (6) |  |  | (0.1) |  |  |  |  | 209 |  |  | 3.3 |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 1,858 |  |  | 14.4 |  |  | 1,358 |  |  | 14.3 |  |  |  |  | 2,176 |  |  | 34.4 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | 4,453 |  |  | 34.5 |  |  | 2,334 |  |  | 24.5 |  |  |  |  | (403) |  |  | (6.4) |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 51 |  |  | 0.4 |  |  | 45 |  |  | 0.5 |  |  |  |  | 33 |  |  | 0.5 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (165) |  |  | (1.3) |  |  | (357) |  |  | (3.8) |  |  |  |  | (414) |  |  | (6.6) |  |
| Gain (loss) on retained interest in Sandisk |  |  |  |  |  |  |  |  |  |  |  |  | 6,498 |  |  | 50.3 |  |  | (772) |  |  | (8.1) |  |  |  |  | — |  |  | — |  |
| Costs in connection with debt-for-equity exchange |  |  |  |  |  |  |  |  |  |  |  |  | (545) |  |  | (4.2) |  |  | (100) |  |  | (1.1) |  |  |  |  | — |  |  | — |  |
| Costs in connection with convertible notes transactions |  |  |  |  |  |  |  |  |  |  |  |  | (108) |  |  | (0.8) |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Costs in connection with equity-for-equity exchanges |  |  |  |  |  |  |  |  |  |  |  |  | (254) |  |  | (2.0) |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |  | (25) |  |  | (0.2) |  |  | (20) |  |  | (0.2) |  |  |  |  | 45 |  |  | 0.7 |  |
| Total interest and other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |  | 5,452 |  |  | 42.2 |  |  | (1,204) |  |  | (12.6) |  |  |  |  | (336) |  |  | (5.3) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | 9,905 |  |  | 76.7 |  |  | 1,130 |  |  | 11.9 |  |  |  |  | (739) |  |  | (11.7) |  |
| Income tax expense (benefit) |  |  |  |  |  |  |  |  |  |  |  |  | 481 |  |  | 3.7 |  |  | (513) |  |  | (5.4) |  |  |  |  | 26 |  |  | 0.4 |  |
| Net income (loss) from continuing operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 9,424 |  |  | 72.9 | % |  | $ | 1,643 |  |  | 17.3 | % |  |  |  | $ | (765) |  |  | (12.1) | % |

[0001628280-26-057139:mdna:28]
(1)Percentages may not total due to rounding.

[0001628280-26-057139:mdna:29]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0001628280-26-057139:mdna:30]
|  |  |  |  |  | 2026 |  | 2025 |  | 2024 |
|  |  |  |  |  | (in millions) |
| Net revenue by end market |  |  |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 11,490 |  |  | $ | 8,341 |  |  | $ | 5,052 |  |
| Client |  |  |  |  | 726 |  |  | 556 |  |  | 577 |  |
| Consumer |  |  |  |  | 703 |  |  | 623 |  |  | 688 |  |
| Total net revenue |  |  |  |  | $ | 12,919 |  |  | $ | 9,520 |  |  | $ | 6,317 |  |
| Net revenue by geography(1) |  |  |  |  |  |  |  |  |  |
| Americas |  |  |  |  | $ | 5,682 |  |  | $ | 4,592 |  |  | $ | 2,858 |  |
| Asia |  |  |  |  | 5,123 |  |  | 3,392 |  |  | 2,392 |  |
| Europe, Middle East and Africa |  |  |  |  | 2,114 |  |  | 1,536 |  |  | 1,067 |  |
| Total net revenue |  |  |  |  | $ | 12,919 |  |  | $ | 9,520 |  |  | $ | 6,317 |  |

[0001628280-26-057139:mdna:31]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer.

[0001628280-26-057139:mdna:32]
Net Revenue

[0001628280-26-057139:mdna:33]
Net revenue increased by 36% in 2026 compared to 2025, primarily driven by a 25% increase in exabytes sold and an 8% increase in ASPs per exabyte, both of which were driven by strong demand across all of our end markets.

[0001628280-26-057139:mdna:34]
Cloud revenue, representing 89% of total net revenue, increased by 38% in 2026 compared to 2025, driven by a 27% increase in exabytes sold and an 8% increase in ASPs per exabyte. The increase in exabytes sold was driven by strong demand for our high-capacity enterprise products. The increase in ASPs per exabyte was due to an improved pricing environment.

[0001628280-26-057139:mdna:35]
Client revenue, representing 6% of total net revenue, increased by 31% in 2026 compared to 2025, driven by a 3% increase in exabytes sold and a 26% increase in ASPs per exabyte. The increase in exabytes sold and ASPs per exabyte were driven by dynamics largely consistent with our other end markets.

[0001628280-26-057139:mdna:36]
Consumer revenue, representing 5% of total net revenue, increased by 13% in 2026 compared to 2025, driven by a 1% increase in exabytes sold and a 12% increase in ASPs per exabyte. The increase in exabytes sold and ASPs per exabyte were driven by dynamics largely consistent with our other end markets.

[0001628280-26-057139:mdna:37]
For 2026, 2025 and 2024, our top 10 customers accounted for 73%, 68% and 55%, respectively, of our net revenue. For 2026, three customers accounted for 16%, 15%, and 13%, respectively, of our net revenue. For 2025, three customers accounted for 17%, 12%, and 10%, respectively, of our net revenue. For 2024, no single customer accounted for 10% or more of our net revenue.

[0001628280-26-057139:mdna:38]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2026, 2025 and 2024, these programs represented 9%, 10% and 11%, respectively, of gross revenue. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0001628280-26-057139:mdna:39]
Gross Profit and Gross Margin

[0001628280-26-057139:mdna:40]
Gross profit increased by $2.62 billion in 2026 compared to 2025. The increase was largely due to an increased volume of shipments, a better cost structure on our newer generation products, a mix shift towards higher capacity drives and improved pricing. Gross margin increased 10.1 percentage points in 2026 compared to 2025. The shift toward higher capacity drives has benefited gross margin through both a better cost structure and improved pricing.

[0001628280-26-057139:mdna:41]
Operating Expenses

[0001628280-26-057139:mdna:42]
R&D expense increased by $167 million or 17% in 2026 compared to 2025. This increase was attributable to $70 million of incremental product development related costs as we continue to execute on our innovative technology and product roadmap, along with $75 million of higher compensation-related costs, reflecting increased headcount and variable compensation aligned with our improved financial performance during the current year.

[0001628280-26-057139:mdna:43]
Selling, general and administrative expense decreased by $17 million or 3% in 2026 compared to 2025, as 2025 included higher costs associated with the final planning and execution of the Separation, including transitional personnel costs and higher outside service fees.

[0001628280-26-057139:mdna:44]
For information regarding Litigation matter, see Part II Item 8, Note 16, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:45]
For information regarding Business realignment charges (credits), see Part II Item 8, Note 10, Business Realignment Charges (Credits), of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:46]
Interest and Other Expense

[0001628280-26-057139:mdna:47]
Total interest and other income (expense), net changed by $6.66 billion or 553% in 2026 compared to 2025. The change primarily reflects a mark-to-market gain on our retained interest in Sandisk of $6.50 billion in the current year compared to a loss of $772 million in the prior year. The change also reflects $545 million of costs incurred in connection with our debt-for-equity exchange in the current year compared to $100 million in the prior year, $254 million of costs in connection with our equity-for-equity exchanges and $108 million of costs in connection with our convertible notes transactions in the current year, as well as lower interest expense of $192 million, which reflects the reduction in our debt levels.

[0001628280-26-057139:mdna:48]
Income Tax Expense (Benefit)

[0001628280-26-057139:mdna:49]
The following table sets forth Income tax information from our Consolidated Statements of Operations by dollar and effective tax rate:

[0001628280-26-057139:mdna:50]
|  |  |  |  |  | 2026 |  | 2025 |  | 2024 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | 9,905 |  |  | $ | 1,130 |  |  | $ | (739) |  |
| Income tax expense (benefit) |  |  |  |  | 481 |  |  | (513) |  |  | 26 |  |
| Effective tax rate |  |  |  |  | 5 | % |  | (45) | % |  | (4) | % |

[0001628280-26-057139:mdna:51]
The primary drivers of the difference between the effective tax rate for 2026 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for Foreign-Derived Deduction Eligible Income (“FDDEI”) tax credits, and the gain on the retained interest in Sandisk being tax-free due to the Separation. These resulted in decreases to the Company’s effective tax rate below the U.S. Federal statutory rate. The Company’s income tax provision for 2026 includes Global Minimum Tax (“GMT”) for Malaysia as well as Thailand, a country for which the Company maintains a tax holiday.

[0001628280-26-057139:mdna:52]
The primary drivers of the difference between the effective tax rate for 2025 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for FDDEI, credits, and tax holidays in the Philippines and Thailand. These resulted in decreases to our effective tax rate below the U.S. Federal statutory rate for 2025. In anticipation of us operating as a standalone HDD business in a GMT environment, we executed an inter-entity asset transfer in conjunction with the Separation. This resulted in the recognition of one-time deferred tax benefits to continuing operations of $690 million. Our income before tax is reduced by a loss in our retained interest in Sandisk. This loss is not deductible for tax purposes and provides no income tax benefit to us.

[0001628280-26-057139:mdna:53]
37

[0001628280-26-057139:mdna:54]
For additional information regarding Income tax expense (benefit), see Part II, Item 8, Note 9, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:55]
A discussion of our results of operations for 2024, including a comparison of such results of operations to 2025, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, included in our Annual Report on Form 10-K for the year ended June 27, 2025 filed with the SEC on August 14, 2025.

[0001628280-26-057139:mdna:56]
38

[0001628280-26-057139:mdna:57]
Liquidity and Capital Resources

[0001628280-26-057139:mdna:58]
The following table summarizes our statements of cash flows, which are presented on a consolidated basis. Cash flows related to discontinued operations have not been segregated. See Part II, Item 8, Note 4, Discontinued Operations, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional cash flow information related to our discontinued operations.

[0001628280-26-057139:mdna:59]
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 3,929 |  |  | $ | 1,691 |  |  | $ | (294) |  |
| Investing activities | (429) |  |  | 150 |  |  | (27) |  |
| Financing activities | (4,032) |  |  | (1,612) |  |  | 187 |  |
| Effect of exchange rate changes on cash | (3) |  |  | 6 |  |  | (10) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (535) |  |  | $ | 235 |  |  | $ | (144) |  |

[0001628280-26-057139:mdna:60]
Operating Activities

[0001628280-26-057139:mdna:61]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. The significant improvement in cash from operating activities was driven by the improved profitability in the business during 2026. Net cash used for changes in operating assets and liabilities was $658 million for 2026, as compared to $1.03 billion of net cash used for such changes for 2025. Net cash used for changes in operating assets and liabilities in 2026 primarily consisted of a $627 million decrease in taxes payable resulting from the timing of payments, a $541 million increase in accounts receivable driven by our growth in shipments to customers, and a $218 million increase in inventories as we ramped production in response to growing demand. These uses were partially offset by a $385 million increase in accounts payable as we ramped up purchases for production as well as more favorable payment terms with suppliers, a $144 million increase in accrued compensation driven by higher performance on our variable compensation plans, and $230 million from other assets and liabilities primarily driven by recognition and payment of other taxes. Net cash used for changes in operating assets and liabilities in 2025 primarily consisted of a $409 million increase in inventories as we ramped production in response to growing demand, a $366 million decrease in accrued expenses resulting from a significant reduction in our derivative hedging activities since the Separation, and a $905 million decrease in other assets and liabilities, driven by the timing of recognition and realization of income taxes receivable. These uses were partially offset by a $307 million increase in accounts payable as we ramped up purchases for production as well as more favorable payment terms with suppliers and a $348 million increase in taxes payable resulting from the timing of payments.

[0001628280-26-057139:mdna:62]
Investing Activities

[0001628280-26-057139:mdna:63]
Net cash used in investing activities in 2026 primarily consisted of $418 million in capital expenditures. Net cash provided by investing activities in 2025 primarily consisted of $401 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $148 million in net notes receivable proceeds from Flash Ventures, partially offset by $412 million in capital expenditures.

[0001628280-26-057139:mdna:64]
Financing Activities

[0001628280-26-057139:mdna:65]
During 2026, net cash used in financing activities primarily consisted of $2.59 billion for share repurchases, $1.22 billion to settle a portion of our 2028 Convertible Notes, $1.66 billion for repayments of our other debt, $376 million for taxes paid on vested stock awards under employee stock plans, and $184 million for dividends on our common stock and Preferred Shares. These uses were partially offset by $1.95 billion of proceeds from a bridge loan and a drawdown on our Revolving Credit Facility, along with $64 million of proceeds from the issuance of stock under our employee stock plans. During 2025, net cash used in financing activities primarily consisted of $2.09 billion used for the partial repayment of our 4.75% senior unsecured notes due 2026, repayment of borrowings on the Revolving Credit Facility, and scheduled principal payments on our term loans; $1.37 billion of cash transferred to Sandisk at the Separation; $149 million in share repurchases; $113 million for taxes paid on vested stock awards; $73 million in debt issuance costs; and $44 million in dividends on our common stock and our Preferred Shares. These uses were partially offset by $2.00 billion of proceeds from drawing on the Sandisk credit facilities in connection with the Separation, $150 million from the Revolving Credit Facility, and $77 million from issuances of shares under our employee stock plans.

[0001628280-26-057139:mdna:66]
In August 2024, we filed a shelf registration statement (the “Shelf Registration Statement”) with the SEC that expires in August 2027. The Shelf Registration Statement allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0001628280-26-057139:mdna:67]
Over the next five years, we expect our capital expenditures to average between 4% to 6% of our net revenue.

[0001628280-26-057139:mdna:68]
We believe our cash and cash equivalents and our available Revolving Credit Facility will be sufficient to meet our working capital, debt, dividend and capital expenditure needs and fund our share repurchases for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt and equity capital markets to further supplement our liquidity position, if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:69]
A total of $1.08 billion and $0.98 billion of our cash and cash equivalents were held outside of the U.S. as of July 3, 2026 and June 27, 2025, respectively. There are no material tax consequences that were not previously accrued for relating to the repatriation of this cash.

[0001628280-26-057139:mdna:70]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0001628280-26-057139:mdna:71]
A discussion of our cash flows for 2024, including a comparison of such cash flows to 2025, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations – Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended June 27, 2025 filed with the SEC on August 14, 2025.

[0001628280-26-057139:mdna:72]
Off-Balance Sheet Arrangements

[0001628280-26-057139:mdna:73]
Other than certain indemnification provisions (see “Short- and Long-term Liquidity – Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any variable interest entities.

[0001628280-26-057139:mdna:74]
41

[0001628280-26-057139:mdna:75]
Short- and Long-term Liquidity

[0001628280-26-057139:mdna:76]
Material Cash Requirements

[0001628280-26-057139:mdna:77]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of July 3, 2026. In addition, see the discussions further below related to our cash dividend program, share repurchase program, liability for unrecognized tax benefits, global minimum tax, foreign exchange contracts, litigation matters and indemnifications.

[0001628280-26-057139:mdna:78]
|  | Total |  | 1 Year (2027) |  | 2-3 Years (2028-2029) |  | 4-5 Years (2030-2031) |  | More than 5 Years (Beyond 2031) |
|  | (in millions) |
| Debt, including interest | $ | 1,075 |  |  | $ | 1,075 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Operating leases | 160 |  |  | 37 |  |  | 55 |  |  | 34 |  |  | 34 |  |
| Purchase obligations and other commitments | 310 |  |  | 65 |  |  | 77 |  |  | 97 |  |  | 71 |  |
| Total | $ | 1,545 |  |  | $ | 1,177 |  |  | $ | 132 |  |  | $ | 131 |  |  | $ | 105 |  |

[0001628280-26-057139:mdna:79]
Debt

[0001628280-26-057139:mdna:80]
As described in “Key Developments – Capital Allocation Actions” above, we undertook several financing actions during 2026, to settle a substantial portion of our debt.

[0001628280-26-057139:mdna:81]
As described in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, as of July 3, 2026, $710 million in aggregate principal amount of our 2028 Convertible Notes remained outstanding. The holders of the notes have had and continue to have the right to convert the notes through the calendar quarter ending September 30, 2026 based on the sale price conditional conversion feature in their terms. As of July 3, 2026, $343 million in aggregate principal amount of these notes had been tendered for conversion and we believe the remaining $367 million principal amount will likely be tendered in the next few months. We expect the settlement of these notes will require the use of an aggregate $710 million of cash to settle the principal amount with substantially all of any premium being settled in shares under the original terms of the notes.

[0001628280-26-057139:mdna:82]
In addition, as of July 3, 2026, we had $350 million outstanding on our Revolving Credit Facility maturing in January 2027. As of July 3, 2026, we had $900 million remaining available borrowing capacity under this facility, subject to customary conditions under the loan agreement. Additional information regarding our indebtedness, including information about availability under our Revolving Credit Facility, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:83]
We believe our existing cash and cash expected to be generated from our business will be adequate to meet our debt repayment requirements.

[0001628280-26-057139:mdna:84]
We may issue additional debt securities in the future that may be guaranteed by our 100% owned domestic subsidiary, Western Digital Technologies, Inc. (“Guarantor” and, together with Western Digital Corporation, the “Obligor Group”). Such guarantees may be full and unconditional, joint and several, on a secured or unsecured, subordinated or unsubordinated basis, and may be subject to certain customary guarantor release conditions. We conduct operations almost entirely through our subsidiaries. Accordingly, the Obligor Group’s cash flow and ability to service any guaranteed registered debt securities will depend on the earnings of our subsidiaries and the distribution of those earnings to the Obligor Group, including the earnings of the non-guarantor subsidiaries, whether by dividends, loans or otherwise. Holders of such guaranteed registered debt securities would have a direct claim only against the Obligor Group.

[0001628280-26-057139:mdna:85]
The following tables include summarized financial information for the Obligor Group. The financial information for the Obligor Group is presented on combined basis, excluding intercompany balances and transactions between the Company and the Guarantor, excluding net intercompany balances between the Obligor Group and non-guarantor subsidiaries, and excluding investments in and equity in the earnings of non-guarantor subsidiaries. The Obligor Group’s amounts due from, amounts due to, and transactions with non-guarantor subsidiaries have been presented in separate line items in the tables below.

[0001628280-26-057139:mdna:86]
The assets and liabilities of the Obligor Group include the following:

[0001628280-26-057139:mdna:87]
|  | July 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Current assets | $ | 2,360 |  |  | $ | 2,992 |  |
| Non-current assets | 4,415 |  |  | 4,553 |  |
| Net intercompany payables to non-guarantor subsidiaries | 516 |  |  | 1,543 |  |
| Current liabilities | 2,204 |  |  | 3,800 |  |
| Non-current liabilities | 449 |  |  | 2,873 |  |

[0001628280-26-057139:mdna:88]
The operating results of the Obligor Group include the following:

[0001628280-26-057139:mdna:89]
|  | Year Ended |
|  | July 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Net sales | $ | 5,726 |  |  | $ | 5,249 |  |
| Gross profit | 2,543 |  |  | 1,941 |  |
| Operating income | 1,092 |  |  | 279 |  |
| Net income (loss) | 6,196 |  |  | (320) |  |

[0001628280-26-057139:mdna:90]
Results for the Obligor Group include the following transactions with non-guarantor subsidiaries:

[0001628280-26-057139:mdna:91]
|  | Year Ended |
|  | July 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Intercompany revenue | $ | 7,458 |  |  | $ | 1,378 |  |
| Net intercompany interest (income) expense | 33 |  |  | (4) |  |
| Intercompany dividend income | 94 |  |  | 2,215 |  |

[0001628280-26-057139:mdna:92]
Purchase Obligations and Other Commitments

[0001628280-26-057139:mdna:93]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. Our commitments as of July 3, 2026, are included under “Purchase obligations and other commitments” in the table above. For 2027, we expect capital expenditures to be higher than 2026 as we are making the necessary investments in our heads and media operations, as well as in automation to increase our productivity.

[0001628280-26-057139:mdna:94]
In the normal course of business, we also enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0001628280-26-057139:mdna:95]
Cash Dividend Program

[0001628280-26-057139:mdna:96]
On April 29, 2025, our Board of Directors authorized the adoption of a quarterly cash dividend program. See Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K under the caption “Dividends to Common Shareholders” for further details.

[0001628280-26-057139:mdna:97]
Share Repurchase Program

[0001628280-26-057139:mdna:98]
Our Board of Directors has authorized a Share Repurchase Program and as of July 3, 2026, we had $3.26 billion available for repurchases under the program. See Note 13, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K under the caption “Share Repurchase Program” for further details.

[0001628280-26-057139:mdna:99]
Liability for Unrecognized Tax Benefits

[0001628280-26-057139:mdna:100]
As of July 3, 2026, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $610 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties related to unrecognized tax benefits as of July 3, 2026, were approximately $130 million. Of these amounts, approximately $585 million could result in potential cash payments, of which $349 million is reasonably expected to be paid within the next twelve months. The potential cash payments are expected to be netted with offsetting favorable tax receivables totaling $213 million, including a reduction to our mandatory deemed repatriation tax obligations related to the settlement for the years 2008 through 2015, for potential net cash payments of $136 million.

[0001628280-26-057139:mdna:101]
In connection with IRS settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $166 million. Of this amount, $65 million of savings is expected from the deductible interest paid with respect to years 2008 through 2015 that were previously classified as a deferred tax asset due to interest expense limitation rules have been utilized during the year ended July 3, 2026. See Part II, Item 8, Note 9, Income Taxes of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:102]
Global Minimum Tax

[0001628280-26-057139:mdna:103]
As of July 3, 2026, we have accrued GMT liabilities of $89 million that are not expected to be paid until the second quarter of 2028.

[0001628280-26-057139:mdna:104]
Foreign Exchange Contracts

[0001628280-26-057139:mdna:105]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 7A., Quantitative and Qualitative Disclosures About Market Risk, included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:106]
Litigation Matters

[0001628280-26-057139:mdna:107]
For additional information on our litigation matters, see Part II, Item 8, Note 16, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:108]
Indemnifications

[0001628280-26-057139:mdna:109]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0001628280-26-057139:mdna:110]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0001628280-26-057139:mdna:111]
Recent Accounting Pronouncements

[0001628280-26-057139:mdna:112]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057139:mdna:113]
Critical Accounting Policies and Estimates

[0001628280-26-057139:mdna:114]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0001628280-26-057139:mdna:115]
Revenue

[0001628280-26-057139:mdna:116]
For sales to OEMs, our methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from us or other agreed-upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgment and the estimated amount of variable consideration can differ from the actual amount.

[0001628280-26-057139:mdna:117]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. We record estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. We constrain variable consideration until the likelihood of a significant revenue reversal is not probable and believe that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0001628280-26-057139:mdna:118]
Inventories

[0001628280-26-057139:mdna:119]
We periodically perform an analysis of potential excess and obsolete inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. Excess and obsolete reserves are released only when the underlying units are either sold or scrapped.

[0001628280-26-057139:mdna:120]
We value inventories at the lower of cost or net realizable value (“NRV”) with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to the lower of cost or NRV or for obsolete or excess inventory based on assumptions, which requires significant judgment. The determination of NRV involves estimating the ASPs less any selling expenses of inventory based on market conditions and customer demand. To estimate the ASPs and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0001628280-26-057139:mdna:121]
Income Taxes

[0001628280-26-057139:mdna:122]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting bases and the tax bases of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. If we conclude that it is more likely than not that a deferred tax asset will not be realized, we record a valuation allowance so that the net deferred tax asset is valued only to the amount that we conclude is more likely than not to be realized. The assessment of valuation allowances against our deferred tax assets requires estimations and significant judgment. We continue to assess and adjust our valuation allowance based on operating results and market conditions. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0001628280-26-057139:mdna:123]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the Consolidated Financial Statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the Consolidated Financial Statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0001628280-26-057139:mdna:124]
45

[0001628280-26-057139:mdna:125]
Litigation and Contingencies

[0001628280-26-057139:mdna:126]
We disclose information regarding claims and contingencies where the likelihood of a material loss is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose the matter and an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves significant judgments about the merits of the claim, applicable law, potential outcomes, estimates and inherent uncertainties. We engage relevant subject matter experts to assist us with our assessment of available information to reach conclusions on the likelihood and amount, or range, of potential loss. The actual outcome of such matters could differ materially from our estimates.

[0001628280-26-057139:mdna:127]
46
