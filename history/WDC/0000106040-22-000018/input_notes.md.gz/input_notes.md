# WDC notes — 0000106040-22-000018


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-22-000018:notes:1]
[same as prior period, unchanged from 0000106040-21-000053:notes:1]

[0000106040-22-000018:notes:2]
[same as prior period, unchanged from 0000106040-21-000053:notes:2]

[0000106040-22-000018:notes:3]
[same as prior period, unchanged from 0000106040-21-000053:notes:3]

[0000106040-22-000018:notes:4]
[same as prior period, unchanged from 0000106040-21-000053:notes:4]

[0000106040-22-000018:notes:5]
[same as prior period, unchanged from 0000106040-21-000053:notes:5]

[0000106040-22-000018:notes:6]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activity can resume.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000106040-22-000018:notes:7]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-22-000018:notes:8]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted this ASU on July 3, 2021, which is the beginning of fiscal 2022, and its adoption did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000106040-22-000018:notes:9]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-22-000018:notes:10]
In August 2020, the FASB issued ASU No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. For instruments that do not have a component mandatorily settled in cash, the change will likely result in a higher amount of share dilution in the calculation of earnings per share. The Company expects to adopt this ASU in the first quarter of fiscal 2023, and is currently assessing the impact of adoption.

[0000106040-22-000018:notes:11]
In November 2021, the FASB issued ASU No. 2021-10, “Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance” (“ASU 2021-10”). ASU 2021-10 increases the transparency of government assistance received by requiring most business entities to disclose information about government assistance received, including (1) the types of assistance, (2) the entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of fiscal 2023. Early adoption is permitted. The Company is currently assessing the impact and timing of adoption of this ASU.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000106040-22-000018:notes:12]
[same as prior period, unchanged from 0000106040-21-000053:notes:11]

[0000106040-22-000018:notes:13]
The CODM evaluates performance of the Company and makes decisions regarding allocation of resources based on each operating segment’s net revenue and gross margin, which are summarized below. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are not available or reviewed by the CODM  to evaluate the performance of or to allocate resources to the segments.

[0000106040-22-000018:notes:14]
[same as prior period, unchanged from 0000106040-21-000053:notes:13]

[0000106040-22-000018:notes:15]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,213 |  |  | $ | 1,909 |  |  | $ | 4,774 |  |  | $ | 3,753 |  |
| Flash | 2,620 |  |  | 2,034 |  |  | 5,110 |  |  | 4,112 |  |
| Total net revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 677 |  |  | $ | 488 |  |  | $ | 1,469 |  |  | $ | 971 |  |
| Flash | 946 |  |  | 551 |  |  | 1,867 |  |  | 1,099 |  |
| Total gross profit for segments | 1,623 |  |  | 1,039 |  |  | 3,336 |  |  | 2,070 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | (26) |  |  | (109) |  |  | (65) |  |  | (254) |  |
| Stock-based compensation expense | (14) |  |  | (15) |  |  | (23) |  |  | (27) |  |
| Charges related to a power outage incident and related recovery | — |  |  | 45 |  |  | — |  |  | 75 |  |
| Total unallocated corporate items | (40) |  |  | (79) |  |  | (88) |  |  | (206) |  |
| Consolidated gross profit | $ | 1,583 |  |  | $ | 960 |  |  | $ | 3,248 |  |  | $ | 1,864 |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 30.6 | % |  | 25.6 | % |  | 30.8 | % |  | 25.9 | % |
| Flash | 36.1 | % |  | 27.1 | % |  | 36.5 | % |  | 26.7 | % |
| Consolidated gross margin | 32.8 | % |  | 24.3 | % |  | 32.9 | % |  | 23.7 | % |

[0000106040-22-000018:notes:16]
[same as prior period, unchanged from 0000106040-21-000053:notes:15]

[0000106040-22-000018:notes:17]
The Company’s broad portfolio of technology and products address multiple end markets. In the fiscal first quarter of 2022, the Company refined the end markets it reports to be Cloud, Client and Consumer. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which the Company believes it is uniquely positioned to address as the only provider of both hard drive and flash products. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0000106040-22-000018:notes:18]
[same as prior period, unchanged from 0000106040-21-000053:notes:17]

[0000106040-22-000018:notes:19]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,920 |  |  | $ | 1,014 |  |  | $ | 4,145 |  |  | $ | 2,305 |  |  |  |
| Client | 1,854 |  |  | 1,869 |  |  | 3,707 |  |  | 3,619 |  |  |  |
| Consumer | 1,059 |  |  | 1,060 |  |  | 2,032 |  |  | 1,941 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,407 |  |  | $ | 945 |  |  | $ | 3,021 |  |  | $ | 2,024 |  |  |  |
| Europe, Middle East and Africa | 816 |  |  | 725 |  |  | 1,578 |  |  | 1,354 |  |  |  |
| Asia | 2,610 |  |  | 2,273 |  |  | 5,285 |  |  | 4,487 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |

[0000106040-22-000018:notes:20]
The Company’s top 10 customers accounted for 46% and 44% of its net revenue for the three and six months ended December 31, 2021, respectively, and 43% and 41% of its net revenue for the three and six months ended January 1, 2021, respectively. For the three and six months ended December 31, 2021 and January 1, 2021, no single customer accounted for 10% or more of the Company’s net revenue.

[0000106040-22-000018:notes:21]
[same as prior period, unchanged from 0000106040-21-000053:notes:20]

[0000106040-22-000018:notes:22]
In connection with the Company’s determination of its reportable segments, effective July 3, 2021, the Company allocated its goodwill between its segments based on the estimated relative fair values of the business units. In addition, management performed a goodwill impairment assessment for each segment and concluded there were no impairment indicators as of both the beginning and end of the six months ended December 31, 2021. The following table provides a summary of goodwill activity for the period:

[0000106040-22-000018:notes:23]
|  | HDD |  | Flash |  | Total |
|  | (in millions) |
| Balance at July 3, 2021 | $ | 4,328 |  |  | $ | 5,738 |  |  | $ | 10,066 |  |
| Foreign currency translation adjustment | — |  |  | (1) |  |  | (1) |  |
| Balance at December 31, 2021 | $ | 4,328 |  |  | $ | 5,737 |  |  | $ | 10,065 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-22-000018:notes:24]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 31, 2021 or July 2, 2021.

[0000106040-22-000018:notes:25]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of December 31, 2021 and July 2, 2021 as well as the related amortization for the three and six months ended December 31, 2021 and January 1, 2021 were not material.

[0000106040-22-000018:notes:26]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 31, 2021 and July 2, 2021, contract liabilities were not material.

[0000106040-22-000018:notes:27]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 31, 2021 was $51 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-22-000018:notes:28]
[same as prior period, unchanged from 0000106040-21-000053:notes:27]

[0000106040-22-000018:notes:29]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. The Company did not sell any trade accounts receivable during the six months ended December 31, 2021. During the six months ended January 1, 2021, the Company sold trade accounts receivable for cash proceeds of $173 million. The discounts on the trade accounts receivable sold were not material and were recorded within Other income, net in the Condensed Consolidated Statements of Operations. There were no factored receivables outstanding as of December 31, 2021 and July 2, 2021.

[0000106040-22-000018:notes:30]
[same as prior period, unchanged from 0000106040-21-000053:notes:29]

[0000106040-22-000018:notes:31]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,685 |  |  | $ | 1,623 |  |
| Work-in-process | 1,013 |  |  | 1,088 |  |
| Finished goods | 949 |  |  | 905 |  |
| Total inventories | $ | 3,647 |  |  | $ | 3,616 |  |

[0000106040-22-000018:notes:32]
[same as prior period, unchanged from 0000106040-21-000053:notes:31]

[0000106040-22-000018:notes:33]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 273 |  |  | $ | 278 |  |
| Buildings and improvements | 1,870 |  |  | 1,854 |  |
| Machinery and equipment | 8,287 |  |  | 7,860 |  |
| Computer equipment and software | 466 |  |  | 440 |  |
| Furniture and fixtures | 53 |  |  | 51 |  |
| Construction-in-process | 486 |  |  | 476 |  |
| Property, plant and equipment, gross | 11,435 |  |  | 10,959 |  |
| Accumulated depreciation | (8,068) |  |  | (7,771) |  |
| Property, plant and equipment, net | $ | 3,367 |  |  | $ | 3,188 |  |

[0000106040-22-000018:notes:34]
[same as prior period, unchanged from 0000106040-21-000053:notes:33]

[0000106040-22-000018:notes:35]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Finite-lived intangible assets | $ | 5,508 |  |  | $ | 5,508 |  |
| In-process research and development | 80 |  |  | 80 |  |
| Accumulated amortization | (5,288) |  |  | (5,146) |  |
| Intangible assets, net | $ | 300 |  |  | $ | 442 |  |

[0000106040-22-000018:notes:36]
[same as prior period, unchanged from 0000106040-21-000053:notes:35]

[0000106040-22-000018:notes:37]
[same as prior period, unchanged from 0000106040-21-000053:notes:36]

[0000106040-22-000018:notes:38]
[same as prior period, unchanged from 0000106040-21-000053:notes:37]

[0000106040-22-000018:notes:39]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 370 |  |  | $ | 391 |  |  | $ | 363 |  |  | $ | 408 |  |  |  |
| Charges to operations | 36 |  |  | 24 |  |  | 76 |  |  | 59 |  |  |  |
| Utilization | (28) |  |  | (24) |  |  | (51) |  |  | (55) |  |  |  |
| Changes in estimate related to pre-existing warranties | (27) |  |  | (25) |  |  | (37) |  |  | (46) |  |  |  |
| Warranty accrual, end of period | $ | 351 |  |  | $ | 366 |  |  | $ | 351 |  |  | $ | 366 |  |  |  |

[0000106040-22-000018:notes:40]
[same as prior period, unchanged from 0000106040-21-000053:notes:39]

[0000106040-22-000018:notes:41]
|  | December 31,2021 |  | July 2,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 166 |  |  | $ | 175 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 185 |  |  | 188 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 351 |  |  | $ | 363 |  |  |  |  |  |  |  |

[0000106040-22-000018:notes:42]
[same as prior period, unchanged from 0000106040-21-000053:notes:41]

[0000106040-22-000018:notes:43]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 572 |  |  | $ | 684 |  |
| Payables related to unrecognized tax benefits | 772 |  |  | 750 |  |
| Other non-current liabilities | 677 |  |  | 633 |  |
| Total other liabilities | $ | 2,021 |  |  | $ | 2,067 |  |

[0000106040-22-000018:notes:44]
[same as prior period, unchanged from 0000106040-21-000053:notes:43]

[0000106040-22-000018:notes:45]
[same as prior period, unchanged from 0000106040-21-000053:notes:44]

[0000106040-22-000018:notes:46]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at July 2, 2021 | $ | (35) |  |  | $ | (38) |  |  |  |  |  |  | $ | (124) |  |  | $ | (197) |  |
| Other comprehensive income (loss) before reclassifications | 1 |  |  | (41) |  |  |  |  |  |  | (71) |  |  | (111) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | 94 |  |  | 94 |  |
| Income tax expense related to items of other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | (3) |  |  | (3) |  |
| Net current-period other comprehensive income (loss) | 1 |  |  | (41) |  |  |  |  |  |  | 20 |  |  | (20) |  |
| Balance at December 31, 2021 | $ | (34) |  |  | $ | (79) |  |  |  |  |  |  | $ | (104) |  |  | $ | (217) |  |

[0000106040-22-000018:notes:47]
During the three and six months ended December 31, 2021, the amounts reclassified out of AOCI were losses related to foreign exchange contracts and interest rate swap contracts. Losses reclassified out of AOCI related to foreign exchange contracts were $32 million and $69 million, respectively, and were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations. Losses reclassified out of AOCI related to interest rate swap contracts were $12 million and $25 million, respectively, and were charged to Interest expense in the Condensed Consolidated Statements of Operations.
As of December 31, 2021, the amount of existing net losses related to cash flow hedges recorded in AOCI included $5 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of December 31, 2021, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-22-000018:notes:48]
[same as prior period, unchanged from 0000106040-21-000053:notes:47]

[0000106040-22-000018:notes:49]
[same as prior period, unchanged from 0000106040-21-000053:notes:48]

[0000106040-22-000018:notes:50]
[same as prior period, unchanged from 0000106040-21-000053:notes:49]

[0000106040-22-000018:notes:51]
[same as prior period, unchanged from 0000106040-21-000053:notes:50]

[0000106040-22-000018:notes:52]
[same as prior period, unchanged from 0000106040-21-000053:notes:51]

[0000106040-22-000018:notes:53]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of December 31, 2021 and July 2, 2021, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-22-000018:notes:54]
|  | December 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 71 |  |  | $ | — |  |  | $ | — |  |  | $ | 71 |  |
| Foreign exchange contracts | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Total assets at fair value | $ | 71 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 93 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 86 |  |  | $ | — |  |  | $ | 86 |  |
| Interest rate swap contracts | — |  |  | 48 |  |  | — |  |  | 48 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 134 |  |  | $ | — |  |  | $ | 134 |  |

[0000106040-22-000018:notes:55]
|  | July 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,283 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,283 |  |
| Foreign exchange contracts | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total assets at fair value | $ | 1,283 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 1,297 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Interest rate swap contracts | — |  |  | 80 |  |  | — |  |  | 80 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 145 |  |  | $ | — |  |  | $ | 145 |  |

[0000106040-22-000018:notes:56]
During the three and six months ended December 31, 2021 and January 1, 2021, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0000106040-22-000018:notes:57]
[same as prior period, unchanged from 0000106040-21-000053:notes:56]

[0000106040-22-000018:notes:58]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of fiscal 2022 and the fourth quarter of fiscal 2021, respectively.

[0000106040-22-000018:notes:59]
|  | December 31, 2021 |  | July 2, 2021 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 2,998 |  |  | $ | 3,006 |  |  | $ | 4,327 |  |  | $ | 4,346 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | — |  |  | 1,093 |  |  | 1,094 |  |
| 1.50% convertible notes due 2024 | 1,032 |  |  | 1,116 |  |  | 1,017 |  |  | 1,173 |  |
| 4.75% senior unsecured notes due 2026 | 2,289 |  |  | 2,516 |  |  | 2,288 |  |  | 2,556 |  |
| 2.85% senior unsecured notes due 2029 | 495 |  |  | 505 |  |  | — |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 494 |  |  | 504 |  |  | — |  |  | — |  |
| Total | $ | 7,308 |  |  | $ | 7,647 |  |  | $ | 8,725 |  |  | $ | 9,169 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-22-000018:notes:60]
Derivative Instruments and Hedging Activities
As of December 31, 2021, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-22-000018:notes:61]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of the three and six months ended December 31, 2021 and January 1, 2021, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Condensed Consolidated Financial Statements.

[0000106040-22-000018:notes:62]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCI. For more information regarding cash flow hedges, see Part I, Item1, Note 5. Supplemental Information - Accumulated other comprehensive income (losses), of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000018:notes:63]
[same as prior period, unchanged from 0000106040-21-000053:notes:62]

[0000106040-22-000018:notes:64]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of December 31, 2021 and July 2, 2021, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-22-000018:notes:65]
Debt
Debt consisted of the following as of December 31, 2021 and July 2, 2021:

[0000106040-22-000018:notes:66]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 3,000 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,400 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (92) |  |  | (100) |  |
| Subtotal | 7,308 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 7,057 |  |  | $ | 8,474 |  |

[0000106040-22-000018:notes:67]
In December 2021, the Company issued $500 million aggregate principal amount of  2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates. Issuance costs and discounts are amortized to interest expense over their respective terms and as of December 31, 2021, unamortized issuance costs and discounts were $5 million for the 2029 Notes and $6 million for the 2032 Notes.

[0000106040-22-000018:notes:68]
During the six months ended December 31, 2021, the Company voluntarily paid $1.09 billion to prepay the remaining principal balance of its Term Loan B-4 in accordance with its terms. In addition, during the three months ended December 31, 2021, the Company repaid $1.27 billion of the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.0 billion using proceeds from the issuance of the 2029 Notes and the 2032 Notes and using cash on hand.

[0000106040-22-000018:notes:69]
Subsequent to the end of the second quarter of fiscal 2022, on January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace our previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace our previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement will be the senior unsecured obligations of the Company and will not benefit from any collateral or subsidiary guarantees.

[0000106040-22-000018:notes:70]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from  0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 will amortize in equal quarterly installments of (i) 0.625% per quarter during the first through the fourth

[0000106040-22-000018:notes:71]
full fiscal quarters following the date of the Restatement Agreement (the “Restatement Effective Date”) and (ii) 1.25% per quarter for the fifth through the nineteenth full fiscal quarters following the Restatement Effective Date, with the remaining balance payable on the date that is five years after the Restatement Effective Date.

[0000106040-22-000018:notes:72]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company will also pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

[0000106040-22-000018:notes:73]
Prior to its restatement on January 7, 2022, the Loan Agreement required the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of December 31, 2021, the Company was in compliance with these financial covenants. Following its restatement on January 7, 2022, the covenants under the Loan Agreement were simplified and the interest coverage ratio requirement was removed.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-22-000018:notes:74]
[same as prior period, unchanged from 0000106040-21-000053:notes:68]

[0000106040-22-000018:notes:75]
[same as prior period, unchanged from 0000106040-21-000053:notes:69]

[0000106040-22-000018:notes:76]
[same as prior period, unchanged from 0000106040-21-000053:notes:70]

[0000106040-22-000018:notes:77]
|  | December 31,2021 |  | July 2,2021 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 353 |  |  | $ | 359 |  |  |  |
| Fair value of plan assets at end of period | 223 |  |  | 227 |  |  |  |
| Unfunded status | $ | 130 |  |  | $ | 132 |  |  |  |

[0000106040-22-000018:notes:78]
[same as prior period, unchanged from 0000106040-21-000053:notes:72]

[0000106040-22-000018:notes:79]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 129 |  |  | 131 |  |
| Net amount recognized | $ | 130 |  |  | $ | 132 |  |

[0000106040-22-000018:notes:80]
Net periodic benefit costs were not material for the three and six months ended December 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-22-000018:notes:81]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-22-000018:notes:82]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

[0000106040-22-000018:notes:83]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 31, 2021 and July 2, 2021:

[0000106040-22-000018:notes:84]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 92 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 161 |  |  | 213 |  |
| Notes receivable, Flash Forward | 694 |  |  | 561 |  |
| Investment in Flash Partners | 194 |  |  | 199 |  |
| Investment in Flash Alliance | 284 |  |  | 293 |  |
| Investment in Flash Forward | 128 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,553 |  |  | $ | 1,586 |  |

[0000106040-22-000018:notes:85]
During the three and six months ended December 31, 2021 and during the three and six months ended January 1, 2021, the Company made net payments to Flash Ventures of $1.11 billion and $2.30 billion, and $1.21 billion and $2.19 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-22-000018:notes:86]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-22-000018:notes:87]
As of December 31, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $389 million and $398 million, respectively.

[0000106040-22-000018:notes:88]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 31, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-22-000018:notes:89]
|  | December 31,2021 |
|  | (in millions) |
| Notes receivable | $ | 947 |  |
| Equity investments | 606 |  |
| Operating lease guarantees | 1,964 |  |
| Inventory and prepayments | 865 |  |
| Maximum estimable loss exposure | $ | 4,382 |  |

[0000106040-22-000018:notes:90]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-22-000018:notes:91]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and six months ended January 1, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from its insurance carriers, which was recorded in Cost of revenue.

[0000106040-22-000018:notes:92]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-22-000018:notes:93]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

[0000106040-22-000018:notes:94]
Off-Balance Sheet Liabilities

[0000106040-22-000018:notes:95]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-22-000018:notes:96]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021.

[0000106040-22-000018:notes:97]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 226 |  |  | $ | 1,964 |  |

[0000106040-22-000018:notes:98]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 31, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021:

[0000106040-22-000018:notes:99]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2022 |  | $ | 304 |  |  | $ | — |  |  | $ | 304 |  |
| 2023 |  | 507 |  |  | 63 |  |  | 570 |  |
| 2024 |  | 353 |  |  | 113 |  |  | 466 |  |
| 2025 |  | 161 |  |  | 103 |  |  | 264 |  |
| 2026 |  | 124 |  |  | 156 |  |  | 280 |  |
| Thereafter |  | 15 |  |  | 65 |  |  | 80 |  |
| Total guarantee obligations |  | $ | 1,464 |  |  | $ | 500 |  |  | $ | 1,964 |  |

[0000106040-22-000018:notes:100]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 31, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-22-000018:notes:101]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended January 1, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 6% of Accounts receivable, net as of December 31, 2021 and July 2, 2021, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-22-000018:notes:102]
[same as prior period, unchanged from 0000106040-21-000053:notes:96]

[0000106040-22-000018:notes:103]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of December 31, 2021:

[0000106040-22-000018:notes:104]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | ($ in millions) |  |  |  |  |  |  |  |  |
| Remaining six months of 2022 | $ | 27 |  |  |  |  |  |  |  |  |  |
| 2023 | 47 |  |  |  |  |  |  |  |  |  |
| 2024 | 46 |  |  |  |  |  |  |  |  |  |
| 2025 | 43 |  |  |  |  |  |  |  |  |  |
| 2026 | 42 |  |  |  |  |  |  |  |  |  |
| Thereafter | 188 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 393 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | 58 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 335 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 42 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities) | $ | 293 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 318 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.7 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.4 | % |  |  |  |  |  |  |  |  |

[0000106040-22-000018:notes:105]
[same as prior period, unchanged from 0000106040-21-000053:notes:99]

[0000106040-22-000018:notes:106]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
|  | (in millions) |
| Cost of operating leases | $ | 14 |  |  | $ | 12 |  |  | $ | 27 |  |  | $ | 25 |  |
| Cash paid for operating leases | 12 |  |  | 14 |  |  | 24 |  |  | 26 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 11 |  |  | 20 |  |  | 123 |  |  | 27 |  |

[0000106040-22-000018:notes:107]
[same as prior period, unchanged from 0000106040-21-000053:notes:101]

[0000106040-22-000018:notes:108]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of December 31, 2021, the Company had the following minimum long-term commitments:

[0000106040-22-000018:notes:109]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| Remaining six months of 2022 |  | $ | 343 |  |
| 2023 |  | 550 |  |
| 2024 |  | 296 |  |
| 2025 |  | 148 |  |
| 2026 |  | 20 |  |
| Thereafter |  | 170 |  |
| Total |  | $ | 1,527 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-22-000018:notes:110]
[same as prior period, unchanged from 0000106040-21-000053:notes:104]

[0000106040-22-000018:notes:111]
[same as prior period, unchanged from 0000106040-21-000053:notes:105]

[0000106040-22-000018:notes:112]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| RSUs and PSUs | $ | 78 |  |  | $ | 72 |  |  | $ | 145 |  |  | $ | 139 |  |  |  |
| ESPP | 9 |  |  | 8 |  |  | 18 |  |  | 17 |  |  |  |
| Total | $ | 87 |  |  | $ | 80 |  |  | $ | 163 |  |  | $ | 156 |  |  |  |

[0000106040-22-000018:notes:113]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Cost of revenue | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 27 |  |  |  |
| Research and development | 43 |  |  | 40 |  |  | 83 |  |  | 79 |  |  |  |
| Selling, general and administrative | 30 |  |  | 25 |  |  | 57 |  |  | 50 |  |  |  |
| Subtotal | 87 |  |  | 80 |  |  | 163 |  |  | 156 |  |  |  |
| Tax benefit | (13) |  |  | (9) |  |  | (28) |  |  | (20) |  |  |  |
| Total | $ | 74 |  |  | $ | 71 |  |  | $ | 135 |  |  | $ | 136 |  |  |  |

[0000106040-22-000018:notes:114]
[same as prior period, unchanged from 0000106040-21-000053:notes:108]

[0000106040-22-000018:notes:115]
Compensation cost related to unvested stock options, RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of December 31, 2021:

[0000106040-22-000018:notes:116]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 664 |  |  | 2.5 |
| ESPP | 81 |  |  | 1.7 |
| Total unamortized compensation cost | $ | 745 |  |  |  |

[0000106040-22-000018:notes:117]
[same as prior period, unchanged from 0000106040-21-000053:notes:111]

[0000106040-22-000018:notes:118]
[same as prior period, unchanged from 0000106040-21-000053:notes:112]

[0000106040-22-000018:notes:119]
[same as prior period, unchanged from 0000106040-21-000053:notes:113]

[0000106040-22-000018:notes:120]
The following table summarizes stock option activity under the Company’s incentive plans. All outstanding options were exercisable at December 31, 2021:

[0000106040-22-000018:notes:121]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at July 2, 2021 | 1.5 |  |  | $ | 72.84 |  |  | 1.2 |  | $ | 15 |  |
| Exercised | (0.1) |  |  | 43.57 |  |  |  |  | 2 |  |
| Canceled or expired | (0.4) |  |  | 98.85 |  |  |  |  |  |
| Options outstanding at December 31, 2021 | 1.0 |  |  | 66.15 |  |  | 1.0 |  | 9 |  |

[0000106040-22-000018:notes:122]
[same as prior period, unchanged from 0000106040-21-000053:notes:116]

[0000106040-22-000018:notes:123]
[same as prior period, unchanged from 0000106040-21-000053:notes:117]

[0000106040-22-000018:notes:124]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | $ | 50.12 |  |  |  |
| Granted | 5.1 |  |  | 63.39 |  |  |  |
| Vested | (4.6) |  |  | 53.93 |  |  | $ | 285 |  |
| Forfeited | (1.2) |  |  | 51.71 |  |  |  |
| RSUs and PSUs outstanding at December 31, 2021 | 15.4 |  |  | 53.32 |  |  |  |

[0000106040-22-000018:notes:125]
[same as prior period, unchanged from 0000106040-21-000053:notes:119]

[0000106040-22-000018:notes:126]
Stock Repurchase Program
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of the Company’s common stock, which authorization is effective through July 25, 2023. The Company did not make any stock repurchases during the six months ended December 31, 2021 and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of December 31, 2021 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects stock repurchases to be funded principally by operating cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-22-000018:notes:127]
[same as prior period, unchanged from 0000106040-21-000053:notes:121]

[0000106040-22-000018:notes:128]
[same as prior period, unchanged from 0000106040-21-000053:notes:122]

[0000106040-22-000018:notes:129]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
|  | ($ in millions) |
| Income before taxes | $ | 646 |  |  | $ | 85 |  |  | $ | 1,350 |  |  | $ | 82 |  |
| Income tax expense | 82 |  |  | 23 |  |  | 176 |  |  | 80 |  |
| Effective tax rate | 13 | % |  | 27 | % |  | 13 | % |  | 98 | % |

[0000106040-22-000018:notes:130]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 31, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for the three and six months ended December 31, 2021 includes the discrete effect of an increase to unrecognized tax benefits as a result of ongoing discussions with various taxing authorities of $8 million and $25 million, respectively.

[0000106040-22-000018:notes:131]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the six months ended January 1, 2021 includes the discrete effects of net tax deficiencies from shortfalls of $12 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of certain deferred tax liabilities due to restructuring activities. The discrete items had no impact on the amount of income taxes paid by the Company.

[0000106040-22-000018:notes:132]
As previously disclosed, the IRS issued statutory notices of deficiency with respect to adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2008 through 2012. The Company filed petitions with the U.S. Tax Court with respect to these notices. Through January 2022, the IRS has filed various Amendments to Answer with the U.S. Tax Court which (i) assert adjustments relating to transfer pricing with the Company’s foreign subsidiaries for fiscal years 2008 through 2012 that would result in additional federal income tax liabilities totaling approximately $1.26 billion for fiscal years 2008 through 2012, and (ii) assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2012. In addition, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2013 through 2015 that, if sustained, would result in additional federal income tax liabilities totaling approximately $343 million for those fiscal years. In March 2021, the IRS asserted penalties totaling $109 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2013 through 2015. The Company disagrees with the proposed adjustments relating to transfer pricing and related penalties, and continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS. Also in March 2021, the Company and the IRS tentatively reached a basis for resolving the intercompany payable balances matter for all fiscal years at issue and the impact was not material to the Consolidated Financial Statements.

[0000106040-22-000018:notes:133]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of December 31, 2021, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.

[0000106040-22-000018:notes:134]
As of December 31, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $772 million. Accrued interest and penalties related to unrecognized tax benefits as of December 31, 2021 was approximately $135 million. Of these amounts, approximately $772 million could result in potential cash payments. The Company is not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.


## us-gaap:EarningsPerShareTextBlock

[0000106040-22-000018:notes:135]
Net Income Per Common Share The following table presents the computation of basic and diluted income per common share:

[0000106040-22-000018:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
|  | (in millions, except per share data) |
| Net income | $ | 564 |  |  |  | $ | 62 |  |  | $ | 1,174 |  |  | $ | 2 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic | 312 |  |  |  | 305 |  |  | 311 |  |  | 304 |  |
| Employee stock options, RSUs, PSUs and ESPP | 3 |  |  |  | 2 |  |  | 4 |  |  | 1 |  |
| Basic and diluted | 315 |  |  |  | 307 |  |  | 315 |  |  | 305 |  |
| Income per common share: |  |  |  |  |  |  |  |  |
| Basic | $ | 1.81 |  |  |  | $ | 0.20 |  |  | $ | 3.77 |  |  | $ | 0.01 |  |
| Diluted | $ | 1.79 |  |  |  | $ | 0.20 |  |  | $ | 3.73 |  |  | $ | 0.01 |  |
| Anti-dilutive potential common shares excluded | 5 |  |  |  | 8 |  |  | 3 |  |  | 10 |  |

[0000106040-22-000018:notes:137]
The Company computes basic income per common share using Net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using Net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-22-000018:notes:138]
Employee Termination, Asset Impairment, and Other Charges
Business Realignment

[0000106040-22-000018:notes:139]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company recorded the following charges related to these actions:

[0000106040-22-000018:notes:140]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Employee termination benefits | $ | 3 |  |  | $ | 2 |  |  | $ | 18 |  |  | $ | 25 |  |  |  |
| Asset impairments and losses (gains) on disposal of assets | (1) |  |  | — |  |  | 2 |  |  | — |  |  |  |
| Total employee termination, asset impairment, and other charges | $ | 2 |  |  | $ | 2 |  |  | $ | 20 |  |  | $ | 25 |  |  |  |

[0000106040-22-000018:notes:141]
The following table presents an analysis of the components of these activities against the reserve during the six months ended December 31, 2021:

[0000106040-22-000018:notes:142]
|  | Employee Termination Benefits |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance at July 2, 2021 | $ | 2 |  |  |  |  |  |
| Charges | 18 |  |  |  |  |  |
| Cash payments | (12) |  |  |  |  |  |
| Accrual balance at December 31, 2021 | $ | 8 |  |  |  |  |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-22-000018:notes:143]
Legal Proceedings
Tax

[0000106040-22-000018:notes:144]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and a tentative resolution with respect to certain matters, see Note 13, Income Tax Expense.

[0000106040-22-000018:notes:145]
Other Matters

[0000106040-22-000018:notes:146]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
