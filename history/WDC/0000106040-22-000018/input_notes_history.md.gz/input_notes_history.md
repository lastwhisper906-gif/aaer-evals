# WDC note change history — 0000106040-21-000053 → 0000106040-22-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 31, 2021 and July 2, 2021:
  (was, 2021-11-04, similarity 0.973):
[0000106040-21-000053:note_history:1]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 1, 2021 and July 2, 2021:

- changed (2022-02-03):
[0000106040-22-000018:note_history:2]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 92 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 161 |  |  | 213 |  |
| Notes receivable, Flash Forward | 694 |  |  | 561 |  |
| Investment in Flash Partners | 194 |  |  | 199 |  |
| Investment in Flash Alliance | 284 |  |  | 293 |  |
| Investment in Flash Forward | 128 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,553 |  |  | $ | 1,586 |  |
  (was, 2021-11-04, similarity 0.9895):
[0000106040-21-000053:note_history:2]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 194 |  |  | 213 |  |
| Notes receivable, Flash Forward | 681 |  |  | 561 |  |
| Investment in Flash Partners | 201 |  |  | 199 |  |
| Investment in Flash Alliance | 294 |  |  | 293 |  |
| Investment in Flash Forward | 131 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,646 |  |  | $ | 1,586 |  |

- added (2022-02-03):
[0000106040-22-000018:note_history:3]
During the three and six months ended December 31, 2021 and during the three and six months ended January 1, 2021, the Company made net payments to Flash Ventures of $1.11 billion and $2.30 billion, and $1.21 billion and $2.19 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2022-02-03):
[0000106040-22-000018:note_history:4]
As of December 31, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $389 million and $398 million, respectively.
  (was, 2021-11-04, similarity 0.9747):
[0000106040-21-000053:note_history:4]
As of October 1, 2021 and July 2, 2021, the Company had Accounts payable balances due to Flash Ventures of $378 million and $398 million, respectively.

- changed (2022-02-03):
[0000106040-22-000018:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 31, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2021-11-04, similarity 0.9897):
[0000106040-21-000053:note_history:5]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 1, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2022-02-03):
[0000106040-22-000018:note_history:6]
|  | December 31,2021 |
|  | (in millions) |
| Notes receivable | $ | 947 |  |
| Equity investments | 606 |  |
| Operating lease guarantees | 1,964 |  |
| Inventory and prepayments | 865 |  |
| Maximum estimable loss exposure | $ | 4,382 |  |

- changed (2022-02-03):
[0000106040-22-000018:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three and six months ended January 1, 2021, the Company recovered $45 million and $75 million, respectively, related to this incident from its insurance carriers, which was recorded in Cost of revenue.
  (was, 2021-11-04, similarity 0.755):
[0000106040-21-000053:note_history:7]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in damage to flash wafers in production and a reduction in the Company’s flash wafer availability. During the three months ended October 2, 2020, the Company recovered $30 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

- changed (2022-02-03):
[0000106040-22-000018:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021.
  (was, 2021-11-04, similarity 0.9825):
[0000106040-21-000053:note_history:8]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021.

- changed (2022-02-03):
[0000106040-22-000018:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 31, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 31, 2021:
  (was, 2021-11-04, similarity 0.9751):
[0000106040-21-000053:note_history:9]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of October 1, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 1, 2021:

- changed (2022-02-03):
[0000106040-22-000018:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2022 |  | $ | 304 |  |  | $ | — |  |  | $ | 304 |  |
| 2023 |  | 507 |  |  | 63 |  |  | 570 |  |
| 2024 |  | 353 |  |  | 113 |  |  | 466 |  |
| 2025 |  | 161 |  |  | 103 |  |  | 264 |  |
| 2026 |  | 124 |  |  | 156 |  |  | 280 |  |
| Thereafter |  | 15 |  |  | 65 |  |  | 80 |  |
| Total guarantee obligations |  | $ | 1,464 |  |  | $ | 500 |  |  | $ | 1,964 |  |
  (was, 2021-11-04, similarity 0.9901):
[0000106040-21-000053:note_history:10]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining nine months of 2022 |  | $ | 443 |  |  | $ | 22 |  |  | $ | 465 |  |
| 2023 |  | 481 |  |  | 65 |  |  | 546 |  |
| 2024 |  | 325 |  |  | 117 |  |  | 442 |  |
| 2025 |  | 138 |  |  | 107 |  |  | 245 |  |
| 2026 |  | 91 |  |  | 162 |  |  | 253 |  |
| Thereafter |  | 4 |  |  | 30 |  |  | 34 |  |
| Total guarantee obligations |  | $ | 1,482 |  |  | $ | 503 |  |  | $ | 1,985 |  |

- changed (2022-02-03):
[0000106040-22-000018:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 31, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2021-11-04, similarity 0.9912):
[0000106040-21-000053:note_history:11]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of October 1, 2021, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- added (2022-02-03):
[0000106040-22-000018:note_history:12]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 31, 2021, the Company recognized approximately 4% of its consolidated revenue on products distributed by the Unis Venture. For both the three and six months ended January 1, 2021, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 7% and 6% of Accounts receivable, net as of December 31, 2021 and July 2, 2021, respectively.

- removed (2022-02-03):
[0000106040-21-000053:note_history:13]
During the three months ended October 1, 2021 and October 2, 2020, the Company made net payments to Flash Ventures of $1.19 billion and $981 million, respectively, for purchased flash-based memory wafers and net loans.

- removed (2022-02-03):
[0000106040-21-000053:note_history:14]
|  | October 1,2021 |
|  | (in millions) |
| Notes receivable | $ | 1,020 |  |
| Equity investments | 626 |  |
| Operating lease guarantees | 1,985 |  |
| Inventory and prepayments | 790 |  |
| Maximum estimable loss exposure | $ | 4,421 |  |

- removed (2022-02-03):
[0000106040-21-000053:note_history:15]
Unis Venture
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the three months ended October 1, 2021 and October 2, 2020, the Company recognized approximately 5% and 2%, respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from and investment in the Unis Venture were 7% and 6% of Accounts receivable, net as of October 1, 2021 and July 2, 2021, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:16]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the COVID-19 pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, additional surges of COVID-19, including the emergence of more contagious or vaccine-resistant variants, and how quickly and to what extent normal economic and operating activity can resume.
  (was, 2021-11-04, similarity 0.686):
[0000106040-21-000053:note_history:16]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, any possible resurgence of COVID-19, including the emergence of more contagious or vaccine-resistant variants and how quickly and to what extent normal economic and operating activity can resume.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:17]
Debt
Debt consisted of the following as of December 31, 2021 and July 2, 2021:
  (was, 2021-11-04, similarity 0.9489):
[0000106040-21-000053:note_history:17]
Debt
Debt consisted of the following as of October 1, 2021 and July 2, 2021:

- changed (2022-02-03):
[0000106040-22-000018:note_history:18]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 3,000 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,400 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (92) |  |  | (100) |  |
| Subtotal | 7,308 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 7,057 |  |  | $ | 8,474 |  |
  (was, 2021-11-04, similarity 0.8983):
[0000106040-21-000053:note_history:18]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,269 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,612 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (91) |  |  | (100) |  |
| Subtotal | 8,521 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 8,270 |  |  | $ | 8,474 |  |

- added (2022-02-03):
[0000106040-22-000018:note_history:19]
In December 2021, the Company issued $500 million aggregate principal amount of  2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”) pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “First Supplemental Indenture”) between the Company and the Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the First Supplemental Indenture. The Indenture contains certain restrictive covenants which are subject to a number of limitations and exceptions. Interest for both the 2029 Notes and 2032 Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Notes or 2032 Notes prior to their maturity dates. Issuance costs and discounts are amortized to interest expense over their respective terms and as of December 31, 2021, unamortized issuance costs and discounts were $5 million for the 2029 Notes and $6 million for the 2032 Notes.

- added (2022-02-03):
[0000106040-22-000018:note_history:20]
During the six months ended December 31, 2021, the Company voluntarily paid $1.09 billion to prepay the remaining principal balance of its Term Loan B-4 in accordance with its terms. In addition, during the three months ended December 31, 2021, the Company repaid $1.27 billion of the outstanding principal balance on its Term Loan A-1 in accordance with its terms to reduce the remaining outstanding principal balance to $3.0 billion using proceeds from the issuance of the 2029 Notes and the 2032 Notes and using cash on hand.

- added (2022-02-03):
[0000106040-22-000018:note_history:21]
Subsequent to the end of the second quarter of fiscal 2022, on January 7, 2022, the Company entered into a restatement agreement (“Restatement Agreement”) to amend and restate the Loan Agreement, originally dated as of April 29, 2016 (including subsequent amendments and the Restatement Agreement, collectively, the “Loan Agreement”), to provide for, among other things, (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) to replace our previously existing Term Loan A-1; and (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Facility”) to replace our previously existing $2.25 billion revolving credit facility and (iii) additional covenant flexibility and other modifications. The obligations under the Loan Agreement will be the senior unsecured obligations of the Company and will not benefit from any collateral or subsidiary guarantees.

- added (2022-02-03):
[0000106040-22-000018:note_history:22]
The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term Secured Overnight Financing Rate (“SOFR”) (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from  0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of Standard & Poor’s Ratings Services (“S&P”), Moody’s Investors Service, Inc. (“Moody’s”) and Fitch Ratings, Inc. (“Fitch”), with an initial interest rate of Adjusted Term SOFR plus 1.375%. The Term Loan A-2 will amortize in equal quarterly installments of (i) 0.625% per quarter during the first through the fourth

- added (2022-02-03):
[0000106040-22-000018:note_history:23]
full fiscal quarters following the date of the Restatement Agreement (the “Restatement Effective Date”) and (ii) 1.25% per quarter for the fifth through the nineteenth full fiscal quarters following the Restatement Effective Date, with the remaining balance payable on the date that is five years after the Restatement Effective Date.

- added (2022-02-03):
[0000106040-22-000018:note_history:24]
Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial rate of Adjusted Term SOFR plus 1.375%. The Company will also pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of S&P, Moody’s and Fitch, with an initial unused commitment fee of 0.200%.

- added (2022-02-03):
[0000106040-22-000018:note_history:25]
Prior to its restatement on January 7, 2022, the Loan Agreement required the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of December 31, 2021, the Company was in compliance with these financial covenants. Following its restatement on January 7, 2022, the covenants under the Loan Agreement were simplified and the interest coverage ratio requirement was removed.

- removed (2022-02-03):
[0000106040-21-000053:note_history:26]
The credit agreement governing the revolving credit facility and Term Loan A-1 requires the Company to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of October 1, 2021, the Company was in compliance with these financial covenants.

- removed (2022-02-03):
[0000106040-21-000053:note_history:27]
During the three months ended October 1, 2021, the Company made a voluntary prepayment of $150 million on its Term Loan B-4. On October 22, 2021, the Company voluntarily prepaid the remaining principal balance of $943 million on its Term Loan B-4.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:28]
Debt consisted of the following as of December 31, 2021 and July 2, 2021:
  (was, 2021-11-04, similarity 0.9449):
[0000106040-21-000053:note_history:28]
Debt consisted of the following as of October 1, 2021 and July 2, 2021:

- changed (2022-02-03):
[0000106040-22-000018:note_history:29]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 3,000 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | — |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| 2.85% senior unsecured notes due 2029 | 500 |  |  | — |  |
| 3.10% senior unsecured notes due 2032 | 500 |  |  | — |  |
| Total debt | 7,400 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (92) |  |  | (100) |  |
| Subtotal | 7,308 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 7,057 |  |  | $ | 8,474 |  |
  (was, 2021-11-04, similarity 0.8983):
[0000106040-21-000053:note_history:29]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Variable interest rate Term Loan A-1 maturing 2023 | $ | 4,269 |  |  | $ | 4,332 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 943 |  |  | 1,093 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,612 |  |  | 8,825 |  |
| Issuance costs and debt discounts | (91) |  |  | (100) |  |
| Subtotal | 8,521 |  |  | 8,725 |  |
| Less current portion of long-term debt | (251) |  |  | (251) |  |
| Long-term debt | $ | 8,270 |  |  | $ | 8,474 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:30]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of December 31, 2021 and July 2, 2021:
  (was, 2021-11-04, similarity 0.973):
[0000106040-21-000053:note_history:30]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of October 1, 2021 and July 2, 2021:

- changed (2022-02-03):
[0000106040-22-000018:note_history:31]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 92 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 161 |  |  | 213 |  |
| Notes receivable, Flash Forward | 694 |  |  | 561 |  |
| Investment in Flash Partners | 194 |  |  | 199 |  |
| Investment in Flash Alliance | 284 |  |  | 293 |  |
| Investment in Flash Forward | 128 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,553 |  |  | $ | 1,586 |  |
  (was, 2021-11-04, similarity 0.9895):
[0000106040-21-000053:note_history:31]
|  | October 1,2021 |  | July 2,2021 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 145 |  |  | $ | 191 |  |
| Notes receivable, Flash Alliance | 194 |  |  | 213 |  |
| Notes receivable, Flash Forward | 681 |  |  | 561 |  |
| Investment in Flash Partners | 201 |  |  | 199 |  |
| Investment in Flash Alliance | 294 |  |  | 293 |  |
| Investment in Flash Forward | 131 |  |  | 129 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,646 |  |  | $ | 1,586 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,920 |  |  | $ | 1,014 |  |  | $ | 4,145 |  |  | $ | 2,305 |  |  |  |
| Client | 1,854 |  |  | 1,869 |  |  | 3,707 |  |  | 3,619 |  |  |  |
| Consumer | 1,059 |  |  | 1,060 |  |  | 2,032 |  |  | 1,941 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,407 |  |  | $ | 945 |  |  | $ | 3,021 |  |  | $ | 2,024 |  |  |  |
| Europe, Middle East and Africa | 816 |  |  | 725 |  |  | 1,578 |  |  | 1,354 |  |  |  |
| Asia | 2,610 |  |  | 2,273 |  |  | 5,285 |  |  | 4,487 |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |
  (was, 2021-11-04, similarity 0.7768):
[0000106040-21-000053:note_history:32]
|  | Three Months Ended |  |  |
|  | October 1,2021 |  | October 2,2020 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 2,225 |  |  | $ | 1,291 |  |  |  |  |  |  |  |
| Client | 1,853 |  |  | 1,750 |  |  |  |  |  |  |  |
| Consumer | 973 |  |  | 881 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,614 |  |  | $ | 1,079 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 762 |  |  | 629 |  |  |  |  |  |  |  |
| Asia | 2,675 |  |  | 2,214 |  |  |  |  |  |  |  |
| Total Revenue | $ | 5,051 |  |  | $ | 3,922 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-03):
[0000106040-22-000018:note_history:33]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either December 31, 2021 or July 2, 2021.
  (was, 2021-11-04, similarity 0.9843):
[0000106040-21-000053:note_history:33]
Revenues 
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either October 1, 2021 or July 2, 2021.

- changed (2022-02-03):
[0000106040-22-000018:note_history:34]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of December 31, 2021 and July 2, 2021 as well as the related amortization for the three and six months ended December 31, 2021 and January 1, 2021 were not material.
  (was, 2021-11-04, similarity 0.9607):
[0000106040-21-000053:note_history:34]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs as of October 1, 2021 and July 2, 2021 as well as the related amortization for the three months ended October 1, 2021 and October 2, 2020 were not material.

- changed (2022-02-03):
[0000106040-22-000018:note_history:35]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of December 31, 2021 and July 2, 2021, contract liabilities were not material.
  (was, 2021-11-04, similarity 0.9831):
[0000106040-21-000053:note_history:35]
Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. As of October 1, 2021 and July 2, 2021, contract liabilities were not material.

- changed (2022-02-03):
[0000106040-22-000018:note_history:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for intellectual property (“IP”) license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of December 31, 2021 was $51 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $20 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.
  (was, 2021-11-04, similarity 0.6814):
[0000106040-21-000053:note_history:36]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts, which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of October 1, 2021 was $61 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $30 million during the remainder of fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.
