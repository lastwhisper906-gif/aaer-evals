# WDC MD&A — 0000106040-22-000018


## mdna

[0000106040-22-000018:mdna:1]
[same as prior period, unchanged from 0000106040-21-000053:mdna:1]

[0000106040-22-000018:mdna:2]
[same as prior period, unchanged from 0000106040-21-000053:mdna:2]

[0000106040-22-000018:mdna:3]
[same as prior period, unchanged from 0000106040-21-000053:mdna:3]

[0000106040-22-000018:mdna:4]
[same as prior period, unchanged from 0000106040-21-000053:mdna:4]

[0000106040-22-000018:mdna:5]
[same as prior period, unchanged from 0000106040-21-000053:mdna:5]

[0000106040-22-000018:mdna:6]
[same as prior period, unchanged from 0000106040-21-000053:mdna:6]

[0000106040-22-000018:mdna:7]
[same as prior period, unchanged from 0000106040-21-000053:mdna:72]

[0000106040-22-000018:mdna:8]
In the second quarter of fiscal 2022, we continued to execute on our commitment to reduce our overall debt levels and fully repaid our Term Loan B-4. In December 2021, Fitch Ratings, Inc.  raised our Company credit rating to investment grade.  We then initiated a series of transactions to further reduce our debt levels and better stagger the maturities of our debt. In December 2021, we issued $500 million aggregate principal amount of 2.850% senior unsecured notes due February 1, 2029 (the “2029 Notes”) and issued $500 million aggregate principal amount of 3.100% senior unsecured notes due February 1, 2032 (the “2032 Notes”). We used the proceeds from these notes offerings and available cash to voluntarily repay $1.21 billion of our Term Loan A-1 and reduce its principal amount to $3.0 billion as of December 31, 2021. In January 2022, we amended and restated our existing loan agreement to provide for, among other things: (i) the issuance of a new $3.0 billion Term Loan A-2 maturing in January 2027 to replace our previously existing Term Loan A-1; (ii) the availability of a new $2.25 billion revolving credit facility maturing in January 2027 to replace our previously existing $2.25 billion revolving credit facility; and (iii) additional covenant flexibility and other modifications. Upon completion of these transactions, over 85% of the principal amount of our debt is now due in 2026 or later. We believe this new debt structure gives us greater financial stability and flexibility to manage our business over the longer term.

[0000106040-22-000018:mdna:9]
Additional information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-22-000018:mdna:10]
[same as prior period, unchanged from 0000106040-21-000053:mdna:7]

[0000106040-22-000018:mdna:11]
Historically, our company had been managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is our Chief Operating Decision Maker, announced a decision to reorganize our business by forming two separate product business units: hard disk drives (“HDD”) and flash-based products (“Flash”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. To align with the new operating model and business structure, we made management organizational changes and implemented new reporting modules and processes to provide discrete information to manage the business. Effective July 3, 2021, management finalized its assessment of our operating segments and concluded that we now have two reportable segments: HDD and Flash.

[0000106040-22-000018:mdna:12]
Our broad portfolio of technology and products address multiple end markets. In the fiscal first quarter of 2022, we refined the end markets we report to be “Cloud”, “Client” and “Consumer”. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and end customers, which we believe we are uniquely positioned to address as the only provider of both hard drive and flash products. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash and hard drive solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-22-000018:mdna:13]
[same as prior period, unchanged from 0000106040-21-000053:mdna:10]

[0000106040-22-000018:mdna:14]
[same as prior period, unchanged from 0000106040-21-000053:mdna:11]

[0000106040-22-000018:mdna:15]
As the ongoing COVID-19 pandemic has evolved, we have implemented and maintained more thorough sanitation practices as outlined by health organizations and supported vaccination efforts. As we begin to phase in a return to site for more employees, we are monitoring and adopting practices recommended by health organizations to ensure the continued safety of our employees and business partners. In addition, the responses to COVID-19 taken by others in the supply chain have increased the costs of their services which have in turn impacted our operations. We incurred incremental charges primarily related to logistics, absorption and other factory-related costs of approximately $70 million and $126 million, and $33 million and $61 million during the three and six months ended December 31, 2021 and January 1, 2021, respectively, which were recorded in Cost of revenue.

[0000106040-22-000018:mdna:16]
The technology hardware and semiconductor industries continued to face supply chain disruptions during the quarter that negatively impacted both our customers’ ability to ship products, and our ability to build products. In order to meet our end customers’ demand, we are incurring increased component costs in addition to COVID-related expenses, which we expect to weigh primarily on our hard drive gross margins through the first half of calendar year 2022. While these supply disruptions may continue for the near term, we ultimately expect that they will be transitory as demand for our products has remained solid during the COVID-19 pandemic, with work-from-home, distance learning, and at home entertainment driving demand for cloud environments, new devices, and retail products.

[0000106040-22-000018:mdna:17]
[same as prior period, unchanged from 0000106040-21-000053:mdna:15]

[0000106040-22-000018:mdna:18]
[same as prior period, unchanged from 0000106040-21-000053:mdna:16]

[0000106040-22-000018:mdna:19]
In October 2020, Kioxia announced the start of construction of the shell for a new fabrication facility in Yokkaichi, Japan, referred to as “Y7”. We expect to continue Flash Ventures investments into Y7 in due course.

[0000106040-22-000018:mdna:20]
[same as prior period, unchanged from 0000106040-21-000053:mdna:18]

[0000106040-22-000018:mdna:21]
Second Quarter and First Half Overview

[0000106040-22-000018:mdna:22]
[same as prior period, unchanged from 0000106040-21-000053:mdna:20]

[0000106040-22-000018:mdna:23]
|  | Three Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 4,833 |  |  | 100.0 | % |  | $ | 3,943 |  |  | 100.0 | % |  | $ | 890 |  |  | 23 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 3,250 |  |  | 67.2 |  |  | 2,983 |  |  | 75.7 |  |  | 267 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,583 |  |  | 32.8 |  |  | 960 |  |  | 24.3 |  |  | 623 |  |  | 65 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 575 |  |  | 11.9 |  |  | 535 |  |  | 13.6 |  |  | 40 |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 279 |  |  | 5.8 |  |  | 265 |  |  | 6.7 |  |  | 14 |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 2 |  |  | — |  |  | 2 |  |  | 0.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 856 |  |  | 17.7 |  |  | 802 |  |  | 20.3 |  |  | 54 |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 727 |  |  | 15.0 |  |  | 158 |  |  | 4.0 |  |  | 569 |  |  | 360 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 1 |  |  | — |  |  | 2 |  |  | 0.1 |  |  | (1) |  |  | (50) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (76) |  |  | (1.6) |  |  | (81) |  |  | (2.1) |  |  | 5 |  |  | (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (loss), net | (6) |  |  | (0.1) |  |  | 6 |  |  | 0.2 |  |  | (12) |  |  | (200) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (81) |  |  | (1.7) |  |  | (73) |  |  | (1.9) |  |  | (8) |  |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 646 |  |  | 13.4 |  |  | 85 |  |  | 2.2 |  |  | 561 |  |  | 660 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 82 |  |  | 1.7 |  |  | 23 |  |  | 0.6 |  |  | 59 |  |  | 257 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 564 |  |  | 11.7 |  |  | $ | 62 |  |  | 1.6 |  |  | 502 |  |  | 810 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-22-000018:mdna:24]
[same as prior period, unchanged from 0000106040-21-000053:mdna:22]

[0000106040-22-000018:mdna:25]
[same as prior period, unchanged from 0000106040-21-000053:mdna:35]

[0000106040-22-000018:mdna:26]
|  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 9,884 |  |  | 100.0 | % |  | $ | 7,865 |  |  | 100.0 | % |  | $ | 2,019 |  |  | 26 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 6,636 |  |  | 67.1 |  |  | 6,001 |  |  | 76.3 |  |  | 635 |  |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 3,248 |  |  | 32.9 |  |  | 1,864 |  |  | 23.7 |  |  | 1,384 |  |  | 74 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,153 |  |  | 11.7 |  |  | 1,090 |  |  | 13.9 |  |  | 63 |  |  | 6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 570 |  |  | 5.8 |  |  | 521 |  |  | 6.6 |  |  | 49 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee termination, asset impairment, and other charges | 20 |  |  | 0.2 |  |  | 25 |  |  | 0.3 |  |  | (5) |  |  | (20) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 1,743 |  |  | 17.6 |  |  | 1,636 |  |  | 20.8 |  |  | 107 |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 1,505 |  |  | 15.2 |  |  | 228 |  |  | 2.9 |  |  | 1,277 |  |  | 560 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 3 |  |  | — |  |  | 4 |  |  | 0.1 |  |  | (1) |  |  | (25) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (154) |  |  | (1.6) |  |  | (165) |  |  | (2.1) |  |  | 11 |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (4) |  |  | — |  |  | 15 |  |  | 0.2 |  |  | (19) |  |  | (127) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other expense, net | (155) |  |  | (1.6) |  |  | (146) |  |  | (1.9) |  |  | (9) |  |  | 6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 1,350 |  |  | 13.7 |  |  | 82 |  |  | 1.0 |  |  | 1,268 |  |  | 1,546 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 176 |  |  | 1.8 |  |  | 80 |  |  | 1.0 |  |  | 96 |  |  | 120 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 1,174 |  |  | 11.9 |  |  | $ | 2 |  |  | — |  |  | 1,172 |  |  | 58,600 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000106040-22-000018:mdna:27]
(1)    Percentages may not total due to rounding.

[0000106040-22-000018:mdna:28]
40

[0000106040-22-000018:mdna:29]
[same as prior period, unchanged from 0000106040-21-000053:mdna:24]

[0000106040-22-000018:mdna:30]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
|  | ($ in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| HDD | $ | 2,213 |  |  | $ | 1,909 |  |  | $ | 4,774 |  |  | $ | 3,753 |  |
| Flash | 2,620 |  |  | 2,034 |  |  | 5,110 |  |  | 4,112 |  |
| Total net revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |
| Gross profit: |  |  |  |  |  |  |  |
| HDD | $ | 677 |  |  | $ | 488 |  |  | $ | 1,469 |  |  | $ | 971 |  |
| Flash | 946 |  |  | 551 |  |  | 1,867 |  |  | 1,099 |  |
| Total gross profit for segments | 1,623 |  |  | 1,039 |  |  | 3,336 |  |  | 2,070 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | (26) |  |  | (109) |  |  | (65) |  |  | (254) |  |
| Stock-based compensation expense | (14) |  |  | (15) |  |  | (23) |  |  | (27) |  |
| Charges related to cost savings initiatives | — |  |  | — |  |  | — |  |  | — |  |
| Recovery related to a power outage incident | — |  |  | 45 |  |  | — |  |  | 75 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Total unallocated corporate items | (40) |  |  | (79) |  |  | (88) |  |  | (206) |  |
| Consolidated gross profit | $ | 1,583 |  |  | $ | 960 |  |  | $ | 3,248 |  |  | $ | 1,864 |  |
| Gross margin: |  |  |  |  |  |  |  |
| HDD | 30.6 | % |  | 25.6 | % |  | 30.8 | % |  | 25.9 | % |
| Flash | 36.1 | % |  | 27.1 | % |  | 36.5 | % |  | 26.7 | % |
| Consolidated gross margin | 32.8 | % |  | 24.3 | % |  | 32.9 | % |  | 23.7 | % |

[0000106040-22-000018:mdna:31]
[same as prior period, unchanged from 0000106040-21-000053:mdna:26]

[0000106040-22-000018:mdna:32]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |  |  |  |  |  |  |
|  | (in millions) |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud | $ | 1,920 |  |  | $ | 1,014 |  |  | $ | 4,145 |  |  | $ | 2,305 |  |  |  |  |  |  |  |
| Client | 1,854 |  |  | 1,869 |  |  | 3,707 |  |  | 3,619 |  |  |  |  |  |  |  |
| Consumer | 1,059 |  |  | 1,060 |  |  | 2,032 |  |  | 1,941 |  |  |  |  |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |  |  |  |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,407 |  |  | $ | 945 |  |  | $ | 3,021 |  |  | $ | 2,024 |  |  |  |  |  |  |  |
| Europe, Middle East and Africa | 816 |  |  | 725 |  |  | 1,578 |  |  | 1,354 |  |  |  |  |  |  |  |
| Asia | 2,610 |  |  | 2,273 |  |  | 5,285 |  |  | 4,487 |  |  |  |  |  |  |  |
| Total Revenue | $ | 4,833 |  |  | $ | 3,943 |  |  | $ | 9,884 |  |  | $ | 7,865 |  |  |  |  |  |  |  |

[0000106040-22-000018:mdna:33]
41

[0000106040-22-000018:mdna:34]
[same as prior period, unchanged from 0000106040-21-000053:mdna:29]

[0000106040-22-000018:mdna:35]
The increases in consolidated net revenue for the three and six months ended December 31, 2021 from the comparable periods in the prior year reflect increases in exabytes of HDD and Flash sold as further discussed below. The revenue increases driven by exabyte growth were partially offset by declines in the average price per gigabyte of storage for both HDD and Flash as product mix shifted.

[0000106040-22-000018:mdna:36]
HDD revenue increased 16% for the three months ended December 31, 2021 from the comparable period in the prior year, primarily driven by a 27% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The increase in exabytes sold was due to continued demand for our latest generation energy assisted drives among our public and private cloud customers. The strong demand in Cloud was partly offset by a decline in HDD exabytes sold in our Client and Consumer end markets due to pressure in the commercial channel related to component issues impacting our customers’ ability to ship product and greater component sourcing constraints within our own operations, and customers transitioning to client SSD. HDD revenue increased 27% for the six months ended December 31, 2021 from the comparable period in the prior year, primarily driven by a 40% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The increase in exabytes for the six-month period was largely attributable to the same factors noted above for the three-month period.

[0000106040-22-000018:mdna:37]
Flash revenue increased 29% for the three months ended December 31, 2021 from the comparable period in the prior year, primarily driven by a 37% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The higher exabytes sold was due to strong demand in Cloud for our latest generation of enterprise SSD products and the ramp of new 5G-based mobile phones incorporating our latest BiCS5 flash solutions in the Client market. Higher volume was also driven by strong demand in gaming along with a growing brand recognition of WD_Black based products in our Consumer market. Flash revenue increased 24% for the six months ended December 31, 2021 from the comparable period in the prior year, primarily driven by a 33% increase in exabytes sold, partially offset by a decline in the average price per gigabyte as noted above. The increase in exabytes for the six-month period was largely attributable to the same factors noted above for the three-month period.

[0000106040-22-000018:mdna:38]
The increase in Cloud revenue for the three months ended December 31, 2021 from the comparable period in the prior year was led by demand for HDD capacity enterprise drives, including growth in our 18-terabyte capacity drives and enterprise SSDs, as we continued to ramp sales of our latest generation products. However, the supply chain disruptions previously noted contributed to a decline in exabyte shipments and a decline in revenues compared to the first quarter of fiscal 2022. In Client, the slight decrease in revenues for the three months ended December 31, 2021 from the comparable period in the prior year reflected declines in both client SSD and client HDD revenue, as a result of the supply chain disruptions noted previously, partially offset by the ramp of 5G phones. In Consumer, revenue for the three months ended December 31, 2021 was relatively flat with the comparable period in the prior year with a shift in mix from HDD to flash reflecting stronger demand in gaming along with a growing brand recognition of WD_Black.

[0000106040-22-000018:mdna:39]
The increase in Cloud revenue for the six months ended December 31, 2021 from the comparable period in the prior year primarily reflects the same drivers noted above for the three-month period. In Client, the slight increase in revenues for the six months ended December 31, 2021 from the comparable period in the prior year reflected growth in mobile (led by 5G growth), and growth in gaming, automotive, IOT, and industrial applications in the first quarter of fiscal 2022, partially offset by declines in both client SSD and client HDD revenue, as a result of the supply chain disruptions noted previously. In Consumer, the increase in revenue for the six months ended December 31, 2021 from the comparable period in the prior year primarily reflected stronger demand in gaming along with a growing brand recognition of WD_Black.

[0000106040-22-000018:mdna:40]
The changes in net revenue by geography for both the three and six months ended December 31, 2021 from the comparable periods in the prior year reflect routine variations in the mix of business.

[0000106040-22-000018:mdna:41]
Our top 10 customers accounted for 46% and 44% of our net revenue for the three and six months ended December 31, 2021, respectively, compared to 43% and 41% of our net revenue for the three and six months ended January 1, 2021, respectively. For each of the three and six months ended December 31, 2021 and January 1, 2021, no single customer accounted for 10% or more of our net revenue.

[0000106040-22-000018:mdna:42]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. These programs represented 18% of gross revenues for both the three and six months ended December 31, 2021, and 20% and 19% of gross revenues for the three and six months ended January 1, 2021, respectively. Adjustments due to changes in accruals for these programs have generally averaged less than 1% of gross revenue year over year. The amounts attributed to our sales incentive

[0000106040-22-000018:mdna:43]
42

[0000106040-22-000018:mdna:44]
and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-22-000018:mdna:45]
We believe we have made significant progress in strengthening our product portfolio. We have qualified our enterprise SSD products at three cloud titans and two OEMs, and commenced commercial shipments of 20 terabyte hard drives based on OptiNAND technology. Additionally, we are seeing an increase in customer interest in adopting SMR technology and expect multiple cloud titans to deploy SMR drives in higher volume later in this calendar year. In client SSD, we plan to launch new products in the fiscal third quarter and enterprise SSD products later in the year, both based on BiCS5 technology. For our next generation 3D-flash, we began initial commercial shipment of consumer flash devices based on our 162-layer BiCS6. Furthermore, we qualified and commenced revenue shipment of client SSDs based on QLC and BiCS5 technology in the fiscal second quarter. While still early in its evolution, we believe our next generation BiCS6 node will play an important role in the adoption of QLC in the future. We expect these developments to contribute to further revenue growth as supply chain disruptions begin to abate.

[0000106040-22-000018:mdna:46]
[same as prior period, unchanged from 0000106040-21-000053:mdna:40]

[0000106040-22-000018:mdna:47]
Consolidated gross profit increased by $623 million for the three months ended December 31, 2021 from the comparable period in the prior year, which reflects the increase in revenue in both HDD and Flash and reduced costs as we ramped production on newer products, as well as an $83 million decrease in charges in the current period related to amortization expense on acquired intangible assets, some of which became fully amortized. Consolidated gross margin increased 8.5 percentage points for the three months ended December 31, 2021 from the comparable period in the prior year, which reflects cost reductions as we ramped production on newer products, the lower charges for amortization of acquired intangible assets noted above, and a shift in product mix to higher-margin flash drives. HDD and Flash gross margin increased by 5.0 and 9.0 percentage points year over year, respectively, reflecting cost reductions as we ramped production on newer products.

[0000106040-22-000018:mdna:48]
Consolidated gross profit increased by $1.38 billion for the six months ended December 31, 2021 from the comparable period in the prior year, which reflects the increase in revenue in both HDD and Flash, as well as a $189 million decrease in charges in the current period related to amortization expense on acquired intangible assets, some of which became fully amortized. Consolidated gross margin increased 9.2 percentage points for the six months ended December 31, 2021 from the comparable period in the prior year, which reflects higher gross margin in both HDD and Flash, the lower charges for amortization of acquired intangible assets noted above, and a shift in product mix to higher-margin flash drives. HDD and Flash gross margin increased by 4.9 and 9.8 percentage points year over year, respectively, reflecting cost reductions as we ramped production on newer products.

[0000106040-22-000018:mdna:49]
[same as prior period, unchanged from 0000106040-21-000053:mdna:43]

[0000106040-22-000018:mdna:50]
Research and development (“R&D”) expense increased $40 million for the three months ended December 31, 2021 from the comparable period in the prior year. The primary increases include approximately $20 million in employee compensation costs due to merit increases and increased headcount and approximately $10 million of higher engineering-related costs due to timing of projects. R&D expense increased $63 million for the six months ended December 31, 2021 from the comparable period in the prior year and primarily reflected higher employee compensation costs due to merit increases, increased headcount and higher variable compensation.

[0000106040-22-000018:mdna:51]
Selling, general and administrative (“SG&A”) expense increased $14 million for the three months ended December 31, 2021 from the comparable period in the prior year. The increase primarily reflected small increases in employee compensation costs due to merit increases as well as a small increase in professional services. SG&A expense increased $49 million for the six months ended December 31, 2021 from the comparable period in the prior year. The increase primarily reflected approximately $25 million related to higher professional services and approximately $20 million of higher employee compensation cost due to merit increases and higher variable compensation.

[0000106040-22-000018:mdna:52]
Employee termination, asset impairment and other charges were relatively flat for both the three and six month periods compared to the prior year and reflect minor actions taken in each period. For information regarding Employee termination, asset impairment and other charges, see Part I, Item 1, Note 15, Employee Termination, Asset Impairment, and Other Charges of the Notes to Condensed  Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000018:mdna:53]
[same as prior period, unchanged from 0000106040-21-000053:mdna:47]

[0000106040-22-000018:mdna:54]
Total interest and other expense, net for the three and six months ended December 31, 2021 increased slightly compared to the prior year, reflecting higher foreign exchange losses partially offset by lower interest expense resulting from the pay-down of principal on our debt.

[0000106040-22-000018:mdna:55]
[same as prior period, unchanged from 0000106040-21-000053:mdna:49]

[0000106040-22-000018:mdna:56]
[same as prior period, unchanged from 0000106040-21-000053:mdna:50]

[0000106040-22-000018:mdna:57]
[same as prior period, unchanged from 0000106040-21-000053:mdna:51]

[0000106040-22-000018:mdna:58]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
|  | ($ in millions) |
| Income before taxes | $ | 646 |  |  | $ | 85 |  |  | $ | 1,350 |  |  | $ | 82 |  |
| Income tax expense | 82 |  |  | 23 |  |  | 176 |  |  | 80 |  |
| Effective tax rate | 13 | % |  | 27 | % |  | 13 | % |  | 98 | % |

[0000106040-22-000018:mdna:59]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 31, 2021 and the U.S. Federal statutory rate of 21%, are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand that will expire at various dates during fiscal years 2024 through 2031. In addition, the effective tax rate for both the three and six months ended December 31, 2021 includes the discrete effect of an increase to unrecognized tax benefits as a result of ongoing discussions with various taxing authorities of $8 million and $25 million, respectively.

[0000106040-22-000018:mdna:60]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 1, 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, Philippines and Thailand. In addition, the effective tax rate for the three and six months ended January 1, 2021 includes the discrete effects of net tax deficiencies from shortfalls of $12 million related to the vesting of stock-based awards and additional tax expense of $10 million from the re-measurement of certain deferred tax liabilities due to restructuring activities. The discrete items had no impact on the amount of income taxes paid.

[0000106040-22-000018:mdna:61]
[same as prior period, unchanged from 0000106040-21-000053:mdna:55]

[0000106040-22-000018:mdna:62]
For additional information regarding Income tax expense, see Part I, Item 1, Note 13, Income Tax Expense, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000018:mdna:63]
[same as prior period, unchanged from 0000106040-21-000053:mdna:57]

[0000106040-22-000018:mdna:64]
[same as prior period, unchanged from 0000106040-21-000053:mdna:58]

[0000106040-22-000018:mdna:65]
|  | Six Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,187 |  |  | $ | 788 |  |  |  |
| Investing activities | (569) |  |  | (436) |  |  |  |
| Financing activities | (1,456) |  |  | (450) |  |  |  |
| Effect of exchange rate changes on cash | (1) |  |  | 6 |  |  |  |
| Net decrease in cash and cash equivalents | $ | (839) |  |  | $ | (92) |  |  |  |

[0000106040-22-000018:mdna:66]
[same as prior period, unchanged from 0000106040-21-000053:mdna:60]

[0000106040-22-000018:mdna:67]
As further explained under Key Developments- Financing Activities above, we have taken recent actions to reduce our overall debt levels and extend the average maturity. Following these actions, we have reduced the outstanding principal amount of our debt by approximately $1.43 billion since October 1, 2021 and over 85% of the principal amount is now due in 2026 or later. We also have an existing a shelf registration statement (the “Shelf Registration Statement”) filed with the Securities and Exchange Commission that expires in August 2024, which allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We used the Shelf Registration Statement to complete our offering of $1.00 billion aggregate principal amount of senior unsecured notes in December 2021, and we may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-22-000018:mdna:68]
During fiscal 2022, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate approximately $3.0 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we now expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $1.5 billion during fiscal 2022. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-22-000018:mdna:69]
A total of $1.84 billion and $1.97 billion of our Cash and cash equivalents was held outside of the U.S. as of December 31, 2021 and January 1, 2021, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-22-000018:mdna:70]
45

[0000106040-22-000018:mdna:71]
[same as prior period, unchanged from 0000106040-21-000053:mdna:64]

[0000106040-22-000018:mdna:72]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $715 million for the six months ended December 31, 2021, as compared to $78 million for the six months ended January 1, 2021. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0000106040-22-000018:mdna:73]
|  | Three Months Ended |  |  |
|  | December 31,2021 |  | January 1,2021 |  |  |  |  |
| Days sales outstanding | 52 |  |  | 42 |  |  |  |  |  |
| Days in inventory | 102 |  |  | 109 |  |  |  |  |  |
| Days payables outstanding | (68) |  |  | (71) |  |  |  |  |  |
| Cash conversion cycle | 86 |  |  | 80 |  |  |  |  |  |

[0000106040-22-000018:mdna:74]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds and staging of inventory to meet expected future demand. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we negotiate to modify the timing of payments to our vendors to manage our vendor relationships and to manage our cash flows, including our cash balances.

[0000106040-22-000018:mdna:75]
For the three months ended December 31, 2021, DSO increased by 10 days from the comparable period in the prior year, primarily reflecting the timing of shipments and customer collections. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO and DPO decreased by 7 days and 3 days, respectively, from the comparable period in the prior year primarily reflecting improved supply chain management in the HDD business, as well as routine variations in the timing of purchases and payments during the period.

[0000106040-22-000018:mdna:76]
[same as prior period, unchanged from 0000106040-21-000053:mdna:69]

[0000106040-22-000018:mdna:77]
Net cash used in investing activities for the six months ended December 31, 2021 primarily consisted of $551 million in capital expenditures and a $17 million net increase in notes receivable issuances to Flash Ventures to fund its capital expansion. Net cash used in investing activities for the six months ended January 1, 2021 primarily consisted of $576 million in capital expenditures, partially offset by a $94 million net decrease in notes receivable issuances to Flash Ventures to fund its capital expansion.

[0000106040-22-000018:mdna:78]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset backed securities and corporate and municipal notes and bonds.

[0000106040-22-000018:mdna:79]
Financing Activities

[0000106040-22-000018:mdna:80]
During the six months ended December 31, 2021, net cash used in financing activities primarily consisted of $2.43 billion for repayment of debt, which included $1.09 billion to voluntarily repay our Term Loan B-4 in full, scheduled principal payments of $126 million and a voluntary prepayment of $1.21 billion on our Term Loan A-1, as well as $80 million for taxes paid on vested stock awards under employee stock plans offset by net proceeds of $989 million from the issuance of new debt, which was used to fund a portion of the voluntary prepayment on Term Loan A-1, and $60 million from the issuance of stock under employee stock plans. Net cash used in financing activities for the six months ended months ended January 1, 2021 primarily consisted of $461 million for the repayment of our debt, which included a $300 million voluntary prepayment on our Term Loan B-4.

[0000106040-22-000018:mdna:81]
[same as prior period, unchanged from 0000106040-21-000053:mdna:75]

[0000106040-22-000018:mdna:82]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Contractual Obligations and Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000106040-22-000018:mdna:83]
47

[0000106040-22-000018:mdna:84]
[same as prior period, unchanged from 0000106040-21-000053:mdna:78]

[0000106040-22-000018:mdna:85]
[same as prior period, unchanged from 0000106040-21-000053:mdna:79]

[0000106040-22-000018:mdna:86]
The following is a summary of our known contractual cash obligations and commercial commitments as of December 31, 2021:

[0000106040-22-000018:mdna:87]
|  | Total |  | Remaining six months of 2022 |  | 2023-2024 |  | 2025-2026 |  | Beyond 2026 |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 7,400 |  |  | $ | 126 |  |  | $ | 3,974 |  |  | $ | 2,300 |  |  | $ | 1,000 |  |
| Interest on debt | 831 |  |  | 103 |  |  | 376 |  |  | 278 |  |  | 74 |  |
| Flash Ventures related commitments(2) | 6,049 |  |  | 2,105 |  |  | 2,587 |  |  | 1,136 |  |  | 221 |  |
| Operating leases | 393 |  |  | 27 |  |  | 93 |  |  | 85 |  |  | 188 |  |
| Purchase obligations and other commitments | 3,770 |  |  | 2,215 |  |  | 1,217 |  |  | 168 |  |  | 170 |  |
| Mandatory Deemed Repatriation Tax | 819 |  |  | — |  |  | 284 |  |  | 535 |  |  | — |  |
| Total | $ | 19,262 |  |  | $ | 4,576 |  |  | $ | 8,531 |  |  | $ | 4,502 |  |  | $ | 1,653 |  |

[0000106040-22-000018:mdna:88]
(1)Principal portion of debt, excluding discounts and issuance costs.

[0000106040-22-000018:mdna:89]
[same as prior period, unchanged from 0000106040-21-000053:mdna:83]

[0000106040-22-000018:mdna:90]
[same as prior period, unchanged from 0000106040-21-000053:mdna:84]

[0000106040-22-000018:mdna:91]
Following the transactions described under Key Developments- Financing Activities, we have outstanding $3.3 billion aggregate principal amount of senior unsecured notes with maturities between 2026 and 2032, $3.0 billion principal amount of a new Term Loan A-2 that will mature in January 2027 and $1.1 billion of 1.5% convertible notes due 2024. In addition to our existing debt, we have $2.25 billion available for borrowing under our revolving credit facility until January 2027, subject to customary conditions under the loan agreement. See Key Developments- Financing Activities above for further information.  Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q and in Part II, Item 8, Note 6, Debt, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0000106040-22-000018:mdna:92]
We may issue additional debt securities in the future that may be guaranteed by our 100% owned domestic subsidiary, Western Digital Technologies, Inc. (“Guarantor” and, together with Western Digital Corporation, the “Obligor Group”). Such guarantees may be full and unconditional, joint and several, on a secured or unsecured, subordinated or unsubordinated basis, and may be subject to certain customary guarantor release conditions. We conduct operations almost entirely through our subsidiaries. Accordingly, the Obligor Group’s cash flow and ability to service any guaranteed registered debt securities will depend on the earnings of our subsidiaries and the distribution of those earnings to the Obligor Group, including the earnings of the non-guarantor subsidiaries, whether by dividends, loans or otherwise. Holders of such guaranteed registered debt securities would have a direct claim only against the Obligor Group.

[0000106040-22-000018:mdna:93]
[same as prior period, unchanged from 0000106040-21-000053:mdna:87]

[0000106040-22-000018:mdna:94]
[same as prior period, unchanged from 0000106040-21-000053:mdna:88]

[0000106040-22-000018:mdna:95]
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Current assets (excluding net intercompany receivable from non-guarantor subsidiaries) | $ | 2,429 |  |  | $ | 2,898 |  |
| Non-current assets | 1,848 |  |  | 1,903 |  |
| Net intercompany payable to non-guarantor subsidiaries | 1,110 |  |  | 463 |  |
| Current liabilities | 2,379 |  |  | 2,325 |  |
| Non-current liabilities | 8,289 |  |  | 9,726 |  |

[0000106040-22-000018:mdna:96]
[same as prior period, unchanged from 0000106040-21-000053:mdna:90]

[0000106040-22-000018:mdna:97]
|  | Six Months Ended |  | Year Ended |
|  | December 31,2021 |  | July 2,2021 |
|  | (in millions) |
| Net sales | $ | 4,253 |  |  | $ | 12,378 |  |
| Gross profit | 1,124 |  |  | 1,861 |  |
| Operating income | 77 |  |  | 142 |  |
| Net income (loss) | (15) |  |  | 377 |  |
| Intercompany revenue | 1,234 |  |  | 5,190 |  |
| Net intercompany interest expense (income) | (22) |  |  | 23 |  |
| Intercompany dividends | 105 |  |  | 528 |  |

[0000106040-22-000018:mdna:98]
[same as prior period, unchanged from 0000106040-21-000053:mdna:92]

[0000106040-22-000018:mdna:99]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of December 31, 2021, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0000106040-22-000018:mdna:100]
49

[0000106040-22-000018:mdna:101]
[same as prior period, unchanged from 0000106040-21-000053:mdna:94]

[0000106040-22-000018:mdna:102]
[same as prior period, unchanged from 0000106040-21-000053:mdna:95]

[0000106040-22-000018:mdna:103]
[same as prior period, unchanged from 0000106040-21-000053:mdna:96]

[0000106040-22-000018:mdna:104]
[same as prior period, unchanged from 0000106040-21-000053:mdna:97]

[0000106040-22-000018:mdna:105]
|  |  | December 31,2021 |
| 2023 |  | $ | 106 |  |
| 2024 |  | 178 |  |
| 2025 |  | 238 |  |
| 2026 |  | 297 |  |
| Total |  | $ | 819 |  |

[0000106040-22-000018:mdna:106]
[same as prior period, unchanged from 0000106040-21-000053:mdna:99]

[0000106040-22-000018:mdna:107]
[same as prior period, unchanged from 0000106040-21-000053:mdna:100]

[0000106040-22-000018:mdna:108]
As of December 31, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $772 million. Accrued interest and penalties related to unrecognized tax benefits as of December 31, 2021 was approximately $135 million. Of these amounts, approximately $772 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-22-000018:mdna:109]
[same as prior period, unchanged from 0000106040-21-000053:mdna:104]

[0000106040-22-000018:mdna:110]
[same as prior period, unchanged from 0000106040-21-000053:mdna:105]

[0000106040-22-000018:mdna:111]
[same as prior period, unchanged from 0000106040-21-000053:mdna:106]

[0000106040-22-000018:mdna:112]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-22-000018:mdna:113]
[same as prior period, unchanged from 0000106040-21-000053:mdna:108]

[0000106040-22-000018:mdna:114]
[same as prior period, unchanged from 0000106040-21-000053:mdna:109]

[0000106040-22-000018:mdna:115]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of our common stock, which authorization is effective through July 25, 2023. We did not make any stock repurchases during the six months ended December 31, 2021 and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of December 31, 2021 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-22-000018:mdna:116]
[same as prior period, unchanged from 0000106040-21-000053:mdna:111]

[0000106040-22-000018:mdna:117]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 2, Recent Accounting Pronouncements, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form    10-Q.

[0000106040-22-000018:mdna:118]
[same as prior period, unchanged from 0000106040-21-000053:mdna:113]

[0000106040-22-000018:mdna:119]
[same as prior period, unchanged from 0000106040-21-000053:mdna:114]

[0000106040-22-000018:mdna:120]
[same as prior period, unchanged from 0000106040-21-000053:mdna:115]
