# WDC note change history — 0001628280-25-047613 → 0001628280-26-004207


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004207:note_history:1]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of January 2, 2026.
  (was, 2025-10-31, similarity 0.9938):
[0001628280-25-047613:note_history:1]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of October 3, 2025.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-01-30):
[0001628280-26-004207:note_history:2]
The Company manufactures, markets, and sells data storage devices and solutions globally through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its extensive portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a wide range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.

- changed (2026-01-30):
[0001628280-26-004207:note_history:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 27, 2025 (the “2025 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and disclosures normally included in the Consolidated Financial Statements have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2025 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.
  (was, 2025-10-31, similarity 0.8437):
[0001628280-25-047613:note_history:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 27, 2025 (the “2025 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2025 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- changed (2026-01-30):
[0001628280-26-004207:note_history:4]
Information provided herein for the three and six months ended December 27, 2024 is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 4, Discontinued Operations.
  (was, 2025-10-31, similarity 0.9198):
[0001628280-25-047613:note_history:4]
Information provided herein for the three months ended September 27, 2024 is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 4, Discontinued Operations.

- changed (2026-01-30):
[0001628280-26-004207:note_history:5]
The Company’s Chief Executive Officer is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income from continuing operations and Total assets. The Company has therefore determined that it has one reportable segment.
  (was, 2025-10-31, similarity 0.9755):
[0001628280-25-047613:note_history:5]
The Company’s Chief Executive Officer is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income from continuing operations and Total assets. The Company has, therefore, determined that it has one reportable segment.

- removed (2026-01-30):
[0001628280-25-047613:note_history:6]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004207:note_history:7]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,586 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,686 |  |  | 4,749 |  |
| Issuance costs | (31) |  |  | (38) |  |
| Subtotal | 4,655 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,429 |  |  | $ | 2,485 |  |
  (was, 2025-10-31, similarity 0.9857):
[0001628280-25-047613:note_history:7]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,617 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,717 |  |  | 4,749 |  |
| Issuance costs | (34) |  |  | (38) |  |
| Subtotal | 4,683 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,457 |  |  | $ | 2,485 |  |

- added (2026-01-30):
[0001628280-26-004207:note_history:8]
During the three and six months ended January 2, 2026, the Company made scheduled repayments of $32 million and $63 million, respectively, under Term Loan A-3. The Company intends to redeem or repay the outstanding $500 million aggregate principal amount of 4.75% senior unsecured notes due 2026 on or before the scheduled maturity date of February 15, 2026.

- added (2026-01-30):
[0001628280-26-004207:note_history:9]
The Term Loan A-3 bears interest, at the Company’s option, at a base rate plus an applicable margin (as defined in the loan agreement governing the Term Loan A-3, which the Company refers to as the “Loan Agreement”). The all-in interest rate for Term Loan A-3 as of January 2, 2026 was 5.300%.

- changed (2026-01-30):
[0001628280-26-004207:note_history:10]
As of January 2, 2026, the Company had no outstanding standby letters of credit and the available capacity under the revolving credit facility maturing in January 2027 was $1.25 billion as of that date.
  (was, 2025-10-31, similarity 0.9686):
[0001628280-25-047613:note_history:10]
As of October 3, 2025, the Company had no outstanding standby letters of credit and the available capacity under the revolving credit facility maturing in January 2027 was $1.25 billion as of that date.

- changed (2026-01-30):
[0001628280-26-004207:note_history:11]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of January 2, 2026, the Company was in compliance with the financial covenant.
  (was, 2025-10-31, similarity 0.9643):
[0001628280-25-047613:note_history:11]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of October 3, 2025, the Company was in compliance with the financial covenant.

- changed (2026-01-30):
[0001628280-26-004207:note_history:12]
As of January 2, 2026, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).
  (was, 2025-10-31, similarity 0.9788):
[0001628280-25-047613:note_history:12]
As of October 3, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

- changed (2026-01-30):
[0001628280-26-004207:note_history:13]
The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.74 per share of common stock (as of January 2, 2026, as adjusted in accordance with the Indenture as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.
  (was, 2025-10-31, similarity 0.9733):
[0001628280-25-047613:note_history:13]
As of October 3, 2025, the 2028 Convertible Notes were convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.77 per share of common stock (as adjusted in accordance with the Indenture as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.

- added (2026-01-30):
[0001628280-26-004207:note_history:14]
During the calendar quarter ended December 31, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered, which provides the holders of those notes with the right to convert during the succeeding calendar ending March 31, 2026. Similarly, during the calendar quarter ended June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was also triggered, which then provided the holders with the right to convert during the succeeding calendar quarter ended September 30, 2025. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of each of January 2, 2026 and June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.

- changed (2026-01-30):
[0001628280-26-004207:note_history:15]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). As of January 2, 2026, the Capped Calls each have a strike price of approximately $37.74 per share, as adjusted in accordance with the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the 2028 Convertible Notes, which the Company expects will result in adjusted cap prices of approximately $50.43 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.
  (was, 2025-10-31, similarity 0.9941):
[0001628280-25-047613:note_history:15]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). As of October 3, 2025, the Capped Calls each have a strike price of approximately $37.77 per share, as adjusted in accordance with the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $50.47 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.

- removed (2026-01-30):
[0001628280-25-047613:note_history:16]
During the three months ended October 3, 2025, the Company made scheduled repayments of $31 million under the Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”). The Term Loan A-3 bears interest, at the Company’s option, at a base rate plus an applicable margin (as defined in the loan agreement governing the Term Loan A-3, which the Company refers to as the “Loan Agreement”). The all-in interest rate for Term Loan A-3 as of October 3, 2025 was 5.774%.

- removed (2026-01-30):
[0001628280-25-047613:note_history:17]
During the calendar quarters ended September 30, 2025 and June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holders of the 2028 Convertible Notes have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through December 31, 2025. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of October 3, 2025 and June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004207:note_history:18]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,586 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,686 |  |  | 4,749 |  |
| Issuance costs | (31) |  |  | (38) |  |
| Subtotal | 4,655 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,429 |  |  | $ | 2,485 |  |
  (was, 2025-10-31, similarity 0.9857):
[0001628280-25-047613:note_history:18]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,617 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,717 |  |  | 4,749 |  |
| Issuance costs | (34) |  |  | (38) |  |
| Subtotal | 4,683 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,457 |  |  | $ | 2,485 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004207:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,673 |  |  | $ | 2,096 |  |  | $ | 5,183 |  |  | $ | 4,005 |  |
| Client | 176 |  |  | 140 |  |  | 322 |  |  | 279 |  |
| Consumer | 168 |  |  | 173 |  |  | 330 |  |  | 337 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Americas | $ | 1,291 |  |  | $ | 1,039 |  |  | $ | 2,391 |  |  | $ | 2,286 |  |
| Asia | 1,117 |  |  | 910 |  |  | 2,292 |  |  | 1,596 |  |
| Europe, Middle East and Africa | 609 |  |  | 460 |  |  | 1,152 |  |  | 739 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |
  (was, 2025-10-31, similarity 0.7314):
[0001628280-25-047613:note_history:19]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,510 |  |  | $ | 1,909 |  |  |  |  |  |
| Client | 146 |  |  | 139 |  |  |  |  |  |
| Consumer | 162 |  |  | 164 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Asia | $ | 1,175 |  |  | $ | 686 |  |  |  |  |  |
| Americas | 1,100 |  |  | 1,247 |  |  |  |  |  |
| Europe, Middle East and Africa | 543 |  |  | 279 |  |  |  |  |  |
| Total revenue | $ | 2,818 |  |  | $ | 2,212 |  |  |  |  |  |
