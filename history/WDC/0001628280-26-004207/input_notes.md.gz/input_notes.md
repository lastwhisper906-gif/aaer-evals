# WDC notes — 0001628280-26-004207


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-26-004207:notes:1]
[same as prior period, unchanged from 0001628280-25-047613:notes:1]

[0001628280-26-004207:notes:2]
The Company manufactures, markets, and sells data storage devices and solutions globally through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its extensive portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a wide range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world.

[0001628280-26-004207:notes:3]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 27, 2025 (the “2025 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and disclosures normally included in the Consolidated Financial Statements have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2025 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

[0001628280-26-004207:notes:4]
Information provided herein for the three and six months ended December 27, 2024 is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 4, Discontinued Operations.

[0001628280-26-004207:notes:5]
[same as prior period, unchanged from 0001628280-25-047613:notes:5]

[0001628280-26-004207:notes:6]
[same as prior period, unchanged from 0001628280-25-047613:notes:6]

[0001628280-26-004207:notes:7]
[same as prior period, unchanged from 0001628280-25-047613:notes:7]

[0001628280-26-004207:notes:8]
The Company’s Chief Executive Officer is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income from continuing operations and Total assets. The Company has therefore determined that it has one reportable segment.

[0001628280-26-004207:notes:9]
[same as prior period, unchanged from 0001628280-25-047613:notes:9]

[0001628280-26-004207:notes:10]
[same as prior period, unchanged from 0001628280-25-047613:notes:10]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-26-004207:notes:11]
Recent Accounting Pronouncements
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001628280-26-004207:notes:12]
In December 2025, the Financial Accounting Standards Board (“FASB”) issued accounting standards update (“ASU”) No. 2025-10, “Government Grants (Topic 832): Accounting for Government Grants Received by Business Entities” (“ASU 2025-10”), which establishes guidance on the recognition, measurement, and presentation of government grants. The standard may be adopted using a full retrospective, modified retrospective, or modified prospective transition method. ASU 2025-10 is effective for the year beginning June 30, 2029, and interim periods within that year, with early adoption permitted. The Company is currently assessing the impact of this guidance on its condensed consolidated financial statements and related disclosures.

[0001628280-26-004207:notes:13]
In November 2025, the FASB issued ASU No. 2025-09, “Derivatives and Hedging (Topic 815): Hedge Accounting Improvements” (“ASU 2025-09”), which introduces targeted improvements to better align hedge accounting with entities’ risk management activities. ASU 2025-09 is effective for the year beginning July 3, 2027, and interim periods within that year, with early adoption permitted. The Company is currently assessing the impact of this guidance on its condensed consolidated financial statements and related disclosures.

[0001628280-26-004207:notes:14]
In September 2025, the FASB issued ASU No. 2025-07, “Derivatives and Hedging (Topic 815) and Revenue from Contracts with Customers (Topic 606): Derivatives Scope Refinements and Scope Clarification for Share-Based Noncash Consideration from a Customer in a Revenue Contract” (“ASU 2025-07”), which (i) expands the scope exception of Topic 815 to exclude certain contracts with a variable that is based on operations or activities specific to one of the parties to the contract and (ii) clarifies the scope of share-based payments from a customer in a revenue contract. ASU 2025-07 is effective for the year beginning July 3, 2027, and interim periods within that year. Early adoption is permitted and must be applied as of the beginning of the fiscal year that includes the interim period. The Company currently does not expect this standard to have a material impact on its condensed consolidated financial statements and related disclosures.

[0001628280-26-004207:notes:15]
In September 2025, the FASB issued ASU No. 2025-06, “Intangibles – Goodwill and Other – Internal-Use Software (Topic 350): Targeted Improvements to the Accounting for Internal-Use Software” (“ASU 2025-06”). ASU 2025-06 amends existing references to prescriptive and sequential software development stages to better align with current software development methods, such as agile development. Under the new standard, entities will begin to capitalize eligible software costs when (i) management has authorized and committed to funding the software project, and (ii) it is probable that the project will be completed and the software will be used to perform the function intended. ASU 2025-06 is effective for the year beginning July 1, 2028, and interim periods within that year, with early adoption permitted. The Company is currently assessing the impact of this standard on its condensed consolidated financial statements and related disclosures.

[0001628280-26-004207:notes:16]
In November 2024, the FASB issued ASU No. 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses” (“ASU 2024-03”), which is intended to improve disclosures about the expenses of public entities. The new guidance requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement, within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses and, in annual reporting periods, the definition of selling expenses. This standard is effective on either a prospective or retrospective basis with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption and expects to adopt the guidance for annual reporting periods in its annual report for the year ending June 30, 2028.

[0001628280-26-004207:notes:17]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” (“ASU 2023-09”). ASU 2023-09 calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. This standard is effective on either a prospective or retrospective basis. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026. The Company is currently compiling the information required for these disclosures and expects to provide any required disclosures in its annual report for the year ending July 3, 2026.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001628280-26-004207:notes:18]
[same as prior period, unchanged from 0001628280-25-047613:notes:16]

[0001628280-26-004207:notes:19]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,673 |  |  | $ | 2,096 |  |  | $ | 5,183 |  |  | $ | 4,005 |  |
| Client | 176 |  |  | 140 |  |  | 322 |  |  | 279 |  |
| Consumer | 168 |  |  | 173 |  |  | 330 |  |  | 337 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Americas | $ | 1,291 |  |  | $ | 1,039 |  |  | $ | 2,391 |  |  | $ | 2,286 |  |
| Asia | 1,117 |  |  | 910 |  |  | 2,292 |  |  | 1,596 |  |
| Europe, Middle East and Africa | 609 |  |  | 460 |  |  | 1,152 |  |  | 739 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |

[0001628280-26-004207:notes:20]
[same as prior period, unchanged from 0001628280-25-047613:notes:18]

[0001628280-26-004207:notes:21]
The Company’s top 10 customers accounted for 76% and 77%, respectively, of its net revenue for the three and six months ended January 2, 2026, compared to 67% and 65%, respectively, of its net revenue for the three and six months ended December 27, 2024. For the three months ended January 2, 2026, three customers accounted for 15%, 14%, and 14%, respectively, of the Company’s net revenue, and for the six months ended January 2, 2026, three customers accounted for 17%, 15%, and 14%, respectively, of the Company’s net revenue. For the three months ended December 27, 2024, two customers accounted for 18% and 13%, respectively, of the Company’s net revenue, and for the six months ended December 27, 2024, two customers accounted for 18% and 11%, respectively, of the Company’s net revenue.

[0001628280-26-004207:notes:22]
As of January 2, 2026 and June 27, 2025, net accounts receivable were $1.69 billion and $1.49 billion, respectively, and reserves for potential credit losses were not material. As of January 2, 2026, three customers accounted for 24%, 14%, and 14%, respectively, of the Company’s net accounts receivable, and as of June 27, 2025, three customers accounted for 20%, 19%, and 12%, respectively, of the Company’s net accounts receivable.

[0001628280-26-004207:notes:23]
[same as prior period, unchanged from 0001628280-25-047613:notes:21]

[0001628280-26-004207:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue, net | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |
| Less: Significant expenses and other segment items |  |  |  |  |  |  |  |
| Cost of revenue(1) | 1,626 |  |  | 1,483 |  |  | 3,207 |  |  | 2,869 |  |
| Research and development(1) | 265 |  |  | 209 |  |  | 535 |  |  | 452 |  |
| Selling, general and administrative(1) | 107 |  |  | 126 |  |  | 218 |  |  | 302 |  |
| Litigation matter | — |  |  | 14 |  |  | — |  |  | 28 |  |
| Business realignment charges | 52 |  |  | (10) |  |  | 55 |  |  | (7) |  |
| Stock-based compensation | 53 |  |  | 30 |  |  | 106 |  |  | 87 |  |
| Interest expense, net | 42 |  |  | 84 |  |  | 84 |  |  | 176 |  |
| Gain on retained interest in Sandisk | (1,103) |  |  | — |  |  | (1,714) |  |  | — |  |
| Other expense, net | 3 |  |  | 6 |  |  | 5 |  |  | 2 |  |
| Other segment items(2) | 10 |  |  | 1 |  |  | 40 |  |  | 3 |  |
| Income tax expense | 120 |  |  | — |  |  | 275 |  |  | 90 |  |
| Net income from continuing operations | $ | 1,842 |  |  | $ | 466 |  |  | $ | 3,024 |  |  | $ | 619 |  |

[0001628280-26-004207:notes:25]
[same as prior period, unchanged from 0001628280-25-047613:notes:23]

[0001628280-26-004207:notes:26]
(2)    Other segment items include activity from strategic investments and other charges.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-26-004207:notes:27]
[same as prior period, unchanged from 0001628280-25-047613:notes:25]

[0001628280-26-004207:notes:28]
On February 21, 2025, the Company completed the separation of its Flash business (the “Separation”) through a pro rata distribution of 80.1% of the outstanding shares of Sandisk Corporation (“Sandisk”) to Western Digital stockholders. The Separation is intended to be tax-free for U.S. federal income tax purposes. To reflect the completion of the Separation, the Company recorded a decrease in shareholders’ equity for the net book value of applicable assets and liabilities derecognized in connection with the Separation, net of the Company’s retained ownership interest, which was initially 19.9% and was based on the net book value of the applicable assets and liabilities derecognized. As a result of the Separation, Sandisk became an independent public company and Western Digital no longer consolidates Sandisk into the Company’s financial results. The historical results of operations of Sandisk are now reported in the Company’s Condensed Consolidated Financial Statements as discontinued operations for all periods prior to the Separation on February 21, 2025. Following the Separation, as the Company no longer controls or has the ability to exert significant influence over Sandisk, the Company measures, at fair value on a recurring basis, its retained ownership interest in Sandisk common stock (see additional information in Note 6, Fair Value Measurements and Investments). In June 2025, the Company disposed of 21.3 million shares of Sandisk common stock, along with $4 million in cash, in a tax-free exchange for $800 million principal amount of the Company’s Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”). The Company expects to monetize its remaining stake in Sandisk to further reduce its debt within one year from the Separation date.

[0001628280-26-004207:notes:29]
[same as prior period, unchanged from 0001628280-25-047613:notes:27]

[0001628280-26-004207:notes:30]
The following table provides a summary of the historical results of Sandisk for the three and six months ended December 27, 2024 which have been reflected as Net income from discontinued operations, net of taxes in the Condensed Consolidated Statements of Operations:

[0001628280-26-004207:notes:31]
|  |  | Three Months Ended |  | Six Months Ended |  |  |  |  |
| Net Income from Discontinued Operations, Net of Taxes |  | December 27,2024 |  |  |  |  |  |  |
|  |  | (in millions) |  |  |
| Revenue, net |  | $ | 1,876 |  |  | $ | 3,759 |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,267 |  |  | 2,405 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 277 |  |  | 534 |  |  |  |  |  |  |  |
| Selling, general and administrative |  | 106 |  |  | 144 |  |  |  |  |  |  |  |
| Gain on business divestiture |  | (113) |  |  | (113) |  |  |  |  |  |  |  |
| Business separation costs |  | 44 |  |  | 87 |  |  |  |  |  |  |  |
| Business realignment charges |  | 3 |  |  | 2 |  |  |  |  |  |  |  |
| Operating income |  | 292 |  |  | 700 |  |  |  |  |  |  |  |
| Total interest and other expense, net |  | 17 |  |  | 40 |  |  |  |  |  |  |  |
| Income before taxes |  | 275 |  |  | 660 |  |  |  |  |  |  |  |
| Income tax expense |  | 147 |  |  | 192 |  |  |  |  |  |  |  |
| Net income from discontinued operations, net of taxes |  | $ | 128 |  |  | $ | 468 |  |  |  |  |  |  |  |

[0001628280-26-004207:notes:32]
[same as prior period, unchanged from 0001628280-25-047613:notes:30]

[0001628280-26-004207:notes:33]
|  |  |  |  | Six Months Ended |
| Select Cash Flow Information from Discontinued Operations |  |  |  | December 27,2024 |
|  |  |  |  | (in millions) |
| Purchases of property, plant and equipment |  |  |  | $ | 115 |  |
| Depreciation and amortization |  |  |  | 91 |  |
| Stock-based compensation |  |  |  | 74 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001628280-26-004207:notes:34]
[same as prior period, unchanged from 0001628280-25-047613:notes:32]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-004207:notes:35]
[same as prior period, unchanged from 0001628280-25-047613:notes:33]

[0001628280-26-004207:notes:36]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 207 |  |  | $ | 227 |  |
| Work-in-process | 785 |  |  | 785 |  |
| Finished goods | 357 |  |  | 279 |  |
| Total inventories | $ | 1,349 |  |  | $ | 1,291 |  |

[0001628280-26-004207:notes:37]
[same as prior period, unchanged from 0001628280-25-047613:notes:35]

[0001628280-26-004207:notes:38]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 225 |  |  | $ | 225 |  |
| Buildings and improvements | 1,586 |  |  | 1,550 |  |
| Machinery and equipment | 6,649 |  |  | 6,488 |  |
| Computer equipment and software | 272 |  |  | 257 |  |
| Furniture and fixtures | 36 |  |  | 33 |  |
| Construction-in-process | 446 |  |  | 532 |  |
| Property, plant and equipment, gross | 9,214 |  |  | 9,085 |  |
| Accumulated depreciation | (6,862) |  |  | (6,742) |  |
| Property, plant and equipment, net | $ | 2,352 |  |  | $ | 2,343 |  |

[0001628280-26-004207:notes:39]
[same as prior period, unchanged from 0001628280-25-047613:notes:37]

[0001628280-26-004207:notes:40]
|  | January 2,2026 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Non-current assets: |  |  |  |  |  |  |  |  |  |
| Deferred tax assets | $ | 925 |  |  | $ | 1,007 |  |  |  |  |  |  |  |
| Other non-current assets | 484 |  |  | 477 |  |  |  |  |  |  |  |
| Total non-current assets | $ | 1,409 |  |  | $ | 1,484 |  |  |  |  |  |  |  |

[0001628280-26-004207:notes:41]
Product warranty accrual

[0001628280-26-004207:notes:42]
[same as prior period, unchanged from 0001628280-25-047613:notes:40]

[0001628280-26-004207:notes:43]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 160 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 142 |  |  |  |
| Charges to operations | 29 |  |  | 25 |  |  | 56 |  |  | 49 |  |  |  |
| Utilization | (13) |  |  | (13) |  |  | (37) |  |  | (43) |  |  |  |
| Changes in estimate related to pre-existing warranties | 1 |  |  | (10) |  |  | 6 |  |  | (27) |  |  |  |
| Warranty accrual, end of period | $ | 177 |  |  | $ | 121 |  |  | $ | 177 |  |  | $ | 121 |  |  |  |

[0001628280-26-004207:notes:44]
The current portion of the warranty accrual was classified in Accrued expenses and the long-term portion was classified in Other liabilities, as noted below:

[0001628280-26-004207:notes:45]
|  | January 2,2026 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 49 |  |  | $ | 57 |  |  |  |  |  |  |  |
| Long-term portion | 128 |  |  | 95 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 177 |  |  | $ | 152 |  |  |  |  |  |  |  |

[0001628280-26-004207:notes:46]
[same as prior period, unchanged from 0001628280-25-047613:notes:44]

[0001628280-26-004207:notes:47]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current portion of unrecognized tax benefits | $ | 207 |  |  | $ | 163 |  |
| Other non-current liabilities | 459 |  |  | 396 |  |
| Total other liabilities | $ | 666 |  |  | $ | 559 |  |

[0001628280-26-004207:notes:48]
[same as prior period, unchanged from 0001628280-25-047613:notes:46]

[0001628280-26-004207:notes:49]
Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. Management performed goodwill impairment assessments and concluded there were no impairments for each of the three or six months ended January 2, 2026 and December 27, 2024. The carrying amount of goodwill was $4.32 billion as of both January 2, 2026 and June 27, 2025.

[0001628280-26-004207:notes:50]
[same as prior period, unchanged from 0001628280-25-047613:notes:48]

[0001628280-26-004207:notes:51]
[same as prior period, unchanged from 0001628280-25-047613:notes:49]

[0001628280-26-004207:notes:52]
|  | Actuarial Pension Gains |  | Foreign Currency Translation Adjustment |  |  |  | Unrealized Gains on Derivative Contracts |  | Total Accumulated Other Comprehensive Income |
|  | (in millions) |
| Balance at June 27, 2025 | $ | 16 |  |  | $ | (2) |  |  |  |  | $ | 6 |  |  | $ | 20 |  |
| Other comprehensive loss before reclassifications | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | — |  |  |  |  | (3) |  |  | (3) |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | — |  |  |  |  | 2 |  |  | 2 |  |
| Net current-period other comprehensive loss | — |  |  | — |  |  |  |  | (2) |  |  | (2) |  |
| Balance at January 2, 2026 | $ | 16 |  |  | $ | (2) |  |  |  |  | $ | 4 |  |  | $ | 18 |  |

[0001628280-26-004207:notes:53]
During the three and six months ended January 2, 2026, the amounts reclassified from Accumulated other comprehensive income were losses related to foreign exchange contracts that were substantially charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001628280-26-004207:notes:54]
As of January 2, 2026, all existing net gains related to cash flow hedges recorded in Accumulated other comprehensive income are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-004207:notes:55]
[same as prior period, unchanged from 0001628280-25-047613:notes:53]

[0001628280-26-004207:notes:56]
[same as prior period, unchanged from 0001628280-25-047613:notes:54]

[0001628280-26-004207:notes:57]
[same as prior period, unchanged from 0001628280-25-047613:notes:55]

[0001628280-26-004207:notes:58]
[same as prior period, unchanged from 0001628280-25-047613:notes:56]

[0001628280-26-004207:notes:59]
[same as prior period, unchanged from 0001628280-25-047613:notes:57]

[0001628280-26-004207:notes:60]
[same as prior period, unchanged from 0001628280-25-047613:notes:58]

[0001628280-26-004207:notes:61]
|  | January 2, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Retained interest in Sandisk | $ | 2,068 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,068 |  |
| Cash equivalents - Money market funds | 133 |  |  | — |  |  | — |  |  | 133 |  |
| Foreign exchange contracts | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total assets at fair value | $ | 2,201 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 2,214 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |

[0001628280-26-004207:notes:62]
[same as prior period, unchanged from 0001628280-25-047613:notes:60]

[0001628280-26-004207:notes:63]
[same as prior period, unchanged from 0001628280-25-047613:notes:61]

[0001628280-26-004207:notes:64]
[same as prior period, unchanged from 0001628280-25-047613:notes:62]

[0001628280-26-004207:notes:65]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below were categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the second quarter of 2026 and the fourth quarter of 2025, respectively.

[0001628280-26-004207:notes:66]
|  | January 2, 2026 |  | June 27, 2025 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |  | $ | 500 |  |  | $ | 499 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,582 |  |  | 1,593 |  |  | 1,642 |  |  | 1,655 |  |
| 3.00% convertible notes due 2028 | 1,579 |  |  | 7,993 |  |  | 1,575 |  |  | 2,849 |  |
| 2.85% senior notes due 2029 | 498 |  |  | 478 |  |  | 498 |  |  | 463 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 462 |  |  | 496 |  |  | 442 |  |
| Total | $ | 4,655 |  |  | $ | 11,026 |  |  | $ | 4,711 |  |  | $ | 5,908 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-004207:notes:67]
Debt
Debt consisted of the following:

[0001628280-26-004207:notes:68]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 500 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,586 |  |  | 1,649 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,686 |  |  | 4,749 |  |
| Issuance costs | (31) |  |  | (38) |  |
| Subtotal | 4,655 |  |  | 4,711 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (2,226) |  |
| Long-term debt | $ | 2,429 |  |  | $ | 2,485 |  |

[0001628280-26-004207:notes:69]
During the three and six months ended January 2, 2026, the Company made scheduled repayments of $32 million and $63 million, respectively, under Term Loan A-3. The Company intends to redeem or repay the outstanding $500 million aggregate principal amount of 4.75% senior unsecured notes due 2026 on or before the scheduled maturity date of February 15, 2026.

[0001628280-26-004207:notes:70]
The Term Loan A-3 bears interest, at the Company’s option, at a base rate plus an applicable margin (as defined in the loan agreement governing the Term Loan A-3, which the Company refers to as the “Loan Agreement”). The all-in interest rate for Term Loan A-3 as of January 2, 2026 was 5.300%.

[0001628280-26-004207:notes:71]
As of January 2, 2026, the Company had no outstanding standby letters of credit and the available capacity under the revolving credit facility maturing in January 2027 was $1.25 billion as of that date.

[0001628280-26-004207:notes:72]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of January 2, 2026, the Company was in compliance with the financial covenant.

[0001628280-26-004207:notes:73]
As of January 2, 2026, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

[0001628280-26-004207:notes:74]
The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.74 per share of common stock (as of January 2, 2026, as adjusted in accordance with the Indenture as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.

[0001628280-26-004207:notes:75]
During the calendar quarter ended December 31, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered, which provides the holders of those notes with the right to convert during the succeeding calendar ending March 31, 2026. Similarly, during the calendar quarter ended June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was also triggered, which then provided the holders with the right to convert during the succeeding calendar quarter ended September 30, 2025. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of each of January 2, 2026 and June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.

[0001628280-26-004207:notes:76]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). As of January 2, 2026, the Capped Calls each have a strike price of approximately $37.74 per share, as adjusted in accordance with the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the 2028 Convertible Notes, which the Company expects will result in adjusted cap prices of approximately $50.43 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-26-004207:notes:77]
[same as prior period, unchanged from 0001628280-25-047613:notes:74]

[0001628280-26-004207:notes:78]
[same as prior period, unchanged from 0001628280-25-047613:notes:75]

[0001628280-26-004207:notes:79]
[same as prior period, unchanged from 0001628280-25-047613:notes:76]

[0001628280-26-004207:notes:80]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 132 |  |  | $ | 123 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 33 |  |  | 31 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 115 |  |  | 110 |  |
| Total operating lease liabilities | $ | 148 |  |  | $ | 141 |  |

[0001628280-26-004207:notes:81]
[same as prior period, unchanged from 0001628280-25-047613:notes:78]

[0001628280-26-004207:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Cost of operating leases | $ | 9 |  |  | $ | 7 |  |  | $ | 18 |  |  | $ | 17 |  |
| Cash paid for operating leases | 9 |  |  | 9 |  |  | 19 |  |  | 20 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 23 |  |  | 7 |  |  | 23 |  |  | 12 |  |

[0001628280-26-004207:notes:83]
[same as prior period, unchanged from 0001628280-25-047613:notes:80]

[0001628280-26-004207:notes:84]
|  | January 2,2026 |  | June 27,2025 |  |  |
| Weighted average remaining lease term in years | 5.9 |  | 6.1 |  |  |
| Weighted average discount rate | 5.1 | % |  | 5.0 | % |  |  |

[0001628280-26-004207:notes:85]
As of January 2, 2026, minimum lease payments were as follows:

[0001628280-26-004207:notes:86]
|  | Lease Amounts |
|  | (in millions) |
| Remaining six months of 2026 | $ | 19 |  |
| 2027 | 36 |  |
| 2028 | 28 |  |
| 2029 | 22 |  |
| 2030 | 17 |  |
| Thereafter | 49 |  |
| Total future minimum lease payments | 171 |  |
| Less: imputed interest | 23 |  |
| Present value of lease liabilities | $ | 148 |  |

[0001628280-26-004207:notes:87]
[same as prior period, unchanged from 0001628280-25-047613:notes:84]

[0001628280-26-004207:notes:88]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions, such as performance, quality and technology of the vendor’s components. As of January 2, 2026, the Company had the following minimum long-term commitments:

[0001628280-26-004207:notes:89]
|  | Long-Term Commitments |
|  | (in millions) |
| Remaining six months of 2026 | $ | 32 |  |
| 2027 | 56 |  |
| Total | $ | 88 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-004207:notes:90]
[same as prior period, unchanged from 0001628280-25-047613:notes:87]

[0001628280-26-004207:notes:91]
[same as prior period, unchanged from 0001628280-25-047613:notes:88]

[0001628280-26-004207:notes:92]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”). For 2026, the Company is subject to GMT in Malaysia, Thailand, and the Philippines.

[0001628280-26-004207:notes:93]
[same as prior period, unchanged from 0001628280-25-047613:notes:90]

[0001628280-26-004207:notes:94]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | ($ in millions) |
| Income before taxes | $ | 1,962 |  | $ | 466 |  | $ | 3,299 |  | $ | 709 |
| Income tax expense | 120 |  | — |  | 275 |  | 90 |
| Effective tax rate | 6% |  | —% |  | 8% |  | 13% |

[0001628280-26-004207:notes:95]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 2, 2026 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for FDDEI, tax credits, and the gain on the retained interest in Sandisk being tax-free due to the Separation of the Flash business. These resulted in decreases to the Company’s effective tax rate below the U.S. Federal statutory rate for the three and six months ended January 2, 2026. The Company’s income tax provision for the three and six months ended January 2, 2026 includes GMT for Malaysia as well as Thailand and the Philippines, countries for which the Company maintains tax holidays.

[0001628280-26-004207:notes:96]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 27, 2024 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, tax credits, and tax holidays in Thailand and the Philippines. In addition, the effective tax rate for the six months ended December 27, 2024 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with U.S. Internal Revenue Service (“IRS”) calculations.

[0001628280-26-004207:notes:97]
[same as prior period, unchanged from 0001628280-25-047613:notes:94]

[0001628280-26-004207:notes:98]
[same as prior period, unchanged from 0001628280-25-047613:notes:95]

[0001628280-26-004207:notes:99]
The following is a reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties for the six months ended January 2, 2026 (in millions):

[0001628280-26-004207:notes:100]
| Accrual balance as of June 27, 2025 | $ | 569 |  |
| Gross increases related to current year tax positions | 6 |  |
| Gross increases related to prior year tax positions | 34 |  |
| Settlements | (1) |  |
| Lapse of statute of limitations | (1) |  |
| Accrual balance as of January 2, 2026 | $ | 607 |  |

[0001628280-26-004207:notes:101]
In addition to the amounts noted above, interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of January 2, 2026 was $97 million. Of the aggregate unrecognized tax benefits, including interest and penalties, approximately $130 million could result in potential cash payments to be made within the next twelve months.

[0001628280-26-004207:notes:102]
The Company believes that an adequate provision has been made for any adjustments that may result from any other tax examinations; however, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0001628280-26-004207:notes:103]
[same as prior period, unchanged from 0001628280-25-047613:notes:100]

[0001628280-26-004207:notes:104]
[same as prior period, unchanged from 0001628280-25-047613:notes:101]

[0001628280-26-004207:notes:105]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |  |  |
|  | (in millions) |
| Cash-based employee termination benefits | $ | 52 |  |  | $ | — |  |  | $ | 55 |  |  | $ | — |  |  |  |
| Stock-based employee termination benefits | 3 |  |  | — |  |  | 3 |  |  | — |  |  |  |
| Contract termination and other | — |  |  | (10) |  |  | — |  |  | (7) |  |  |  |
| Total business realignment charges | $ | 55 |  |  | $ | (10) |  |  | $ | 58 |  |  | $ | (7) |  |  |  |

[0001628280-26-004207:notes:106]
In addition, in January 2026, the Company implemented additional actions to further streamline functions and expects to record incremental employee termination costs of approximately $50 million in the remainder of 2026.

[0001628280-26-004207:notes:107]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the six months ended January 2, 2026:

[0001628280-26-004207:notes:108]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Accrual balance as of June 27, 2025 | $ | 1 |  |  | $ | 9 |  |  | $ | 10 |  |  |  |  |  |
| Charges | 55 |  |  | — |  |  | 55 |  |  |  |  |  |
| Cash payments | (10) |  |  | (2) |  |  | (12) |  |  |  |  |  |
| Accrual balance as of January 2, 2026 | $ | 46 |  |  | $ | 7 |  |  | $ | 53 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-26-004207:notes:109]
[same as prior period, unchanged from 0001628280-25-047613:notes:105]

[0001628280-26-004207:notes:110]
[same as prior period, unchanged from 0001628280-25-047613:notes:106]

[0001628280-26-004207:notes:111]
[same as prior period, unchanged from 0001628280-25-047613:notes:107]

[0001628280-26-004207:notes:112]
|  | January 2,2026 |  | June 27,2025 |  |  |
|  | (in millions) |
| Benefit obligation at end of period | $ | 257 |  |  | $ | 272 |  |  |  |
| Less: Fair value of plan assets at end of period | 179 |  |  | 204 |  |  |  |
| Unfunded status | $ | 78 |  |  | $ | 68 |  |  |  |

[0001628280-26-004207:notes:113]
[same as prior period, unchanged from 0001628280-25-047613:notes:109]

[0001628280-26-004207:notes:114]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Current liabilities (included in Accrued expenses) | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities (included in Other liabilities) | 77 |  |  | 67 |  |
| Net amount recognized | $ | 78 |  |  | $ | 68 |  |

[0001628280-26-004207:notes:115]
Net periodic benefit costs were immaterial for the three and six months ended January 2, 2026 and December 27, 2024.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001628280-26-004207:notes:116]
[same as prior period, unchanged from 0001628280-25-047613:notes:112]

[0001628280-26-004207:notes:117]
[same as prior period, unchanged from 0001628280-25-047613:notes:113]

[0001628280-26-004207:notes:118]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |  |
|  | (in millions) |
| RSUs and PSUs | $ | 49 |  |  | $ | 27 |  |  | $ | 98 |  |  | $ | 76 |  |  |
| ESPP | 4 |  |  | 3 |  |  | 8 |  |  | 11 |  |  |
| Total | $ | 53 |  |  | $ | 30 |  |  | $ | 106 |  |  | $ | 87 |  |  |

[0001628280-26-004207:notes:119]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |  |
|  | (in millions) |
| Cost of revenue | $ | 8 |  |  | $ | 9 |  |  | $ | 17 |  |  | $ | 19 |  |  |
| Research and development | 23 |  |  | 15 |  |  | 46 |  |  | 35 |  |  |
| Selling, general and administrative | 19 |  |  | 6 |  |  | 40 |  |  | 33 |  |  |
| Business realignment charges | 3 |  |  | — |  |  | 3 |  |  | — |  |  |
| Subtotal | 53 |  |  | 30 |  |  | 106 |  |  | 87 |  |  |
| Tax benefit | (6) |  |  | (5) |  |  | (13) |  |  | (11) |  |  |
| Total | $ | 47 |  |  | $ | 25 |  |  | $ | 93 |  |  | $ | 76 |  |  |

[0001628280-26-004207:notes:120]
[same as prior period, unchanged from 0001628280-25-047613:notes:116]

[0001628280-26-004207:notes:121]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are generally amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of January 2, 2026:

[0001628280-26-004207:notes:122]
|  | Unamortized Compensation Cost |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 335 |  |  | 2.0 |
| ESPP | 19 |  |  | 1.0 |
| Total unamortized compensation cost | $ | 354 |  |  |  |

[0001628280-26-004207:notes:123]
[same as prior period, unchanged from 0001628280-25-047613:notes:119]

[0001628280-26-004207:notes:124]
[same as prior period, unchanged from 0001628280-25-047613:notes:120]

[0001628280-26-004207:notes:125]
[same as prior period, unchanged from 0001628280-25-047613:notes:121]

[0001628280-26-004207:notes:126]
[same as prior period, unchanged from 0001628280-25-047613:notes:122]

[0001628280-26-004207:notes:127]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 27, 2025 | 9.7 |  |  | $ | 33.56 |  |  |  |
| Granted | 2.5 |  |  | 72.20 |  |  |  |
| Vested | (2.8) |  |  | 34.14 |  |  | $ | 278 |  |
| Forfeited | (0.3) |  |  | 35.31 |  |  |  |
| RSUs and PSUs outstanding at January 2, 2026 | 9.1 |  |  | $ | 44.51 |  |  |  |

[0001628280-26-004207:notes:128]
[same as prior period, unchanged from 0001628280-25-047613:notes:124]

[0001628280-26-004207:notes:129]
[same as prior period, unchanged from 0001628280-25-047613:notes:125]

[0001628280-26-004207:notes:130]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”), from the Company’s existing 5,000,000 authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement. As of both January 2, 2026 and June 27, 2025, 235,000 of the Preferred Shares were outstanding.

[0001628280-26-004207:notes:131]
The Preferred Shares have an initial stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. Such dividends are payable on a quarterly basis in cash or in-kind through an increase to the stated value. Through December 27, 2024, the Company paid quarterly dividends on the Preferred Shares in-kind through an increase to the stated value. Subsequently, quarterly dividends on the Preferred Shares have been made in cash, including $4 million and $8 million paid in the three and six months ended January 2, 2026, respectively. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis.

[0001628280-26-004207:notes:132]
As of January 2, 2026, the Preferred Shares are convertible into shares of the Company’s common stock at a conversion rate of approximately $35.51 per share, as adjusted in accordance with the Certificate of Designations for the Preferred Shares (the “Conversion Price”). This rate is subject to future anti-dilution adjustments and certain other one-time adjustments in the event of various specified spin-off transactions. The conversion applies to the total of the stated value of the Preferred Shares, including dividends paid in-kind. As of January 2, 2026 and June 27, 2025, the Preferred Shares outstanding had an aggregate liquidation preference, including previous dividends paid in-kind, of $265 million as of each date, and would have been convertible, if otherwise permitted, into approximately 7 million shares of common stock as of each date. The Company may opt to convert the Preferred Shares after January 31, 2026, if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately before the Company’s conversion notice.

[0001628280-26-004207:notes:133]
[same as prior period, unchanged from 0001628280-25-047613:notes:129]

[0001628280-26-004207:notes:134]
On May 9, 2025, the Company’s Board of Directors authorized a share repurchase program for the repurchase of up to $2.0 billion of the Company’s common stock (the “Share Repurchase Program”). There is no expiration date for the Share Repurchase Program. During the three months ended January 2, 2026, the Company repurchased 3.8 million shares under the Share Repurchase Program for a total cash cost of $615 million plus $4 million for accrued excise taxes. During the six months ended January 2, 2026, the Company repurchased 10.2 million shares under the Share Repurchase Program for a total cash cost of $1.17 billion plus $8 million for accrued excise taxes. As of January 2, 2026, the Company had $684 million available for purchases pursuant to the Share Repurchase Program. Repurchases under the Share Repurchase Program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects shares repurchased under the Share Repurchase Program to be funded principally by operating cash flows. The amount and timing of share repurchases will depend on market conditions and other corporate considerations. The Company may suspend or discontinue the Share Repurchase Program at any time.

[0001628280-26-004207:notes:135]
[same as prior period, unchanged from 0001628280-25-047613:notes:131]

[0001628280-26-004207:notes:136]
On April 29, 2025, the Company’s Board of Directors authorized the adoption of a cash dividend program. Under the cash dividend program, holders of the Company’s common stock will receive dividends when and as declared by the Board of Directors. During the three months ended January 2, 2026, the Company paid cash dividends of $0.125 per share of its outstanding common stock, totaling $43 million, plus $1 million paid to holders of the Company’s Preferred Shares in accordance with their participation rights. During the six months ended January 2, 2026, the Company paid aggregate cash dividends of $0.225 per share of its outstanding common stock, totaling $77 million, plus $2 million paid to holders of the Company’s Preferred Shares in accordance with their participation rights.

[0001628280-26-004207:notes:137]
Subsequent to quarter-end, on January 28, 2026, the Board of Directors declared a cash dividend of $0.125 per share of the Company’s common stock, which will be paid on March 18, 2026 to shareholders of record as of the close of business on March 5, 2026.

[0001628280-26-004207:notes:138]
[same as prior period, unchanged from 0001628280-25-047613:notes:134]


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-004207:notes:139]
[same as prior period, unchanged from 0001628280-25-047613:notes:135]

[0001628280-26-004207:notes:140]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions, except per share data) |
| Net income from continuing operations | $ | 1,842 |  |  |  | $ | 466 |  |  | $ | 3,024 |  |  | $ | 619 |  |
| Dividends allocated to preferred shareholders | (5) |  |  |  | (4) |  |  | (10) |  |  | (8) |  |
| Income attributable to participating securities(1) | (39) |  |  |  | (7) |  |  | (64) |  |  | (9) |  |
| Net income from continuing operations attributable to common shareholders - basic | 1,798 |  |  |  | 455 |  |  | 2,950 |  |  | 602 |  |
| Net income from discontinued operations, net of taxes, attributable to common shareholders | — |  |  |  | 126 |  |  | — |  |  | 460 |  |
| Net income attributable to common shareholders - basic | $ | 1,798 |  |  |  | $ | 581 |  |  | $ | 2,950 |  |  | $ | 1,062 |  |
| Net income from continuing operations attributable to common shareholders - basic | $ | 1,798 |  |  |  | $ | 455 |  |  | $ | 2,950 |  |  | $ | 602 |  |
| Re-allocation of participating securities considered potentially dilutive | 4 |  |  |  | — |  |  | 6 |  |  | 1 |  |
| Net income from continuing operations attributable to common shareholders - diluted | 1,802 |  |  |  | 455 |  |  | 2,956 |  |  | 603 |  |
| Net income from discontinued operations, net of taxes, attributable to common shareholders | — |  |  |  | 126 |  |  | — |  |  | 460 |  |
| Net income attributable to common shareholders - diluted | $ | 1,802 |  |  |  | $ | 581 |  |  | $ | 2,956 |  |  | $ | 1,063 |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |
| Basic | 341 |  |  |  | 346 |  |  | 343 |  |  | 345 |  |
| RSUs, PSUs, ESPP, and convertible notes | 40 |  |  |  | 11 |  |  | 35 |  |  | 12 |  |
| Diluted | 381 |  |  |  | 357 |  |  | 378 |  |  | 357 |  |
| Net income per common share: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 5.27 |  |  |  | $ | 1.32 |  |  | $ | 8.60 |  |  | $ | 1.74 |  |
| Discontinued operations | — |  |  |  | 0.36 |  |  | — |  |  | 1.34 |  |
| Net income per common share | 5.27 |  |  |  | 1.68 |  |  | 8.60 |  |  | 3.08 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations | 4.73 |  |  |  | 1.27 |  |  | 7.82 |  |  | 1.69 |  |
| Discontinued operations | — |  |  |  | 0.36 |  |  | — |  |  | 1.29 |  |
| Net income per common share | 4.73 |  |  |  | 1.63 |  |  | 7.82 |  |  | 2.98 |  |

[0001628280-26-004207:notes:141]
[same as prior period, unchanged from 0001628280-25-047613:notes:137]

[0001628280-26-004207:notes:142]
Basic net income per common share is computed using (i) net income less (ii) dividends allocated to preferred shareholders less (iii) net income attributable to participating securities divided by (iv) basic weighted average shares outstanding. Diluted net income per common share is computed as (i) basic net income attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) diluted weighted average shares outstanding. The “if-converted” method is used to determine the dilutive impact for the convertible notes and the preferred shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0001628280-26-004207:notes:143]
Potentially dilutive common shares include dilutive outstanding RSUs and PSUs, rights to purchase shares of common stock under the Company’s ESPP, shares issuable in connection with the Company’s convertible notes, and Preferred Shares. For the three and six months ended January 2, 2026 and December 27, 2024, based on the Company’s average stock price during the period, an insignificant number of common shares subject to outstanding equity awards were anti-dilutive.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001628280-26-004207:notes:144]
Legal Proceedings
Intellectual Property Litigation

[0001628280-26-004207:notes:145]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of January 2, 2026.

[0001628280-26-004207:notes:146]
Other Matters

[0001628280-26-004207:notes:147]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.

[0001628280-26-004207:notes:148]
The ability to predict the ultimate outcome of any legal proceeding involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-004207:notes:149]
Brian Scott Davis, Executive Vice President and Chief Sales and Marketing Officer of the Company, adopted a Rule 10b5-1 Plan on November 3, 2025. Under this plan, up to an aggregate of 30,000 shares of the Company’s common stock may be sold before the plan expires on August 14, 2026.

[0001628280-26-004207:notes:150]
Matthew E. Massengill, a director of the Company, adopted a Rule 10b5-1 Plan on November 6, 2025. Under this plan, up to an aggregate of 36,926 shares of the Company’s common stock may be sold before the plan expires on May 15, 2026.
