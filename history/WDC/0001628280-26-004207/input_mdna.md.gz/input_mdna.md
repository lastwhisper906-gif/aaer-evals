# WDC MD&A — 0001628280-26-004207


## mdna

[0001628280-26-004207:mdna:1]
[same as prior period, unchanged from 0001628280-25-047613:mdna:1]

[0001628280-26-004207:mdna:2]
[same as prior period, unchanged from 0001628280-25-047613:mdna:2]

[0001628280-26-004207:mdna:3]
[same as prior period, unchanged from 0001628280-25-047613:mdna:3]

[0001628280-26-004207:mdna:4]
We are a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology. We leverage our capability in the HDD industry primarily for the cloud and hyperscale data center markets. HDDs are critical components in the worldwide data infrastructure market, powering the digital economy. HDDs provide reliable, cost-effective, high-capacity storage needs for a wide range of applications, ranging from cloud data centers, enterprise storage systems, edge computing, video surveillance, to client and consumer.

[0001628280-26-004207:mdna:5]
Our broad portfolio of technology and products addresses our customers’ storage needs through multiple end markets: “Cloud,” “Client” and “Consumer”. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0001628280-26-004207:mdna:6]
[same as prior period, unchanged from 0001628280-25-047613:mdna:6]

[0001628280-26-004207:mdna:7]
[same as prior period, unchanged from 0001628280-25-047613:mdna:7]

[0001628280-26-004207:mdna:8]
[same as prior period, unchanged from 0001628280-25-047613:mdna:8]

[0001628280-26-004207:mdna:9]
On February 21, 2025 (the “Separation Date”), we completed the separation of our HDD and Flash business units (the “Separation”) to create two independent public companies, with Western Digital continuing our existing HDD business and Sandisk Corporation (“Sandisk”), formerly a wholly-owned subsidiary of the Company, holding the Flash business. We believe the Separation has better positioned us as a pure-play HDD company that can execute innovative technology and product development, capitalize on unique growth opportunities, extend our leadership position, operate more efficiently, and pursue capital allocation strategies to maximize long-term shareholder value. As part of the Separation, we initially retained 28.8 million shares of Sandisk common stock, of which 21.3 million shares were used in the three months ended June 27, 2025 in a tax-free exchange to reduce approximately $800 million principal amount of our term loan A-3. We expect to monetize our remaining stake in Sandisk to further reduce our debt within one year from the Separation Date.

[0001628280-26-004207:mdna:10]
Prior period information provided herein is presented on a continuing operations basis to reflect the impact of the Separation. See Part I, Item 1, Note 4, Discontinued Operations, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information regarding the Separation.

[0001628280-26-004207:mdna:11]
[same as prior period, unchanged from 0001628280-25-047613:mdna:11]

[0001628280-26-004207:mdna:12]
The increasing long-term demand for data storage in the cloud is benefiting our HDD business. The adoption of artificial intelligence (“AI”) and workloads driven by hybrid data is driving additional growth in data storage as well. This creates an accelerated demand for high-capacity drives, resulting in greater manufacturing complexity and longer production lead times. In response, customers are partnering with us earlier to support their future growth requirements and are extending the duration of their commercial arrangements.

[0001628280-26-004207:mdna:13]
The United States has been making changes to its trade policy, including increasing tariffs on imports, in some cases significantly. Several of these tariff actions have been followed by announcements of limited exemptions, temporary pauses or other changes. These actions have caused substantial uncertainty and have also resulted in retaliatory measures. Our business and results of operations have not been materially impacted through the second quarter of 2026 as a result of these tariff actions, but we are actively monitoring developments and exploring opportunities to mitigate potential future tariff and retaliatory actions. For additional information, please see Part I, Item 1A, Risk Factors, included in our 2025 Annual Report on Form 10-K.

[0001628280-26-004207:mdna:14]
39

[0001628280-26-004207:mdna:15]
[same as prior period, unchanged from 0001628280-25-047613:mdna:15]

[0001628280-26-004207:mdna:16]
Second Quarter and First Half Overview

[0001628280-26-004207:mdna:17]
[same as prior period, unchanged from 0001628280-25-047613:mdna:17]

[0001628280-26-004207:mdna:18]
|  | Three Months Ended |  |  |
|  | January 2,2026 |  | December 27,2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  | ($ in millions) |  |  |
| Revenue, net | $ | 3,017 |  |  | 100.0 | % |  | $ | 2,409 |  |  | 100.0 | % |  | $ | 608 |  |  | 25 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 1,637 |  |  | 54.3 |  |  | 1,502 |  |  | 62.3 |  |  | 135 |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 1,380 |  |  | 45.7 |  |  | 907 |  |  | 37.7 |  |  | 473 |  |  | 52 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 289 |  |  | 9.6 |  |  | 225 |  |  | 9.3 |  |  | 64 |  |  | 28 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 128 |  |  | 4.2 |  |  | 132 |  |  | 5.5 |  |  | (4) |  |  | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business realignment charges | 55 |  |  | 1.8 |  |  | (10) |  |  | (0.4) |  |  | 65 |  |  | (650) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 472 |  |  | 15.6 |  |  | 347 |  |  | 14.4 |  |  | 125 |  |  | 36 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | 908 |  |  | 30.1 |  |  | 560 |  |  | 23.2 |  |  | 348 |  |  | 62 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 12 |  |  | 0.4 |  |  | 9 |  |  | 0.4 |  |  | 3 |  |  | 33 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (54) |  |  | (1.8) |  |  | (93) |  |  | (3.9) |  |  | 39 |  |  | (42) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on retained interest in Sandisk | 1,103 |  |  | 36.6 |  |  | — |  |  | — |  |  | 1,103 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (7) |  |  | (0.2) |  |  | (10) |  |  | (0.4) |  |  | 3 |  |  | 30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total interest and other income (expense), net | 1,054 |  |  | 34.9 |  |  | (94) |  |  | (3.9) |  |  | 1,148 |  |  | (1,221) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before taxes | 1,962 |  |  | 65.0 |  |  | 466 |  |  | 19.3 |  |  | 1,496 |  |  | 321 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 120 |  |  | 4.0 |  |  | — |  |  | — |  |  | 120 |  |  | n/a |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,842 |  |  | 61.1 | % |  | $ | 466 |  |  | 19.3 | % |  | $ | 1,376 |  |  | 295 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-26-004207:mdna:19]
[same as prior period, unchanged from 0001628280-25-047613:mdna:19]

[0001628280-26-004207:mdna:20]
|  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | $ Change |  | % Change |
|  | ($ in millions) |
| Revenue, net | $ | 5,835 |  |  | 100.0 | % |  | $ | 4,621 |  |  | 100.0 | % |  | $ | 1,214 |  |  | 26 | % |
| Cost of revenue | 3,228 |  |  | 55.3 |  |  | 2,908 |  |  | 62.9 |  |  | 320 |  |  | 11 |  |
| Gross profit | 2,607 |  |  | 44.7 |  |  | 1,713 |  |  | 37.1 |  |  | 894 |  |  | 52 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 583 |  |  | 10.0 |  |  | 487 |  |  | 10.5 |  |  | 96 |  |  | 20 |  |
| Selling, general and administrative | 266 |  |  | 4.6 |  |  | 336 |  |  | 7.3 |  |  | (70) |  |  | (21) |  |
| Litigation matter | — |  |  | — |  |  | 3 |  |  | 0.1 |  |  | (3) |  |  | (100) |  |
| Business realignment charges | 58 |  |  | 1.0 |  |  | (7) |  |  | (0.2) |  |  | 65 |  |  | (929) |  |
| Total operating expenses | 907 |  |  | 15.5 |  |  | 819 |  |  | 17.7 |  |  | 88 |  |  | 11 |  |
| Operating income | 1,700 |  |  | 29.1 |  |  | 894 |  |  | 19.3 |  |  | 806 |  |  | 90 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 29 |  |  | 0.5 |  |  | 16 |  |  | 0.3 |  |  | 13 |  |  | 81 |  |
| Interest expense | (113) |  |  | (1.9) |  |  | (192) |  |  | (4.2) |  |  | 79 |  |  | (41) |  |
| Gain on retained interest in Sandisk | 1,714 |  |  | 29.4 |  |  | — |  |  | — |  |  | 1,714 |  |  | n/a |
| Other income (expense), net | (31) |  |  | (0.5) |  |  | (9) |  |  | (0.2) |  |  | (22) |  |  | 244 |  |
| Total interest and other income (expense), net | 1,599 |  |  | 27.4 |  |  | (185) |  |  | (4.0) |  |  | 1,784 |  |  | (964) |  |
| Income before taxes | 3,299 |  |  | 56.5 |  |  | 709 |  |  | 15.3 |  |  | 2,590 |  |  | 365 |  |
| Income tax expense | 275 |  |  | 4.7 |  |  | 90 |  |  | 1.9 |  |  | 185 |  |  | 206 |  |
| Net income from continuing operations | $ | 3,024 |  |  | 51.8 | % |  | $ | 619 |  |  | 13.4 | % |  | $ | 2,405 |  |  | 389 | % |

[0001628280-26-004207:mdna:21]
(1)    Percentages may not total due to rounding.

[0001628280-26-004207:mdna:22]
[same as prior period, unchanged from 0001628280-25-047613:mdna:20]

[0001628280-26-004207:mdna:23]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,673 |  |  | $ | 2,096 |  |  | $ | 5,183 |  |  | $ | 4,005 |  |
| Client | 176 |  |  | 140 |  |  | 322 |  |  | 279 |  |
| Consumer | 168 |  |  | 173 |  |  | 330 |  |  | 337 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |
| Revenue by geography(1) |  |  |  |  |  |  |  |
| Americas | $ | 1,291 |  |  | $ | 1,039 |  |  | $ | 2,391 |  |  | $ | 2,286 |  |
| Asia | 1,117 |  |  | 910 |  |  | 2,292 |  |  | 1,596 |  |
| Europe, Middle East and Africa | 609 |  |  | 460 |  |  | 1,152 |  |  | 739 |  |
| Total revenue | $ | 3,017 |  |  | $ | 2,409 |  |  | $ | 5,835 |  |  | $ | 4,621 |  |

[0001628280-26-004207:mdna:24]
[same as prior period, unchanged from 0001628280-25-047613:mdna:22]

[0001628280-26-004207:mdna:25]
41

[0001628280-26-004207:mdna:26]
[same as prior period, unchanged from 0001628280-25-047613:mdna:23]

[0001628280-26-004207:mdna:27]
Comparison of Three and Six Months Ended January 2, 2026 to Three and Six Months Ended December 27, 2024

[0001628280-26-004207:mdna:28]
Net revenue increased by 25% for the three months ended January 2, 2026 from the comparable period in the prior year, driven by a 22% increase in exabytes sold and a 2% increase in average selling price per exabyte. The increase in exabytes sold was driven by strong demand for our high-capacity enterprise products. The increase in average selling price per exabyte was due to improved pricing on our higher capacity drives. Net revenue increased by 26% for the six months ended January 2, 2026 from the comparable period in the prior year, driven by a 23% increase in exabytes sold and a 3% increase in average selling price per exabyte. The increase in exabytes sold and increase in average selling price per exabyte were attributable to the same factors noted for the three-month period above.

[0001628280-26-004207:mdna:29]
Cloud revenue increased by 28% for the three months ended January 2, 2026 from the comparable period in the prior year, driven by a 24% increase in exabytes sold and a 3% increase in average selling price per exabyte. The increase in exabytes sold was driven by strong demand for our high-capacity enterprise products. The increase in average selling price per exabyte was due to improved pricing on our higher capacity drives. Cloud revenue increased by 29% for the six months ended January 2, 2026 from the comparable period in the prior year, driven by a 25% increase in exabytes sold and a 3% increase in average selling price per exabyte. The increase in exabytes sold and increase in average selling price per exabyte were attributable to the same factors noted for the three-month period above.

[0001628280-26-004207:mdna:30]
Client revenue increased by 26% for the three months ended January 2, 2026 from the comparable period in the prior year, driven by a 17% increase in average selling price per exabyte and a 7% increase in exabytes sold. The increase in average selling price per exabyte was due to a shift in product mix to our higher capacity drives. The increase in exabytes sold was driven by strong demand. Client revenue increased by 15% for the six months ended January 2, 2026 from the comparable period in the prior year, driven by a 18% increase in average selling price per exabyte, partially offset by a 2% decrease in exabytes sold. The increase in average selling price per exabyte was due to a shift in product mix to our higher capacity drives. The decrease in exabytes sold was driven by lower demand in the first three months of the year.

[0001628280-26-004207:mdna:31]
Consumer revenue decreased by 3% for the three months ended January 2, 2026 from the comparable period in the prior year, driven by a 5% decrease in exabytes sold, partially offset by a 3% increase in average selling price per exabyte, both of which reflect variations in product mix and demand. Consumer revenue decreased by 2% for the six months ended January 2, 2026 from the comparable period in the prior year, driven by a 2% decrease in average selling price per exabyte while volume remained relatively flat, which reflects routine variations in product mix and demand.

[0001628280-26-004207:mdna:32]
The mix of net revenue by geography for the three months ended January 2, 2026 was relatively consistent with the comparable period in the prior year. The mix of net revenue by geography for the six months ended January 2, 2026 compared to the comparable period in the prior year reflects higher revenue in the Asia and Europe, Middle East and Africa regions as customers expanded data center capacity in these regions in the first three months of the year.

[0001628280-26-004207:mdna:33]
Our top 10 customers accounted for 76% and 77%, respectively, of our net revenue for the three and six months ended January 2, 2026, compared to 67% and 65%, respectively, of our net revenue for the three and six months ended December 27, 2024. For the three months ended January 2, 2026, three customers accounted for 15%, 14%, and 14%, respectively, of our net revenue, and for the three months ended December 27, 2024, two customers accounted for 18% and 13%, respectively, of our net revenue. For the six months ended January 2, 2026, three customers accounted for 17%, 15%, and 14%, respectively, of our net revenue, and for the six months ended December 27, 2024, two customers accounted for 18% and 11%, respectively, of our net revenue.

[0001628280-26-004207:mdna:34]
[same as prior period, unchanged from 0001628280-25-047613:mdna:31]

[0001628280-26-004207:mdna:35]
Gross profit increased by $473 million for the three months ended January 2, 2026 from the comparable period in the prior year, due to an increased volume of shipments, a lower cost structure on our newer generation products and improved pricing on our higher capacity drives. Gross margin increased by 8 percentage points year over year, primarily due to a lower cost structure on our newer generation products and improved pricing on our higher capacity drives. Gross profit increased by $894 million for the six months ended January 2, 2026 from the comparable period in the prior year and gross margin increased by 8 percentage points year over year, primarily due to the same factors noted for the three-month period above.

[0001628280-26-004207:mdna:36]
[same as prior period, unchanged from 0001628280-25-047613:mdna:33]

[0001628280-26-004207:mdna:37]
Research and development (“R&D”) expense increased by $64 million for the three months ended January 2, 2026 from the comparable period in the prior year. The increase was attributable to higher variable compensation, as a result of our company performance and further investment for innovation, technology and product development. R&D expense increased by $96 million for the six months ended January 2, 2026 from the comparable period in the prior year. The increase was driven by the same factors noted for the three-month period above. In future periods, we expect modest increases in R&D as we continue to innovate and develop higher capacity and performance HDD.

[0001628280-26-004207:mdna:38]
Selling, general and administrative (“SG&A”) expense was relatively flat for the three months ended January 2, 2026 from the comparable period in the prior year, which reflects approximately $30 million of higher variable compensation, as a result of our company performance, offset by general corporate overhead roles in the prior year that have since transferred to Sandisk and were not backfilled after the Separation. SG&A expense decreased by $70 million for the six months ended January 2, 2026 from the comparable period in the prior year. The decrease reflects $37 million of lower compensation and benefits in the first three months of the year, which was driven by certain general corporate overhead roles in the prior year that have since transferred to Sandisk and were not backfilled after the Separation. The decrease also reflects $30 million of lower service fees resulting from reduced marketing activities and legal costs in the first three months of the year.

[0001628280-26-004207:mdna:39]
For information regarding litigation matters, see Part I, Item 1, Note 14, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-004207:mdna:40]
[same as prior period, unchanged from 0001628280-25-047613:mdna:37]

[0001628280-26-004207:mdna:41]
[same as prior period, unchanged from 0001628280-25-047613:mdna:38]

[0001628280-26-004207:mdna:42]
Total interest and other income (expense), changed by $1.15 billion for the three months ended January 2, 2026 from the comparable period in the prior year. The change reflects an unrealized gain of $1.10 billion on our retained interest in Sandisk based on the mark-to-market value as of January 2, 2026, and lower interest expense of $39 million, which reflects the reduction in our debt. Total interest and other income (expense), changed by $1.78 billion for the six months ended January 2, 2026 from the comparable period in the prior year. The change primarily reflects an unrealized gain of $1.71 billion on our retained interest in Sandisk based on the mark-to-market value as of January 2, 2026, and lower interest expense of $79 million, which reflects the reduction in our debt.

[0001628280-26-004207:mdna:43]
[same as prior period, unchanged from 0001628280-25-047613:mdna:40]

[0001628280-26-004207:mdna:44]
Previously, the Tax Cuts and Jobs Act of 2017 (“TCJA”) eliminated the ability to deduct R&D expenditures in the year incurred, requiring capitalization and amortization under Internal Revenue Code Section 174. On July 4, 2025, the One Big Beautiful Bill Act of 2025 (“OBBBA”) was signed into law, which includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with 2026. The legislation also includes favorable modifications to international tax provisions, including changes to the Global Intangible Low-Taxed Income regime and enhancements to the Foreign-Derived Deduction Eligible Income (“FDDEI”) deduction that will become effective for us in 2027.

[0001628280-26-004207:mdna:45]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. Although CAMT became effective for us beginning with 2024, we were not subject to CAMT for 2024 and 2025. We do not expect to be subject to CAMT in 2026 as our annual average AFSI did not exceed $1.0 billion for the preceding three-year period.

[0001628280-26-004207:mdna:46]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”). For 2026, we are subject to GMT in Malaysia, Thailand, and the Philippines.

[0001628280-26-004207:mdna:47]
[same as prior period, unchanged from 0001628280-25-047613:mdna:44]

[0001628280-26-004207:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | ($ in millions) |
| Income before taxes | $ | 1,962 |  | $ | 466 |  | $ | 3,299 |  | $ | 709 |
| Income tax expense | 120 |  | — |  | 275 |  | 90 |
| Effective tax rate | 6% |  | —% |  | 8% |  | 13% |

[0001628280-26-004207:mdna:49]
The primary drivers of the difference between the effective tax rate for the three and six months ended January 2, 2026 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for FDDEI, tax credits, and the gain on the retained interest in Sandisk being tax-free due to the Separation of the Flash business. These resulted in decreases to our effective tax rate below the U.S. Federal statutory rate for the three and six months ended January 2, 2026. Our income tax provision for the three and six months ended January 2, 2026 includes GMT for Malaysia as well as Thailand and the Philippines, countries for which we maintain tax holidays.

[0001628280-26-004207:mdna:50]
The primary drivers of the difference between the effective tax rate for the three and six months ended December 27, 2024 and the U.S. Federal statutory rate of 21% were the relative mix of earnings and losses by jurisdiction, tax credits, and tax holidays in Thailand and the Philippines. In addition, the effective tax rate for the six months ended December 27, 2024 includes the discrete effect of a net decrease of $30 million to the liability for unrecognized tax benefits, which includes interest and offsetting tax benefits, as a result of adjustments to align with U.S. Internal Revenue Service (“IRS”) calculations.

[0001628280-26-004207:mdna:51]
44

[0001628280-26-004207:mdna:52]
[same as prior period, unchanged from 0001628280-25-047613:mdna:49]

[0001628280-26-004207:mdna:53]
[same as prior period, unchanged from 0001628280-25-047613:mdna:50]

[0001628280-26-004207:mdna:54]
|  | Six Months Ended |  |  |
|  | January 2,2026 |  | December 27,2024 |  |  |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,417 |  |  | $ | 437 |  |  |  |
| Investing activities | (173) |  |  | 78 |  |  |  |
| Financing activities | (1,381) |  |  | (103) |  |  |  |
| Effect of exchange rate changes on cash | (2) |  |  | — |  |  |  |
| Net increase (decrease) in cash and cash equivalents | $ | (139) |  |  | $ | 412 |  |  |  |

[0001628280-26-004207:mdna:55]
[same as prior period, unchanged from 0001628280-25-047613:mdna:52]

[0001628280-26-004207:mdna:56]
[same as prior period, unchanged from 0001628280-25-047613:mdna:53]

[0001628280-26-004207:mdna:57]
We believe our cash and cash equivalents and our available 2027 Revolving Credit Facility (as defined below) will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt and equity capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A, Risk Factors, in this Quarterly Report on Form 10-Q and in Part I, Item 1A, Risk Factors, in our 2025 Annual Report on Form 10-K.

[0001628280-26-004207:mdna:58]
A total of $1.35 billion and $0.98 billion of our cash and cash equivalents was held by our foreign subsidiaries as of January 2, 2026 and June 27, 2025, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0001628280-26-004207:mdna:59]
[same as prior period, unchanged from 0001628280-25-047613:mdna:56]

[0001628280-26-004207:mdna:60]
[same as prior period, unchanged from 0001628280-25-047613:mdna:57]

[0001628280-26-004207:mdna:61]
Net cash provided by operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $275 million for the six months ended January 2, 2026, compared to $1.04 billion for the six months ended December 27, 2024. The year over year decrease largely reflects a $232 million improvement in timing and collection of accounts receivable, a $127 million improvement from accrued compensation resulting from amount and timing of payment of variable compensation, and a $906 million improvement in other assets and liabilities driven by the timing of recognition and realization of income taxes receivable. These were partially offset by a $520 million increase in cash used driven by the timing of recognition and payment of income taxes.

[0001628280-26-004207:mdna:62]
[same as prior period, unchanged from 0001628280-25-047613:mdna:59]

[0001628280-26-004207:mdna:63]
Net cash used in investing activities for the six months ended January 2, 2026 primarily consisted of $165 million in capital expenditures. Net cash provided by investing activities for the six months ended December 27, 2024 primarily consisted of $191 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $92 million in net proceeds from activity related to Flash Ventures, partially offset by $208 million in capital expenditures, net of proceeds from disposals of assets.

[0001628280-26-004207:mdna:64]
[same as prior period, unchanged from 0001628280-25-047613:mdna:61]

[0001628280-26-004207:mdna:65]
Net cash used in financing activities for the six months ended January 2, 2026 primarily consisted of $1.17 billion for share repurchases, $87 million for dividends on our common stock and Preferred Shares, $95 million for taxes paid on vested stock awards under employee stock plans, and $63 million for scheduled repayments on our term loan. These uses were partially offset by $32 million of proceeds from the issuance of stock under employee stock plans. Net cash used in financing activities for the six months ended December 27, 2024 primarily consisted of $225 million for repayment of amounts borrowed under the revolving credit facility and scheduled repayments on our term loan and $80 million for taxes paid on vested stock awards under employee stock plans, partially offset by $150 million of proceeds from drawing on the revolving credit facility and $52 million of proceeds from the issuance of stock under employee stock plans.

[0001628280-26-004207:mdna:66]
[same as prior period, unchanged from 0001628280-25-047613:mdna:63]

[0001628280-26-004207:mdna:67]
[same as prior period, unchanged from 0001628280-25-047613:mdna:64]

[0001628280-26-004207:mdna:68]
[same as prior period, unchanged from 0001628280-25-047613:mdna:65]

[0001628280-26-004207:mdna:69]
[same as prior period, unchanged from 0001628280-25-047613:mdna:66]

[0001628280-26-004207:mdna:70]
The following is a summary of our known material cash requirements as of January 2, 2026. In addition, see the discussions further below related to liability for unrecognized tax benefits, litigation matters, cash dividend program, dividend rights with respect to the Preferred Shares, global minimum tax, foreign exchange contracts and indemnifications.

[0001628280-26-004207:mdna:71]
|  | Total |  | 1 Year (Remaining Six Months of 2026) |  | 2-3 Years (2027-2028) |  | 4-5 Years (2029-2030) |  | More than 5 Years (Beyond 2030) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 4,686 |  |  | $ | 2,163 |  |  | $ | 1,523 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 394 |  |  | 95 |  |  | 199 |  |  | 69 |  |  | 31 |  |
| Operating leases | 171 |  |  | 19 |  |  | 64 |  |  | 39 |  |  | 49 |  |
| Purchase obligations and other commitments | 88 |  |  | 32 |  |  | 56 |  |  | — |  |  | — |  |
| Total | $ | 5,339 |  |  | $ | 2,309 |  |  | $ | 1,842 |  |  | $ | 608 |  |  | $ | 580 |  |

[0001628280-26-004207:mdna:72]
[same as prior period, unchanged from 0001628280-25-047613:mdna:69]

[0001628280-26-004207:mdna:73]
[same as prior period, unchanged from 0001628280-25-047613:mdna:70]

[0001628280-26-004207:mdna:74]
As of January 2, 2026, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $607 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in our liability related to unrecognized tax benefits as of January 2, 2026 was $97 million. Of these amounts, approximately $130 million could result in potential cash payments to be made within the next twelve months.

[0001628280-26-004207:mdna:75]
Litigation Matters

[0001628280-26-004207:mdna:76]
For additional information on our litigation matters, see Part I, Item 1, Note 14, Legal Proceedings, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-004207:mdna:77]
[same as prior period, unchanged from 0001628280-25-047613:mdna:74]

[0001628280-26-004207:mdna:78]
On April 29, 2025, our Board of Directors authorized the adoption of a cash dividend program. Under the cash dividend program, holders of our common stock will receive dividends when and as declared by our Board of Directors. During the three months ended January 2, 2026, we paid cash dividends of $0.125 per share of our outstanding common stock, totaling $43 million, plus $1 million paid to holders of our Preferred Shares in accordance with their participation rights. During the six months ended January 2, 2026, we paid aggregate cash dividends of $0.225 per share of our outstanding common stock, totaling $77 million, plus $2 million paid to holders of our Preferred Shares in accordance with their participation rights.

[0001628280-26-004207:mdna:79]
Subsequent to quarter-end, on January 28, 2026, our Board of Directors declared a cash dividend of $0.125 per share of our common stock, which will be paid on March 18, 2026 to our shareholders of record as of the close of business on March 5, 2026.

[0001628280-26-004207:mdna:80]
[same as prior period, unchanged from 0001628280-25-047613:mdna:77]

[0001628280-26-004207:mdna:81]
[same as prior period, unchanged from 0001628280-25-047613:mdna:78]

[0001628280-26-004207:mdna:82]
As of January 2, 2026, 235,000 shares of our Preferred Shares remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in our 2025 Annual Report on Form 10-K and Part I, Item 1, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more information regarding the dividend provisions.

[0001628280-26-004207:mdna:83]
[same as prior period, unchanged from 0001628280-25-047613:mdna:80]

[0001628280-26-004207:mdna:84]
As described in Part I, Item 1, Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, the Company issued $1.60 billion aggregate principal amount of convertible senior notes in November 2023, which bear interest at an annual rate of 3.00% and mature on November 15, 2028 (the “2028 Convertible Notes”). The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028 at a conversion price of approximately $37.74 per share of common stock (as adjusted in accordance with the indenture as a result of the Separation and the payment of dividends on the Company’s common stock). Prior to August 15, 2028, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, we may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at our option, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of our redemption notice.

[0001628280-26-004207:mdna:85]
The sale price conditional conversion feature of the 2028 Convertible Notes was triggered during the calendar quarter ended December 31, 2025 and, accordingly, the holders of the 2028 Convertible Notes have the right to convert the notes during the succeeding calendar quarter ending March 31, 2026. As a result, the 2028 Convertible Notes have been classified in Current portion of long-term debt in the Condensed Consolidated Financial Statements as of January 2, 2026. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes remain convertible in future periods.

[0001628280-26-004207:mdna:86]
In addition to our outstanding debt, as of January 2, 2026, we had $1.25 billion available for borrowing under our revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”), subject to customary conditions under the Loan Agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. The Loan Agreement requires us to comply with a financial leverage ratio covenant. As of January 2, 2026, we were in compliance with the financial covenant. Additional information regarding our indebtedness, including information about availability under our 2027 Revolving Credit Facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in our 2025 Annual Report on Form 10-K and Note 7, Debt, of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001628280-26-004207:mdna:87]
[same as prior period, unchanged from 0001628280-25-047613:mdna:84]

[0001628280-26-004207:mdna:88]
[same as prior period, unchanged from 0001628280-25-047613:mdna:85]

[0001628280-26-004207:mdna:89]
[same as prior period, unchanged from 0001628280-25-047613:mdna:86]

[0001628280-26-004207:mdna:90]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Current assets | $ | 4,281 |  |  | $ | 2,992 |  |
| Non-current assets | 4,478 |  |  | 4,553 |  |
| Net intercompany payables to non-guarantor subsidiaries | (924) |  |  | (1,543) |  |
| Current liabilities | 3,310 |  |  | 3,800 |  |
| Non-current liabilities | 2,822 |  |  | 2,873 |  |

[0001628280-26-004207:mdna:91]
[same as prior period, unchanged from 0001628280-25-047613:mdna:88]

[0001628280-26-004207:mdna:92]
|  | Six Months Ended |  | Year Ended |
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Net sales | $ | 2,457 |  |  | $ | 5,249 |  |
| Gross profit | 973 |  |  | 1,941 |  |
| Operating income | 252 |  |  | 279 |  |
| Net income (loss) | 1,665 |  |  | (320) |  |

[0001628280-26-004207:mdna:93]
[same as prior period, unchanged from 0001628280-25-047613:mdna:90]

[0001628280-26-004207:mdna:94]
|  | Six Months Ended |  | Year Ended |
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Intercompany revenue | $ | 3,499 |  |  | $ | 1,378 |  |
| Net intercompany interest income (expense) | (5) |  |  | 4 |  |
| Intercompany dividend income | 33 |  |  | 2,215 |  |

[0001628280-26-004207:mdna:95]
[same as prior period, unchanged from 0001628280-25-047613:mdna:92]

[0001628280-26-004207:mdna:96]
[same as prior period, unchanged from 0001628280-25-047613:mdna:93]

[0001628280-26-004207:mdna:97]
[same as prior period, unchanged from 0001628280-25-047613:mdna:94]

[0001628280-26-004207:mdna:98]
As of January 2, 2026, we have accrued GMT of $42 million that are not expected to be paid until the second quarter of 2028.

[0001628280-26-004207:mdna:99]
49

[0001628280-26-004207:mdna:100]
[same as prior period, unchanged from 0001628280-25-047613:mdna:96]

[0001628280-26-004207:mdna:101]
[same as prior period, unchanged from 0001628280-25-047613:mdna:97]

[0001628280-26-004207:mdna:102]
[same as prior period, unchanged from 0001628280-25-047613:mdna:98]

[0001628280-26-004207:mdna:103]
[same as prior period, unchanged from 0001628280-25-047613:mdna:99]

[0001628280-26-004207:mdna:104]
[same as prior period, unchanged from 0001628280-25-047613:mdna:100]

[0001628280-26-004207:mdna:105]
[same as prior period, unchanged from 0001628280-25-047613:mdna:101]

[0001628280-26-004207:mdna:106]
[same as prior period, unchanged from 0001628280-25-047613:mdna:102]

[0001628280-26-004207:mdna:107]
[same as prior period, unchanged from 0001628280-25-047613:mdna:103]

[0001628280-26-004207:mdna:108]
We have prepared the accompanying unaudited Condensed Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Condensed Consolidated Financial Statements may be material.

[0001628280-26-004207:mdna:109]
[same as prior period, unchanged from 0001628280-25-047613:mdna:105]
