# WDC 10-Q controls and the auditor's report


## item_4_controls

[0001628280-26-004207:item_4_controls:1]
Item 4.    Controls and Procedures

[0001628280-26-004207:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-26-004207:item_4_controls:3]
As required by Rule 13a-15(b) promulgated by the Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Quarterly Report on Form 10-Q, our disclosure controls and procedures were effective.

[0001628280-26-004207:item_4_controls:4]
Changes in Internal Controls over Financial Reporting

[0001628280-26-004207:item_4_controls:5]
During the quarter ended January 2, 2026, we implemented new information technology systems supporting our revenue-related processes and made corresponding changes in our internal control over financial reporting. The implementation was not made in response to any deficiency in our internal controls. There were no additional changes in our internal control over financial reporting during the quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-26-004207:item_4_controls:6]
51
