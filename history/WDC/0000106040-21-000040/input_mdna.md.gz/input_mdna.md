# WDC MD&A — 0000106040-21-000040


## mdna

[0000106040-21-000040:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-21-000040:mdna:2]
Our Company

[0000106040-21-000040:mdna:3]
We are a leading developer, manufacturer and provider of data storage devices and solutions that address the evolving needs of the IT industry and the infrastructure that enables the proliferation of data in virtually every other industry. We create environments for data to thrive. We drive the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, our industry-leading solutions deliver the possibilities of data.

[0000106040-21-000040:mdna:4]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2021 and 2019, which ended on July 2, 2021 and June 28, 2019, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-21-000040:mdna:5]
Key Developments

[0000106040-21-000040:mdna:6]
Business Structure

[0000106040-21-000040:mdna:7]
Late in the first quarter of fiscal 2021, we announced a decision to reorganize our business by forming two separate product business units: flash-based products and hard disk drives (“HDD”). The new structure is intended to provide each business unit with focus and responsibility for identifying current and future customer requirements while driving the strategy, roadmap, pricing and overall profitability for their respective product areas. In the second fiscal quarter, to align with the new operating model and business structure, we began making management organizational changes and are implementing new reporting modules and processes to provide discrete information to manage the business. We are evaluating the impact of these changes on our discussion and analysis of our financial condition and results of operations and expect to modify our disclosures to align with this structure when the implementations and assessments are completed, which is expected to be in the first quarter of fiscal 2022.

[0000106040-21-000040:mdna:8]
COVID-19 Pandemic and Operational Update

[0000106040-21-000040:mdna:9]
As a result of the ongoing COVID-19 pandemic, governments and other authorities around the world, including federal, state and local authorities in the United States, have from time-to-time imposed measures intended to reduce its spread, including restrictions on freedom of movement and business operations such as travel bans, border closings, business limitations and closures (subject to exceptions for essential operations and businesses), quarantines and shelter-in-place orders. Although some of these governmental restrictions have since been lifted or scaled back, a resurgence of COVID-19 infections could result in the re-imposition of certain restrictions in efforts to reduce further spread of COVID-19. We have taken actions to protect the health and safety of our employees while continuing to serve our global customers as an essential business. We have implemented and maintained more thorough sanitation practices as outlined by health organizations and supported vaccination efforts.  As we begin to phase in a return to site for more employees, we are monitoring and adopting practices recommended by health organizations to ensure the continued safety of our employees and business partners. In addition, the responses to COVID-19 taken by others in the supply chain have increased the costs of their services which have in turn impacted our operations. As a result, we have incurred charges of approximately $127 million primarily related to higher logistics during the year ended July 2, 2021, which were recorded in cost of revenue.

[0000106040-21-000040:mdna:10]
As an essential business, we continue to provide products and solutions that enable the proliferation of data and facilitate the sharing of information remotely, which has become more critical as much of the world is interacting from areas of self-isolation. Generally, our revenues have remained solid during the pandemic, supported by continued work-from-home, distance learning, and at-home entertainment demand. However, the COVID-19 environment remains dynamic and we cannot predict the duration of the pandemic and how demand may change as it continues to develop.

[0000106040-21-000040:mdna:11]
32

[0000106040-21-000040:mdna:12]
We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and stakeholders, or as required by federal, state, or local authorities. See “The COVID-19 pandemic could negatively affect our business” in Part I, Item 1A, Risk Factors, of this Annual Report on Form 10-K for more information regarding the risks we face as a result of the COVID-19 pandemic.

[0000106040-21-000040:mdna:13]
33

[0000106040-21-000040:mdna:14]
Results of Operations

[0000106040-21-000040:mdna:15]
Summary Comparison of 2021, 2020 and 2019

[0000106040-21-000040:mdna:16]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-21-000040:mdna:17]
|  |  |  |  |  |  |  |  |  | 2021 |  | 2020 |  |  |  | 2019 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 16,922 |  |  | 100.0 | % |  | $ | 16,736 |  |  | 100.0 | % |  |  |  | $ | 16,569 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 12,401 |  |  | 73.3 |  |  | 12,955 |  |  | 77.4 |  |  |  |  | 12,817 |  |  | 77.4 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 4,521 |  |  | 26.7 |  |  | 3,781 |  |  | 22.6 |  |  |  |  | 3,752 |  |  | 22.6 |  |
| Operating Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 2,243 |  |  | 13.3 |  |  | 2,261 |  |  | 13.5 |  |  |  |  | 2,182 |  |  | 13.2 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 1,105 |  |  | 6.5 |  |  | 1,153 |  |  | 6.9 |  |  |  |  | 1,317 |  |  | 7.9 |  |
| Employee termination, asset impairment, and other charges |  |  |  |  |  |  |  |  |  |  |  |  | (47) |  |  | (0.3) |  |  | 32 |  |  | 0.2 |  |  |  |  | 166 |  |  | 1.0 |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 3,301 |  |  | 19.5 |  |  | 3,446 |  |  | 20.6 |  |  |  |  | 3,665 |  |  | 22.1 |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  | 1,220 |  |  | 7.2 |  |  | 335 |  |  | 2.0 |  |  |  |  | 87 |  |  | 0.5 |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 7 |  |  | — |  |  | 28 |  |  | 0.2 |  |  |  |  | 57 |  |  | 0.3 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (326) |  |  | (1.9) |  |  | (413) |  |  | (2.5) |  |  |  |  | (469) |  |  | (2.8) |  |
| Other income, net |  |  |  |  |  |  |  |  |  |  |  |  | 26 |  |  | 0.2 |  |  | 4 |  |  | — |  |  |  |  | 38 |  |  | 0.2 |  |
| Total interest and other expense, net |  |  |  |  |  |  |  |  |  |  |  |  | (293) |  |  | (1.7) |  |  | (381) |  |  | (2.3) |  |  |  |  | (374) |  |  | (2.3) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | 927 |  |  | 5.5 |  |  | (46) |  |  | (0.3) |  |  |  |  | (287) |  |  | (1.7) |  |
| Income tax expense |  |  |  |  |  |  |  |  |  |  |  |  | 106 |  |  | 0.6 |  |  | 204 |  |  | 1.2 |  |  |  |  | 467 |  |  | 2.8 |  |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | $ | 821 |  |  | 4.9 | % |  | $ | (250) |  |  | (1.5) | % |  |  |  | $ | (754) |  |  | (4.6) | % |

[0000106040-21-000040:mdna:18]
(1)    Percentages may not total due to rounding.

[0000106040-21-000040:mdna:19]
The following table sets forth, for the periods presented, summary information regarding our revenue:

[0000106040-21-000040:mdna:20]
|  |  |  | Year Ended |
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD |  |  |  |  | $ | 8,216 |  |  | $ | 8,967 |  |  | $ | 8,746 |  |
| Flash-based |  |  |  |  | 8,706 |  |  | 7,769 |  |  | 7,823 |  |
| Total Revenue |  |  |  |  | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices |  |  |  |  | $ | 8,255 |  |  | $ | 7,160 |  |  | $ | 8,095 |  |
| Data Center Devices & Solutions |  |  |  |  | 4,950 |  |  | 6,228 |  |  | 5,038 |  |
| Client Solutions |  |  |  |  | 3,717 |  |  | 3,348 |  |  | 3,436 |  |
| Total Revenue |  |  |  |  | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |
| Revenue by Geography |  |  |  |  |  |  |  |  |  |
| Americas |  |  |  |  | $ | 4,406 |  |  | $ | 5,444 |  |  | $ | 4,361 |  |
| Europe, Middle East and Africa |  |  |  |  | 3,061 |  |  | 2,926 |  |  | 3,109 |  |
| Asia |  |  |  |  | 9,455 |  |  | 8,366 |  |  | 9,099 |  |
| Total Revenue |  |  |  |  | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |
| Exabytes Shipped |  |  |  |  | 541 |  |  | 518 |  |  | 383 |  |

[0000106040-21-000040:mdna:21]
Net Revenue

[0000106040-21-000040:mdna:22]
Net revenue increased 1% in 2021 compared to 2020, which reflects approximately 13 percentage points increase in revenue related to higher exabyte volume of flash sold, largely offset by lower average selling price per gigabyte.

[0000106040-21-000040:mdna:23]
Client Devices revenue increased 15% year over year, reflecting a 22% increase from a higher volume of flash products sold. This increase in flash volume was driven by continued strength in demand for notebook and Chromebooks, gaming, smart home devices, automotive and industrial applications. This increase was partially offset by lower average selling price per gigabyte, primarily in flash.

[0000106040-21-000040:mdna:24]
Data Center Devices and Solutions revenue decreased 20% year over year. Lower exabytes of storage sold for HDD and flash each contributed approximately 7 percentage points to the revenue decline, while lower average selling price per gigabyte, primarily in HDD products, contributed another 6 percentage points to the decline. Year-over-year volume was negatively impacted by cloud digestion and China shipment restrictions, and delays in product qualifications with certain customers earlier in the year. The impacts of cloud digestion have abated and we have now completed qualifications with all our cloud titan customers. In flash, we are beginning to see growth with our second generation, NVMe enterprise SSD at several cloud titans and are ramping production more broadly. In HDD, we are experiencing a resurgence of demand driven by the successful ramp of our 18-terabyte energy-assisted hard drive, growing cloud demand, a recovery in enterprise spending, and to a lesser extent, cryptocurrency, driven by Chia. We believe the strong demand from our cloud customers and beginning of a recovery in the enterprise demand continues to positively impact results.

[0000106040-21-000040:mdna:25]
Client Solutions revenue increased 11% year over year, which reflects an increase of approximately 16 percentage points due to exabyte growth, split evenly between HDD and Flash products, which was partially offset by lower average selling price per gigabyte. Client Solutions remains a high performing end market, reflecting our brand recognition, broad product portfolio and extensive distribution channels to markets.

[0000106040-21-000040:mdna:26]
The changes in net revenue by geography reflect an increase in Asia due to our increased sales of mobility products to manufacturers in the Asia region, and a decrease in Americas driven by lower sales of capacity enterprise products.

[0000106040-21-000040:mdna:27]
For 2021, 2020 and 2019, our top 10 customers accounted for 39%, 42% and 45%, respectively, of our net revenue. For each of 2021, 2020 and 2019, no single customer accounted for 10% or more of our net revenue.

[0000106040-21-000040:mdna:28]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2021, 2020 and 2019, these programs represented 19%, 16% and 15%, respectively, of gross revenues, and adjustments to revenue due to changes in accruals for these programs have generally averaged less than 1% of gross revenue over the last three fiscal years. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-21-000040:mdna:29]
Gross Profit and Gross Margin

[0000106040-21-000040:mdna:30]
Gross profit increased $740 million, or 19.6%, in 2021 compared to 2020, which reflected a $279 million decrease in charges for amortization expense on acquired intangible assets, $143 million improvement related to power outage charges of $68 million incurred in 2020 combined with a $75 million recovery in the current year as well as incremental profit from the increase in volume. As a percent of revenue, gross margin increased by 4.1 percentage points over the prior year of which 2.5 percentage points reflected the impact of the change in power outage charges and lower charges for amortization expense. In addition, as we ramped production on new products, cost reduction also contributed to the increase in gross margin.

[0000106040-21-000040:mdna:31]
Operating Expenses

[0000106040-21-000040:mdna:32]
Research and development (“R&D”) expense decreased $18 million in 2021 compared to 2020. The decrease was driven by lower facility costs of approximately $50 million due to restructuring and cost initiatives and approximately $20 million of lower travel related expenses due to COVID-19 restrictions, partially offset by higher employee compensation cost for additional headcount as we invested in research and development, and higher variable compensation cost due to improved earnings.

[0000106040-21-000040:mdna:33]
Selling, general and administrative (“SG&A”) expense decreased $48 million in 2021 compared to 2020. The decline was primarily driven by a $50 million reduction in expenses related to travel, marketing and outside services as a result of COVID-19 restrictions.

[0000106040-21-000040:mdna:34]
The gains recognized in Employee termination, asset impairment and other charges compared to the losses in the prior year primarily reflect gains on the disposal of assets associated with our business realignment activities. For additional information regarding employee termination, asset impairment and other charges, see Part II, Item 8, Note 16, Employee Termination, Asset Impairment and Other Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:35]
Interest and Other Income (Expense)

[0000106040-21-000040:mdna:36]
The decreases in total interest and other expense, net in 2021 compared to 2020 primarily reflects a decrease in interest expense resulting from lower index rates and the pay-down of principal on our debt during 2021.

[0000106040-21-000040:mdna:37]
Income Tax Expense

[0000106040-21-000040:mdna:38]
The Tax Cuts and Jobs Act (the “2017 Act”) includes a broad range of tax reform proposals affecting businesses. We completed our accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the Internal Revenue Service (“IRS”) have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and we anticipate the issuance of additional regulatory and interpretive guidance. We applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing our accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to our estimates in future periods.

[0000106040-21-000040:mdna:39]
The following table sets forth income tax information from our Consolidated Statements of Operations by dollar and effective tax rate:

[0000106040-21-000040:mdna:40]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | 927 |  |  | $ | (46) |  |  | $ | (287) |  |
| Income tax expense |  |  |  |  | 106 |  |  | 204 |  |  | 467 |  |
| Effective tax rate |  |  |  |  | 11 | % |  | (443) | % |  | (163) | % |

[0000106040-21-000040:mdna:41]
The primary drivers of the difference between the effective tax rate for 2021 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2031.

[0000106040-21-000040:mdna:42]
The primary drivers of the difference between the effective tax rate for 2020 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits and tax holidays in Malaysia, Philippines and Thailand that will expire at various dates during fiscal years 2021 through 2030. In addition, the effective tax rate for 2020 includes the discrete effect of a de-recognition of $31 million for certain deferred tax assets associated with creditable foreign withholding taxes due to the issuance of final regulatory guidance. The regulatory guidance does not preclude us from potentially claiming these creditable taxes as a period benefit when paid.

[0000106040-21-000040:mdna:43]
Our future effective tax rate is subject to future regulatory developments and changes in the mix of our U.S. earnings compared to foreign earnings. Our total tax expense in future fiscal years may also vary as a result of discrete items such as excess tax benefits or deficiencies.

[0000106040-21-000040:mdna:44]
For additional information regarding Income tax expense (benefit), see Part II, Item 8, Note 14, Income Tax Expense, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:45]
A discussion of our results of operations for 2019, including a comparison of such results of operations to 2020, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, included in our Annual Report on Form 10-K for the year ended July 3, 2020 filed with the Securities and Exchange Commission on August 28, 2020.

[0000106040-21-000040:mdna:46]
Liquidity and Capital Resources

[0000106040-21-000040:mdna:47]
The following table summarizes our statements of cash flows:

[0000106040-21-000040:mdna:48]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,898 |  |  | $ | 824 |  |  | $ | 1,547 |  |
| Investing activities | (765) |  |  | 278 |  |  | (1,272) |  |
| Financing activities | (817) |  |  | (1,508) |  |  | (1,829) |  |
| Effect of exchange rate changes on cash | 6 |  |  | (1) |  |  | 4 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 322 |  |  | $ | (407) |  |  | $ | (1,550) |  |

[0000106040-21-000040:mdna:49]
We believe our cash, cash equivalents and cash generated from operations as well as our available credit facilities will be sufficient to meet our working capital, debt and capital expenditure needs for at least the next twelve months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:50]
During fiscal 2022, we expect expenditures for property, plant and equipment for our company plus our portion of the capital expenditures by our Flash Ventures joint venture with Kioxia for its operations to aggregate to $3.1 billion. After consideration of the Flash Ventures’ lease financing of its capital expenditures and net operating cash flow, we expect net cash used for our purchases of property, plant and equipment and net activity in notes receivable relating to Flash Ventures to be a cash outflow of approximately $2.0 billion during fiscal 2022. The total expected cash to be used could vary depending on the timing and completion of various capital projects and the availability, timing and terms of related financing.

[0000106040-21-000040:mdna:51]
A total of $1.99 billion and $2.12 billion of our Cash and cash equivalents was held outside of the U.S. as of July 2, 2021 and July 3, 2020, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-21-000040:mdna:52]
Operating Activities

[0000106040-21-000040:mdna:53]
Cash flow from operating activities primarily consists of net income, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. This represents our principal source of cash. Net cash used for changes in operating assets and liabilities was $175 million for 2021, as compared to $757 million for 2020. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. At the end of the respective fourth quarters, the cash conversion cycles were as follows:

[0000106040-21-000040:mdna:54]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in days) |
| Days sales outstanding | 42 |  |  | 50 |  |  | 30 |  |
| Days in inventory | 98 |  |  | 87 |  |  | 94 |  |
| Days payables outstanding | (63) |  |  | (67) |  |  | (54) |  |
| Cash conversion cycle | 77 |  |  | 70 |  |  | 70 |  |

[0000106040-21-000040:mdna:55]
Changes in days sales outstanding (“DSO”) are generally due to the linearity of timing of shipments. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make the payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0000106040-21-000040:mdna:56]
38

[0000106040-21-000040:mdna:57]
For 2021, DSO decreased by 8 days over the prior year, reflecting more linearity in the timing of shipments and more favorable customer terms, partially offset by an increase of approximately 2 days for lower factoring of receivables. We have seen no significant deterioration in our receivables as a result of COVID-19. DIO increased by 11 days over the prior year, reflecting higher stocking levels of HDD inventory to serve anticipated demand growth and better output from Flash Ventures as production ramped up at the new fabrication sites. DPO decreased by 4 days over the prior year, primarily reflecting resumptions of flash production volumes and ramp up of production of new drives as well as routine variations in the timing of purchases and payments during the period.

[0000106040-21-000040:mdna:58]
Investing Activities

[0000106040-21-000040:mdna:59]
Net cash used in investing activities in 2021 primarily consisted of $1.1 billion in capital expenditures, partially offset by a $231 million net decrease in notes receivable issuances to Flash Ventures and proceeds of $143 million from the disposal of property, plant and equipment, primarily related to our business realignment activities. Net cash provided by investing activities in 2020 primarily consisted of a $931 million net decrease in notes receivable issuances to Flash Ventures, partially offset by $647 million of capital expenditures.

[0000106040-21-000040:mdna:60]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we invest directly in U.S. Treasury securities, U.S. and international government agency securities, certificates of deposit, asset backed securities and corporate and municipal notes and bonds.

[0000106040-21-000040:mdna:61]
Financing Activities

[0000106040-21-000040:mdna:62]
During 2021, net cash used in financing activities primarily consisted of $886 million for repayment of debt, which included $600 million in voluntary prepayments on our Term Loan B-4, and $56 million for taxes paid on vested stock awards under employee stock plans, partially offset by $134 million of cash from the issuance of stock under our employee stock plans. Net cash used in financing activities in 2020 primarily consisted of $982 million for the repayment of debt, which included $725 million in voluntary prepayments on our Term Loan B-4, $595 million to pay dividends on our common stock, and $72 million for taxes paid with respect to vested stock awards under our employee stock plans, partially offset by $141 million of cash from the issuance of stock under our employee stock plans. On July 19, 2021, we made an incremental voluntary prepayment of $150 million on our Term Loan B-4.

[0000106040-21-000040:mdna:63]
A discussion of our cash flows for the year ended June 28, 2019 is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended July 3, 2020 filed with the Securities and Exchange Commission on August 28, 2020.

[0000106040-21-000040:mdna:64]
Off-Balance Sheet Arrangements

[0000106040-21-000040:mdna:65]
Other than the commitments related to Flash Ventures incurred in the normal course of business and certain indemnification provisions (see “Short and Long-term Liquidity-Indemnifications” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures and our joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:66]
Short and Long-term Liquidity

[0000106040-21-000040:mdna:67]
Contractual Obligations and Commitments

[0000106040-21-000040:mdna:68]
The following is a summary of our known contractual cash obligations and commercial commitments as of July 2, 2021:

[0000106040-21-000040:mdna:69]
|  | Total |  | 1 Year (2022) |  | 2-3 Years (2023-2024) |  | 4-5 Years (2025-2026) |  | More than 5 Years (Beyond 2026) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 8,825 |  |  | $ | 251 |  |  | $ | 6,274 |  |  | $ | 2,300 |  |  | $ | — |  |
| Interest on debt | 833 |  |  | 269 |  |  | 345 |  |  | 219 |  |  | — |  |
| Flash Ventures related commitments(2) | 5,952 |  |  | 2,970 |  |  | 2,046 |  |  | 830 |  |  | 106 |  |
| Operating leases | 284 |  |  | 40 |  |  | 67 |  |  | 61 |  |  | 116 |  |
| Purchase obligations and other commitments | 3,716 |  |  | 2,541 |  |  | 837 |  |  | 168 |  |  | 170 |  |
| Mandatory Deemed Repatriation Tax | 925 |  |  | 106 |  |  | 283 |  |  | 536 |  |  | — |  |
| Total | $ | 20,535 |  |  | $ | 6,177 |  |  | $ | 9,852 |  |  | $ | 4,114 |  |  | $ | 392 |  |

[0000106040-21-000040:mdna:70]
(1)Principal portion of debt, excluding discounts and issuance costs.

[0000106040-21-000040:mdna:71]
(2)Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0000106040-21-000040:mdna:72]
Debt

[0000106040-21-000040:mdna:73]
In addition to our existing debt, we have $2.25 billion available under our revolving credit facility, subject to customary conditions under the credit agreement. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 7, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K. The credit agreement governing our revolving credit facility and our term loan A-1 due 2023 requires us to comply with certain financial covenants, consisting of a leverage ratio and an interest coverage ratio. As of July 2, 2021, we were in compliance with these financial covenants.

[0000106040-21-000040:mdna:74]
Flash Ventures

[0000106040-21-000040:mdna:75]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which we guarantee half or all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of July 2, 2021, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0000106040-21-000040:mdna:76]
Purchase Obligations and Other Commitments

[0000106040-21-000040:mdna:77]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations” in the table above.

[0000106040-21-000040:mdna:78]
40

[0000106040-21-000040:mdna:79]
Mandatory Deemed Repatriation Tax

[0000106040-21-000040:mdna:80]
The following is a summary of our estimated mandatory deemed repatriation tax obligations under the 2017 Act that are payable in the following fiscal years (in millions):

[0000106040-21-000040:mdna:81]
|  |  | July 2,2021 |
| 2022 |  | $ | 106 |  |
| 2023 |  | 104 |  |
| 2024 |  | 179 |  |
| 2025 |  | 238 |  |
| 2026 |  | 298 |  |
| Total |  | $ | 925 |  |

[0000106040-21-000040:mdna:82]
For additional information regarding our estimate of the total tax liability for the mandatory deemed repatriation tax, see Part II, Item 8, Note 13, Income Tax Expense, of the Notes to Consolidated Financial Statements included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2019.

[0000106040-21-000040:mdna:83]
Unrecognized Tax Benefits

[0000106040-21-000040:mdna:84]
As of July 2, 2021, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $748 million. Accrued interest and penalties related to unrecognized tax benefits as of July 2, 2021 was approximately $138 million. Of these amounts, approximately $750 million could result in potential cash payments. We are not able to provide a reasonable estimate of the timing of future tax payments related to these obligations.

[0000106040-21-000040:mdna:85]
Interest Rate Swap

[0000106040-21-000040:mdna:86]
We have generally held a balance of fixed and variable rate debt. At July 2, 2021, we had $5.43 billion of variable rate debt, comprising 61% of the par value of our debt. To balance the portfolio and moderate our exposure to fluctuations in interest rates underlying our variable debt, we entered into pay-fixed interest rate swaps on $2.00 billion notional amount, which effectively converts a portion of our term loan to fixed rates through February 2023. After giving effect to the $2.00 billion of interest rate swaps, we effectively had $3.43 billion of Long-term debt subject to variations in interest rates and a one percent increase in the variable rate of interest would increase annual interest expense by $34 million.

[0000106040-21-000040:mdna:87]
Foreign Exchange Contracts

[0000106040-21-000040:mdna:88]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 8, Note 6, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:89]
Indemnifications

[0000106040-21-000040:mdna:90]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance or from IP infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-21-000040:mdna:91]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-21-000040:mdna:92]
Stock Repurchase Program

[0000106040-21-000040:mdna:93]
Our Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.00 billion of our common stock, which authorization is effective through July 25, 2023. For the year ended July 2, 2021, we did not make any stock repurchases and have not repurchased any shares of our common stock pursuant to our stock repurchase program since the first quarter of fiscal 2019. Although we will reevaluate the repurchasing of our common stock when appropriate, there can be no assurance if, when or at what level we may resume such activity. The remaining amount available to be repurchased under our current stock repurchase program as of July 2, 2021 was $4.50 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-21-000040:mdna:94]
Cash Dividend

[0000106040-21-000040:mdna:95]
We issued a quarterly cash dividend from the first quarter of fiscal 2013 up to the third quarter of fiscal 2020. In April 2020, we suspended our dividend to reinvest in the business and to support our ongoing deleveraging efforts. We will reevaluate our dividend policy as our leverage ratio improves.

[0000106040-21-000040:mdna:96]
Recent Accounting Pronouncements

[0000106040-21-000040:mdna:97]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-21-000040:mdna:98]
Critical Accounting Policies and Estimates

[0000106040-21-000040:mdna:99]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (U.S. GAAP). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0000106040-21-000040:mdna:100]
Revenue

[0000106040-21-000040:mdna:101]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0000106040-21-000040:mdna:102]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0000106040-21-000040:mdna:103]
Marketing development program costs are typically recorded as a reduction of the transaction price and, therefore, of revenue. We net sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-21-000040:mdna:104]
Inventories

[0000106040-21-000040:mdna:105]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We record inventory write-downs for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-21-000040:mdna:106]
42

[0000106040-21-000040:mdna:107]
We evaluate inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduce inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of our products, which may require a write down of inventory that could materially affect operating results.

[0000106040-21-000040:mdna:108]
Income Taxes

[0000106040-21-000040:mdna:109]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-21-000040:mdna:110]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-21-000040:mdna:111]
Goodwill and Other Long-Lived Assets

[0000106040-21-000040:mdna:112]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. We perform our annual impairment test as of the first day of our fiscal fourth quarter. We use qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If we conclude from the qualitative assessment that goodwill is more likely than not impaired, we are required to perform a quantitative approach to determine the amount of impairment. We are required to use judgment when applying the goodwill impairment test, including the identification of one or more reporting units. If we had more than one reporting unit, judgment would also be required in the assignment of assets and liabilities to reporting units, assignment of goodwill to reporting units and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of each reporting unit may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect our assessment of the fair value and goodwill impairment for each reporting unit. If our stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect our results of operations.

[0000106040-21-000040:mdna:113]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow.
