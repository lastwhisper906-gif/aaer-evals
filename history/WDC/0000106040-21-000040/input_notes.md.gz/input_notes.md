# WDC notes — 0000106040-21-000040


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000106040-21-000040:notes:1]
Part III incorporates by reference certain information from the registrant’s definitive proxy statement (the “Proxy Statement”) for the 2021 Annual Meeting of Stockholders, which will be filed with the Securities and Exchange Commission within 120 days after the end of the 2021 fiscal year. Except with respect to information specifically incorporated by reference in this Form 10-K, the Proxy Statement is not deemed to be filed as part hereof.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-21-000040:notes:2]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or “the Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions that address the evolving needs of the information technology (“IT”) industry and the infrastructure that enables the proliferation of data in virtually every other industry. The Company creates environments for data to thrive. The Company is driving the innovation needed to help customers capture, preserve, access and transform an ever-increasing diversity of data. Everywhere data lives, from advanced data centers to mobile sensors to personal devices, the Company’s industry-leading solutions deliver the possibilities of data.

[0000106040-21-000040:notes:3]
The Company’s broad portfolio of technology and products address the following key end markets: Client Devices; Data Center Devices and Solutions; and Client Solutions. The Company also generates license and royalty revenue from its extensive intellectual property (“IP”) portfolio, which is included in each of these three end market categories.

[0000106040-21-000040:notes:4]
Basis of Presentation

[0000106040-21-000040:notes:5]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-21-000040:notes:6]
Fiscal Year

[0000106040-21-000040:notes:7]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2021 and 2019, which ended on July 2, 2021 and June 28, 2019, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks, with the first quarter consisting of 14 weeks and the remaining quarters consisting of 13 weeks each.

[0000106040-21-000040:notes:8]
Basis of Consolidation

[0000106040-21-000040:notes:9]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in accumulated other comprehensive income, a component of shareholders’ equity.

[0000106040-21-000040:notes:10]
Use of Estimates

[0000106040-21-000040:notes:11]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of the ongoing COVID-19 pandemic. However, actual results could differ materially from these estimates and be significantly affected by the severity and duration of the pandemic, the extent of actions to contain or treat COVID-19, the timing, distribution, efficacy and public acceptance of vaccines around the world, any possible resurgence of COVID-19, including the emergence of more contagious or vaccine-resistant variants and how quickly and to what extent normal economic and operating activity can resume.

[0000106040-21-000040:notes:12]
Cash Equivalents

[0000106040-21-000040:notes:13]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.

[0000106040-21-000040:notes:14]
Equity Investments

[0000106040-21-000040:notes:15]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income, net, in the Consolidated Statements of Operations.

[0000106040-21-000040:notes:16]
If the Company’s ownership interest is less than 20% and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee, the Company accounts for these investments at fair value, or if these equity securities do not have a readily determinable fair value, these securities are measured and recorded using the measurement alternative under Accounting Standards Update (“ASU”) No. 2016-01, “Financial Instruments — Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities,” which is cost minus impairment, if any, plus or minus changes resulting from observable price changes. Previously, these investments were accounted for under the cost method of accounting. These investments are recorded within Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-21-000040:notes:17]
Variable Interest Entities

[0000106040-21-000040:notes:18]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. The Company does not consolidate any cost method investment or equity method investment entities.

[0000106040-21-000040:notes:19]
Fair Value of Financial Instruments

[0000106040-21-000040:notes:20]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-21-000040:notes:21]
Inventories

[0000106040-21-000040:notes:22]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-21-000040:notes:23]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write down of inventory that could materially affect operating results.

[0000106040-21-000040:notes:24]
Property, Plant and Equipment

[0000106040-21-000040:notes:25]
Property and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings and improvements are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures, are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-21-000040:notes:26]
Business Combinations

[0000106040-21-000040:notes:27]
The application of acquisition accounting to a business combination requires that the Company identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date using a combination of valuation techniques, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the excess purchase price are based upon preliminary estimates and assumptions and subject to revision when the Company receives final information, including appraisals and other analyses. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. The Company will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0000106040-21-000040:notes:28]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. The Company recognizes the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of technology, customer relationships, and trade name and trademarks acquired in business combinations and in-process research and development (“IPR&D”). The Company’s assessment of IPR&D also includes consideration of the risk of the projects not achieving technological feasibility.

[0000106040-21-000040:notes:29]
Goodwill and Other Long-Lived Assets

[0000106040-21-000040:notes:30]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fiscal fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company’s assessment resulted in no impairment of goodwill in 2021, 2020, or 2019.

[0000106040-21-000040:notes:31]
The Company is required to use judgment when applying the goodwill impairment test, including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-21-000040:notes:32]
IPR&D is an intangible asset accounted as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets.

[0000106040-21-000040:notes:33]
Other long-lived intangible assets are amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable. If impairment is indicated, the impairment is measured as the amount by which the carrying amount of the assets exceeds the fair value of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow. See Note 4, Supplemental Financial Statement Data, for additional disclosures related to the Company’s other intangible assets.

[0000106040-21-000040:notes:34]
Revenue and Accounts Receivable

[0000106040-21-000040:notes:35]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which superseded the requirements in Accounting Standards Codification (“ASC”) 605 “Revenue Recognition” (Topic 605)”. Topic 606 outlines a comprehensive five-step revenue recognition model based on the principle that an entity should recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. Topic 606 also requires more detailed disclosures to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company adopted Topic 606 effective June 30, 2018, using the modified retrospective method to all contracts that were not completed contracts as of the beginning of the fiscal year. The cumulative effect of adopting Topic 606 was a post-tax increase to the opening retained earnings of $56 million as of June 30, 2018, which was primarily related to the Company’s license and royalty revenue arrangements. These arrangements had no remaining performance obligations but were previously recognized under Topic 605 when they were reported to the Company by its licensees, which was generally one quarter in arrears from the licensees’ sales of the licensed products. Adoption of the standard did not have a material impact on the Company’s financial position, results of operations, and cash flows.

[0000106040-21-000040:notes:36]
The Company offers a broad range of data storage products that include Client Devices, Data Center Devices and Solutions, and Client Solutions. Client Devices consist of hard disk drives (“HDDs”) and solid state drives (“SSDs”) for computing devices; flash-based embedded storage products; and flash-based memory wafers. Data Center Devices and Solutions consist of high-capacity enterprise HDDs and high-performance enterprise SSDs, data center software and system solutions. Client Solutions consist of HDDs and SSDs embedded into external storage products and removable flash-based products. The Company also generates license and royalty revenue related to its IP patent licenses.

[0000106040-21-000040:notes:37]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and that uncertainties are resolved in a fairly short period of time.

[0000106040-21-000040:notes:38]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes post contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right to use or right to access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period using the time lapse method. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0000106040-21-000040:notes:39]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-21-000040:notes:40]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics.

[0000106040-21-000040:notes:41]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed upon sales incentive programs. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0000106040-21-000040:notes:42]
Marketing development program costs are typically recorded as a reduction of the transaction price and, therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-21-000040:notes:43]
An immaterial amount of the Company’s revenue arrangements include contracts that contain more than one performance obligation, which are typically comprised of tangible products, software and support services for multiple distinct licenses. For these contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. The Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices. Where a separate standalone selling price is not available, the transaction price is based on the Company’s best estimate of the standalone selling price. The Company uses one or a combination of more than one of the following methods to estimate the standalone selling price: the adjusted market assessment approach, the expected cost plus a margin approach, or another suitable method based on the facts and circumstances.

[0000106040-21-000040:notes:44]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency or other collection issues. In addition, the Company routinely analyzes the various receivable aging categories to establish reserves based on a combination of past due receivables and expected future losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss trajectory changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-21-000040:notes:45]
Warranty

[0000106040-21-000040:notes:46]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0000106040-21-000040:notes:47]
Litigation and Other Contingencies

[0000106040-21-000040:notes:48]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 17, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-21-000040:notes:49]
Advertising Expense

[0000106040-21-000040:notes:50]
Advertising costs are expensed as incurred and amounted to $84 million, $93 million and $107 million in 2021, 2020 and 2019, respectively. These expenses are included in Selling, general and administrative in the Consolidated Statements of Operations.

[0000106040-21-000040:notes:51]
Research and Development Expense

[0000106040-21-000040:notes:52]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-21-000040:notes:53]
Income Taxes

[0000106040-21-000040:notes:54]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-21-000040:notes:55]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously-recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.

[0000106040-21-000040:notes:56]
Income per Common Share

[0000106040-21-000040:notes:57]
The Company computes basic income per common share using net income and the weighted average number of common shares outstanding during the period. Diluted income per common share is computed using net income and the weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSU”), restricted stock unit awards with performance conditions or market conditions (“PSU”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”) and shares issuable in connection with convertible debt.

[0000106040-21-000040:notes:58]
Stock-based Compensation

[0000106040-21-000040:notes:59]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the value of the award and is recognized as expense over the vesting period. The fair values of RSUs and PSUs with a performance condition are determined based on the closing market price of the Company’s stock on the date of the grant. The fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option-pricing model and require the input of highly subjective assumptions. The fair values of PSUs with a market condition are estimated using a Monte Carlo simulation model. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance or market conditions. Once these conditions are met, vesting of PSUs is subject to continued service by the employee. At the end of each reporting period, the Company evaluates the probability that PSUs with a performance condition will be earned and records the related stock-based compensation expense over the service period. Compensation expense for PSUs with market conditions is recognized ratably over the required service period regardless of expected or actual achievement.

[0000106040-21-000040:notes:60]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-21-000040:notes:61]
Other comprehensive income (loss), net of tax refers to revenue, expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is primarily comprised of unrealized gains or losses on foreign exchange contracts and interest rate swap agreements designated as cash flow hedges, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-21-000040:notes:62]
Derivative Contracts

[0000106040-21-000040:notes:63]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. Substantially all of these contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Thai baht, Korean won and Israeli shekel, which had an aggregate notional amount of $4.88 billion and $4.62 billion at July 2, 2021 and July 3, 2020, respectively.

[0000106040-21-000040:notes:64]
If the derivative is designated as a cash flow hedge and is determined to be highly effective, the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in Cost of revenue and Operating expenses, and presented within cash flows from operating activities. The Company accounts for its interest rate swaps as designated cash flow hedges to mitigate variations in interest payments under a portion of its LIBOR-based term loans due to variations in the LIBOR index. The Company pays interest monthly at a fixed rate and receives interest monthly at the LIBOR rate on the notional amount of the contract with realized gains or losses recognized in Interest expense. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-21-000040:notes:65]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income, net.

[0000106040-21-000040:notes:66]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-21-000040:notes:67]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s fiscal year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with actuarial changes in the funded status recognized through accumulated other comprehensive income (loss) in the year in which such changes occur. 
The Company reports the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are presented in Other income, net in the Consolidated Statements of Operations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-21-000040:notes:68]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-21-000040:notes:69]
In June 2016, the FASB issued ASU No. 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments” (“ASU 2016-13”). ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader

[0000106040-21-000040:notes:70]
range of reasonable and supportable information to inform credit loss estimates. The amendments are effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2019, which for the Company was the first quarter of fiscal 2021. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its  Consolidated Financial Statements.

[0000106040-21-000040:notes:71]
In November 2018, the FASB issued ASU No. 2018-18, “Collaborative Arrangements (Topic 808): Clarifying the Interaction between Topic 808 and Topic 606” (“ASU 2018-18”). ASU 2018-18 clarifies that certain transactions between collaborative arrangement participants should be accounted for as revenue when the collaborative arrangement participant is a customer in the context of a unit of account and precludes recognizing as revenue consideration received from a collaborative arrangement participant if the participant is not a customer. This ASU requires retrospective adoption to the date the Company adopted ASC 606 by recognizing a cumulative-effect adjustment to the opening balance of retained earnings of the earliest annual period presented. The Company adopted this standard effective July 4, 2020 (the beginning of fiscal 2021) with no material impact on its  Consolidated Financial Statements.

[0000106040-21-000040:notes:72]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-21-000040:notes:73]
In December 2019, the FASB issued ASU No. 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes” (“ASU 2019-12”). ASU 2019-12 removes certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. The ASU also adds guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2020, which for the Company is the first quarter of fiscal 2022. Early adoption is permitted. The Company does not expect this update to have a material impact on its Consolidated Financial Statements.

[0000106040-21-000040:notes:74]
In August 2020, the FASB issued ASU No. 2020-06, “Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity” (“ASU 2020-06”). ASU 2020-06 reduces the number of accounting models for convertible debt instruments and convertible preferred stock and results in fewer instruments with embedded conversion features being separately recognized from the host contract as compared with current standards. Those instruments

[0000106040-21-000040:notes:75]
that do not have a separately recognized embedded conversion feature will no longer recognize a debt issuance discount related to such a conversion feature and would recognize less interest expense on a periodic basis. Additionally, the ASU amends the calculation of the share dilution impact related to a conversion feature and eliminates the treasury method as an option. For instruments that do not have a component mandatorily settled in cash, the change will likely result in a higher amount of share dilution in the calculation of earnings per share. This ASU is effective for fiscal years (and interim periods within those fiscal years) beginning after December 15, 2021, which for the Company is the first quarter of fiscal 2023, with early adoption permitted beginning in the first quarter of fiscal 2022. The Company is currently assessing the impact and timing of adoption of this ASU.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000106040-21-000040:notes:76]
Revenues
The Company’s disaggregated revenue information is as follows:

[0000106040-21-000040:notes:77]
|  |  |  | Year Ended |
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Revenue by Product |  |  |  |  |  |  |  |  |  |
| HDD |  |  |  |  | $ | 8,216 |  |  | $ | 8,967 |  |  | $ | 8,746 |  |
| Flash-based |  |  |  |  | 8,706 |  |  | 7,769 |  |  | 7,823 |  |
| Total Revenue |  |  |  |  | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |
| Revenue by End Market |  |  |  |  |  |  |  |  |  |
| Client Devices |  |  |  |  | $ | 8,255 |  |  | $ | 7,160 |  |  | $ | 8,095 |  |
| Data Center Devices & Solutions |  |  |  |  | 4,950 |  |  | 6,228 |  |  | 5,038 |  |
| Client Solutions |  |  |  |  | 3,717 |  |  | 3,348 |  |  | 3,436 |  |
| Total Revenue |  |  |  |  | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |

[0000106040-21-000040:notes:78]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of either July 2, 2021 or July 3, 2020. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under support and maintenance contracts. Contract liabilities as of July 2, 2021 and July 3, 2020 and changes in contract liabilities during fiscal years 2021 and 2020 were not material.

[0000106040-21-000040:notes:79]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. Other direct incremental costs to obtain contracts that have an expected benefit of greater than one year are amortized over the period of expected cash flows from the related contracts, and the amortization expense is recorded as a reduction to revenue. Total capitalized contract costs and the related amortization as of July 2, 2021 and July 3, 2020 and for the years then ended, were not material.

[0000106040-21-000040:notes:80]
The Company applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for (i) arrangements that have an original expected duration of one year or less, which mainly consist of the support and maintenance contracts, and (ii) variable consideration amounts for sale-based or usage-based royalties for IP license arrangements, which typically range longer than one year. Remaining performance obligations are mainly attributed to right-to-access patent license arrangements and customer support and service contracts which will be recognized over the remaining contract period. The transaction price allocated to the remaining performance obligations as of July 2, 2021 was $71 million, which is mainly attributable to the functional IP license and service arrangements. The Company expects to recognize this amount as revenue as follows: $40 million in fiscal 2022, $30 million in fiscal 2023, and $1 million in fiscal 2024 and thereafter.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-21-000040:notes:81]
Supplemental Financial Statement Data
Accounts receivable, net

[0000106040-21-000040:notes:82]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third party purchasers in exchange for cash. In 2021, 2020 and 2019, the Company sold trade accounts receivable and received cash proceeds of $233 million, $411 million and $1.02 billion, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income, net in the Consolidated Statements of Operations. As of July 2, 2021 and July 3, 2020, the amount of factored receivables that remained outstanding was $0 million and $113 million, respectively.

[0000106040-21-000040:notes:83]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,623 |  |  | $ | 1,306 |  |
| Work-in-process | 1,088 |  |  | 956 |  |
| Finished goods | 905 |  |  | 808 |  |
| Total inventories | $ | 3,616 |  |  | $ | 3,070 |  |

[0000106040-21-000040:notes:84]
Property, plant and equipment, net

[0000106040-21-000040:notes:85]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 278 |  |  | $ | 294 |  |
| Buildings and improvements | 1,854 |  |  | 1,837 |  |
| Machinery and equipment | 7,860 |  |  | 7,391 |  |
| Computer equipment and software | 440 |  |  | 429 |  |
| Furniture and fixtures | 51 |  |  | 52 |  |
| Construction-in-process | 476 |  |  | 297 |  |
| Property, plant and equipment, gross | 10,959 |  |  | 10,300 |  |
| Accumulated depreciation | (7,771) |  |  | (7,446) |  |
| Property, plant and equipment, net | $ | 3,188 |  |  | $ | 2,854 |  |

[0000106040-21-000040:notes:86]
Depreciation expense of property, plant and equipment totaled $726 million, $797 million and $844 million in 2021, 2020 and 2019, respectively.

[0000106040-21-000040:notes:87]
Goodwill

[0000106040-21-000040:notes:88]
|  | Carrying Amount |
|  | (in millions) |
| Balance at June 28, 2019 | $ | 10,076 |  |
| Goodwill recorded in connection with acquisitions | 14 |  |
| Purchase price adjustments to goodwill | (21) |  |
| Foreign currency translation adjustment | (2) |  |
| Balance at July 3, 2020 | 10,067 |  |
| Foreign currency translation adjustment | (1) |  |
| Balance at July 2, 2021 | $ | 10,066 |  |

[0000106040-21-000040:notes:89]
Acquisition

[0000106040-21-000040:notes:90]
On September 10, 2019, the Company acquired substantially all the assets of Kazan Networks, Inc., an innovator in high-performance networking and non-volatile memory express over fabrics technology, and an industry leader in application-specific integrated circuit and adapter solutions to connect storage platforms and systems over ethernet fabrics. The purchase price of this acquisition was $22 million in cash, with net assets acquired primarily consisting of IPR&D of $8 million and $14 million allocated to Goodwill. Goodwill is primarily attributable to the benefits the Company expects to derive from diversifying product offerings in its Data Center Devices and Solutions and Client Solutions end markets as well as the acquired workforce. The expenses incurred by the Company related to the acquisition as well as the revenues and earnings related to the acquisition were not material to the Consolidated Financial Statements.

[0000106040-21-000040:notes:91]
Dispositions

[0000106040-21-000040:notes:92]
In September 2019, the Company announced its intention to exit storage systems, which consisted of IntelliFlash and ActiveScale. These actions allow the Company to redirect investments to other high value priorities. In November 2019, the Company completed its sale of IntelliFlash for a price of $28 million, to be collected over the next three years. The sale of the IntelliFlash business included an immaterial amount of inventory, other tangible and intangible assets, and goodwill; and resulted in a gain of approximately $17 million recorded in Employee termination, asset impairment, and other charges in the Consolidated Statements of Operations for the year ended July 3, 2020. Additionally, in March 2020, the Company completed the sale of ActiveScale. The net assets sold and the proceeds from the sale of ActiveScale were not material. The revenues and expenses related to these businesses were not material to the Consolidated Financial Statements and did not qualify to be reported as discontinued operations. The operating results of these businesses have been reflected in the Company’s results from continuing operations in the Consolidated Statements of Operations for all periods presented through the date of disposition.

[0000106040-21-000040:notes:93]
Intangible assets

[0000106040-21-000040:notes:94]
The following tables present intangible assets as of July 2, 2021 and July 3, 2020:

[0000106040-21-000040:notes:95]
|  | July 2, 2021 |  |  |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |  |
|  | (in years) |  | (in millions) |  |  |
| Finite: |  |  |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,231 |  |  | $ | (4,165) |  |  | $ | 66 |  |  |  |
| Trade names and trademarks | 7 |  | 647 |  |  | (486) |  |  | 161 |  |  |  |
| Customer relationships | 6 |  | 618 |  |  | (491) |  |  | 127 |  |  |  |
| Leasehold interests | 31 |  | 12 |  |  | (4) |  |  | 8 |  |  |  |
| Total finite intangible assets |  |  | 5,508 |  |  | (5,146) |  |  | 362 |  |  |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |  |  |
| Total intangible assets |  |  | $ | 5,588 |  |  | $ | (5,146) |  |  | $ | 442 |  |  |  |

[0000106040-21-000040:notes:96]
|  | July 3, 2020 |
|  | Weighted Average Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
|  | (in years) |  | (in millions) |
| Finite: |  |  |  |  |  |  |  |
| Existing technology | 3 |  | $ | 4,248 |  |  | $ | (3,852) |  |  | $ | 396 |  |
| Trade names and trademarks | 7 |  | 648 |  |  | (398) |  |  | 250 |  |
| Customer relationships | 6 |  | 616 |  |  | (423) |  |  | 193 |  |
| Leasehold interests | 31 |  | 29 |  |  | (7) |  |  | 22 |  |
| Total finite intangible assets |  |  | 5,541 |  |  | (4,680) |  |  | 861 |  |
| In-process research and development |  |  | 80 |  |  | — |  |  | 80 |  |
| Total intangible assets |  |  | $ | 5,621 |  |  | $ | (4,680) |  |  | $ | 941 |  |

[0000106040-21-000040:notes:97]
As part of prior acquisitions, the Company recorded at the time of the acquisition acquired IPR&D for projects in progress that had not yet reached technological feasibility. IPR&D is initially accounted for as an indefinite-lived intangible asset. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life.

[0000106040-21-000040:notes:98]
During 2021, 2020 and 2019, the Company did not record any impairment charges related to intangible assets.

[0000106040-21-000040:notes:99]
Intangible assets are amortized over the estimated useful lives based on the pattern in which the economic benefits are expected to be received. Intangible asset amortization was as follows:

[0000106040-21-000040:notes:100]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Intangible asset amortization | $ | 486 |  |  | $ | 769 |  |  | $ | 968 |  |

[0000106040-21-000040:notes:101]
The following table presents estimated future amortization expense for intangible assets currently subject to amortization as of July 2, 2021:

[0000106040-21-000040:notes:102]
|  |  | Future Intangible Asset Amortization Expenses |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2022 |  | $ | 221 |  |
| 2023 |  | 134 |  |
| 2024 and thereafter |  | 7 |  |
| Total future amortization expense |  | $ | 362 |  |

[0000106040-21-000040:notes:103]
Product warranty liability

[0000106040-21-000040:notes:104]
Changes in the warranty accrual were as follows:

[0000106040-21-000040:notes:105]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Warranty accrual, beginning of period |  |  |  |  | $ | 408 |  |  | $ | 350 |  |  | $ | 318 |  |
| Charges to operations |  |  |  |  | 137 |  |  | 203 |  |  | 162 |  |
| Utilization |  |  |  |  | (106) |  |  | (151) |  |  | (142) |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (76) |  |  | 6 |  |  | 12 |  |
| Warranty accrual, end of period |  |  |  |  | $ | 363 |  |  | $ | 408 |  |  | $ | 350 |  |

[0000106040-21-000040:notes:106]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-21-000040:notes:107]
|  | 2021 |  | 2020 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 175 |  |  | $ | 205 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 188 |  |  | 203 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 363 |  |  | $ | 408 |  |  |  |  |  |  |  |

[0000106040-21-000040:notes:108]
Other liabilities

[0000106040-21-000040:notes:109]
|  | 2021 |  | 2020 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | 684 |  |  | $ | 815 |  |
| Payables related to unrecognized tax benefits | 750 |  |  | 720 |  |
| Other non-current liabilities | 633 |  |  | 881 |  |
| Total other liabilities | $ | 2,067 |  |  | $ | 2,416 |  |

[0000106040-21-000040:notes:110]
Accumulated other comprehensive income (loss)

[0000106040-21-000040:notes:111]
Accumulated other comprehensive income (loss) (“AOCI”), net of tax refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of AOCI:

[0000106040-21-000040:notes:112]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 28, 2019 | $ | (53) |  |  | $ | 4 |  |  |  |  |  |  | $ | (19) |  |  | $ | (68) |  |
| Other comprehensive loss before reclassifications | (1) |  |  | (7) |  |  |  |  |  |  | (87) |  |  | (95) |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  |  |  |  |  | (6) |  |  | (6) |  |
| Income tax benefit (expense) related to items of other comprehensive loss | (4) |  |  | 1 |  |  |  |  |  |  | 15 |  |  | 12 |  |
| Net current-period other comprehensive loss | (5) |  |  | (6) |  |  |  |  |  |  | (78) |  |  | (89) |  |
| Balance at July 3, 2020 | (58) |  |  | (2) |  |  |  |  |  |  | (97) |  |  | (157) |  |
| Other comprehensive income (loss) before reclassifications | 27 |  |  | (36) |  |  |  |  |  |  | 42 |  |  | 33 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | (75) |  |  | (75) |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (4) |  |  | — |  |  |  |  |  |  | 6 |  |  | 2 |  |
| Net current-period other comprehensive income (loss) | 23 |  |  | (36) |  |  |  |  |  |  | (27) |  |  | (40) |  |
| Balance at July 2, 2021 | $ | (35) |  |  | $ | (38) |  |  |  |  |  |  | $ | (124) |  |  | $ | (197) |  |

[0000106040-21-000040:notes:113]
During 2021, the amounts reclassified out of AOCI included losses of $50 million on interest rate swap contracts that were charged to Interest expense and losses of $25 million related to foreign exchange contracts that were substantially all charged to Cost of revenue in the Consolidated Statements of Operations. During 2020, the amounts reclassified out of AOCI primarily related to foreign exchange contracts and were substantially all charged to Cost of revenue in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-21-000040:notes:114]
Fair Value Measurements and Investments
Financial Instruments Carried at Fair Value

[0000106040-21-000040:notes:115]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-21-000040:notes:116]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0000106040-21-000040:notes:117]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-21-000040:notes:118]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-21-000040:notes:119]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of July 2, 2021 and July 3, 2020, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-21-000040:notes:120]
|  | July 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,283 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,283 |  |
| Foreign exchange contracts | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total assets at fair value | $ | 1,283 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 1,297 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |
| Interest rate swap contract | — |  |  | 80 |  |  | — |  |  | 80 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 145 |  |  | $ | — |  |  | $ | 145 |  |

[0000106040-21-000040:notes:121]
|  | July 3, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,079 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,079 |  |
| Foreign exchange contracts | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Total assets at fair value | $ | 1,079 |  |  | $ | 28 |  |  | $ | — |  |  | $ | 1,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Interest rate swap contract | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 142 |  |  | $ | — |  |  | $ | 142 |  |

[0000106040-21-000040:notes:122]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-21-000040:notes:123]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 6, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheet under Other current assets and Accrued expenses, respectively.

[0000106040-21-000040:notes:124]
Interest Rate Swaps. The Company’s interest rate swaps are long-term contracts to hedge the Company’s variable rate debt risk. Interest rate swaps are valued based on estimated present value of future cash flows model. The market-based observable inputs for the model include interest rate curves and credit valuation adjustments based on published credit default swap curves.

[0000106040-21-000040:notes:125]
During 2021 and 2020, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-21-000040:notes:126]
Financial Instruments Not Carried at Fair Value

[0000106040-21-000040:notes:127]
For financial instruments where the carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) differs from fair value (which is based on quoted market prices), the following table represents the related carrying value and fair value for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2021 and the fourth quarter of 2020, respectively.

[0000106040-21-000040:notes:128]
|  | July 2, 2021 |  | July 3, 2020 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | 30 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,327 |  |  | 4,346 |  |  | 4,576 |  |  | 4,474 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,093 |  |  | 1,094 |  |  | 1,692 |  |  | 1,656 |  |
| 1.50% convertible notes due 2024 | 1,017 |  |  | 1,173 |  |  | 987 |  |  | 1,036 |  |
| 4.75% senior unsecured notes due 2026 | 2,288 |  |  | 2,556 |  |  | 2,286 |  |  | 2,428 |  |
| Total | $ | 8,725 |  |  | $ | 9,169 |  |  | $ | 9,575 |  |  | $ | 9,624 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-21-000040:notes:129]
Derivative Instruments and Hedging Activities
As of July 2, 2021, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed 12 months. In addition, the Company had outstanding pay-fixed interest rate swaps that were designated as cash flow hedges of variable rate interest payments on a portion of its term loans through February 2023.

[0000106040-21-000040:notes:130]
As of July 2, 2021, the amount of existing net losses related to cash flow hedges recorded in AOCI included $30 million related to the Company’s interest rate swaps that is expected to be reclassified to earnings after twelve months. In addition, as of July 2, 2021, the Company did not have any foreign exchange forward contracts with credit-risk-related contingent features.

[0000106040-21-000040:notes:131]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income, net and are largely offset by corresponding changes in the fair values of the foreign currency denominated monetary assets and liabilities. For each of 2021, 2020 and 2019, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-21-000040:notes:132]
Netting Arrangements

[0000106040-21-000040:notes:133]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of July 2, 2021 and July 3, 2020, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-21-000040:notes:134]
Debt
Debt consisted of the following as of July 2, 2021 and July 3, 2020:

[0000106040-21-000040:notes:135]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| 0.50% convertible senior notes due 2020 | $ | — |  |  | $ | 35 |  |
| Variable interest rate Term Loan A-1 maturing 2023 | 4,332 |  |  | 4,583 |  |
| Variable interest rate Term Loan B-4 maturing 2023 | 1,093 |  |  | 1,693 |  |
| 1.50% convertible notes due 2024 | 1,100 |  |  | 1,100 |  |
| 4.75% senior unsecured notes due 2026 | 2,300 |  |  | 2,300 |  |
| Total debt | 8,825 |  |  | 9,711 |  |
| Issuance costs and debt discounts | (100) |  |  | (136) |  |
| Subtotal | 8,725 |  |  | 9,575 |  |
| Less current portion of long-term debt | (251) |  |  | (286) |  |
| Long-term debt | $ | 8,474 |  |  | $ | 9,289 |  |

[0000106040-21-000040:notes:136]
The Company has a credit agreement originally entered into on April 29, 2016 and most recently amended in July 2020 (as amended, the “Credit Agreement”), that provides for, among other things, (i) a $2.25 billion revolving credit facility maturing in 2023 (the “Revolving Facility”), (ii) a term loan A-1 due 2023 (the “Term Loan A-1”), and (iii) a term loan B-4 due 2023 (the “Term Loan B-4”).

[0000106040-21-000040:notes:137]
Borrowings under the revolving credit facility bear interest at a rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. During 2018, the Company repaid the previously outstanding borrowings under its revolving credit facility. At July 2, 2021, the Company’s borrowing capacity under the revolving credit facility was $2.25 billion.

[0000106040-21-000040:notes:138]
The Term Loan A-1 bears interest at a rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus an applicable margin varying from 1.125% to 2.000% or a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the Company’s corporate credit ratings. Currently the Company has selected the LIBOR rate option, and the applicable rate was 1.60% as of July 2, 2021. Principal payments are due in quarterly installments of 1.250% per quarter through December 2022, with the remaining balance payable on February 27, 2023. The Term Loan A-1 issuance costs are amortized to interest expense over the term of the loan, and as of July 2, 2021, issuance costs of $5 million remained unamortized.

[0000106040-21-000040:notes:139]
The Term Loan B-4 bears interest at a rate equal to, at the Company’s option, either an adjusted LIBOR rate, subject to a 0.00% floor, plus 1.75% or a base rate plus 0.75%. Currently the Company has selected the LIBOR rate option, and the applicable interest rate was 1.85% as of July 2, 2021. During 2021, the Company made aggregate voluntary prepayments of $600 million on its Term Loan B-4, which was applied toward the remaining scheduled amortization and the remainder towards the principal due at maturity. As of July 2, 2021, there are no longer any scheduled amortization payments due under the Term Loan B-4 prior to its maturity on April 29, 2023. As of July 2, 2021, issuance costs of less than $1 million remained unamortized. On July 19, 2021, the Company made an incremental voluntary prepayment of $150 million on its Term Loan B-4.

[0000106040-21-000040:notes:140]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bear interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. The Company is not required to make principal payments on the 2024 Convertible Notes prior to the maturity date. The 2024 Convertible Notes are jointly and severally guaranteed by the Company’s wholly owned subsidiary, Western Digital Technologies (“WDT”).

[0000106040-21-000040:notes:141]
The 2024 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination thereof at an initial conversion price of $121.91 per share of common stock. Holders of the 2024 Convertible Notes may freely convert their 2024 Convertible Notes on or after November 1, 2023 until the close of business on the business day immediately preceding the maturity date. Prior to November 1, 2023, holders may convert their 2024 Convertible Notes based on variations in market price of the Company’s common stock in relation to the conversion price or the trading price of the 2024 Convertible Notes or upon the occurrence of specified corporate events. As of July 2, 2021, none of the conditions allowing holders of the Convertible Notes to convert had been met. Since February 5, 2021, the Company may redeem all or part of the 2024 Convertible Notes, at its option, if the market price of the Company’s stock achieves certain levels.

[0000106040-21-000040:notes:142]
The Company separately accounts for the liability and equity components of the 2024 Convertible Notes. The value of the liability component as of the date of issuance was recognized at the present value of its cash flows using a discount rate of 4.375%, the Company’s borrowing rate at the date of the issuance for a similar debt instrument without the conversion feature, resulting in a debt discount of $165 million, which was allocated to equity as the value of the conversion feature. The 2024 Convertible Notes debt issuance costs were approximately $18 million, of which $15 million was allocated to the debt component and $3 million was allocated to equity. The debt discount and issuance costs are amortized to interest expense over the term of the 2024 Convertible Notes. As of July 2, 2021, debt discount and issuance costs of $83 million remained unamortized.

[0000106040-21-000040:notes:143]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. The 2026 Senior Unsecured Notes are jointly and severally guaranteed by WDT. The 2026 Senior Unsecured Notes issuance costs are amortized to interest expense over the term of the 2026 Senior Unsecured Notes and as of July 2, 2021, issuance costs of $12 million remained unamortized.

[0000106040-21-000040:notes:144]
In October 2020, the 0.5% convertible senior notes due 2020 were settled in full for cash in accordance with their terms.

[0000106040-21-000040:notes:145]
The Revolving Facility, Term Loan A-1 and Term Loan B-4 are unconditionally guaranteed by WDT under the Credit Agreement and are secured on a first-priority basis (subject to permitted liens) by a lien on the same collateral that secure the other loans under the Credit Agreement; provided that the security and guarantee will be automatically suspended upon certain conditions.

[0000106040-21-000040:notes:146]
The Credit Agreement requires the Company to comply with certain financial covenants with respect to the Revolving Facility and Term Loan A-1, consisting of a Leverage Ratio and an Interest Coverage Ratio (each as defined below). Consolidated Adjusted EBITDA is defined as net income (loss) plus interest expense, income tax expense (benefit) and depreciation and amortization, as well as other contractual adjustments as provided for in the Credit Agreement, including, for purposes of the financial covenants, an addback for certain depreciation-related payments made to the Company’s Flash Ventures.

[0000106040-21-000040:notes:147]
The Company was required to maintain a maximum ratio of total funded debt to trailing twelve-month Consolidated Adjusted EBITDA (“Leverage Ratio”) at the end of each quarter of 4.25 to 1.00 through the quarter ended October 2, 2020 and 4.00 to 1.00 through the quarter ended July 2, 2021, and is required to maintain a maximum Leverage Ratio of 3.75 to 1.00 through the quarter ending December 31, 2021, 3.50 to 1.00 through the quarter ending July 1, 2022, and 3.25 to 1.00 thereafter. In addition, the Company is required to maintain a minimum ratio of Consolidated Adjusted EBITDA to interest expense (“Interest Coverage Ratio”), both calculated on a trailing twelve-month basis, at the end of each quarter of 3.50 to 1.00. As of July 2, 2021, the Company was in compliance with all financial covenants under the Credit Agreement.

[0000106040-21-000040:notes:148]
The Credit Agreement also requires the Company and its subsidiaries to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolutions, asset sales, dividends and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements. In addition, the indentures governing the Company’s 2026 Senior Unsecured Notes and the 2024 Convertible Notes contain restrictive covenants that limit the Company’s and its subsidiaries’ ability to, among other

[0000106040-21-000040:notes:149]
things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness.

[0000106040-21-000040:notes:150]
Future Debt Payments

[0000106040-21-000040:notes:151]
As of July 2, 2021, required annual future debt payments were as follows:

[0000106040-21-000040:notes:152]
|  |  | Future Debt Payments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2022 |  | $ | 251 |  |
| 2023 |  | 5,174 |  |
| 2024 |  | 1,100 |  |
| 2025 and thereafter |  | 2,300 |  |
| Total debt maturities |  | 8,825 |  |
| Issuance costs and debt discounts |  | (100) |  |
| Net carrying value |  | $ | 8,725 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-21-000040:notes:153]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand and the Philippines. All pension and other post-retirement benefit plans outside of the Company’s Japan, Thailand and the Philippines defined benefit pension plans (the “Pension Plans”) are immaterial to the Consolidated Financial Statements.

[0000106040-21-000040:notes:154]
Obligations and Funded Status

[0000106040-21-000040:notes:155]
The following table presents the unfunded status of the benefit obligations for the Pension Plans:

[0000106040-21-000040:notes:156]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 366 |  |  | $ | 352 |  |  | $ | 300 |  |
| Service cost | 16 |  |  | 13 |  |  | 10 |  |
| Interest cost | 5 |  |  | 4 |  |  | 4 |  |
| Plan amendments | — |  |  | — |  |  | 13 |  |
| Actuarial loss (gain) | (5) |  |  | 3 |  |  | 26 |  |
| Benefits paid | (11) |  |  | (8) |  |  | (9) |  |
| Settlement/curtailment | — |  |  | — |  |  | (3) |  |
| Non-U.S. currency movement | (12) |  |  | 2 |  |  | 11 |  |
| Projected benefit obligation at end of period | 359 |  |  | 366 |  |  | 352 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 215 |  |  | 209 |  |  | 200 |  |
| Actual return on plan assets | 20 |  |  | 4 |  |  | 2 |  |
| Employer contributions | 11 |  |  | 9 |  |  | 10 |  |
| Benefits paid | (11) |  |  | (8) |  |  | (9) |  |
| Non-U.S. currency movement | (8) |  |  | 1 |  |  | 6 |  |
| Fair value of plan assets at end of period | 227 |  |  | 215 |  |  | 209 |  |
| Unfunded status | $ | 132 |  |  | $ | 151 |  |  | $ | 143 |  |

[0000106040-21-000040:notes:157]
The following table presents the unfunded amounts related to the Pension Plans as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-21-000040:notes:158]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 131 |  |  | 150 |  |
| Net amount recognized | $ | 132 |  |  | $ | 151 |  |

[0000106040-21-000040:notes:159]
The accumulated benefit obligation for the Pension Plans was $359 million at July 2, 2021. As of July 2, 2021, actuarial gains for the Pension Plans of $27 million are included in Accumulated other comprehensive loss in the Consolidated Balance Sheet. There were no material prior service credits for the defined benefit pension plans recognized in Accumulated other comprehensive loss in the Consolidated Balance Sheet as of July 2, 2021.

[0000106040-21-000040:notes:160]
Net periodic benefit costs were not material for 2021, 2020, and 2019.

[0000106040-21-000040:notes:161]
Assumptions

[0000106040-21-000040:notes:162]
Weighted-Average Assumptions

[0000106040-21-000040:notes:163]
The weighted-average actuarial assumptions used to determine the projected benefit obligations for the Pension Plans were as follows:

[0000106040-21-000040:notes:164]
|  | 2021 |  | 2020 |  | 2019 |
| Discount rate | 1.4 | % |  | 1.1 | % |  | 1.1 | % |
| Rate of compensation increase | 2.0 | % |  | 2.0 | % |  | 1.7 | % |

[0000106040-21-000040:notes:165]
The weighted-average actuarial assumptions used to determine benefit costs for the Pension Plans were as follows:

[0000106040-21-000040:notes:166]
|  | 2021 |  | 2020 |  | 2019 |
| Discount rate | 1.1 | % |  | 1.1 | % |  | 1.3 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 2.0 | % |  | 1.7 | % |  | 1.2 | % |

[0000106040-21-000040:notes:167]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management then matches the benefit payments to high quality bonds which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-21-000040:notes:168]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in each plan as well as the investment portfolio applicable to the plan depending on each plan’s economic environment. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates. As of July 2, 2021, Pension Plan assets materially consisted of plan assets related to the Japan Pension Plan and as such the assumption used herein is primarily related to the Japan Pension Plan.

[0000106040-21-000040:notes:169]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-21-000040:notes:170]
Plan Assets

[0000106040-21-000040:notes:171]
Investment Policies and Strategies

[0000106040-21-000040:notes:172]
The investment policy in the Pension Plans is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 55% in debt securities, 30% in equity securities, and the remaining 15% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-21-000040:notes:173]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-21-000040:notes:174]
Fair Value Measurements

[0000106040-21-000040:notes:175]
The following tables present the Pension Plans’ major asset categories and their associated fair values and net asset values as of July 2, 2021 and July 3, 2020:

[0000106040-21-000040:notes:176]
|  | July 2, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 123 |  |  | — |  |  | 123 |  |
| Fair value of plan assets | $ | — |  |  | $ | 196 |  |  | $ | — |  |  | $ | 196 |  |
| Plan assets measured at net asset value: |  |  |  |  |  |  |  |
| Real estate investment trust |  |  |  |  |  |  | $ | 30 |  |

[0000106040-21-000040:notes:177]
|  | July 3, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Equity: |  |  |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 72 |  |  | $ | — |  |  | $ | 72 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 131 |  |  | — |  |  | 131 |  |
| Cash equivalents and short-term investments | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Fair value of plan assets | $ | 12 |  |  | $ | 203 |  |  | $ | — |  |  | $ | 215 |  |

[0000106040-21-000040:notes:178]
(1)    Commingled funds represent pooled institutional investments.

[0000106040-21-000040:notes:179]
(2)    Equity mutual funds invest primarily in equity securities.

[0000106040-21-000040:notes:180]
(3)    Fixed income mutual funds invest primarily in fixed income securities.

[0000106040-21-000040:notes:181]
There were no significant movements of assets between any level categories in 2021 or 2020.

[0000106040-21-000040:notes:182]
Fair Value Valuation Techniques

[0000106040-21-000040:notes:183]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-21-000040:notes:184]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics, and is generally classified as Level 2.

[0000106040-21-000040:notes:185]
Cash equivalents includes money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-21-000040:notes:186]
Cash Flows

[0000106040-21-000040:notes:187]
The Company’s expected employer contributions for 2022 and annual benefit payments over the next five years for its Pension Plans are not expected to be material.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000106040-21-000040:notes:188]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0000106040-21-000040:notes:189]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”. The Company has a 49.9% ownership interest and Kioxia has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Kioxia collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by Kioxia at its wafer fabrication facilities located in Japan using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from Kioxia at cost and then resells those wafers to the Company and Kioxia at cost plus a markup.

[0000106040-21-000040:notes:190]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of Kioxia’s “Y3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-21-000040:notes:191]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of Kioxia’s “Y4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0000106040-21-000040:notes:192]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of Kioxia’s “Y5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Y5 was built in two phases of approximately equal size.

[0000106040-21-000040:notes:193]
New Y2. The Company has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “New Y2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Y2 primarily provided additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Y2 started in 2016.

[0000106040-21-000040:notes:194]
Y6. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “Y6” 300-millimeter wafer fabrication facility in Yokkaichi, Japan. Y6 is primarily intended to provide clean room space to continue the transition of existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. Production of flash-based wafers in Y6 started in 2018.

[0000106040-21-000040:notes:195]
K1. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “K1” 300-milimeter wafer fabrication facility in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. K1 is now fully operational. In connection with the start-up of this facility, the Company agreed to prepay an aggregate of approximately $360 million over a 3-year period beginning in the first half of fiscal year 2020 toward K1 building depreciation, to be credited against future wafer charges. As of July 2, 2021, remaining committed prepayments totaled $77 million.

[0000106040-21-000040:notes:196]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0000106040-21-000040:notes:197]
The following table presents the notes receivable from, and equity investments in, Flash Ventures as of July 2, 2021 and July 3, 2020:

[0000106040-21-000040:notes:198]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 191 |  |  | $ | 273 |  |
| Notes receivable, Flash Alliance | 213 |  |  | 301 |  |
| Notes receivable, Flash Forward | 561 |  |  | 670 |  |
| Investment in Flash Partners | 199 |  |  | 203 |  |
| Investment in Flash Alliance | 293 |  |  | 300 |  |
| Investment in Flash Forward | 129 |  |  | 128 |  |
| Total notes receivable and investments in Flash Ventures | $ | 1,586 |  |  | $ | 1,875 |  |

[0000106040-21-000040:notes:199]
During 2021, 2020 and 2019, the Company made net payments to Flash Ventures of $4.36 billion, $3.09 billion and $4.13 billion, respectively, for purchased flash-based memory wafers and net loans.

[0000106040-21-000040:notes:200]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0000106040-21-000040:notes:201]
As of July 2, 2021 and July 3, 2020, the Company had Accounts payable balances due to Flash Ventures of $398 million and $407 million, respectively.

[0000106040-21-000040:notes:202]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at July 2, 2021, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0000106040-21-000040:notes:203]
|  | July 2,2021 |
|  | (in millions) |
| Notes receivable | $ | 965 |  |
| Equity investments | 621 |  |
| Operating lease guarantees | 1,973 |  |
| Inventory and prepayments | 712 |  |
| Maximum estimable loss exposure | $ | 4,271 |  |

[0000106040-21-000040:notes:204]
As of July 2, 2021 and July 3, 2020, the Company’s retained earnings included undistributed earnings of Flash Ventures of $33 million and $24 million, respectively.

[0000106040-21-000040:notes:205]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0000106040-21-000040:notes:206]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2019, as a result of flash business conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with the projected demand. In 2019, the Company incurred costs of $264 million associated with the reduction in utilization, which was recorded as a charge to Cost of revenue.

[0000106040-21-000040:notes:207]
In June 2019, an unexpected power outage incident occurred at the flash-based memory manufacturing facilities operated by Flash Ventures in Yokkaichi, Japan. The power outage incident impacted the facilities and process tools and resulted in the damage of flash wafers in production and a reduction in the Company’s flash wafer availability. As a result of this incident, the Company incurred charges of $68 million and $145 million in 2020 and 2019, respectively, which were recorded in Cost of revenue and primarily consisted of the write-off of damaged inventory and unabsorbed manufacturing overhead costs. In 2021, the Company recovered $75 million related to this incident from its insurance carriers, which was recorded in Cost of revenue.

[0000106040-21-000040:notes:208]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

[0000106040-21-000040:notes:209]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Consolidated Financial Statements.

[0000106040-21-000040:notes:210]
Off-Balance Sheet Liabilities

[0000106040-21-000040:notes:211]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0000106040-21-000040:notes:212]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of July 2, 2021.

[0000106040-21-000040:notes:213]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 220 |  |  | $ | 1,973 |  |

[0000106040-21-000040:notes:214]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of July 2, 2021 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of July 2, 2021:

[0000106040-21-000040:notes:215]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| 2022 |  | $ | 560 |  |  | $ | 48 |  |  | $ | 608 |  |
| 2023 |  | 445 |  |  | 65 |  |  | 510 |  |
| 2024 |  | 290 |  |  | 117 |  |  | 407 |  |
| 2025 |  | 115 |  |  | 107 |  |  | 222 |  |
| 2026 and thereafter |  | 64 |  |  | 162 |  |  | 226 |  |
| Total guarantee obligations |  | $ | 1,474 |  |  | $ | 499 |  |  | $ | 1,973 |  |

[0000106040-21-000040:notes:216]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of July 2, 2021, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0000106040-21-000040:notes:217]
Unis Venture

[0000106040-21-000040:notes:218]
The Company has a joint venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For the years ended July 2, 2021, July 3, 2020 and June 28, 2019, the Company recognized approximately 3%, 1%, and 1% of its consolidated revenue on products distributed by the Unis Venture, respectively. The outstanding accounts receivable due from and investment in the Unis Venture were 5% and 4% of Accounts receivable, net as of both July 2, 2021 and July 3, 2020, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-21-000040:notes:219]
Leases and Other Commitments 
Leases

[0000106040-21-000040:notes:220]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term. The following table summarizes supplemental balance sheet information related to operating leases as of July 2, 2021:

[0000106040-21-000040:notes:221]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
| Minimum lease payments by fiscal year: | (in millions) |  |  |  |  |  |  |  |  |
| 2022 | $ | 40 |  |  |  |  |  |  |  |  |  |
| 2023 | 34 |  |  |  |  |  |  |  |  |  |
| 2024 | 33 |  |  |  |  |  |  |  |  |  |
| 2025 | 31 |  |  |  |  |  |  |  |  |  |
| 2026 | 30 |  |  |  |  |  |  |  |  |  |
| Thereafter | 116 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 284 |  |  |  |  |  |  |  |  |  |
| Less: Imputed Interest | (47) |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | 237 |  |  |  |  |  |  |  |  |  |
| Less: Current portion (included in Accrued expenses) | 33 |  |  |  |  |  |  |  |  |  |
| Long-term operating lease liabilities (included in Other liabilities ) | $ | 204 |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 222 |  |  |  |  |  |  |  |  |  |
| Weighted average remaining lease term in years | 8.4 |  |  |  |  |  |  |  |  |
| Weighted average discount rate | 3.8 | % |  |  |  |  |  |  |  |  |

[0000106040-21-000040:notes:222]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases for the year ended July 2, 2021:

[0000106040-21-000040:notes:223]
|  |  |  | Year Ended |  |  |  |  |  |  |
|  |  |  | July 2,2021 |  |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |  |  |  |
| Cost of operating leases |  |  | $ | 50 |  |  |  |  |  |  |  |
| Cash paid for operating leases |  |  | 51 |  |  |  |  |  |  |  |
| Operating lease assets obtained in exchange for operating lease liabilities |  |  | 29 |  |  |  |  |  |  |  |

[0000106040-21-000040:notes:224]
Cost of operating leases was as follows:

[0000106040-21-000040:notes:225]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Cost of operating leases | $ | 50 |  |  | $ | 55 |  |  | $ | 47 |  |

[0000106040-21-000040:notes:226]
Purchase Agreements and Other Commitments

[0000106040-21-000040:notes:227]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of July 2, 2021, the Company had the following minimum long-term commitments:

[0000106040-21-000040:notes:228]
|  |  | Long-term commitments |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2022 |  | $ | 630 |  |
| 2023 |  | 530 |  |
| 2024 |  | 281 |  |
| 2025 |  | 148 |  |
| 2026 |  | 20 |  |
| Thereafter |  | 170 |  |
| Total |  | $ | 1,779 |  |

[0000106040-21-000040:notes:229]
Sale-Leaseback

[0000106040-21-000040:notes:230]
In April 2019, the Company completed a sale and leaseback of its manufacturing facility in Fremont, California. The Company received proceeds from the sale of $115 million and recognized a loss of $25 million. The property is being leased back over a term of 15 years at an annual lease rate of $7 million for the first year and increasing by 3% per year thereafter. The lease includes four 5-year renewal options for the ability to extend up to an additional 20 years.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-21-000040:notes:231]
Business Segment, Geographic Information, and Concentration of Risk 
The Company manufactures, markets, and sells data storage devices and solutions in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Historically, the Company has managed and reported under a single operating segment. Late in the first quarter of fiscal 2021, the Chief Executive Officer, who is the Company’s Chief Operating Decision Maker, announced a decision to reorganize the Company’s business by forming two separate product business units: flash-based products and hard disk drives. To align the new operating model and business structure, the Company is making management organizational changes and implementing new reporting modules and processes to provide discrete information to manage the business. Management expects to finalize its assessment of its operating segments when the implementations and transitions are completed, which is expected to be in the first quarter of fiscal 2022.

[0000106040-21-000040:notes:232]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0000106040-21-000040:notes:233]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Net revenue (1) |  |  |  |  |  |
| United States | $ | 3,789 |  |  | $ | 4,679 |  |  | $ | 3,602 |  |
| China | 4,339 |  |  | 4,075 |  |  | 3,861 |  |
| Hong Kong | 3,624 |  |  | 2,592 |  |  | 3,122 |  |
| Rest of Asia | 1,492 |  |  | 1,699 |  |  | 2,116 |  |
| Europe, Middle East and Africa | 3,061 |  |  | 2,926 |  |  | 3,109 |  |
| Other | 617 |  |  | 765 |  |  | 759 |  |
| Total | $ | 16,922 |  |  | $ | 16,736 |  |  | $ | 16,569 |  |

[0000106040-21-000040:notes:234]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee.

[0000106040-21-000040:notes:235]
|  | 2021 |  | 2020 |
|  | (in millions) |
| Long-lived assets (1) |  |  |  |
| United States | $ | 1,068 |  |  | $ | 949 |  |
| Malaysia | 632 |  |  | 643 |  |
| China | 395 |  |  | 373 |  |
| Thailand | 651 |  |  | 472 |  |
| Rest of Asia | 398 |  |  | 366 |  |
| Europe, Middle East and Africa | 44 |  |  | 51 |  |
| Total | $ | 3,188 |  |  | $ | 2,854 |  |

[0000106040-21-000040:notes:236]
(1)    Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located.

[0000106040-21-000040:notes:237]
Customer Concentration and Credit Risk

[0000106040-21-000040:notes:238]
The Company sells its products to computer manufacturers, cloud service providers, resellers and retailers throughout the world. For each of 2021, 2020 and 2019, no customer accounted for 10% or more of the Company’s net revenue. For 2021, 2020 and 2019, the Company’s top 10 customers accounted for 39%,  42%, and 45%, respectively, of the Company’s net revenue.

[0000106040-21-000040:notes:239]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of July 2, 2021 and July 3, 2020, the Company had net accounts receivable of $2.3 billion and $2.4 billion, respectively, and one customer, Kingston Technology Company, accounted for 12% and 10%, respectively, of the Company’s net accounts receivable.  Reserves for potential credit losses were not material as of each period end.

[0000106040-21-000040:notes:240]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-21-000040:notes:241]
Supplier Concentration

[0000106040-21-000040:notes:242]
All of the Company’s flash memory system products require silicon wafers for the memory and controller components. The Company’s flash memory wafers are currently supplied almost entirely from Flash Ventures and the controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations.

[0000106040-21-000040:notes:243]
In addition, some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-21-000040:notes:244]
Western Digital Corporation 401(k) Plan 
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all domestic employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire unless the individual is covered by a collective bargaining agreement, provides services as a consultant, intern, independent contractor, leased or temporary employee, or otherwise is not treated as a common-law employee.

[0000106040-21-000040:notes:245]
Eligible employees are generally able to contribute up to 75% of their eligible compensation on a combined pre-tax and Roth basis, 10% on a combined pre-tax catch-up and Roth catch-up basis, and 10% on a non-Roth after-tax basis subject to Internal Revenue Service (“IRS”) limitations. The Company makes a basic matching contribution equal to 50% of each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. The Company’s employer matching contributions vest over a two-year graded period. The Company may suspend matching contributions at any time at its discretion. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-21-000040:notes:246]
For 2021, 2020 and 2019, the Company made Plan contributions of $34 million, $33 million and $34 million, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-21-000040:notes:247]
Shareholders’ Equity
2017 Performance Incentive Plan

[0000106040-21-000040:notes:248]
The types of awards that may be granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (as amended, the “2017 Performance Incentive Plan”) include stock options, stock appreciation rights (“SARs”), RSUs, PSUs, stock bonuses and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash bonus awards. Persons eligible to receive awards under the 2017 Performance Incentive Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2017 Performance Incentive Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs under the 2017 Performance Incentive Plan is ten years after the grant date of the award. RSUs granted under the 2017 Performance Incentive Plan typically vest over periods ranging from one to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance conditions or market conditions and completion of requisite service periods. Once the performance conditions or market conditions are met, vesting of PSUs is generally subject to continued service by the employee. To the extent available, the Company issues shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-21-000040:notes:249]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-21-000040:notes:250]
As of July 2, 2021, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2017 Performance Incentive Plan was 105.6 million shares. Shares issued in respect of stock options and SARs granted under the 2017 Performance Incentive Plan count against the plan’s share limit on a one-for-one basis, whereas currently, shares issued in respect of any other type of award granted count against the plan’s share limit as 1.72 shares for every one share issued in connection with such award. The 2017 Performance Incentive Plan will terminate on August 4, 2025 unless terminated earlier by the Company’s Board of Directors.

[0000106040-21-000040:notes:251]
Employee Stock Purchase Plan

[0000106040-21-000040:notes:252]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock either at the beginning of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-21-000040:notes:253]
During 2021, 2020 and 2019, the Company issued 3.2 million, 3.0 million, and 2.6 million shares, respectively, for aggregate purchase amounts of $115 million, $107 million and $102 million, respectively.

[0000106040-21-000040:notes:254]
Stock-based Compensation Expense

[0000106040-21-000040:notes:255]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-21-000040:notes:256]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Options |  |  |  |  | $ | — |  |  | $ | 7 |  |  | $ | 16 |  |
| RSUs and PSUs |  |  |  |  | 282 |  |  | 268 |  |  | 263 |  |
| ESPP |  |  |  |  | 36 |  |  | 33 |  |  | 27 |  |
| Total |  |  |  |  | $ | 318 |  |  | $ | 308 |  |  | $ | 306 |  |

[0000106040-21-000040:notes:257]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Cost of revenue |  |  |  |  | $ | 55 |  |  | $ | 51 |  |  | $ | 48 |  |
| Research and development |  |  |  |  | 158 |  |  | 163 |  |  | 155 |  |
| Selling, general and administrative |  |  |  |  | 105 |  |  | 94 |  |  | 103 |  |
| Subtotal |  |  |  |  | 318 |  |  | 308 |  |  | 306 |  |
| Tax benefit |  |  |  |  | (47) |  |  | (45) |  |  | (50) |  |
| Total |  |  |  |  | $ | 271 |  |  | $ | 263 |  |  | $ | 256 |  |

[0000106040-21-000040:notes:258]
Windfall tax benefits related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-21-000040:notes:259]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The remaining compensation cost related to unvested stock options is immaterial as of July 2, 2021. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of July 2, 2021:

[0000106040-21-000040:notes:260]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 543 |  |  | 2.4 |
| ESPP | 65 |  |  | 1.8 |
| Total unamortized compensation cost | $ | 608 |  |  |  |

[0000106040-21-000040:notes:261]
(1)    Weighted average service period assumes the performance conditions are met for the PSUs.

[0000106040-21-000040:notes:262]
Plan Activities

[0000106040-21-000040:notes:263]
Stock Options

[0000106040-21-000040:notes:264]
The following table summarizes stock option activity under the Company’s incentive plans:

[0000106040-21-000040:notes:265]
|  | Number of Shares |  | Weighted Average Exercise Price Per Share |  | Weighted Average Remaining Contractual Life |  | Aggregate Intrinsic Value |
|  | (in millions) |  |  |  | (in years) |  | (in millions) |
| Options outstanding at June 29, 2018 | 4.8 |  |  | $ | 64.23 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 39.58 |  |  |  |  | $ | 8 |  |
| Canceled or expired | (0.5) |  |  | 74.79 |  |  |  |  |  |
| Options outstanding at June 28, 2019 | 3.9 |  |  | 65.72 |  |  |  |  |  |
| Exercised | (0.8) |  |  | 43.26 |  |  |  |  | $ | 12 |  |
| Canceled or expired | (0.4) |  |  | 88.58 |  |  |  |  |  |
| Options outstanding at July 3, 2020 | 2.7 |  |  | 69.16 |  |  |  |  |  |
| Exercised | (0.4) |  |  | 44.34 |  |  |  |  | $ | 6 |  |
| Canceled or expired | (0.8) |  |  | 75.42 |  |  |  |  |  |
| Options outstanding at July 2, 2021 | 1.5 |  |  | $ | 72.84 |  |  | 1.20 |  | $ | 15 |  |

[0000106040-21-000040:notes:266]
No options were granted in 2021, 2020 or 2019. All outstanding options were exercisable at July 2, 2021.

[0000106040-21-000040:notes:267]
RSUs and PSUs

[0000106040-21-000040:notes:268]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-21-000040:notes:269]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at June 29, 2018 | 12.6 |  |  | $ | 58.31 |  |  |  |
| Granted | 7.3 |  |  | 54.82 |  |  |  |
| Vested | (6.3) |  |  | 53.21 |  |  | $ | 360 |  |
| Forfeited | (2.0) |  |  | 58.63 |  |  |  |
| RSUs and PSUs outstanding at June 28, 2019 | 11.6 |  |  | 62.07 |  |  |  |
| Granted | 7.4 |  |  | 55.32 |  |  |  |
| Vested | (4.4) |  |  | 58.36 |  |  | $ | 252 |  |
| Forfeited | (1.3) |  |  | 63.33 |  |  |  |
| RSUs and PSUs outstanding at July 3, 2020 | 13.3 |  |  | 60.92 |  |  |  |
| Granted | 8.8 |  |  | 40.40 |  |  |  |
| Vested | (4.5) |  |  | 60.18 |  |  | $ | 196 |  |
| Forfeited | (1.5) |  |  | 55.74 |  |  |  |
| RSUs and PSUs outstanding at July 2, 2021 | 16.1 |  |  | $ | 50.12 |  |  |  |

[0000106040-21-000040:notes:270]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-21-000040:notes:271]
Fair Value Valuation Assumptions

[0000106040-21-000040:notes:272]
RSU and PSU Grants

[0000106040-21-000040:notes:273]
The fair value of the Company’s RSU and PSU awards with a performance condition is determined based upon the closing price of the Company’s stock price on the date of grant. The fair value of PSU awards with a market condition is estimated using a Monte Carlo simulation model on the date of grant using historical volatility.

[0000106040-21-000040:notes:274]
ESPP — Black-Scholes-Merton Model

[0000106040-21-000040:notes:275]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option-pricing model. The Black-Scholes-Merton option-pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-21-000040:notes:276]
The fair values of ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option-pricing model with the following weighted average assumptions:

[0000106040-21-000040:notes:277]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
| Weighted-average expected term (in years) |  |  |  |  | 1.25 |  | 1.25 |  | 1.24 |
| Risk-free interest rate |  |  |  |  | 0.10% |  | 0.55% |  | 2.25% |
| Stock price volatility |  |  |  |  | 0.56 |  | 0.59 |  | 0.35 |
| Dividend yield |  |  |  |  | —% |  | 1.08% |  | 2.42% |
| Fair value |  |  |  |  | $21.59 |  | $12.76 |  | $16.89 |

[0000106040-21-000040:notes:278]
Stock Repurchase Program

[0000106040-21-000040:notes:279]
The Company’s Board of Directors has authorized a stock repurchase program for the repurchase of up to $5.0 billion of the Company’s common stock, which authorization is effective through July 25, 2023. For the year ended July 2, 2021, the Company did not make any stock repurchases and has not repurchased any shares of its common stock pursuant to its stock repurchase program since the first quarter of fiscal 2019. Although the Company will reevaluate the repurchasing of common stock when appropriate, there can be no assurance if, when or at what level the Company may resume such activity. The remaining amount available to be repurchased under the Company’s current stock repurchase program as of July 2, 2021 was $4.5 billion. Repurchases under the stock repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan.

[0000106040-21-000040:notes:280]
Stock Reserved for Issuance

[0000106040-21-000040:notes:281]
The following table summarizes all common stock reserved for issuance at July 2, 2021:

[0000106040-21-000040:notes:282]
|  | Number of Shares |
|  | (in millions) |
| Outstanding awards and shares available for award grants | 33 |  |
| ESPP | 6 |  |
| Total | 39 |  |

[0000106040-21-000040:notes:283]
Dividends to Shareholders
The Company issued a quarterly cash dividend from the first quarter of fiscal 2013 up to the third quarter of fiscal 2020.  In April 2020, the Company suspended its dividend to reinvest in the business and to support its ongoing deleveraging efforts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-21-000040:notes:284]
Income Tax Expense
Income (loss) Before Taxes

[0000106040-21-000040:notes:285]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0000106040-21-000040:notes:286]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Foreign | $ | 218 |  |  | $ | (695) |  |  | $ | (642) |  |
| Domestic | 709 |  |  | 649 |  |  | 355 |  |
| Income (loss) before taxes | $ | 927 |  |  | $ | (46) |  |  | $ | (287) |  |

[0000106040-21-000040:notes:287]
Income Tax Expense (Benefit)

[0000106040-21-000040:notes:288]
The components of the income tax expense (benefit) were as follows:

[0000106040-21-000040:notes:289]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 195 |  |  | $ | 157 |  |  | $ | 181 |  |
| Domestic - Federal | 154 |  |  | 124 |  |  | (91) |  |
| Domestic - State | (1) |  |  | 5 |  |  | 3 |  |
|  | 348 |  |  | 286 |  |  | 93 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (20) |  |  | (29) |  |  | 226 |  |
| Domestic - Federal | (208) |  |  | (53) |  |  | 141 |  |
| Domestic - State | (14) |  |  | — |  |  | 7 |  |
|  | (242) |  |  | (82) |  |  | 374 |  |
| Income tax expense | $ | 106 |  |  | $ | 204 |  |  | $ | 467 |  |

[0000106040-21-000040:notes:290]
The Tax Cuts and Jobs Act (the “2017 Act”), enacted on December 22, 2017, includes a broad range of tax reform proposals affecting businesses. The Company completed its accounting for the tax effects of the enactment of the 2017 Act during the second quarter of fiscal 2019. However, the U.S. Treasury and the IRS have issued tax guidance on certain provisions of the 2017 Act since the enactment date, and the Company anticipates the issuance of additional regulatory and interpretive guidance. The Company applied a reasonable interpretation of the 2017 Act along with the then-available guidance in finalizing its accounting for the tax effects of the 2017 Act. Any additional regulatory or interpretive guidance would constitute new information, which may require further refinements to the Company’s estimates in future periods.

[0000106040-21-000040:notes:291]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was enacted in response to the COVID-19 pandemic in the U.S. The CARES Act, among other things, allows net operating losses arising in tax years 2018, 2019, and 2020 to be carried back to each of the five preceding taxable years to generate a refund of previously paid income taxes and increases the business interest expense limitation from 30% to 50% of adjusted taxable income for tax years 2019 and 2020. Additionally, countries around the world implemented emergency tax measures to provide relief similar to the CARES Act. The Company at present does not expect that any of the provisions of the CARES Act or the emergency tax measures around the world would result in a material cash benefit.

[0000106040-21-000040:notes:292]
On December 27, 2020, the Consolidated Appropriations Act (the “Appropriations Act”) was enacted to fund the federal government through their fiscal year, extend certain expiring tax provisions and provide additional emergency relief to individuals and businesses related to the COVID-19 pandemic in the U.S. The Company at present does not expect any of the provisions of the Appropriations Act to have a material impact on its Consolidated Financial Statements.

[0000106040-21-000040:notes:293]
On March 11, 2021, the American Rescue Plan Act of 2021 (the “Rescue Act”) was enacted to provide additional emergency relief to individuals and businesses related to the COVID-19 pandemic in the U.S. The Rescue Act includes certain business-related provisions, which the Company at present does not expect to have a material impact on its Consolidated Financial Statements. The Company continues to monitor and evaluate the regulatory and interpretive guidance related to the CARES Act, the Appropriations Act and the Rescue Act, as well as legislation in other jurisdictions.

[0000106040-21-000040:notes:294]
Deferred Taxes

[0000106040-21-000040:notes:295]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-21-000040:notes:296]
|  | July 2,2021 |  | July 3,2020 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 88 |  |  | $ | 52 |  |
| Accrued compensation and benefits not currently deductible | 143 |  |  | 130 |  |
| Deferred revenue | 128 |  |  | — |  |
| Net operating loss carryforward | 196 |  |  | 251 |  |
| Business credit carryforward | 461 |  |  | 438 |  |
| Long-lived assets | 101 |  |  | 123 |  |
| Other | 131 |  |  | 133 |  |
| Total deferred tax assets | 1,248 |  |  | 1,127 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (202) |  |  | (294) |  |
| Unremitted earnings of certain non-U.S. entities | (280) |  |  | (228) |  |
| Other | (20) |  |  | (26) |  |
| Total deferred tax liabilities | (502) |  |  | (548) |  |
| Valuation allowances | (558) |  |  | (624) |  |
| Deferred tax assets (liabilities), net | $ | 188 |  |  | $ | (45) |  |

[0000106040-21-000040:notes:297]
The net deferred tax asset valuation allowance decreased by $66 million primarily due to an increase in the deferred tax liability for state taxes on the unremitted earnings of certain non-U.S. entities that would be offset by existing business tax credits carryforwards. The assessment of valuation allowances against deferred tax assets requires estimations and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize most of its deferred tax assets with the exception of certain loss and credit carryforwards.

[0000106040-21-000040:notes:298]
The Company is permanently reinvested with respect to certain foreign earnings. There is no unrecognized deferred tax liability associated with the repatriation of these foreign undistributed earnings as it can be achieved without additional federal tax consequences.

[0000106040-21-000040:notes:299]
Effective Tax Rate

[0000106040-21-000040:notes:300]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-21-000040:notes:301]
|  | 2021 |  | 2020 |  | 2019 |
| U.S. Federal statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| Tax rate differential on international income | 8 |  |  | (443) |  |  | (75) |  |
| Tax effect of U.S. foreign income inclusion | 5 |  |  | (38) |  |  | (7) |  |
| Tax effect of U.S. foreign minimum tax | 1 |  |  | (235) |  |  | (38) |  |
| Tax effect of U.S. foreign derived intangible income | (14) |  |  | 109 |  |  | 11 |  |
| Tax effect of U.S. non-deductible stock-based compensation | 1 |  |  | (21) |  |  | (1) |  |
| Tax effect of U.S. permanent differences | 1 |  |  | (26) |  |  | (3) |  |
| Impact of 2017 Act: |  |  |  |  |  |
| One-time mandatory deemed repatriation tax | — |  |  | — |  |  | (41) |  |
| Re-measurement of deferred taxes | — |  |  | — |  |  | 2 |  |
| Change in valuation allowance | (7) |  |  | (12) |  |  | (2) |  |
| Unremitted earnings of certain non-U.S. entities | 6 |  |  | (114) |  |  | (79) |  |
| Foreign income tax credits | (5) |  |  | 191 |  |  | 23 |  |
| R&D tax credits | (8) |  |  | 147 |  |  | 24 |  |
| Other | 2 |  |  | (22) |  |  | 2 |  |
| Effective tax rate | 11 | % |  | (443) | % |  | (163) | % |

[0000106040-21-000040:notes:302]
Tax Holidays and Carryforwards

[0000106040-21-000040:notes:303]
A substantial portion of the Company’s manufacturing operations in Malaysia, the Philippines and Thailand operate under various tax holidays and tax incentive programs which expired or will expire in whole or in part at various dates during fiscal years 2021 through 2031. Certain of the holidays may be extended if specific conditions are met. The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $390 million, or $1.26 per diluted share, $464 million, or $1.54 per diluted share, and $393 million, or $1.33 per diluted share, in 2021, 2020, and 2019, respectively.

[0000106040-21-000040:notes:304]
As of July 2, 2021, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-21-000040:notes:305]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 661 |  |  | 2022 to 2038 |
| State NOL | 369 |  |  | 2022 to 2038 |
| Federal tax credits | 56 |  |  | 2022 to 2034 |
| State tax credits | 648 |  |  | No expiration |

[0000106040-21-000040:notes:306]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the Internal Revenue Code. The Company expects the total amount of federal and state NOLs ultimately realized will be reduced as a result of these provisions by $134 million and $245 million, respectively. The Company expects the total amount of federal and state credits ultimately realized will be reduced as a result of these provisions by $27 million and $2 million, respectively.

[0000106040-21-000040:notes:307]
As of July 2, 2021, the Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-21-000040:notes:308]
| Jurisdiction |  | NOL Carryforward Amount |  | Expiration |
|  |  | (in millions) |  |  |
| Belgium |  | $ | 120 |  |  | No expiration |
| Japan |  | 111 |  |  | 2024 to 2031 |
| Malaysia |  | 72 |  |  | 2025 to 2027 |
| Spain |  | 51 |  |  | No expiration |
| Netherlands |  | 12 |  |  | 2025 to 2026 |

[0000106040-21-000040:notes:309]
Uncertain Tax Positions

[0000106040-21-000040:notes:310]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets.

[0000106040-21-000040:notes:311]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-21-000040:notes:312]
|  | 2021 |  | 2020 |  | 2019 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 717 |  |  | $ | 695 |  |  | $ | 551 |  |
| Gross increases related to current year tax positions | 21 |  |  | 11 |  |  | 172 |  |
| Gross increases related to prior year tax positions | 46 |  |  | 35 |  |  | 8 |  |
| Gross decreases related to prior year tax positions | (20) |  |  | (4) |  |  | (24) |  |
| Settlements | (9) |  |  | (12) |  |  | (1) |  |
| Lapse of statute of limitations | (7) |  |  | (8) |  |  | (11) |  |
| Acquisitions | — |  |  | — |  |  | — |  |
| Unrecognized tax benefit, ending balance | $ | 748 |  |  | $ | 717 |  |  | $ | 695 |  |

[0000106040-21-000040:notes:313]
Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of July 2, 2021, July 3, 2020 and June 28, 2019 was $138 million, $137 million and $123 million, respectively. Included within long-term liabilities in the Consolidated Balance Sheets are the Company’s payables related to unrecognized tax benefits, including accrued interest and penalties, of $750 million, $720 million, and $699 million as of July 2, 2021, July 3, 2020 and June 28, 2019, respectively. The entire balance of the gross unrecognized tax benefits as of July 2, 2021, July 3, 2020 and June 28, 2019, if recognized, would affect the effective tax rate.

[0000106040-21-000040:notes:314]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for fiscal years 2013 through 2020. The Company is no longer subject to examination by the IRS for periods prior to 2012, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the major foreign jurisdictions where there is no tax holiday, the Company could be subject to examination in China for calendar years 2011 through 2020, in Ireland for calendar year 2015 through fiscal year 2020, in India for fiscal years 2008 through 2020, in Israel for calendar year 2016 through fiscal year 2020 and in Japan for fiscal years 2013 through 2020.

[0000106040-21-000040:notes:315]
As previously disclosed, the IRS issued statutory notices of deficiency with respect to adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The Company filed petitions with the U.S. Tax Court with respect to the statutory notices of deficiency for fiscal years 2008 through 2009 and the fiscal years 2010 through 2012. The U.S. Tax Court consolidated the case for fiscal years 2008 through 2009 with the case for fiscal years 2010 through 2012. In May 2020, the IRS filed with the U.S. Tax Court Amendments to Answer to assert penalties totaling $340 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2008 through 2012. In June 2021, the IRS filed with the U.S. Tax Court Second Amendments to Answer to assert additional adjustments relating to transfer pricing with the Company’s foreign subsidiaries for fiscal years 2008 through 2009 and fiscal years 2010 through 2012. The Second Amendments to Answer replace the amounts asserted in the statutory notices of deficiency. With its Second Amendments to Answer, the IRS seeks to increase the Company’s U.S. taxable income by amounts that would result in additional federal income tax liabilities totaling approximately $335 million for fiscal years 2008 through 2009 and approximately $922 million for fiscal years 2010 through 2012, subject to interest and the IRS’s claim for penalties. In September 2020 and December 2020, the IRS proposed adjustments relating to transfer pricing with the Company’s foreign subsidiaries and intercompany payable balances for fiscal years 2013 through 2015 that, if sustained, would result in additional federal income tax liabilities totaling approximately $343 million for those fiscal years. In March 2021, the IRS asserted penalties totaling $109 million on the proposed adjustments relating to transfer pricing with respect to fiscal years 2013 through 2015. The Company disagrees with the proposed adjustments relating to transfer pricing and related penalties, and continues to believe that its tax positions are properly supported and will vigorously contest the position taken by the IRS. Also in March 2021, the Company and the IRS tentatively reached a basis for resolving the intercompany payable balances matter for all fiscal years at issue and the impact was not material to the Consolidated Financial Statements.

[0000106040-21-000040:notes:316]
The Company believes that adequate provision has been made for any adjustments that may result from tax examinations. However, the outcome of tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of July 2, 2021, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information or settlements relating to the examination of the Company’s tax returns.


## us-gaap:SummaryOfOperatingLossCarryforwardsTextBlock

[0000106040-21-000040:notes:317]
Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-21-000040:notes:318]
The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:


## us-gaap:EarningsPerShareTextBlock

[0000106040-21-000040:notes:319]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-21-000040:notes:320]
|  |  |  | Year Ended |
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions, except per share data) |
| Net income (loss) |  |  |  |  | $ | 821 |  |  | $ | (250) |  |  | $ | (754) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 305 |  |  | 298 |  |  | 292 |  |
| Employee stock options, RSUs, PSUs and ESPP |  |  |  |  | 4 |  |  | — |  |  | — |  |
| Diluted |  |  |  |  | 309 |  |  | 298 |  |  | 292 |  |
| Income (loss) per common share |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 2.69 |  |  | $ | (0.84) |  |  | $ | (2.58) |  |
| Diluted |  |  |  |  | $ | 2.66 |  |  | $ | (0.84) |  |  | $ | (2.58) |  |
| Anti-dilutive potential common shares excluded |  |  |  |  | 5 |  |  | 15 |  |  | 17 |  |

[0000106040-21-000040:notes:321]
The Company computes basic income (loss) per common share using Net income (loss) and the Weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed using Net income (loss) and the Weighted average number of common shares and potentially dilutive common shares outstanding during the period. Potentially dilutive common shares include dilutive outstanding employee stock options, RSUs and PSUs, and rights to purchase shares of common stock under the Company’s ESPP. For 2021, the Company excluded common shares subject to outstanding equity awards from the calculation of diluted shares because their impact would have been anti-dilutive based on the Company’s average stock price during the period. For 2020 and 2019, the Company recorded net loss, and all shares subject to outstanding equity awards have been excluded for those periods because including them would be anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-21-000040:notes:322]
Employee Termination, Asset Impairment and Other Charges
The Company recorded the following charges related to employee termination benefits, asset impairment, and other charges:

[0000106040-21-000040:notes:323]
|  |  |  |  |  | 2021 |  | 2020 |  | 2019 |
|  |  |  |  |  | (in millions) |
| Employee termination and other charges: |  |  |  |  |  |  |  |  |  |
| Closure of Foreign Manufacturing Facilities |  |  |  |  | $ | — |  |  | $ | 5 |  |  | $ | 22 |  |
| Business Realignment |  |  |  |  | 28 |  |  | 44 |  |  | 144 |  |
| Total employee termination and other charges |  |  |  |  | 28 |  |  | 49 |  |  | 166 |  |
| Gain on disposition of assets: |  |  |  |  |  |  |  |  |  |
| Business Realignment |  |  |  |  | (75) |  |  | (17) |  |  | — |  |
| Total gain on disposition of assets |  |  |  |  | (75) |  |  | (17) |  |  | — |  |
| Total employee termination, asset impairment, and other charges |  |  |  |  | $ | (47) |  |  | $ | 32 |  |  | $ | 166 |  |

[0000106040-21-000040:notes:324]
Closure of Foreign Manufacturing Facilities

[0000106040-21-000040:notes:325]
In July 2018, the Company announced the closing of its HDD manufacturing facility in Kuala Lumpur, Malaysia, in order to reduce its manufacturing costs and consolidate HDD operations into Thailand. The Company substantially completed the closure in fiscal year 2019.

[0000106040-21-000040:notes:326]
Business Realignment

[0000106040-21-000040:notes:327]
The Company periodically incurs charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company may also record credits related to gains upon sale of property in connection with these activities. The Company recognized gains related to the disposition of assets associated with these activities $75 million and $17 million for 2021 and 2020, respectively.

[0000106040-21-000040:notes:328]
The following table presents an analysis of the components of the activity against the reserve during the year ended July 2, 2021:

[0000106040-21-000040:notes:329]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at July 3, 2020 | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Charges | 25 |  |  | 3 |  |  | 28 |  |
| Cash payments | (36) |  |  | (3) |  |  | (39) |  |
| Accrual balance at July 2, 2021 | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0000106040-21-000040:notes:330]
The Company recorded the following charges related to employee termination benefits, asset impairment, and other charges:


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-21-000040:notes:331]
Legal Proceedings
Tax

[0000106040-21-000040:notes:332]
For disclosures regarding statutory notices of deficiency issued by the IRS on June 28, 2018 and December 10, 2018, petitions filed by the Company with the U.S. Tax Court in September 2018 and March 2019, additional penalties asserted by the IRS in March 2021 and a tentative resolution with respect to certain matters, see Note 14, Income Tax Expense.

[0000106040-21-000040:notes:333]
Other Matters

[0000106040-21-000040:notes:334]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.
