# WDC MD&A — 0000106040-25-000038


## mdna

[0000106040-25-000038:mdna:1]
Item 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000106040-25-000038:mdna:2]
Our Company

[0000106040-25-000038:mdna:3]
We are a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology. We leverage our capability in the HDD industry primarily for the cloud and hyperscale data center markets. HDDs are critical components in the worldwide data infrastructure market, powering the digital economy. HDDs provide reliable, cost-effective, high-capacity storage needs for a wide range of applications, ranging from cloud data centers, enterprise storage systems, edge computing, video surveillance to client and consumer.

[0000106040-25-000038:mdna:4]
Our broad portfolio of technology and products addresses our customers’ storage needs through multiple end markets: “Cloud,” “Client” and “Consumer”. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0000106040-25-000038:mdna:5]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2026, ending on July 3, 2026 will be comprised of 53 weeks, with the first quarter consisting of 14 weeks. Fiscal years 2025, 2024, and 2023, which ended on June 27, 2025, June 28, 2024, and June 30, 2023, respectively, each comprised 52 weeks, with all quarters presented consisting of 13 weeks.

[0000106040-25-000038:mdna:6]
Key Developments

[0000106040-25-000038:mdna:7]
Separation of Business Units

[0000106040-25-000038:mdna:8]
On February 21, 2025 (the “Separation Date”), we completed the separation of our HDD and Flash business units (the “Separation”) to create two independent public companies, with Western Digital focusing on our existing HDD business and Sandisk Corporation (“Sandisk”), formerly a wholly-owned subsidiary of the Company, holding the Flash business. We believe the Separation better positions each business unit to execute innovative technology and product development, capitalize on unique growth opportunities, extend respective leadership positions, operate more efficiently with distinct capital structures, and pursue capital allocation strategies that maximize long-term shareholder value. The Separation was effected through a pro rata distribution of 80.1% of the outstanding shares of Sandisk common stock to holders of the Company’s common stock as of February 12, 2025, the record date for the distribution. The Company did not issue fractional shares of Sandisk common stock in connection with the distribution. Sandisk is now an independent public company, and Sandisk common stock commenced trading “regular way” under the symbol “SNDK” on the Nasdaq Stock Market LLC (“Nasdaq”) on February 24, 2025, which was the next trading day following the distribution date. The Company continues to trade on Nasdaq under the symbol “WDC” following the Separation. Following the Separation, the Company no longer consolidates Sandisk within the Company’s financial results. As part of the Separation, the Company retained 28.8 million shares of Sandisk common stock, or a 19.9% stake. During the quarter ended June 27, 2025, the Company disposed of 21.3 million shares of Sandisk common stock, along with $4 million in cash, in a tax-free exchange for $800 million principal amount of the Company’s term loan A-3. The Company expects to monetize its remaining stake in Sandisk within one year from the Separation Date.

[0000106040-25-000038:mdna:9]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation. See Part II, Item 8, Note 3, Discontinued Operations, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information regarding the Separation.

[0000106040-25-000038:mdna:10]
30

[0000106040-25-000038:mdna:11]
Macroeconomic Conditions

[0000106040-25-000038:mdna:12]
The United States has recently announced changes to its trade policy, including increasing tariffs on imports, in some cases significantly. Several of these recent tariff actions have been followed by announcements of limited exemptions and temporary pauses. These actions have caused substantial uncertainty and have also resulted in retaliatory measures on U.S. goods. Our business and results of operations were not materially impacted in fiscal 2025 as a result of the recent tariff actions. We are actively monitoring developments and plan to leverage tariff exemptions where possible and will take other actions as appropriate to offset any resulting increase in the cost of importing our products or the costs for materials or components in our products, including optimizing our supply chain, sourcing from alternative suppliers, or passing the costs to our customers through tariff surcharges, or increased prices. There can be no assurance that we will be able to successfully offset or mitigate any resulting increase in our costs. In addition, the impact of the tariff actions on our customers, retaliatory measures by other countries in response to U.S. trade policy and any resulting decline in consumer confidence, significant inflation and diminished expectations for the economy could reduce demand for our products and adversely affect our business, financial condition and results of operations. For additional information, please see Part I, Item 1A, Risk Factors, included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:13]
Operational Update

[0000106040-25-000038:mdna:14]
In fiscal 2025, we saw an improvement in the supply and demand dynamic relative to the prior year, and we anticipate that digital transformation, including the AI data-cycle, will drive improved market conditions in the long term. However, macroeconomic factors such as tariffs, inflation, changes in interest rates, and recession concerns can affect demand for our products. As an example, in fiscal 2024, we and our industry experienced a supply-demand imbalance, which led to reduced shipments, negatively impacted pricing, and resulted in business realignment charges and charges for unabsorbed manufacturing overhead costs due to the underutilization of facilities as we temporarily scaled back production and took other actions to align our operations to the market at the time.

[0000106040-25-000038:mdna:15]
We will continue to actively monitor developments impacting our business and may take future responsive actions that we determine to be in the best interest of our business and stakeholders.

[0000106040-25-000038:mdna:16]
Capital Allocation Actions

[0000106040-25-000038:mdna:17]
We have taken significant actions to deleverage our business and to initiate programs to return capital to our investors.

[0000106040-25-000038:mdna:18]
In February 2025, in connection with the Separation, we amended the loan agreement governing our revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”) and Term Loan Facility (as defined below), dated as of January 7, 2022 (as amended, the “Loan Agreement”) to, among other changes, permit the Separation, provide for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a noncash exchange to replace our previously existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”); facilitate a subsequent exchange of a portion of the Term Loan A-3 for shares of Sandisk retained by us at the Separation; and reduce the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion.

[0000106040-25-000038:mdna:19]
In April 2025, we redeemed, at our election, $1.80 billion aggregate principal amount of our 4.75% senior unsecured notes due 2026 (the “2026 Notes”) at par plus accrued interest.

[0000106040-25-000038:mdna:20]
In June 2025, we settled $800 million principal amount of our Term Loan A-3 through an exchange of 21.3 million shares of Sandisk common stock held by us and $4 million in cash paid by us.

[0000106040-25-000038:mdna:21]
These actions, along with scheduled principal payments made on our term loans, reduced the principal amount of our debt by $2.78 billion during fiscal 2025.

[0000106040-25-000038:mdna:22]
On April 29, 2025, our Board of Directors authorized the adoption of a quarterly cash dividend program. Under the cash dividend program, holders of our common stock will receive dividends when and as declared by our Board of Directors. During the year ended June 27, 2025, we paid cash dividends of $0.10 per share of our outstanding common stock, totaling $36 million, including payment to holders of our Series A Preferred Stock in accordance with their participation rights.

[0000106040-25-000038:mdna:23]
Subsequent to year-end, on July 29, 2025, our Board of Directors declared a cash dividend of $0.10 per share of our common stock, which will be paid on September 18, 2025 to our shareholders of record as of the close of business on September 4, 2025.

[0000106040-25-000038:mdna:24]
31

[0000106040-25-000038:mdna:25]
On May 9, 2025, our Board of Directors authorized a share repurchase program for the repurchase of up to $2.0 billion of our common stock. For the year ended June 27, 2025, we repurchased 2.8 million shares for a total cost of $149 million. The remaining amount available to be repurchased under our share repurchase program as of June 27, 2025 was $1.85 billion. Repurchases under the share repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. We expect share repurchases to be funded principally by operating cash flows.

[0000106040-25-000038:mdna:26]
Information regarding our indebtedness, including the principal repayment terms, interest rates, covenants and other key terms of our outstanding indebtedness, and additional information on the terms of our convertible preferred shares is included in Part II, Item 8, Note 8, Debt, and Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:27]
Tax Resolution

[0000106040-25-000038:mdna:28]
As previously disclosed, we had reached a final agreement with the U.S. Internal Revenue Service (the “IRS”) and received notices of deficiency with respect to years 2008 through 2012, and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the year ended June 27, 2025, we made payments aggregating to $162 million for tax and interest with respect to years 2008 through 2015 and have no remaining liability as of June 27, 2025 related to all years from 2008 through 2015. Additional information regarding these settlements and related tax matters is provided in Part II, Item 8, Note 13, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:29]
32

[0000106040-25-000038:mdna:30]
Results of Operations

[0000106040-25-000038:mdna:31]
Summary Comparison of 2025, 2024 and 2023

[0000106040-25-000038:mdna:32]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0000106040-25-000038:mdna:33]
|  |  |  |  |  |  |  |  |  | 2025 |  | 2024 |  |  |  | 2023 |
|  |  |  | (in millions, except percentages) |
| Revenue, net |  |  |  |  |  |  |  |  |  |  |  |  | $ | 9,520 |  |  | 100.0 | % |  | $ | 6,317 |  |  | 100.0 | % |  |  |  | $ | 6,255 |  |  | 100.0 | % |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  | 5,828 |  |  | 61.2 |  |  | 4,544 |  |  | 71.9 |  |  |  |  | 4,864 |  |  | 77.8 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |  | 3,692 |  |  | 38.8 |  |  | 1,773 |  |  | 28.1 |  |  |  |  | 1,391 |  |  | 22.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  |  |  | 994 |  |  | 10.4 |  |  | 950 |  |  | 15.0 |  |  |  |  | 986 |  |  | 15.8 |  |
| Selling, general and administrative |  |  |  |  |  |  |  |  |  |  |  |  | 568 |  |  | 6.0 |  |  | 726 |  |  | 11.5 |  |  |  |  | 807 |  |  | 12.9 |  |
| Litigation matter |  |  |  |  |  |  |  |  |  |  |  |  | (198) |  |  | (2.1) |  |  | 291 |  |  | 4.6 |  |  |  |  | — |  |  | — |  |
| Business realignment charges |  |  |  |  |  |  |  |  |  |  |  |  | (6) |  |  | (0.1) |  |  | 209 |  |  | 3.3 |  |  |  |  | 146 |  |  | 2.3 |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  |  |  | 1,358 |  |  | 14.3 |  |  | 2,176 |  |  | 34.4 |  |  |  |  | 1,939 |  |  | 31.0 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  | 2,334 |  |  | 24.5 |  |  | (403) |  |  | (6.4) |  |  |  |  | (548) |  |  | (8.8) |  |
| Interest and other income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  |  |  |  |  |  |  |  |  |  |  | 45 |  |  | 0.5 |  |  | 33 |  |  | 0.5 |  |  |  |  | 19 |  |  | 0.3 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  |  | (357) |  |  | (3.8) |  |  | (414) |  |  | (6.6) |  |  |  |  | (310) |  |  | (5.0) |  |
| Loss on retained interest in Sandisk |  |  |  |  |  |  |  |  |  |  |  |  | (772) |  |  | (8.1) |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  |  |  |  |  | (100) |  |  | (1.1) |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Other income (expense), net |  |  |  |  |  |  |  |  |  |  |  |  | (20) |  |  | (0.2) |  |  | 45 |  |  | 0.7 |  |  |  |  | (10) |  |  | (0.2) |  |
| Total interest and other income, net |  |  |  |  |  |  |  |  |  |  |  |  | (1,204) |  |  | (12.6) |  |  | (336) |  |  | (5.3) |  |  |  |  | (301) |  |  | (4.8) |  |
| Income (loss) before taxes |  |  |  |  |  |  |  |  |  |  |  |  | 1,130 |  |  | 11.9 |  |  | (739) |  |  | (11.7) |  |  |  |  | (849) |  |  | (13.6) |  |
| Income tax expense (benefit) |  |  |  |  |  |  |  |  |  |  |  |  | (513) |  |  | (5.4) |  |  | 26 |  |  | 0.4 |  |  |  |  | 53 |  |  | 0.8 |  |
| Net income (loss) from continuing operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,643 |  |  | 17.3 | % |  | $ | (765) |  |  | (12.1) | % |  |  |  | $ | (902) |  |  | (14.4) | % |

[0000106040-25-000038:mdna:34]
(1)Percentages may not total due to rounding.

[0000106040-25-000038:mdna:35]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0000106040-25-000038:mdna:36]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |  |  |
| Cloud |  |  |  |  | $ | 8,341 |  |  | $ | 5,052 |  |  | $ | 4,753 |  |
| Client |  |  |  |  | 556 |  |  | 577 |  |  | 691 |  |
| Consumer |  |  |  |  | 623 |  |  | 688 |  |  | 811 |  |
| Total revenue |  |  |  |  | $ | 9,520 |  |  | $ | 6,317 |  |  | $ | 6,255 |  |
| Revenue by geography |  |  |  |  |  |  |  |  |  |
| Americas |  |  |  |  | $ | 4,592 |  |  | $ | 2,858 |  |  | $ | 2,924 |  |
| Asia |  |  |  |  | 3,392 |  |  | 2,392 |  |  | 2,156 |  |
| Europe, Middle East and Africa |  |  |  |  | 1,536 |  |  | 1,067 |  |  | 1,175 |  |
| Total revenue |  |  |  |  | $ | 9,520 |  |  | $ | 6,317 |  |  | $ | 6,255 |  |
| Exabytes shipped |  |  |  |  | 696 |  |  | 443 |  |  | 412 |  |

[0000106040-25-000038:mdna:37]
33

[0000106040-25-000038:mdna:38]
Net Revenue

[0000106040-25-000038:mdna:39]
Net revenue increased by 51% in 2025 compared to 2024, primarily driven by a 29% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives. The increase was also driven by a 15% increase in units sold as a result of higher shipments of our high-capacity enterprise products stemming from data center expansions.

[0000106040-25-000038:mdna:40]
Cloud revenue increased by 65% in 2025 compared to 2024, primarily driven by a 36% increase in units sold and a 20% increase in average selling price per unit. The increase in units sold was driven by higher shipments of our high-capacity enterprise products. The increase in average selling price per unit was primarily due to a shift in product mix to higher capacity drives.

[0000106040-25-000038:mdna:41]
Client revenue decreased by 4% in 2025 compared to 2024, primarily driven by a 16% decrease in units sold, reflecting lower demand in the market, partially offset by a 14% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives.

[0000106040-25-000038:mdna:42]
Consumer revenue decreased by 9% in 2025 compared to 2024, primarily driven by a 14% decrease in units sold, reflecting lower demand in the market, partially offset by a 5% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives.

[0000106040-25-000038:mdna:43]
Net revenue increased by 1% in 2024 compared to 2023, primarily driven by a 25% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives, partially offset by a 13% decrease in units sold reflecting lower demand in the market. The increase was offset by approximately 7 percentage points due to a decline in data storage systems revenues resulting from weakness in the market.

[0000106040-25-000038:mdna:44]
Cloud revenue increased by 6% in 2024 compared to 2023, primarily driven by a 1% increase in units sold and a 16% increase in average selling price per unit. The changes in units sold and average selling price per unit were primarily due to customers moving to higher capacity drives. The increase was offset by approximately 9 percentage points due to a decline in data storage systems revenues resulting from weakness in the market.

[0000106040-25-000038:mdna:45]
Client revenue decreased by 17% in 2024 compared to 2023, primarily driven by a 30% decrease in units sold, reflecting lower demand in the market, partially offset by a 19% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives.

[0000106040-25-000038:mdna:46]
Consumer revenue decreased by 15% in 2024 compared to 2023, primarily driven by a 25% decrease in units sold, reflecting lower demand in the market, partially offset by a 13% increase in average selling price per unit as a result of a shift in product mix to higher capacity drives.

[0000106040-25-000038:mdna:47]
For 2025, 2024 and 2023, our top 10 customers accounted for 68%, 55% and 56%, respectively, of our net revenue. For 2025, three customers accounted for 17%, 12%, and 10%, respectively, of our net revenue. For 2024 and 2023, no single customer accounted for 10% or more of our net revenue.

[0000106040-25-000038:mdna:48]
Consistent with standard industry practice, we have sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For 2025, 2024 and 2023, these programs represented 10%, 11% and 18%, respectively, of gross revenue. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0000106040-25-000038:mdna:49]
Gross Profit and Gross Margin

[0000106040-25-000038:mdna:50]
Gross profit increased by $1.92 billion in 2025 compared to 2024. The increase was largely due to higher revenues, cost reductions due to efficiencies achieved through improved manufacturing operations, cost-saving actions, and a more favorable product mix. The increase also reflected charges for unabsorbed manufacturing overhead of approximately $155 million in 2024 which were not incurred in 2025. Gross margin increased 10.7 percentage points in 2025 compared to 2024, with approximately 2.5 percentage points of the increase due to the impact of unabsorbed manufacturing overhead costs in the prior year and the remainder driven by the factors as noted above.

[0000106040-25-000038:mdna:51]
Gross profit increased by $382 million in 2024 compared to 2023. The increase was largely due to cost efficiencies achieved through improved manufacturing operations, cost-saving actions, and a more favorable product mix. The increase also reflected a reduction in charges for unabsorbed manufacturing overhead costs as a result of the reduced utilization of our manufacturing capacity to approximately $155 million in 2024, from approximately $200 million of such costs in 2023. Gross margin increased 5.9 percentage points in 2024 compared to 2023, with approximately 1 percentage point of the increase due to the reduction in unabsorbed manufacturing overhead costs from the prior year and the remainder driven by the factors as noted above.

[0000106040-25-000038:mdna:52]
Operating Expenses

[0000106040-25-000038:mdna:53]
Research and development (“R&D”) expense increased by $44 million or 5% in 2025 compared to 2024. This increase was primarily driven by a $46 million increase in costs for compensation and benefits, which was attributed to an increase in headcount in support of our technology and product roadmap. This increase was partially offset by a decrease in depreciation and amortization.

[0000106040-25-000038:mdna:54]
R&D expense decreased by $36 million or 4% in 2024 compared to 2023. This decrease was driven by relatively equal decreases in depreciation and amortization and in outside services as we scaled back expenditures in response to market conditions.

[0000106040-25-000038:mdna:55]
Selling, general and administrative (“SG&A”) expense decreased by $158 million or 22% in 2025 compared to 2024. This decrease was primarily driven by a $122 million decrease in costs for compensation and benefits, which was attributed to certain shared overhead roles in the prior year that have since transferred to Sandisk and were not backfilled after the Separation. The decrease also reflects a $38 million decrease in strategic review costs incurred in the prior year but not incurred in the current year.

[0000106040-25-000038:mdna:56]
SG&A expense decreased by $81 million or 10% in 2024 compared to 2023. This decrease was primarily driven by a $37 million decrease in costs for compensation and benefits, attributed to a decrease in headcount, a $19 million decrease in outside services and various smaller savings as we scaled back expenditures in response to market conditions.

[0000106040-25-000038:mdna:57]
For information regarding litigation matters, see Part II Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:58]
For information regarding Business realignment charges, see Part II Item 8, Note 15, Business Realignment Charges, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:59]
Interest and Other Expense

[0000106040-25-000038:mdna:60]
Total interest and other expense, net increased by $868 million or 258% in 2025 compared to 2024, primarily reflecting a $772 million mark-to-market loss on our retained interest in Sandisk and a $100 million loss on the extinguishment of debt in connection with the debt-for-equity exchange. The increase was partially offset by lower interest expense driven by lower debt balances.

[0000106040-25-000038:mdna:61]
Total interest and other expense, net increased by $35 million or 12% in 2024 compared to 2023. The increase primarily reflects higher interest rates and higher outstanding debt balances in the period.

[0000106040-25-000038:mdna:62]
Income Tax Expense (Benefit)

[0000106040-25-000038:mdna:63]
Previously, the Tax Cuts and Jobs Act of 2017 (“TCJA”) eliminated the ability to deduct R&D expenditures in the year incurred, requiring capitalization and amortization under Internal Revenue Code Section 174. On July 4, 2025, the One Big Beautiful Bill Act of 2025 (“OBBBA”) was signed into law, which includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with our fiscal year 2026. The legislation also includes favorable modifications to international tax provisions, including changes to the Global Intangible Low-Taxed Income regime and enhancements to the Foreign-Derived Intangible Income deduction. Because the OBBBA provisions are not effective for us until fiscal year 2026 and the enactment date occurred after the balance sheet date, the tax effects of the OBBBA are not included in the Company’s operating results for the fiscal year ended June 27, 2025.

[0000106040-25-000038:mdna:64]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The CAMT became effective for us beginning with fiscal year 2024. We were not subject to CAMT in fiscal year 2024 and do not expect to be subject to CAMT for fiscal year 2025 as our average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0000106040-25-000038:mdna:65]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”), some of which are effective for us in fiscal year 2025. For fiscal year 2025, we currently expect to be able to meet certain transitional safe harbors and do not expect any material GMT taxes. As most of the jurisdictions in which we operate have adopted this legislation for our fiscal year 2026, we expect there will be increases in our future tax obligations in these jurisdictions.

[0000106040-25-000038:mdna:66]
The following table sets forth Income tax information from our Consolidated Statements of Operations by dollar and effective tax rate:

[0000106040-25-000038:mdna:67]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  | (in millions, except percentages) |
| Income (loss) before taxes |  |  |  |  | $ | 1,130 |  |  | $ | (739) |  |  | $ | (849) |  |
| Income tax expense (benefit) |  |  |  |  | (513) |  |  | 26 |  |  | 53 |  |
| Effective tax rate |  |  |  |  | (45) | % |  | (4) | % |  | (6) | % |

[0000106040-25-000038:mdna:68]
The primary drivers of the difference between the effective tax rate for fiscal year 2025 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in the Philippines and Thailand that will expire at various dates during 2026 through 2033. These resulted in decreases to our effective tax rate below the U.S. Federal statutory rate for fiscal year 2025. In anticipation of us operating as a standalone HDD business in a GMT environment, we executed an inter-entity asset transfer in conjunction with the Separation. This resulted in the recognition of one-time deferred tax benefits to continuing operations of $690 million. Our income before tax is reduced by a loss in our retained interest in Sandisk. This loss is not deductible for tax purposes and provides no income tax benefit to us.

[0000106040-25-000038:mdna:69]
The primary drivers of the difference between the effective tax rate for fiscal year 2024 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in the Philippines and Thailand. On November 1, 2023, our tax holiday in Malaysia expired. We have applied for an extension and continue to be engaged in active discussions with the Malaysian Investment Development Authority. Because the exact terms of an extension are not currently known, we are applying the Malaysia corporate statutory tax rate on our Malaysian income for the full fiscal year. If an extension is granted, we will make an adjustment to our effective tax rate in that period.

[0000106040-25-000038:mdna:70]
The primary drivers of the difference between the effective tax rate for fiscal year 2023 and the U.S. Federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the deduction for foreign derived intangible income, credits, and tax holidays in Malaysia, the Philippines and Thailand.

[0000106040-25-000038:mdna:71]
36

[0000106040-25-000038:mdna:72]
While we do not expect to be subject to the CAMT in fiscal year 2026, the potential benefits from the OBBBA changes could be partially offset in future periods by CAMT, which is designed to ensure that large corporations pay a minimum level of tax by applying a 15% tax on financial statement income rather than taxable income. This may result in a higher effective tax rate and impact the realizability of our deferred tax assets in future periods. We continue to assess how these new rules and future regulatory guidance may affect our tax rate, financial reporting, and long-term tax strategy.

[0000106040-25-000038:mdna:73]
For additional information regarding Income tax expense, see Part II, Item 8, Note 13, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:74]
37

[0000106040-25-000038:mdna:75]
Liquidity and Capital Resources

[0000106040-25-000038:mdna:76]
The following table summarizes our statements of cash flows, which are presented on a consolidated basis. Cash flows related to discontinued operations have not been segregated. See Part II, Item 8, Note 3, Discontinued Operations, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional cash flow information related to our discontinued operations.

[0000106040-25-000038:mdna:77]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 1,691 |  |  | $ | (294) |  |  | $ | (408) |  |
| Investing activities | 150 |  |  | (27) |  |  | (762) |  |
| Financing activities | (1,612) |  |  | 187 |  |  | 875 |  |
| Effect of exchange rate changes on cash | 6 |  |  | (10) |  |  | (9) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 235 |  |  | $ | (144) |  |  | $ | (304) |  |

[0000106040-25-000038:mdna:78]
We had previously reached a final agreement with the IRS and received notices of deficiency with respect to years 2008 through 2012, and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the year ended June 27, 2025, we made payments of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of June 27, 2025 related to all years from 2008 through 2015.

[0000106040-25-000038:mdna:79]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to $166 million. Of this amount, $65 million of interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules. See Part II, Item 8, Note 13, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for further details.

[0000106040-25-000038:mdna:80]
In August 2024, we filed a shelf registration statement (the “Shelf Registration Statement”) with the Securities and Exchange Commission that expires in August 2027. The Shelf Registration Statement allows us to offer and sell shares of common stock, preferred stock, warrants, and debt securities. We may use the Shelf Registration Statement or other capital sources, including other offerings of equity or debt securities or the credit markets, to satisfy future financing needs, including planned or unanticipated capital expenditures, investments, debt repayments or other expenses. Any such additional financing will be subject to market conditions and may not be available on terms acceptable to us or at all.

[0000106040-25-000038:mdna:81]
As a result of the Separation, we no longer have any capital expenditure requirements for the Flash business or its joint ventures with Kioxia Corporation. We expect our capital expenditures for fiscal year 2026 to be between 4% to 6% of our net revenue.

[0000106040-25-000038:mdna:82]
We believe our cash and cash equivalents and our available 2027 Revolving Credit Facility will be sufficient to meet our working capital, debt, dividend and capital expenditure needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various debt and equity capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A, Risk Factors, in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:83]
A total of $0.98 billion and $1.43 billion of our cash and cash equivalents were held outside of the U.S. as of June 27, 2025 and June 28, 2024, respectively. There are no material tax consequences that were not previously accrued for on the repatriation of this cash.

[0000106040-25-000038:mdna:84]
Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities. In addition, from time to time, we also invest directly in certificates of deposit, asset-backed securities and corporate and municipal notes and bonds.

[0000106040-25-000038:mdna:85]
Operating Activities

[0000106040-25-000038:mdna:86]
Net cash provided by or used in operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used for changes in operating assets and liabilities was $1.03 billion for 2025, as compared to $307 million of net cash used for such changes for 2024, which largely reflects an increase in net operating assets and liabilities resulting from the increase in the volume of our business as well as the timing and amount of tax payments. Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on our volume of business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. At the end of the respective fourth quarters, the cash conversion cycles were as follows (in days):

[0000106040-25-000038:mdna:87]
|  | 2025 |  | 2024 |  | 2023 |
| Days sales outstanding | 52 |  |  | 56 |  |  | 56 |  |
| Days in inventory | 76 |  |  | 97 |  |  | 107 |  |
| Days payables outstanding | (75) |  |  | (73) |  |  | (66) |  |
| Cash conversion cycle | 53 |  |  | 80 |  |  | 97 |  |

[0000106040-25-000038:mdna:88]
Changes in days sales outstanding (“DSO”) are generally due to the timing of shipments to and collections from customers. Changes in days in inventory (“DIO”) are generally related to the timing of inventory builds and shipments to customers. Changes in days payables outstanding (“DPO”) are generally related to production volume and the timing of purchases during the period. From time to time, we make payment term modifications with vendors through negotiations with them or by granting to, or receiving from, our vendors payment term accommodations. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances.

[0000106040-25-000038:mdna:89]
In 2025, DSO decreased by 4 days over the prior year, reflecting timing of shipments and customer collections. DIO decreased by 21 days over the prior year, primarily reflecting improvements in inventory management. DPO increased by 2 days over the prior year, primarily due to more favorable payment terms and routine variations in the timing of purchases and payments during the period.

[0000106040-25-000038:mdna:90]
Investing Activities

[0000106040-25-000038:mdna:91]
Net cash provided by investing activities in 2025 primarily consisted of $401 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $148 million in net notes receivable proceeds from Flash Ventures, partially offset by $412 million in capital expenditures. Net cash used in investing activities in 2024 primarily consisted of $487 million of capital expenditures, partially offset by $239 million in net notes receivable proceeds from Flash Ventures and $195 million in proceeds from the sale-leaseback of property, plant and equipment.

[0000106040-25-000038:mdna:92]
Financing Activities

[0000106040-25-000038:mdna:93]
During 2025, net cash used in financing activities primarily consisted of $2.09 billion used for the partial repayment of the 2026 Notes, repayment of borrowings on the 2027 Revolving Credit Facility, and scheduled principal payments on our Term Loan A-2 and Term Loan A-3; $1.37 billion of cash transferred to Sandisk at the Separation; $149 million in share repurchases; $113 million for taxes paid on vested stock awards; $73 million in debt issuance costs; and $44 million in dividends on our common stock and our Series A Preferred Stock. These uses were partially offset by $2.00 billion of proceeds from drawing on the Sandisk credit facilities in connection with the Separation, $150 million from the 2027 Revolving Credit Facility, and $77 million from issuances of shares under our employee stock plans. During 2024, net cash provided by financing activities primarily consisted of $3.00 billion in proceeds from the issuance of the 2028 Convertible Notes, the drawdown of a delayed draw term loan and draws on the revolving credit facility. These sources were partially offset by $2.10 billion used for the repayment of draws on the revolving credit facility, repayments of a delayed draw term loan, scheduled payments on the Term Loan A-2, and settlement of our remaining 1.50% convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”); $505 million used to repurchase a portion of the 2024 Convertible Notes; and $155 million for the purchase of capped calls to hedge the potential dilution impact of the conversion feature of the 2028 Convertible Notes.

[0000106040-25-000038:mdna:94]
A discussion of our cash flows for 2023, including a comparison of such cash flows to 2024, is included in Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations – Liquidity and Capital Resources, included in our Annual Report on Form 10-K for the year ended June 28, 2024 filed with the SEC on August 20, 2024.

[0000106040-25-000038:mdna:95]
Off-Balance Sheet Arrangements

[0000106040-25-000038:mdna:96]
Other than certain indemnification provisions (see “Short- and Long-term Liquidity – Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligation arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, we do not have an interest in, or relationships with, any variable interest entities.

[0000106040-25-000038:mdna:97]
40

[0000106040-25-000038:mdna:98]
Short- and Long-term Liquidity

[0000106040-25-000038:mdna:99]
Material Cash Requirements

[0000106040-25-000038:mdna:100]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of June 27, 2025. In addition, see the discussions further below related to unrecognized tax benefits, litigation matters, cash dividend program, dividend rights with respect to the Series A Preferred Stock, foreign exchange contracts and indemnifications.

[0000106040-25-000038:mdna:101]
|  | Total |  | 1 Year (2026) |  | 2-3 Years (2027-2028) |  | 4-5 Years (2029-2030) |  | More than 5 Years (Beyond 2030) |
|  | (in millions) |
| Long-term debt, including current portion(1) | $ | 4,749 |  |  | $ | 2,226 |  |  | $ | 1,523 |  |  | $ | 500 |  |  | $ | 500 |  |
| Interest on debt | 507 |  |  | 203 |  |  | 204 |  |  | 69 |  |  | 31 |  |
| Operating leases | 165 |  |  | 36 |  |  | 53 |  |  | 30 |  |  | 46 |  |
| Purchase obligations and other commitments | 76 |  |  | 50 |  |  | 26 |  |  | — |  |  | — |  |
| Mandatory deemed repatriation tax | 331 |  |  | 331 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 5,828 |  |  | $ | 2,846 |  |  | $ | 1,806 |  |  | $ | 599 |  |  | $ | 577 |  |

[0000106040-25-000038:mdna:102]
(1)Principal portion of debt, excluding issuance costs.

[0000106040-25-000038:mdna:103]
Unrecognized Tax Benefits

[0000106040-25-000038:mdna:104]
As of June 27, 2025, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $569 million. Accrued interest and penalties related to unrecognized tax benefits are recognized in liabilities for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties related to unrecognized tax benefits as of June 27, 2025, were approximately $82 million. Of these amounts, approximately $498 million could result in potential cash payments, of which $332 million is reasonably expected to be paid within the next twelve months. This potential cash payment is expected to be netted with offsetting favorable tax receivables totaling $148 million, including a reduction to our mandatory deemed repatriation tax obligations related to the settlement for the years 2008 through 2015, for a potential net cash payment of $184 million.

[0000106040-25-000038:mdna:105]
As noted above, we had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, we also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the year ended June 27, 2025, we made payments of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of June 27, 2025 related to all years from 2008 through 2015.

[0000106040-25-000038:mdna:106]
In connection with settlements for the years 2008 through 2015, we expect to realize reductions to our mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $166 million. Of this amount, $65 million of interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules. See Part II, Item 8, Note 13, Income Taxes of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:107]
Litigation Matters

[0000106040-25-000038:mdna:108]
For additional information on our litigation matters, see Part II, Item 8, Note 17, Legal Proceedings, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:109]
Cash Dividend Program

[0000106040-25-000038:mdna:110]
On April 29, 2025, our Board of Directors authorized the adoption of a quarterly cash dividend program. Under the cash dividend program, holders of our common stock will receive dividends when and as declared by our Board of Directors. During the year ended June 27, 2025, we paid cash dividends of $0.10 per share of our outstanding common stock, totaling $36 million, including payment to holders of our Series A Preferred Stock in accordance with their participation rights.

[0000106040-25-000038:mdna:111]
Subsequent to year-end, on July 29, 2025, our Board of Directors declared a cash dividend of $0.10 per share of our common stock, which will be paid on September 18, 2025 to our shareholders of record as of the close of business on September 4, 2025.

[0000106040-25-000038:mdna:112]
We may modify, suspend, or cancel our cash dividend program in any manner and at any time. The amount of future dividends under our cash dividend program, and the declaration and payment thereof, will be based upon all relevant factors, including our financial position, results of operations, cash flows, capital requirements and restrictions under our Loan Agreement and other financing agreements, and shall be in compliance with applicable law.

[0000106040-25-000038:mdna:113]
Dividend Rights

[0000106040-25-000038:mdna:114]
As of June 27, 2025, 235,000 shares of our Series A Preferred Stock remained outstanding. These shares are entitled to cumulative preferred dividends and will also participate in any dividends declared for common shareholders on an as-converted equivalent basis. See Part II, Item 8, Note 12, Shareholders’ Equity and Convertible Preferred Stock, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for more information regarding these dividend provisions.

[0000106040-25-000038:mdna:115]
Debt

[0000106040-25-000038:mdna:116]
As described in “Key Developments – Capital Allocation Actions” above, we undertook several financing actions during 2025, including the amendment of our Credit Facility in connection with the Separation and the exchange of a portion of our retained interest in Sandisk shares to reduce a portion of our TLA-3 loan balance.

[0000106040-25-000038:mdna:117]
The Company issued $1.60 billion aggregate principal amount of convertible senior notes in November 2023, which bear interest at an annual rate of 3.00% and mature on November 15, 2028 (the “2028 Convertible Notes”). The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028 at a conversion price of approximately $37.82 per share of common stock (which conversion price has been adjusted from approximately $52.20 in accordance with the indenture as a result of the Separation). Prior to August 15, 2028, if the trading price of our common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, we will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of our common stock or a combination thereof, at our election, in respect of the remainder, if any, of our conversion obligation in excess of the aggregate principal amount of the notes being converted.

[0000106040-25-000038:mdna:118]
The sale price conditional conversion feature of the 2028 Convertible Notes was triggered during the calendar quarter ended June 30, 2025 and, accordingly, the holders of the 2028 Convertible Notes have the right to convert the notes during the succeeding calendar quarter ending September 30, 2025. As a result, the 2028 Convertible Notes were classified as Short-term debt in the Consolidated Financial Statements as of June 27, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

[0000106040-25-000038:mdna:119]
In addition to our outstanding debt, as of June 27, 2025, we had $1.25 billion available for borrowing under our revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”), subject to customary conditions under the Loan Agreement. The agreements governing our credit facilities each include limits on secured indebtedness and certain types of unsecured subsidiary indebtedness and require us and certain of our subsidiaries to provide guarantees and collateral to the extent the conditions providing for such guarantees and collateral are met. The loan agreement governing our 2027 Revolving Credit Facility and our Term Loan A-3 (as amended, the “Loan Agreement”) requires us to comply with a financial leverage ratio covenant. As of June 27, 2025, we were in compliance with the financial covenant. Additional information regarding our indebtedness, including information about availability under our 2027 Revolving Credit Facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8, Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:120]
In connection with the Separation, we entered into an amendment with our existing lenders under the Loan Agreement governing our Term Loan Facility and the 2027 Revolving Credit Facility that, among other changes, (a) permitted the Separation, (b) provided for the automatic release, in connection with the Separation, of guarantees and liens on collateral provided by Sandisk and Sandisk Technologies, Inc. under the Loan Agreement, (c) provided for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a non-cash exchange to replace our previously

[0000106040-25-000038:mdna:121]
existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”), (d) facilitated the debt for equity exchange with respect to the Term Loan A-3 in connection with the Sandisk retained interest, and (e) in connection with the Separation, reduced the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion. In June 2025, we settled $800 million of the Term Loan A-3 principal amount, through a non-cash exchange of 21.3 million shares of Sandisk common stock held by us, and a $4 million cash payment.

[0000106040-25-000038:mdna:122]
We may issue additional debt securities in the future that may be guaranteed by our 100% owned domestic subsidiary, Western Digital Technologies, Inc. (“Guarantor” and, together with Western Digital Corporation, the “Obligor Group”). Such guarantees may be full and unconditional, joint and several, on a secured or unsecured, subordinated or unsubordinated basis, and may be subject to certain customary guarantor release conditions. We conduct operations almost entirely through our subsidiaries. Accordingly, the Obligor Group’s cash flow and ability to service any guaranteed registered debt securities will depend on the earnings of our subsidiaries and the distribution of those earnings to the Obligor Group, including the earnings of the non-guarantor subsidiaries, whether by dividends, loans or otherwise. Holders of such guaranteed registered debt securities would have a direct claim only against the Obligor Group.

[0000106040-25-000038:mdna:123]
The following tables include summarized financial information for the Obligor Group. The financial information for the Obligor Group is presented on combined basis, excluding intercompany balances and transactions between the Company and the Guarantor, excluding net intercompany balances between the Obligor Group and non-guarantor subsidiaries, and excluding investments in and equity in the earnings of non-guarantor subsidiaries. The Obligor Group’s amounts due from, amounts due to, and transactions with non-guarantor subsidiaries have been presented in separate line items in the tables below.

[0000106040-25-000038:mdna:124]
The assets and liabilities of the Obligor Group include the following:

[0000106040-25-000038:mdna:125]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Current assets | $ | 2,992 |  |  | $ | 2,149 |  |
| Non-current assets | 4,553 |  |  | 2,208 |  |
| Net intercompany receivables from (payables to) non-guarantor subsidiaries | (1,543) |  |  | 2,473 |  |
| Current liabilities | 3,800 |  |  | 3,758 |  |
| Non-current liabilities | 2,873 |  |  | 6,626 |  |

[0000106040-25-000038:mdna:126]
The operating results of the Obligor Group include the following:

[0000106040-25-000038:mdna:127]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Net sales | $ | 5,249 |  |  | $ | 4,066 |  |
| Gross profit | 1,941 |  |  | 1,002 |  |
| Operating income (loss) | 279 |  |  | (927) |  |
| Net income (loss) | (320) |  |  | (1,211) |  |

[0000106040-25-000038:mdna:128]
Results for the Obligor Group include the following transactions with non-guarantor subsidiaries:

[0000106040-25-000038:mdna:129]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Intercompany revenue | $ | 1,378 |  |  | $ | 1,416 |  |
| Net intercompany interest (income) expense | (4) |  |  | 8 |  |
| Intercompany dividend income | 2,215 |  |  | 567 |  |

[0000106040-25-000038:mdna:130]
Purchase Obligations and Other Commitments

[0000106040-25-000038:mdna:131]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0000106040-25-000038:mdna:132]
Mandatory Deemed Repatriation Tax

[0000106040-25-000038:mdna:133]
As of June 27, 2025, our final estimated mandatory deemed repatriation tax obligation is $331 million and is expected to be paid within the next twelve months.

[0000106040-25-000038:mdna:134]
Mandatory Research and Development Expense Capitalization

[0000106040-25-000038:mdna:135]
Since the beginning of 2023, we have been required to capitalize and amortize both domestic and foreign R&D expenditures rather than expensing them in the year incurred. The OBBBA, which was signed into law on July 4, 2025, includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with our fiscal year 2026, which is expected to result in lower cash tax payments in future periods than previously anticipated.

[0000106040-25-000038:mdna:136]
Foreign Exchange Contracts

[0000106040-25-000038:mdna:137]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. For a description of our current foreign exchange contract commitments, see Part II, Item 8, Note 7, Derivative Instruments and Hedging Activities, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:138]
Indemnifications

[0000106040-25-000038:mdna:139]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or from intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0000106040-25-000038:mdna:140]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0000106040-25-000038:mdna:141]
Recent Accounting Pronouncements

[0000106040-25-000038:mdna:142]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8, Note 2, Recent Accounting Pronouncements, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0000106040-25-000038:mdna:143]
Critical Accounting Policies and Estimates

[0000106040-25-000038:mdna:144]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”). The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, liabilities and shareholders’ equity. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material.

[0000106040-25-000038:mdna:145]
Revenue

[0000106040-25-000038:mdna:146]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. We record estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. We constrain variable consideration until the likelihood of a significant revenue reversal is not probable and believe that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0000106040-25-000038:mdna:147]
For sales to OEMs, our methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from us or other agreed-upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgement and the estimated amount of variable consideration can differ from the actual amount.

[0000106040-25-000038:mdna:148]
Inventories

[0000106040-25-000038:mdna:149]
We value inventories at the lower of cost or net realizable value (“NRV”) with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to the lower of cost or net realizable value or for obsolete or excess inventory based on assumptions, which requires significant judgement. The determination of NRV involves estimating the ASPs less any selling expenses of inventory based on market conditions and customer demand. To estimate the ASPs and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0000106040-25-000038:mdna:150]
We periodically perform an analysis of potential excess and obsolete inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. If in any period, we can sell inventories that had been written down to a level below the realized selling price in previous periods, higher gross profit would be recognized in the current period.

[0000106040-25-000038:mdna:151]
Income Taxes

[0000106040-25-000038:mdna:152]
We account for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting bases and the tax bases of our assets and liabilities and expected benefits of utilizing net operating loss and tax credit carryforwards. We record a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, we evaluate the need for a valuation allowance for our deferred tax assets and we adjust the valuation allowance so that we record net deferred tax assets only to the extent that we conclude it is more likely than not that these deferred tax assets will be realized. The assessment of valuation allowances against our deferred tax assets requires estimations and significant judgment. We continue to assess and adjust our valuation allowance based on operating results and market conditions. We account for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-25-000038:mdna:153]
We recognize liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the Consolidated Financial Statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the Consolidated Financial Statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized on liabilities recorded for uncertain tax positions and are recorded in our provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from our estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously recorded liabilities for unrealized tax benefits and materially affect our operating results.

[0000106040-25-000038:mdna:154]
Litigation and Contingencies

[0000106040-25-000038:mdna:155]
45

[0000106040-25-000038:mdna:156]
We disclose information regarding claims and contingencies where the likelihood of a material loss is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, we record an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, we disclose the matter and an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to our financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves significant judgments about the merits of the claim, applicable law, potential outcomes, estimates and inherent uncertainties. We engage relevant subject matter experts to assist us with our assessment of available information to reach conclusions on the likelihood and amount, or range, of potential loss. The actual outcome of such matters could differ materially from our estimates.

[0000106040-25-000038:mdna:157]
46
