# WDC note change history — 0000106040-25-000008 → 0000106040-25-000026


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000106040-25-000026:note_history:1]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Taxes.
  (was, 2025-01-31, similarity 0.9805):
[0000106040-25-000008:note_history:1]
For disclosures regarding the status of statutory notices of deficiency issued by the IRS with regard to tax years 2008 through 2015, see Note 12, Income Tax Expense.

- added (2025-05-02):
[0000106040-25-000026:note_history:2]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives.

- added (2025-05-02):
[0000106040-25-000026:note_history:3]
Subsequent to March 28, 2025, pursuant to a confidential agreement effective as of April 17, 2025, MRT and the Company reached a global settlement of $130 million for all pending legal disputes. The settlement results in the dismissal of the MRT matter, as well as a second patent litigation matter MRT filed on August 22, 2024 against the Company. As a result of the settlement, the Company reversed $201 million of previously recorded charges in Operating expense under Litigation matter and $6 million of post-judgment interest previously recorded in Other income (expense), net.

- changed (2025-05-02):
[0000106040-25-000026:note_history:4]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company is contesting the judgment and, based on available arguments, the Company believes the judgment, including any prejudgment interest and legal costs will be reversed, amended or vacated based on the Company’s motions for judgment as a matter of law in the district court or when the Company presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of March 28, 2025.
  (was, 2025-01-31, similarity 0.6535):
[0000106040-25-000008:note_history:4]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim under U.S. Patent No. 6,088,802 asserted against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. The Company intends to contest the verdict and, based on available arguments, the Company believes the jury verdict and the prejudgment interest and legal costs will be reversed, amended or vacated when the Company files motions for judgment as a matter of law in the district court or presents its appeal to the United States Court of Appeals for the Federal Circuit, if necessary. The Company therefore believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of judgment in its financial statements as of December 27, 2024.

- changed (2025-05-02):
[0000106040-25-000026:note_history:5]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.
  (was, 2025-01-31, similarity 0.9838):
[0000106040-25-000008:note_history:5]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of probable monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.

- added (2025-05-02):
[0000106040-25-000026:note_history:6]
The ability to predict the ultimate outcome of any legal proceeding involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.

- removed (2025-05-02):
[0000106040-25-000008:note_history:7]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives. During the three and six months ended December 27, 2024, the Company recognized incremental charges of $0 and $3 million, respectively, related to plaintiff’s attorney’s fees in Operating expense under Litigation matter; $4 million and $6 million, respectively, of post-judgment interest in Other income (expense), net; and $10 million and $19 million, respectively, in Cost of revenue from the amortization of licenses related to this matter. The Company believes it has meritorious defenses, has filed post-trial motions, and if not successful, plans to appeal the judgment and continue to defend itself vigorously.

- removed (2025-05-02):
[0000106040-25-000008:note_history:8]
The ability to predict the ultimate outcome of these matters involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.


## wdc:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2025-05-02):
[0000106040-25-000008:note_history:9]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

- removed (2025-05-02):
[0000106040-25-000008:note_history:10]
The Company’s business ventures with Kioxia Corporation (“Kioxia”) consist of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”), and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures”.

- removed (2025-05-02):
[0000106040-25-000008:note_history:11]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

- removed (2025-05-02):
[0000106040-25-000008:note_history:12]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 44 |  |  | 149 |  |
| Investment in Flash Alliance | 111 |  |  | 216 |  |
| Investment in Flash Forward | 123 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 861 |  |  | $ | 991 |  |

- removed (2025-05-02):
[0000106040-25-000008:note_history:13]
The Company made net payments to Flash Ventures for purchased flash-based memory wafers and net loans of $1.1 billion and $2.0 billion during the three and six months ended December 27, 2024, respectively, and $0.8 billion and $1.8 billion during the three and six months ended December 29, 2023, respectively.

- removed (2025-05-02):
[0000106040-25-000008:note_history:14]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Venture entity. For all reporting periods presented, no loans were past due and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

- removed (2025-05-02):
[0000106040-25-000008:note_history:15]
As of December 27, 2024 and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $252 million and $313 million, respectively.

- removed (2025-05-02):
[0000106040-25-000008:note_history:16]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2025-05-02):
[0000106040-25-000008:note_history:17]
|  | December 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 583 |  |
| Equity investments | 278 |  |
| Operating lease guarantees | 1,343 |  |
| Inventory and prepayments | 1,393 |  |
| Maximum estimable loss exposure | $ | 3,597 |  |

- removed (2025-05-02):
[0000106040-25-000008:note_history:18]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that each Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- removed (2025-05-02):
[0000106040-25-000008:note_history:19]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During the three and six months ended December 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 27, 2024.

- removed (2025-05-02):
[0000106040-25-000008:note_history:20]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the start-up of these facilities, the Company has made prepayments toward future building depreciation. In connection with the start-up of the K1, K2 and Y7 facilities, the Company has made prepayments over time, and as of December 27, 2024, $944 million remains to be credited against future building depreciation charges. As of December 27, 2024, the Company is also committed to make additional building depreciation prepayments of $303 million, based on the Japanese yen to U.S. dollar exchange rate of 157.86 as of such date, payable as follows: $60 million for the remainder of fiscal year 2025, $30 million in fiscal year 2026, $111 million in fiscal year 2027, $89 million in fiscal year 2028 and $13 million in fiscal year 2029. As of December 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $107 million at varying dates through fiscal year 2035.

- removed (2025-05-02):
[0000106040-25-000008:note_history:21]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed under Flash Ventures for up to three months are binding and cannot be canceled.

- removed (2025-05-02):
[0000106040-25-000008:note_history:22]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Consolidated Financial Statements.

- removed (2025-05-02):
[0000106040-25-000008:note_history:23]
Off-Balance Sheet Liabilities

- removed (2025-05-02):
[0000106040-25-000008:note_history:24]
Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half or all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

- removed (2025-05-02):
[0000106040-25-000008:note_history:25]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024.

- removed (2025-05-02):
[0000106040-25-000008:note_history:26]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 212 |  |  | $ | 1,343 |  |

- removed (2025-05-02):
[0000106040-25-000008:note_history:27]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments as of December 27, 2024 in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024:

- removed (2025-05-02):
[0000106040-25-000008:note_history:28]
| Annual Installments |  | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  |  | (in millions) |
| Remaining six months of 2025 |  | $ | 201 |  |  | $ | 49 |  |  | $ | 250 |  |
| 2026 |  | 406 |  |  | 113 |  |  | 519 |  |
| 2027 |  | 198 |  |  | 97 |  |  | 295 |  |
| 2028 |  | 83 |  |  | 93 |  |  | 176 |  |
| 2029 |  | 25 |  |  | 50 |  |  | 75 |  |
| 2030 |  | 4 |  |  | 24 |  |  | 28 |  |
| Total guarantee obligations |  | $ | 917 |  |  | $ | 426 |  |  | $ | 1,343 |  |

- removed (2025-05-02):
[0000106040-25-000008:note_history:29]
The Company and Kioxia have agreed to mutually contribute to, and indemnify each other and Flash Ventures for, environmental remediation costs or liability resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments, nor recorded any indemnification receivables, under any such agreements. As of December 27, 2024, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- removed (2025-05-02):
[0000106040-25-000008:note_history:30]
Unis Venture

- removed (2025-05-02):
[0000106040-25-000008:note_history:31]
The Company has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Company accounts for its investment in the Unis Venture under the equity method of accounting. Revenue on products distributed by the Unis Venture is recognized upon sell through to third-party customers. For both the three and six months ended December 27, 2024, the Company recognized approximately 3% of its consolidated revenue on products distributed by the Unis Venture. For the three and six months ended December 29, 2023, the Company recognized approximately 4% and 3% of its consolidated revenue, respectively, on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 6% and 7% of Accounts receivable, net as of both December 27, 2024 and June 28, 2024, respectively.

- removed (2025-05-02):
[0000106040-25-000008:note_history:32]
Sale of a Majority Interest in a Subsidiary

- removed (2025-05-02):
[0000106040-25-000008:note_history:33]
In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies in its flash-based products, on September 28, 2024, the Company’s wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) completed the sale of 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), the Company’s indirect wholly-owned subsidiary in its Flash business that owned its Flash manufacturing facility, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

- removed (2025-05-02):
[0000106040-25-000008:note_history:34]
Proceeds from the sale, including working capital adjustments, are $659 million pre-tax. On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive remaining pre-tax proceeds of $187 million in five installments of approximately $37 million on September 28 of each year through September 28, 2029. As of December 27, 2024, the outstanding consideration receivable was recognized at its present value of $370 million, with $243 million within Other current assets and $127 million within Other non-current assets in the Condensed Consolidated Balance Sheets. The present value discount of $27 million as of December 27, 2024 will be accreted using the effective interest method to Interest income in the Condensed Consolidated Statements of Operations over the next five years.

- removed (2025-05-02):
[0000106040-25-000008:note_history:35]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS will be recognized one quarter in arrears and will be reported in Other net income (expense), net in the Condensed Consolidated Statements of Operations.

- removed (2025-05-02):
[0000106040-25-000008:note_history:36]
The Transaction resulted in a pre-tax gain of $113 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $303 million of goodwill allocated to SDSS.

- removed (2025-05-02):
[0000106040-25-000008:note_history:37]
Subsequent to and in connection with the SDSS sale, the Company entered into a five-year Supply Agreement with SDSS to purchase certain flash-based products with a minimum annual commitment of $550 million (“the minimum annual commitment”). The Supply Agreement contains specific penalties the Company must pay if SDSS’s revenue fails to meet the minimum annual commitment. The Supply Agreement also provides that if SDSS’s revenue is higher than the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company a true-up amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by any of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the six months ended December 27, 2024, the Company made purchases of $111 million under the Supply Agreement and had an account payable balance due to SDSS of $117 million as of December 27, 2024.

- removed (2025-05-02):
[0000106040-25-000008:note_history:38]
The Company also entered into a Transaction Services Agreement (“TSA”) to provide certain transitional services for one year following the closing of the Transaction. Charges under the TSA were not material.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000106040-25-000026:note_history:39]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drive (“HDD”) technology.
  (was, 2025-01-31, similarity 0.8975):
[0000106040-25-000008:note_history:39]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on both hard disk drive and NAND flash technologies.

- added (2025-05-02):
[0000106040-25-000026:note_history:40]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- added (2025-05-02):
[0000106040-25-000026:note_history:41]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024 (the “2024 Annual Report on Form 10-K”). In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the 2024 Annual Report on Form 10‑K. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- added (2025-05-02):
[0000106040-25-000026:note_history:42]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 3, Discontinued Operations.

- added (2025-05-02):
[0000106040-25-000026:note_history:43]
Historically, the Company had been managed and operated under two reportable segments: hard disk drives (“HDD”) and Flash-based products (“Flash”). As a result of the Separation (as defined in Note 3, Discontinued Operations) and disposition of the Flash segment, the Company’s continuing operations now consist of a single reportable segment, HDD. The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), now evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s consolidated results.

- removed (2025-05-02):
[0000106040-25-000008:note_history:44]
The Company’s broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

- removed (2025-05-02):
[0000106040-25-000008:note_history:45]
The accounting policies followed by the Company are set forth in Part II, Item 8, Note 1, Organization and Basis of Presentation, of the Notes to the Consolidated Financial Statements included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. In the opinion of management, all adjustments necessary to fairly state the Condensed Consolidated Financial Statements have been made. Such adjustments consist of items of a normal, recurring nature. Certain information and footnote disclosures normally included in the Consolidated Financial Statements prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) have been condensed or omitted pursuant to the rules and regulations of the Securities and Exchange Commission (“SEC”). These Condensed Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10‑K for the year ended June 28, 2024. The results of operations for interim periods are not necessarily indicative of results to be expected for the full year.

- removed (2025-05-02):
[0000106040-25-000008:note_history:46]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports under two reportable segments: hard disk drives (“HDD”) and flash-based products (“Flash”).

- removed (2025-05-02):
[0000106040-25-000008:note_history:47]
The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), evaluates the performance of the Company and makes decisions regarding the allocation of resources based on each operating segment’s net revenue and gross margin. Because of the integrated nature of the Company’s production and distribution activities, separate segment asset measures are either not available or not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

- removed (2025-05-02):
[0000106040-25-000008:note_history:48]
Business Separation Costs

- removed (2025-05-02):
[0000106040-25-000008:note_history:49]
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent, public companies. As a result of the plan, the Company has incurred separation and transition costs and expects to incur such costs through the completion of the separation of the businesses. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000106040-25-000026:note_history:50]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,480 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,380 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,333 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,426) |  |  | (1,750) |  |
| Long-term debt | $ | 4,907 |  |  | $ | 5,684 |  |
  (was, 2025-01-31, similarity 0.9074):
[0000106040-25-000008:note_history:50]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,513 |  |  | 2,588 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,413 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,366 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (150) |  |  | (1,750) |  |
| Long-term debt | $ | 7,216 |  |  | $ | 5,684 |  |

- added (2025-05-02):
[0000106040-25-000026:note_history:51]
On February 20, 2025, the Company entered into a fourth amendment to the loan agreement governing the Company’s revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”) and term loan facility, dated as of January 7, 2022 (as amended, the “Loan Agreement”) that, among other changes, (a) permitted the Separation, (b) provided for the automatic release, in connection with the Separation, of guarantees and liens on collateral provided by Sandisk (as defined below) and Sandisk Technologies, Inc. under the Loan Agreement, (c) provided for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a noncash exchange to replace the Company’s previously existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”), (d) facilitates a potential future debt for equity exchange with respect to the Term Loan A-3 in connection with the Sandisk retained interest, and (e) in connection with the Separation, reduced the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion.

- changed (2025-05-02):
[0000106040-25-000026:note_history:52]
During the three and nine months ended March 28, 2025, the Company made scheduled repayments of $32 million and $107 million, respectively, under the Term Loan Facility. The Term Loan A-3 bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies (as defined in the Loan Agreement), with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-3 as of March 28, 2025 was 5.927%.
  (was, 2025-01-31, similarity 0.7902):
[0000106040-25-000008:note_history:52]
During the three and six months ended December 27, 2024, the Company made scheduled repayments of the Term Loan A-2 maturing in January 2027 (the “Term Loan A-2”) of $38 million and $75 million, respectively. The Term Loan A-2 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the loan agreement governing the Term Loan A-2) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-2 as of December 27, 2024 was 6.107%.

- changed (2025-05-02):
[0000106040-25-000026:note_history:53]
During the nine months ended March 28, 2025, the Company drew and repaid $150 million principal amount under the 2027 Revolving Credit Facility. As of March 28, 2025, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $1.25 billion as of that date.
  (was, 2025-01-31, similarity 0.7198):
[0000106040-25-000008:note_history:53]
During the six months ended December 27, 2024, the Company drew and repaid $150 million principal amount under its $2.25 billion revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”). As of December 27, 2024, the Company had no outstanding standby letters of credit and the available capacity under the 2027 Revolving Credit Facility was $2.25 billion as of that date.

- changed (2025-05-02):
[0000106040-25-000026:note_history:54]
The Loan Agreement requires the Company to comply with a financial leverage ratio covenant. As of March 28, 2025, the Company was in compliance with the financial covenant.
  (was, 2025-01-31, similarity 0.7901):
[0000106040-25-000008:note_history:54]
The loan agreements governing the Company’s 2027 Revolving Credit Facility and Term Loan A-2 require the Company to comply with a financial leverage ratio covenant. As of December 27, 2024, the Company was in compliance with the financial covenant.

- changed (2025-05-02):
[0000106040-25-000026:note_history:55]
As of March 28, 2025, the Company had outstanding $1.60 billion aggregate principal amount of convertible senior notes pursuant to an indenture dated as of November 3, 2023 (the “Indenture”), which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).
  (was, 2025-01-31, similarity 0.8062):
[0000106040-25-000008:note_history:55]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”).

- added (2025-05-02):
[0000106040-25-000026:note_history:56]
The 2028 Convertible Notes are convertible at the option of any holder beginning August 15, 2028, at a conversion price of approximately $37.89 per share of common stock (which conversion price has been adjusted from its original conversion price of approximately $52.20 in accordance with the Indenture as a result of the Separation). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028, upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- changed (2025-05-02):
[0000106040-25-000026:note_history:57]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended March 31, 2025 and accordingly, the holders of the 2028 Convertible Notes do not have the right to convert the notes during the succeeding calendar quarter ending June 30, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of March 28, 2025. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.
  (was, 2025-01-31, similarity 0.9754):
[0000106040-25-000008:note_history:57]
During the calendar quarter ended June 30, 2024, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holder of the 2028 Convertible Notes had the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter through September 30, 2024. Consequently, the Company classified the 2028 Convertible Notes in the Current portion of long-term debt in the Condensed Consolidated Financial Statements as of June 28, 2024. The sale price conditional conversion feature was not triggered during the calendar quarter ended December 31, 2024 and accordingly, the holders of the 2028 Convertible Notes no longer have the right to convert the notes during the succeeding calendar quarter ending March 31, 2025. As a result, the 2028 Convertible Notes were classified as Long-term debt in the Condensed Consolidated Financial Statements as of December 27, 2024. The Company will continue to evaluate the conversion feature quarterly to determine if the 2028 Convertible Notes become convertible in future periods.

- added (2025-05-02):
[0000106040-25-000026:note_history:58]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $37.89 per share, which has been adjusted from its original conversion price of approximately $52.20 per share according to the terms of the agreements and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $51.00 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 11 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.

- added (2025-05-02):
[0000106040-25-000026:note_history:59]
Subsequent to March 28, 2025, the Company redeemed, at its election, $1.80 billion aggregate principal amount of its 4.75% senior unsecured notes due 2026 (the “2026 Notes”) at par plus accrued interest. Following such redemption, $500 million aggregate principal amount of the 2026 Notes remained outstanding.

- removed (2025-05-02):
[0000106040-25-000008:note_history:60]
The 2028 Convertible Notes are convertible at the option of any holder at an initial conversion price of approximately $52.20 per share of common stock beginning August 15, 2028. Prior to that date, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to that date upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted.

- removed (2025-05-02):
[0000106040-25-000008:note_history:61]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $52.20 per share, subject to certain adjustments, which correspond to the initial conversion price of the 2028 Convertible Notes. The Capped Calls have initial cap prices of $70.26 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 8 million shares of the Company’s common stock. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. However, if the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Calls are recorded in shareholders’ equity and are not accounted for as derivatives.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000106040-25-000026:note_history:62]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 2,480 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,380 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,333 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,426) |  |  | (1,750) |  |
| Long-term debt | $ | 4,907 |  |  | $ | 5,684 |  |
  (was, 2025-01-31, similarity 0.9074):
[0000106040-25-000008:note_history:62]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 2,300 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | 2,513 |  |  | 2,588 |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 7,413 |  |  | 7,488 |  |
| Issuance costs | (47) |  |  | (54) |  |
| Subtotal | 7,366 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (150) |  |  | (1,750) |  |
| Long-term debt | $ | 7,216 |  |  | $ | 5,684 |  |


## wdc:NotesReceivableAndInvestmentsInRelatedPartiesTableTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2025-05-02):
[0000106040-25-000008:note_history:63]
The following table presents the notes receivable from, and equity investments in, Flash Ventures:

- removed (2025-05-02):
[0000106040-25-000008:note_history:64]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 44 |  |  | 149 |  |
| Investment in Flash Alliance | 111 |  |  | 216 |  |
| Investment in Flash Forward | 123 |  |  | 135 |  |
| Total notes receivable and investments in Flash Ventures | $ | 861 |  |  | $ | 991 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0000106040-25-000026:note_history:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,007 |  |  | $ | 1,455 |  |  | $ | 6,012 |  |  | $ | 3,340 |  |
| Client | 137 |  |  | 140 |  |  | 416 |  |  | 440 |  |
| Consumer | 150 |  |  | 157 |  |  | 487 |  |  | 533 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 753 |  |  | $ | 600 |  |  | $ | 2,349 |  |  | $ | 1,677 |  |
| Americas | 1,182 |  |  | 882 |  |  | 3,468 |  |  | 1,844 |  |
| Europe, Middle East and Africa | 359 |  |  | 270 |  |  | 1,098 |  |  | 792 |  |
| Total revenue | $ | 2,294 |  |  | $ | 1,752 |  |  | $ | 6,915 |  |  | $ | 4,313 |  |
  (was, 2025-01-31, similarity 0.92):
[0000106040-25-000008:note_history:65]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 2,346 |  |  | $ | 1,071 |  |  | $ | 4,554 |  |  | $ | 1,943 |  |
| Client | 1,168 |  |  | 1,122 |  |  | 2,377 |  |  | 2,269 |  |
| Consumer | 771 |  |  | 839 |  |  | 1,449 |  |  | 1,570 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,995 |  |  | $ | 1,699 |  |  | $ | 3,832 |  |  | $ | 3,250 |  |
| Americas | 1,428 |  |  | 804 |  |  | 3,118 |  |  | 1,466 |  |
| Europe, Middle East and Africa | 862 |  |  | 529 |  |  | 1,430 |  |  | 1,066 |  |
| Total revenue | $ | 4,285 |  |  | $ | 3,032 |  |  | $ | 8,380 |  |  | $ | 5,782 |  |
