# WDC notes — 0000106040-25-000038


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000106040-25-000038:notes:1]
Part III incorporates by reference certain information from the registrant’s definitive proxy statement (the “Proxy Statement”) for the 2025 Annual Meeting of Stockholders, which we intend to file with the Securities and Exchange Commission within 120 days after the end of the 2025 fiscal year. Except with respect to information specifically incorporated by reference in this Form 10-K, the Proxy Statement is not deemed to be filed as part hereof.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000106040-25-000038:notes:2]
At Western Digital, our management team is charged with managing risk and bringing to our Board of Directors’ attention all material risk exposures to our company. Our enterprise risk management (“ERM”) process is designed to facilitate the identification, assessment, management, reporting and monitoring of material risks our company may face over the short-term and long-term and promote regular communication with our Board of Directors and its committees regarding these risks. Through our ERM process, we have determined that the compromise, damage and interruption of our technology infrastructure, information systems or products by cybersecurity incidents are key risks to our company that may have a material negative impact on our business. To help mitigate the potential impact of cybersecurity incidents on our business and protect against cybersecurity threats, we have established organizational structures, procedural measures and response plans that define roles and responsibilities related to cybersecurity risk management.

[0000106040-25-000038:notes:3]
Our Information Security organization addresses cybersecurity risks with a broad spectrum of technologies, controls, and processes that focus on mitigating these risks. Our cybersecurity strategy is designed to be dynamic and adaptive to combat the rapidly-evolving cybersecurity threat landscape and is influenced by commonly leveraged frameworks such as the NIST-CSF (National Institute of Standard and Technologies – CyberSecurity Framework). Our program includes, but is not limited to, advanced systems and network security protocols, electronic communications protections, vulnerability management programs, least-privilege access controls, third-party risk management procedures, workforce education and training exercises, and compliance programs.

[0000106040-25-000038:notes:4]
Our dedicated 24x7 Security Operations Center incorporates specialized systems and processes for handling security incidents into its regular work and operates a robust, modern security infrastructure with appropriate security sensors and event monitoring capabilities. Upon detection of a cybersecurity incident, the Security Operations Center determines the severity of the incident in accordance with a pre-established incident severity matrix, initiates the appropriate notification and escalation protocols and begins triage. Predefined severity tiers serve as a guide to match our response to each incident’s determined severity or risk level.

[0000106040-25-000038:notes:5]
Additionally, we have established a Cyber Incident Response Plan that follows the structure of the Incident Handling Guide published by the U.S. National Institute of Standards and Technology (SP 800-61r2) and that serves as an operational guide for handling cybersecurity incidents. Our Cyber Incident Response Plan provides procedural and strategic guidance that is designed to be flexible enough to apply to a variety of different incidents, but also specific enough to provide guidelines for incident prevention, detection, analysis, escalation and notification, and containment, eradication and recovery.

[0000106040-25-000038:notes:6]
As part of our ongoing information security program, we utilize periodic independent third-party experts to conduct assessments of our program’s effectiveness. These experts are also leveraged to design and orchestrate tabletop exercises where multiple business functions and leadership levels must navigate complex incident scenarios to help determine our level of preparedness for various cybersecurity incidents.

[0000106040-25-000038:notes:7]
As part of our business operations, we engage with a number of third parties, including but not limited to, online software service providers, vendors, consultants, and partners. Each of these third parties must be cleared through a formal cybersecurity risk assessment process before being allowed to integrate with our information systems, access confidential data, or provide electronic services to members of our workforce. Additionally, further scrutiny is applied during the post-assessment onboarding process in order to fine-tune access rights to limit privileges to those necessary to enable the related service, resulting in a least-privilege level of access.

[0000106040-25-000038:notes:8]
We have in the past experienced cybersecurity incidents of varying degrees involving our technology infrastructure and information systems, including incidents in which unauthorized parties have obtained access to our information systems and networks. While these incidents have at times resulted in some disruptions to our business operations, as of the date of this Annual Report on Form 10-K, we do not believe that known risks from cybersecurity threats, including as a result of any previous cybersecurity incident, have materially affected or are reasonably likely to materially affect us, including our business strategy, results of operations or financial condition. However, we can give no assurance that we have detected or protected against all such cybersecurity incidents or threats or that we will not experience such an incident in the future. Further details about the cybersecurity risks we face are described under “The compromise, damage or interruption of our technology infrastructure, information systems or products by cybersecurity incidents, data security breaches, other security problems, design defects, information system failures or other events could have a material negative impact on our business” in Part I, Item 1A, Risk Factors, of this Annual Report on Form 10-K.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0000106040-25-000038:notes:9]
We have implemented a governance framework related to cybersecurity that includes operational risk-mitigation practices and Board-level cybersecurity risk oversight.

[0000106040-25-000038:notes:10]
Our management team is charged with managing cybersecurity risk and identifying material cybersecurity risk exposures to our company and carries out this function primarily through our Information Security organization, which is led by our Chief Information Security Officer who has a master’s degree in computer science, over a decade of information security leadership, and thirty years of combined IT leadership experience. Additionally, our Cyber Incident Response Plan discussed above calls for the establishment of a management Impact Assessment Committee, which consists of key leadership representatives from the organization and is convened on an ad hoc basis to assess the detailed business impact of a cybersecurity incident. The Impact Assessment Committee is led by our Chief Information Security Officer and includes key representatives from the Company’s functional groups, including human resources, ethics and compliance, labor, privacy, internal audit, finance, communications, legal, risk and accounting. The Impact Assessment Committee receives updates and communications from the Security Operations Center on a fixed cadence determined by incident severity and follows our pre-established escalation framework provided by our Security Incident Response Plan to communicate with and include executive leadership, outside counsel and our Board of Directors, as appropriate. The Impact Assessment Committee works with our internal and external legal counsel to determine and facilitate appropriate communications with our Board of Directors.

[0000106040-25-000038:notes:11]
Our Board of Directors is responsible for overseeing the cybersecurity risk management process and exercises this risk oversight through both our full Board of Directors and its Audit Committee. Our Board of Directors has delegated to our Audit Committee the responsibility to oversee risks related to cybersecurity threats, and our Audit Committee Charter requires our Audit Committee to review and discuss with management the Company’s policies with respect to risk assessment and enterprise risk management and to review the risk exposure of the Company related to the Committee’s areas of responsibility, including with respect to cybersecurity. In carrying out this role, our Audit Committee meets with our Chief Information Security Officer regularly and receives at least quarterly reports on cybersecurity matters.

[0000106040-25-000038:notes:12]
Additionally, at least annually, our chief audit executive, who manages the day-to-day activities of our ERM program, reports to our Board of Directors on enterprise risk assessment under our ERM program, providing updates on key risks, status of mitigation efforts and residual risk trends, including an analysis of cybersecurity risks. Also at least annually, our Chief Information Security Officer reports to our full Board of Directors on cybersecurity matters related to or impacting our company and our business.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000106040-25-000038:notes:13]
Organization and Basis of Presentation
Western Digital Corporation (“Western Digital” or the “Company”) is a leading developer, manufacturer, and provider of data storage devices and solutions based on hard disk drives (“HDD”) technologies.

[0000106040-25-000038:notes:14]
The Company manufactures, markets, and sells data storage devices and solutions in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. Its broad portfolio of technology and products addresses the following key end markets: Cloud, Client, and Consumer. Cloud is comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its OEM and channel customers a broad array of high-performance HDD solutions across desktop and notebooks. The Consumer end market provides a broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast presence around the world. The Company also generates immaterial license and royalty revenue from its extensive intellectual property portfolio, which is included in each of these three end market categories.

[0000106040-25-000038:notes:15]
Basis of Presentation

[0000106040-25-000038:notes:16]
The Company has prepared its Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and has adopted accounting policies and practices which are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0000106040-25-000038:notes:17]
Information provided herein is presented on a continuing operations basis to reflect the impact of the Separation of the Company’s Flash business as discussed in further detail in Note 3, Discontinued Operations.

[0000106040-25-000038:notes:18]
Fiscal Year

[0000106040-25-000038:notes:19]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2025, 2024, and 2023, which ended on June 27, 2025, June 28, 2024 and June 30, 2023, respectively, are comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated continuing operations basis.

[0000106040-25-000038:notes:20]
Segment Reporting

[0000106040-25-000038:notes:21]
Historically, the Company had been managed and operated under two reportable segments: HDD and Flash-based products (“Flash”). As a result of the Separation (as defined in Note 3, Discontinued Operations) and disposition of the Flash segment, the Company’s continuing operations now consist of a single reportable segment, HDD. The Chief Executive Officer, who is the Company’s Chief Operating Decision Maker (“CODM”), now evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s consolidated results.

[0000106040-25-000038:notes:22]
Basis of Consolidation

[0000106040-25-000038:notes:23]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All significant intercompany accounts and transactions have been eliminated in consolidation. The functional currency of most of the Company’s foreign subsidiaries is the U.S. dollar. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from the remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in Accumulated other comprehensive income (loss), a component of shareholders’ equity.

[0000106040-25-000038:notes:24]
Use of Estimates

[0000106040-25-000038:notes:25]
Company management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented with consideration given to the potential impacts of tariffs. However, actual results could differ materially from these estimates and be significantly affected by changes in U.S. trade policies, including tariffs, trade agreements or other trade restrictions imposed by the United States or other governments and possible retaliatory measures on U.S. goods.

[0000106040-25-000038:notes:26]
Cash Equivalents

[0000106040-25-000038:notes:27]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as bank certificates of deposit with original maturities at purchase of three months or less. These deposits are typically in excess of U.S. insured limits. Cash equivalents are carried at cost plus accrued interest, which approximates fair value.

[0000106040-25-000038:notes:28]
Equity Investments

[0000106040-25-000038:notes:29]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20% but less than a majority, or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income (expense), net, in the Consolidated Statements of Operations and were immaterial for all years presented.

[0000106040-25-000038:notes:30]
The Company’s retained interest in Sandisk is less than 20% and the Company does not have the ability to exercise significant influence over Sandisk’s operating and financial policies. As such, the Company accounts for this interest at fair value. The Company also has an immaterial amount of equity securities that do not have a readily determinable fair value. These securities are measured and recorded using the measurement alternative under Accounting Standards Update (“ASU”) No. 2016-01, “Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities,” which is cost minus impairment, if any, plus or minus changes resulting from observable price changes. These investments are recorded within Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0000106040-25-000038:notes:31]
Fair Value of Financial Instruments

[0000106040-25-000038:notes:32]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The fair value of investments that are not accounted for under the equity method is based on appropriate market information.

[0000106040-25-000038:notes:33]
Inventories

[0000106040-25-000038:notes:34]
The Company values inventories at the lower of cost (first-in, first out) or net realizable value. The first-in, first-out method is used to value the cost of the majority of the Company’s inventories. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0000106040-25-000038:notes:35]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write-down of inventory that could materially affect operating results.

[0000106040-25-000038:notes:36]
Property, Plant and Equipment

[0000106040-25-000038:notes:37]
Property, plant, and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings and improvements are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s machinery and equipment, software, and furniture and fixtures are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0000106040-25-000038:notes:38]
Goodwill and Other Long-Lived Assets

[0000106040-25-000038:notes:39]
Goodwill is not amortized. Instead, it is tested for impairment on an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fourth quarter. The Company uses qualitative factors to determine whether goodwill is more likely than not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more likely than not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment. The Company’s assessments resulted in no impairment of goodwill in 2025, 2024 or 2023.

[0000106040-25-000038:notes:40]
The Company is required to use judgment when applying goodwill impairment tests, including the identification of its reporting unit and the determination of fair value. In addition, the estimates used to determine the fair value of its reporting unit may change based on the results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment. If the Company’s stock price decreases significantly, goodwill could become impaired, which could result in a material charge and adversely affect the Company’s results of operations.

[0000106040-25-000038:notes:41]
In-process research and development (“IPR&D”) is an intangible asset accounted for as an indefinite-lived asset until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test at least annually or whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, strategic decisions made in response to economic, market, and competitive conditions, and the impact of the economic environment on the Company and on its customer base. If impairment is indicated, the impairment is measured as the amount by which the carrying amounts of the assets exceed the fair values of the assets. The Company’s assessment resulted in no impairment of IPR&D in 2025, 2024 or 2023.

[0000106040-25-000038:notes:42]
Other long-lived assets are depreciated or amortized over their estimated useful lives based on the pattern in which the economic benefits are expected to be received. Long-lived assets are tested for recoverability whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable from undiscounted cash flows. If impairment is indicated, the impairment is measured as the amount by which the carrying amounts of the assets exceed the fair values of the assets. The estimates of fair value require evaluation of future market conditions and product lifecycles as well as projected revenue, earnings and cash flow. See Note 5, Supplemental Financial Statement Data, for additional disclosures related to the Company’s other long-lived assets.

[0000106040-25-000038:notes:43]
Revenue and Accounts Receivable

[0000106040-25-000038:notes:44]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not considered constrained based on the Company’s history with similar transactions and the fact that uncertainties are resolved in a fairly short period of time.

[0000106040-25-000038:notes:45]
Substantially all of the Company’s revenue is from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue is immaterial and mainly includes professional service arrangements and post-contract customer support, warranty as a service and maintenance contracts. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms.

[0000106040-25-000038:notes:46]
The Company incurs sales commissions and other direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize the direct incremental costs of obtaining contracts as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

[0000106040-25-000038:notes:47]
The Company also applies the practical expedients and does not disclose transaction price allocated to the remaining performance obligations for arrangements that have an original expected duration of one year or less, which mainly consist of support and maintenance contracts. The transaction prices allocated to the Company’s remaining performance obligations as of June 27, 2025 and June 28, 2024, were not material.

[0000106040-25-000038:notes:48]
The contract assets and contract liabilities for the years ended June 27, 2025 and June 28, 2024 were not material.

[0000106040-25-000038:notes:49]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year. The financing components of contracts with payment terms were not material.

[0000106040-25-000038:notes:50]
The Company provides distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. The Company also provides resellers and original equipment manufacturers (“OEMs”) with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics.

[0000106040-25-000038:notes:51]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed-upon sales incentive programs. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0000106040-25-000038:notes:52]
Marketing development program costs are typically recorded as a reduction of the transaction price and therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded within other accrued liabilities.

[0000106040-25-000038:notes:53]
For contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. If applicable, the Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices.

[0000106040-25-000038:notes:54]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency or other collection issues. In addition, the Company routinely analyzes the various receivable aging categories to establish reserves based on a combination of past-due receivables and expected future losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss trajectory changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0000106040-25-000038:notes:55]
Warranty

[0000106040-25-000038:notes:56]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific detail on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0000106040-25-000038:notes:57]
Litigation and Other Contingencies

[0000106040-25-000038:notes:58]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each claim where the likelihood of a material loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the loss. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 17, Legal Proceedings, for additional disclosures related to the Company’s litigation.

[0000106040-25-000038:notes:59]
Advertising Expense

[0000106040-25-000038:notes:60]
Advertising costs are expensed as incurred and amounted to $32 million, $51 million and $66 million in 2025, 2024 and 2023, respectively. These expenses are included in Selling, general and administrative in the Consolidated Statements of Operations.

[0000106040-25-000038:notes:61]
Research and Development Expense

[0000106040-25-000038:notes:62]
Research and development (“R&D”) expenditures are expensed as incurred.

[0000106040-25-000038:notes:63]
Income Taxes

[0000106040-25-000038:notes:64]
The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting bases and the tax bases of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more likely than not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more likely than not that these deferred tax assets will be realized. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0000106040-25-000038:notes:65]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously recorded liabilities for unrealized tax benefits, and may materially affect the Company’s operating results.

[0000106040-25-000038:notes:66]
Net Income (Loss) Per Common Share

[0000106040-25-000038:notes:67]
The Company computes net income (loss) per common share using a two-class method when shares are issued that meet the definition of participating securities. The two-class method determines net income (loss) per common share for each class of common stock and participating securities according to dividends declared or accumulated and participation rights in undistributed earnings. The two-class method requires undistributed earnings for the period to be allocated between common stock and participating securities based upon their respective rights to receive dividends as if all income for the period had been distributed. The Company’s convertible preferred stock contractually entitles the holders of such shares to participate in dividends but does not contractually require the holders of such shares to participate in the Company’s losses.

[0000106040-25-000038:notes:68]
The Company computes basic income (loss) per common share by dividing net income (loss) attributable to common shareholders by the weighted average number of common shares outstanding during the period. Diluted income (loss) per common share is computed by using diluted net income (loss) attributable to common shareholders, the weighted average number of common shares and potentially dilutive securities outstanding during the period using the treasury stock method or the “if-converted” method based on the nature of the securities. Potentially dilutive common shares include dilutive outstanding employee stock options, restricted stock unit awards (“RSUs”) and restricted stock unit awards with performance conditions or market conditions (“PSUs”), rights to purchase shares of common stock under the Company’s Employee Stock Purchase Plan (“ESPP”), and shares issuable in connection with the Company’s convertible notes and convertible preferred stock.

[0000106040-25-000038:notes:69]
Stock-Based Compensation

[0000106040-25-000038:notes:70]
The Company accounts for all stock-based compensation at fair value. Stock-based compensation cost is measured at the grant date based on the fair value of the award and is recognized as expense over the vesting period. Compensation expense is adjusted for forfeitures as they occur. The fair values of RSUs and PSUs with performance conditions are determined based on the closing market price of the Company’s stock on the date of the grant. The fair values of all ESPP purchase rights are estimated using the Black-Scholes-Merton option pricing model and require the input of subjective assumptions. The fair values of PSUs with market conditions are estimated using a Monte Carlo simulation model. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance or market conditions and completion of a requisite service period. At the end of each reporting period, the Company evaluates the probability that PSUs with a performance condition will be earned and records the related stock-based compensation expense over the service period. Compensation expense for PSUs with market conditions is recognized ratably over the required service period regardless of expected or actual achievement.

[0000106040-25-000038:notes:71]
Other Comprehensive Income (Loss), Net of Tax

[0000106040-25-000038:notes:72]
Other comprehensive income (loss), net of tax refers to gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The Company’s other comprehensive income (loss), net of tax is primarily comprised of unrealized gains or losses on foreign exchange contracts designated as cash flow hedges, foreign currency translation, and actuarial gains or losses related to pensions.

[0000106040-25-000038:notes:73]
Derivative Contracts

[0000106040-25-000038:notes:74]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for Operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. All contract maturity dates are 12 months or less. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for the British pound sterling, European euro, Japanese yen, Malaysian ringgit, Philippine peso, Singaporean dollar and Thai baht, which had an aggregate notional amount of $1.14 billion and $1.00 billion at June 27, 2025 and June 28, 2024, respectively.

[0000106040-25-000038:notes:75]
If the derivative is designated as a cash flow hedge and is determined to be highly effective, the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in Cost of revenue and Operating expenses and presented within cash flows from operating activities. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for all years presented.

[0000106040-25-000038:notes:76]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income (expense), net.

[0000106040-25-000038:notes:77]
Pensions and Other Post-Retirement Benefit Plans

[0000106040-25-000038:notes:78]
The Company has defined benefit pension plans and other post-retirement plans covering certain employees in various countries. The benefits are based on the employees’ years of service and compensation. The plans are funded in conformity with the funding requirements of applicable government authorities. The Company amortizes unrecognized actuarial gains and losses and prior service costs on a straight-line basis over the remaining estimated average service life of the participants. The measurement date for the plans is the Company’s year-end. The Company recognizes the funded status of its defined benefit pension and post-retirement plans in the Consolidated Balance Sheets, with actuarial changes in the funded status recognized through accumulated other comprehensive loss in the year in which such changes occur.

[0000106040-25-000038:notes:79]
The Company reports the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. In addition, the other components of net benefit cost are presented in Other income (expense), net in the Consolidated Statements of Operations.

[0000106040-25-000038:notes:80]
Leases

[0000106040-25-000038:notes:81]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000106040-25-000038:notes:82]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0000106040-25-000038:notes:83]
In September 2022, the Financial Accounting Standards Board (“FASB”) issued an accounting standards update (“ASU”) No. 2022-04, “Liabilities-Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations” (“ASU 2022-04”), which requires annual and interim disclosures for entities that use supplier finance programs in connection with the purchase of goods and services. ASU 2022-04 requires the Company to provide disclosure of outstanding obligations to such suppliers for all balance sheet dates presented beginning with the Company’s first quarter of 2024 and to provide certain rollforward information related to those obligations beginning in the Company’s first fiscal quarter of 2025. The ASU does not affect the recognition, measurement, or financial statement presentation of supplier finance program obligations. The Company adopted the guidance on the first day of fiscal year 2024. See Note 16, Supplier Finance Program, of the Notes to Consolidated Financial Statements for information regarding the supplier finance program.

[0000106040-25-000038:notes:84]
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures” (“ASU 2023-07”), which expands on segment reporting requirements primarily through enhanced disclosures surrounding significant segment expenses. ASU 2023-07 requires that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures have been provided in these financial statements, as discussed in Note 4, Segment Reporting, Disaggregated Revenue, Geographic Information, and Concentrations of Risk.

[0000106040-25-000038:notes:85]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000106040-25-000038:notes:86]
In November 2024, the FASB issued ASU No. 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses” (“ASU 2024-03”), which is intended to improve disclosures about the expenses of public entities. ASU 2024-03 requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement, within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This standard is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years following adoption, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption and expects to adopt the guidance for annual reporting periods in its annual report for the year ending June 30, 2028.

[0000106040-25-000038:notes:87]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures” (“ASU 2023-09”). ASU 2023-09 calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company is currently compiling the information required for these disclosures and expects to provide required disclosures in the year ending July 3, 2026.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000106040-25-000038:notes:88]
Discontinued Operations
On October 30, 2023, the Company announced that its Board of Directors had completed its strategic review of the business and, after evaluating a comprehensive range of alternatives, authorized the Company to pursue a plan to separate its HDD and Flash business units to create two independent public companies. In connection with the Separation (as defined below), the Company has incurred separation and transition costs, which are recorded as Business separation costs within discontinued operations in the Company’s Consolidated Financial Statements, as further detailed in the summary of net income (loss) from discontinued operations, net of taxes, below.

[0000106040-25-000038:notes:89]
On February 21, 2025, the Company completed the previously announced separation of its Flash business (the “Separation”) through a pro rata distribution of 80.1% of the outstanding shares of Sandisk Corporation (“Sandisk”) to Western Digital stockholders. The Separation is intended to be tax-free for U.S. federal income tax purposes. To reflect the completion of the Separation, the Company recorded a decrease in shareholders’ equity for the net book value of applicable assets and liabilities derecognized in connection with the Separation, net of the Company’s retained 19.9% ownership interest, or 28.8 million shares, initially based on the net book value of the applicable assets and liabilities derecognized. As a result of the Separation, Sandisk became an independent public company and Western Digital no longer consolidates Sandisk into the Company’s financial results. The historical net income of Sandisk and applicable assets and liabilities included in the Separation are now reported in the Company’s Consolidated Financial Statements as discontinued operations for all periods prior to the Separation on February 21, 2025. Following the Separation, as the Company no longer controls or has the ability to exert significant influence over Sandisk, the Company measures its retained ownership interest in Sandisk common stock at fair value on a recurring basis (see additional information in Note 6, Fair Value Measurements and Investments). In June 2025, the Company disposed of 21.3 million shares of its Sandisk common stock, along with $4 million in cash, in a tax-free exchange for $800 million principal amount of the Company’s Term Loan A-3. The Company expects to monetize its remaining shares of Sandisk within one year from the Separation Date.

[0000106040-25-000038:notes:90]
The Company entered into various agreements to effect the Separation and provide for the temporary framework of the relationship between Western Digital and Sandisk following the Separation, including, among others, a separation and distribution agreement, a tax matters agreement, and a transition services agreement. The transition services agreement provides for transition service support to be provided for various periods of time ranging up to 15 months. The amounts involved under these agreements were not material for the fiscal year ended June 27, 2025 and are not expected to be material.

[0000106040-25-000038:notes:91]
The following table provides a summary of the assets and liabilities classified as discontinued operations:

[0000106040-25-000038:notes:92]
| Assets and Liabilities of Discontinued Operations |  | June 28,2024 |
|  |  | (in millions) |
| Assets |
| Cash and cash equivalents |  | $ | 328 |  |
| Accounts receivable, net |  | 935 |  |
| Inventories |  | 1,955 |  |
| Other current assets |  | 313 |  |
| Current assets of discontinued operations |  | $ | 3,531 |  |
| Property, plant and equipment, net |  | $ | 808 |  |
| Notes receivable and investments in Flash Ventures |  | 991 |  |
| Goodwill |  | 5,713 |  |
| Other non-current assets |  | 1,101 |  |
| Non-current assets of discontinued operations |  | $ | 8,613 |  |
| Liabilities |
| Accounts payable |  | $ | 357 |  |
| Accounts payable to related parties |  | 313 |  |
| Accrued expenses |  | 427 |  |
| Income taxes payable |  | 54 |  |
| Accrued compensation |  | 173 |  |
| Current liabilities of discontinued operations |  | $ | 1,324 |  |
| Non-current liabilities of discontinued operations |  | $ | 368 |  |

[0000106040-25-000038:notes:93]
The following table provides a summary of net income (loss) from discontinued operations, net of taxes:

[0000106040-25-000038:notes:94]
| Net Income (Loss) from Discontinued Operations, Net of Taxes |  | 2025 |  | 2024 |  | 2023 |  |  |  |
|  |  | (in millions) |  |  |
| Revenue, net |  | $ | 4,361 |  |  | $ | 6,686 |  |  | $ | 6,063 |  |  |  |  |
| Cost of revenue |  | 2,892 |  |  | 5,514 |  |  | 5,567 |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development |  | 718 |  |  | 957 |  |  | 1,023 |  |  |  |  |
| Selling, general and administrative |  | 229 |  |  | 102 |  |  | 163 |  |  |  |  |
| Gain on business divestiture |  | (113) |  |  | — |  |  | — |  |  |  |  |
| Business separation costs |  | 144 |  |  | 97 |  |  | — |  |  |  |  |
| Business realignment charges |  | 3 |  |  | (70) |  |  | 47 |  |  |  |  |
| Operating income (loss) |  | 488 |  |  | 86 |  |  | (737) |  |  |  |  |
| Total interest and other income (expense), net |  | (36) |  |  | (8) |  |  | 36 |  |  |  |  |
| Income (loss) before taxes |  | 452 |  |  | 78 |  |  | (701) |  |  |  |  |
| Income tax expense |  | 206 |  |  | 111 |  |  | 81 |  |  |  |  |
| Net income (loss) from discontinued operations, net of taxes |  | $ | 246 |  |  | $ | (33) |  |  | $ | (782) |  |  |  |  |

[0000106040-25-000038:notes:95]
Cash flows related to discontinued operations have not been segregated and are included in the Consolidated Statements of Cash Flows for all periods presented. The following table provides selected financial information related to cash flows from discontinued operations:

[0000106040-25-000038:notes:96]
| Select Cash Flow Information from Discontinued Operations |  | 2025 |  | 2024 |  | 2023 |
|  |  | (in millions) |
| Depreciation and amortization |  | $ | 115 |  |  | $ | 221 |  |  | $ | 439 |  |
| Purchases of property, plant and equipment |  | 139 |  |  | 166 |  |  | 219 |  |
| Stock-based compensation |  | 98 |  |  | 92 |  |  | 106 |  |

[0000106040-25-000038:notes:97]
On February 21, 2025, prior to the effective time of the Separation, Sandisk entered into a loan agreement (the “Sandisk Loan Agreement”) by and among Sandisk, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and others party thereto. The Sandisk Loan Agreement comprises a term loan B facility in the principal amount of $2 billion (the “Sandisk Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Sandisk Revolving Credit Facility” and together with the Sandisk Term Loan Facility, the “Sandisk Facilities”). The obligations under this facility were retained by Sandisk upon the Separation.

[0000106040-25-000038:notes:98]
The Company previously had business ventures with Kioxia Corporation (“Kioxia”), which consisted of three separate legal entities: Flash Partners Ltd., Flash Alliance Ltd., and Flash Forward Ltd. The Company also previously had a business venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd., both collectively referred to as the “Unis Venture”. All business ventures with Kioxia and Unis Venture were distributed to Sandisk in connection with the Separation and are included in discontinued operations.

[0000106040-25-000038:notes:99]
Prior to the Separation, effective September 28, 2024, the Company sold 80% of its equity interest in an indirect wholly-owned subsidiary in its Flash business, SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), resulting in a gain on divestiture of $113 million. Net proceeds from the sale received prior to the Separation were $401 million. The rights to the remaining future proceeds from the sale and the 20% retained interest in SDSS were distributed to Sandisk in connection with the Separation.
During the year ended June 28, 2024, the Company completed a sale and leaseback of its facility in Milpitas, California associated with the Flash business. The Company received net proceeds of $191 million in cash and recorded a gain of $85 million on the sale.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0000106040-25-000038:notes:100]
The following table provides selected financial information related to cash flows from discontinued operations:


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000106040-25-000038:notes:101]
Segment Reporting, Disaggregated Revenue, Geographic Information, and Concentrations of Risk 
The Company’s Chief Executive Officer, Irving Tan, is the Company’s Chief Operating Decision Maker (“CODM”). The CODM manages the business as a provider of data storage devices and solutions based on HDD technology. The CODM evaluates the performance of the Company and makes decisions regarding the allocation of resources based on the Company’s Net income (loss) from continuing operations and Total assets. The Company has therefore, determined that it has one reportable segment: HDD.

[0000106040-25-000038:notes:102]
The following table is a reconciliation of the Company’s measure of segment profit or loss, significant segment expenses and other segment items:

[0000106040-25-000038:notes:103]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Revenue, net | $ | 9,520 |  |  | $ | 6,317 |  |  | $ | 6,255 |  |
| Less: Significant expenses and other segment items |  |  |  |  |  |
| Cost of revenue(1) | 5,771 |  |  | 4,506 |  |  | 4,827 |  |
| Research and development(1) | 920 |  |  | 885 |  |  | 916 |  |
| Selling, general and administrative(1) | 503 |  |  | 583 |  |  | 656 |  |
| Litigation matter | (179) |  |  | 291 |  |  | — |  |
| Business realignment charges | (6) |  |  | 209 |  |  | 146 |  |
| Stock-based compensation | 167 |  |  | 202 |  |  | 212 |  |
| Strategic review | — |  |  | 38 |  |  | 42 |  |
| Interest expense, net | 312 |  |  | 381 |  |  | 291 |  |
| Loss on retained interest in Sandisk | 772 |  |  | — |  |  | — |  |
| Loss on extinguishment of debt | 100 |  |  | — |  |  | — |  |
| Other expense, net | 2 |  |  | 14 |  |  | 20 |  |
| Other segment items(2) | 28 |  |  | (53) |  |  | (6) |  |
| Income tax expense (benefit) | (513) |  |  | 26 |  |  | 53 |  |
| Net income (loss) from continuing operations | $ | 1,643 |  |  | $ | (765) |  |  | $ | (902) |  |

[0000106040-25-000038:notes:104]
(1)    Excludes amounts related to stock-based compensation and strategic review which are presented separately in the table above.

[0000106040-25-000038:notes:105]
(2)    Other segment items include strategic investment activity and other small charges.

[0000106040-25-000038:notes:106]
Disaggregated Revenue

[0000106040-25-000038:notes:107]
The Company’s disaggregated revenue by end market is as follows:

[0000106040-25-000038:notes:108]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |
| Cloud | $ | 8,341 |  |  | $ | 5,052 |  |  | $ | 4,753 |  |
| Client | 556 |  |  | 577 |  |  | 691 |  |
| Consumer | 623 |  |  | 688 |  |  | 811 |  |
| Total revenue | $ | 9,520 |  |  | $ | 6,317 |  |  | $ | 6,255 |  |

[0000106040-25-000038:notes:109]
The Company’s operations outside the United States include manufacturing facilities in China, Japan, Malaysia, the Philippines and Thailand, as well as sales offices throughout the Americas, Asia Pacific, Europe, the Middle East and Africa. The following tables summarize the Company’s operations by geographic area:

[0000106040-25-000038:notes:110]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net revenue (1) |  |  |  |  |  |
| United States | $ | 4,328 |  |  | $ | 2,636 |  |  | $ | 2,694 |  |
| China | 1,549 |  |  | 488 |  |  | 471 |  |
| Hong Kong | 1,051 |  |  | 1,331 |  |  | 1,139 |  |
| Rest of Asia | 792 |  |  | 573 |  |  | 546 |  |
| Europe, Middle East and Africa | 1,536 |  |  | 1,067 |  |  | 1,175 |  |
| Other | 264 |  |  | 222 |  |  | 230 |  |
| Total | $ | 9,520 |  |  | $ | 6,317 |  |  | $ | 6,255 |  |

[0000106040-25-000038:notes:111]
(1)    Net revenue is attributed to geographic regions based on the ship-to location of the customer.

[0000106040-25-000038:notes:112]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Long-lived assets (1) |  |  |  |
| United States | $ | 807 |  |  | $ | 810 |  |
| Malaysia | 378 |  |  | 330 |  |
| China | 87 |  |  | 89 |  |
| Thailand | 791 |  |  | 825 |  |
| Rest of Asia | 279 |  |  | 304 |  |
| Europe, Middle East and Africa | 1 |  |  | 1 |  |
| Total | $ | 2,343 |  |  | $ | 2,359 |  |

[0000106040-25-000038:notes:113]
(1)    Long-lived assets include property, plant and equipment and are attributed to the geographic location in which they are located.

[0000106040-25-000038:notes:114]
Customer Concentration and Credit Risk

[0000106040-25-000038:notes:115]
The Company sells its products to cloud service providers, OEMs, resellers, distributors and retailers throughout the world. For 2025, three customers accounted for 17%, 12% and 10%, respectively, of the Company’s net revenue. For 2024 and 2023, no single customer accounted for 10% or more of the Company’s net revenue. For 2025, 2024 and 2023, the Company’s top 10 customers accounted for 68%, 55% and 56%, respectively, of the Company’s net revenue.

[0000106040-25-000038:notes:116]
The Company performs ongoing credit evaluations of its customers’ financial condition to manage collection risk, in some cases supplemented by collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial condition. As of June 27, 2025 and June 28, 2024, net accounts receivable were $1.49 billion and $1.23 billion, respectively, and reserves for potential credit losses were not material. As of June 27, 2025, three customers accounted for 20%, 19%, and 12%, respectively, of the Company’s net accounts receivable and as of June 28, 2024, one customer accounted for 23% of the Company’s net accounts receivable.

[0000106040-25-000038:notes:117]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and require that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0000106040-25-000038:notes:118]
Supplier Concentration

[0000106040-25-000038:notes:119]
Some key components are purchased from single source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect on its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000106040-25-000038:notes:120]
Supplemental Financial Statement Data
Accounts receivable, net

[0000106040-25-000038:notes:121]
From time to time, in connection with factoring agreements, the Company sells trade accounts receivable without recourse to third-party purchasers in exchange for cash. In 2025, the Company sold no trade accounts receivable. In 2024 and 2023, the Company sold trade accounts receivable aggregating to $284 million and $406 million, respectively. The discounts on the trade accounts receivable sold during the periods were not material and were recorded within Other income (expense), net in the Consolidated Statements of Operations. As of June 27, 2025 and June 28, 2024, no factored receivables were outstanding.

[0000106040-25-000038:notes:122]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 227 |  |  | $ | 329 |  |
| Work-in-process | 785 |  |  | 829 |  |
| Finished goods | 279 |  |  | 229 |  |
| Total inventories | $ | 1,291 |  |  | $ | 1,387 |  |

[0000106040-25-000038:notes:123]
Property, plant and equipment, net

[0000106040-25-000038:notes:124]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land and improvements | $ | 225 |  |  | $ | 225 |  |
| Buildings and improvements | 1,550 |  |  | 1,419 |  |
| Machinery and equipment | 6,488 |  |  | 6,301 |  |
| Computer equipment and software | 257 |  |  | 313 |  |
| Furniture and fixtures | 33 |  |  | 32 |  |
| Construction-in-process | 532 |  |  | 685 |  |
| Property, plant and equipment, gross | 9,085 |  |  | 8,975 |  |
| Accumulated depreciation | (6,742) |  |  | (6,616) |  |
| Property, plant and equipment, net | $ | 2,343 |  |  | $ | 2,359 |  |

[0000106040-25-000038:notes:125]
Depreciation expense for property, plant and equipment totaled $334 million, $347 million and $389 million in 2025, 2024 and 2023, respectively.

[0000106040-25-000038:notes:126]
Other intangible assets, net

[0000106040-25-000038:notes:127]
The Company has acquired IPR&D for projects in progress that had not yet reached technological feasibility at the time of acquisition. IPR&D is initially accounted for as an indefinite-lived intangible asset at the time of acquisition. Once a project reaches technological feasibility, the Company reclassifies the balance to existing technology and begins to amortize the intangible asset over its estimated useful life. As of both June 27, 2025 and June 28, 2024, Other non-current assets included $72 million of IPR&D. During 2025, 2024 and 2023, the Company did not record any impairment charges related to IPR&D.

[0000106040-25-000038:notes:128]
Non-current assets

[0000106040-25-000038:notes:129]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Non-current assets: |  |  |  |
| Deferred tax assets | $ | 1,007 |  |  | $ | 225 |  |
| Other non-current assets | 477 |  |  | 612 |  |
| Total non-current assets | $ | 1,484 |  |  | $ | 837 |  |

[0000106040-25-000038:notes:130]
Product warranty liability

[0000106040-25-000038:notes:131]
Changes in the warranty accrual were as follows:

[0000106040-25-000038:notes:132]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| Warranty accrual, beginning of period |  |  |  |  | $ | 142 |  |  | $ | 202 |  |  | $ | 293 |  |
| Charges to operations |  |  |  |  | 99 |  |  | 79 |  |  | 76 |  |
| Utilization |  |  |  |  | (83) |  |  | (119) |  |  | (143) |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (6) |  |  | (20) |  |  | (24) |  |
| Warranty accrual, end of period |  |  |  |  | $ | 152 |  |  | $ | 142 |  |  | $ | 202 |  |

[0000106040-25-000038:notes:133]
The current portion of the warranty accrual is classified in Accrued expenses and the long-term portion is classified in Other liabilities as noted below:

[0000106040-25-000038:notes:134]
|  | June 27,2025 |  | June 28,2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion (included in Accrued expenses) | $ | 57 |  |  | $ | 9 |  |  |  |  |  |  |  |
| Long-term portion (included in Other liabilities) | 95 |  |  | 133 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 152 |  |  | $ | 142 |  |  |  |  |  |  |  |

[0000106040-25-000038:notes:135]
Other liabilities

[0000106040-25-000038:notes:136]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current net tax payable | $ | — |  |  | $ | 200 |  |
| Non-current portion of unrecognized tax benefits | 163 |  |  | 443 |  |
| Other non-current liabilities | 396 |  |  | 359 |  |
| Total other liabilities | $ | 559 |  |  | $ | 1,002 |  |

[0000106040-25-000038:notes:137]
Goodwill

[0000106040-25-000038:notes:138]
Management performed its annual goodwill impairment assessment as of the first day of its fourth quarter ended June 27, 2025 and concluded there were no impairment indicators as of June 27, 2025. The Company also did not incur any impairment charges for 2025, 2024 or 2023. The carrying amount of goodwill was $4.32 billion as of both June 27, 2025 and June 28, 2024.

[0000106040-25-000038:notes:139]
Accumulated other comprehensive income (loss)

[0000106040-25-000038:notes:140]
Accumulated other comprehensive income (loss), net of tax, refers to expenses, gains and losses that are recorded as an element of shareholders’ equity but are excluded from net income. The following table illustrates the changes in the balances of each component of Accumulated other comprehensive income (loss):

[0000106040-25-000038:notes:141]
|  | Actuarial Pension Gains (Losses) |  | Foreign Currency Translation Adjustment |  |  |  |  |  | Unrealized Gains (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Income (Loss) |
|  | (in millions) |
| Balance at June 30, 2023 | $ | (2) |  |  | $ | (389) |  |  |  |  |  |  | $ | (157) |  |  | $ | (548) |  |
| Other comprehensive income (loss) before reclassifications | 23 |  |  | (115) |  |  |  |  |  |  | (331) |  |  | (423) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | 244 |  |  | 244 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss) | (7) |  |  | (1) |  |  |  |  |  |  | 23 |  |  | 15 |  |
| Net current-period other comprehensive income (loss) | 16 |  |  | (116) |  |  |  |  |  |  | (64) |  |  | (164) |  |
| Balance at June 28, 2024 | 14 |  |  | (505) |  |  |  |  |  |  | (221) |  |  | (712) |  |
| Other comprehensive income before reclassifications | 3 |  |  | 45 |  |  |  |  |  |  | 31 |  |  | 79 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  |  |  |  |  | 149 |  |  | 149 |  |
| Income tax expense related to items of other comprehensive income | (1) |  |  | — |  |  |  |  |  |  | (41) |  |  | (42) |  |
| Net current-period other comprehensive income | 2 |  |  | 45 |  |  |  |  |  |  | 139 |  |  | 186 |  |
| Distribution in connection with the Separation | — |  |  | 458 |  |  |  |  |  |  | 88 |  |  | 546 |  |
| Balance at June 27, 2025 | $ | 16 |  |  | $ | (2) |  |  |  |  |  |  | $ | 6 |  |  | $ | 20 |  |

[0000106040-25-000038:notes:142]
During 2025 and 2024, the amounts reclassified out of Accumulated other comprehensive income (loss) included losses of $149 million and $244 million, respectively, related to foreign exchange contracts.
As of June 27, 2025, all existing net losses related to cash flow hedges recorded in Accumulated other comprehensive income (loss) are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0000106040-25-000038:notes:143]
Fair Value Measurements and Investments
Financial Instruments Carried at Fair Value

[0000106040-25-000038:notes:144]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0000106040-25-000038:notes:145]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0000106040-25-000038:notes:146]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0000106040-25-000038:notes:147]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0000106040-25-000038:notes:148]
The following tables present information about the Company’s financial assets and liabilities that are measured at fair value on a recurring basis as of June 27, 2025 and June 28, 2024, and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0000106040-25-000038:notes:149]
|  | June 27, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Retained interest in Sandisk | $ | 354 |  |  | $ | — |  |  | $ | — |  |  | $ | 354 |  |
| Cash equivalents – Money market funds | 285 |  |  | — |  |  | — |  |  | 285 |  |
| Foreign exchange contracts | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets at fair value | $ | 639 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 649 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0000106040-25-000038:notes:150]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents – Money market funds | $ | 388 |  |  | $ | — |  |  | $ | — |  |  | $ | 388 |  |
| Foreign exchange contracts | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets at fair value | $ | 388 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 389 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |

[0000106040-25-000038:notes:151]
Retained Interest in Sandisk. The Company retained 28.8 million shares of Sandisk at the Separation. These shares are valued based on quoted market prices. As discussed in Note 8, Debt, the Company exchanged 21.3 million shares of Sandisk to settle a portion of the Company’s Term Loan A-3. As of June 27, 2025, the Company still held 7.5 million shares of Sandisk.

[0000106040-25-000038:notes:152]
Money Market Funds. The Company’s money market funds are funds that invest in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0000106040-25-000038:notes:153]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on a present value of future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. For more information on the Company’s foreign exchange contracts, see Note 7, Derivative Instruments and Hedging Activities. Derivative assets and liabilities are reflected in the Company’s Consolidated Balance Sheets under Other current assets and Accrued expenses, respectively.

[0000106040-25-000038:notes:154]
During 2025 and 2024, the Company had no transfers of financial assets and liabilities between levels and there were no changes in valuation techniques and the inputs used in the fair value measurement.

[0000106040-25-000038:notes:155]
Financial Instruments Not Carried at Fair Value

[0000106040-25-000038:notes:156]
The following table contains the related carrying value (which includes principal adjusted for any unamortized issuance costs, and discounts or premiums) and fair value (which is based on quoted market prices) for each of the Company’s outstanding financial instruments. Each of the financial instruments presented below was categorized as Level 2 for all periods presented, based on the frequency of trading immediately prior to the end of the fourth quarter of 2025 and the fourth quarter of 2024, respectively.

[0000106040-25-000038:notes:157]
|  | June 27, 2025 |  | June 28, 2024 |
|  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 499 |  |  | $ | 2,296 |  |  | $ | 2,253 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | — |  |  | 2,578 |  |  | 2,539 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,642 |  |  | 1,655 |  |  | — |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,575 |  |  | 2,849 |  |  | 1,568 |  |  | 2,556 |  |
| 2.85% senior notes due 2029 | 498 |  |  | 463 |  |  | 496 |  |  | 434 |  |
| 3.10% senior notes due 2032 | 496 |  |  | 442 |  |  | 496 |  |  | 407 |  |
| Total | $ | 4,711 |  |  | $ | 5,908 |  |  | $ | 7,434 |  |  | $ | 8,189 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000106040-25-000038:notes:158]
Derivative Instruments and Hedging Activities
As of June 27, 2025, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. All of the contract maturity dates of these foreign exchange forward contracts are 12 months or less. As of June 27, 2025, the Company did not have any derivative contracts with credit risk related contingent features.

[0000106040-25-000038:notes:159]
Changes in fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net and are largely offset by corresponding changes in the fair values of the foreign-currency denominated monetary assets and liabilities. For each of 2025, 2024 and 2023, total net realized and unrealized transaction and foreign exchange contract currency gains and losses were not material to the Company’s Consolidated Financial Statements.

[0000106040-25-000038:notes:160]
Unrealized gains or losses on designated cash flow hedges are recognized in Accumulated other comprehensive income (loss). For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data – Accumulated other comprehensive income (loss).

[0000106040-25-000038:notes:161]
Netting Arrangements

[0000106040-25-000038:notes:162]
Under certain provisions and conditions within agreements with counterparties to the Company’s foreign exchange forward contracts, subject to applicable requirements, the Company has the right of offset associated with the Company’s foreign exchange forward contracts and is allowed to net settle transactions of the same currency with a single net amount payable by one party to the other. As of June 27, 2025 and June 28, 2024, the effect of rights of offset was not material and the Company did not offset or net the fair value amounts of derivative instruments in its Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000106040-25-000038:notes:163]
Debt
Debt consisted of the following:

[0000106040-25-000038:notes:164]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| 4.75% senior unsecured notes due 2026 | $ | 500 |  |  | $ | 2,300 |  |
| Variable interest rate Term Loan A-2 maturing 2027 | — |  |  | 2,588 |  |
| Variable interest rate Term Loan A-3 maturing 2027 | 1,649 |  |  | — |  |
| 3.00% convertible notes due 2028 | 1,600 |  |  | 1,600 |  |
| 2.85% senior notes due 2029 | 500 |  |  | 500 |  |
| 3.10% senior notes due 2032 | 500 |  |  | 500 |  |
| Total debt | 4,749 |  |  | 7,488 |  |
| Issuance costs | (38) |  |  | (54) |  |
| Subtotal | 4,711 |  |  | 7,434 |  |
| Less: current portion of long-term debt | (2,226) |  |  | (1,750) |  |
| Long-term debt | $ | 2,485 |  |  | $ | 5,684 |  |

[0000106040-25-000038:notes:165]
Revolving Credit Facility and Term Loans

[0000106040-25-000038:notes:166]
On February 20, 2025, the Company entered into a fourth amendment to the loan agreement governing the Company’s revolving credit facility maturing in January 2027 (the “2027 Revolving Credit Facility”) and Term Loan Facility (as defined below), dated as of January 7, 2022 (as amended, the “Loan Agreement”) that, among other changes, (a) permitted the Separation, (b) provided for the automatic release, in connection with the Separation, of guarantees and liens on collateral provided by Sandisk and Sandisk Technologies, Inc. under the Loan Agreement, (c) provided for the issuance of a new $2.51 billion Term Loan A-3 maturing in January 2027 (the “Term Loan A-3”) in a noncash exchange to replace the Company’s previously existing Term Loan A-2 (the “Term Loan A-2” and, together with the Term Loan A-3, the “Term Loan Facility”), (d) facilitated the exchange of Sandisk shares retained at the Separation to settle a portion of the Term Loan A-3 in connection with the Sandisk retained interest, and (e) in connection with the Separation, reduced the aggregate commitments under the 2027 Revolving Credit Facility from $2.25 billion to $1.25 billion. In June 2025, the Company settled $800 million of the Term Loan A-3 principal amount, through a non-cash exchange of 21.3 million shares of Sandisk common stock held by the Company, and a $4 million cash payment, resulting in a loss on extinguishment of debt of $100 million.

[0000106040-25-000038:notes:167]
During the year ended June 27, 2025, the Company also made principal repayments aggregating to $138 million on its Term Loan Facility. As of June 27, 2025, the remaining balance of Term Loan A-3 amortizes in quarterly installments of $31 million per quarter beginning with the quarter ending October 3, 2025, and the remaining balance is payable at maturity on January 7, 2027. Issuance costs for the Term Loan Facility are amortized to Interest expense over its term and unamortized costs were $7 million as of June 27, 2025.

[0000106040-25-000038:notes:168]
The Term Loan A-3 Loan bears interest, at the Company’s option, at a per annum rate equal to either (x) the Adjusted Term SOFR (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies (as defined in the Loan Agreement), with an initial interest rate of Adjusted Term SOFR plus 1.500%. The all-in interest rate for Term Loan A-3 as of June 27, 2025 was 5.918%.

[0000106040-25-000038:notes:169]
During the year ended June 27, 2025, the Company drew and repaid $150 million principal amount under its $1.25 billion 2027 Revolving Facility. Loans under the 2027 Revolving Facility bear interest at a per annum rate, at the Company’s option, equal to either (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an applicable margin varying from 1.125% to 2.000% or (y) a base rate plus an applicable margin varying from 0.125% to 1.000%, in each case depending on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an interest rate of Adjusted Term SOFR plus 1.375%. The Company is also required to pay an unused commitment fee on the 2027 Revolving Facility ranging from 0.120% to 0.350% based on the corporate family ratings of the Company from at least two of the Credit Rating Agencies, with an initial unused commitment fee of 0.200%.

[0000106040-25-000038:notes:170]
As of June 27, 2025, the Company had an insignificant amount of issued standby letters of credit.

[0000106040-25-000038:notes:171]
The Loan Agreement governing the 2027 Revolving Credit Facility and the term loan facility requires the Company to maintain a ratio (“Leverage Ratio”) of total funded debt to Consolidated Adjusted EBITDA (as defined in the Loan Agreement) below a maximum, at the end of each quarter, which was 3.75 times through June 27, 2025 and will be 3.25 times thereafter. As of June 27, 2025, the Company was in compliance with all financial covenants under the Loan Agreement.

[0000106040-25-000038:notes:172]
The Loan Agreement also requires the Company to comply with customary covenants that include, among others, limitations on the incurrence of additional debt, liens on property, acquisitions and investments, loans and guarantees, mergers, consolidations, liquidations and dissolution, asset sales, dividends and distribution, and other payments in respect of the Company’s capital stock, prepayments of certain debt, transactions with affiliates and certain modifications of organizational documents and certain debt agreements.

[0000106040-25-000038:notes:173]
Senior Notes

[0000106040-25-000038:notes:174]
In February 2018, the Company issued $2.30 billion aggregate principal amount of senior unsecured notes due February 15, 2026 (the “2026 Senior Unsecured Notes”). The 2026 Senior Unsecured Notes bear interest at an annual rate of 4.750% with interest payable on February 15 and August 15 of each year. The Company is not required to make principal payments on the 2026 Senior Unsecured Notes prior to the maturity date. In April 2025 however, the Company redeemed, at its election, $1.80 billion aggregate principal amount of its 2026 Unsecured Notes at par plus accrued interest.

[0000106040-25-000038:notes:175]
On November 3, 2023, the Company issued $1.60 billion aggregate principal amount of convertible senior notes which bear interest at an annual rate of 3.00% and mature on November 15, 2028, unless earlier repurchased, redeemed or converted (the “2028 Convertible Notes”). The Company is not required to make principal payments on the 2028 Convertible Notes prior to the maturity date. The 2028 Convertible Notes are guaranteed by Western Digital Technologies, Inc., the Company’s wholly-owned subsidiary that also guarantees the 2026 Senior Unsecured Notes.

[0000106040-25-000038:notes:176]
The 2028 Convertible Notes are convertible at the option of any holder beginning on August 15, 2028, at a conversion price of approximately $37.82 per share of common stock (which conversion price has been adjusted from its original conversion price of approximately $52.20 in accordance with the Indenture, as a result of the Separation and dividends paid on the Company’s common stock). Prior to August 15, 2028, if the trading price of the Company’s common stock remains above 130% of the conversion price for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading-day period prior to the end of a calendar quarter, holders of the 2028 Convertible Notes would have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter. The 2028 Convertible Notes are also convertible prior to August 15, 2028 upon the occurrence of certain corporate events. Upon any conversion of the 2028 Convertible Notes, the Company will pay cash for the aggregate principal amount of the notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination thereof, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the notes being converted. On or after November 15, 2026, the Company may redeem for cash, at par plus accrued interest, all or any portion of the 2028 Convertible Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price then in effect for at least 10 trading days during any 20 consecutive trading day period immediately preceding the date of the Company’s redemption notice.

[0000106040-25-000038:notes:177]
During the calendar quarter ended June 30, 2025, the sale price conditional conversion feature of the 2028 Convertible Notes was triggered. As a result, the holders of the 2028 Convertible Notes have the right to convert the 2028 Convertible Notes during the next succeeding calendar quarter, through September 30, 2025, at which point the common stock price will be re-evaluated to determine whether the 2028 Convertible Notes will continue to be convertible in the subsequent calendar quarter. The Company has classified the 2028 Convertible Notes as current liabilities in the Company’s Consolidated Financial Statements as of June 27, 2025.

[0000106040-25-000038:notes:178]
Net proceeds from the 2028 Convertible Notes were approximately $1.56 billion after deducting issuance costs of approximately $37 million. Debt issuance costs are amortized to interest expense over the term of the 2028 Convertible Notes. As of June 27, 2025, issuance costs of $25 million remained unamortized.

[0000106040-25-000038:notes:179]
In connection with the issuance of the 2028 Convertible Notes, the Company also entered into privately negotiated capped call transactions with certain counterparties (the “Capped Calls”). The Capped Calls each have a strike price of approximately $37.82 per share, which has been adjusted from its original strike price of approximately $52.20, in accordance with the terms of the agreements, and corresponds to the current conversion price of the 2028 Convertible Notes. The Capped Calls are subject to the same adjustments applicable to the conversion price of the convertible notes, which the Company expects will result in adjusted cap prices of approximately $50.53 per share, subject to certain adjustments. The Capped Calls are generally intended to reduce or offset the potential dilution to the Company’s common stock upon any conversion of the 2028 Convertible Notes with such reduction or offset, as the case may be, subject to a cap based on the cap price. If the market price per share of the Company’s common stock, as measured under the terms of the Capped Calls, exceeds the cap prices of the Capped Calls, there would not be an offset for the excess. The Capped Calls are separate transactions and not part of the terms of the 2028 Convertible Notes. As these transactions met certain accounting criteria, the Capped Calls were recorded in shareholders’ equity and are not accounted for as derivatives. The cost of the Capped Calls of $155 million, net of $37 million in deferred tax assets, was recorded as a decrease to Additional paid-in capital on the Company’s Consolidated Balance Sheets.

[0000106040-25-000038:notes:180]
In December 2021, the Company issued $500 million aggregate principal amount of 2.850% senior notes due February 1, 2029 (the “2029 Senior Notes”) and issued $500 million aggregate principal amount of 3.100% senior notes due February 1, 2032 (the “2032 Senior Notes”), pursuant to the terms of an indenture, dated as of December 10, 2021 (the “Base Indenture”) between the Company and U.S. Bank National Association, as trustee (the “Senior Notes Trustee”), as supplemented by the first supplemental indenture dated as of December 10, 2021 (the “Senior Notes First Supplemental Indenture”) between the Company and the Senior Notes Trustee. As used herein, “Indenture” means the Base Indenture, as supplemented by the Senior Notes First Supplemental Indenture. Interest for both the 2029 Senior Notes and 2032 Senior Notes is payable on February 1 and August 1 of each year. The Company is not required to make principal payments on either the 2029 Senior Notes or 2032 Senior Notes prior to their maturity dates.

[0000106040-25-000038:notes:181]
In February 2018, the Company issued $1.10 billion aggregate principal amount of convertible senior notes due February 1, 2024 (the “2024 Convertible Notes”). The 2024 Convertible Notes bore interest at an annual rate of 1.50% with interest payable on February 1 and August 1 of each year. Contemporaneously with the issuance of the 2028 Convertible Notes as noted above, the Company entered into individually negotiated transactions with certain holders of the Company’s 2024 Convertible Notes to repurchase approximately $508 million aggregate principal amount of such notes at an immaterial discount. On February 1, 2024, the Company settled all remaining 2024 Convertible Notes in accordance with their original terms for an aggregate cash principal payment of $592 million plus interest.

[0000106040-25-000038:notes:182]
Collateral and Restrictive Covenants

[0000106040-25-000038:notes:183]
Under the terms of the Loan Agreement, the 2027 Revolving Facility and Term Loan Facility (together, the “Credit Facilities”) are unconditionally guaranteed by Western Digital Technologies, Inc. (the “Guarantor”) and are secured on a first-priority basis (subject to permitted liens) by a lien on substantially all assets and properties of the Company and the Guarantor (the “Collateral”), subject to certain exceptions. Furthermore, under the terms of the applicable indentures, the obligations under the Company’s 2.850% Senior Notes due 2029 and 3.100% Senior Notes due 2032 have been secured by the Collateral on an equal and ratable basis to the obligations under the Credit Facilities, and the obligations under the Company’s 2026 Senior Unsecured Notes have been guaranteed by the Guarantor pursuant to the First Supplemental Indenture dated as of June 20, 2023 and the Second Supplemental Indenture dated as of April 26, 2024 (the “2026 Senior Notes Supplemental Indentures”).

[0000106040-25-000038:notes:184]
The indentures and supplemental indentures, as applicable, governing the Company’s 2029 Senior Notes, 2032 Senior Notes, 2026 Senior Unsecured Notes and the 2028 Convertible Notes each contain various restrictive covenants, which can include limitations on the Company’s and its subsidiaries’ ability to, among other things, consolidate, merge or sell all or substantially all of their assets; create liens; and incur, assume or guarantee additional indebtedness, and are subject to a number of limitations and exceptions.

[0000106040-25-000038:notes:185]
Maturity of Debt

[0000106040-25-000038:notes:186]
As of June 27, 2025, the Company is subject to required principal payment or earlier conversion, at the option of the holder, as follows:

[0000106040-25-000038:notes:187]
|  |  | Contractual Maturity (1) |
|  |  | (in millions) |
| Fiscal year: |  |  |
| 2026 |  | $ | 2,226 |  |
| 2027 |  | 1,523 |  |
| 2028 |  | — |  |
| 2029 |  | 500 |  |
| 2030 |  | — |  |
| 2031 and thereafter |  | 500 |  |
| Total debt maturities |  | 4,749 |  |
| Issuance costs |  | (38) |  |
| Net carrying value |  | $ | 4,711 |  |

[0000106040-25-000038:notes:188]
(1)    As of June 30, 2025, the holders of the 2028 Convertible Notes will have the option to convert the notes from July 1, 2025 through September 30, 2025. As such, the principal portion of these notes is reflected as current in the table above.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000106040-25-000038:notes:189]
Pension and Other Post-Retirement Benefit Plans
The Company has pension and other post-retirement benefit plans in various countries. The Company’s principal pension plans are in Japan, Thailand, and the Philippines (the “Pension Plans”). All other pension and other post-retirement benefit plans are immaterial to the Consolidated Financial Statements. The expected long-term rate of return on the Pension Plans’ assets is 2.5%.

[0000106040-25-000038:notes:190]
Obligations and Funded Status

[0000106040-25-000038:notes:191]
The following table presents the changes in unfunded status of the benefit obligations for the Pension Plans:

[0000106040-25-000038:notes:192]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Change in benefit obligation: |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 244 |  |  | $ | 273 |  |  | $ | 294 |  |
| Service cost | 9 |  |  | 9 |  |  | 14 |  |
| Interest cost | 7 |  |  | 6 |  |  | 6 |  |
| Plan amendments | — |  |  | — |  |  | — |  |
| Actuarial gain | (6) |  |  | (17) |  |  | (6) |  |
| Benefits paid | (8) |  |  | (7) |  |  | (8) |  |
| Settlement/curtailment | — |  |  | 2 |  |  | (15) |  |
| Other | — |  |  | — |  |  | — |  |
| Non-U.S. currency movement | 26 |  |  | (22) |  |  | (12) |  |
| Projected benefit obligation at end of period | 272 |  |  | 244 |  |  | 273 |  |
| Change in plan assets: |  |  |  |  |  |
| Fair value of plan assets at beginning of period | 184 |  |  | 185 |  |  | 189 |  |
| Actual return on plan assets | 3 |  |  | 12 |  |  | 7 |  |
| Employer contributions | 6 |  |  | 13 |  |  | 9 |  |
| Benefits paid | (8) |  |  | (7) |  |  | (8) |  |
| Non-U.S. currency movement | 19 |  |  | (19) |  |  | (12) |  |
| Fair value of plan assets at end of period | 204 |  |  | 184 |  |  | 185 |  |
| Unfunded status | $ | 68 |  |  | $ | 60 |  |  | $ | 88 |  |

[0000106040-25-000038:notes:193]
The following table presents the unfunded amounts related to the Pension Plans as recognized on the Company’s Consolidated Balance Sheets:

[0000106040-25-000038:notes:194]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Current liabilities | $ | 1 |  |  | $ | 1 |  |
| Non-current liabilities | 67 |  |  | 59 |  |
| Net amount recognized | $ | 68 |  |  | $ | 60 |  |

[0000106040-25-000038:notes:195]
The accumulated benefit obligation for the Pension Plans was $272 million at June 27, 2025. As of June 27, 2025, the accumulated other income pension balance was $27 million. There were no material prior service credits for the Pension Plans recognized in Accumulated other comprehensive income (loss) in the Consolidated Balance Sheet as of June 27, 2025.

[0000106040-25-000038:notes:196]
Net periodic benefit costs were not material for 2025, 2024 and 2023.

[0000106040-25-000038:notes:197]
Assumptions

[0000106040-25-000038:notes:198]
Weighted-Average Assumptions

[0000106040-25-000038:notes:199]
The weighted-average actuarial assumptions used to determine the projected benefit obligations for the Pension Plans were as follows:

[0000106040-25-000038:notes:200]
|  | 2025 |  | 2024 |  | 2023 |
| Discount rate | 2.9 | % |  | 3.0 | % |  | 2.2 | % |
| Rate of compensation increase | 2.7 | % |  | 2.7 | % |  | 2.4 | % |

[0000106040-25-000038:notes:201]
The weighted-average actuarial assumptions used to determine benefit costs for the Pension Plans were as follows:

[0000106040-25-000038:notes:202]
|  | 2025 |  | 2024 |  | 2023 |
| Discount rate | 3.0 | % |  | 2.2 | % |  | 2.3 | % |
| Expected long-term rate of return on plan assets | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Rate of compensation increase | 2.7 | % |  | 2.4 | % |  | 2.3 | % |

[0000106040-25-000038:notes:203]
The Company develops a discount rate by calculating when the estimated benefit payments will be due. Management then matches the benefit payments to high quality bonds which match the timing of the expected benefit payments to determine the appropriate discount rate.

[0000106040-25-000038:notes:204]
The Company develops the expected long-term rate of return on plan assets by analyzing rates of return in each plan as well as the investment portfolio applicable to the plan depending on each plan’s economic environment. The Company’s estimates of future rates of return on assets is based in large part on the projected rate of return from the respective investment managers using a long-term view of historical returns, as well as actuarial recommendations using the most current generational and mortality tables and rates. As of June 27, 2025, the Pension Plans’ assets materially consisted of plan assets related to the Japan pension plan and, as such, the assumption used herein is primarily related to the Japan pension plan.

[0000106040-25-000038:notes:205]
The Company develops the rate of compensation increase assumptions using local compensation practices and historical rates of increases.

[0000106040-25-000038:notes:206]
Plan Assets

[0000106040-25-000038:notes:207]
Investment Policies and Strategies

[0000106040-25-000038:notes:208]
The investment policy in the Pension Plans is to generate a stable return on investments over a long-term horizon in order to have adequate pension funds to meet the Company’s future obligations. In order to achieve this investment goal, a diversified portfolio with target asset allocation and expected rate of return is established by considering factors such as composition of participants, level of funded status, capacity to absorb risks and the current economic environment. The target asset allocation is 55% in debt securities, 30% in equity securities, and the remaining 15% in other assets. Risk management is accomplished through diversification, periodic review of plan asset performance and appropriate realignment of asset allocation. Assumptions regarding the expected long-term rate of return on plan assets are periodically reviewed and are based on the historical trend of returns, the risk and correlation of each asset and the latest economic environment.

[0000106040-25-000038:notes:209]
The expected long-term rate of return is estimated based on many factors, including expected forecast for inflation, risk premiums for each asset class, expected asset allocation, current and future financial market conditions and diversification and rebalancing strategies. Historical return patterns and correlations, consensus return forecasts and other relevant financial factors are analyzed periodically by the investment advisor so as to ensure that the expected long-term rate of return is reasonable and appropriate.

[0000106040-25-000038:notes:210]
Fair Value Measurements

[0000106040-25-000038:notes:211]
The following tables present the Pension Plans’ major asset categories and their associated fair values and net asset values as of June 27, 2025 and June 28, 2024:

[0000106040-25-000038:notes:212]
|  | June 27, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 110 |  |  | — |  |  | 110 |  |
| Net plan assets subject to leveling | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Real estate investment trust at net asset value | — |  |  | — |  |  | — |  |  | 28 |  |
| Total investments at fair value | $ | — |  |  | $ | 176 |  |  | $ | — |  |  | $ | 204 |  |

[0000106040-25-000038:notes:213]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Plan assets measured at fair value: |  |  |  |
| Equity: |  |  |  |  |  |
| Equity commingled/mutual funds(1)(2) | $ | — |  |  | $ | 58 |  |  | $ | — |  |  | $ | 58 |  |
| Fixed income: |  |  |  |  |  |  |  |
| Fixed income commingled/mutual funds(1)(3) | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Net plan assets subject to leveling | — |  |  | 157 |  |  | — |  |  | 157 |  |
| Real estate investment trust at net asset value | — |  |  | — |  |  | — |  |  | 27 |  |
| Total investments at fair value | $ | — |  |  | $ | 157 |  |  | $ | — |  |  | $ | 184 |  |

[0000106040-25-000038:notes:214]
(1)    Commingled funds represent pooled institutional investments.

[0000106040-25-000038:notes:215]
(2)    Equity mutual funds invest primarily in equity securities.

[0000106040-25-000038:notes:216]
(3)    Fixed income mutual funds invest primarily in fixed income securities.

[0000106040-25-000038:notes:217]
There were no significant movements of assets between any level categories in 2025 or 2024.

[0000106040-25-000038:notes:218]
Fair Value Valuation Techniques

[0000106040-25-000038:notes:219]
Equity securities are valued at the closing price reported on the stock exchange on which the individual securities are traded. Equity commingled/mutual funds are typically valued using the net asset value (“NAV”) provided by the investment manager or administrator of the fund. The NAV is based on the value of the underlying assets owned by the fund, minus liabilities and divided by the number of shares or units outstanding. These assets are classified as either Level 1 or Level 2, depending on availability of quoted market prices for identical or similar assets.

[0000106040-25-000038:notes:220]
If available, fixed income securities are valued using the close price reported on the major market on which the individual securities are traded and are classified as Level 1. The fair value of other fixed income securities is typically estimated using pricing models and quoted prices of securities with similar characteristics and is generally classified as Level 2.

[0000106040-25-000038:notes:221]
Cash equivalents include money market accounts that are valued at their cost plus interest on a daily basis, which approximates fair value. Short-term investments represent securities with original maturities of one year or less. These assets are classified as either Level 1 or Level 2.

[0000106040-25-000038:notes:222]
Cash Flows

[0000106040-25-000038:notes:223]
The Company’s expected employer contributions for 2026 and annual benefit payments over the next five years for its Pension Plans are not expected to be material.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000106040-25-000038:notes:224]
Leases and Other Commitments 
Leases

[0000106040-25-000038:notes:225]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2034. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term.

[0000106040-25-000038:notes:226]
The following table presents right-of-use lease assets and lease liabilities included in the Company’s Consolidated Balance Sheets:

[0000106040-25-000038:notes:227]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Operating lease right-of-use assets (included in Other non-current assets) | $ | 123 |  |  | $ | 143 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in Accrued expenses) | 31 |  |  | 28 |  |
| Long-term operating lease liabilities (included in Other liabilities) | 110 |  |  | 133 |  |
| Total operating lease liabilities | $ | 141 |  |  | $ | 161 |  |

[0000106040-25-000038:notes:228]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases:

[0000106040-25-000038:notes:229]
|  |  |  | 2025 |  |  |  | 2024 |  | 2023 |
|  |  |  | (in millions) |
| Cost of operating leases |  |  | $ | 33 |  |  |  |  | $ | 41 |  |  | $ | 49 |  |
| Cash paid for operating leases |  |  | 36 |  |  |  |  | 44 |  |  | 43 |  |
| Operating lease assets obtained in exchange for operating lease liabilities |  |  | 18 |  |  |  |  | 10 |  |  | 11 |  |

[0000106040-25-000038:notes:230]
The weighted average remaining lease term and discount rate for the Company’s operating leases were as follows:

[0000106040-25-000038:notes:231]
|  | June 27,2025 |  | June 28,2024 |  |  |
| Weighted average remaining lease term in years | 6.1 |  | 6.6 |  |  |
| Weighted average discount rate | 5.0 | % |  | 5.0 | % |  |  |

[0000106040-25-000038:notes:232]
As of June 27, 2025, minimum lease payments were as follows:

[0000106040-25-000038:notes:233]
|  | Lease Amounts |  |  |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| 2026 | $ | 36 |  |  |  |  |  |  |  |  |  |
| 2027 | 30 |  |  |  |  |  |  |  |  |  |
| 2028 | 23 |  |  |  |  |  |  |  |  |  |
| 2029 | 18 |  |  |  |  |  |  |  |  |  |
| 2030 | 12 |  |  |  |  |  |  |  |  |  |
| Thereafter | 46 |  |  |  |  |  |  |  |  |  |
| Total future minimum lease payments | 165 |  |  |  |  |  |  |  |  |  |
| Less: imputed interest | 24 |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 141 |  |  |  |  |  |  |  |  |  |

[0000106040-25-000038:notes:234]
Purchase Agreements and Other Commitments

[0000106040-25-000038:notes:235]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. As of June 27, 2025, the Company had the following minimum long-term commitments:

[0000106040-25-000038:notes:236]
|  |  | Long-term Commitments |
|  |  | (in millions) |
| 2026 |  | $ | 50 |  |
| 2027 |  | 26 |  |
| Total |  | $ | 76 |  |


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000106040-25-000038:notes:237]
Western Digital Corporation 401(k) Plan 
The Company maintains the Western Digital Corporation 401(k) Plan (the “Plan”). The Plan covers substantially all U.S. employees, subject to certain eligibility requirements. Eligible employees receive employer matching contributions immediately upon hire. Eligible employees do not include individuals that are covered by a collective bargaining agreement, provide services as a consultant, interns, independent contractors, leased or temporary employees, or who otherwise are not treated as common-law employees.

[0000106040-25-000038:notes:238]
Eligible employees are able to contribute up to 85% of their eligible compensation on a combined pre-tax and Roth basis regardless of age, and 10% of their eligible compensation on an after-tax basis, all subject to U.S. Internal Revenue Service (“IRS”) limitations. The Company may make a basic matching contribution equal to 50% of each eligible participant’s contribution that does not exceed 6% of the eligible participant’s annual compensation in the year of contribution. Furthermore, the Company’s employer matching contributions vest immediately. Contributions, including the Company’s matching contribution to the Plan, are recorded as soon as administratively possible after the Company makes payroll deductions from Plan participants.

[0000106040-25-000038:notes:239]
Effective February 18, 2023, the Company announced its decision to suspend its previous practice of matching contributions. The Company later resumed matching contributions effective January 1, 2024.

[0000106040-25-000038:notes:240]
For 2025, 2024 and 2023, the Company made Plan contributions of $22 million, $8 million and $13 million, respectively.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000106040-25-000038:notes:241]
Shareholders’ Equity and Convertible Preferred Stock
2021 Long-Term Incentive Plan

[0000106040-25-000038:notes:242]
In November 2021, stockholders approved the Western Digital Corporation 2021 Long-Term Incentive Plan, (as amended and restated, the “2021 Plan”). Upon the effective date of the 2021 Plan, no new awards were granted under the Western Digital Corporation Amended and Restated 2017 Performance Incentive Plan (the “2017 Plan”). The types of awards that may be granted under the 2021 Plan include stock options, stock appreciation rights (“SARs”), RSUs, PSUs, restricted stock and other forms of awards granted or denominated in the Company’s common stock or units of the Company’s common stock, as well as cash awards. Persons eligible to receive awards under the 2021 Plan include officers and employees of the Company or any of its subsidiaries, directors of the Company and certain consultants and advisors to the Company or any of its subsidiaries. The vesting of awards under the 2021 Plan and the 2017 Plan is determined at the date of grant. Each award expires on a date determined at the date of grant; however, the maximum term of options and SARs is ten years after the grant date of the award. RSUs typically vest over periods ranging from two to four years from the date of grant. PSUs are granted to certain employees and vest only after the achievement of pre-determined performance conditions or market conditions and completion of requisite service periods. Once the performance conditions or market conditions are met, the employee’s vesting of PSUs is generally subject to continued service.

[0000106040-25-000038:notes:243]
Outstanding RSU and PSU awards have dividend equivalent rights which entitle holders of such outstanding awards to the same dividend value per share as holders of common stock. Dividend equivalent rights are subject to the same vesting and other terms and conditions as the corresponding unvested RSUs and PSUs. Dividend equivalent rights are accumulated and paid in additional shares when the underlying shares vest.

[0000106040-25-000038:notes:244]
As of June 27, 2025, the maximum number of shares of the Company’s common stock that was authorized for award grants under the 2021 Plan was 34.8 million shares. The 2021 Plan will terminate on November 22, 2031, unless terminated earlier by the Company’s Board of Directors.

[0000106040-25-000038:notes:245]
Employee Stock Purchase Plan

[0000106040-25-000038:notes:246]
Under the Company’s ESPP, eligible employees may authorize payroll deductions of up to 10% of their eligible compensation, subject to IRS limitations, during prescribed offering periods to purchase shares of the Company’s common stock at 95% of the fair market value of common stock either at the beginning of that offering period or on the applicable exercise date, whichever is less. A participant may participate in only one offering period at a time, and a new offering period generally begins each June 1st and December 1st. Each offering period is generally 24 months and consists of four exercise dates (each, generally six months following the start of the offering period or the preceding exercise date, as the case may be). If the fair market value of the Company’s common stock is less on a given exercise date than on the date of grant, employee participation in that offering period ends and participants are automatically re-enrolled in the next new offering period.

[0000106040-25-000038:notes:247]
During 2025, 2024 and 2023, the Company issued 2.0 million, 2.4 million and 2.7 million shares, respectively, under the ESPP for aggregate purchase amounts of $77 million, $81 million and $92 million, respectively.

[0000106040-25-000038:notes:248]
To the extent available, the Company may issue shares out of treasury stock upon the vesting of awards, the exercise of employee stock options and the purchase of shares pursuant to the ESPP.

[0000106040-25-000038:notes:249]
Stock-based Compensation Expense

[0000106040-25-000038:notes:250]
In connection with the Separation (as discussed in Note 3, Discontinued Operations), on February 21, 2025, all outstanding stock-based compensation awards associated with continuing Western Digital employees were adjusted with the intent to preserve the intrinsic value of each award immediately before and after the Separation. The adjustments were determined using a ratio calculated based on the closing price of the Company’s common stock immediately before the Separation and the average of the closing price on each of the first five days of trading after the Separation. In addition, for PSUs, the conditions related to the Company’s performance for the 2025 measurement period were modified and fixed at target. The remaining terms of the outstanding awards are unchanged and any unvested stock awards will continue to vest over the original vesting periods. An incremental value of approximately $40 million resulting from the adjustment of the unvested awards will be recognized ratably over the remaining service periods. Upon the Separation, approximately 3.1 million unvested stock-based compensation awards were retained by Sandisk employees and will vest upon completion of any remaining service period with Sandisk and approximately 3.5 million awards were cancelled from the Company’s incentive plans.

[0000106040-25-000038:notes:251]
The following tables present the Company’s stock-based compensation for equity-settled awards by type and financial statement line items as well as the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0000106040-25-000038:notes:252]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| RSUs and PSUs |  |  |  |  | $ | 151 |  |  | $ | 182 |  |  | $ | 201 |  |
| ESPP |  |  |  |  | 16 |  |  | 20 |  |  | 11 |  |
| Total |  |  |  |  | $ | 167 |  |  | $ | 202 |  |  | $ | 212 |  |

[0000106040-25-000038:notes:253]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| Cost of revenue |  |  |  |  | $ | 34 |  |  | $ | 36 |  |  | $ | 35 |  |
| Research and development |  |  |  |  | 73 |  |  | 65 |  |  | 70 |  |
| Selling, general and administrative |  |  |  |  | 60 |  |  | 101 |  |  | 107 |  |
| Subtotal |  |  |  |  | 167 |  |  | 202 |  |  | 212 |  |
| Tax benefit |  |  |  |  | (23) |  |  | (30) |  |  | (29) |  |
| Total |  |  |  |  | $ | 144 |  |  | $ | 172 |  |  | $ | 183 |  |

[0000106040-25-000038:notes:254]
Any shortfalls or excess windfall tax benefits related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0000106040-25-000038:notes:255]
Compensation costs related to unvested RSUs, PSUs and rights to purchase shares of common stock under the ESPP will generally be amortized on a straight-line basis over the remaining average service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 27, 2025:

[0000106040-25-000038:notes:256]
|  | Unamortized Compensation Costs |  | Weighted Average Service Period |
|  | (in millions) |  | (years) |
| RSUs and PSUs (1) | $ | 245 |  |  | 2.1 |
| ESPP | 23 |  |  | 1.4 |
| Total unamortized compensation cost | $ | 268 |  |  |  |

[0000106040-25-000038:notes:257]
(1)    Weighted average service period assumes the performance conditions are met for the PSUs.

[0000106040-25-000038:notes:258]
Plan Activities

[0000106040-25-000038:notes:259]
Stock Options

[0000106040-25-000038:notes:260]
No options were granted or exercised in 2025, 2024 or 2023. As of June 27, 2025, there were no remaining outstanding options.

[0000106040-25-000038:notes:261]
RSUs and PSUs

[0000106040-25-000038:notes:262]
The following table summarizes RSU and PSU activity under the Company’s incentive plans:

[0000106040-25-000038:notes:263]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  | (in millions) |
| RSUs and PSUs outstanding at July 1, 2022 | 15.4 |  |  | $ | 52.89 |  |  |  |
| Granted | 6.6 |  |  | 41.27 |  |  |  |
| Vested | (6.6) |  |  | 54.05 |  |  | $ | 274 |  |
| Forfeited | (1.6) |  |  | 54.56 |  |  |  |
| RSUs and PSUs outstanding at June 30, 2023 | 13.8 |  |  | 46.56 |  |  |  |
| Granted | 6.6 |  |  | 42.29 |  |  |  |
| Vested | (5.8) |  |  | 48.26 |  |  | $ | 297 |  |
| Forfeited | (1.6) |  |  | 45.62 |  |  |  |
| RSUs and PSUs outstanding at June 28, 2024 | 13.0 |  |  | 44.42 |  |  |  |
| Granted | 5.5 |  |  | 40.99 |  |  |  |
| Vested | (6.5) |  |  | 41.08 |  |  | $ | 379 |  |
| Forfeited | (1.4) |  |  | 50.91 |  |  |  |
| Share conversion due to Separation | 2.6 |  |  | 52.15 |  |  |  |
| Awards cancelled due to Separation | (3.5) |  |  | 52.32 |  |  |  |
| RSUs and PSUs outstanding at June 27, 2025 | 9.7 |  |  | $ | 33.56 |  |  |  |

[0000106040-25-000038:notes:264]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock at the time of vesting of the units.

[0000106040-25-000038:notes:265]
Fair Value Valuation Assumptions

[0000106040-25-000038:notes:266]
RSU and PSU Grants

[0000106040-25-000038:notes:267]
The fair value of the Company’s RSU and PSU awards is determined based upon the closing price of the Company’s stock price on the date of grant. The fair value of PSU awards with a market condition is estimated using a Monte Carlo simulation model on the date of grant.

[0000106040-25-000038:notes:268]
ESPP – Black-Scholes-Merton Model

[0000106040-25-000038:notes:269]
The fair value of ESPP purchase rights issued is estimated at the date of grant of the purchase rights using the Black-Scholes-Merton option pricing model. The Black-Scholes-Merton option pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0000106040-25-000038:notes:270]
The fair values of ESPP purchase rights have been estimated at the date of grant using a Black-Scholes-Merton option pricing model with the following weighted average assumptions:

[0000106040-25-000038:notes:271]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
| Weighted-average expected term (in years) |  |  |  |  | 1.16 |  | 1.25 |  | 1.25 |
| Risk-free interest rate |  |  |  |  | 4.19% |  | 4.93% |  | 4.52% |
| Stock price volatility |  |  |  |  | 0.39 |  | 0.39 |  | 0.46 |
| Dividend yield |  |  |  |  | 0.01% |  | —% |  | —% |
| Fair value |  |  |  |  | $13.32 |  | $15.08 |  | $9.70 |

[0000106040-25-000038:notes:272]
Convertible Preferred Stock

[0000106040-25-000038:notes:273]
On January 31, 2023, the Board of Directors of the Company authorized the designation of 900,000 shares of Series A Convertible Perpetual Preferred Stock, par value $0.01 per share (the “Preferred Shares”) from the Company’s existing five million authorized but unissued shares of preferred stock and issued the Preferred Shares through a private placement for an aggregate purchase price of $900 million, less issuance costs of $24 million. During the year ended June 28, 2024, 665,000 of the Preferred Shares were converted into approximately 15 million shares of common stock in accordance with the original terms of the Preferred Shares. As of both June 27, 2025 and June 28, 2024, 235,000 Preferred Shares were outstanding.

[0000106040-25-000038:notes:274]
Preferred dividend provisions

[0000106040-25-000038:notes:275]
The Preferred Shares have an initial stated value of $1,000 per share and accrue a cumulative preferred dividend at an annual rate of 6.25% per annum (increasing to 7.25% per annum on January 31, 2030 and to 8.25% per annum on January 31, 2033) compounded on a quarterly basis. Such dividends are payable on a quarterly basis in cash or in-kind through an increase to the stated value. Dividends in-kind were declared from the date of issuance of the Preferred Shares through December 31, 2024. Preferred dividends in cash of $8 million were declared and paid in 2025. The Preferred Shares also participate in any dividends declared for common shareholders on an as-converted equivalent basis. As of June 27, 2025 and June 28, 2024, accumulated dividends in-kind were $30 million and $22 million, respectively.

[0000106040-25-000038:notes:276]
Conversion rights

[0000106040-25-000038:notes:277]
The Preferred Shares are convertible into shares of the Company’s common stock at a conversion rate of approximately $35.51 per share (the “Conversion Price”). The conversion rate was adjusted from the initial conversion rate of $47.75 per share as a result of the Separation, in accordance with the Certificate of Designations for the Preferred Shares, using a ratio of the closing price of the Company’s and Sandisk’s common stock over the first 10 trading days after the Separation. This rate is subject to future anti-dilution adjustments and certain other one-time adjustments in the event of various specified spin-off-related transactions. This Conversion Price applies to the total of the stated value of the Preferred Shares plus any cumulative accrued but unpaid dividends (the “Accumulated Stated Value”). In the case of future standalone spin-off transactions, the holders of the Preferred Shares may convert one-third of their Preferred Shares into a similar class of preferred shares of the spin-off entity. The Company may opt to convert the Preferred Shares after January 31, 2026, if the closing price per share of the Company’s common stock exceeds 150% of the Conversion Price for at least 20 out of 30 consecutive trading days immediately before the Company’s conversion notice.

[0000106040-25-000038:notes:278]
As of June 27, 2025 and June 28, 2024, the Preferred Shares outstanding would have been convertible, if otherwise permitted, into 7 million and 5 million shares of common stock, respectively, based on the conversion rate in effect at each such date.

[0000106040-25-000038:notes:279]
Redemption

[0000106040-25-000038:notes:280]
After January 31, 2030, the Company will have the right, but not the obligation, to redeem the Preferred Shares for an amount in cash equal to 110% of the Accumulated Stated Value. Redemption is contingently mandatory in the event of a fundamental change in the business as defined in the designation of the Preferred Shares.

[0000106040-25-000038:notes:281]
The Preferred Shares have been classified as mezzanine equity in the Company’s Consolidated Balance Sheets because, in the event of certain fundamental changes in the business that are not solely within the control of the Company, the Preferred Shares would become redeemable at the option of the holders. The Company did not adjust the carrying values of the Preferred Shares to the current redemption value of such shares since a liquidation event was not probable at any of the balance sheet dates. Subsequent adjustments to increase or decrease the carrying values to the ultimate redemption value will be made only if and when it becomes probable that such a fundamental change in the business will occur.

[0000106040-25-000038:notes:282]
Voting right

[0000106040-25-000038:notes:283]
The Preferred Shares will vote, to the extent permitted under the Nasdaq listing rules, on an as-converted equivalent basis along with holders of the Company’s common stock.

[0000106040-25-000038:notes:284]
Liquidation preference

[0000106040-25-000038:notes:285]
In the event of any voluntary or involuntary liquidation, holders of the Preferred Shares will be senior to the holders of the Company’s common stock and the liquidation preference is the greater of (i) the sum of an amount in cash equal to 110% of the Accumulated Stated Value plus accrued and unpaid dividends and (ii) the payment that the holders of the Preferred Shares would have received had all the Preferred Shares been converted into common stock immediately prior to such liquidation, before any distributions are made to common shareholders and all other classes of junior capital stock of the Company. As of June 27, 2025 and June 28, 2024, the total aggregate liquidation preference was $265 million and $257 million, respectively.

[0000106040-25-000038:notes:286]
Share Repurchase Program

[0000106040-25-000038:notes:287]
On May 9, 2025, the Company’s Board of Directors authorized a share repurchase program for the repurchase of up to $2.0 billion of the Company’s common stock. There is no expiration date for the share repurchase program. For the year ended June 27, 2025, the Company repurchased 2.8 million shares for a total cost of $149 million. The remaining amount available to be repurchased under the Company’s share repurchase program as of June 27, 2025 was $1.85 billion. Repurchases under the share repurchase program may be made in the open market or in privately negotiated transactions and may be made under a Rule 10b5-1 plan. The Company expects share repurchases to be funded principally by operating cash flows. The amount and timing of share repurchases will depend on market conditions and other corporate considerations. The company may suspend or discontinue the share repurchase program at any time.

[0000106040-25-000038:notes:288]
Stock Reserved for Issuance

[0000106040-25-000038:notes:289]
The following table summarizes all common stock reserved for issuance at June 27, 2025:

[0000106040-25-000038:notes:290]
|  | Number of Shares |
|  | (in millions) |
| Convertible notes | 55 |  |
| Outstanding awards and shares available for award grants | 30 |  |
| Convertible preferred stock | 10 |  |
| ESPP | 4 |  |
| Total | 99 |  |

[0000106040-25-000038:notes:291]
Dividends to Common Shareholders

[0000106040-25-000038:notes:292]
On April 29, 2025, the Company’s Board of Directors authorized the adoption of a quarterly cash dividend program. Under the cash dividend program, holders of the Company’s common stock will receive dividends when and as declared by the Board of Directors. During the year ended June 27, 2025, the Company paid cash dividends of $0.10 per share of its outstanding common stock, totaling $36 million, including payment to holders of the Company’s Series A Preferred Stock in accordance with their participation rights.

[0000106040-25-000038:notes:293]
Subsequent to year-end, on July 29, 2025, the Board of Directors declared a cash dividend of $0.10 per share of the Company’s common stock, which will be paid on September 18, 2025 to shareholders of record as of the close of business on September 4, 2025.

[0000106040-25-000038:notes:294]
The Company may modify, suspend, or cancel its cash dividend program in any matter and at any time. The amount of future dividends under the Company’s cash dividend program, and the declaration and payment thereof, will be based upon all relevant factors, including the Company’s financial position, results of operations, cash flows, capital requirements and restrictions under the Company’s Loan Agreement and other financing agreements, and shall be in compliance with applicable law.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000106040-25-000038:notes:295]
Income Taxes
Income (Loss) Before Taxes

[0000106040-25-000038:notes:296]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0000106040-25-000038:notes:297]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Foreign | $ | 2,602 |  |  | $ | (492) |  |  | $ | (696) |  |
| Domestic | (1,472) |  |  | (247) |  |  | (153) |  |
| Income (loss) before taxes | $ | 1,130 |  |  | $ | (739) |  |  | $ | (849) |  |

[0000106040-25-000038:notes:298]
Income Tax Expense (Benefit)

[0000106040-25-000038:notes:299]
The components of Income tax expense (benefit) were as follows:

[0000106040-25-000038:notes:300]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 213 |  |  | $ | 77 |  |  | $ | 27 |  |
| Domestic - Federal | 90 |  |  | 34 |  |  | 28 |  |
| Domestic - State | (1) |  |  | 6 |  |  | (8) |  |
|  | 302 |  |  | 117 |  |  | 47 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (1) |  |  | (8) |  |  | 10 |  |
| Domestic - Federal | (773) |  |  | (68) |  |  | 1 |  |
| Domestic - State | (41) |  |  | (15) |  |  | (5) |  |
|  | (815) |  |  | (91) |  |  | 6 |  |
| Income tax expense (benefit) | $ | (513) |  |  | $ | 26 |  |  | $ | 53 |  |

[0000106040-25-000038:notes:301]
Previously, the Tax Cuts and Jobs Act of 2017 (“TCJA”) eliminated the ability to deduct research and development (“R&D”) expenditures in the year incurred, requiring capitalization and amortization under Internal Revenue Code Section 174. On July 4, 2025, the One Big Beautiful Bill Act of 2025 (“OBBBA”) was signed into law, which includes broad tax reform provisions that extend and modify key elements of the TCJA. Notably, the new legislation now allows an option for the immediate expensing of domestic R&D expenditures, beginning with fiscal year 2026. The legislation also includes favorable modifications to international tax provisions, including changes to the Global Intangible Low-Taxed Income regime and enhancements to the Foreign-Derived Intangible Income deduction. Because the OBBBA provisions are not effective for the Company until fiscal year 2026 and the enactment date occurred after the balance sheet date, the tax effects of the OBBBA are not included in the operating results for the fiscal year ended June 27, 2025.

[0000106040-25-000038:notes:302]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.00 billion. The CAMT became effective for the Company beginning with fiscal year 2024. The Company was not subject to CAMT in fiscal year 2024 and does not expect to be subject to CAMT for fiscal year 2025 as its average annual AFSI did not exceed $1.00 billion for the preceding three-year period.

[0000106040-25-000038:notes:303]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two. Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, also known as Global Minimum Tax (“GMT”), some of which are effective for the Company in fiscal year 2025. For fiscal year 2025, the Company currently expects to be able to meet certain transitional safe harbors and does not expect any material GMT taxes. As most of the jurisdictions in which the Company operates have adopted this legislation for fiscal year 2026, the Company expects there will be increases in the Company’s future tax obligations in these jurisdictions.

[0000106040-25-000038:notes:304]
Deferred Taxes

[0000106040-25-000038:notes:305]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0000106040-25-000038:notes:306]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 38 |  |  | $ | 34 |  |
| Accrued compensation and benefits not currently deductible | 75 |  |  | 75 |  |
| Net operating loss carryforward | 133 |  |  | 134 |  |
| Business credit carryforward | 562 |  |  | 520 |  |
| Long-lived assets | 796 |  |  | 42 |  |
| Interest and hedging costs not currently deductible | 166 |  |  | 187 |  |
| Other | 29 |  |  | 11 |  |
| Total deferred tax assets | 1,799 |  |  | 1,003 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (40) |  |  | (33) |  |
| Unremitted earnings of certain non-U.S. entities | (149) |  |  | (218) |  |
| Other | (12) |  |  | — |  |
| Total deferred tax liabilities | (201) |  |  | (251) |  |
| Valuation allowances | (598) |  |  | (527) |  |
| Deferred tax assets, net | $ | 1,000 |  |  | $ | 225 |  |

[0000106040-25-000038:notes:307]
The increase in the deferred tax assets is attributable primarily to one-time deferred tax benefits related to the inter-entity asset transfer in conjunction with the Separation and the mandatory capitalization of R&D expenditures. While the OBBBA allows for the immediate expensing of domestic R&D expenditures, these provisions are not effective for Company until fiscal year 2026. As such, the Company is required to capitalize a portion of its R&D expenditures in fiscal year 2025 under the prior law. The change in the deferred tax liabilities is attributable primarily to a remeasurement of the Company’s California taxes associated with its un-remitted earnings of its non-U.S. entities. This change is offset entirely by an equal and offsetting change in the valuation allowance. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize its deferred tax assets except for certain loss and credit carryforwards.

[0000106040-25-000038:notes:308]
The Company is permanently reinvested with respect to certain foreign earnings. There is no unrecognized deferred tax liability associated with the repatriation of these foreign undistributed earnings as it can be achieved without additional federal tax consequences.

[0000106040-25-000038:notes:309]
Effective Tax Rate

[0000106040-25-000038:notes:310]
Reconciliation of the U.S. Federal statutory rate to the Company’s effective tax rate is as follows:

[0000106040-25-000038:notes:311]
|  | 2025 |  | 2024 |  | 2023 |
| U.S. Federal statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| Tax rate differential on international income | (36) |  |  | (22) |  |  | (22) |  |
| Tax effect of U.S. foreign income inclusion | 1 |  |  | (1) |  |  | (1) |  |
| Tax effect of U.S. foreign minimum tax | 25 |  |  | (6) |  |  | — |  |
| Tax effect of U.S. stock-based compensation | (2) |  |  | (1) |  |  | (1) |  |
| Tax effect of non-deductible loss on retained interest in Sandisk | 16 |  |  | — |  |  | — |  |
| Tax effect of U.S. permanent differences | — |  |  | 5 |  |  | (1) |  |
| State income tax, net of federal tax | — |  |  | 2 |  |  | (1) |  |
| Change in valuation allowance | 6 |  |  | (3) |  |  | 1 |  |
| Unremitted earnings of certain non-U.S. entities | (2) |  |  | (2) |  |  | (1) |  |
| Foreign income tax credits | (8) |  |  | 1 |  |  | — |  |
| R&D tax credits | (6) |  |  | 5 |  |  | 4 |  |
| U.S. return to provision | 1 |  |  | — |  |  | (1) |  |
| Tax reserves | 1 |  |  | (3) |  |  | (3) |  |
| Inter-entity asset transfer | (61) |  |  | — |  |  | — |  |
| Other | (1) |  |  | — |  |  | (1) |  |
| Effective tax rate | (45) | % |  | (4) | % |  | (6) | % |

[0000106040-25-000038:notes:312]
The tax rate differentials on international income are comprised primarily of reduced tax rates from the Company tax holidays and tax incentive programs in the Philippines and Thailand in fiscal years 2025 and 2024, and in Malaysia, the Philippines, and Thailand in fiscal 2023.

[0000106040-25-000038:notes:313]
Tax Holidays and Carryforwards

[0000106040-25-000038:notes:314]
A substantial portion of the Company’s manufacturing operations in the Philippines and Thailand operate under various tax holidays and tax incentive programs, which will expire in whole or in part at various dates during 2026 through 2033. Certain tax holidays and tax incentive programs may be extended if specific conditions are met. On November 1, 2023, the Company’s tax holiday in Malaysia expired. The Company has applied for an extension and continues to be engaged in active discussions with the Malaysian Investment Development Authority. Because the exact terms of an extension are not currently known, the Company is applying the Malaysia corporate statutory tax rate on its Malaysian income for the full fiscal year. If an extension is granted, the Company will make an adjustment to its effective tax rate in that period.

[0000106040-25-000038:notes:315]
The direct tax impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $551 million, or $1.54 per diluted share, $209 million, or $0.64 per diluted share, and $140 million, or $0.44 per diluted share, in 2025, 2024 and 2023, respectively.

[0000106040-25-000038:notes:316]
As of June 27, 2025, the Company had varying amounts of federal and state NOL/tax credit carryforwards that do not expire or, if not used, expire in various years. Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-25-000038:notes:317]
| Jurisdiction | NOL/Tax Credit Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Federal NOL (Pre 2017 Act Generation) | $ | 563 |  |  | 2026 to 2038 |
| California NOL | 348 |  |  | 2040 to 2047 |
| Other State NOL | 292 |  |  | Various |
| Federal tax credits | 89 |  |  | 2027 to 2036 |
| State tax credits | 750 |  |  | No expiration |

[0000106040-25-000038:notes:318]
The federal and state NOLs and credits relating to various acquisitions are subject to limitations under Sections 382 and 383 of the U.S. Internal Revenue Code. The Company expects the total amount of federal and state NOLs ultimately realized will be reduced as a result of these provisions by $116 million and $240 million, respectively. The Company expects the total amount of federal and state credits ultimately realized will be reduced as a result of these provisions by $27 million and $2 million, respectively.

[0000106040-25-000038:notes:319]
As of June 27, 2025, the Company had varying amounts of foreign NOL carryforwards that do not expire or, if not used, expire in various years, depending on the country. The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:

[0000106040-25-000038:notes:320]
| Jurisdiction | NOL Carryforward Amount |  | Expiration |
|  | (in millions) |  |  |
| Malaysia | $ | 69 |  |  | 2029 |
| Japan | 42 |  |  | 2026 |

[0000106040-25-000038:notes:321]
Uncertain Tax Positions

[0000106040-25-000038:notes:322]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets.

[0000106040-25-000038:notes:323]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits excluding accrued interest and penalties:

[0000106040-25-000038:notes:324]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 721 |  |  | $ | 1,021 |  |  | $ | 1,047 |  |
| Gross increases related to current year tax positions | 11 |  |  | 25 |  |  | 7 |  |
| Gross increases related to prior year tax positions | 26 |  |  | 73 |  |  | 22 |  |
| Gross decreases related to prior year tax positions | (13) |  |  | (32) |  |  | (47) |  |
| Settlements | (40) |  |  | (363) |  |  | (5) |  |
| Lapse of statute of limitations | (10) |  |  | (3) |  |  | (3) |  |
| Distribution in connection with the Separation | (126) |  |  | — |  |  | — |  |
| Unrecognized tax benefit, ending balance | $ | 569 |  |  | $ | 721 |  |  | $ | 1,021 |  |

[0000106040-25-000038:notes:325]
As of June 27, 2025, June 28, 2024 and June 30, 2023, the portion of the gross unrecognized tax benefits, if recognized, that would affect the effective tax rate is $416 million, $555 million and $855 million, respectively. It is the Company’s policy to include interest and penalties related to its gross unrecognized tax benefits as a component of the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 27, 2025, June 28, 2024 and June 30, 2023 was $82 million, $181 million and $289 million, respectively. As of June 27, 2025, June 28, 2024 and June 30, 2023, the Company’s payables related to unrecognized tax benefits, including accrued interest and penalties, were $498 million, $736 million and $1.14 billion, respectively. Of these amounts, approximately $332 million, including interest and penalties, could result in potential cash payments to be made within the next twelve months and have been included in Income taxes payable on the Consolidated Balance Sheets as of June 27, 2025. The remaining payables related to unrecognized tax benefits, including accrued interest and penalties, are included in Other liabilities on the Consolidated Balance Sheets as of June 27, 2025 and June 28, 2024.

[0000106040-25-000038:notes:326]
This potential cash payment is expected to be netted with offsetting favorable tax receivables totaling $148 million, including among other things, a reduction to our mandatory deemed repatriation tax obligations related to the settlement for the years 2008 through 2015, for a potential net cash payment of $184 million. These tax receivables are classified in Other current assets on the Consolidated Balance Sheets as of June 27, 2025.

[0000106040-25-000038:notes:327]
The Company files U.S. Federal, U.S. state and foreign tax returns. For both federal and state tax returns, with few exceptions, the Company is subject to examination for 2016 through 2024. The Company is no longer subject to examination by the IRS for periods prior to 2016, although carry forwards generated prior to those periods may still be adjusted upon examination by the IRS or state taxing authority if they either have been or will be used in a subsequent period. In the following major foreign jurisdictions where there is no tax holiday, the Company could be subject to examination as noted below:

[0000106040-25-000038:notes:328]
| Jurisdiction |  | Period Subject to Examination |
| China (calendar) |  | 2014-2024 |
| India (fiscal) |  | 2017-2024 |
| Japan (fiscal) |  | 2016-2024 |
| Malaysia (fiscal) |  | 2018-2024 |
| Thailand (fiscal) |  | 2014-2024 |
| Singapore (fiscal) |  | 2021-2024 |
| United Kingdom (fiscal) |  | 2023-2024 |

[0000106040-25-000038:notes:329]
The Company had previously reached a final agreement with the IRS regarding notices of deficiency with respect to years 2008 through 2012 and in February 2024, the Company also reached a final agreement for resolving the notices of proposed adjustments with respect to years 2013 through 2015. During the year ended June 27, 2025, the Company made payments of $130 million for interest with respect to years 2008 through 2012 and $32 million for tax and interest with respect to years 2013 through 2015, resulting in no remaining liability as of June 27, 2025 related to all years from 2008 through 2015.

[0000106040-25-000038:notes:330]
In connection with settlements for the years 2008 through 2015, the Company expects to realize reductions to its mandatory deemed repatriation tax obligations and tax savings from interest deductions in future years aggregating to approximately $166 million. Of this amount, $65 million of interest savings from the interest paid with respect to years 2008 through 2015 is classified as a deferred tax asset due to interest expense limitation rules.

[0000106040-25-000038:notes:331]
The Company believes that adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner not consistent with management’s expectations, the Company could be required to adjust its provision for income taxes in the period such resolution occurs. As of June 27, 2025, with the exception of the net potential payment of $183 million, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information relating to the examination of the Company’s tax returns.


## us-gaap:SummaryOfOperatingLossCarryforwardsTextBlock

[0000106040-25-000038:notes:332]
Following is a summary of the Company’s federal and state NOL/tax credit carryforwards and the related expiration dates of these NOL/tax credit carryforwards:

[0000106040-25-000038:notes:333]
The major jurisdictions that the Company receives foreign NOL carryforwards and the related amounts and expiration dates of these NOL carryforwards are as follows:


## us-gaap:EarningsPerShareTextBlock

[0000106040-25-000038:notes:334]
Net Income (Loss) Per Common Share 
The following table presents the computation of basic and diluted income (loss) per common share:

[0000106040-25-000038:notes:335]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions, except per share data) |
| Net income (loss) from continuing operations |  |  |  |  | $ | 1,643 |  |  | $ | (765) |  |  | $ | (902) |  |
| Less: dividends allocated to preferred shareholders |  |  |  |  | 17 |  |  | 54 |  |  | 24 |  |
| Less: income attributable to participating securities |  |  |  |  | 28 |  |  | — |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic |  |  |  |  | 1,598 |  |  | (819) |  |  | (926) |  |
| Net income (loss) from discontinued operations, net of taxes, attributable to common shareholders |  |  |  |  | 242 |  |  | (33) |  |  | (782) |  |
| Net income (loss) attributable to common shareholders - basic |  |  |  |  | $ | 1,840 |  |  | $ | (852) |  |  | $ | (1,708) |  |
| Net income (loss) from continuing operations attributable to common shareholders - basic |  |  |  |  | $ | 1,598 |  |  | $ | (819) |  |  | $ | (926) |  |
| Re-allocation of participating securities considered potentially dilutive securities |  |  |  |  | 1 |  |  | — |  |  | — |  |
| Net income (loss) from continuing operations attributable to common shareholders - diluted |  |  |  |  | 1,599 |  |  | (819) |  |  | (926) |  |
| Net income (loss) from discontinued operations, net of taxes, attributable to common shareholders |  |  |  |  | 242 |  |  | (33) |  |  | (782) |  |
| Net income (loss) attributable to common shareholders - diluted |  |  |  |  | $ | 1,841 |  |  | $ | (852) |  |  | $ | (1,708) |  |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 347 |  |  | 326 |  |  | 318 |  |
| RSUs, PSUs, ESPP, and the convertible notes |  |  |  |  | 12 |  |  | — |  |  | — |  |
| Diluted |  |  |  |  | 359 |  |  | 326 |  |  | 318 |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |
| Continuing operations - basic |  |  |  |  | $ | 4.61 |  |  | $ | (2.51) |  |  | $ | (2.91) |  |
| Discontinued operations - basic |  |  |  |  | 0.70 |  |  | (0.10) |  |  | (2.46) |  |
| Net income (loss) per common share - basic |  |  |  |  | 5.31 |  |  | (2.61) |  |  | (5.37) |  |
| Continuing operations - diluted |  |  |  |  | 4.45 |  |  | (2.51) |  |  | (2.91) |  |
| Discontinued operations - diluted |  |  |  |  | 0.67 |  |  | (0.10) |  |  | (2.46) |  |
| Net income (loss) per common share - diluted |  |  |  |  | 5.12 |  |  | (2.61) |  |  | (5.37) |  |
| Anti-dilutive potential common shares excluded |  |  |  |  | — |  |  | 22 |  |  | 14 |  |

[0000106040-25-000038:notes:336]
Basic income (loss) per share attributable to common shareholders is computed using (i) net income (loss) less (ii) dividends paid to holders of Preferred Shares less (iii) net income (loss) attributable to participating securities divided by (iv) weighted average basic shares outstanding. Diluted net income (loss) per share attributable to common shareholders is computed as (i) basic net income (loss) attributable to common shareholders plus (ii) diluted adjustments to income allocable to participating securities divided by (iii) weighted average diluted shares outstanding. The “if-converted” method is used to determine the dilutive impact for the convertible notes and the Preferred Shares. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0000106040-25-000038:notes:337]
For 2025, based on the Company’s average stock price during the period, an insignificant number of common shares subject to outstanding equity awards were anti-dilutive. For 2024 and 2023, the Company recorded a net loss and all shares subject to outstanding equity awards were excluded from the calculation of diluted shares for the period because their impact would have been anti-dilutive.


## wdc:EmployeeTerminationBenefitsAndOtherChargesDisclosureTextBlock

[0000106040-25-000038:notes:338]
Business Realignment Charges
The Company periodically incurs charges to realign its business operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. These actions may result in charges for employee termination benefits or charges from the impairment of intangible assets and other long-lived assets. In this regard, in 2024, the Company reassessed existing capacity development plans and made a decision to cancel certain projects, including projects to expand capacity in its Penang, Malaysia facility, resulting in the impairment of existing construction in progress, other assets and the recognition of a liability for certain contract termination costs. The Company may also periodically record credits related to gains upon ultimate sale of property in connection with these activities.

[0000106040-25-000038:notes:339]
The Company recorded the following charges related to these actions:

[0000106040-25-000038:notes:340]
|  |  |  |  |  | 2025 |  | 2024 |  | 2023 |
|  |  |  |  |  | (in millions) |
| Employee termination benefits |  |  |  |  | $ | 2 |  |  | $ | 34 |  |  | $ | 130 |  |
| Asset impairments |  |  |  |  | — |  |  | 146 |  |  | 19 |  |
| Other charges (gains): |  |  |  |  |  |  |  |  |  |
| Gain on disposition of assets and other charges |  |  |  |  | — |  |  | — |  |  | (8) |  |
| Contract termination and other |  |  |  |  | 2 |  |  | 29 |  |  | 5 |  |
| Recovery of non-cancellable purchase orders |  |  |  |  | (10) |  |  | — |  |  | — |  |
| Total business realignment charges |  |  |  |  | $ | (6) |  |  | $ | 209 |  |  | $ | 146 |  |

[0000106040-25-000038:notes:341]
The following table presents an analysis of the components of these activities against the reserve (included in Accrued expenses) during the year ended June 27, 2025:

[0000106040-25-000038:notes:342]
|  | Employee Termination Benefits |  | Contract Termination and Other |  | Total |
|  | (in millions) |
| Accrual balance at June 28, 2024 | $ | — |  |  | $ | 28 |  |  | $ | 28 |  |
| Charges | 2 |  |  | 2 |  |  | 4 |  |
| Cash payments | (1) |  |  | (11) |  |  | (12) |  |
| Recovery of non-cancellable purchase orders | — |  |  | (10) |  |  | (10) |  |
| Accrual balance at June 27, 2025 | $ | 1 |  |  | $ | 9 |  |  | $ | 10 |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000106040-25-000038:notes:343]
Supplier Finance Program
The Company maintains a voluntary supplier finance program that provides participating suppliers with enhanced receivable options. The program allows participating suppliers of the Company, at their sole discretion and cost, to sell their receivables due from the Company to a third-party financial institution and receive early payment at terms negotiated between the supplier and the third-party financial institution. The Company’s vendor payment terms and amounts are not impacted by a supplier’s decision to participate in this program.

[0000106040-25-000038:notes:344]
The Company’s current payment terms with its suppliers under these programs generally range from 60 to 90 days and payment terms that the Company negotiates with its suppliers are not impacted by whether a supplier participates in the program. The Company does not provide any guarantees to any third parties, and no assets are pledged in connection with the arrangements.

[0000106040-25-000038:notes:345]
The Company’s outstanding payment obligations to vendors eligible to participate under its supplier finance program were $39 million and $37 million as of June 27, 2025 and June 28, 2024, respectively, and are included within Accounts payable on the Company’s Consolidated Balance Sheets with the associated payments reflected in the operating activities section of the Consolidated Statements of Cash Flows. The roll-forward of the Company’s outstanding obligations confirmed as valid under its supplier finance program for the year ended June 27, 2025 is as follows (in millions):

[0000106040-25-000038:notes:346]
| Confirmed obligation outstanding at the beginning of the year | $ | 37 |  |
| Invoices confirmed during the year | 244 |  |
| Confirmed invoices paid during the year | (242) |  |
| Confirmed obligations outstanding at the end of the year | $ | 39 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000106040-25-000038:notes:347]
Legal Proceedings
Intellectual Property Litigation

[0000106040-25-000038:notes:348]
On August 26, 2022, MR Technologies, GmbH (“MRT”) filed an action in the United States District Court for the Central District of California (the “Central District Court”) against the Company’s wholly-owned subsidiary, Western Digital Technologies, Inc., alleging infringement of U.S. Patent Nos. 9,978,413, 9,928,864, 11,133,031 and 11,138,997, each of which relate to HDD media. As the case progressed, MRT dropped its claims with respect to U.S. Patent Nos. 9,978,413 and 11,133,031, and the case proceeded to trial in July 2024 on the remaining two patents (together, the “MRT Patents”). The trial concluded on July 26, 2024, and the jury awarded MRT a lump sum of $262 million for use of the MRT Patents in the past and through their remaining lives. MRT also requested and was awarded prejudgment interest totaling $117 million in a judgment entered on August 15, 2024. In addition, MRT requested attorney’s fees and post-judgment interest.

[0000106040-25-000038:notes:349]
In the fourth quarter of fiscal year 2024, the Company recognized an aggregate liability for this matter of $384 million with $291 million recognized as an Operating expense under Litigation matter for the year ended June 28, 2024 and $93 million recognized as Other non-current assets for the patent licenses, to be amortized over their remaining lives.

[0000106040-25-000038:notes:350]
Subsequently, in April 2025, pursuant to a confidential agreement, MRT and the Company reached a global settlement of $130 million for all pending legal disputes. The settlement resulted in the dismissal of the MRT matter, as well as a second patent litigation matter MRT filed on August 22, 2024 against the Company. As a result of the settlement, the Company reversed $201 million of previously recorded charges in Operating expense under Litigation matter and $6 million of post-judgment interest previously recorded in Other income (expense), net.

[0000106040-25-000038:notes:351]
On September 28, 2016, SPEX Technologies, Inc. (“SPEX”) filed a lawsuit in the Central District Court against the Company and two of the Company’s current or former wholly-owned subsidiaries, Western Digital Technologies, Inc. and HGST Inc., alleging infringement of U.S. Patent Nos. 6,088,802 and 6,003,135, both of which allegedly relate to moving a security mechanism (e.g., the encrypting/decrypting mechanism) from a host computer or a separate device to a peripheral device that provides data storage. As the case progressed, SPEX dismissed its allegations relating to U.S. Patent No. 6,003,135 and narrowed its case to one claim related to U.S. Patent No. 6,088,802 and asserted this against certain HDD products that may include certain encryption capabilities. The trial commenced on October 8, 2024, and concluded on October 18, 2024, and the jury awarded SPEX damages of $316 million for the use of one claim related to U.S. Patent No. 6,088,802 in the past, prior to its expiration in 2017. On January 8, 2025, the Court entered judgment for SPEX in accordance with the verdict and also awarded SPEX prejudgment interest of $237 million and legal costs. On June 16, 2025, the Court ruled on the Company’s post-trial motions, finding that SPEX did not present sufficient evidence on which a damages award could be determined and therefore awarded nominal damages of $1. On June 27, 2025, the Court entered an amended judgment awarding SPEX nominal damages of $1 with no prejudgment interest and no legal costs. The Company has appealed the infringement finding, and SPEX has appealed damages-related issues. Based on available appellate arguments, the Company believes a loss is not probable and has not accrued a liability as a result of the jury verdict or the entry of amended judgment in its financial statements as of June 27, 2025.

[0000106040-25-000038:notes:352]
Other Matters

[0000106040-25-000038:notes:353]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from management’s expectations.

[0000106040-25-000038:notes:354]
The ability to predict the ultimate outcome of any legal proceeding involves judgments, estimates and inherent uncertainties. The actual outcome of these matters could differ materially from management’s estimates.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000106040-25-000038:notes:355]
Quarterly Results of Operations (unaudited)
As discussed in Note 1, as a result of the Separation, the historical net income (loss) of Sandisk is reported in the Company’s consolidated financial statements as discontinued operations. The below provides unaudited summarized quarterly financial information on this basis to allow for a meaningful comparison of continuing operations:

[0000106040-25-000038:notes:356]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2025 |  |  |  |  |  |  |  |
| Revenue, net | $ | 2,212 |  |  | $ | 2,409 |  |  | $ | 2,294 |  |  | $ | 2,605 |  |
| Gross profit | 806 |  |  | 907 |  |  | 912 |  |  | 1,067 |  |
| Net income from continuing operations | 153 |  |  | 466 |  |  | 772 |  |  | 252 |  |
| Net income | 493 |  |  | 594 |  |  | 520 |  |  | 282 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Continuing operations - basic | $ | 0.43 |  |  | $ | 1.32 |  |  | $ | 2.17 |  |  | $ | 0.70 |  |
| Earnings per common share - basic | 1.40 |  |  | 1.68 |  |  | 1.46 |  |  | 0.78 |  |
| Continuing operations - diluted | 0.42 |  |  | 1.28 |  |  | 2.11 |  |  | 0.67 |  |
| Earnings per common share - diluted | 1.35 |  |  | 1.63 |  |  | 1.42 |  |  | 0.75 |  |

[0000106040-25-000038:notes:357]
|  | First |  | Second |  | Third |  | Fourth |
|  | (in millions, except per share amounts) |
| 2024 |  |  |  |  |  |  |  |
| Revenue, net | $ | 1,194 |  |  | $ | 1,367 |  |  | $ | 1,752 |  |  | $ | 2,004 |  |
| Gross profit | 244 |  |  | 313 |  |  | 519 |  |  | 697 |  |
| Net income (loss) from continuing operations | (365) |  |  | (146) |  |  | (8) |  |  | (246) |  |
| Net income (loss) | (685) |  |  | (287) |  |  | 135 |  |  | 39 |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |
| Continuing operations - basic | $ | (1.18) |  |  | $ | (0.49) |  |  | $ | (0.07) |  |  | $ | (0.77) |  |
| Earnings (loss) per common share - basic | (2.17) |  |  | (0.92) |  |  | 0.35 |  |  | 0.08 |  |
| Continuing operations - diluted | (1.18) |  |  | (0.49) |  |  | (0.07) |  |  | (0.77) |  |
| Earnings (loss) per common share - diluted | (2.17) |  |  | (0.92) |  |  | 0.35 |  |  | 0.08 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000106040-25-000038:notes:358]
Irving Tan, Chief Executive Officer of the Company adopted a Rule 10b5-1 Plan on May 12, 2025. Under this plan, up to an aggregate of 80,000 shares of the Company’s common stock may be sold before the plan expires on May 26, 2026.

[0000106040-25-000038:notes:359]
Cynthia Tregillis, Executive Vice President, Chief Legal Officer and Secretary of the Company, adopted a Rule 10b5-1 Plan on May 23, 2025. Under this plan, up to an aggregate of 17,502 shares of the Company’s common stock may be sold before the plan expires on May 26, 2026.
