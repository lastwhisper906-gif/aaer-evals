# CSCO 8-K — 0001193125-21-034339 filed 2021-02-09

## item codes, every 8-K on or before 2021-02-16

- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2021-02-16

- none on or before 2021-02-16

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-034339:8k_2_02:1]
EX-99.1
2
d124648dex991.htm
EX-99.1

[0001193125-21-034339:8k_2_02:2]
EX-99.1

[0001193125-21-034339:8k_2_02:3]
Exhibit 99.1

[0001193125-21-034339:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-21-034339:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-21-034339:8k_2_02:6]
News Summary:

[0001193125-21-034339:8k_2_02:7]
|  | • |  | Total product order growth of 1% year over year |

[0001193125-21-034339:8k_2_02:8]
|  | • |  | Product revenue strength across Catalyst 9000, Data Center Switching, Security, Wireless and Webex portfolios |

[0001193125-21-034339:8k_2_02:9]
|  | • |  | Great progress on business transformation to more software and subscription, with 76% of software revenue sold as a subscription |

[0001193125-21-034339:8k_2_02:10]
|  | • |  | Dividend increased 3% |

[0001193125-21-034339:8k_2_02:11]
|  | • |  | Q2 Results: |

[0001193125-21-034339:8k_2_02:12]
|  | • |  | Revenue: $12.0 billion |

[0001193125-21-034339:8k_2_02:13]
|  | • |  | Flat year over year |

[0001193125-21-034339:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.60; Non-GAAP: $0.79 |

[0001193125-21-034339:8k_2_02:15]
|  | • |  | GAAP EPS decreased (12)% year over year |

[0001193125-21-034339:8k_2_02:16]
|  | • |  | Non-GAAP EPS increased 3% year over year |

[0001193125-21-034339:8k_2_02:17]
|  | • |  | Q3 Guidance: |

[0001193125-21-034339:8k_2_02:18]
|  | • |  | Revenue: 3.5% to 5.5% growth year over year |

[0001193125-21-034339:8k_2_02:19]
|  | • |  | Earnings per Share: GAAP: $0.64 to $0.69; Non-GAAP: $0.80 to $0.82 |

[0001193125-21-034339:8k_2_02:20]
SAN JOSE, Calif. — February 9, 2021 — Cisco today reported second quarter results for the period ended January 23,
2021. Cisco reported second quarter revenue of $12.0 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.5 billion or $0.60 per share, and non-GAAP net income of
$3.4 billion or $0.79 per share.

[0001193125-21-034339:8k_2_02:21]
“We are seeing encouraging signs of strength across our business showing how our technology will be a powerful
engine for recovery and growth,” said Chuck Robbins, chairman and CEO of Cisco. “Our team delivered a strong performance as we partnered with customers on accelerating their digital transformation and driving secure, remote work.”

[0001193125-21-034339:8k_2_02:22]
“Cisco executed well in Q2, delivering growth in orders, strong margins, and growth in non-GAAP EPS, while
continuing to grow deferred revenue in double-digits through the shift to more software and subscriptions,” said Scott Herren, CFO of Cisco.

[0001193125-21-034339:8k_2_02:23]
GAAP Results

[0001193125-21-034339:8k_2_02:24]
|  |  | Q2 FY 2021 |  |  | Q2 FY 2020 |  |  | Vs. Q2 FY 2020 |  |
| Revenue |  | $ | 12.0 billion |  |  | $ | 12.0 billion |  |  |  | — | % |
| Net Income |  | $ | 2.5 billion |  |  | $ | 2.9 billion |  |  |  | (12 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.60 |  |  | $ | 0.68 |  |  |  | (12 | )% |

[0001193125-21-034339:8k_2_02:25]
Non-GAAP Results

[0001193125-21-034339:8k_2_02:26]
|  |  | Q2 FY 2021 |  |  | Q2 FY 2020 |  |  | Vs. Q2 FY 2020 |  |
| Net Income |  | $ | 3.4 billion |  |  | $ | 3.3 billion |  |  |  | 2 | % |
| EPS |  | $ | 0.79 |  |  | $ | 0.77 |  |  |  | 3 | % |

[0001193125-21-034339:8k_2_02:27]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-034339:8k_2_02:28]
1

[0001193125-21-034339:8k_2_02:29]
Cisco Increases Quarterly Cash Dividend

[0001193125-21-034339:8k_2_02:30]
Cisco declared a quarterly dividend of $0.37 per common share, a $0.01 increase or up 3% over the previous quarter’s dividend, to be paid on
April 28, 2021 to all stockholders of record as of the close of business on April 6, 2021. Future dividends will be subject to Board approval.

[0001193125-21-034339:8k_2_02:31]
Financial Summary

[0001193125-21-034339:8k_2_02:32]
All comparative percentages are on
a year-over-year basis unless otherwise noted.

[0001193125-21-034339:8k_2_02:33]
Q2 FY 2021 Highlights

[0001193125-21-034339:8k_2_02:34]
Revenue — Total revenue was flat at $12.0 billion, with product revenue down 1% and service revenue up 2%. Revenue by geographic
segment was: Americas down 1%, EMEA up 2%, and APJC down 4%. Product revenue was led by growth in Security, up 10%. Infrastructure Platforms was down 3% and Applications was flat.

[0001193125-21-034339:8k_2_02:35]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 65.1%, 64.5%, and 66.6%,
respectively, as compared with 64.7%, 63.9%, and 66.6%, respectively, in the second quarter of fiscal 2020.

[0001193125-21-034339:8k_2_02:36]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 66.9%, 66.6%, and 67.9%, respectively, as compared with 66.4%, 65.9%, and 67.7%, respectively, in the second quarter of
fiscal 2020.

[0001193125-21-034339:8k_2_02:37]
Total gross margins by geographic segment were: 67.5% for the Americas, 66.9% for EMEA and 64.8% for APJC.

[0001193125-21-034339:8k_2_02:38]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, up 4%, and were 38.1% of revenue. Non-GAAP operating expenses were $3.9 billion, down 1%, and were 32.6% of revenue.

[0001193125-21-034339:8k_2_02:39]
Operating Income
— GAAP operating income was $3.2 billion, down 5%, with GAAP operating margin of 26.9%. Non-GAAP operating income was $4.1 billion, up 2%, with
non-GAAP operating margin at 34.4%.

[0001193125-21-034339:8k_2_02:40]
Provision for Income Taxes — The GAAP tax provision rate
was 21.8%. The non-GAAP tax provision rate was 19.0%.

[0001193125-21-034339:8k_2_02:41]
Net Income and EPS — On a GAAP basis,
net income was $2.5 billion, a decrease of 12%, and EPS was $0.60, a decrease of 12%. On a non-GAAP basis, net income was $3.4 billion, an increase of 2%, and EPS was $0.79, an increase of 3%.

[0001193125-21-034339:8k_2_02:42]
Cash Flow from Operating Activities — $3.0 billion for the second quarter of fiscal 2021, a decrease of 22% compared with
$3.8 billion for the second quarter of fiscal 2020.

[0001193125-21-034339:8k_2_02:43]
Balance Sheet and Other Financial Highlights

[0001193125-21-034339:8k_2_02:44]
Cash and Cash Equivalents and Investments — $30.6 billion at the end of the second quarter of fiscal 2021, compared with
$29.4 billion at the end of fiscal 2020.

[0001193125-21-034339:8k_2_02:45]
Deferred Revenue — $20.8 billion, up 12% in total, with deferred product revenue up
16%. Deferred service revenue was up 9%.

[0001193125-21-034339:8k_2_02:46]
Remaining Performance Obligations — $28.2 billion at the end of the second
quarter of fiscal 2021, up 13%.

[0001193125-21-034339:8k_2_02:47]
Capital Allocation — In the second quarter of fiscal 2021, we returned $2.3 billion to
shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.36 per common share, or $1.5 billion, and repurchased approximately 19 million shares of common stock under our stock repurchase program at an
average price of $42.82 per share for an aggregate purchase price of $801 million. The remaining authorized amount for stock repurchases under the program is $9.2 billion with no termination date.

[0001193125-21-034339:8k_2_02:48]
Acquisitions

[0001193125-21-034339:8k_2_02:49]
In the second quarter of fiscal 2021, we
closed the acquisition of Portshift, a privately held applications security solutions company, and the acquisition of assets and the team of Banzai Cloud Zrt., a company that specializes in deploying cloud-native applications.

[0001193125-21-034339:8k_2_02:50]
In the second quarter of fiscal 2021, we announced an amendment to the definitive merger agreement under which we previously agreed to acquire Acacia
Communications, Inc., a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity
and cost. Under the terms of the amended agreement, Cisco would acquire Acacia for $115 per share in cash, or for approximately $4.5 billion on a fully diluted basis, net of cash and marketable securities. The acquisition is expected to close
during the third quarter of fiscal 2021, subject to closing conditions, including Acacia stockholder approval. All required regulatory approvals have been received.

[0001193125-21-034339:8k_2_02:51]
2

[0001193125-21-034339:8k_2_02:52]
We announced our intent to acquire IMImobile PLC, a United Kingdom publicly-traded cloud communications
software and services company. The acquisition is expected to close during the third quarter of fiscal 2021, subject to certain regulatory approvals and IMImobile shareholder approval.

[0001193125-21-034339:8k_2_02:53]
In addition, we announced our intent to acquire Dashbase, Inc., an enterprise software company, which closed in the third quarter of fiscal 2021. We also
announced our intent to acquire Slido s.r.o, a privately held company that provides an audience interaction platform. The acquisition is expected to close during the second half of fiscal 2021, subject to customary closing conditions and regulatory
approvals.

[0001193125-21-034339:8k_2_02:54]
3

[0001193125-21-034339:8k_2_02:55]
Guidance for Q3 FY 2021

[0001193125-21-034339:8k_2_02:56]
Cisco expects to achieve the following results for the third quarter of fiscal 2021:

[0001193125-21-034339:8k_2_02:57]
| Q3 FY 2021 |  |  |
| Revenue |  | 3.5% - 5.5% growth Y/Y |
| Non-GAAP gross margin rate |  | 65% - 66% |
| Non-GAAP operating margin rate |  | 33% - 34% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.80 - $0.82 |

[0001193125-21-034339:8k_2_02:58]
Cisco’s third quarter of fiscal 2021 will have 14 weeks compared to 13 weeks for the third quarter of fiscal 2020 which
is reflected in the guidance.

[0001193125-21-034339:8k_2_02:59]
Cisco estimates that GAAP EPS will be $0.64 to $0.69 in the third quarter of fiscal 2021.

[0001193125-21-034339:8k_2_02:60]
A reconciliation between the Guidance for Q3 FY 2021 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q3 FY 2021” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-034339:8k_2_02:61]
Editor’s Notes:

[0001193125-21-034339:8k_2_02:62]
|  | • |  | Q2 fiscal year 2021 conference call to discuss Cisco’s results along with its guidance will be held on Tuesday, February 9, 2021 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-21-034339:8k_2_02:63]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 9, 2021 to 4:00 p.m. Pacific Time, February 16, 2021 at 1-800-391-9851 (United States) or 1-203-369-3268 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-034339:8k_2_02:64]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 9, 2021. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-034339:8k_2_02:65]
4

[0001193125-21-034339:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:67]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-21-034339:8k_2_02:68]
(In millions, except per-share amounts)

[0001193125-21-034339:8k_2_02:69]
(Unaudited)

[0001193125-21-034339:8k_2_02:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2021 |  |  | January 25,2020 |  |  | January 23,2021 |  |  | January 25,2020 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,572 |  |  | $ | 8,671 |  |  | $ | 17,159 |  |  | $ | 18,549 |  |
| Service |  |  | 3,388 |  |  |  | 3,334 |  |  |  | 6,730 |  |  |  | 6,615 |  |
| Total revenue |  |  | 11,960 |  |  |  | 12,005 |  |  |  | 23,889 |  |  |  | 25,164 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,044 |  |  |  | 3,126 |  |  |  | 6,250 |  |  |  | 6,650 |  |
| Service |  |  | 1,132 |  |  |  | 1,115 |  |  |  | 2,274 |  |  |  | 2,286 |  |
| Total cost of sales |  |  | 4,176 |  |  |  | 4,241 |  |  |  | 8,524 |  |  |  | 8,936 |  |
| GROSS MARGIN |  |  | 7,784 |  |  |  | 7,764 |  |  |  | 15,365 |  |  |  | 16,228 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,527 |  |  |  | 1,570 |  |  |  | 3,139 |  |  |  | 3,236 |  |
| Sales and marketing |  |  | 2,277 |  |  |  | 2,279 |  |  |  | 4,494 |  |  |  | 4,759 |  |
| General and administrative |  |  | 484 |  |  |  | 455 |  |  |  | 1,028 |  |  |  | 974 |  |
| Amortization of purchased intangible assets |  |  | 39 |  |  |  | 38 |  |  |  | 75 |  |  |  | 74 |  |
| Restructuring and other charges |  |  | 234 |  |  |  | 42 |  |  |  | 836 |  |  |  | 226 |  |
| Total operating expenses |  |  | 4,561 |  |  |  | 4,384 |  |  |  | 9,572 |  |  |  | 9,269 |  |
| OPERATING INCOME |  |  | 3,223 |  |  |  | 3,380 |  |  |  | 5,793 |  |  |  | 6,959 |  |
| Interest income |  |  | 161 |  |  |  | 242 |  |  |  | 335 |  |  |  | 515 |  |
| Interest expense |  |  | (113 | ) |  |  | (158 | ) |  |  | (225 | ) |  |  | (336 | ) |
| Other income (loss), net |  |  | (16 | ) |  |  | 70 |  |  |  | 33 |  |  |  | 82 |  |
| Interest and other income (loss), net |  |  | 32 |  |  |  | 154 |  |  |  | 143 |  |  |  | 261 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,255 |  |  |  | 3,534 |  |  |  | 5,936 |  |  |  | 7,220 |  |
| Provision for income taxes |  |  | 710 |  |  |  | 656 |  |  |  | 1,217 |  |  |  | 1,416 |  |
| NET INCOME |  | $ | 2,545 |  |  | $ | 2,878 |  |  | $ | 4,719 |  |  | $ | 5,804 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 1.12 |  |  | $ | 1.37 |  |
| Diluted |  | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 1.11 |  |  | $ | 1.36 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,223 |  |  |  | 4,242 |  |  |  | 4,227 |  |  |  | 4,244 |  |
| Diluted |  |  | 4,234 |  |  |  | 4,260 |  |  |  | 4,239 |  |  |  | 4,265 |  |

[0001193125-21-034339:8k_2_02:71]
5

[0001193125-21-034339:8k_2_02:72]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:73]
REVENUE BY SEGMENT

[0001193125-21-034339:8k_2_02:74]
(In
millions, except percentages)

[0001193125-21-034339:8k_2_02:75]
|  |  | January 23, 2021 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,969 |  |  |  | (1 | )% |  | $ | 14,168 |  |  |  | (5 | )% |
| EMEA |  |  | 3,207 |  |  |  | 2 | % |  |  | 6,171 |  |  |  | (4 | )% |
| APJC |  |  | 1,784 |  |  |  | (4 | )% |  |  | 3,551 |  |  |  | (6 | )% |
| Total |  | $ | 11,960 |  |  |  | — | % |  | $ | 23,889 |  |  |  | (5 | )% |

[0001193125-21-034339:8k_2_02:76]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-034339:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:78]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-21-034339:8k_2_02:79]
(In percentages)

[0001193125-21-034339:8k_2_02:80]
|  |  | January 23, 2021 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 67.5 | % |  |  | 67.4 | % |
| EMEA |  |  | 66.9 | % |  |  | 65.4 | % |
| APJC |  |  | 64.8 | % |  |  | 63.9 | % |

[0001193125-21-034339:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:82]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-21-034339:8k_2_02:83]
(In millions, except percentages)

[0001193125-21-034339:8k_2_02:84]
|  |  | January 23, 2021 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,391 |  |  |  | (3 | )% |  | $ | 12,732 |  |  |  | (10 | )% |
| Applications |  |  | 1,354 |  |  |  | — | % |  |  | 2,734 |  |  |  | (4 | )% |
| Security |  |  | 822 |  |  |  | 10 | % |  |  | 1,684 |  |  |  | 8 | % |
| Other Products |  |  | 4 |  |  |  | (39 | )% |  |  | 9 |  |  |  | (49 | )% |
| Total Product |  |  | 8,572 |  |  |  | (1 | )% |  |  | 17,159 |  |  |  | (7 | )% |
| Services |  |  | 3,388 |  |  |  | 2 | % |  |  | 6,730 |  |  |  | 2 | % |
| Total |  | $ | 11,960 |  |  |  | — | % |  | $ | 23,889 |  |  |  | (5 | )% |

[0001193125-21-034339:8k_2_02:85]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-034339:8k_2_02:86]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:87]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-21-034339:8k_2_02:88]
(In millions)

[0001193125-21-034339:8k_2_02:89]
(Unaudited)

[0001193125-21-034339:8k_2_02:90]
|  |  | January 23, 2021 |  |  | July 25, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,793 |  |  | $ | 11,809 |  |
| Investments |  |  | 18,795 |  |  |  | 17,610 |  |
| Accounts receivable, net of allowance for doubtful accounts of $102 at January 23, 2021 and $143 at July 25, 2020 |  |  | 4,307 |  |  |  | 5,472 |  |
| Inventories |  |  | 1,436 |  |  |  | 1,282 |  |
| Financing receivables, net |  |  | 5,027 |  |  |  | 5,051 |  |
| Other current assets |  |  | 2,553 |  |  |  | 2,349 |  |
| Total current assets |  |  | 43,911 |  |  |  | 43,573 |  |
| Property and equipment, net |  |  | 2,386 |  |  |  | 2,453 |  |
| Financing receivables, net |  |  | 5,100 |  |  |  | 5,714 |  |
| Goodwill |  |  | 34,733 |  |  |  | 33,806 |  |
| Purchased intangible assets, net |  |  | 1,462 |  |  |  | 1,576 |  |
| Deferred tax assets |  |  | 4,109 |  |  |  | 3,990 |  |
| Other assets |  |  | 3,900 |  |  |  | 3,741 |  |
| TOTAL ASSETS |  | $ | 95,601 |  |  | $ | 94,853 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 5,000 |  |  | $ | 3,005 |  |
| Accounts payable |  |  | 1,867 |  |  |  | 2,218 |  |
| Income taxes payable |  |  | 763 |  |  |  | 839 |  |
| Accrued compensation |  |  | 3,295 |  |  |  | 3,122 |  |
| Deferred revenue |  |  | 11,552 |  |  |  | 11,406 |  |
| Other current liabilities |  |  | 4,791 |  |  |  | 4,741 |  |
| Total current liabilities |  |  | 27,268 |  |  |  | 25,331 |  |
| Long-term debt |  |  | 9,554 |  |  |  | 11,578 |  |
| Income taxes payable |  |  | 8,084 |  |  |  | 8,837 |  |
| Deferred revenue |  |  | 9,294 |  |  |  | 9,040 |  |
| Other long-term liabilities |  |  | 2,280 |  |  |  | 2,147 |  |
| Total liabilities |  |  | 56,480 |  |  |  | 56,933 |  |
| Total equity |  |  | 39,121 |  |  |  | 37,920 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 95,601 |  |  | $ | 94,853 |  |

[0001193125-21-034339:8k_2_02:91]
7

[0001193125-21-034339:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:93]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-21-034339:8k_2_02:94]
(In millions)

[0001193125-21-034339:8k_2_02:95]
(Unaudited)

[0001193125-21-034339:8k_2_02:96]
|  |  | Six Months Ended |  |
|  |  | January 23,2021 |  |  | January 25,2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,719 |  |  | $ | 5,804 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 887 |  |  |  | 918 |  |
| Share-based compensation expense |  |  | 874 |  |  |  | 779 |  |
| Provision (benefit) for receivables |  |  | (10 | ) |  |  | 46 |  |
| Deferred income taxes |  |  | (91 | ) |  |  | 128 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | (86 | ) |  |  | (162 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,245 |  |  |  | 1,084 |  |
| Inventories |  |  | (145 | ) |  |  | 25 |  |
| Financing receivables |  |  | 748 |  |  |  | 408 |  |
| Other assets |  |  | (212 | ) |  |  | 130 |  |
| Accounts payable |  |  | (358 | ) |  |  | (126 | ) |
| Income taxes, net |  |  | (836 | ) |  |  | (1,007 | ) |
| Accrued compensation |  |  | 125 |  |  |  | (521 | ) |
| Deferred revenue |  |  | 226 |  |  |  | 236 |  |
| Other liabilities |  |  | (16 | ) |  |  | (355 | ) |
| Net cash provided by operating activities |  |  | 7,070 |  |  |  | 7,387 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (6,025 | ) |  |  | (4,250 | ) |
| Proceeds from sales of investments |  |  | 1,374 |  |  |  | 3,410 |  |
| Proceeds from maturities of investments |  |  | 3,373 |  |  |  | 4,044 |  |
| Acquisitions and divestitures |  |  | (860 | ) |  |  | (163 | ) |
| Purchases of investments in privately held companies |  |  | (95 | ) |  |  | (97 | ) |
| Return of investments in privately held companies |  |  | 58 |  |  |  | 91 |  |
| Acquisition of property and equipment |  |  | (358 | ) |  |  | (391 | ) |
| Proceeds from sales of property and equipment |  |  | 9 |  |  |  | 131 |  |
| Other |  |  | (4 | ) |  |  | (10 | ) |
| Net cash (used in) provided by investing activities |  |  | (2,528 | ) |  |  | 2,765 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 306 |  |  |  | 334 |  |
| Repurchases of common stock—repurchase program |  |  | (1,569 | ) |  |  | (1,648 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (317 | ) |  |  | (437 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | — |  |  |  | (3,470 | ) |
| Repayments of debt |  |  | — |  |  |  | (5,220 | ) |
| Dividends paid |  |  | (3,041 | ) |  |  | (2,972 | ) |
| Other |  |  | 70 |  |  |  | (12 | ) |
| Net cash used in financing activities |  |  | (4,551 | ) |  |  | (13,425 | ) |
| Net decrease in cash, cash equivalents, and restricted cash |  |  | (9 | ) |  |  | (3,273 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 11,812 |  |  |  | 11,772 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 11,803 |  |  | $ | 8,499 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 220 |  |  | $ | 349 |  |
| Cash paid for income taxes, net |  | $ | 2,142 |  |  | $ | 2,295 |  |

[0001193125-21-034339:8k_2_02:97]
8

[0001193125-21-034339:8k_2_02:98]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:99]
DEFERRED REVENUE

[0001193125-21-034339:8k_2_02:100]
(In
millions)

[0001193125-21-034339:8k_2_02:101]
|  |  | January 23,2021 |  |  | October 24,2020 |  |  | January 25,2020 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,332 |  |  | $ | 8,139 |  |  | $ | 7,160 |  |
| Service |  |  | 12,514 |  |  |  | 12,334 |  |  |  | 11,526 |  |
| Total |  | $ | 20,846 |  |  | $ | 20,473 |  |  | $ | 18,686 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,552 |  |  | $ | 11,271 |  |  | $ | 10,638 |  |
| Noncurrent |  |  | 9,294 |  |  |  | 9,202 |  |  |  | 8,048 |  |
| Total |  | $ | 20,846 |  |  | $ | 20,473 |  |  | $ | 18,686 |  |

[0001193125-21-034339:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:103]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-21-034339:8k_2_02:104]
(In millions, except percentages)

[0001193125-21-034339:8k_2_02:105]
|  |  | January 23, 2021 |  |  | October 24, 2020 |  |  | January 25, 2020 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 11,666 |  |  |  | 17 | % |  | $ | 11,340 |  |  |  | 15 | % |  | $ | 9,933 |  |  |  | 25 | % |
| Service |  |  | 16,512 |  |  |  | 10 | % |  |  | 16,129 |  |  |  | 8 | % |  |  | 14,998 |  |  |  | 3 | % |
| Total |  | $ | 28,178 |  |  |  | 13 | % |  | $ | 27,469 |  |  |  | 10 | % |  | $ | 24,931 |  |  |  | 11 | % |

[0001193125-21-034339:8k_2_02:106]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:107]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-21-034339:8k_2_02:108]
(In millions, except per-share amounts)

[0001193125-21-034339:8k_2_02:109]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0001193125-21-034339:8k_2_02:110]
9

[0001193125-21-034339:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:112]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-034339:8k_2_02:113]
GAAP TO NON-GAAP NET INCOME

[0001193125-21-034339:8k_2_02:114]
(In millions)

[0001193125-21-034339:8k_2_02:115]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2021 |  |  | January 25,2020 |  |  | January 23,2021 |  |  | January 25,2020 |  |
| GAAP net income |  | $ | 2,545 |  |  | $ | 2,878 |  |  | $ | 4,719 |  |  | $ | 5,804 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 68 |  |  |  | 59 |  |  |  | 133 |  |  |  | 116 |  |
| Amortization of acquisition-related intangible assets |  |  | 152 |  |  |  | 150 |  |  |  | 315 |  |  |  | 300 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 43 |  |  |  | 4 |  |
| Total adjustments to GAAP cost of sales |  |  | 221 |  |  |  | 210 |  |  |  | 493 |  |  |  | 422 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 358 |  |  |  | 320 |  |  |  | 720 |  |  |  | 653 |  |
| Amortization of acquisition-related intangible assets |  |  | 39 |  |  |  | 38 |  |  |  | 75 |  |  |  | 74 |  |
| Acquisition-related/divestiture costs |  |  | 34 |  |  |  | 53 |  |  |  | 93 |  |  |  | 125 |  |
| Significant asset impairments and restructurings |  |  | 234 |  |  |  | 42 |  |  |  | 836 |  |  |  | 226 |  |
| Total adjustments to GAAP operating expenses |  |  | 665 |  |  |  | 453 |  |  |  | 1,724 |  |  |  | 1,078 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | (2 | ) |  |  | — |  |  |  | (2 | ) |  |  | — |  |
| (Gains) and losses on equity investments |  |  | 13 |  |  |  | (87 | ) |  |  | (35 | ) |  |  | (100 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | 11 |  |  |  | (87 | ) |  |  | (37 | ) |  |  | (100 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 897 |  |  |  | 576 |  |  |  | 2,180 |  |  |  | 1,400 |  |
| Income tax effect of non-GAAP adjustments |  |  | (162 | ) |  |  | (166 | ) |  |  | (408 | ) |  |  | (375 | ) |
| Significant tax matters |  |  | 83 |  |  |  | — |  |  |  | 83 |  |  |  | 67 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (79 | ) |  |  | (166 | ) |  |  | (325 | ) |  |  | (308 | ) |
| Non-GAAP net income |  | $ | 3,363 |  |  | $ | 3,288 |  |  | $ | 6,574 |  |  | $ | 6,896 |  |

[0001193125-21-034339:8k_2_02:116]
10

[0001193125-21-034339:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:118]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-034339:8k_2_02:119]
GAAP TO NON-GAAP EPS

[0001193125-21-034339:8k_2_02:120]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2021 |  |  | January 25,2020 |  |  | January 23,2021 |  |  | January 25,2020 |  |
| GAAP EPS |  | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 1.11 |  |  | $ | 1.36 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.10 |  |  |  | 0.09 |  |  |  | 0.20 |  |  |  | 0.18 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.05 |  |  |  | 0.04 |  |  |  | 0.09 |  |  |  | 0.09 |  |
| Acquisition-related/divestiture costs |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.03 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 0.06 |  |  |  | 0.01 |  |  |  | 0.20 |  |  |  | 0.05 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | (0.02 | ) |  |  | (0.01 | ) |  |  | (0.02 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.04 | ) |  |  | (0.10 | ) |  |  | (0.09 | ) |
| Significant tax matters |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Non-GAAP EPS |  | $ | 0.79 |  |  | $ | 0.77 |  |  | $ | 1.55 |  |  | $ | 1.62 |  |

[0001193125-21-034339:8k_2_02:121]
Amounts may not sum due to rounding.

[0001193125-21-034339:8k_2_02:122]
11

[0001193125-21-034339:8k_2_02:123]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:124]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-034339:8k_2_02:125]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-034339:8k_2_02:126]
(In millions, except percentages)

[0001193125-21-034339:8k_2_02:127]
|  |  | Three Months Ended |  |
|  |  | January 23, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,528 |  |  | $ | 2,256 |  |  | $ | 7,784 |  |  | $ | 4,561 |  |  |  | 4 | % |  | $ | 3,223 |  |  |  | (5 | )% |  | $ | 32 |  |  | $ | 2,545 |  |  |  | (12 | )% |
| % of revenue |  |  | 64.5 | % |  |  | 66.6 | % |  |  | 65.1 | % |  |  | 38.1 | % |  |  |  |  |  |  | 26.9 | % |  |  |  |  |  |  | 0.3 | % |  |  | 21.3 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 25 |  |  |  | 43 |  |  |  | 68 |  |  |  | 358 |  |  |  |  |  |  |  | 426 |  |  |  |  |  |  |  | — |  |  |  | 426 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 152 |  |  |  | — |  |  |  | 152 |  |  |  | 39 |  |  |  |  |  |  |  | 191 |  |  |  |  |  |  |  | — |  |  |  | 191 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 34 |  |  |  |  |  |  |  | 35 |  |  |  |  |  |  |  | (2 | ) |  |  | 33 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 234 |  |  |  |  |  |  |  | 234 |  |  |  |  |  |  |  | — |  |  |  | 234 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 13 |  |  |  | 13 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (79 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,706 |  |  | $ | 2,299 |  |  | $ | 8,005 |  |  | $ | 3,896 |  |  |  | (1 | )% |  | $ | 4,109 |  |  |  | 2 | % |  | $ | 43 |  |  | $ | 3,363 |  |  |  | 2 | % |
| % of revenue |  |  | 66.6 | % |  |  | 67.9 | % |  |  | 66.9 | % |  |  | 32.6 | % |  |  |  |  |  |  | 34.4 | % |  |  |  |  |  |  | 0.4 | % |  |  | 28.1 | % |  |  |  |  |

[0001193125-21-034339:8k_2_02:128]
|  |  | Three Months Ended |  |
|  |  | January 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interest andotherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,545 |  |  | $ | 2,219 |  |  | $ | 7,764 |  |  | $ | 4,384 |  |  | $ | 3,380 |  |  | $ | 154 |  |  | $ | 2,878 |  |
| % of revenue |  |  | 63.9 | % |  |  | 66.6 | % |  |  | 64.7 | % |  |  | 36.5 | % |  |  | 28.2 | % |  |  | 1.3 | % |  |  | 24.0 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 36 |  |  |  | 59 |  |  |  | 320 |  |  |  | 379 |  |  |  | — |  |  |  | 379 |  |
| Amortization of acquisition-related intangible assets |  |  | 150 |  |  |  | — |  |  |  | 150 |  |  |  | 38 |  |  |  | 188 |  |  |  | — |  |  |  | 188 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 53 |  |  |  | 54 |  |  |  | — |  |  |  | 54 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 42 |  |  |  | — |  |  |  | 42 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (87 | ) |  |  | (87 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (166 | ) |
| Non-GAAP amount |  | $ | 5,718 |  |  | $ | 2,256 |  |  | $ | 7,974 |  |  | $ | 3,931 |  |  | $ | 4,043 |  |  | $ | 67 |  |  | $ | 3,288 |  |
| % of revenue |  |  | 65.9 | % |  |  | 67.7 | % |  |  | 66.4 | % |  |  | 32.7 | % |  |  | 33.7 | % |  |  | 0.6 | % |  |  | 27.4 | % |

[0001193125-21-034339:8k_2_02:129]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-034339:8k_2_02:130]
12

[0001193125-21-034339:8k_2_02:131]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:132]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-034339:8k_2_02:133]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-034339:8k_2_02:134]
(In millions, except percentages)

[0001193125-21-034339:8k_2_02:135]
|  |  | Six Months Ended |  |
|  |  | January 23, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 10,909 |  |  | $ | 4,456 |  |  | $ | 15,365 |  |  | $ | 9,572 |  |  |  | 3 | % |  | $ | 5,793 |  |  |  | (17 | )% |  | $ | 143 |  |  | $ | 4,719 |  |  |  | (19 | )% |
| % of revenue |  |  | 63.6 | % |  |  | 66.2 | % |  |  | 64.3 | % |  |  | 40.1 | % |  |  |  |  |  |  | 24.2 | % |  |  |  |  |  |  | 0.6 | % |  |  | 19.8 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 49 |  |  |  | 84 |  |  |  | 133 |  |  |  | 720 |  |  |  |  |  |  |  | 853 |  |  |  |  |  |  |  | — |  |  |  | 853 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 315 |  |  |  | — |  |  |  | 315 |  |  |  | 75 |  |  |  |  |  |  |  | 390 |  |  |  |  |  |  |  | — |  |  |  | 390 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 93 |  |  |  |  |  |  |  | 95 |  |  |  |  |  |  |  | (2 | ) |  |  | 93 |  |  |  |  |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  |  |  |  |  | 43 |  |  |  |  |  |  |  | — |  |  |  | 43 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 836 |  |  |  |  |  |  |  | 836 |  |  |  |  |  |  |  | — |  |  |  | 836 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (35 | ) |  |  | (35 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (325 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 11,317 |  |  | $ | 4,541 |  |  | $ | 15,858 |  |  | $ | 7,848 |  |  |  | (4 | )% |  | $ | 8,010 |  |  |  | (5 | )% |  | $ | 106 |  |  | $ | 6,574 |  |  |  | (5 | )% |
| % of revenue |  |  | 66.0 | % |  |  | 67.5 | % |  |  | 66.4 | % |  |  | 32.9 | % |  |  |  |  |  |  | 33.5 | % |  |  |  |  |  |  | 0.4 | % |  |  | 27.5 | % |  |  |  |  |

[0001193125-21-034339:8k_2_02:136]
|  |  | Six Months Ended |  |
|  |  | January 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interest andotherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 11,899 |  |  | $ | 4,329 |  |  | $ | 16,228 |  |  | $ | 9,269 |  |  | $ | 6,959 |  |  | $ | 261 |  |  | $ | 5,804 |  |
| % of revenue |  |  | 64.1 | % |  |  | 65.4 | % |  |  | 64.5 | % |  |  | 36.8 | % |  |  | 27.7 | % |  |  | 1.0 | % |  |  | 23.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 46 |  |  |  | 70 |  |  |  | 116 |  |  |  | 653 |  |  |  | 769 |  |  |  | — |  |  |  | 769 |  |
| Amortization of acquisition-related intangible assets |  |  | 300 |  |  |  | — |  |  |  | 300 |  |  |  | 74 |  |  |  | 374 |  |  |  | — |  |  |  | 374 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 125 |  |  |  | 127 |  |  |  | — |  |  |  | 127 |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 226 |  |  |  | 226 |  |  |  | — |  |  |  | 226 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (100 | ) |  |  | (100 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (308 | ) |
| Non-GAAP amount |  | $ | 12,249 |  |  | $ | 4,401 |  |  | $ | 16,650 |  |  | $ | 8,191 |  |  | $ | 8,459 |  |  | $ | 161 |  |  | $ | 6,896 |  |
| % of revenue |  |  | 66.0 | % |  |  | 66.5 | % |  |  | 66.2 | % |  |  | 32.6 | % |  |  | 33.6 | % |  |  | 0.6 | % |  |  | 27.4 | % |

[0001193125-21-034339:8k_2_02:137]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-034339:8k_2_02:138]
13

[0001193125-21-034339:8k_2_02:139]
CISCO SYSTEMS, INC.

[0001193125-21-034339:8k_2_02:140]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-034339:8k_2_02:141]
EFFECTIVE TAX RATE

[0001193125-21-034339:8k_2_02:142]
(In
percentages)

[0001193125-21-034339:8k_2_02:143]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2021 |  |  | January 25,2020 |  |  | January 23,2021 |  |  | January 25,2020 |  |
| GAAP effective tax rate |  |  | 21.8 | % |  |  | 18.6 | % |  |  | 20.5 | % |  |  | 19.6 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (2.8 | )% |  |  | 1.4 | % |  |  | (1.5 | )% |  |  | 0.4 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 20.0 | % |  |  | 19.0 | % |  |  | 20.0 | % |

[0001193125-21-034339:8k_2_02:144]
GAAP TO NON-GAAP GUIDANCE FOR Q3 FY 2021

[0001193125-21-034339:8k_2_02:145]
| Q3 FY 2021 |  | Gross Margin Rate |  |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  |  | 63.5% - 64.5% |  |  | 27% - 28% |  | 19% |  | $0.64 - $0.69 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.5% |  |  | 3.5% |  | — |  | $0.08 - $0.09 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  |  | 1.0% |  |  | 2.0% |  | — |  | $0.04 - $0.05 |
| Significant asset impairments and restructurings (1) |  |  | — |  |  | 0.5% |  | — |  | $0.01 - $0.02 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  |  |  | — |  |  |
| Non-GAAP |  |  | 65% - 66% |  |  | 33% -34% |  | 19% |  | $0.80 - $0.82 |

[0001193125-21-034339:8k_2_02:146]
| (1) | In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas with total estimated pretax charges of approximately $900 million consisting of severance and other one-time termination benefits, and other costs. We recognized $602 million and $232 million of these charges during the first and second quarter of fiscal 2021, respectively. We expect to recognize approximately $60 million of these charges in the third quarter of fiscal 2021 with the remaining amount to be recognized during the rest of the fiscal year. |

[0001193125-21-034339:8k_2_02:147]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-21-034339:8k_2_02:148]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-21-034339:8k_2_02:149]
14

[0001193125-21-034339:8k_2_02:150]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-21-034339:8k_2_02:151]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating
income and margin, non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per
share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-21-034339:8k_2_02:152]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-21-034339:8k_2_02:153]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-21-034339:8k_2_02:154]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures.

[0001193125-21-034339:8k_2_02:155]
15

[0001193125-21-034339:8k_2_02:156]
From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information
on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and
Exchange Commission.

[0001193125-21-034339:8k_2_02:157]
About Cisco

[0001193125-21-034339:8k_2_02:158]
Cisco (Nasdaq:
CSCO) is the worldwide leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and
inclusive future. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-21-034339:8k_2_02:159]
Copyright
© 2021 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.

[0001193125-21-034339:8k_2_02:160]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-21-034339:8k_2_02:161]
16
