# CSCO note change history — 0000858877-20-000015 → 0000858877-21-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 23, 2021 and July 25, 2020, we had total purchase commitments for inventory of $4.6 billion and $4.4 billion, respectively.
  (was, 2020-11-17, similarity 0.9937):
[0000858877-20-000015:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of October 24, 2020 and July 25, 2020, we had total purchase commitments for inventory of $4.2 billion and $4.4 billion, respectively.

- changed (2021-02-16):
[0000858877-21-000004:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2021 and July 25, 2020, the liability for these purchase commitments was $152 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $44 million and $67 million for the first six months of fiscal 2021 and 2020, respectively.
  (was, 2020-11-17, similarity 0.9569):
[0000858877-20-000015:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 24, 2020 and July 25, 2020, the liability for these purchase commitments was $157 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $32 million and $29 million for the first quarter of fiscal 2021 and 2020, respectively.

- changed (2021-02-16):
[0000858877-21-000004:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Compensation expense related to acquisitions | $ | 59 |  |  | $ | 50 |  |  | $ | 116 |  |  | $ | 111 |  |
  (was, 2020-11-17, similarity 0.6985):
[0000858877-20-000015:note_history:3]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Compensation expense related to acquisitions | $ | 57 |  |  | $ | 61 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:4]
As of January 23, 2021, we estimated that future cash compensation expense of up to $452 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2020-11-17, similarity 0.9669):
[0000858877-20-000015:note_history:4]
As of October 24, 2020, we estimated that future cash compensation expense of up to $495 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2021-02-16):
[0000858877-21-000004:note_history:5]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of January 23, 2021 and July 25, 2020.
  (was, 2020-11-17, similarity 0.9443):
[0000858877-20-000015:note_history:5]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 24, 2020 and July 25, 2020.

- changed (2021-02-16):
[0000858877-21-000004:note_history:6]
|  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 247 |  |  | 283 |  |
| Adjustments for pre-existing warranties | 4 |  |  | (3) |  |
| Settlements | (249) |  |  | (291) |  |
| Balance at end of period | $ | 333 |  |  | $ | 331 |  |
  (was, 2020-11-17, similarity 0.9183):
[0000858877-20-000015:note_history:6]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 121 |  |  | 140 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (3) |  |
| Settlements | (122) |  |  | (149) |  |
| Balance at end of period | $ | 331 |  |  | $ | 330 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.6 billion for the second quarter of fiscal 2021 and 2020, respectively, and was $12.8 billion and $14.2 billion for the first six months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of January 23, 2021 and July 25, 2020, respectively.
  (was, 2020-11-17, similarity 0.9204):
[0000858877-20-000015:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $7.6 billion for the first quarter of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of October 24, 2020 and July 25, 2020, respectively.

- changed (2021-02-16):
[0000858877-21-000004:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the second quarter of fiscal 2021 and 2020, respectively, and was $8 million and $6 million for the first six months of fiscal 2021 and 2020, respectively.
  (was, 2020-11-17, similarity 0.7748):
[0000858877-20-000015:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million for each of the first quarters of fiscal 2021 and 2020.

- changed (2021-02-16):
[0000858877-21-000004:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2020-11-17, similarity 0.9776):
[0000858877-20-000015:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2020 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2021-02-16):
[0000858877-21-000004:note_history:10]
|  | January 23,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 205 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 213 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (19) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (27) |  |  | $ | (28) |  |
| Total | $ | 186 |  |  | $ | 179 |  |
  (was, 2020-11-17, similarity 0.9831):
[0000858877-20-000015:note_history:10]
|  | October 24,2020 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 193 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 201 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (25) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (33) |  |  | $ | (28) |  |
| Total | $ | 168 |  |  | $ | 179 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:11]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre- and post-judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.
  (was, 2020-11-17, similarity 0.8257):
[0000858877-20-000015:note_history:11]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

- changed (2021-02-16):
[0000858877-21-000004:note_history:12]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided
  (was, 2020-11-17, similarity 0.9225):
[0000858877-20-000015:note_history:12]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. On October

- added (2021-02-16):
[0000858877-21-000004:note_history:13]
by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. On October 13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that Chanbond will not be able to meet its burden required for injunctive relief. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- changed (2021-02-16):
[0000858877-21-000004:note_history:14]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $148 million for the alleged evasion of import and other taxes, $728 million for interest, and $366 million for various penalties, all determined using an exchange rate as of January 23, 2021.
  (was, 2020-11-17, similarity 0.9916):
[0000858877-20-000015:note_history:14]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of October 24, 2020.

- added (2021-02-16):
[0000858877-21-000004:note_history:15]
China     The Company is investigating allegations of a self-enrichment scheme involving now-former employees in China.  Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. The Company voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

- changed (2021-02-16):
[0000858877-21-000004:note_history:16]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment when it becomes final as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.
  (was, 2020-11-17, similarity 0.7589):
[0000858877-20-000015:note_history:16]
sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the cases filed in Germany and we believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

- added (2021-02-16):
[0000858877-21-000004:note_history:17]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have now expired such that no injunctive relief is available on those patents. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty (instead of injunctive relief) until its expiration on December 12, 2025. The case is currently set for jury trial starting June 4, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

- changed (2021-02-16):
[0000858877-21-000004:note_history:18]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. As of November 27, 2020, the U.S. Patent & Trademark Office preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the Court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
  (was, 2020-11-17, similarity 0.642):
[0000858877-20-000015:note_history:18]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. The case is currently set for a jury trial starting December 4, 2020. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- added (2021-02-16):
[0000858877-21-000004:note_history:19]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of 
operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- removed (2021-02-16):
[0000858877-20-000015:note_history:20]
13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- removed (2021-02-16):
[0000858877-20-000015:note_history:21]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal

- removed (2021-02-16):
[0000858877-20-000015:note_history:22]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting January 11, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:23]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 is a 53-week fiscal year and fiscal 2020 was a 52-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2020-11-17, similarity 0.9863):
[0000858877-20-000015:note_history:23]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 is a 53-week fiscal year and fiscal 2020 was a 52-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- added (2021-02-16):
[0000858877-21-000004:note_history:24]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing the state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

- changed (2021-02-16):
[0000858877-21-000004:note_history:25]
We have prepared the accompanying financial data as of January 23, 2021 and for the second quarter and first six months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.
  (was, 2020-11-17, similarity 0.977):
[0000858877-20-000015:note_history:25]
We have prepared the accompanying financial data as of October 24, 2020 and for the first quarter of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

- added (2021-02-16):
[0000858877-21-000004:note_history:26]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2021 and 2020, and the statements of cash flows for the first six months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2021-02-16):
[0000858877-20-000015:note_history:27]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2020, the results of operations, the statements of comprehensive income (loss), the statements of cash flows and the statements of equity for the first quarter of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the first quarter of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:28]
|  | January 23, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,000 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2020-11-17, similarity 0.9651):
[0000858877-20-000015:note_history:28]
|  | October 24, 2020 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,002 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |

- changed (2021-02-16):
[0000858877-21-000004:note_history:29]
|  |  |  | January 23, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.92% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.17% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.33% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (84) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 138 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,554 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2020-11-17, similarity 0.9943):
[0000858877-20-000015:note_history:29]
|  |  |  | October 24, 2020 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.91% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.19% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.35% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (86) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 152 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,002 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,564 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:30]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2021, we were in compliance with all debt covenants.
  (was, 2020-11-17, similarity 0.984):
[0000858877-20-000015:note_history:30]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 24, 2020, we were in compliance with all debt covenants.

- changed (2021-02-16):
[0000858877-21-000004:note_history:31]
As of January 23, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-11-17, similarity 0.9556):
[0000858877-20-000015:note_history:31]
As of October 24, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-02-16):
[0000858877-21-000004:note_history:32]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |
  (was, 2020-11-17, similarity 0.9836):
[0000858877-20-000015:note_history:32]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:33]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. On January 25, 2021, we entered into an amendment to the credit facility to obtain consent of the lenders to our reincorporation to Delaware. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of January 23, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2020-11-17, similarity 0.8511):
[0000858877-20-000015:note_history:33]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of October 24, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:34]
| January 23, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,613 |  |  | $ | 50 |  |  | $ | — |  |  | $ | 2,663 |  |
| U.S. government agency securities | 168 |  |  | — |  |  | — |  |  | 168 |  |
| Corporate debt securities | 10,516 |  |  | 296 |  |  | (26) |  |  | 10,786 |  |
| U.S. agency mortgage-backed securities | 2,796 |  |  | 47 |  |  | (3) |  |  | 2,840 |  |
| Commercial paper | 1,730 |  |  | — |  |  | — |  |  | 1,730 |  |
| Certificates of deposit | 603 |  |  | — |  |  | — |  |  | 603 |  |
| Total (1) | $ | 18,426 |  |  | $ | 393 |  |  | $ | (29) |  |  | $ | 18,790 |  |
  (was, 2020-11-17, similarity 0.9875):
[0000858877-20-000015:note_history:34]
| October 24, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,656 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 2,717 |  |
| U.S. government agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Corporate debt securities | 11,266 |  |  | 298 |  |  | (27) |  |  | 11,537 |  |
| U.S. agency mortgage-backed securities | 2,494 |  |  | 41 |  |  | (6) |  |  | 2,529 |  |
| Commercial paper | 1,712 |  |  | — |  |  | — |  |  | 1,712 |  |
| Certificates of deposit | 517 |  |  | — |  |  | — |  |  | 517 |  |
| Total (1) | $ | 18,823 |  |  | $ | 400 |  |  | $ | (33) |  |  | $ | 19,190 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:35]
(1) Net unsettled investment sales were $39 million as of January 23, 2021 and were included in other current assets.
  (was, 2020-11-17, similarity 0.9459):
[0000858877-20-000015:note_history:35]
(1) Net unsettled investment sales were $57 million as of October 24, 2020 and were included in other current assets.

- changed (2021-02-16):
[0000858877-21-000004:note_history:36]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Gross realized gains | $ | 9 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 25 |  |
| Gross realized losses | — |  |  | (2) |  |  | — |  |  | (4) |  |
| Total | $ | 9 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | 21 |  |
  (was, 2020-11-17, similarity 0.7002):
[0000858877-20-000015:note_history:36]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Gross realized gains | $ | 15 |  |  | $ | 12 |  |
| Gross realized losses | — |  |  | (2) |  |
| Total | $ | 15 |  |  | $ | 10 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2021 and July 25, 2020 (in millions):
  (was, 2020-11-17, similarity 0.967):
[0000858877-20-000015:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2020 and July 25, 2020 (in millions):

- changed (2021-02-16):
[0000858877-21-000004:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 109 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |
| U.S. government agency securities | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Corporate debt securities | 663 |  |  | (1) |  |  | — |  |  | — |  |  | 663 |  |  | (1) |  |
| U.S. agency mortgage-backed securities | 698 |  |  | (3) |  |  | — |  |  | — |  |  | 698 |  |  | (3) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 1,521 |  |  | $ | (4) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,521 |  |  | $ | (4) |  |
  (was, 2020-11-17, similarity 0.9906):
[0000858877-20-000015:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 144 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 144 |  |  | $ | — |  |
| U.S. government agency securities | 65 |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |
| Corporate debt securities | 1,008 |  |  | (2) |  |  | — |  |  | — |  |  | 1,008 |  |  | (2) |  |
| U.S. agency mortgage-backed securities | 1,076 |  |  | (6) |  |  | — |  |  | — |  |  | 1,076 |  |  | (6) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 2,308 |  |  | $ | (8) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,308 |  |  | $ | (8) |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:39]
The following table summarizes the maturities of our available-for-sale debt investments as of January 23, 2021 (in millions):
  (was, 2020-11-17, similarity 0.9504):
[0000858877-20-000015:note_history:39]
The following table summarizes the maturities of our available-for-sale debt investments as of October 24, 2020 (in millions):

- added (2021-02-16):
[0000858877-21-000004:note_history:40]
Our net unrealized gains recognized during the reporting period on our marketable and non-marketable equity securities still held as of January 23, 2021 was $4 million for each of the second quarter and first six months of fiscal 2021, and a net gain of $3 million for the corresponding periods of fiscal 2020. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $3 million and $4 million for the second quarter and first six months of fiscal 2021, respectively. These adjustments were net gains of $3 million for each of the corresponding periods of fiscal 2020. We held equity interests in certain private equity funds of $0.7 billion as of each of January 23, 2021 and July 25, 2020, which are accounted for under the NAV practical expedient.

- changed (2021-02-16):
[0000858877-21-000004:note_history:41]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 23, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2020-11-17, similarity 0.9881):
[0000858877-20-000015:note_history:41]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 24, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2021-02-16):
[0000858877-21-000004:note_history:42]
The carrying value of our investments in privately held companies was $1.3 billion as of each of January 23, 2021 and July 25, 2020.
  (was, 2020-11-17, similarity 0.8185):
[0000858877-20-000015:note_history:42]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of October 24, 2020 and July 25, 2020, respectively.

- changed (2021-02-16):
[0000858877-21-000004:note_history:43]
Of the total carrying value of our investments in privately held companies as of January 23, 2021, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.
  (was, 2020-11-17, similarity 0.978):
[0000858877-20-000015:note_history:43]
Of the total carrying value of our investments in privately held companies as of October 24, 2020, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to these privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.

- removed (2021-02-16):
[0000858877-20-000015:note_history:44]
Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $1 million and a net loss of $1 million for the first quarter of fiscal 2021 and 2020, respectively. We held equity interests in certain private equity funds of $0.7 billion as of each of October 24, 2020 and July 25, 2020, which are accounted for under the NAV practical expedient.

- removed (2021-02-16):
[0000858877-20-000015:note_history:45]
(c)Variable Interest Entities


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:46]
|  |  |  | January 23, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.92% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.17% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.33% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (84) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 138 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,554 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2020-11-17, similarity 0.9943):
[0000858877-20-000015:note_history:46]
|  |  |  | October 24, 2020 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.91% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.19% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.35% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (86) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 152 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,002 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,564 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:47]
As of January 23, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-11-17, similarity 0.9556):
[0000858877-20-000015:note_history:47]
As of October 24, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-02-16):
[0000858877-21-000004:note_history:48]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |
  (was, 2020-11-17, similarity 0.9836):
[0000858877-20-000015:note_history:48]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:49]
|  | January 23, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,000 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2020-11-17, similarity 0.9651):
[0000858877-20-000015:note_history:49]
|  | October 24, 2020 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,002 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-02-16):
[0000858877-21-000004:note_history:50]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

- added (2021-02-16):
[0000858877-21-000004:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

- removed (2021-02-16):
[0000858877-20-000015:note_history:52]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |

- removed (2021-02-16):
[0000858877-20-000015:note_history:53]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:54]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 23, 2021 and July 25, 2020 was $73 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2020-11-17, similarity 0.9759):
[0000858877-20-000015:note_history:54]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 24, 2020 and July 25, 2020 was $81 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-16):
[0000858877-21-000004:note_history:55]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 23, 2021 and July 25, 2020 was $73 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2020-11-17, similarity 0.9759):
[0000858877-20-000015:note_history:55]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 24, 2020 and July 25, 2020 was $81 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- added (2021-02-16):
[0000858877-21-000004:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:57]
Accounts receivable, net was $4.3 billion as of January 23, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.
  (was, 2020-11-17, similarity 0.9544):
[0000858877-20-000015:note_history:57]
Accounts receivable, net was $4.0 billion as of October 24, 2020 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheet.

- changed (2021-02-16):
[0000858877-21-000004:note_history:58]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.
  (was, 2020-11-17, similarity 0.9276):
[0000858877-20-000015:note_history:58]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.2 billion as of October 24, 2020 and July 25, 2020, and were included in other current assets and other assets.

- changed (2021-02-16):
[0000858877-21-000004:note_history:59]
|  | January 23,2021 |
| 1 to 4 | $ | 426 |  |
| 5 to 6 | 783 |  |
| 7 and Higher | 98 |  |
| Total | $ | 1,307 |  |
  (was, 2020-11-17, similarity 0.9375):
[0000858877-20-000015:note_history:59]
|  | October 24,2020 |
| 1 to 4 | $ | 442 |  |
| 5 to 6 | 737 |  |
| 7 and Higher | 119 |  |
| Total | $ | 1,298 |  |

- changed (2021-02-16):
[0000858877-21-000004:note_history:60]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.8 billion as of January 23, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.0 billion and $6.9 billion of revenue during the second quarter and first six months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.
  (was, 2020-11-17, similarity 0.6581):
[0000858877-20-000015:note_history:60]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.5 billion as of October 24, 2020 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.9 billion of revenue during the first quarter of fiscal 2021, that was included in the deferred revenue balance at July 25, 2020.

- changed (2021-02-16):
[0000858877-21-000004:note_history:61]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $817 million and $732 million as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $129 million and $252 million for the second quarter and first six months of fiscal 2021, respectively, and $122 million and $238 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.
  (was, 2020-11-17, similarity 0.8698):
[0000858877-20-000015:note_history:61]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $771 million and $732 million as of October 24, 2020 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $123 million and $116 million for the first quarter of fiscal 2021 and 2020, respectively, and was included in sales and marketing expenses.

- removed (2021-02-16):
[0000858877-20-000015:note_history:62]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |
