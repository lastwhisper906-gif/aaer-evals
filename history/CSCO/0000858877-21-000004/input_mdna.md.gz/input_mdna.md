# CSCO MD&A — 0000858877-21-000004


## mdna

[0000858877-21-000004:mdna:1]
[same as prior period, unchanged from 0000858877-20-000015:mdna:1]

[0000858877-21-000004:mdna:2]
[same as prior period, unchanged from 0000858877-20-000015:mdna:2]

[0000858877-21-000004:mdna:3]
[same as prior period, unchanged from 0000858877-20-000015:mdna:3]

[0000858877-21-000004:mdna:4]
[same as prior period, unchanged from 0000858877-20-000015:mdna:4]

[0000858877-21-000004:mdna:5]
[same as prior period, unchanged from 0000858877-20-000015:mdna:5]

[0000858877-21-000004:mdna:6]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 23,2021 |  | January 25,2020 |  | % Variance |  | January 23, 2021 |  | January 25, 2020 |  | % Variance |  |
| Revenue | $ | 11,960 |  |  | $ | 12,005 |  |  | — | % |  | $ | 23,889 |  |  | $ | 25,164 |  |  | (5) | % |  |
| Gross margin percentage | 65.1 | % |  | 64.7 | % |  | 0.4 |  | pts | 64.3 | % |  | 64.5 | % |  | (0.2) |  | pts |
| Research and development | $ | 1,527 |  |  | $ | 1,570 |  |  | (3) | % |  | $ | 3,139 |  |  | $ | 3,236 |  |  | (3) | % |  |
| Sales and marketing | $ | 2,277 |  |  | $ | 2,279 |  |  | — | % |  | $ | 4,494 |  |  | $ | 4,759 |  |  | (6) | % |  |
| General and administrative | $ | 484 |  |  | $ | 455 |  |  | 6 | % |  | $ | 1,028 |  |  | $ | 974 |  |  | 6 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,288 |  |  | $ | 4,304 |  |  | — | % |  | $ | 8,661 |  |  | $ | 8,969 |  |  | (3) | % |  |
| Total as a percentage of revenue | 35.9 | % |  | 35.9 | % |  | — |  | pts | 36.3 | % |  | 35.6 | % |  | 0.7 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 39 |  |  | $ | 38 |  |  | 3 | % |  | $ | 75 |  |  | $ | 74 |  |  | 1 | % |  |
| Restructuring and other charges included in operating expenses | $ | 234 |  |  | $ | 42 |  |  | 457 | % |  | $ | 836 |  |  | $ | 226 |  |  | 270 | % |  |
| Operating income as a percentage of revenue | 26.9 | % |  | 28.2 | % |  | (1.3) |  | pts | 24.2 | % |  | 27.7 | % |  | (3.5) |  | pts |
| Interest and other income (loss), net | $ | 32 |  |  | $ | 154 |  |  | (79) | % |  | $ | 143 |  |  | $ | 261 |  |  | (45) | % |  |
| Income tax percentage | 21.8 | % |  | 18.6 | % |  | 3.2 |  | pts | 20.5 | % |  | 19.6 | % |  | 0.9 |  | pts |
| Net income | $ | 2,545 |  |  | $ | 2,878 |  |  | (12) | % |  | $ | 4,719 |  |  | $ | 5,804 |  |  | (19) | % |  |
| Net income as a percentage of revenue | 21.3 | % |  | 24.0 | % |  | (2.7) |  | pts | 19.8 | % |  | 23.1 | % |  | (3.3) |  | pts |
| Earnings per share—diluted | $ | 0.60 |  |  | $ | 0.68 |  |  | (12) | % |  | $ | 1.11 |  |  | $ | 1.36 |  |  | (18) | % |  |

[0000858877-21-000004:mdna:7]
[same as prior period, unchanged from 0000858877-20-000015:mdna:7]

[0000858877-21-000004:mdna:8]
[same as prior period, unchanged from 0000858877-20-000015:mdna:8]

[0000858877-21-000004:mdna:9]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:10]
In the second quarter of fiscal 2021, we saw improving business momentum and delivered strong total gross margin in a challenging environment with the COVID-19 pandemic. As customers have accelerated their digitization and cloud investments in the wake of the pandemic, we have been focusing on executing and innovating to support and assist that transition. Total revenue was flat compared with the second quarter of fiscal 2020. Our product revenue declined in Infrastructure Platforms partially offset by growth in Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-21-000004:mdna:11]
Within total revenue, product revenue decreased by 1% and service revenue increased by 2%. Total gross margin increased by 0.4 percentage points, driven by favorable product mix and to a lesser extent, productivity improvements, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, was flat. Operating income as a percentage of revenue decreased by 1.3 percentage points. We incurred restructuring and other charges of $234 million in the second quarter of fiscal 2021, which resulted in a decrease of 12% in net income and a decrease of 12% in diluted earnings per share.

[0000858877-21-000004:mdna:12]
In terms of our geographic segments, revenue from the Americas decreased $44 million, EMEA revenue increased by $73 million and APJC revenue decreased by $75 million. We continue to experience continuing weakness in emerging countries, and we expect ongoing uncertainty in this market. The “BRICM” countries experienced a product revenue decline of 13% in the aggregate, driven by decreased product revenue across each of the BRICM countries.

[0000858877-21-000004:mdna:13]
From a customer market standpoint, we experienced product revenue declines in the enterprise, service provider and commercial markets, partially offset by product revenue growth in the public sector market. We are seeing improvement in business momentum in the service provider, public sector and commercial markets.

[0000858877-21-000004:mdna:14]
From a product category perspective, the product revenue decrease of 1% was driven by declines in revenue in Infrastructure Platforms of 3%, partially offset by a product revenue increase in Security of 10%. Applications was flat.

[0000858877-21-000004:mdna:15]
[same as prior period, unchanged from 0000858877-20-000015:mdna:47]

[0000858877-21-000004:mdna:16]
[same as prior period, unchanged from 0000858877-20-000015:mdna:27]

[0000858877-21-000004:mdna:17]
[same as prior period, unchanged from 0000858877-20-000015:mdna:28]

[0000858877-21-000004:mdna:18]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:19]
Total revenue decreased 5%, with product revenue decreasing 7% and service revenue increasing 2%. Total gross margin decreased by 0.2 percentage points due to pricing erosion, and to a lesser extent, lower productivity benefits, partially offset by favorable impacts from product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.7 percentage points. Operating income as a percentage of revenue decreased by 3.5 percentage points. We incurred restructuring and other charges of $836 million in the first six months of fiscal 2021, which resulted in a decrease of 19% in net income and a decrease of 18% in diluted earnings per share.

[0000858877-21-000004:mdna:20]
[same as prior period, unchanged from 0000858877-20-000015:mdna:15]

[0000858877-21-000004:mdna:21]
During this extraordinary time, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations. The actions we have taken and are taking include:

[0000858877-21-000004:mdna:22]
[same as prior period, unchanged from 0000858877-20-000015:mdna:17]

[0000858877-21-000004:mdna:23]
[same as prior period, unchanged from 0000858877-20-000015:mdna:18]

[0000858877-21-000004:mdna:24]
[same as prior period, unchanged from 0000858877-20-000015:mdna:19]

[0000858877-21-000004:mdna:25]
[same as prior period, unchanged from 0000858877-20-000015:mdna:20]

[0000858877-21-000004:mdna:26]
[same as prior period, unchanged from 0000858877-20-000015:mdna:21]

[0000858877-21-000004:mdna:27]
[same as prior period, unchanged from 0000858877-20-000015:mdna:22]

[0000858877-21-000004:mdna:28]
[same as prior period, unchanged from 0000858877-20-000015:mdna:23]

[0000858877-21-000004:mdna:29]
[same as prior period, unchanged from 0000858877-20-000015:mdna:24]

[0000858877-21-000004:mdna:30]
•Provided technology and financial support for non-profits, first responders, and governments.

[0000858877-21-000004:mdna:31]
•Donated personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world.

[0000858877-21-000004:mdna:32]
[same as prior period, unchanged from 0000858877-20-000015:mdna:36]

[0000858877-21-000004:mdna:33]
[same as prior period, unchanged from 0000858877-20-000015:mdna:37]

[0000858877-21-000004:mdna:34]
[same as prior period, unchanged from 0000858877-20-000015:mdna:29]

[0000858877-21-000004:mdna:35]
[same as prior period, unchanged from 0000858877-20-000015:mdna:30]

[0000858877-21-000004:mdna:36]
[same as prior period, unchanged from 0000858877-20-000015:mdna:31]

[0000858877-21-000004:mdna:37]
[same as prior period, unchanged from 0000858877-20-000015:mdna:32]

[0000858877-21-000004:mdna:38]
The following is a summary of our other key financial measures for the second quarter of fiscal 2021 (in millions):

[0000858877-21-000004:mdna:39]
|  |  | January 23,2021 |  | July 25,2020 |
| Cash and cash equivalents and investments |  | $ | 30,588 |  |  | $ | 29,419 |  |
| Deferred revenue |  | $ | 20,846 |  |  | $ | 20,446 |  |
| Inventories |  | $ | 1,436 |  |  | $ | 1,282 |  |

[0000858877-21-000004:mdna:40]
|  |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |
| Cash provided by operating activities |  | $ | 7,070 |  |  | $ | 7,387 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,601 |  |  | $ | 1,638 |  |
| Dividends paid |  | $ | 3,041 |  |  | $ | 2,972 |  |

[0000858877-21-000004:mdna:41]
[same as prior period, unchanged from 0000858877-20-000015:mdna:48]

[0000858877-21-000004:mdna:42]
[same as prior period, unchanged from 0000858877-20-000015:mdna:49]

[0000858877-21-000004:mdna:43]
[same as prior period, unchanged from 0000858877-20-000015:mdna:38]

[0000858877-21-000004:mdna:44]
[same as prior period, unchanged from 0000858877-20-000015:mdna:39]

[0000858877-21-000004:mdna:45]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the second quarter and first six months of fiscal 2021. These estimates are listed in our Annual Report on Form 10-K for the year ending July 25, 2020, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-21-000004:mdna:46]
[same as prior period, unchanged from 0000858877-20-000015:mdna:41]

[0000858877-21-000004:mdna:47]
[same as prior period, unchanged from 0000858877-20-000015:mdna:42]

[0000858877-21-000004:mdna:48]
[same as prior period, unchanged from 0000858877-20-000015:mdna:43]

[0000858877-21-000004:mdna:49]
[same as prior period, unchanged from 0000858877-20-000015:mdna:44]

[0000858877-21-000004:mdna:50]
[same as prior period, unchanged from 0000858877-20-000015:mdna:45]

[0000858877-21-000004:mdna:51]
[same as prior period, unchanged from 0000858877-20-000015:mdna:46]

[0000858877-21-000004:mdna:52]
[same as prior period, unchanged from 0000858877-20-000015:mdna:80]

[0000858877-21-000004:mdna:53]
[same as prior period, unchanged from 0000858877-20-000015:mdna:62]

[0000858877-21-000004:mdna:54]
[same as prior period, unchanged from 0000858877-20-000015:mdna:63]

[0000858877-21-000004:mdna:55]
Loss Contingencies

[0000858877-21-000004:mdna:56]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-21-000004:mdna:57]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-21-000004:mdna:58]
[same as prior period, unchanged from 0000858877-20-000015:mdna:53]

[0000858877-21-000004:mdna:59]
[same as prior period, unchanged from 0000858877-20-000015:mdna:54]

[0000858877-21-000004:mdna:60]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2021 and 2020.

[0000858877-21-000004:mdna:61]
[same as prior period, unchanged from 0000858877-20-000015:mdna:56]

[0000858877-21-000004:mdna:62]
[same as prior period, unchanged from 0000858877-20-000015:mdna:57]

[0000858877-21-000004:mdna:63]
[same as prior period, unchanged from 0000858877-20-000015:mdna:58]

[0000858877-21-000004:mdna:64]
[same as prior period, unchanged from 0000858877-20-000015:mdna:59]

[0000858877-21-000004:mdna:65]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 21.8% and 18.6% in the second quarter of fiscal 2021 and 2020, respectively, and 20.5% and 19.6% in the first six months of fiscal 2021 and 2020, respectively.

[0000858877-21-000004:mdna:66]
[same as prior period, unchanged from 0000858877-20-000015:mdna:61]

[0000858877-21-000004:mdna:67]
[same as prior period, unchanged from 0000858877-20-000015:mdna:68]

[0000858877-21-000004:mdna:68]
[same as prior period, unchanged from 0000858877-20-000015:mdna:69]

[0000858877-21-000004:mdna:69]
[same as prior period, unchanged from 0000858877-20-000015:mdna:64]

[0000858877-21-000004:mdna:70]
[same as prior period, unchanged from 0000858877-20-000015:mdna:65]

[0000858877-21-000004:mdna:71]
[same as prior period, unchanged from 0000858877-20-000015:mdna:66]

[0000858877-21-000004:mdna:72]
47

[0000858877-21-000004:mdna:73]
[same as prior period, unchanged from 0000858877-20-000015:mdna:81]

[0000858877-21-000004:mdna:74]
[same as prior period, unchanged from 0000858877-20-000015:mdna:82]

[0000858877-21-000004:mdna:75]
[same as prior period, unchanged from 0000858877-20-000015:mdna:70]

[0000858877-21-000004:mdna:76]
[same as prior period, unchanged from 0000858877-20-000015:mdna:71]

[0000858877-21-000004:mdna:77]
[same as prior period, unchanged from 0000858877-20-000015:mdna:72]

[0000858877-21-000004:mdna:78]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2021 |  | January 25, 2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,572 |  |  | $ | 8,671 |  |  | $ | (99) |  |  | (1) | % |  | $ | 17,159 |  |  | $ | 18,549 |  |  | $ | (1,390) |  |  | (7) | % |
| Percentage of revenue |  | 71.7 | % |  | 72.2 | % |  |  |  |  |  | 71.8 | % |  | 73.7 | % |  |  |  |  |
| Service |  | 3,388 |  |  | 3,334 |  |  | 54 |  |  | 2 | % |  | 6,730 |  |  | 6,615 |  |  | 115 |  |  | 2 | % |
| Percentage of revenue |  | 28.3 | % |  | 27.8 | % |  |  |  |  |  | 28.2 | % |  | 26.3 | % |  |  |  |  |
| Total |  | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | (45) |  |  | — | % |  | $ | 23,889 |  |  | $ | 25,164 |  |  | $ | (1,275) |  |  | (5) | % |

[0000858877-21-000004:mdna:79]
[same as prior period, unchanged from 0000858877-20-000015:mdna:74]

[0000858877-21-000004:mdna:80]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2021 |  | January 25, 2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,969 |  |  | $ | 7,013 |  |  | $ | (44) |  |  | (1) | % |  | $ | 14,168 |  |  | $ | 14,990 |  |  | $ | (822) |  |  | (5) | % |
| Percentage of revenue |  | 58.3 | % |  | 58.4 | % |  |  |  |  |  | 59.3 | % |  | 59.6 | % |  |  |  |  |
| EMEA |  | 3,207 |  |  | 3,134 |  |  | 73 |  |  | 2 | % |  | 6,171 |  |  | 6,417 |  |  | (246) |  |  | (4) | % |
| Percentage of revenue |  | 26.8 | % |  | 26.1 | % |  |  |  |  |  | 25.8 | % |  | 25.5 | % |  |  |  |  |
| APJC |  | 1,784 |  |  | 1,859 |  |  | (75) |  |  | (4) | % |  | 3,551 |  |  | 3,758 |  |  | (207) |  |  | (6) | % |
| Percentage of revenue |  | 14.9 | % |  | 15.5 | % |  |  |  |  |  | 14.9 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | (45) |  |  | — | % |  | $ | 23,889 |  |  | $ | 25,164 |  |  | $ | (1,275) |  |  | (5) | % |

[0000858877-21-000004:mdna:81]
[same as prior period, unchanged from 0000858877-20-000015:mdna:76]

[0000858877-21-000004:mdna:82]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:83]
Total revenue was flat. Product revenue decreased by 1% and service revenue increased by 2%. Our total revenue reflected declines in the Americas and APJC segments while revenue grew in the EMEA segment. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 13% product revenue decline, with decreases in each of these countries.

[0000858877-21-000004:mdna:84]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-21-000004:mdna:85]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:86]
Total revenue decreased by 5%. Product revenue decreased by 7% and service revenue increased by 2%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 21% product revenue decline, with decreases in each of these countries.

[0000858877-21-000004:mdna:87]
48

[0000858877-21-000004:mdna:88]
[same as prior period, unchanged from 0000858877-20-000015:mdna:99]

[0000858877-21-000004:mdna:89]
[same as prior period, unchanged from 0000858877-20-000015:mdna:100]

[0000858877-21-000004:mdna:90]
[same as prior period, unchanged from 0000858877-20-000015:mdna:83]

[0000858877-21-000004:mdna:91]
[same as prior period, unchanged from 0000858877-20-000015:mdna:84]

[0000858877-21-000004:mdna:92]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,888 |  |  | $ | 4,935 |  |  | $ | (47) |  |  | (1) | % |  | $ | 10,017 |  |  | $ | 10,842 |  |  | $ | (825) |  |  | (8) | % |
| Percentage of product revenue |  | 57.1 | % |  | 56.9 | % |  |  |  |  |  | 58.4 | % |  | 58.4 | % |  |  |  |  |
| EMEA |  | 2,438 |  |  | 2,393 |  |  | 45 |  |  | 2 | % |  | 4,648 |  |  | 4,951 |  |  | (303) |  |  | (6) | % |
| Percentage of product revenue |  | 28.4 | % |  | 27.6 | % |  |  |  |  |  | 27.1 | % |  | 26.7 | % |  |  |  |  |
| APJC |  | 1,246 |  |  | 1,343 |  |  | (97) |  |  | (7) | % |  | 2,494 |  |  | 2,757 |  |  | (263) |  |  | (10) | % |
| Percentage of product revenue |  | 14.5 | % |  | 15.5 | % |  |  |  |  |  | 14.5 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 8,572 |  |  | $ | 8,671 |  |  | $ | (99) |  |  | (1) | % |  | $ | 17,159 |  |  | $ | 18,549 |  |  | $ | (1,390) |  |  | (7) | % |

[0000858877-21-000004:mdna:93]
[same as prior period, unchanged from 0000858877-20-000015:mdna:86]

[0000858877-21-000004:mdna:94]
[same as prior period, unchanged from 0000858877-20-000015:mdna:88]

[0000858877-21-000004:mdna:95]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:96]
Product revenue in the Americas segment decreased by 1%. The product revenue decrease was driven by declines in the enterprise and service provider markets. These declines were offset by growth in the public sector and commercial markets. From a country perspective, product revenue decreased by 16% in Mexico and 14% in Brazil, partially offset by growth in product revenue in Canada of 6%. Product revenue in the United States was flat.

[0000858877-21-000004:mdna:97]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:98]
The decrease in product revenue in the Americas segment was driven by declines in the enterprise, commercial and service provider markets. The decreases were partially offset by product revenue growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada, Mexico and Brazil by 7%, 10%, 20% and 28%, respectively.

[0000858877-21-000004:mdna:99]
[same as prior period, unchanged from 0000858877-20-000015:mdna:90]

[0000858877-21-000004:mdna:100]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:101]
Product revenue in the EMEA segment increased by 2%, with growth in the service provider, public sector and enterprise markets partially offset by a decline in the commercial market. Product revenue from emerging countries within EMEA decreased by 13% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 7%. From a country perspective, product revenue increased by 18% in Germany and 6% in France, partially offset by a decline in product revenue of 7% in the United Kingdom.

[0000858877-21-000004:mdna:102]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:103]
Product revenue in the EMEA segment decreased by 6%, with declines in the commercial, enterprise and public sector markets partially offset by growth in the service provider market. Product revenue from emerging countries within EMEA decreased by 14% and product revenue for the remainder of the EMEA segment decreased by 3%. From a country perspective, product revenue declined 10% in the United Kingdom and 6% in France, partially offset by growth in product revenue of 6% in Germany.

[0000858877-21-000004:mdna:104]
[same as prior period, unchanged from 0000858877-20-000015:mdna:92]

[0000858877-21-000004:mdna:105]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:106]
Product revenue in the APJC segment decreased by 7%, driven by declines in the service provider, enterprise and commercial markets partially offset by growth in the public sector market. From a country perspective, product revenue decreased in Australia, India and China by 4%, 10%, and 9%, respectively, partially offset by a product revenue increase in Japan of 3%.

[0000858877-21-000004:mdna:107]
[same as prior period, unchanged from 0000858877-20-000015:mdna:113]

[0000858877-21-000004:mdna:108]
[same as prior period, unchanged from 0000858877-20-000015:mdna:114]

[0000858877-21-000004:mdna:109]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:110]
Product revenue in the APJC segment decreased by 10%, with declines across each of the customer markets in this geographic segment. From a country perspective, product revenue decreased in Australia, India and China by 10%, 24% and 19%, respectively, partially offset by a product revenue increase of 8% in Japan.

[0000858877-21-000004:mdna:111]
Product Revenue by Category

[0000858877-21-000004:mdna:112]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-21-000004:mdna:113]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-21-000004:mdna:114]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | (176) |  |  | (3) | % |  | $ | 12,732 |  |  | $ | 14,120 |  |  | $ | (1,388) |  |  | (10) | % |
| Applications |  | 1,354 |  |  | 1,349 |  |  | 5 |  |  | — | % |  | 2,734 |  |  | 2,847 |  |  | (113) |  |  | (4) | % |
| Security |  | 822 |  |  | 749 |  |  | 73 |  |  | 10 | % |  | 1,684 |  |  | 1,565 |  |  | 119 |  |  | 8 | % |
| Other Products |  | 4 |  |  | 7 |  |  | (3) |  |  | (39) | % |  | 9 |  |  | 17 |  |  | (8) |  |  | (49) | % |
| Total |  | $ | 8,572 |  |  | $ | 8,671 |  |  | $ | (99) |  |  | (1) | % |  | $ | 17,159 |  |  | $ | 18,549 |  |  | $ | (1,390) |  |  | (7) | % |

[0000858877-21-000004:mdna:115]
[same as prior period, unchanged from 0000858877-20-000015:mdna:98]

[0000858877-21-000004:mdna:116]
[same as prior period, unchanged from 0000858877-20-000015:mdna:102]

[0000858877-21-000004:mdna:117]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:118]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 3%, or $176 million. This was the product area most impacted by the COVID-19 pandemic environment. Switching revenue was flat. We experienced revenue growth in data center switching driven by increased revenue from our Nexus 9000 Series. This product revenue growth was partially offset by declines in campus switching, although we had revenue growth in our intent-based networking Catalyst 9000 Series. We experienced a decrease in sales of routing products, with declines primarily in the service provider market. We experienced revenue growth from wireless products driven by our WiFi6 products and Meraki offerings. Revenue from data center declined primarily driven by our servers products.

[0000858877-21-000004:mdna:119]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:120]
Revenue from the Infrastructure Platforms product category decreased 10%, or $1.4 billion, with declines across the portfolio with the exception of wireless. Switching revenue declined in both campus switching and data center switching, although we saw revenue growth in our intent-based networking Catalyst 9000 Series and Nexus 9000 Series. The decrease in routing was driven by continued weakness in the service provider and enterprise markets. Revenue from data center decreased driven primarily by our server products.

[0000858877-21-000004:mdna:121]
[same as prior period, unchanged from 0000858877-20-000015:mdna:104]

[0000858877-21-000004:mdna:122]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:123]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category was flat, driven by double digit growth in Webex partially offset by declines in Unified Communications and Cisco TelePresence.

[0000858877-21-000004:mdna:124]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:125]
Revenue in our Applications product category decreased by 4%, or $113 million, with declines in Unified Communications and Cisco Telepresence partially offset by double digit growth in Webex.

[0000858877-21-000004:mdna:126]
[same as prior period, unchanged from 0000858877-20-000015:mdna:128]

[0000858877-21-000004:mdna:127]
[same as prior period, unchanged from 0000858877-20-000015:mdna:129]

[0000858877-21-000004:mdna:128]
[same as prior period, unchanged from 0000858877-20-000015:mdna:106]

[0000858877-21-000004:mdna:129]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:130]
Revenue in our Security product category increased 10%, or $73 million with growth across the portfolio. Our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-21-000004:mdna:131]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:132]
Revenue in our Security product category increased by 8%, or $119 million, driven by growth in our cloud security portfolio reflecting growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-21-000004:mdna:133]
[same as prior period, unchanged from 0000858877-20-000015:mdna:108]

[0000858877-21-000004:mdna:134]
[same as prior period, unchanged from 0000858877-20-000015:mdna:109]

[0000858877-21-000004:mdna:135]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,081 |  |  | $ | 2,078 |  |  | $ | 3 |  |  | — | % |  | $ | 4,151 |  |  | $ | 4,148 |  |  | $ | 3 |  |  | — | % |
| Percentage of service revenue |  | 61.4 | % |  | 62.3 | % |  |  |  |  |  | 61.7 | % |  | 62.7 | % |  |  |  |  |
| EMEA |  | 769 |  |  | 741 |  |  | 28 |  |  | 4 | % |  | 1,523 |  |  | 1,466 |  |  | 57 |  |  | 4 | % |
| Percentage of service revenue |  | 22.7 | % |  | 22.2 | % |  |  |  |  |  | 22.6 | % |  | 22.2 | % |  |  |  |  |
| APJC |  | 538 |  |  | 515 |  |  | 23 |  |  | 4 | % |  | 1,057 |  |  | 1,001 |  |  | 56 |  |  | 6 | % |
| Percentage of service revenue |  | 15.9 | % |  | 15.5 | % |  |  |  |  |  | 15.7 | % |  | 15.1 | % |  |  |  |  |
| Total |  | $ | 3,388 |  |  | $ | 3,334 |  |  | $ | 54 |  |  | 2 | % |  | $ | 6,730 |  |  | $ | 6,615 |  |  | $ | 115 |  |  | 2 | % |

[0000858877-21-000004:mdna:136]
[same as prior period, unchanged from 0000858877-20-000015:mdna:111]

[0000858877-21-000004:mdna:137]
Service revenue increased 2% in each of the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020. The increases in both periods were driven by revenue growth in solution support offerings. Service revenue increased across all geographic segments.

[0000858877-21-000004:mdna:138]
[same as prior period, unchanged from 0000858877-20-000015:mdna:144]

[0000858877-21-000004:mdna:139]
[same as prior period, unchanged from 0000858877-20-000015:mdna:145]

[0000858877-21-000004:mdna:140]
[same as prior period, unchanged from 0000858877-20-000015:mdna:115]

[0000858877-21-000004:mdna:141]
[same as prior period, unchanged from 0000858877-20-000015:mdna:116]

[0000858877-21-000004:mdna:142]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,528 |  |  | $ | 5,545 |  |  | 64.5 | % |  | 63.9 | % |  | $ | 10,909 |  |  | $ | 11,899 |  |  | 63.6 | % |  | 64.1 | % |
| Service |  | 2,256 |  |  | 2,219 |  |  | 66.6 | % |  | 66.6 | % |  | 4,456 |  |  | 4,329 |  |  | 66.2 | % |  | 65.4 | % |
| Total |  | $ | 7,784 |  |  | $ | 7,764 |  |  | 65.1 | % |  | 64.7 | % |  | $ | 15,365 |  |  | $ | 16,228 |  |  | 64.3 | % |  | 64.5 | % |

[0000858877-21-000004:mdna:143]
[same as prior period, unchanged from 0000858877-20-000015:mdna:118]

[0000858877-21-000004:mdna:144]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2021, as compared with the corresponding prior year periods:

[0000858877-21-000004:mdna:145]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2020 |  | 63.9 | % |  | 64.1 | % |
| Productivity (1) |  | 0.6 | % |  | (0.1) | % |
| Product pricing |  | (1.6) | % |  | (1.6) | % |
| Mix of products sold |  | 1.7 | % |  | 1.6 | % |
| Legal and indemnification charge |  | — | % |  | (0.2) | % |
| Others |  | (0.1) | % |  | (0.2) | % |
| Fiscal 2021 |  | 64.5 | % |  | 63.6 | % |

[0000858877-21-000004:mdna:146]
[same as prior period, unchanged from 0000858877-20-000015:mdna:121]

[0000858877-21-000004:mdna:147]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:148]
Product gross margin increased by 0.6 percentage points driven by favorable product mix and productivity improvements, partially offset by pricing erosion.

[0000858877-21-000004:mdna:149]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued efficiency in manufacturing operations. In the second quarter of fiscal 2021, as a result of the COVID-19 pandemic, we continued to incur additional logistics costs, such as freight which had a negative impact on product gross margin. The pricing erosion was driven by typical market factors and impacted each of our geographic segments. The favorable mix was driven by changes in the proportion of products sold from each of our product categories as compared to the corresponding period of fiscal 2020.

[0000858877-21-000004:mdna:150]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:151]
Product gross margin decreased by 0.5 percentage points driven by pricing erosion and to a lesser extent, productivity, partially offset by favorable impacts from product mix. In the first six months of fiscal 2021, as a result of the COVID-19 pandemic, we incurred additional logistics costs, such as freight which had a negative impact on product gross margin.

[0000858877-21-000004:mdna:152]
[same as prior period, unchanged from 0000858877-20-000015:mdna:124]

[0000858877-21-000004:mdna:153]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:154]
Our service gross margin percentage was flat primarily due to higher sales volume and favorable mix of service offerings, partially offset by higher headcount-related and delivery costs.

[0000858877-21-000004:mdna:155]
[same as prior period, unchanged from 0000858877-20-000015:mdna:127]

[0000858877-21-000004:mdna:156]
[same as prior period, unchanged from 0000858877-20-000015:mdna:164]

[0000858877-21-000004:mdna:157]
[same as prior period, unchanged from 0000858877-20-000015:mdna:165]

[0000858877-21-000004:mdna:158]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:159]
Service gross margin percentage increased by 0.8 percentage points due to higher sales volume and favorable mix of service offerings, partially offset by increased headcount-related and delivery costs.

[0000858877-21-000004:mdna:160]
[same as prior period, unchanged from 0000858877-20-000015:mdna:130]

[0000858877-21-000004:mdna:161]
[same as prior period, unchanged from 0000858877-20-000015:mdna:131]

[0000858877-21-000004:mdna:162]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,705 |  |  | $ | 4,692 |  |  | 67.5 | % |  | 66.9 | % |  | $ | 9,552 |  |  | $ | 10,008 |  |  | 67.4 | % |  | 66.8 | % |
| EMEA | 2,145 |  |  | 2,062 |  |  | 66.9 | % |  | 65.8 | % |  | 4,038 |  |  | 4,229 |  |  | 65.4 | % |  | 65.9 | % |
| APJC | 1,155 |  |  | 1,219 |  |  | 64.8 | % |  | 65.6 | % |  | 2,268 |  |  | 2,413 |  |  | 63.9 | % |  | 64.2 | % |
| Segment total | 8,005 |  |  | 7,974 |  |  | 66.9 | % |  | 66.4 | % |  | 15,858 |  |  | 16,650 |  |  | 66.4 | % |  | 66.2 | % |
| Unallocated corporate items (1) | (221) |  |  | (210) |  |  |  |  |  |  | (493) |  |  | (422) |  |  |  |  |  |
| Total | $ | 7,784 |  |  | $ | 7,764 |  |  | 65.1 | % |  | 64.7 | % |  | $ | 15,365 |  |  | $ | 16,228 |  |  | 64.3 | % |  | 64.5 | % |

[0000858877-21-000004:mdna:163]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-21-000004:mdna:164]
[same as prior period, unchanged from 0000858877-20-000015:mdna:134]

[0000858877-21-000004:mdna:165]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:166]
We experienced a gross margin percentage increase in our Americas segment due to favorable impacts from product mix and productivity improvements, partially offset by pricing erosion.

[0000858877-21-000004:mdna:167]
Gross margin in our EMEA segment increased due favorable impacts from productivity improvements and product mix, partially offset by pricing erosion. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-21-000004:mdna:168]
The APJC segment gross margin percentage decrease was due to pricing erosion, partially offset by favorable impacts from product mix. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-21-000004:mdna:169]
[same as prior period, unchanged from 0000858877-20-000015:mdna:139]

[0000858877-21-000004:mdna:170]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:171]
The Americas segment had a gross margin percentage increase driven by favorable product mix, and to a lesser extent, productivity improvements, partially offset by pricing erosion.

[0000858877-21-000004:mdna:172]
The gross margin percentage decrease in our EMEA segment was due to pricing erosion, partially offset by favorable product mix and productivity improvements.

[0000858877-21-000004:mdna:173]
The APJC segment gross margin percentage decrease was driven by pricing erosion, partially offset by productivity improvements and favorable product mix.

[0000858877-21-000004:mdna:174]
[same as prior period, unchanged from 0000858877-20-000015:mdna:180]

[0000858877-21-000004:mdna:175]
[same as prior period, unchanged from 0000858877-20-000015:mdna:181]

[0000858877-21-000004:mdna:176]
[same as prior period, unchanged from 0000858877-20-000015:mdna:140]

[0000858877-21-000004:mdna:177]
[same as prior period, unchanged from 0000858877-20-000015:mdna:141]

[0000858877-21-000004:mdna:178]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,527 |  |  | $ | 1,570 |  |  | $ | (43) |  |  | (3) | % |  | $ | 3,139 |  |  | $ | 3,236 |  |  | $ | (97) |  |  | (3) | % |
| Percentage of revenue | 12.8 | % |  | 13.1 | % |  |  |  |  |  | 13.1 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing | 2,277 |  |  | 2,279 |  |  | (2) |  |  | — | % |  | 4,494 |  |  | 4,759 |  |  | (265) |  |  | (6) | % |
| Percentage of revenue | 19.0 | % |  | 19.0 | % |  |  |  |  |  | 18.8 | % |  | 18.9 | % |  |  |  |  |
| General and administrative | 484 |  |  | 455 |  |  | 29 |  |  | 6 | % |  | 1,028 |  |  | 974 |  |  | 54 |  |  | 6 | % |
| Percentage of revenue | 4.0 | % |  | 3.8 | % |  |  |  |  |  | 4.3 | % |  | 3.9 | % |  |  |  |  |
| Total | $ | 4,288 |  |  | $ | 4,304 |  |  | $ | (16) |  |  | — | % |  | $ | 8,661 |  |  | $ | 8,969 |  |  | $ | (308) |  |  | (3) | % |
| Percentage of revenue | 35.9 | % |  | 35.9 | % |  |  |  |  |  | 36.3 | % |  | 35.6 | % |  |  |  |  |

[0000858877-21-000004:mdna:179]
[same as prior period, unchanged from 0000858877-20-000015:mdna:147]

[0000858877-21-000004:mdna:180]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:181]
R&D expenses decreased due to lower headcount-related expenses, contracted services spending and discretionary spending.

[0000858877-21-000004:mdna:182]
[same as prior period, unchanged from 0000858877-20-000015:mdna:149]

[0000858877-21-000004:mdna:183]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:184]
R&D expenses decreased primarily due to lower discretionary spending and headcount-related expenses, partially offset by higher share-based compensation expense.

[0000858877-21-000004:mdna:185]
[same as prior period, unchanged from 0000858877-20-000015:mdna:150]

[0000858877-21-000004:mdna:186]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:187]
Sales and marketing expenses were flat due to higher headcount-related expenses and contracted services spending, partially offset by lower discretionary spending.

[0000858877-21-000004:mdna:188]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:189]
Sales and marketing expenses decreased primarily due to lower discretionary spending and lower acquisition-related costs partially offset by higher headcount-related expenses.

[0000858877-21-000004:mdna:190]
[same as prior period, unchanged from 0000858877-20-000015:mdna:152]

[0000858877-21-000004:mdna:191]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:192]
G&A expenses increased due to the impact from the gain recognized on the sale of property that had been held for sale in the second quarter of fiscal 2020, partially offset by lower contracted services spending, lower headcount-related expenses and lower discretionary spending.

[0000858877-21-000004:mdna:193]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:194]
G&A expenses increased due to the impact from the gain recognized on the sale of property that had been held for sale in the second quarter of fiscal 2020, partially offset by lower acquisition-related costs and lower discretionary spending.

[0000858877-21-000004:mdna:195]
[same as prior period, unchanged from 0000858877-20-000015:mdna:154]

[0000858877-21-000004:mdna:196]
In the second quarter of fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $29 million, or 0.7%, compared with the second quarter of fiscal 2020.

[0000858877-21-000004:mdna:197]
In the first six months of fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $43 million or 0.5%, compared with the first six months of fiscal 2020.

[0000858877-21-000004:mdna:198]
54

[0000858877-21-000004:mdna:199]
[same as prior period, unchanged from 0000858877-20-000015:mdna:186]

[0000858877-21-000004:mdna:200]
[same as prior period, unchanged from 0000858877-20-000015:mdna:187]

[0000858877-21-000004:mdna:201]
[same as prior period, unchanged from 0000858877-20-000015:mdna:156]

[0000858877-21-000004:mdna:202]
[same as prior period, unchanged from 0000858877-20-000015:mdna:157]

[0000858877-21-000004:mdna:203]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 156 |  |  | $ | 165 |  |  | $ | 326 |  |  | $ | 331 |  |
| Operating expenses |  | 39 |  |  | 38 |  |  | 75 |  |  | 74 |  |
| Total |  | $ | 195 |  |  | $ | 203 |  |  | $ | 401 |  |  | $ | 405 |  |

[0000858877-21-000004:mdna:204]
For each of the second quarter and first six months of fiscal 2021, the decrease was primarily due to lower amortization of purchased intangibles from our recent acquisitions.

[0000858877-21-000004:mdna:205]
[same as prior period, unchanged from 0000858877-20-000015:mdna:161]

[0000858877-21-000004:mdna:206]
In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with this restructuring plan, we incurred charges of $232 million and $834 million for the second quarter and first six months of fiscal 2021. We expect the plan to be substantially completed in fiscal 2021 and estimate it will generate cost savings of approximately $1.0 billion on an annualized basis over the next few quarters.

[0000858877-21-000004:mdna:207]
We initiated a restructuring plan during fiscal 2020 in order to realign the organization and enable further investment in key priority areas. In connection with this restructuring plan, we have incurred cumulative charges of $257 million. We expect this restructuring plan to be substantially completed in fiscal 2021.

[0000858877-21-000004:mdna:208]
[same as prior period, unchanged from 0000858877-20-000015:mdna:166]

[0000858877-21-000004:mdna:209]
[same as prior period, unchanged from 0000858877-20-000015:mdna:167]

[0000858877-21-000004:mdna:210]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Operating income |  | $ | 3,223 |  |  | $ | 3,380 |  |  | $ | 5,793 |  |  | $ | 6,959 |  |
| Operating income as a percentage of revenue |  | 26.9 | % |  | 28.2 | % |  | 24.2 | % |  | 27.7 | % |

[0000858877-21-000004:mdna:211]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:212]
Operating income decreased by 5%, and as a percentage of revenue operating income decreased by 1.3 percentage points. These changes resulted primarily from higher restructuring and other charges, partially offset by a gross margin percentage increase (driven by favorable product mix and productivity improvements, partially offset by pricing erosion).

[0000858877-21-000004:mdna:213]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:214]
Operating income decreased by 17%, and as a percentage of revenue operating income decreased by 3.5 percentage points. These changes resulted primarily from a revenue decrease, higher restructuring and other charges and a gross margin percentage decrease (driven by pricing erosion).

[0000858877-21-000004:mdna:215]
[same as prior period, unchanged from 0000858877-20-000015:mdna:201]

[0000858877-21-000004:mdna:216]
[same as prior period, unchanged from 0000858877-20-000015:mdna:202]

[0000858877-21-000004:mdna:217]
[same as prior period, unchanged from 0000858877-20-000015:mdna:171]

[0000858877-21-000004:mdna:218]
[same as prior period, unchanged from 0000858877-20-000015:mdna:172]

[0000858877-21-000004:mdna:219]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |
| Interest income |  | $ | 161 |  |  | $ | 242 |  |  | $ | (81) |  |  | $ | 335 |  |  | $ | 515 |  |  | $ | (180) |  |
| Interest expense |  | (113) |  |  | (158) |  |  | 45 |  |  | (225) |  |  | (336) |  |  | 111 |  |
| Interest income (expense), net |  | $ | 48 |  |  | $ | 84 |  |  | $ | (36) |  |  | $ | 110 |  |  | $ | 179 |  |  | $ | (69) |  |

[0000858877-21-000004:mdna:220]
For each of the second quarter and first six months of fiscal 2021, interest income decreased driven by lower yields on our portfolio. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-21-000004:mdna:221]
[same as prior period, unchanged from 0000858877-20-000015:mdna:176]

[0000858877-21-000004:mdna:222]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |  | January 23,2021 |  | January 25,2020 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 9 |  |  | $ | 11 |  |  | $ | (2) |  |  | $ | 24 |  |  | $ | 21 |  |  | $ | 3 |  |
| Marketable equity investments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Non-marketable equity and other investments |  | (17) |  |  | 81 |  |  | (98) |  |  | 25 |  |  | 91 |  |  | (66) |  |
| Net gains (losses) on investments |  | (8) |  |  | 92 |  |  | (100) |  |  | 48 |  |  | 112 |  |  | (64) |  |
| Other gains (losses), net |  | (8) |  |  | (22) |  |  | 14 |  |  | (15) |  |  | (30) |  |  | 15 |  |
| Other income (loss), net |  | $ | (16) |  |  | $ | 70 |  |  | $ | (86) |  |  | $ | 33 |  |  | $ | 82 |  |  | $ | (49) |  |

[0000858877-21-000004:mdna:223]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:224]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net realized losses, offset by higher net unrealized gains, and lower impairment charges. The change in other gains (losses), net was driven by impacts from foreign exchange and our equity derivatives.

[0000858877-21-000004:mdna:225]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:226]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net realized losses, offset by higher net unrealized gains and lower impairment charges. The change in other gains (losses), net was primarily driven by the impacts from foreign exchange and our equity derivatives.

[0000858877-21-000004:mdna:227]
[same as prior period, unchanged from 0000858877-20-000015:mdna:182]

[0000858877-21-000004:mdna:228]
Three Months Ended January 23, 2021 Compared with Three Months Ended January 25, 2020

[0000858877-21-000004:mdna:229]
The provision for income taxes resulted in an effective tax rate of 21.8% for the second quarter of fiscal 2021 compared with 18.6% for the second quarter of fiscal 2020. The increase in the effective tax rate was primarily due to a foreign tax audit settlement expense and a decrease in excess tax benefits from share-based compensation in the second quarter of fiscal 2021 as compared to the second quarter of fiscal 2020.

[0000858877-21-000004:mdna:230]
[same as prior period, unchanged from 0000858877-20-000015:mdna:185]

[0000858877-21-000004:mdna:231]
Six Months Ended January 23, 2021 Compared with Six Months Ended January 25, 2020

[0000858877-21-000004:mdna:232]
The provision for income taxes resulted in an effective tax rate of 20.5% for the first six months of fiscal 2021 compared with 19.6% for the first six months of fiscal 2020. The increase in effective tax rate was primarily due to a decrease in excess tax benefits from share-based compensation in fiscal 2021 as compared to fiscal 2020.

[0000858877-21-000004:mdna:233]
[same as prior period, unchanged from 0000858877-20-000015:mdna:234]

[0000858877-21-000004:mdna:234]
[same as prior period, unchanged from 0000858877-20-000015:mdna:215]

[0000858877-21-000004:mdna:235]
[same as prior period, unchanged from 0000858877-20-000015:mdna:216]

[0000858877-21-000004:mdna:236]
[same as prior period, unchanged from 0000858877-20-000015:mdna:188]

[0000858877-21-000004:mdna:237]
[same as prior period, unchanged from 0000858877-20-000015:mdna:189]

[0000858877-21-000004:mdna:238]
[same as prior period, unchanged from 0000858877-20-000015:mdna:190]

[0000858877-21-000004:mdna:239]
[same as prior period, unchanged from 0000858877-20-000015:mdna:191]

[0000858877-21-000004:mdna:240]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 11,793 |  |  | $ | 11,809 |  |  | $ | (16) |  |
| Available-for-sale debt investments | 18,790 |  |  | 17,610 |  |  | 1,180 |  |
| Marketable equity securities | 5 |  |  | — |  |  | 5 |  |
| Total | $ | 30,588 |  |  | $ | 29,419 |  |  | $ | 1,169 |  |

[0000858877-21-000004:mdna:241]
The net increase in cash and cash equivalents and investments in the first six months of fiscal 2021 was primarily driven by cash provided by operating activities of $7.1 billion. This source of cash was partially offset by cash returned to shareholders in the form of repurchases of common stock of $1.6 billion and cash dividends of $3.0 billion; net cash paid for acquisitions and divestitures of $0.9 billion and capital expenditures of $0.4 billion.

[0000858877-21-000004:mdna:242]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia. On January 14, 2021, we announced an amendment to the definitive merger agreement. Under the amended agreement, we have agreed to acquire Acacia for a net purchase consideration of approximately $4.5 billion on a fully diluted basis, net of cash and marketable securities. Additionally, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Also, $5.0 billion of long-term debt outstanding at January 23, 2021 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-21-000004:mdna:243]
[same as prior period, unchanged from 0000858877-20-000015:mdna:195]

[0000858877-21-000004:mdna:244]
[same as prior period, unchanged from 0000858877-20-000015:mdna:196]

[0000858877-21-000004:mdna:245]
[same as prior period, unchanged from 0000858877-20-000015:mdna:197]

[0000858877-21-000004:mdna:246]
[same as prior period, unchanged from 0000858877-20-000015:mdna:198]

[0000858877-21-000004:mdna:247]
|  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |
| Net cash provided by operating activities | $ | 7,070 |  |  | $ | 7,387 |  |
| Acquisition of property and equipment | (358) |  |  | (391) |  |
| Free cash flow | $ | 6,712 |  |  | $ | 6,996 |  |

[0000858877-21-000004:mdna:248]
57

[0000858877-21-000004:mdna:249]
[same as prior period, unchanged from 0000858877-20-000015:mdna:224]

[0000858877-21-000004:mdna:250]
[same as prior period, unchanged from 0000858877-20-000015:mdna:225]

[0000858877-21-000004:mdna:251]
[same as prior period, unchanged from 0000858877-20-000015:mdna:200]

[0000858877-21-000004:mdna:252]
[same as prior period, unchanged from 0000858877-20-000015:mdna:203]

[0000858877-21-000004:mdna:253]
[same as prior period, unchanged from 0000858877-20-000015:mdna:204]

[0000858877-21-000004:mdna:254]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0000858877-21-000004:mdna:255]
On February 9, 2021, our Board of Directors declared a quarterly dividend of $0.37 per common share to be paid on April 28, 2021 to all stockholders of record as of the close of business on April 6, 2021. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-21-000004:mdna:256]
The remaining authorized amount for stock repurchases under this program is approximately $9.2 billion, with no termination date.

[0000858877-21-000004:mdna:257]
[same as prior period, unchanged from 0000858877-20-000015:mdna:208]

[0000858877-21-000004:mdna:258]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,307 |  |  | $ | 5,472 |  |  | $ | (1,165) |  |

[0000858877-21-000004:mdna:259]
Our accounts receivable net, as of January 23, 2021 decreased by approximately 21%, as compared with the end of fiscal 2020, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2021 compared with the fourth quarter of fiscal 2020.

[0000858877-21-000004:mdna:260]
[same as prior period, unchanged from 0000858877-20-000015:mdna:211]

[0000858877-21-000004:mdna:261]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Inventories | $ | 1,436 |  |  | $ | 1,282 |  |  | $ | 154 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,588 |  |  | $ | 4,406 |  |  | $ | 182 |  |

[0000858877-21-000004:mdna:262]
Inventory as of January 23, 2021 increased by 12% from our inventory balance at the end of fiscal 2020. The increase in inventory was primarily due to an increase in raw materials and finished goods. Purchase commitments with contract

[0000858877-21-000004:mdna:263]
[same as prior period, unchanged from 0000858877-20-000015:mdna:235]

[0000858877-21-000004:mdna:264]
[same as prior period, unchanged from 0000858877-20-000015:mdna:236]

[0000858877-21-000004:mdna:265]
manufacturers and suppliers increased 4% compared to the end of fiscal 2020. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased 6% compared with the end of fiscal 2020. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-21-000004:mdna:266]
[same as prior period, unchanged from 0000858877-20-000015:mdna:214]

[0000858877-21-000004:mdna:267]
[same as prior period, unchanged from 0000858877-20-000015:mdna:217]

[0000858877-21-000004:mdna:268]
[same as prior period, unchanged from 0000858877-20-000015:mdna:218]

[0000858877-21-000004:mdna:269]
[same as prior period, unchanged from 0000858877-20-000015:mdna:219]

[0000858877-21-000004:mdna:270]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,840 |  |  | $ | 2,088 |  |  | $ | (248) |  |
| Loan receivables, net | 5,721 |  |  | 5,856 |  |  | (135) |  |
| Financed service contracts, net | 2,566 |  |  | 2,821 |  |  | (255) |  |
| Total, net | $ | 10,127 |  |  | $ | 10,765 |  |  | $ | (638) |  |

[0000858877-21-000004:mdna:271]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 6%.

[0000858877-21-000004:mdna:272]
[same as prior period, unchanged from 0000858877-20-000015:mdna:222]

[0000858877-21-000004:mdna:273]
The volume of channel partner financing was $12.8 billion and $14.2 billion for the first six months of fiscal 2021 and 2020, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of January 23, 2021 and July 25, 2020, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 23, 2021, the total maximum potential future payments related to these guarantees was approximately $213 million, of which approximately $27 million was recorded as deferred revenue.

[0000858877-21-000004:mdna:274]
[same as prior period, unchanged from 0000858877-20-000015:mdna:254]

[0000858877-21-000004:mdna:275]
[same as prior period, unchanged from 0000858877-20-000015:mdna:255]

[0000858877-21-000004:mdna:276]
[same as prior period, unchanged from 0000858877-20-000015:mdna:226]

[0000858877-21-000004:mdna:277]
[same as prior period, unchanged from 0000858877-20-000015:mdna:227]

[0000858877-21-000004:mdna:278]
|  | Maturity Date |  | January 23,2021 |  | July 25,2020 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | $ | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 14,500 |  |  | $ | 14,500 |  |

[0000858877-21-000004:mdna:279]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 23, 2021.

[0000858877-21-000004:mdna:280]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of January 23, 2021 and July 25, 2020.

[0000858877-21-000004:mdna:281]
Credit Facility  On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. On January 25, 2021, we entered into an amendment to the credit facility to obtain consent of the lenders to our reincorporation to Delaware. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of January 23, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-21-000004:mdna:282]
[same as prior period, unchanged from 0000858877-20-000015:mdna:232]

[0000858877-21-000004:mdna:283]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 8,332 |  |  | $ | 7,895 |  |  | $ | 437 |  |
| Service | 12,514 |  |  | 12,551 |  |  | (37) |  |
| Total | $ | 20,846 |  |  | $ | 20,446 |  |  | $ | 400 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,552 |  |  | $ | 11,406 |  |  | $ | 146 |  |
| Noncurrent | 9,294 |  |  | 9,040 |  |  | 254 |  |
| Total | $ | 20,846 |  |  | $ | 20,446 |  |  | $ | 400 |  |

[0000858877-21-000004:mdna:284]
CISCO SYSTEMS, INC.

[0000858877-21-000004:mdna:285]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-21-000004:mdna:286]
Deferred product revenue increased primarily due to increased deferrals related to our recurring software offerings. The slight decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-21-000004:mdna:287]
[same as prior period, unchanged from 0000858877-20-000015:mdna:238]

[0000858877-21-000004:mdna:288]
|  | January 23,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 11,666 |  |  | $ | 11,261 |  |  | $ | 405 |  |
| Service | 16,512 |  |  | 17,093 |  |  | (581) |  |
| Total | $ | 28,178 |  |  | $ | 28,354 |  |  | $ | (176) |  |

[0000858877-21-000004:mdna:289]
Total remaining performance obligations decreased 1% in the first six months of fiscal 2021 compared to the end of fiscal 2020. Remaining performance obligations for product increased 4% compared to the end of fiscal 2020. Remaining performance obligations for service decreased 3%.

[0000858877-21-000004:mdna:290]
[same as prior period, unchanged from 0000858877-20-000015:mdna:241]

[0000858877-21-000004:mdna:291]
[same as prior period, unchanged from 0000858877-20-000015:mdna:242]

[0000858877-21-000004:mdna:292]
The income tax payable outstanding as of January 23, 2021 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.9 billion. Approximately $0.7 billion is payable in less than one year; $2.1 billion is payable between 1 to 3 years; and $4.1 billion is payable between 3 to 5 years.

[0000858877-21-000004:mdna:293]
[same as prior period, unchanged from 0000858877-20-000015:mdna:244]

[0000858877-21-000004:mdna:294]
[same as prior period, unchanged from 0000858877-20-000015:mdna:245]

[0000858877-21-000004:mdna:295]
[same as prior period, unchanged from 0000858877-20-000015:mdna:246]

[0000858877-21-000004:mdna:296]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of January 23, 2021 and July 25, 2020.

[0000858877-21-000004:mdna:297]
[same as prior period, unchanged from 0000858877-20-000015:mdna:248]

[0000858877-21-000004:mdna:298]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of January 23, 2021 there were no material unconsolidated variable interest entities.

[0000858877-21-000004:mdna:299]
[same as prior period, unchanged from 0000858877-20-000015:mdna:250]

[0000858877-21-000004:mdna:300]
[same as prior period, unchanged from 0000858877-20-000015:mdna:251]

[0000858877-21-000004:mdna:301]
[same as prior period, unchanged from 0000858877-20-000015:mdna:252]

[0000858877-21-000004:mdna:302]
[same as prior period, unchanged from 0000858877-20-000015:mdna:253]

[0000858877-21-000004:mdna:303]
CISCO SYSTEMS, INC.

[0000858877-21-000004:mdna:304]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-21-000004:mdna:305]
[same as prior period, unchanged from 0000858877-20-000015:mdna:256]

[0000858877-21-000004:mdna:306]
62
