# CSCO notes — 0000858877-21-000004


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-21-000004:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 is a 53-week fiscal year and fiscal 2020 was a 52-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-21-000004:notes:2]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing the state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

[0000858877-21-000004:notes:3]
We have prepared the accompanying financial data as of January 23, 2021 and for the second quarter and first six months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

[0000858877-21-000004:notes:4]
[same as prior period, unchanged from 0000858877-20-000015:notes:3]

[0000858877-21-000004:notes:5]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2021 and 2020, and the statements of cash flows for the first six months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-21-000004:notes:6]
[same as prior period, unchanged from 0000858877-20-000015:notes:5]

[0000858877-21-000004:notes:7]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-21-000004:notes:8]
[same as prior period, unchanged from 0000858877-20-000015:notes:7]

[0000858877-21-000004:notes:9]
[same as prior period, unchanged from 0000858877-20-000015:notes:8]

[0000858877-21-000004:notes:10]
[same as prior period, unchanged from 0000858877-20-000015:notes:9]

[0000858877-21-000004:notes:11]
[same as prior period, unchanged from 0000858877-20-000015:notes:10]

[0000858877-21-000004:notes:12]
[same as prior period, unchanged from 0000858877-20-000015:notes:11]

[0000858877-21-000004:notes:13]
[same as prior period, unchanged from 0000858877-20-000015:notes:12]

[0000858877-21-000004:notes:14]
[same as prior period, unchanged from 0000858877-20-000015:notes:13]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-21-000004:notes:15]
[same as prior period, unchanged from 0000858877-20-000015:notes:14]

[0000858877-21-000004:notes:16]
[same as prior period, unchanged from 0000858877-20-000015:notes:15]

[0000858877-21-000004:notes:17]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 23, 2021 and July 25, 2020 was $73 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-21-000004:notes:18]
[same as prior period, unchanged from 0000858877-20-000015:notes:17]

[0000858877-21-000004:notes:19]
[same as prior period, unchanged from 0000858877-20-000015:notes:18]

[0000858877-21-000004:notes:20]
[same as prior period, unchanged from 0000858877-20-000015:notes:19]

[0000858877-21-000004:notes:21]
[same as prior period, unchanged from 0000858877-20-000015:notes:20]

[0000858877-21-000004:notes:22]
[same as prior period, unchanged from 0000858877-20-000015:notes:21]

[0000858877-21-000004:notes:23]
[same as prior period, unchanged from 0000858877-20-000015:notes:22]

[0000858877-21-000004:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

[0000858877-21-000004:notes:25]
[same as prior period, unchanged from 0000858877-20-000015:notes:24]

[0000858877-21-000004:notes:26]
[same as prior period, unchanged from 0000858877-20-000015:notes:25]

[0000858877-21-000004:notes:27]
[same as prior period, unchanged from 0000858877-20-000015:notes:26]

[0000858877-21-000004:notes:28]
[same as prior period, unchanged from 0000858877-20-000015:notes:27]

[0000858877-21-000004:notes:29]
[same as prior period, unchanged from 0000858877-20-000015:notes:28]

[0000858877-21-000004:notes:30]
[same as prior period, unchanged from 0000858877-20-000015:notes:29]

[0000858877-21-000004:notes:31]
[same as prior period, unchanged from 0000858877-20-000015:notes:30]

[0000858877-21-000004:notes:32]
[same as prior period, unchanged from 0000858877-20-000015:notes:31]

[0000858877-21-000004:notes:33]
[same as prior period, unchanged from 0000858877-20-000015:notes:32]

[0000858877-21-000004:notes:34]
Accounts receivable, net was $4.3 billion as of January 23, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.

[0000858877-21-000004:notes:35]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.

[0000858877-21-000004:notes:36]
[same as prior period, unchanged from 0000858877-20-000015:notes:35]

[0000858877-21-000004:notes:37]
|  | January 23,2021 |
| 1 to 4 | $ | 426 |  |
| 5 to 6 | 783 |  |
| 7 and Higher | 98 |  |
| Total | $ | 1,307 |  |

[0000858877-21-000004:notes:38]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.8 billion as of January 23, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.0 billion and $6.9 billion of revenue during the second quarter and first six months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.

[0000858877-21-000004:notes:39]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $817 million and $732 million as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $129 million and $252 million for the second quarter and first six months of fiscal 2021, respectively, and $122 million and $238 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-21-000004:notes:40]
[same as prior period, unchanged from 0000858877-20-000015:notes:39]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-21-000004:notes:41]
[same as prior period, unchanged from 0000858877-20-000015:notes:40]

[0000858877-21-000004:notes:42]
[same as prior period, unchanged from 0000858877-20-000015:notes:41]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-21-000004:notes:43]
Acquisitions and Divestitures
We completed five acquisitions during the first six months of fiscal 2021. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-21-000004:notes:44]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (five in total) | $ | 958 |  |  | $ | 2 |  |  | $ | 228 |  |  | $ | 728 |  |

[0000858877-21-000004:notes:45]
The total purchase consideration related to our acquisitions completed during the first six months of fiscal 2021 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $35 million. Total transaction costs related to acquisition and divestiture activities were $10 million and $9 million for the first six months of fiscal 2021 and 2020, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-21-000004:notes:46]
The goodwill generated from acquisitions completed during the first six months of fiscal 2021 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-21-000004:notes:47]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2021 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-21-000004:notes:48]
[same as prior period, unchanged from 0000858877-20-000015:notes:47]

[0000858877-21-000004:notes:49]
On January 14, 2021, Cisco and Acacia announced an amendment to the definitive merger agreement under which we had previously agreed to acquire Acacia. Under the terms of the amended agreement, we have agreed to acquire Acacia for $115 per share in cash, or approximately $4.5 billion on a fully diluted basis, net of cash and marketable securities. The acquisition is expected to close during the third quarter of fiscal 2021, subject to customary closing conditions, including Acacia stockholder approval. All required regulatory approvals have been received. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-21-000004:notes:50]
[same as prior period, unchanged from 0000858877-20-000015:notes:49]

[0000858877-21-000004:notes:51]
The following table presents the goodwill allocated to our reportable segments as of January 23, 2021 and during the first six months of fiscal 2021 (in millions):

[0000858877-21-000004:notes:52]
|  | Balance at July 25, 2020 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at January 23, 2021 |
| Americas | $ | 21,304 |  |  | $ | 415 |  |  | $ | 135 |  |  | $ | 21,854 |  |
| EMEA | 8,040 |  |  | 198 |  |  | 51 |  |  | 8,289 |  |
| APJC | 4,462 |  |  | 100 |  |  | 28 |  |  | 4,590 |  |
| Total | $ | 33,806 |  |  | $ | 713 |  |  | $ | 214 |  |  | $ | 34,733 |  |

[0000858877-21-000004:notes:53]
[same as prior period, unchanged from 0000858877-20-000015:notes:52]

[0000858877-21-000004:notes:54]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2021 (in millions, except years):

[0000858877-21-000004:notes:55]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (five in total) | 3.8 |  | $ | 179 |  |  | 4.0 |  | $ | 43 |  |  | 2.0 |  | $ | 6 |  |  | — |  |  | $ | 228 |  |

[0000858877-21-000004:notes:56]
[same as prior period, unchanged from 0000858877-20-000015:notes:55]

[0000858877-21-000004:notes:57]
| January 23, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,625 |  |  | $ | (1,700) |  |  | $ | 925 |  |
| Customer relationships |  | 773 |  |  | (404) |  |  | 369 |  |
| Other |  | 13 |  |  | (5) |  |  | 8 |  |
| Total purchased intangible assets with finite lives |  | 3,411 |  |  | (2,109) |  |  | 1,302 |  |
| In-process research and development, with indefinite lives |  | 160 |  |  | — |  |  | 160 |  |
| Total |  | $ | 3,571 |  |  | $ | (2,109) |  |  | $ | 1,462 |  |

[0000858877-21-000004:notes:58]
[same as prior period, unchanged from 0000858877-20-000015:notes:57]

[0000858877-21-000004:notes:59]
[same as prior period, unchanged from 0000858877-20-000015:notes:58]

[0000858877-21-000004:notes:60]
[same as prior period, unchanged from 0000858877-20-000015:notes:59]

[0000858877-21-000004:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 156 |  |  | $ | 165 |  |  | $ | 326 |  |  | $ | 331 |  |
| Operating expenses | 39 |  |  | 38 |  |  | 75 |  |  | 74 |  |
| Total | $ | 195 |  |  | $ | 203 |  |  | $ | 401 |  |  | $ | 405 |  |

[0000858877-21-000004:notes:62]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 23, 2021 is as follows (in millions):

[0000858877-21-000004:notes:63]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 311 |  |
| 2022 | $ | 453 |  |
| 2023 | $ | 308 |  |
| 2024 | $ | 188 |  |
| 2025 | $ | 31 |  |
| Thereafter | $ | 11 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-21-000004:notes:64]
Restructuring and Other Charges
We initiated a restructuring plan in the first quarter of fiscal 2021 (the “Fiscal 2021 Plan”), which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we incurred charges of $232 million and $834 million for the second quarter and first six months of fiscal 2021, respectively.

[0000858877-21-000004:notes:65]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. In connection with the Fiscal 2020 Plan, we have incurred cumulative charges of $257 million.

[0000858877-21-000004:notes:66]
[same as prior period, unchanged from 0000858877-20-000015:notes:65]

[0000858877-21-000004:notes:67]
[same as prior period, unchanged from 0000858877-20-000015:notes:66]

[0000858877-21-000004:notes:68]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | 2 |  |  | 804 |  |  | 30 |  |  | 836 |  |
| Cash payments |  | (58) |  |  | (3) |  |  | (703) |  |  | (3) |  |  | (767) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (21) |  |  | (21) |  |
| Liability as of January 23, 2021 |  | $ | — |  |  | $ | 13 |  |  | $ | 101 |  |  | $ | 6 |  |  | $ | 120 |  |

[0000858877-21-000004:notes:69]
|  |  | FISCAL 2018 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | 22 |  |  | $ | 11 |  |  | $ | 33 |  |
| Charges |  | 209 |  |  | 17 |  |  | 226 |  |
| Cash payments |  | (202) |  |  | (1) |  |  | (203) |  |
| Non-cash items |  | — |  |  | (23) |  |  | (23) |  |
| Liability as of January 25, 2020 |  | $ | 29 |  |  | $ | 4 |  |  | $ | 33 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-21-000004:notes:70]
[same as prior period, unchanged from 0000858877-20-000015:notes:69]

[0000858877-21-000004:notes:71]
|  |  | January 23,2021 |  | July 25,2020 |
| Cash and cash equivalents |  | $ | 11,793 |  |  | $ | 11,809 |  |
| Restricted cash included in other current assets |  | 7 |  |  | — |  |
| Restricted cash included in other assets |  | 3 |  |  | 3 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 11,803 |  |  | $ | 11,812 |  |

[0000858877-21-000004:notes:72]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 527 |  |  | $ | 456 |  |
| Work in process |  | 30 |  |  | 25 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 74 |  |  | 59 |  |
| Manufactured finished goods |  | 600 |  |  | 542 |  |
| Total finished goods |  | 674 |  |  | 601 |  |
| Service-related spares |  | 191 |  |  | 184 |  |
| Demonstration systems |  | 14 |  |  | 16 |  |
| Total |  | $ | 1,436 |  |  | $ | 1,282 |  |

[0000858877-21-000004:notes:73]
Our provision for inventory was $65 million and $30 million for the first six months of fiscal 2021 and 2020, respectively.

[0000858877-21-000004:notes:74]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,291 |  |  | $ | 4,252 |  |
| Computer equipment and related software |  | 864 |  |  | 875 |  |
| Production, engineering, and other equipment |  | 5,193 |  |  | 5,163 |  |
| Operating lease assets |  | 343 |  |  | 337 |  |
| Furniture, fixtures and other |  | 375 |  |  | 387 |  |
| Total gross property and equipment |  | 11,066 |  |  | 11,014 |  |
| Less: accumulated depreciation and amortization |  | (8,680) |  |  | (8,561) |  |
| Total |  | $ | 2,386 |  |  | $ | 2,453 |  |

[0000858877-21-000004:notes:75]
| Deferred revenue: |  |  |  |  |
| Product |  | $ | 8,332 |  |  | $ | 7,895 |  |
| Service |  | 12,514 |  |  | 12,551 |  |
| Total |  | $ | 20,846 |  |  | $ | 20,446 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,552 |  |  | $ | 11,406 |  |
| Noncurrent |  | 9,294 |  |  | 9,040 |  |
| Total |  | $ | 20,846 |  |  | $ | 20,446 |  |

[0000858877-21-000004:notes:76]
| Remaining Performance Obligations: |  |  |  |  |
| Product |  | $ | 11,666 |  |  | $ | 11,261 |  |
| Service |  | 16,512 |  |  | 17,093 |  |
| Total |  | $ | 28,178 |  |  | $ | 28,354 |  |

[0000858877-21-000004:notes:77]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 23, 2021, the aggregate amount of RPO was comprised of $20.8 billion of deferred revenue and $7.3 billion of unbilled contract revenue. We expect approximately 54% of this amount of be recognized as revenue over the next 12 months. As of July 25, 2020, the aggregate amount of RPO was comprised of $20.4 billion of deferred revenue and $7.9 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-21-000004:notes:78]
Leases 
(a)Lessee Arrangements

[0000858877-21-000004:notes:79]
The following table presents our operating lease balances (in millions):

[0000858877-21-000004:notes:80]
|  | Balance Sheet Line Item |  | January 23, 2021 |  | July 25, 2020 |
| Operating lease right-of-use assets | Other assets |  | $ | 974 |  |  | $ | 921 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 366 |  |  | $ | 341 |  |
| Operating lease liabilities | Other long-term liabilities |  | 688 |  |  | 661 |  |
| Total operating lease liabilities |  |  | $ | 1,054 |  |  | $ | 1,002 |  |

[0000858877-21-000004:notes:81]
The components of our lease expenses were as follows (in millions):

[0000858877-21-000004:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Operating lease expense | $ | 103 |  |  | $ | 101 |  |  | $ | 201 |  |  | $ | 214 |  |
| Short-term lease expense | 17 |  |  | 16 |  |  | 35 |  |  | 33 |  |
| Variable lease expense | 43 |  |  | 39 |  |  | 89 |  |  | 79 |  |
| Total lease expense | $ | 163 |  |  | $ | 156 |  |  | $ | 325 |  |  | $ | 326 |  |

[0000858877-21-000004:notes:83]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-21-000004:notes:84]
|  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 201 |  |  | $ | 206 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 218 |  |  | $ | 77 |  |

[0000858877-21-000004:notes:85]
The weighted-average lease term was 4.2 years and 4.0 years as of January 23, 2021 and July 25, 2020, respectively. The weighted-average discount rate was 1.0% and 1.5% as of January 23, 2021 and July 25, 2020, respectively.

[0000858877-21-000004:notes:86]
The maturities of our operating leases (undiscounted) as of January 23, 2021 are as follows (in millions):

[0000858877-21-000004:notes:87]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 193 |  |
| 2022 | 304 |  |
| 2023 | 232 |  |
| 2024 | 151 |  |
| 2025 | 92 |  |
| Thereafter | 104 |  |
| Total lease payments | 1,076 |  |
| Less interest | (22) |  |
| Total | $ | 1,054 |  |

[0000858877-21-000004:notes:88]
(b)Lessor Arrangements

[0000858877-21-000004:notes:89]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the second quarter and first six months of fiscal 2021 was $19 million and $40 million, respectively, and $23 million and $49 million for the corresponding periods of fiscal 2020, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-21-000004:notes:90]
Future minimum lease payments on our lease receivables as of January 23, 2021 are summarized as follows (in millions):

[0000858877-21-000004:notes:91]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 330 |  |
| 2022 | 685 |  |
| 2023 | 455 |  |
| 2024 | 237 |  |
| 2025 | 130 |  |
| Thereafter | 28 |  |
| Total | 1,865 |  |
| Less: Present value of lease payments | 1,768 |  |
| Unearned income | $ | 97 |  |

[0000858877-21-000004:notes:92]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-21-000004:notes:93]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by Cisco and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-21-000004:notes:94]
|  | January 23, 2021 |  | July 25, 2020 |
| Operating lease assets | $ | 343 |  |  | $ | 337 |  |
| Accumulated depreciation | (201) |  |  | (198) |  |
| Operating lease assets, net | $ | 142 |  |  | $ | 139 |  |

[0000858877-21-000004:notes:95]
Our operating lease income for the second quarter and first six months of fiscal 2021 was $40 million and $83 million, respectively, and $50 million and $94 million for the corresponding periods of fiscal 2020, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-21-000004:notes:96]
Minimum future rentals on noncancelable operating leases as of January 23, 2021 are summarized as follows (in millions):

[0000858877-21-000004:notes:97]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 38 |  |
| 2022 | 44 |  |
| 2023 | 20 |  |
| 2024 | 4 |  |
| Total | $ | 106 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-21-000004:notes:98]
[same as prior period, unchanged from 0000858877-20-000015:notes:97]

[0000858877-21-000004:notes:99]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one year to three years.

[0000858877-21-000004:notes:100]
[same as prior period, unchanged from 0000858877-20-000015:notes:99]

[0000858877-21-000004:notes:101]
| January 23, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,865 |  |  | $ | 5,817 |  |  | $ | 2,575 |  |  | $ | 10,257 |  |
| Residual value | 115 |  |  | — |  |  | — |  |  | 115 |  |
| Unearned income | (97) |  |  | — |  |  | — |  |  | (97) |  |
| Allowance for credit loss | (43) |  |  | (96) |  |  | (9) |  |  | (148) |  |
| Total, net | $ | 1,840 |  |  | $ | 5,721 |  |  | $ | 2,566 |  |  | $ | 10,127 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 868 |  |  | $ | 2,746 |  |  | $ | 1,413 |  |  | $ | 5,027 |  |
| Noncurrent | 972 |  |  | 2,975 |  |  | 1,153 |  |  | 5,100 |  |
| Total, net | $ | 1,840 |  |  | $ | 5,721 |  |  | $ | 2,566 |  |  | $ | 10,127 |  |

[0000858877-21-000004:notes:102]
[same as prior period, unchanged from 0000858877-20-000015:notes:101]

[0000858877-21-000004:notes:103]
[same as prior period, unchanged from 0000858877-20-000015:notes:102]

[0000858877-21-000004:notes:104]
Gross financing receivables(1) categorized by our internal credit risk rating by period of origination as of January 23, 2021 are summarized as follows (in millions):

[0000858877-21-000004:notes:105]
|  |  |  | Fiscal Year |  | Six Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | January 23, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 10 |  |  | $ | 49 |  |  | $ | 153 |  |  | $ | 248 |  |  | $ | 331 |  |  | $ | 16 |  |  | $ | 807 |  |
| 5 to 6 | 15 |  |  | 48 |  |  | 121 |  |  | 270 |  |  | 360 |  |  | 98 |  |  | 912 |  |
| 7 and Higher | 3 |  |  | 2 |  |  | 6 |  |  | 14 |  |  | 20 |  |  | 4 |  |  | 49 |  |
| Total Lease Receivables | $ | 28 |  |  | $ | 99 |  |  | $ | 280 |  |  | $ | 532 |  |  | $ | 711 |  |  | $ | 118 |  |  | $ | 1,768 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 16 |  |  | $ | 141 |  |  | $ | 387 |  |  | $ | 774 |  |  | $ | 1,302 |  |  | $ | 1,053 |  |  | $ | 3,673 |  |
| 5 to 6 | 5 |  |  | 60 |  |  | 145 |  |  | 362 |  |  | 745 |  |  | 672 |  |  | 1,989 |  |
| 7 and Higher | 2 |  |  | 3 |  |  | 8 |  |  | 65 |  |  | 58 |  |  | 19 |  |  | 155 |  |
| Total Loan Receivables | $ | 23 |  |  | $ | 204 |  |  | $ | 540 |  |  | $ | 1,201 |  |  | $ | 2,105 |  |  | $ | 1,744 |  |  | $ | 5,817 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 49 |  |  | $ | 51 |  |  | $ | 213 |  |  | $ | 455 |  |  | $ | 742 |  |  | $ | 1,512 |  |
| 5 to 6 | 1 |  |  | 21 |  |  | 57 |  |  | 235 |  |  | 412 |  |  | 305 |  |  | 1,031 |  |
| 7 and Higher | — |  |  | — |  |  | 2 |  |  | 15 |  |  | 12 |  |  | 3 |  |  | 32 |  |
| Total Financed Service Contracts | $ | 3 |  |  | $ | 70 |  |  | $ | 110 |  |  | $ | 463 |  |  | $ | 879 |  |  | $ | 1,050 |  |  | $ | 2,575 |  |
| Total | $ | 54 |  |  | $ | 373 |  |  | $ | 930 |  |  | $ | 2,196 |  |  | $ | 3,695 |  |  | $ | 2,912 |  |  | $ | 10,160 |  |

[0000858877-21-000004:notes:106]
[same as prior period, unchanged from 0000858877-20-000015:notes:105]

[0000858877-21-000004:notes:107]
The following table summarizes our gross receivables categorized by our internal credit risk rating as of July 25, 2020 and was not restated to reflect the impact of adoption of the accounting standards update on Credit Losses on Financial Instruments:

[0000858877-21-000004:notes:108]
[same as prior period, unchanged from 0000858877-20-000015:notes:107]

[0000858877-21-000004:notes:109]
The following tables present the aging analysis of gross receivables as of January 23, 2021 and July 25, 2020 (in millions):

[0000858877-21-000004:notes:110]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| January 23, 2021 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 68 |  |  | $ | 13 |  |  | $ | 83 |  |  | $ | 164 |  |  | $ | 1,604 |  |  | $ | 1,768 |  |  | $ | 2 |  |  | $ | 33 |  |  | $ | 33 |  |
| Loan receivables | 109 |  |  | 30 |  |  | 73 |  |  | 212 |  |  | 5,605 |  |  | 5,817 |  |  | 15 |  |  | 50 |  |  | 50 |  |
| Financed service contracts | 40 |  |  | 11 |  |  | 101 |  |  | 152 |  |  | 2,423 |  |  | 2,575 |  |  | 31 |  |  | 4 |  |  | 4 |  |
| Total | $ | 217 |  |  | $ | 54 |  |  | $ | 257 |  |  | $ | 528 |  |  | $ | 9,632 |  |  | $ | 10,160 |  |  | $ | 48 |  |  | $ | 87 |  |  | $ | 87 |  |

[0000858877-21-000004:notes:111]
[same as prior period, unchanged from 0000858877-20-000015:notes:110]

[0000858877-21-000004:notes:112]
[same as prior period, unchanged from 0000858877-20-000015:notes:111]

[0000858877-21-000004:notes:113]
[same as prior period, unchanged from 0000858877-20-000015:notes:112]

[0000858877-21-000004:notes:114]
[same as prior period, unchanged from 0000858877-20-000015:notes:113]

[0000858877-21-000004:notes:115]
[same as prior period, unchanged from 0000858877-20-000015:notes:114]

[0000858877-21-000004:notes:116]
| Three months ended January 23, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 24, 2020 | $ | 46 |  |  | $ | 101 |  |  | $ | 7 |  |  | $ | 154 |  |
| Provisions (benefits) | (4) |  |  | (6) |  |  | 2 |  |  | (8) |  |
| Other | 1 |  |  | 1 |  |  | — |  |  | 2 |  |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |

[0000858877-21-000004:notes:117]
| Six months ended January 23, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (7) |  |  | (3) |  |  | 1 |  |  | (9) |  |
| Other | 2 |  |  | 18 |  |  | (1) |  |  | 19 |  |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |

[0000858877-21-000004:notes:118]
| Three months ended January 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 26, 2019 | $ | 43 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 133 |  |
| Provisions (benefits) | (1) |  |  | 15 |  |  | — |  |  | 14 |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Foreign exchange and other | 1 |  |  | — |  |  | (1) |  |  | — |  |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |

[0000858877-21-000004:notes:119]
| Six months ended January 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (4) |  |  | 42 |  |  | — |  |  | 38 |  |
| Recoveries (write-offs), net | (1) |  |  | (17) |  |  | — |  |  | (18) |  |
| Foreign exchange and other | 1 |  |  | (1) |  |  | (1) |  |  | (1) |  |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-21-000004:notes:120]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-21-000004:notes:121]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-21-000004:notes:122]
| January 23, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,613 |  |  | $ | 50 |  |  | $ | — |  |  | $ | 2,663 |  |
| U.S. government agency securities | 168 |  |  | — |  |  | — |  |  | 168 |  |
| Corporate debt securities | 10,516 |  |  | 296 |  |  | (26) |  |  | 10,786 |  |
| U.S. agency mortgage-backed securities | 2,796 |  |  | 47 |  |  | (3) |  |  | 2,840 |  |
| Commercial paper | 1,730 |  |  | — |  |  | — |  |  | 1,730 |  |
| Certificates of deposit | 603 |  |  | — |  |  | — |  |  | 603 |  |
| Total (1) | $ | 18,426 |  |  | $ | 393 |  |  | $ | (29) |  |  | $ | 18,790 |  |

[0000858877-21-000004:notes:123]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |

[0000858877-21-000004:notes:124]
(1) Net unsettled investment sales were $39 million as of January 23, 2021 and were included in other current assets.

[0000858877-21-000004:notes:125]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-21-000004:notes:126]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Gross realized gains | $ | 9 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 25 |  |
| Gross realized losses | — |  |  | (2) |  |  | — |  |  | (4) |  |
| Total | $ | 9 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | 21 |  |

[0000858877-21-000004:notes:127]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2021 and July 25, 2020 (in millions):

[0000858877-21-000004:notes:128]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 109 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |
| U.S. government agency securities | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Corporate debt securities | 663 |  |  | (1) |  |  | — |  |  | — |  |  | 663 |  |  | (1) |  |
| U.S. agency mortgage-backed securities | 698 |  |  | (3) |  |  | — |  |  | — |  |  | 698 |  |  | (3) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 1,521 |  |  | $ | (4) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,521 |  |  | $ | (4) |  |

[0000858877-21-000004:notes:129]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |

[0000858877-21-000004:notes:130]
The following table summarizes the maturities of our available-for-sale debt investments as of January 23, 2021 (in millions):

[0000858877-21-000004:notes:131]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 6,674 |  |  | $ | 6,679 |  |
| After 1 year through 5 years | 7,035 |  |  | 7,201 |  |
| After 5 years through 10 years | 1,913 |  |  | 2,060 |  |
| After 10 years | 8 |  |  | 10 |  |
| Mortgage-backed securities with no single maturity | 2,796 |  |  | 2,840 |  |
| Total | $ | 18,426 |  |  | $ | 18,790 |  |

[0000858877-21-000004:notes:132]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-21-000004:notes:133]
(b)Summary of Equity Investments

[0000858877-21-000004:notes:134]
Our net unrealized gains recognized during the reporting period on our marketable and non-marketable equity securities still held as of January 23, 2021 was $4 million for each of the second quarter and first six months of fiscal 2021, and a net gain of $3 million for the corresponding periods of fiscal 2020. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $3 million and $4 million for the second quarter and first six months of fiscal 2021, respectively. These adjustments were net gains of $3 million for each of the corresponding periods of fiscal 2020. We held equity interests in certain private equity funds of $0.7 billion as of each of January 23, 2021 and July 25, 2020, which are accounted for under the NAV practical expedient.

[0000858877-21-000004:notes:135]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 23, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-21-000004:notes:136]
The carrying value of our investments in privately held companies was $1.3 billion as of each of January 23, 2021 and July 25, 2020.

[0000858877-21-000004:notes:137]
Of the total carrying value of our investments in privately held companies as of January 23, 2021, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-21-000004:notes:138]
[same as prior period, unchanged from 0000858877-20-000015:notes:136]

[0000858877-21-000004:notes:139]
[same as prior period, unchanged from 0000858877-20-000015:notes:137]

[0000858877-21-000004:notes:140]
[same as prior period, unchanged from 0000858877-20-000015:notes:138]

[0000858877-21-000004:notes:141]
[same as prior period, unchanged from 0000858877-20-000015:notes:139]

[0000858877-21-000004:notes:142]
[same as prior period, unchanged from 0000858877-20-000015:notes:140]

[0000858877-21-000004:notes:143]
[same as prior period, unchanged from 0000858877-20-000015:notes:141]

[0000858877-21-000004:notes:144]
[same as prior period, unchanged from 0000858877-20-000015:notes:142]

[0000858877-21-000004:notes:145]
|  | JANUARY 23, 2021 |  | JULY 25, 2020 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,515 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,515 |  |  | $ | 10,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,024 |  |
| Corporate debt securities | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Certificates of deposit | — |  |  | 161 |  |  | — |  |  | 161 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 902 |  |  | — |  |  | 902 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,663 |  |  | — |  |  | 2,663 |  |  | — |  |  | 2,685 |  |  | — |  |  | 2,685 |  |
| U.S. government agency securities | — |  |  | 168 |  |  | — |  |  | 168 |  |  | — |  |  | 110 |  |  | — |  |  | 110 |  |
| Corporate debt securities | — |  |  | 10,786 |  |  | — |  |  | 10,786 |  |  | — |  |  | 11,877 |  |  | — |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,840 |  |  | — |  |  | 2,840 |  |  | — |  |  | 2,035 |  |  | — |  |  | 2,035 |  |
| Commercial paper | — |  |  | 1,730 |  |  | — |  |  | 1,730 |  |  | — |  |  | 727 |  |  | — |  |  | 727 |  |
| Certificates of deposit | — |  |  | 603 |  |  | — |  |  | 603 |  |  | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 5 |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative assets | — |  |  | 165 |  |  | 6 |  |  | 171 |  |  | — |  |  | 190 |  |  | 1 |  |  | 191 |  |
| Total | $ | 8,520 |  |  | $ | 20,027 |  |  | $ | 6 |  |  | $ | 28,553 |  |  | $ | 10,024 |  |  | $ | 17,808 |  |  | $ | 1 |  |  | $ | 27,833 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |

[0000858877-21-000004:notes:146]
Level 1 marketable securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and

[0000858877-21-000004:notes:147]
determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented. Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-21-000004:notes:148]
[same as prior period, unchanged from 0000858877-20-000015:notes:146]

[0000858877-21-000004:notes:149]
[same as prior period, unchanged from 0000858877-20-000015:notes:147]

[0000858877-21-000004:notes:150]
[same as prior period, unchanged from 0000858877-20-000015:notes:148]

[0000858877-21-000004:notes:151]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of January 23, 2021 and July 25, 2020 was $4.1 billion and $4.5 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of January 23, 2021, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 23, 2021, the fair value of our senior notes was $16.8 billion with a carrying amount of $14.6 billion. This compares to a fair value of $17.4 billion and a carrying amount of $14.6 billion as of July 25, 2020. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-21-000004:notes:152]
Borrowings 
(a)Short-Term Debt

[0000858877-21-000004:notes:153]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-21-000004:notes:154]
|  | January 23, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,000 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |

[0000858877-21-000004:notes:155]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-21-000004:notes:156]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-21-000004:notes:157]
(b)Long-Term Debt

[0000858877-21-000004:notes:158]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-21-000004:notes:159]
|  |  |  | January 23, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.92% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.17% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.33% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (84) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 138 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,554 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |

[0000858877-21-000004:notes:160]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-21-000004:notes:161]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2021, we were in compliance with all debt covenants.

[0000858877-21-000004:notes:162]
As of January 23, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-21-000004:notes:163]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |

[0000858877-21-000004:notes:164]
(c)Credit Facility

[0000858877-21-000004:notes:165]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. On January 25, 2021, we entered into an amendment to the credit facility to obtain consent of the lenders to our reincorporation to Delaware. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of January 23, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-21-000004:notes:166]
[same as prior period, unchanged from 0000858877-20-000015:notes:164]

[0000858877-21-000004:notes:167]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-21-000004:notes:168]
[same as prior period, unchanged from 0000858877-20-000015:notes:166]

[0000858877-21-000004:notes:169]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 23,2021 |  | July 25,2020 |  | Balance Sheet Line Item |  | January 23,2021 |  | July 25,2020 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 7 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 14 |  |  | $ | 2 |  |
| Interest rate derivatives | Other current assets |  | 1 |  |  | 6 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 140 |  |  | 169 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 148 |  |  | 182 |  |  |  |  | 14 |  |  | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 17 |  |  | 8 |  |  | Other current liabilities |  | 12 |  |  | 8 |  |
| Equity derivatives | Other assets |  | 6 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 23 |  |  | 9 |  |  |  |  | 12 |  |  | 8 |  |
| Total |  |  | $ | 171 |  |  | $ | 191 |  |  |  |  | $ | 26 |  |  | $ | 10 |  |

[0000858877-21-000004:notes:170]
[same as prior period, unchanged from 0000858877-20-000015:notes:168]

[0000858877-21-000004:notes:171]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | January 23,2021 |  | July 25,2020 |  | January 23,2021 |  | July 25,2020 |
| Short-term debt |  | $ | (501) |  |  | $ | (506) |  |  | $ | (1) |  |  | $ | (6) |  |
| Long-term debt |  | $ | (2,132) |  |  | $ | (2,159) |  |  | $ | (137) |  |  | $ | (165) |  |

[0000858877-21-000004:notes:172]
[same as prior period, unchanged from 0000858877-20-000015:notes:170]

[0000858877-21-000004:notes:173]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | 14 |  |  | $ | 7 |  |  | $ | 33 |  |  | $ | (14) |  |
| Derivatives designated as hedging instruments |  | (14) |  |  | (6) |  |  | (34) |  |  | 16 |  |
| Total |  | $ | — |  |  | $ | 1 |  |  | $ | (1) |  |  | $ | 2 |  |

[0000858877-21-000004:notes:174]
[same as prior period, unchanged from 0000858877-20-000015:notes:172]

[0000858877-21-000004:notes:175]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 33 |  |  | $ | (2) |  |  | $ | 47 |  |  | $ | (9) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 76 |  |  | 41 |  |  | 99 |  |  | 41 |  |
| Equity derivatives |  | Other income (loss), net |  | 9 |  |  | 3 |  |  | 14 |  |  | 5 |  |
| Total |  |  |  | $ | 118 |  |  | $ | 42 |  |  | $ | 160 |  |  | $ | 37 |  |

[0000858877-21-000004:notes:176]
[same as prior period, unchanged from 0000858877-20-000015:notes:174]

[0000858877-21-000004:notes:177]
|  | January 23,2021 |  | July 25,2020 |
| Foreign currency derivatives | $ | 4,839 |  |  | $ | 4,315 |  |
| Interest rate derivatives | 2,500 |  |  | 2,500 |  |
| Total return swaps—deferred compensation | 689 |  |  | 580 |  |
| Total | $ | 8,028 |  |  | $ | 7,395 |  |

[0000858877-21-000004:notes:178]
[same as prior period, unchanged from 0000858877-20-000015:notes:176]

[0000858877-21-000004:notes:179]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of January 23, 2021 and July 25, 2020, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $22 million and $10 million, respectively.

[0000858877-21-000004:notes:180]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of January 23, 2021 and July 25, 2020 was $141 million and $173 million, respectively. Including the effects of collateral, this results in a net derivative asset of $4 million and $8 million as of January 23, 2021 and July 25, 2020, respectively.

[0000858877-21-000004:notes:181]
[same as prior period, unchanged from 0000858877-20-000015:notes:179]

[0000858877-21-000004:notes:182]
[same as prior period, unchanged from 0000858877-20-000015:notes:180]

[0000858877-21-000004:notes:183]
[same as prior period, unchanged from 0000858877-20-000015:notes:181]

[0000858877-21-000004:notes:184]
[same as prior period, unchanged from 0000858877-20-000015:notes:182]

[0000858877-21-000004:notes:185]
[same as prior period, unchanged from 0000858877-20-000015:notes:183]

[0000858877-21-000004:notes:186]
[same as prior period, unchanged from 0000858877-20-000015:notes:184]

[0000858877-21-000004:notes:187]
[same as prior period, unchanged from 0000858877-20-000015:notes:185]

[0000858877-21-000004:notes:188]
[same as prior period, unchanged from 0000858877-20-000015:notes:186]

[0000858877-21-000004:notes:189]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-21-000004:notes:190]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-21-000004:notes:191]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 23, 2021 and July 25, 2020, we had total purchase commitments for inventory of $4.6 billion and $4.4 billion, respectively.

[0000858877-21-000004:notes:192]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2021 and July 25, 2020, the liability for these purchase commitments was $152 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $44 million and $67 million for the first six months of fiscal 2021 and 2020, respectively.

[0000858877-21-000004:notes:193]
(b)Other Commitments

[0000858877-21-000004:notes:194]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-21-000004:notes:195]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-21-000004:notes:196]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Compensation expense related to acquisitions | $ | 59 |  |  | $ | 50 |  |  | $ | 116 |  |  | $ | 111 |  |

[0000858877-21-000004:notes:197]
As of January 23, 2021, we estimated that future cash compensation expense of up to $452 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-21-000004:notes:198]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of January 23, 2021 and July 25, 2020.

[0000858877-21-000004:notes:199]
(c)Product Warranties

[0000858877-21-000004:notes:200]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-21-000004:notes:201]
|  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 247 |  |  | 283 |  |
| Adjustments for pre-existing warranties | 4 |  |  | (3) |  |
| Settlements | (249) |  |  | (291) |  |
| Balance at end of period | $ | 333 |  |  | $ | 331 |  |

[0000858877-21-000004:notes:202]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-21-000004:notes:203]
(d)Financing and Other Guarantees

[0000858877-21-000004:notes:204]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-21-000004:notes:205]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.6 billion for the second quarter of fiscal 2021 and 2020, respectively, and was $12.8 billion and $14.2 billion for the first six months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of January 23, 2021 and July 25, 2020, respectively.

[0000858877-21-000004:notes:206]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the second quarter of fiscal 2021 and 2020, respectively, and was $8 million and $6 million for the first six months of fiscal 2021 and 2020, respectively.

[0000858877-21-000004:notes:207]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-21-000004:notes:208]
|  | January 23,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 205 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 213 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (19) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (27) |  |  | $ | (28) |  |
| Total | $ | 186 |  |  | $ | 179 |  |

[0000858877-21-000004:notes:209]
(e)Indemnifications

[0000858877-21-000004:notes:210]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-21-000004:notes:211]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre- and post-judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.

[0000858877-21-000004:notes:212]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided

[0000858877-21-000004:notes:213]
by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. On October 13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that Chanbond will not be able to meet its burden required for injunctive relief. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

[0000858877-21-000004:notes:214]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-21-000004:notes:215]
It is not possible to determine the maximum potential amount under these indemnification agreements due to uncertainties in the litigation process, coordination with other suppliers and the defendants in these cases, and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-21-000004:notes:216]
(f)Legal Proceedings

[0000858877-21-000004:notes:217]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $148 million for the alleged evasion of import and other taxes, $728 million for interest, and $366 million for various penalties, all determined using an exchange rate as of January 23, 2021.

[0000858877-21-000004:notes:218]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-21-000004:notes:219]
China     The Company is investigating allegations of a self-enrichment scheme involving now-former employees in China.  Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. The Company voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

[0000858877-21-000004:notes:220]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-21-000004:notes:221]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment when it becomes final as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

[0000858877-21-000004:notes:222]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have now expired such that no injunctive relief is available on those patents. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty (instead of injunctive relief) until its expiration on December 12, 2025. The case is currently set for jury trial starting June 4, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

[0000858877-21-000004:notes:223]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. As of November 27, 2020, the U.S. Patent & Trademark Office preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the Court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

[0000858877-21-000004:notes:224]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of 
operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-21-000004:notes:225]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-21-000004:notes:226]
[same as prior period, unchanged from 0000858877-20-000015:notes:223]

[0000858877-21-000004:notes:227]
We declared and paid cash dividends of $0.36 and $0.35 per common share, or $1.5 billion, on our outstanding common stock for each of the second quarters of fiscal 2021 and 2020. We declared and paid cash dividends of $0.72 and $0.70 per common share, or $3.0 billion, on our outstanding common stock for each of the first six months of fiscal 2021 and 2020.

[0000858877-21-000004:notes:228]
On February 9, 2021, our Board of Directors declared a quarterly dividend of $0.37 per common share to be paid on April 28, 2021 to all stockholders of record as of the close of business on April 6, 2021. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-21-000004:notes:229]
[same as prior period, unchanged from 0000858877-20-000015:notes:226]

[0000858877-21-000004:notes:230]
In September 2001, our Board of Directors authorized a stock repurchase program. As of January 23, 2021, the remaining authorized amount for stock repurchases under this program was approximately $9.2 billion with no termination date. A summary of the stock repurchase activity for fiscal 2021 and 2020 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-21-000004:notes:231]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2021 |  |  |  |  |  |  |
| January 23, 2021 |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |
| Fiscal 2020 |  |  |  |  |  |  |
| July 25, 2020 |  | — |  |  | $ | — |  |  | $ | — |  |
| April 25, 2020 |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |
| January 25, 2020 |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |

[0000858877-21-000004:notes:232]
There were $32 million stock repurchases that were pending settlement as of January 23, 2021. There were no stock repurchases that were pending settlement as of July 25, 2020.

[0000858877-21-000004:notes:233]
[same as prior period, unchanged from 0000858877-20-000015:notes:230]

[0000858877-21-000004:notes:234]
[same as prior period, unchanged from 0000858877-20-000015:notes:231]

[0000858877-21-000004:notes:235]
[same as prior period, unchanged from 0000858877-20-000015:notes:232]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-21-000004:notes:236]
[same as prior period, unchanged from 0000858877-20-000015:notes:233]

[0000858877-21-000004:notes:237]
Stock Incentive Plan Program Description    As of January 23, 2021, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-21-000004:notes:238]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. On December 10, 2020, the 2005 Plan was amended to extend the term for nine years, and increase the number of shares authorized for issuance by approximately 96 million, among other items. As of January 23, 2021, the maximum number of shares issuable under the 2005 Plan over its term was increased to 790 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-21-000004:notes:239]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 23, 2021, 253 million shares were authorized for future grant under the 2005 Plan.

[0000858877-21-000004:notes:240]
[same as prior period, unchanged from 0000858877-20-000015:notes:238]

[0000858877-21-000004:notes:241]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of January 23, 2021. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 8 million shares during the second quarter and first six months of fiscal 2021 and 9 million shares during the corresponding periods of fiscal 2020. As of January 23, 2021, 133 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-21-000004:notes:242]
[same as prior period, unchanged from 0000858877-20-000015:notes:240]

[0000858877-21-000004:notes:243]
[same as prior period, unchanged from 0000858877-20-000015:notes:241]

[0000858877-21-000004:notes:244]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Cost of sales—product | $ | 25 |  |  | $ | 23 |  |  | $ | 49 |  |  | $ | 46 |  |
| Cost of sales—service | 43 |  |  | 36 |  |  | 84 |  |  | 70 |  |
| Share-based compensation expense in cost of sales | 68 |  |  | 59 |  |  | 133 |  |  | 116 |  |
| Research and development | 171 |  |  | 146 |  |  | 338 |  |  | 292 |  |
| Sales and marketing | 128 |  |  | 119 |  |  | 262 |  |  | 246 |  |
| General and administrative | 59 |  |  | 55 |  |  | 120 |  |  | 115 |  |
| Restructuring and other charges | 10 |  |  | 5 |  |  | 21 |  |  | 13 |  |
| Share-based compensation expense in operating expenses | 368 |  |  | 325 |  |  | 741 |  |  | 666 |  |
| Total share-based compensation expense | $ | 436 |  |  | $ | 384 |  |  | $ | 874 |  |  | $ | 782 |  |
| Income tax benefit for share-based compensation | $ | 95 |  |  | $ | 109 |  |  | $ | 176 |  |  | $ | 240 |  |

[0000858877-21-000004:notes:245]
As of January 23, 2021, the total compensation cost related to unvested share-based awards not yet recognized was $4.0 billion which is expected to be recognized over approximately 2.7 years on a weighted-average basis.

[0000858877-21-000004:notes:246]
[same as prior period, unchanged from 0000858877-20-000015:notes:244]

[0000858877-21-000004:notes:247]
[same as prior period, unchanged from 0000858877-20-000015:notes:245]

[0000858877-21-000004:notes:248]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 27, 2019 | 100 |  |  | $ | 38.66 |  |  |  |
| Granted and assumed | 49 |  |  | 42.61 |  |  |  |
| Vested | (44) |  |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9) |  |  | 40.45 |  |  |  |
| Unvested balance at July 25, 2020 | 96 |  |  | 42.03 |  |  |  |
| Granted and assumed | 33 |  |  | 37.90 |  |  |  |
| Vested | (21) |  |  | 39.05 |  |  | $ | 908 |  |
| Canceled/forfeited/other | (9) |  |  | 41.63 |  |  |  |
| Unvested balance at January 23, 2021 | 99 |  |  | $ | 41.35 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-21-000004:notes:249]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2021 and 2020 are summarized as follows (in millions):

[0000858877-21-000004:notes:250]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (35) |  |  | (5) |  |  | 345 |  |  | 305 |  |
| (Gains) losses reclassified out of AOCI | (24) |  |  | (5) |  |  | 2 |  |  | (27) |  |
| Tax benefit (expense) | 24 |  |  | 2 |  |  | (3) |  |  | 23 |  |
| Balance at January 23, 2021 | $ | 280 |  |  | $ | (14) |  |  | $ | (484) |  |  | $ | (218) |  |

[0000858877-21-000004:notes:251]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2019 | $ | — |  |  | $ | (14) |  |  | $ | (778) |  |  | $ | (792) |  |
| Other comprehensive income (loss) before reclassifications | 168 |  |  | — |  |  | (42) |  |  | 126 |  |
| (Gains) losses reclassified out of AOCI | (21) |  |  | 2 |  |  | 2 |  |  | (17) |  |
| Tax benefit (expense) | (17) |  |  | 1 |  |  | (1) |  |  | (17) |  |
| Balance at January 25, 2020 | $ | 130 |  |  | $ | (11) |  |  | $ | (819) |  |  | $ | (700) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-21-000004:notes:252]
[same as prior period, unchanged from 0000858877-20-000015:notes:250]

[0000858877-21-000004:notes:253]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Income before provision for income taxes | $ | 3,255 |  |  | $ | 3,534 |  |  | $ | 5,936 |  |  | $ | 7,220 |  |
| Provision for income taxes | $ | 710 |  |  | $ | 656 |  |  | $ | 1,217 |  |  | $ | 1,416 |  |
| Effective tax rate | 21.8 | % |  | 18.6 | % |  | 20.5 | % |  | 19.6 | % |

[0000858877-21-000004:notes:254]
As of January 23, 2021, we had $2.5 billion of unrecognized tax benefits, of which $2.1 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-21-000004:notes:255]
[same as prior period, unchanged from 0000858877-20-000015:notes:253]

[0000858877-21-000004:notes:256]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-21-000004:notes:257]
Summarized financial information by segment for the second quarter and first six months of fiscal 2021 and 2020, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-21-000004:notes:258]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23, 2021 |  | January 25, 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 6,969 |  |  | $ | 7,013 |  |  | $ | 14,168 |  |  | $ | 14,990 |  |
| EMEA | 3,207 |  |  | 3,134 |  |  | 6,171 |  |  | 6,417 |  |
| APJC | 1,784 |  |  | 1,859 |  |  | 3,551 |  |  | 3,758 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,705 |  |  | $ | 4,692 |  |  | $ | 9,552 |  |  | $ | 10,008 |  |
| EMEA | 2,145 |  |  | 2,062 |  |  | 4,038 |  |  | 4,229 |  |
| APJC | 1,155 |  |  | 1,219 |  |  | 2,268 |  |  | 2,413 |  |
| Segment total | 8,005 |  |  | 7,974 |  |  | 15,858 |  |  | 16,650 |  |
| Unallocated corporate items | (221) |  |  | (210) |  |  | (493) |  |  | (422) |  |
| Total | $ | 7,784 |  |  | $ | 7,764 |  |  | $ | 15,365 |  |  | $ | 16,228 |  |

[0000858877-21-000004:notes:259]
[same as prior period, unchanged from 0000858877-20-000015:notes:257]

[0000858877-21-000004:notes:260]
Revenue in the United States was $6.2 billion for each of the second quarters of fiscal 2021 and 2020 and $12.7 billion and $13.3 billion for the first six months of fiscal 2021 and 2020, respectively.

[0000858877-21-000004:notes:261]
[same as prior period, unchanged from 0000858877-20-000015:notes:259]

[0000858877-21-000004:notes:262]
[same as prior period, unchanged from 0000858877-20-000015:notes:260]


## us-gaap:EarningsPerShareTextBlock

[0000858877-21-000004:notes:263]
[same as prior period, unchanged from 0000858877-20-000015:notes:261]

[0000858877-21-000004:notes:264]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Net income | $ | 2,545 |  |  | $ | 2,878 |  |  | $ | 4,719 |  |  | $ | 5,804 |  |
| Weighted-average shares—basic | 4,223 |  |  | 4,242 |  |  | 4,227 |  |  | 4,244 |  |
| Effect of dilutive potential common shares | 11 |  |  | 18 |  |  | 12 |  |  | 21 |  |
| Weighted-average shares—diluted | 4,234 |  |  | 4,260 |  |  | 4,239 |  |  | 4,265 |  |
| Net income per share—basic | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 1.12 |  |  | $ | 1.37 |  |
| Net income per share—diluted | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 1.11 |  |  | $ | 1.36 |  |
| Antidilutive employee share-based awards, excluded | 49 |  |  | 29 |  |  | 56 |  |  | 32 |  |

[0000858877-21-000004:notes:265]
[same as prior period, unchanged from 0000858877-20-000015:notes:263]
