# CSCO note change history — 0000858877-17-000019 → 0000858877-18-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-02-20):
[0000858877-18-000004:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 27, 2018 are as follows (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 220 |  |
| 2019 | 323 |  |
| 2020 | 239 |  |
| 2021 | 147 |  |
| 2022 | 122 |  |
| Thereafter | 178 |  |
| Total | $ | 1,229 |  |
  (was, 2017-11-21, similarity 0.9836):
[0000858877-17-000019:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 316 |  |
| 2019 | 292 |  |
| 2020 | 203 |  |
| 2021 | 120 |  |
| 2022 | 99 |  |
| Thereafter | 147 |  |
| Total | $ | 1,177 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.
  (was, 2017-11-21, similarity 0.6637):
[0000858877-17-000019:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 28, 2017 and July 29, 2017, the Company had total purchase commitments for inventory of $4,205 million and $4,640 million, respectively.

- added (2018-02-20):
[0000858877-18-000004:note_history:4]
The following table summarizes the Company's purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

- added (2018-02-20):
[0000858877-18-000004:note_history:5]
| Commitments by Period | January 27, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 4,498 |  |  | $ | 4,620 |  |
| 1 to 3 years | 690 |  |  | 20 |  |
| 3 to 5 years | 540 |  |  | — |  |
| Total | $ | 5,728 |  |  | $ | 4,640 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:6]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 27, 2018 and July 29, 2017, the liability for these purchase commitments was $159 million and $162 million, respectively, and was included in other current liabilities.
  (was, 2017-11-21, similarity 0.9597):
[0000858877-17-000019:note_history:6]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 28, 2017 and July 29, 2017, the liability for these purchase commitments was $161 million and $162 million, respectively, and was included in other current liabilities.

- changed (2018-02-20):
[0000858877-18-000004:note_history:7]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Compensation expense related to acquisitions | $ | 46 |  |  | $ | 73 |  |  | $ | 88 |  |  | $ | 137 |  |
  (was, 2017-11-21, similarity 0.6985):
[0000858877-17-000019:note_history:7]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Compensation expense related to acquisitions | $ | 42 |  |  | $ | 64 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:8]
As of January 27, 2018, the Company estimated that future cash compensation expense of up to $246 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2017-11-21, similarity 0.9684):
[0000858877-17-000019:note_history:8]
As of October 28, 2017, the Company estimated that future cash compensation expense of up to $298 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2018-02-20):
[0000858877-18-000004:note_history:9]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million during the six months ended January 28, 2017. The Company recorded compensation expense of $12 million during the three months ended January 28, 2017, and $32 million during the six months ended January 28, 2017, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.
  (was, 2017-11-21, similarity 0.667):
[0000858877-17-000019:note_history:9]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $1 million and $323 million during the three months ended October 28, 2017 and October 29, 2016, respectively. The Company recorded compensation expense of $1 million and $20 million during the three months ended October 28, 2017 and October 29, 2016, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

- changed (2018-02-20):
[0000858877-18-000004:note_history:10]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $215 million and $216 million as of January 27, 2018 and July 29, 2017, respectively.
  (was, 2017-11-21, similarity 0.9563):
[0000858877-17-000019:note_history:10]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $213 million and $216 million as of October 28, 2017 and July 29, 2017, respectively.

- changed (2018-02-20):
[0000858877-18-000004:note_history:11]
|  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 287 |  |  | 367 |  |
| Adjustments for pre-existing warranties | (21 | ) |  | (3 | ) |
| Settlements | (292 | ) |  | (352 | ) |
| Balance at end of period | $ | 381 |  |  | $ | 426 |  |
  (was, 2017-11-21, similarity 0.7968):
[0000858877-17-000019:note_history:11]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 148 |  |  | 176 |  |
| Adjustments for pre-existing warranties | (12 | ) |  | — |  |
| Settlements | (149 | ) |  | (177 | ) |
| Balance at end of period | $ | 394 |  |  | $ | 413 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:12]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $13.6 billion and $13.2 billion for the six months ended January 27, 2018 and January 28, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of January 27, 2018 and July 29, 2017.
  (was, 2017-11-21, similarity 0.7558):
[0000858877-17-000019:note_history:12]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.9 billion for the three months ended October 28, 2017 and October 29, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of October 28, 2017 and July 29, 2017.

- changed (2018-02-20):
[0000858877-18-000004:note_history:13]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $12 million and $30 million for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $26 million and $36 million for the six months ended January 27, 2018 and January 28, 2017, respectively.
  (was, 2017-11-21, similarity 0.8508):
[0000858877-17-000019:note_history:13]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $14 million and $6 million for the three months ended October 28, 2017 and October 29, 2016, respectively.

- changed (2018-02-20):
[0000858877-18-000004:note_history:14]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 27, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2017-11-21, similarity 0.9776):
[0000858877-17-000019:note_history:14]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 28, 2017 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2018-02-20):
[0000858877-18-000004:note_history:15]
|  | January 27, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 288 |  |  | $ | 240 |  |
| End user | 53 |  |  | 74 |  |
| Total | $ | 341 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (91 | ) |  | $ | (82 | ) |
| End user | (40 | ) |  | (52 | ) |
| Total | $ | (131 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 210 |  |  | $ | 180 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:16]
Other Guarantees   The Company’s other guarantee arrangements as of January 27, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.
  (was, 2017-11-21, similarity 0.9647):
[0000858877-17-000019:note_history:16]
Other Guarantees   The Company’s other guarantee arrangements as of October 28, 2017 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

- changed (2018-02-20):
[0000858877-18-000004:note_history:17]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of January 27, 2018 and July 29, 2017 were $120 million and $174 million, respectively.
  (was, 2017-11-21, similarity 0.9864):
[0000858877-17-000019:note_history:17]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of October 28, 2017 and July 29, 2017 were $146 million and $174 million, respectively.

- changed (2018-02-20):
[0000858877-18-000004:note_history:18]
The Company has been asked to indemnify certain of the Company’s service provider customers that have been subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and, on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. On December 6, 2017, Sprint and Cox Communications, Inc. reached resolution of the claims in Sprint's lawsuit against Cox, and the Delaware court dismissed Sprint's lawsuit against Cox on December 7, 2017.
  (was, 2017-11-21, similarity 0.8483):
[0000858877-17-000019:note_history:18]
The Company has been asked to indemnify certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. Sprint's trial against Cox Communications, Inc. in Delaware is scheduled for December 7, 2017.

- added (2018-02-20):
[0000858877-18-000004:note_history:19]
The Company believes that Time Warner Cable continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the Time Warner Cable litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify Time Warner Cable for damages, mediation awards, or settlement amounts arising from its use of Cisco products.

- changed (2018-02-20):
[0000858877-18-000004:note_history:20]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringed 12 patents. Huawei's infringement allegations for some of the patents were based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On December 22, 2017, the Eastern District of Texas court dismissed Huawei's four lawsuits after the parties reached settlement, and T-Mobile's indemnity request was subsequently resolved.
  (was, 2017-11-21, similarity 0.7934):
[0000858877-17-000019:note_history:20]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringe 12 patents, now reduced to 10 patents as a result of pre-trial dismissals. Huawei's infringement allegations for some of the patents are based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile has requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On November 9, 2017, the court continued the trial date to January 2, 2018.

- changed (2018-02-20):
[0000858877-18-000004:note_history:21]
During the first six months of fiscal 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.
  (was, 2017-11-21, similarity 0.6875):
[0000858877-17-000019:note_history:21]
During the first quarter of fiscal 2018, the Company recorded legal and indemnification settlement charges of $122 million to product cost of sales in relation to these matters.

- added (2018-02-20):
[0000858877-18-000004:note_history:22]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $257 million for the alleged evasion of import and other taxes, $1.6 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 27, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2018-02-20):
[0000858877-18-000004:note_history:23]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.
  (was, 2017-11-21, similarity 0.9406):
[0000858877-17-000019:note_history:23]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018.

- changed (2018-02-20):
[0000858877-18-000004:note_history:24]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.
  (was, 2017-11-21, similarity 0.8843):
[0000858877-17-000019:note_history:24]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. The court continued the trial date from November 6, 2017 to March 12, 2018. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On August 30, 2017, the Company and DXC attended a court ordered mediation and, on September 1, 2017, the parties jointly informed the court that they are continuing to discuss the details of a business resolution to the dispute. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

- removed (2018-02-20):
[0000858877-17-000019:note_history:25]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 28, 2017 are as follows (in millions):

- removed (2018-02-20):
[0000858877-17-000019:note_history:26]
|  | October 28, 2017 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 266 |  |  | $ | 240 |  |
| End user | 65 |  |  | 74 |  |
| Total | $ | 331 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (79 | ) |  | $ | (82 | ) |
| End user | (46 | ) |  | (52 | ) |
| Total | $ | (125 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 206 |  |  | $ | 180 |  |

- removed (2018-02-20):
[0000858877-17-000019:note_history:27]
For the remaining cases, the Company believes that the service providers continue to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the remaining litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the remaining matters would be material.

- removed (2018-02-20):
[0000858877-17-000019:note_history:28]
The Company believes that the patents are invalid and/or not infringed, and that Huawei’s claims should be rejected for Huawei's failure to comply with its licensing and disclosure obligations to standards setting organizations that issued the relevant standards. If T-Mobile is found to infringe any of the patents warranting an award of damages, the Company believes damages against T-Mobile, as appropriately measured, should be governed by reasonable and nondiscriminatory licensing principles. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation and the Company does not anticipate that its obligations, if any, regarding the final outcome of the matters would be material.

- removed (2018-02-20):
[0000858877-17-000019:note_history:29]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $250 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:30]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed
  (was, 2017-11-21, similarity 0.7057):
[0000858877-17-000019:note_history:30]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:31]
The accompanying financial data as of January 27, 2018 and for the three and six months ended January 27, 2018 and January 28, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.
  (was, 2017-11-21, similarity 0.9637):
[0000858877-17-000019:note_history:31]
The accompanying financial data as of October 28, 2017 and for the three months ended October 28, 2017 and October 29, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

- added (2018-02-20):
[0000858877-18-000004:note_history:32]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three and six months ended January 27, 2018 and January 28, 2017; the statements of cash flows and equity for the six months ended January 27, 2018 and January 28, 2017, as applicable, have been made. The results of operations for the three and six months ended January 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2018-02-20):
[0000858877-17-000019:note_history:33]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 28, 2017; the results of operations and the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 28, 2017 and October 29, 2016, as applicable, have been made. The results of operations for the three months ended October 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:34]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the six months ended January 27, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.
  (was, 2017-11-21, similarity 0.966):
[0000858877-17-000019:note_history:34]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the first quarter of fiscal 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

- changed (2018-02-20):
[0000858877-18-000004:note_history:35]
(b) Recent Accounting Standards or Updates Not Yet Effective as of Period End
  (was, 2017-11-21, similarity 0.8759):
[0000858877-17-000019:note_history:35]
(b) Recent Accounting Standards or Updates Not Yet Effective

- changed (2018-02-20):
[0000858877-18-000004:note_history:36]
Cisco will be required to record cumulative effect adjustments to retained earnings (net of tax) upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.
  (was, 2017-11-21, similarity 0.9916):
[0000858877-17-000019:note_history:36]
Cisco will be required to record cumulative effect adjustments to retained earnings upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

- added (2018-02-20):
[0000858877-18-000004:note_history:37]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued a new accounting standard update that allows companies to reclassify from Accumulated Other Comprehensive Income to Retained Earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). Cisco will adopt this accounting standard update in the third quarter of fiscal 2018 on a retrospective basis. The application of this accounting standard update will not have a material impact on the Company's Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:38]
|  | January 27, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,749 |  |  | 1.78 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 8,992 |  |  | 1.51 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 13,741 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2017-11-21, similarity 0.9753):
[0000858877-17-000019:note_history:38]
|  | October 28, 2017 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,748 |  |  | 1.70 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 5,491 |  |  | 1.25 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 10,239 |  |  |  |  | $ | 7,992 |  |  |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:39]
|  |  |  | January 27, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 2.11% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.96% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.04% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.01% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.04% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.18% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.11% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.34% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.60% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.46% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.76% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (125 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (1 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,749 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,625 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2017-11-21, similarity 0.9942):
[0000858877-17-000019:note_history:39]
|  |  |  | October 28, 2017 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 1.98% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.70% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.88% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 1.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.85% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.85% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.01% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.28% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.13% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.44% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 62 |  |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,748 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,684 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:40]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2018, the Company was in compliance with all debt covenants.
  (was, 2017-11-21, similarity 0.9865):
[0000858877-17-000019:note_history:40]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2017, the Company was in compliance with all debt covenants.

- changed (2018-02-20):
[0000858877-18-000004:note_history:41]
As of January 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-11-21, similarity 0.9556):
[0000858877-17-000019:note_history:41]
As of October 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:42]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |
  (was, 2017-11-21, similarity 0.9836):
[0000858877-17-000019:note_history:42]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:43]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of January 27, 2018, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.
  (was, 2017-11-21, similarity 0.9808):
[0000858877-17-000019:note_history:43]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of October 28, 2017, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:44]
| January 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 17,506 |  |  | $ | — |  |  | $ | (140 | ) |  | $ | 17,366 |  |
| U.S. government agency securities | 1,722 |  |  | — |  |  | (10 | ) |  | 1,712 |  |
| Non-U.S. government and agency securities | 340 |  |  | — |  |  | (1 | ) |  | 339 |  |
| Corporate debt securities | 31,508 |  |  | 80 |  |  | (233 | ) |  | 31,355 |  |
| U.S. agency mortgage-backed securities | 2,106 |  |  | — |  |  | (49 | ) |  | 2,057 |  |
| Commercial paper | 1,414 |  |  | — |  |  | — |  |  | 1,414 |  |
| Certificates of deposit | 196 |  |  | — |  |  | — |  |  | 196 |  |
| Total fixed income securities | 54,792 |  |  | 80 |  |  | (433 | ) |  | 54,439 |  |
| Publicly traded equity securities | 924 |  |  | 697 |  |  | (1 | ) |  | 1,620 |  |
| Total (1) | $ | 55,716 |  |  | $ | 777 |  |  | $ | (434 | ) |  | $ | 56,059 |  |
  (was, 2017-11-21, similarity 0.9902):
[0000858877-17-000019:note_history:44]
| October 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 20,564 |  |  | $ | — |  |  | $ | (93 | ) |  | $ | 20,471 |  |
| U.S. government agency securities | 1,923 |  |  | — |  |  | (6 | ) |  | 1,917 |  |
| Non-U.S. government and agency securities | 358 |  |  | — |  |  | (1 | ) |  | 357 |  |
| Corporate debt securities | 31,999 |  |  | 162 |  |  | (131 | ) |  | 32,030 |  |
| U.S. agency mortgage-backed securities | 2,095 |  |  | 2 |  |  | (23 | ) |  | 2,074 |  |
| Commercial paper | 1,775 |  |  | — |  |  | — |  |  | 1,775 |  |
| Certificates of deposit | 140 |  |  | — |  |  | — |  |  | 140 |  |
| Total fixed income securities | 58,854 |  |  | 164 |  |  | (254 | ) |  | 58,764 |  |
| Publicly traded equity securities | 1,134 |  |  | 653 |  |  | (6 | ) |  | 1,781 |  |
| Total (1) | $ | 59,988 |  |  | $ | 817 |  |  | $ | (260 | ) |  | $ | 60,545 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:45]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(3) million and $(30) million as of January 27, 2018 and July 29, 2017, respectively.
  (was, 2017-11-21, similarity 0.8925):
[0000858877-17-000019:note_history:45]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $95 million and $(30) million as of October 28, 2017 and July 29, 2017, respectively.

- changed (2018-02-20):
[0000858877-18-000004:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Gross realized gains | $ | 165 |  |  | $ | 18 |  |  | $ | 232 |  |  | $ | 48 |  |
| Gross realized losses | (107 | ) |  | (48 | ) |  | (141 | ) |  | (63 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |
  (was, 2017-11-21, similarity 0.6909):
[0000858877-17-000019:note_history:46]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Gross realized gains | $ | 67 |  |  | $ | 30 |  |
| Gross realized losses | (34 | ) |  | (15 | ) |
| Total | $ | 33 |  |  | $ | 15 |  |

- added (2018-02-20):
[0000858877-18-000004:note_history:47]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 154 |  |  | $ | 4 |  |  | $ | 183 |  |  | $ | 9 |  |
| Net gains (losses) on investments in fixed income securities | (96 | ) |  | (34 | ) |  | (92 | ) |  | (24 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |

- changed (2018-02-20):
[0000858877-18-000004:note_history:48]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2018 and July 29, 2017 (in millions):
  (was, 2017-11-21, similarity 0.9662):
[0000858877-17-000019:note_history:48]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2017 and July 29, 2017 (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:49]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,553 |  |  | $ | (96 | ) |  | $ | 5,804 |  |  | $ | (44 | ) |  | $ | 17,357 |  |  | $ | (140 | ) |
| U.S. government agency securities | 1,152 |  |  | (5 | ) |  | 559 |  |  | (5 | ) |  | 1,711 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 136 |  |  | — |  |  | 203 |  |  | (1 | ) |  | 339 |  |  | (1 | ) |
| Corporate debt securities | 16,003 |  |  | (146 | ) |  | 4,287 |  |  | (87 | ) |  | 20,290 |  |  | (233 | ) |
| U.S. agency mortgage-backed securities | 1,161 |  |  | (19 | ) |  | 876 |  |  | (30 | ) |  | 2,037 |  |  | (49 | ) |
| Total fixed income securities | 30,005 |  |  | (266 | ) |  | 11,729 |  |  | (167 | ) |  | 41,734 |  |  | (433 | ) |
| Publicly traded equity securities | 10 |  |  | (1 | ) |  | — |  |  | — |  |  | 10 |  |  | (1 | ) |
| Total | $ | 30,015 |  |  | $ | (267 | ) |  | $ | 11,729 |  |  | $ | (167 | ) |  | $ | 41,744 |  |  | $ | (434 | ) |
  (was, 2017-11-21, similarity 0.6025):
[0000858877-17-000019:note_history:49]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,719 |  |  | $ | (66 | ) |  | $ | 3,602 |  |  | $ | (27 | ) |  | $ | 20,321 |  |  | $ | (93 | ) |
| U.S. government agency securities | 1,696 |  |  | (4 | ) |  | 222 |  |  | (2 | ) |  | 1,918 |  |  | (6 | ) |
| Non-U.S. government and agency securities | 316 |  |  | (1 | ) |  | 41 |  |  | — |  |  | 357 |  |  | (1 | ) |
| Corporate debt securities | 8,129 |  |  | (45 | ) |  | 4,209 |  |  | (86 | ) |  | 12,338 |  |  | (131 | ) |
| U.S. agency mortgage-backed securities | 1,562 |  |  | (16 | ) |  | 266 |  |  | (7 | ) |  | 1,828 |  |  | (23 | ) |
| Total fixed income securities | 28,422 |  |  | (132 | ) |  | 8,340 |  |  | (122 | ) |  | 36,762 |  |  | (254 | ) |
| Publicly traded equity securities | 54 |  |  | (6 | ) |  | — |  |  | — |  |  | 54 |  |  | (6 | ) |
| Total | $ | 28,476 |  |  | $ | (138 | ) |  | $ | 8,340 |  |  | $ | (122 | ) |  | $ | 36,816 |  |  | $ | (260 | ) |

- added (2018-02-20):
[0000858877-18-000004:note_history:50]
The net realized losses related to the Company's available-for-sale investments included impairment charges of zero and $26 million for the three and six months ended January 27, 2018, respectively. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2017.

- changed (2018-02-20):
[0000858877-18-000004:note_history:51]
As of January 27, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 27, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 27, 2018.
  (was, 2017-11-21, similarity 0.9385):
[0000858877-17-000019:note_history:51]
As of October 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 28, 2017.

- changed (2018-02-20):
[0000858877-18-000004:note_history:52]
The Company has evaluated its publicly traded equity securities as of January 27, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2017-11-21, similarity 0.9882):
[0000858877-17-000019:note_history:52]
The Company has evaluated its publicly traded equity securities as of October 28, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2018-02-20):
[0000858877-18-000004:note_history:53]
The following table summarizes the maturities of the Company’s fixed income securities as of January 27, 2018 (in millions):
  (was, 2017-11-21, similarity 0.9496):
[0000858877-17-000019:note_history:53]
The following table summarizes the maturities of the Company’s fixed income securities as of October 28, 2017 (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:54]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 27, 2018 and January 28, 2017 was $0.4 billion and $0.9 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 27, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.
  (was, 2017-11-21, similarity 0.9645):
[0000858877-17-000019:note_history:54]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 28, 2017 and October 29, 2016 was $0.5 billion and $1.2 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 28, 2017 and July 29, 2017, the Company had no outstanding securities lending transactions.

- changed (2018-02-20):
[0000858877-18-000004:note_history:55]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 27, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):
  (was, 2017-11-21, similarity 0.974):
[0000858877-17-000019:note_history:55]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 28, 2017 and July 29, 2017, the amounts are summarized in the following table (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:56]
|  | January 27, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 121 |  |  | $ | 124 |  |
| Cost method investments | 861 |  |  | 859 |  |
| Total | $ | 982 |  |  | $ | 983 |  |
  (was, 2017-11-21, similarity 0.9615):
[0000858877-17-000019:note_history:56]
|  | October 28, 2017 |  | July 29, 2017 |
| Equity method investments | $ | 108 |  |  | $ | 124 |  |
| Cost method investments | 839 |  |  | 859 |  |
| Total | $ | 947 |  |  | $ | 983 |  |

- changed (2018-02-20):
[0000858877-18-000004:note_history:57]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2017-11-21, similarity 0.9881):
[0000858877-17-000019:note_history:57]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2018-02-20):
[0000858877-18-000004:note_history:58]
As of January 27, 2018, the carrying value of investments in privately held companies was $982 million, of which $528 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $215 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.
  (was, 2017-11-21, similarity 0.9888):
[0000858877-17-000019:note_history:58]
As of October 28, 2017, the carrying value of investments in privately held companies was $947 million, of which $519 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $213 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2018-02-20):
[0000858877-17-000019:note_history:59]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 29 |  |  | $ | 5 |  |
| Net gains (losses) on investments in fixed income securities | 4 |  |  | 10 |  |
| Total | $ | 33 |  |  | $ | 15 |  |

- removed (2018-02-20):
[0000858877-17-000019:note_history:60]
For the three months ended October 28, 2017, the net realized losses related to available-for-sale investments included impairment charges of $26 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the three months ended October 29, 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: title_similarity, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:61]
|  |  |  | January 27, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 2.11% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.96% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.04% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.01% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.04% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.18% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.11% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.34% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.60% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.46% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.76% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (125 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (1 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,749 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,625 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2017-11-21, similarity 0.9942):
[0000858877-17-000019:note_history:61]
|  |  |  | October 28, 2017 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 1.98% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.70% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.88% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 1.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.85% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.85% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.01% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.28% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.13% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.44% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 62 |  |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,748 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,684 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:62]
As of January 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-11-21, similarity 0.9556):
[0000858877-17-000019:note_history:62]
As of October 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-02-20):
[0000858877-18-000004:note_history:63]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |
  (was, 2017-11-21, similarity 0.9836):
[0000858877-17-000019:note_history:63]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-20):
[0000858877-18-000004:note_history:64]
|  | January 27, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,749 |  |  | 1.78 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 8,992 |  |  | 1.51 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 13,741 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2017-11-21, similarity 0.9753):
[0000858877-17-000019:note_history:64]
|  | October 28, 2017 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,748 |  |  | 1.70 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 5,491 |  |  | 1.25 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 10,239 |  |  |  |  | $ | 7,992 |  |  |  |
