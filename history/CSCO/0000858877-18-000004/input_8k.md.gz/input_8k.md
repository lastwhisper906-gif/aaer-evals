# CSCO 8-K — 0001193125-18-045716 filed 2018-02-14

## item codes, every 8-K on or before 2018-02-20

- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2018-02-20

- none on or before 2018-02-20

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-045716:8k_2_02:1]
EX-99.1
2
d540218dex991.htm
EX-99.1

[0001193125-18-045716:8k_2_02:2]
EX-99.1

[0001193125-18-045716:8k_2_02:3]
Exhibit 99.1

[0001193125-18-045716:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-18-045716:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-18-045716:8k_2_02:6]
Dividend Increased 14 Percent, Additional $25 Billion Authorized for Stock Repurchase

[0001193125-18-045716:8k_2_02:7]
|  | • |  | Q2 Revenue: $11.9 billion |

[0001193125-18-045716:8k_2_02:8]
|  | • |  | Increase of 3% year over year |

[0001193125-18-045716:8k_2_02:9]
|  | • |  | Recurring revenue was 33% of total revenue, up 2 points year over year |

[0001193125-18-045716:8k_2_02:10]
|  | • |  | Q2 Earnings (Loss) per Share: $(1.78) GAAP; $0.63 non-GAAP |

[0001193125-18-045716:8k_2_02:11]
|  | • |  | GAAP results include an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act |

[0001193125-18-045716:8k_2_02:12]
|  | • |  | Q3 FY 2018 Guidance: |

[0001193125-18-045716:8k_2_02:13]
|  | • |  | Revenue: 3% to 5% growth year over year |

[0001193125-18-045716:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.50 to $0.55; Non-GAAP: $0.64 to $0.66 |

[0001193125-18-045716:8k_2_02:15]
SAN JOSE, Calif. — February 14, 2018 — Cisco today reported second quarter results for the period ended January 27, 2018. Cisco reported
second quarter revenue of $11.9 billion, net loss on a generally accepted accounting principles (GAAP) basis of $(8.8) billion or $(1.78) per share, and non-GAAP net income of $3.1 billion or $0.63
per share.

[0001193125-18-045716:8k_2_02:16]
“We had a great quarter which demonstrates that our strategy is working. Our business is growing, we have a fantastic innovation
pipeline, our balance sheet is strong and we have a team that’s executing incredibly well,” said Chuck Robbins, Chairman and CEO, Cisco. “The network is more critical to business success than ever, and our new intent-based networking
portfolio has great momentum including the fastest ramping new product in our history.”

[0001193125-18-045716:8k_2_02:17]
GAAP Results

[0001193125-18-045716:8k_2_02:18]
|  |  | Q2 FY 2018 |  |  | Q2 FY 2017 |  |  | Vs. Q2 FY 2017 |  |
| Revenue |  | $ | 11.9 billion |  |  | $ | 11.6 billion |  |  |  | 3 | % |
| Net Income (Loss) |  | $ | (8.8) billion |  |  | $ | 2.3 billion |  |  |  | (474 | )% |
| Earnings (Loss) per Share |  | $ | (1.78 | ) |  | $ | 0.47 |  |  |  | (479 | )% |

[0001193125-18-045716:8k_2_02:19]
GAAP results include an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act comprised of
$9.0 billion for the U.S. transition tax, $1.2 billion for foreign withholding tax and $0.9 billion for the re-measurement of net deferred tax assets.

[0001193125-18-045716:8k_2_02:20]
Non-GAAP Results

[0001193125-18-045716:8k_2_02:21]
|  |  | Q2 FY 2018 |  |  | Q2 FY 2017 |  |  | Vs. Q2 FY 2017 |  |
| Net Income |  | $ | 3.1 billion |  |  | $ | 2.9 billion |  |  |  | 10 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.63 |  |  | $ | 0.57 |  |  |  | 11 | % |

[0001193125-18-045716:8k_2_02:22]
Reconciliations between net income (loss), earnings (loss) per share, and other measures on a GAAP and non-GAAP basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-045716:8k_2_02:23]
1

[0001193125-18-045716:8k_2_02:24]
Cisco Increases Quarterly Cash Dividend; Stock Repurchase Program Authorization Increased

[0001193125-18-045716:8k_2_02:25]
Cisco has declared a quarterly dividend of $0.33 per common share, a 4-cent increase or up 14% over the previous
quarter’s dividend, to be paid on April 25, 2018 to all shareholders of record as of the close of business on April 5, 2018. Future dividends will be subject to Board approval.

[0001193125-18-045716:8k_2_02:26]
Cisco’s board of directors has also approved a $25 billion increase to the authorization of the stock repurchase program. There is no fixed termination
date for the repurchase program. The remaining authorized amount for stock repurchases including the additional authorization is approximately $31 billion.

[0001193125-18-045716:8k_2_02:27]
“Q2 was a great quarter with 3% revenue growth and strong margins and cash flow,” said Kelly Kramer, CFO of Cisco. “We continue to make
progress as we shift the business toward more software and recurring revenue. Our significant dividend increase and additional share repurchase authorization reinforce our commitment to returning capital to our shareholders and show confidence in
the strength of our ongoing cash flows.”

[0001193125-18-045716:8k_2_02:28]
Financial Summary

[0001193125-18-045716:8k_2_02:29]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-18-045716:8k_2_02:30]
Q2 FY 2018 Highlights

[0001193125-18-045716:8k_2_02:31]
Revenue — Total
revenue was $11.9 billion, up 3%, with product revenue up 3% and service revenue up 3%. 33% of total revenue was from recurring offers, up 2 percentage points from the second quarter of fiscal 2017. Revenue by geographic segment was: Americas
up 5%, EMEA flat, and APJC down 2%. Product revenue performance reflected solid growth in Applications and Security, which each increased 6%. Infrastructure Platforms increased by 2%.

[0001193125-18-045716:8k_2_02:32]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 63.1% and 61.5%, respectively. Product gross margin
increased compared with 61.1% in the second quarter of fiscal 2017.

[0001193125-18-045716:8k_2_02:33]
Non-GAAP total gross margin and product gross
margin were 64.7% and 63.3%, respectively. Non-GAAP product gross margin increased compared with 62.4% in the second quarter of fiscal 2017. The increase was primarily due to improved productivity benefits and
to a lesser extent product mix, partially offset by pricing.

[0001193125-18-045716:8k_2_02:34]
GAAP service gross margin was 67.4% and non-GAAP
service gross margin was 68.5%.

[0001193125-18-045716:8k_2_02:35]
Total gross margins by geographic segment were: 65.9% for the Americas, 64.6% for EMEA and 60.1% for APJC.

[0001193125-18-045716:8k_2_02:36]
Operating Expenses — On a GAAP basis, operating expenses were $4.4 billion, up 1%.
Non-GAAP operating expenses were $3.9 billion, up 2%, and were 32.9% of revenue.

[0001193125-18-045716:8k_2_02:37]
Operating Income
— GAAP operating income was $3.1 billion, up 6%, with GAAP operating margin of 25.9%. Non-GAAP operating income was $3.8 billion, up 5%, with
non-GAAP operating margin of 31.7%.

[0001193125-18-045716:8k_2_02:38]
Provision for Income Taxes — The GAAP tax provision rate
was 371.6% which includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. The non-GAAP tax provision rate was 20.0%.

[0001193125-18-045716:8k_2_02:39]
Net Income (Loss) and Earnings (Loss) per Share — On a GAAP basis, net loss was $(8.8) billion and earnings (loss) per share was $(1.78).
On a non-GAAP basis, net income was $3.1 billion, an increase of 10%, and EPS was $0.63, an increase of 11%.

[0001193125-18-045716:8k_2_02:40]
Cash Flow from Operating Activities — was $4.1 billion, an increase of 8% compared with $3.8 billion for the second quarter of
fiscal 2017.

[0001193125-18-045716:8k_2_02:41]
Balance Sheet and Other Financial Highlights

[0001193125-18-045716:8k_2_02:42]
Cash and Cash Equivalents and Investments — were $73.7 billion at the end of the second quarter of fiscal 2018, compared with
$71.6 billion at the end of the first quarter of fiscal 2018, and compared with $70.5 billion at the end of fiscal 2017. The total cash and cash equivalents and investments available in the United States at the end of the second quarter of
fiscal 2018 were $2.4 billion.

[0001193125-18-045716:8k_2_02:43]
Deferred Revenue — was $18.8 billion, up 10% in total, with deferred product revenue up 19%,
driven largely by subscription-based and software offers, and deferred service revenue was up 4%. The portion of deferred product revenue related to recurring software and subscription offers increased 36%.

[0001193125-18-045716:8k_2_02:44]
2

[0001193125-18-045716:8k_2_02:45]
Capital Allocation — In the second quarter of fiscal 2018, Cisco declared and paid a cash
dividend of $0.29 per common share, or $1.4 billion. For the second quarter of fiscal 2018, Cisco repurchased approximately 103 million shares of common stock under its stock repurchase program at an average price of $39.07 per share for
an aggregate purchase price of $4.0 billion.

[0001193125-18-045716:8k_2_02:46]
Acquisitions

[0001193125-18-045716:8k_2_02:47]
In the first quarter of fiscal 2018, we announced a definitive agreement to acquire BroadSoft, Inc., a publicly held company that offers cloud calling and
contact center solutions. The BroadSoft acquisition closed in the third quarter of fiscal 2018.

[0001193125-18-045716:8k_2_02:48]
On January 24, 2018, we announced our intent to
acquire Skyport Systems, Inc., a privately held company providing cloud-managed, hyper-converged systems that run and protect business critical applications. The Skyport acquisition closed in the third quarter of fiscal 2018.

[0001193125-18-045716:8k_2_02:49]
3

[0001193125-18-045716:8k_2_02:50]
Guidance for Q3 FY 2018

[0001193125-18-045716:8k_2_02:51]
Cisco expects to achieve the following results for the third quarter of fiscal 2018:

[0001193125-18-045716:8k_2_02:52]
| Q3 FY 2018 |  |  |
| Revenue |  | 3% - 5% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29.5% - 30.5% |
| Non-GAAP tax provision rate |  | 21% |
| Non-GAAP EPS |  | $0.64 - $0.66 |

[0001193125-18-045716:8k_2_02:53]
The impact of the BroadSoft acquisition is factored into our guidance.

[0001193125-18-045716:8k_2_02:54]
Cisco estimates that GAAP EPS will be $0.50 to $0.55 in the third quarter of fiscal 2018.

[0001193125-18-045716:8k_2_02:55]
A reconciliation between the Guidance for Q3 FY 2018 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q3 FY 2018” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-045716:8k_2_02:56]
Editor’s Notes:

[0001193125-18-045716:8k_2_02:57]
|  | • |  | Q2 fiscal year 2018 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, February 14, 2018 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-18-045716:8k_2_02:58]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 14, 2018 to 4:00 p.m. Pacific Time, February 21, 2018 at 1-800-391-9854 (United States) or 1-402-220-9828 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-045716:8k_2_02:59]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 14, 2018. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-045716:8k_2_02:60]
4

[0001193125-18-045716:8k_2_02:61]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:62]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-045716:8k_2_02:63]
(In millions, except per-share amounts)

[0001193125-18-045716:8k_2_02:64]
(Unaudited)

[0001193125-18-045716:8k_2_02:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 27,2018 |  |  | January 28,2017 |  |  | January 27,2018 |  |  | January 28,2017 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,709 |  |  | $ | 8,491 |  |  | $ | 17,763 |  |  | $ | 17,793 |  |
| Service |  |  | 3,178 |  |  |  | 3,089 |  |  |  | 6,260 |  |  |  | 6,139 |  |
| Total revenue |  |  | 11,887 |  |  |  | 11,580 |  |  |  | 24,023 |  |  |  | 23,932 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,354 |  |  |  | 3,305 |  |  |  | 6,969 |  |  |  | 6,708 |  |
| Service |  |  | 1,035 |  |  |  | 999 |  |  |  | 2,129 |  |  |  | 2,064 |  |
| Total cost of sales |  |  | 4,389 |  |  |  | 4,304 |  |  |  | 9,098 |  |  |  | 8,772 |  |
| GROSS MARGIN |  |  | 7,498 |  |  |  | 7,276 |  |  |  | 14,925 |  |  |  | 15,160 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,549 |  |  |  | 1,508 |  |  |  | 3,116 |  |  |  | 3,053 |  |
| Sales and marketing |  |  | 2,235 |  |  |  | 2,222 |  |  |  | 4,569 |  |  |  | 4,640 |  |
| General and administrative |  |  | 483 |  |  |  | 456 |  |  |  | 1,040 |  |  |  | 1,011 |  |
| Amortization of purchased intangible assets |  |  | 60 |  |  |  | 64 |  |  |  | 121 |  |  |  | 142 |  |
| Restructuring and other charges |  |  | 98 |  |  |  | 133 |  |  |  | 250 |  |  |  | 544 |  |
| Total operating expenses |  |  | 4,425 |  |  |  | 4,383 |  |  |  | 9,096 |  |  |  | 9,390 |  |
| OPERATING INCOME |  |  | 3,073 |  |  |  | 2,893 |  |  |  | 5,829 |  |  |  | 5,770 |  |
| Interest income |  |  | 396 |  |  |  | 329 |  |  |  | 775 |  |  |  | 624 |  |
| Interest expense |  |  | (247 | ) |  |  | (222 | ) |  |  | (482 | ) |  |  | (420 | ) |
| Other income (loss), net |  |  | 10 |  |  |  | (37 | ) |  |  | 72 |  |  |  | (58 | ) |
| Interest and other income (loss), net |  |  | 159 |  |  |  | 70 |  |  |  | 365 |  |  |  | 146 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,232 |  |  |  | 2,963 |  |  |  | 6,194 |  |  |  | 5,916 |  |
| Provision for income taxes (1) |  |  | 12,010 |  |  |  | 615 |  |  |  | 12,578 |  |  |  | 1,246 |  |
| NET INCOME (LOSS) |  | $ | (8,778 | ) |  | $ | 2,348 |  |  | $ | (6,384 | ) |  | $ | 4,670 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.78 | ) |  | $ | 0.47 |  |  | $ | (1.29 | ) |  | $ | 0.93 |  |
| Diluted |  | $ | (1.78 | ) |  | $ | 0.47 |  |  | $ | (1.29 | ) |  | $ | 0.92 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,924 |  |  |  | 5,015 |  |  |  | 4,942 |  |  |  | 5,021 |  |
| Diluted |  |  | 4,924 |  |  |  | 5,040 |  |  |  | 4,942 |  |  |  | 5,054 |  |
| Cash dividends declared per common share |  | $ | 0.29 |  |  | $ | 0.26 |  |  | $ | 0.58 |  |  | $ | 0.52 |  |

[0001193125-18-045716:8k_2_02:66]
| (1) | The provision for income taxes includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-045716:8k_2_02:67]
5

[0001193125-18-045716:8k_2_02:68]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:69]
REVENUE BY SEGMENT

[0001193125-18-045716:8k_2_02:70]
(In
millions, except percentages)

[0001193125-18-045716:8k_2_02:71]
|  |  | January 27, 2018 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,004 |  |  |  | 5 | % |  | $ | 14,354 |  |  |  | 2 | % |
| EMEA |  |  | 3,062 |  |  |  | — | % |  |  | 5,971 |  |  |  | (2 | )% |
| APJC |  |  | 1,821 |  |  |  | (2 | )% |  |  | 3,698 |  |  |  | (1 | )% |
| Total |  | $ | 11,887 |  |  |  | 3 | % |  | $ | 24,023 |  |  |  | — | % |

[0001193125-18-045716:8k_2_02:72]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:73]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-18-045716:8k_2_02:74]
(In percentages)

[0001193125-18-045716:8k_2_02:75]
|  |  | January 27, 2018 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.9 | % |  |  | 65.0 | % |
| EMEA |  |  | 64.6 | % |  |  | 63.9 | % |
| APJC |  |  | 60.1 | % |  |  | 61.1 | % |

[0001193125-18-045716:8k_2_02:76]
6

[0001193125-18-045716:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:78]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-18-045716:8k_2_02:79]
(In millions, except percentages)

[0001193125-18-045716:8k_2_02:80]
|  |  | January 27, 2018 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,694 |  |  |  | 2 | % |  | $ | 13,664 |  |  |  | (1 | )% |
| Applications |  |  | 1,184 |  |  |  | 6 | % |  |  | 2,387 |  |  |  | 6 | % |
| Security |  |  | 558 |  |  |  | 6 | % |  |  | 1,143 |  |  |  | 7 | % |
| Other Products |  |  | 273 |  |  |  | (10 | )% |  |  | 569 |  |  |  | (13 | )% |
| Total Product |  |  | 8,709 |  |  |  | 3 | % |  |  | 17,763 |  |  |  | — | % |
| Services |  |  | 3,178 |  |  |  | 3 | % |  |  | 6,260 |  |  |  | 2 | % |
| Total |  | $ | 11,887 |  |  |  | 3 | % |  | $ | 24,023 |  |  |  | — | % |

[0001193125-18-045716:8k_2_02:81]
7

[0001193125-18-045716:8k_2_02:82]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:83]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-045716:8k_2_02:84]
(In millions)

[0001193125-18-045716:8k_2_02:85]
(Unaudited)

[0001193125-18-045716:8k_2_02:86]
|  |  | January 27, 2018 |  |  | July 29, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 17,624 |  |  | $ | 11,708 |  |
| Investments |  |  | 56,059 |  |  |  | 58,784 |  |
| Accounts receivable, net of allowance for doubtful accounts of $181 at January 27, 2018 and $211 at July 29, 2017 |  |  | 3,963 |  |  |  | 5,146 |  |
| Inventories |  |  | 1,896 |  |  |  | 1,616 |  |
| Financing receivables, net |  |  | 4,925 |  |  |  | 4,856 |  |
| Other current assets |  |  | 1,583 |  |  |  | 1,593 |  |
| Total current assets |  |  | 86,050 |  |  |  | 83,703 |  |
| Property and equipment, net |  |  | 3,113 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 4,913 |  |  |  | 4,738 |  |
| Goodwill |  |  | 30,391 |  |  |  | 29,766 |  |
| Purchased intangible assets, net |  |  | 2,474 |  |  |  | 2,539 |  |
| Deferred tax assets |  |  | 3,097 |  |  |  | 4,239 |  |
| Other assets |  |  | 1,472 |  |  |  | 1,511 |  |
| TOTAL ASSETS |  | $ | 131,510 |  |  | $ | 129,818 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 13,741 |  |  | $ | 7,992 |  |
| Accounts payable |  |  | 1,060 |  |  |  | 1,385 |  |
| Income taxes payable |  |  | 2,204 |  |  |  | 98 |  |
| Accrued compensation |  |  | 2,736 |  |  |  | 2,895 |  |
| Deferred revenue |  |  | 11,102 |  |  |  | 10,821 |  |
| Other current liabilities |  |  | 4,521 |  |  |  | 4,392 |  |
| Total current liabilities |  |  | 35,364 |  |  |  | 27,583 |  |
| Long-term debt |  |  | 25,625 |  |  |  | 25,725 |  |
| Income taxes payable |  |  | 9,185 |  |  |  | 1,250 |  |
| Deferred revenue |  |  | 7,686 |  |  |  | 7,673 |  |
| Other long-term liabilities |  |  | 1,668 |  |  |  | 1,450 |  |
| Total liabilities |  |  | 79,528 |  |  |  | 63,681 |  |
| Total equity |  |  | 51,982 |  |  |  | 66,137 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 131,510 |  |  | $ | 129,818 |  |

[0001193125-18-045716:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:88]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-045716:8k_2_02:89]
(In millions)

[0001193125-18-045716:8k_2_02:90]
(Unaudited)

[0001193125-18-045716:8k_2_02:91]
|  |  | Six Months Ended |  |
|  |  | January 27,2018 |  |  | January 28,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (6,384 | ) |  | $ | 4,670 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,112 |  |  |  | 1,148 |  |
| Share-based compensation expense |  |  | 785 |  |  |  | 724 |  |
| Provision for receivables |  |  | (43 | ) |  |  | 4 |  |
| Deferred income taxes |  |  | 1,021 |  |  |  | (26 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | (101 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (174 | ) |  |  | 79 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,236 |  |  |  | 1,396 |  |
| Inventories |  |  | (276 | ) |  |  | (51 | ) |
| Financing receivables |  |  | (156 | ) |  |  | (764 | ) |
| Other assets |  |  | (15 | ) |  |  | 155 |  |
| Accounts payable |  |  | (338 | ) |  |  | (98 | ) |
| Income taxes, net |  |  | 10,246 |  |  |  | (257 | ) |
| Accrued compensation |  |  | (189 | ) |  |  | (417 | ) |
| Deferred revenue |  |  | 237 |  |  |  | 611 |  |
| Other liabilities |  |  | 88 |  |  |  | (571 | ) |
| Net cash provided by operating activities |  |  | 7,150 |  |  |  | 6,502 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (13,954 | ) |  |  | (27,847 | ) |
| Proceeds from sales of investments |  |  | 9,111 |  |  |  | 18,420 |  |
| Proceeds from maturities of investments |  |  | 7,365 |  |  |  | 5,245 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (754 | ) |  |  | (251 | ) |
| Proceeds from business divestitures |  |  | 27 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (89 | ) |  |  | (142 | ) |
| Return of investments in privately held companies |  |  | 124 |  |  |  | 108 |  |
| Acquisition of property and equipment |  |  | (379 | ) |  |  | (526 | ) |
| Proceeds from sales of property and equipment |  |  | 51 |  |  |  | 5 |  |
| Other |  |  | (7 | ) |  |  | 10 |  |
| Net cash provided by (used in) investing activities |  |  | 1,495 |  |  |  | (4,978 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 302 |  |  |  | 386 |  |
| Repurchases of common stock - repurchase program |  |  | (5,457 | ) |  |  | (1,991 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (433 | ) |  |  | (432 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 5,095 |  |  |  | 300 |  |
| Issuances of debt |  |  | 6,877 |  |  |  | 6,232 |  |
| Repayments of debt |  |  | (6,230 | ) |  |  | (1 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | 101 |  |
| Dividends paid |  |  | (2,861 | ) |  |  | (2,612 | ) |
| Other |  |  | (22 | ) |  |  | (240 | ) |
| Net cash provided by (used in) financing activities |  |  | (2,729 | ) |  |  | 1,743 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 5,916 |  |  |  | 3,267 |  |
| Cash and cash equivalents, beginning of period |  |  | 11,708 |  |  |  | 7,631 |  |
| Cash and cash equivalents, end of period |  | $ | 17,624 |  |  | $ | 10,898 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 454 |  |  | $ | 419 |  |
| Cash paid for income taxes, net |  | $ | 1,311 |  |  | $ | 1,529 |  |

[0001193125-18-045716:8k_2_02:92]
9

[0001193125-18-045716:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:94]
DEFERRED REVENUE

[0001193125-18-045716:8k_2_02:95]
(In
millions)

[0001193125-18-045716:8k_2_02:96]
|  |  | January 27,2018 |  |  | October 28,2017 |  |  | January 28,2017 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,963 |  |  | $ | 10,991 |  |  | $ | 10,525 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  |  | 5,451 |  |  |  | 5,213 |  |  |  | 3,997 |  |
| Other product deferred revenue |  |  | 2,374 |  |  |  | 2,361 |  |  |  | 2,564 |  |
| Total product deferred revenue |  |  | 7,825 |  |  |  | 7,574 |  |  |  | 6,561 |  |
| Total |  | $ | 18,788 |  |  | $ | 18,565 |  |  | $ | 17,086 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,102 |  |  | $ | 10,920 |  |  | $ | 10,243 |  |
| Noncurrent |  |  | 7,686 |  |  |  | 7,645 |  |  |  | 6,843 |  |
| Total |  | $ | 18,788 |  |  | $ | 18,565 |  |  | $ | 17,086 |  |

[0001193125-18-045716:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:98]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-18-045716:8k_2_02:99]
(In millions, except per-share amounts)

[0001193125-18-045716:8k_2_02:100]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0001193125-18-045716:8k_2_02:101]
10

[0001193125-18-045716:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:103]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-045716:8k_2_02:104]
GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001193125-18-045716:8k_2_02:105]
(In millions, except per-share amounts)

[0001193125-18-045716:8k_2_02:106]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 27,2018 |  |  | January 28,2017 |  |  | January 27,2018 |  |  | January 28,2017 |  |
| GAAP net income (loss) |  | $ | (8,778 | ) |  | $ | 2,348 |  |  | $ | (6,384 | ) |  | $ | 4,670 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 54 |  |  |  | 53 |  |  |  | 111 |  |  |  | 107 |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | 107 |  |  |  | 283 |  |  |  | 219 |  |
| Supplier component remediation charge (adjustment), net |  |  | (13 | ) |  |  | (16 | ) |  |  | (32 | ) |  |  | (16 | ) |
| Acquisition-related/divestiture costs |  |  | 2 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 122 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 187 |  |  |  | 145 |  |  |  | 486 |  |  |  | 311 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 333 |  |  |  | 299 |  |  |  | 668 |  |  |  | 614 |  |
| Amortization of acquisition-related intangible assets |  |  | 60 |  |  |  | 64 |  |  |  | 121 |  |  |  | 142 |  |
| Acquisition-related/divestiture costs |  |  | 23 |  |  |  | 61 |  |  |  | 106 |  |  |  | 114 |  |
| Significant asset impairments and restructurings |  |  | 98 |  |  |  | 133 |  |  |  | 250 |  |  |  | 544 |  |
| Total adjustments to GAAP operating expenses |  |  | 514 |  |  |  | 557 |  |  |  | 1,145 |  |  |  | 1,414 |  |
| Total adjustments to GAAP income (loss) before provision for income taxes |  |  | 701 |  |  |  | 702 |  |  |  | 1,631 |  |  |  | 1,725 |  |
| Income tax effect of non-GAAP adjustments |  |  | (157 | ) |  |  | (191 | ) |  |  | (445 | ) |  |  | (435 | ) |
| Significant tax matters (1) |  |  | 11,380 |  |  |  | — |  |  |  | 11,380 |  |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | 11,223 |  |  |  | (191 | ) |  |  | 10,935 |  |  |  | (435 | ) |
| Non-GAAP net income |  | $ | 3,146 |  |  | $ | 2,859 |  |  | $ | 6,182 |  |  | $ | 5,960 |  |
| Net income (loss) per share: (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | (1.78 | ) |  | $ | 0.47 |  |  | $ | (1.29 | ) |  | $ | 0.92 |  |
| Non-GAAP |  | $ | 0.63 |  |  | $ | 0.57 |  |  | $ | 1.24 |  |  | $ | 1.18 |  |

[0001193125-18-045716:8k_2_02:107]
| (1) | During the second quarter of fiscal 2018, Cisco recorded charges relating to significant tax matters that were excluded from non-GAAP net income for the second quarter and first six months of fiscal 2018. $11.1 billion of these charges were provisional amounts related to the enactment of the Tax Cuts and Jobs Act comprised of $9.0 billion related to the U.S. transition tax, $1.2 billion related to foreign withholding tax and $0.9 billion related to the re-measurement of net deferred tax assets. The amounts are provisional based on Securities and Exchange Commission Staff Accounting Bulletin No. 118. The remaining $0.3 billion was related to other significant tax matters. |

[0001193125-18-045716:8k_2_02:108]
| (2) | GAAP net loss per share for the three and six months ended January 27, 2018 is calculated using basic shares of 4,924 million and 4,942 million respectively, due to the net loss resulting from the tax charge as discussed in footnote (1). Non-GAAP net income per share for the respective periods is calculated using diluted shares of 4,966 million and 4,982 million, as the Company had non-GAAP net income for these periods. |

[0001193125-18-045716:8k_2_02:109]
11

[0001193125-18-045716:8k_2_02:110]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:111]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-045716:8k_2_02:112]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME (LOSS)

[0001193125-18-045716:8k_2_02:113]
(In millions, except percentages)

[0001193125-18-045716:8k_2_02:114]
|  |  | Three Months Ended |  |
|  |  | January 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome(Loss) |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,355 |  |  | $ | 2,143 |  |  | $ | 7,498 |  |  | $ | 4,425 |  |  |  | 1 | % |  | $ | 3,073 |  |  |  | 6 | % |  | $ | (8,778 | ) |  |  | (474 | )% |
| % of revenue |  |  | 61.5 | % |  |  | 67.4 | % |  |  | 63.1 | % |  |  | 37.2 | % |  |  |  |  |  |  | 25.9 | % |  |  |  |  |  |  | (73.8 | )% |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 31 |  |  |  | 54 |  |  |  | 333 |  |  |  |  |  |  |  | 387 |  |  |  |  |  |  |  | 387 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | — |  |  |  | 144 |  |  |  | 60 |  |  |  |  |  |  |  | 204 |  |  |  |  |  |  |  | 204 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (13 | ) |  |  | — |  |  |  | (13 | ) |  |  | — |  |  |  |  |  |  |  | (13 | ) |  |  |  |  |  |  | (13 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 23 |  |  |  |  |  |  |  | 25 |  |  |  |  |  |  |  | 25 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 98 |  |  |  |  |  |  |  | 98 |  |  |  |  |  |  |  | 98 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 11,223 | (1) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,509 |  |  | $ | 2,176 |  |  | $ | 7,685 |  |  | $ | 3,911 |  |  |  | 2 | % |  | $ | 3,774 |  |  |  | 5 | % |  | $ | 3,146 |  |  |  | 10 | % |
| % of revenue |  |  | 63.3 | % |  |  | 68.5 | % |  |  | 64.7 | % |  |  | 32.9 | % |  |  |  |  |  |  | 31.7 | % |  |  |  |  |  |  | 26.5 | % |  |  |  |  |

[0001193125-18-045716:8k_2_02:115]
| (1) | Includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-045716:8k_2_02:116]
|  |  | Three Months Ended |  |
|  |  | January 28, 2017 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,186 |  |  | $ | 2,090 |  |  | $ | 7,276 |  |  | $ | 4,383 |  |  | $ | 2,893 |  |  | $ | 2,348 |  |
| % of revenue |  |  | 61.1 | % |  |  | 67.7 | % |  |  | 62.8 | % |  |  | 37.8 | % |  |  | 25.0 | % |  |  | 20.3 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 19 |  |  |  | 34 |  |  |  | 53 |  |  |  | 299 |  |  |  | 352 |  |  |  | 352 |  |
| Amortization of acquisition-related intangible assets |  |  | 107 |  |  |  | — |  |  |  | 107 |  |  |  | 64 |  |  |  | 171 |  |  |  | 171 |  |
| Supplier component remediation charge (adjustment), net |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | (16 | ) |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 61 |  |  |  | 62 |  |  |  | 62 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |  |  | 133 |  |  |  | 133 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (191 | ) |
| Non-GAAP amount |  | $ | 5,296 |  |  | $ | 2,125 |  |  | $ | 7,421 |  |  | $ | 3,826 |  |  | $ | 3,595 |  |  | $ | 2,859 |  |
| % of revenue |  |  | 62.4 | % |  |  | 68.8 | % |  |  | 64.1 | % |  |  | 33.0 | % |  |  | 31.0 | % |  |  | 24.7 | % |

[0001193125-18-045716:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:118]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-045716:8k_2_02:119]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME (LOSS)

[0001193125-18-045716:8k_2_02:120]
(In millions, except percentages)

[0001193125-18-045716:8k_2_02:121]
|  |  | Six Months Ended |  |
|  |  | January 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome(Loss) |  |  | Y/Y |  |
| GAAP amount |  | $ | 10,794 |  |  | $ | 4,131 |  |  | $ | 14,925 |  |  | $ | 9,096 |  |  |  | (3 | )% |  | $ | 5,829 |  |  |  | 1 | % |  | $ | (6,384 | ) |  |  | (237 | )% |
| % of revenue |  |  | 60.8 | % |  |  | 66.0 | % |  |  | 62.1 | % |  |  | 37.9 | % |  |  |  |  |  |  | 24.3 | % |  |  |  |  |  |  | (26.6 | )% |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 46 |  |  |  | 65 |  |  |  | 111 |  |  |  | 668 |  |  |  |  |  |  |  | 779 |  |  |  |  |  |  |  | 779 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 283 |  |  |  | — |  |  |  | 283 |  |  |  | 121 |  |  |  |  |  |  |  | 404 |  |  |  |  |  |  |  | 404 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (32 | ) |  |  | — |  |  |  | (32 | ) |  |  | — |  |  |  |  |  |  |  | (32 | ) |  |  |  |  |  |  | (32 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  |  |  |  |  | 122 |  |  |  |  |  |  |  | 122 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 106 |  |  |  |  |  |  |  | 108 |  |  |  |  |  |  |  | 108 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 250 |  |  |  |  |  |  |  | 250 |  |  |  |  |  |  |  | 250 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 10,935 | (1) |  |  |  |  |
| Non-GAAP amount |  | $ | 11,213 |  |  | $ | 4,198 |  |  | $ | 15,411 |  |  | $ | 7,951 |  |  |  | — | % |  | $ | 7,460 |  |  |  | — | % |  | $ | 6,182 |  |  |  | 4 | % |
| % of revenue |  |  | 63.1 | % |  |  | 67.1 | % |  |  | 64.2 | % |  |  | 33.1 | % |  |  |  |  |  |  | 31.1 | % |  |  |  |  |  |  | 25.7 | % |  |  |  |  |

[0001193125-18-045716:8k_2_02:122]
| (1) | Includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-045716:8k_2_02:123]
|  |  | Six Months Ended |  |
|  |  | January 28, 2017 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 11,085 |  |  | $ | 4,075 |  |  | $ | 15,160 |  |  | $ | 9,390 |  |  | $ | 5,770 |  |  | $ | 4,670 |  |
| % of revenue |  |  | 62.3 | % |  |  | 66.4 | % |  |  | 63.3 | % |  |  | 39.2 | % |  |  | 24.1 | % |  |  | 19.5 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 40 |  |  |  | 67 |  |  |  | 107 |  |  |  | 614 |  |  |  | 721 |  |  |  | 721 |  |
| Amortization of acquisition-related intangible assets |  |  | 219 |  |  |  | — |  |  |  | 219 |  |  |  | 142 |  |  |  | 361 |  |  |  | 361 |  |
| Supplier component remediation charge (adjustment), net |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | (16 | ) |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 114 |  |  |  | 115 |  |  |  | 115 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 544 |  |  |  | 544 |  |  |  | 544 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (435 | ) |
| Non-GAAP amount |  | $ | 11,328 |  |  | $ | 4,143 |  |  | $ | 15,471 |  |  | $ | 7,976 |  |  | $ | 7,495 |  |  | $ | 5,960 |  |
| % of revenue |  |  | 63.7 | % |  |  | 67.5 | % |  |  | 64.6 | % |  |  | 33.3 | % |  |  | 31.3 | % |  |  | 24.9 | % |

[0001193125-18-045716:8k_2_02:124]
13

[0001193125-18-045716:8k_2_02:125]
CISCO SYSTEMS, INC.

[0001193125-18-045716:8k_2_02:126]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-045716:8k_2_02:127]
EFFECTIVE TAX RATE

[0001193125-18-045716:8k_2_02:128]
(In
percentages)

[0001193125-18-045716:8k_2_02:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 27, 2018 |  |  | January 28, 2017 |  |  | January 27, 2018 |  |  | January 28, 2017 |  |
| GAAP effective tax rate (1) |  |  | 371.6% |  |  |  | 20.8% |  |  |  | 203.1% |  |  |  | 21.1% |  |
| Total adjustments to GAAP provision for income taxes |  |  | (351.6)% |  |  |  | 1.2% |  |  |  | (182.1)% |  |  |  | 0.9% |  |
| Non-GAAP effective tax rate |  |  | 20.0% |  |  |  | 22.0% |  |  |  | 21.0% |  |  |  | 22.0% |  |

[0001193125-18-045716:8k_2_02:130]
| (1) | Includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-045716:8k_2_02:131]
GAAP TO NON-GAAP GUIDANCE FOR Q3 FY 2018

[0001193125-18-045716:8k_2_02:132]
| Q3 FY 2018 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |  |
| GAAP |  | 61.5% - 62.5% |  | 24%- 25% |  | 22% |  | $ | 0.50 - $0.55 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | — |  | $ | 0.06 - $0.07 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.0% |  | — |  | $ | 0.05 - $0.06 |  |
| Restructuring and other charges (1) |  | — |  | — |  | — |  | $ | 0.00 - $0.01 |  |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | (1)% |  |  |  |  |
| Non-GAAP |  | 63% - 64% |  | 29.5% - 30.5% |  | 21% |  | $ | 0.64 - $0.66 |  |

[0001193125-18-045716:8k_2_02:133]
| (1) | In August 2016, we began taking action under a restructuring plan in order to reinvest in our key priority areas. We have incurred charges of approximately $1.0 billion in relation to this plan since its inception through Q2 FY2018. We have a small amount of charges that remain which will be recognized over the remainder of the fiscal year. |

[0001193125-18-045716:8k_2_02:134]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-18-045716:8k_2_02:135]
The impact of the
BroadSoft acquisition is factored into our guidance.

[0001193125-18-045716:8k_2_02:136]
Except as noted above, this guidance does not include the effects of any future
acquisitions/divestitures, asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-18-045716:8k_2_02:137]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-18-045716:8k_2_02:138]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, and
non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-18-045716:8k_2_02:139]
These non-GAAP measures are not in accordance with, or an
alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect
all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP
measures.

[0001193125-18-045716:8k_2_02:140]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-18-045716:8k_2_02:141]
15

[0001193125-18-045716:8k_2_02:142]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when
applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies,
significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-18-045716:8k_2_02:143]
About Cisco

[0001193125-18-045716:8k_2_02:144]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-18-045716:8k_2_02:145]
Copyright © 2018 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
