# CSCO MD&A — 0000858877-18-000004


## mdna

[0000858877-18-000004:mdna:1]
[same as prior period, unchanged from 0000858877-17-000019:mdna:1]

[0000858877-18-000004:mdna:2]
[same as prior period, unchanged from 0000858877-17-000019:mdna:2]

[0000858877-18-000004:mdna:3]
[same as prior period, unchanged from 0000858877-17-000019:mdna:3]

[0000858877-18-000004:mdna:4]
[same as prior period, unchanged from 0000858877-17-000019:mdna:4]

[0000858877-18-000004:mdna:5]
[same as prior period, unchanged from 0000858877-17-000019:mdna:5]

[0000858877-18-000004:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 27, 2018 |  | January 28, 2017 |  | Variance |  |  | January 27, 2018 |  | January 28, 2017 |  | Variance |  |
| Revenue | $ | 11,887 |  |  | $ | 11,580 |  |  | 3 | % |  |  | $ | 24,023 |  |  | $ | 23,932 |  |  | — | % |  |
| Gross margin percentage | 63.1 | % |  | 62.8 | % |  | 0.3 |  | pts |  | 62.1 | % |  | 63.3 | % |  | (1.2 | ) | pts |
| Research and development | $ | 1,549 |  |  | $ | 1,508 |  |  | 3 | % |  |  | $ | 3,116 |  |  | $ | 3,053 |  |  | 2 | % |  |
| Sales and marketing | $ | 2,235 |  |  | $ | 2,222 |  |  | 1 | % |  |  | $ | 4,569 |  |  | $ | 4,640 |  |  | (2 | )% |  |
| General and administrative | $ | 483 |  |  | $ | 456 |  |  | 6 | % |  |  | $ | 1,040 |  |  | $ | 1,011 |  |  | 3 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,267 |  |  | $ | 4,186 |  |  | 2 | % |  |  | $ | 8,725 |  |  | $ | 8,704 |  |  | — | % |  |
| Total as a percentage of revenue | 35.9 | % |  | 36.1 | % |  | (0.2 | ) | pts |  | 36.3 | % |  | 36.4 | % |  | (0.1 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 60 |  |  | $ | 64 |  |  | (6 | )% |  |  | $ | 121 |  |  | $ | 142 |  |  | (15 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 98 |  |  | $ | 133 |  |  | (26 | )% |  |  | $ | 250 |  |  | $ | 544 |  |  | (54 | )% |  |
| Operating income as a percentage of revenue | 25.9 | % |  | 25.0 | % |  | 0.9 |  | pts |  | 24.3 | % |  | 24.1 | % |  | 0.2 |  | pts |
| Income tax percentage | 371.6 | % |  | 20.8 | % |  | 350.8 |  | pts |  | 203.1 | % |  | 21.1 | % |  | 182.0 |  | pts |
| Net income (loss) | $ | (8,778 | ) |  | $ | 2,348 |  |  | (474 | )% |  |  | $ | (6,384 | ) |  | $ | 4,670 |  |  | (237 | )% |  |
| Net income (loss) as a percentage of revenue | (73.8 | )% |  | 20.3 | % |  | (94.1 | ) | pts |  | (26.6 | )% |  | 19.5 | % |  | (46.1 | ) | pts |
| Earnings (loss) per share | $ | (1.78 | ) |  | $ | 0.47 |  |  | (479 | )% |  |  | $ | (1.29 | ) |  | $ | 0.92 |  |  | (240 | )% |  |

[0000858877-18-000004:mdna:7]
[same as prior period, unchanged from 0000858877-17-000019:mdna:8]

[0000858877-18-000004:mdna:8]
[same as prior period, unchanged from 0000858877-17-000019:mdna:9]

[0000858877-18-000004:mdna:9]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:10]
In the second quarter of fiscal 2018, we saw broad strength across the business and delivered solid revenue growth, strong margins and operating cash flows.  We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We experienced solid revenue growth in Security and Applications and modest growth in Infrastructure Platforms, and we continued to make progress in the transition of our business model to increased software and subscriptions. We continue to operate in a challenging and highly competitive environment, which has negatively impacted certain of our offerings within our Infrastructure Platforms product category. We continued to see weakness in the service provider market and we expect ongoing uncertainty in that area. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-18-000004:mdna:11]
Total revenue increased by 3% compared with the second quarter of fiscal 2017. Within total revenue, product and service revenue each increased by 3%. Total gross margin increased by 0.3 percentage points, driven by productivity improvements and favorable product mix partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.2 percentage points. Operating income as a percentage of revenue increased by 0.9 percentage points. We had a net loss of $8.8 billion and a net loss per share of $1.78, primarily due to the $11.1 billion provisional tax expense related to the Tax Act, comprised of $9.0 billion U.S. transition tax, $1.2 billion of foreign withholding tax, and $0.9 billion of net deferred tax assets re-measurement.

[0000858877-18-000004:mdna:12]
In terms of our geographic segments, revenue from the Americas increased $344 million, driven in large part by product revenue growth in the United States. EMEA revenue decreased by $3 million, led by a product revenue decline in the United Kingdom. Revenue in our APJC segment decreased by $34 million, led by a product revenue decline in Japan. The “BRICM” countries experienced product revenue growth of 2% in the aggregate, driven by increased product revenue in the emerging countries of China, Russia and Brazil of 8%, 17% and 11%, respectively, partially offset by product revenue declines in India and Mexico of 11% and 4%, respectively.

[0000858877-18-000004:mdna:13]
From a customer market standpoint, we experienced product revenue growth in the public sector and commercial markets, partially offset by a product revenue decline in the service provider market. Product revenue in the enterprise market was flat.

[0000858877-18-000004:mdna:14]
From a product category perspective, product revenue increased 3% led by solid product revenue growth in Security and Applications, which each grew by 6%. We experienced a 2% product revenue increase in Infrastructure Platforms and we saw broad strength across the portfolio.

[0000858877-18-000004:mdna:15]
[same as prior period, unchanged from 0000858877-17-000019:mdna:16]

[0000858877-18-000004:mdna:16]
[same as prior period, unchanged from 0000858877-17-000019:mdna:17]

[0000858877-18-000004:mdna:17]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:18]
Total revenue was flat, with product revenue flat and service revenue increasing 2%. Total gross margin decreased by 1.2 percentage points due to unfavorable impacts from pricing and a $127 million legal and indemnification settlement charge, partially offset by productivity benefits and favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.1 percentage points. Operating income as a percentage of revenue increased by 0.2 percentage points. We had a net loss of $6.4 billion and a net loss per share of $1.29, due primarily to the $11.1 billion provisional tax expense related to the Tax Act as discussed above.

[0000858877-18-000004:mdna:19]
[same as prior period, unchanged from 0000858877-17-000019:mdna:18]

[0000858877-18-000004:mdna:20]
[same as prior period, unchanged from 0000858877-17-000019:mdna:19]

[0000858877-18-000004:mdna:21]
[same as prior period, unchanged from 0000858877-17-000019:mdna:20]

[0000858877-18-000004:mdna:22]
[same as prior period, unchanged from 0000858877-17-000019:mdna:21]

[0000858877-18-000004:mdna:23]
The following is a summary of our other key financial measures for the second quarter and first six months of fiscal 2018 (in millions):

[0000858877-18-000004:mdna:24]
|  |  | January 27, 2018 |  | July 29, 2017 |
| Cash and cash equivalents and investments |  | $ | 73,683 |  |  | $ | 70,492 |  |
| Deferred revenue |  | $ | 18,788 |  |  | $ | 18,494 |  |
| Inventories |  | $ | 1,896 |  |  | $ | 1,616 |  |

[0000858877-18-000004:mdna:25]
|  |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |
| Cash provided by operating activities |  | $ | 7,150 |  |  | $ | 6,502 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 5,631 |  |  | $ | 2,002 |  |
| Dividends |  | $ | 2,861 |  |  | $ | 2,612 |  |

[0000858877-18-000004:mdna:26]
[same as prior period, unchanged from 0000858877-17-000019:mdna:34]

[0000858877-18-000004:mdna:27]
[same as prior period, unchanged from 0000858877-17-000019:mdna:35]

[0000858877-18-000004:mdna:28]
[same as prior period, unchanged from 0000858877-17-000019:mdna:25]

[0000858877-18-000004:mdna:29]
[same as prior period, unchanged from 0000858877-17-000019:mdna:26]

[0000858877-18-000004:mdna:30]
[same as prior period, unchanged from 0000858877-17-000019:mdna:27]

[0000858877-18-000004:mdna:31]
[same as prior period, unchanged from 0000858877-17-000019:mdna:28]

[0000858877-18-000004:mdna:32]
[same as prior period, unchanged from 0000858877-17-000019:mdna:29]

[0000858877-18-000004:mdna:33]
[same as prior period, unchanged from 0000858877-17-000019:mdna:30]

[0000858877-18-000004:mdna:34]
[same as prior period, unchanged from 0000858877-17-000019:mdna:31]

[0000858877-18-000004:mdna:35]
[same as prior period, unchanged from 0000858877-17-000019:mdna:32]

[0000858877-18-000004:mdna:36]
[same as prior period, unchanged from 0000858877-17-000019:mdna:36]

[0000858877-18-000004:mdna:37]
[same as prior period, unchanged from 0000858877-17-000019:mdna:37]

[0000858877-18-000004:mdna:38]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first six months of fiscal 2018, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-18-000004:mdna:39]
[same as prior period, unchanged from 0000858877-17-000019:mdna:80]

[0000858877-18-000004:mdna:40]
[same as prior period, unchanged from 0000858877-17-000019:mdna:44]

[0000858877-18-000004:mdna:41]
[same as prior period, unchanged from 0000858877-17-000019:mdna:45]

[0000858877-18-000004:mdna:42]
[same as prior period, unchanged from 0000858877-17-000019:mdna:39]

[0000858877-18-000004:mdna:43]
[same as prior period, unchanged from 0000858877-17-000019:mdna:40]

[0000858877-18-000004:mdna:44]
[same as prior period, unchanged from 0000858877-17-000019:mdna:41]

[0000858877-18-000004:mdna:45]
|  |  | January 27, 2018 |  | July 29, 2017 |
| Allowance for doubtful accounts |  | $ | 181 |  |  | $ | 211 |  |
| Percentage of gross accounts receivable |  | 4.4 | % |  | 3.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 165 |  |  | $ | 162 |  |
| Percentage of gross lease receivables(1) |  | 5.6 | % |  | 5.5 | % |
| Allowance for credit loss—loan receivables |  | $ | 94 |  |  | $ | 103 |  |
| Percentage of gross loan receivables |  | 1.9 | % |  | 2.3 | % |

[0000858877-18-000004:mdna:46]
[same as prior period, unchanged from 0000858877-17-000019:mdna:43]

[0000858877-18-000004:mdna:47]
[same as prior period, unchanged from 0000858877-17-000019:mdna:46]

[0000858877-18-000004:mdna:48]
[same as prior period, unchanged from 0000858877-17-000019:mdna:47]

[0000858877-18-000004:mdna:49]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 27, 2018 and July 29, 2017 was $121 million and $122 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-18-000004:mdna:50]
[same as prior period, unchanged from 0000858877-17-000019:mdna:49]

[0000858877-18-000004:mdna:51]
[same as prior period, unchanged from 0000858877-17-000019:mdna:50]

[0000858877-18-000004:mdna:52]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2018, the liability for these purchase commitments was $159 million, compared with $162 million as of July 29, 2017, and was included in other current liabilities.

[0000858877-18-000004:mdna:53]
[same as prior period, unchanged from 0000858877-17-000019:mdna:56]

[0000858877-18-000004:mdna:54]
[same as prior period, unchanged from 0000858877-17-000019:mdna:57]

[0000858877-18-000004:mdna:55]
Our provision for inventory was $31 million and $35 million for the first six months of fiscal 2018 and 2017, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $44 million and $74 million for the first six months of fiscal 2018 and 2017, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-18-000004:mdna:56]
Loss Contingencies and Product Warranties

[0000858877-18-000004:mdna:57]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-18-000004:mdna:58]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-18-000004:mdna:59]
In fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses.  During the second quarter of fiscal 2017, we further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, we recorded a $125 million charge to product cost of sales related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of our products.  The liabilities related to the supplier component remediation matters as of January 27, 2018 and July 29, 2017 were $120 million and $174 million, respectively.

[0000858877-18-000004:mdna:60]
[same as prior period, unchanged from 0000858877-17-000019:mdna:60]

[0000858877-18-000004:mdna:61]
[same as prior period, unchanged from 0000858877-17-000019:mdna:61]

[0000858877-18-000004:mdna:62]
[same as prior period, unchanged from 0000858877-17-000019:mdna:62]

[0000858877-18-000004:mdna:63]
[same as prior period, unchanged from 0000858877-17-000019:mdna:63]

[0000858877-18-000004:mdna:64]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $56.1 billion as of January 27, 2018, compared with $58.8 billion as of July 29, 2017. Our fixed income investment portfolio as of January 27, 2018 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-18-000004:mdna:65]
53

[0000858877-18-000004:mdna:66]
[same as prior period, unchanged from 0000858877-17-000019:mdna:68]

[0000858877-18-000004:mdna:67]
[same as prior period, unchanged from 0000858877-17-000019:mdna:69]

[0000858877-18-000004:mdna:68]
[same as prior period, unchanged from 0000858877-17-000019:mdna:65]

[0000858877-18-000004:mdna:69]
[same as prior period, unchanged from 0000858877-17-000019:mdna:66]

[0000858877-18-000004:mdna:70]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of January 27, 2018. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of January 27, 2018 and July 29, 2017.

[0000858877-18-000004:mdna:71]
[same as prior period, unchanged from 0000858877-17-000019:mdna:70]

[0000858877-18-000004:mdna:72]
[same as prior period, unchanged from 0000858877-17-000019:mdna:71]

[0000858877-18-000004:mdna:73]
[same as prior period, unchanged from 0000858877-17-000019:mdna:72]

[0000858877-18-000004:mdna:74]
[same as prior period, unchanged from 0000858877-17-000019:mdna:73]

[0000858877-18-000004:mdna:75]
We also have investments in privately held companies, some of which are in the startup or development stages. As of January 27, 2018, our investments in privately held companies were $982 million, compared with $983 million as of July 29, 2017, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-18-000004:mdna:76]
[same as prior period, unchanged from 0000858877-17-000019:mdna:112]

[0000858877-18-000004:mdna:77]
[same as prior period, unchanged from 0000858877-17-000019:mdna:81]

[0000858877-18-000004:mdna:78]
[same as prior period, unchanged from 0000858877-17-000019:mdna:82]

[0000858877-18-000004:mdna:79]
[same as prior period, unchanged from 0000858877-17-000019:mdna:75]

[0000858877-18-000004:mdna:80]
[same as prior period, unchanged from 0000858877-17-000019:mdna:76]

[0000858877-18-000004:mdna:81]
The goodwill recorded in the Consolidated Balance Sheets as of January 27, 2018 and July 29, 2017 was $30.4 billion and $29.8 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2018 and 2017.

[0000858877-18-000004:mdna:82]
[same as prior period, unchanged from 0000858877-17-000019:mdna:78]

[0000858877-18-000004:mdna:83]
[same as prior period, unchanged from 0000858877-17-000019:mdna:79]

[0000858877-18-000004:mdna:84]
There were no impairment charges related to purchased intangible assets for the first six months of fiscal 2018, and there were $42 million of such impairment charges for the first six months of fiscal 2017. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-18-000004:mdna:85]
[same as prior period, unchanged from 0000858877-17-000019:mdna:84]

[0000858877-18-000004:mdna:86]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 371.6% and 20.8% in the second quarter of fiscal 2018 and 2017, respectively. Our effective tax rate was 203.1% and 21.1% in the first six months of fiscal 2018 and 2017, respectively.

[0000858877-18-000004:mdna:87]
The Tax Act, enacted on December 22, 2017, lowers the U.S. federal corporation income tax rate from 35% to 21% effective January 1, 2018, while also imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. During the three months ended January 27, 2018, the Company recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $9.0 billion of U.S. transition tax, $1.2 billion of foreign withholding tax and $0.9 billion of DTA re-measurement.

[0000858877-18-000004:mdna:88]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the provisional estimates due to changes in interpretations of the Tax Act, and legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and updates or changes to estimates used in the provisional amounts. We have determined that the $9.0 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $0.9 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of January 27, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000004:mdna:89]
[same as prior period, unchanged from 0000858877-17-000019:mdna:89]

[0000858877-18-000004:mdna:90]
[same as prior period, unchanged from 0000858877-17-000019:mdna:90]

[0000858877-18-000004:mdna:91]
[same as prior period, unchanged from 0000858877-17-000019:mdna:86]

[0000858877-18-000004:mdna:92]
[same as prior period, unchanged from 0000858877-17-000019:mdna:87]

[0000858877-18-000004:mdna:93]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 35 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-18-000004:mdna:94]
56

[0000858877-18-000004:mdna:95]
[same as prior period, unchanged from 0000858877-17-000019:mdna:100]

[0000858877-18-000004:mdna:96]
[same as prior period, unchanged from 0000858877-17-000019:mdna:101]

[0000858877-18-000004:mdna:97]
[same as prior period, unchanged from 0000858877-17-000019:mdna:91]

[0000858877-18-000004:mdna:98]
[same as prior period, unchanged from 0000858877-17-000019:mdna:92]

[0000858877-18-000004:mdna:99]
[same as prior period, unchanged from 0000858877-17-000019:mdna:93]

[0000858877-18-000004:mdna:100]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,709 |  |  | $ | 8,491 |  |  | $ | 218 |  |  | 3 | % |  | $ | 17,763 |  |  | $ | 17,793 |  |  | $ | (30 | ) |  | — | % |
| Percentage of revenue |  | 73.3 | % |  | 73.3 | % |  |  |  |  |  |  |  | 73.9 | % |  | 74.3 | % |  |  |  |  |  |  |
| Service |  | 3,178 |  |  | 3,089 |  |  | 89 |  |  | 3 | % |  | 6,260 |  |  | 6,139 |  |  | 121 |  |  | 2 | % |
| Percentage of revenue |  | 26.7 | % |  | 26.7 | % |  |  |  |  |  |  |  | 26.1 | % |  | 25.7 | % |  |  |  |  |  |  |
| Total |  | $ | 11,887 |  |  | $ | 11,580 |  |  | $ | 307 |  |  | 3 | % |  | $ | 24,023 |  |  | $ | 23,932 |  |  | $ | 91 |  |  | — | % |

[0000858877-18-000004:mdna:101]
[same as prior period, unchanged from 0000858877-17-000019:mdna:95]

[0000858877-18-000004:mdna:102]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,004 |  |  | $ | 6,660 |  |  | $ | 344 |  |  | 5 | % |  | $ | 14,354 |  |  | $ | 14,103 |  |  | $ | 251 |  |  | 2 | % |
| Percentage of revenue |  | 58.9 | % |  | 57.5 | % |  |  |  |  |  | 59.7 | % |  | 58.9 | % |  |  |  |  |
| EMEA |  | 3,062 |  |  | 3,065 |  |  | (3 | ) |  | — | % |  | 5,971 |  |  | 6,078 |  |  | (107 | ) |  | (2 | )% |
| Percentage of revenue |  | 25.8 | % |  | 26.5 | % |  |  |  |  |  | 24.9 | % |  | 25.4 | % |  |  |  |  |
| APJC |  | 1,821 |  |  | 1,855 |  |  | (34 | ) |  | (2 | )% |  | 3,698 |  |  | 3,751 |  |  | (53 | ) |  | (1 | )% |
| Percentage of revenue |  | 15.3 | % |  | 16.0 | % |  |  |  |  |  | 15.4 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 11,887 |  |  | $ | 11,580 |  |  | $ | 307 |  |  | 3 | % |  | $ | 24,023 |  |  | $ | 23,932 |  |  | $ | 91 |  |  | — | % |

[0000858877-18-000004:mdna:103]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:104]
Total revenue increased by 3%. Product and service revenue each increased by 3%. The increase in total revenue reflected solid growth in the Americas segment, while revenue declined in the APJC segment and was flat in the EMEA segment. The emerging countries of BRICM, in the aggregate, experienced  2% product revenue growth, with increases in China, Russia and Brazil partially offset by decreases in the other two BRICM countries.

[0000858877-18-000004:mdna:105]
[same as prior period, unchanged from 0000858877-17-000019:mdna:99]

[0000858877-18-000004:mdna:106]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:107]
Total revenue was flat. Product revenue was flat while service revenue increased by 2%. Our total revenue grew in the Americas segment and declined in the EMEA and APJC segments. Product revenue for the emerging countries of BRICM, in the aggregate, was flat, as revenue increases in Brazil, Russia and China were offset by decreases in the other two BRICM countries.

[0000858877-18-000004:mdna:108]
[same as prior period, unchanged from 0000858877-17-000019:mdna:113]

[0000858877-18-000004:mdna:109]
[same as prior period, unchanged from 0000858877-17-000019:mdna:114]

[0000858877-18-000004:mdna:110]
[same as prior period, unchanged from 0000858877-17-000019:mdna:102]

[0000858877-18-000004:mdna:111]
[same as prior period, unchanged from 0000858877-17-000019:mdna:103]

[0000858877-18-000004:mdna:112]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,988 |  |  | $ | 4,695 |  |  | $ | 293 |  |  | 6 | % |  | $ | 10,380 |  |  | $ | 10,175 |  |  | $ | 205 |  |  | 2 | % |
| Percentage of product revenue |  | 57.3 | % |  | 55.3 | % |  |  |  |  |  | 58.4 | % |  | 57.2 | % |  |  |  |  |
| EMEA |  | 2,375 |  |  | 2,392 |  |  | (17 | ) |  | (1 | )% |  | 4,614 |  |  | 4,756 |  |  | (142 | ) |  | (3 | )% |
| Percentage of product revenue |  | 27.3 | % |  | 28.2 | % |  |  |  |  |  | 26.0 | % |  | 26.7 | % |  |  |  |  |
| APJC |  | 1,346 |  |  | 1,404 |  |  | (58 | ) |  | (4 | )% |  | 2,769 |  |  | 2,862 |  |  | (93 | ) |  | (3 | )% |
| Percentage of product revenue |  | 15.4 | % |  | 16.5 | % |  |  |  |  |  | 15.6 | % |  | 16.1 | % |  |  |  |  |
| Total |  | $ | 8,709 |  |  | $ | 8,491 |  |  | $ | 218 |  |  | 3 | % |  | $ | 17,763 |  |  | $ | 17,793 |  |  | $ | (30 | ) |  | — | % |

[0000858877-18-000004:mdna:113]
[same as prior period, unchanged from 0000858877-17-000019:mdna:106]

[0000858877-18-000004:mdna:114]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:115]
Product revenue in the Americas segment increased by 6%, led by solid growth in the service provider and public sector markets and, to a lesser extent, growth in the commercial market. These increases were partially offset by a product revenue decline in the enterprise market. The product revenue increase in the public sector market was due primarily to higher sales to the U.S. federal government. From a country perspective, product revenue increased by 5% in the United States, 19% in Canada and 11% in Brazil, partially offset by a decrease of 4% in Mexico.

[0000858877-18-000004:mdna:116]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:117]
The increase in product revenue in the Americas segment was led by solid growth in the commercial market and, to a lesser extent, growth in the public sector and service provider markets. These increases were partially offset by a product revenue decline in the enterprise market. The product revenue growth in the public sector market was due primarily to higher sales to the U.S. federal government. From a country perspective, product revenue increased by 1% in the United States, 20% in Brazil and 8% in Canada, partially offset by a decrease of 16% in Mexico.

[0000858877-18-000004:mdna:118]
[same as prior period, unchanged from 0000858877-17-000019:mdna:108]

[0000858877-18-000004:mdna:119]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:120]
Product revenue in the EMEA segment decreased by 1%, led by a decline in the service provider market and, to a lesser extent, a decline in the enterprise market, partially offset by product revenue growth in the public sector and commercial markets. Product revenue from emerging countries within EMEA increased by 7% while product revenue for the remainder of the EMEA segment decreased by 3%.

[0000858877-18-000004:mdna:121]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:122]
The decrease in product revenue in the EMEA segment of 3% was driven by a decline in the service provider market and, to a lesser extent, a decline in the enterprise market. We experienced product revenue growth in the public sector and commercial markets in this segment. Product revenue from emerging countries within EMEA increased by 1% while product revenue for the remainder of the EMEA segment decreased by 4%.

[0000858877-18-000004:mdna:123]
58

[0000858877-18-000004:mdna:124]
[same as prior period, unchanged from 0000858877-17-000019:mdna:128]

[0000858877-18-000004:mdna:125]
[same as prior period, unchanged from 0000858877-17-000019:mdna:129]

[0000858877-18-000004:mdna:126]
[same as prior period, unchanged from 0000858877-17-000019:mdna:110]

[0000858877-18-000004:mdna:127]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:128]
Product revenue in the APJC segment decreased by 4%.  The product revenue decrease was led by a decline in the service provider market, partially offset by solid growth in the commercial and enterprise markets. Product revenue in the public sector market was flat. From a country perspective, product revenue decreased by 21% in Japan and 11% in India, while product revenue increased by 8% in China.

[0000858877-18-000004:mdna:129]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:130]
The decrease in product revenue in the APJC segment of 3% was led by decline in the service provider market, partially offset by product revenue growth in the commercial, enterprise and public sector markets. From a country perspective, product revenue decreased by 15% in Japan and 5% in India, while product revenue increased by 3% in China.

[0000858877-18-000004:mdna:131]
[same as prior period, unchanged from 0000858877-17-000019:mdna:115]

[0000858877-18-000004:mdna:132]
[same as prior period, unchanged from 0000858877-17-000019:mdna:116]

[0000858877-18-000004:mdna:133]
[same as prior period, unchanged from 0000858877-17-000019:mdna:117]

[0000858877-18-000004:mdna:134]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,694 |  |  | $ | 6,545 |  |  | $ | 149 |  |  | 2 | % |  | $ | 13,664 |  |  | $ | 13,818 |  |  | $ | (154 | ) |  | (1 | )% |
| Applications |  | 1,184 |  |  | 1,116 |  |  | 68 |  |  | 6 | % |  | 2,387 |  |  | 2,252 |  |  | 135 |  |  | 6 | % |
| Security |  | 558 |  |  | 528 |  |  | 30 |  |  | 6 | % |  | 1,143 |  |  | 1,068 |  |  | 75 |  |  | 7 | % |
| Other Products |  | 273 |  |  | 302 |  |  | (29 | ) |  | (10 | )% |  | 569 |  |  | 655 |  |  | (86 | ) |  | (13 | )% |
| Total |  | $ | 8,709 |  |  | $ | 8,491 |  |  | $ | 218 |  |  | 3 | % |  | $ | 17,763 |  |  | $ | 17,793 |  |  | $ | (30 | ) |  | — | % |

[0000858877-18-000004:mdna:135]
[same as prior period, unchanged from 0000858877-17-000019:mdna:120]

[0000858877-18-000004:mdna:136]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:137]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center.  The Infrastructure Platforms product category increased by 2%, or $149 million, and we saw broad strength across the portfolio. Within switching, we had strong growth in our data center switching and we saw solid momentum with our intent-based networking Catalyst 9000 Series. Our revenue from data center also had strong growth driven by higher sales of server products and our hyperconverged data center offering, HyperFlex. We experienced solid revenue growth from wireless products driven by our Wave 2 offerings as well as Meraki. We had a modest decrease in sales of routing products driven by continued weakness in the service provider market.

[0000858877-18-000004:mdna:138]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:139]
The Infrastructure Platforms product category decreased by 1%, or $154 million, with the vast majority of the decrease driven by lower revenue from routing products. The decrease in routing revenue was driven by weakness in the service provider market and a slowdown in enterprise routing sales.  Our switching revenue decreased modestly but we saw solid momentum in campus switching with our intent-based networking Catalyst 9000 Series.  Within switching, we experienced an increase in sales of data center switches, driven by strength in our Application Centric Infrastructure (ACI) portfolio.  We experienced solid revenue growth from wireless products and our data center products driven by higher sales of server products and HyperFlex.

[0000858877-18-000004:mdna:140]
[same as prior period, unchanged from 0000858877-17-000019:mdna:138]

[0000858877-18-000004:mdna:141]
[same as prior period, unchanged from 0000858877-17-000019:mdna:139]

[0000858877-18-000004:mdna:142]
[same as prior period, unchanged from 0000858877-17-000019:mdna:122]

[0000858877-18-000004:mdna:143]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:144]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as IoT and analytics software offerings from AppDynamics and Jasper.  Revenue in our Applications product category increased by 6%, or $68 million, driven by increased revenue in Telepresence, Conferencing and analytics from our fiscal 2017 acquisition of AppDynamics partially offset by decreased revenue from unified communications endpoints.  We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Applications product category.

[0000858877-18-000004:mdna:145]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:146]
Revenue in our Applications product category increased by 6%, or $135 million, with analytics from our fiscal 2017 acquisition of AppDynamics driving the majority of the increase and a modest revenue increase from collaboration offerings.

[0000858877-18-000004:mdna:147]
[same as prior period, unchanged from 0000858877-17-000019:mdna:124]

[0000858877-18-000004:mdna:148]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:149]
Revenue in our Security product category increased 6%, or $30 million, driven by higher sales of unified threat management and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-18-000004:mdna:150]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:151]
Revenue in our Security product category increased 7%, or $75 million, driven by higher sales of unified threat management and web security products.

[0000858877-18-000004:mdna:152]
[same as prior period, unchanged from 0000858877-17-000019:mdna:126]

[0000858877-18-000004:mdna:153]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:154]
The decrease in revenue from our Other Products category of 10%, or $29 million, was driven by a decrease in revenue from Service Provider Video software and solutions.

[0000858877-18-000004:mdna:155]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:156]
The decrease in revenue from our Other Products category of 13%, or $86 million, was driven by a decrease in revenue from Service Provider Video software and solutions.

[0000858877-18-000004:mdna:157]
60

[0000858877-18-000004:mdna:158]
[same as prior period, unchanged from 0000858877-17-000019:mdna:148]

[0000858877-18-000004:mdna:159]
[same as prior period, unchanged from 0000858877-17-000019:mdna:149]

[0000858877-18-000004:mdna:160]
[same as prior period, unchanged from 0000858877-17-000019:mdna:130]

[0000858877-18-000004:mdna:161]
[same as prior period, unchanged from 0000858877-17-000019:mdna:131]

[0000858877-18-000004:mdna:162]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,016 |  |  | $ | 1,965 |  |  | $ | 51 |  |  | 3 | % |  | $ | 3,974 |  |  | $ | 3,928 |  |  | $ | 46 |  |  | 1 | % |
| Percentage of service revenue |  | 63.4 | % |  | 63.6 | % |  |  |  |  |  | 63.5 | % |  | 64.0 | % |  |  |  |  |
| EMEA |  | 687 |  |  | 673 |  |  | 14 |  |  | 2 | % |  | 1,357 |  |  | 1,322 |  |  | 35 |  |  | 3 | % |
| Percentage of service revenue |  | 21.6 | % |  | 21.8 | % |  |  |  |  |  | 21.7 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 475 |  |  | 451 |  |  | 24 |  |  | 5 | % |  | 929 |  |  | 889 |  |  | 40 |  |  | 4 | % |
| Percentage of service revenue |  | 15.0 | % |  | 14.6 | % |  |  |  |  |  | 14.8 | % |  | 14.5 | % |  |  |  |  |
| Total |  | $ | 3,178 |  |  | $ | 3,089 |  |  | $ | 89 |  |  | 3 | % |  | $ | 6,260 |  |  | $ | 6,139 |  |  | $ | 121 |  |  | 2 | % |

[0000858877-18-000004:mdna:163]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:164]
Service revenue increased 3%.  Technical support services revenue and advanced services revenue each increased by 3%. Technical support services revenue increased across all geographic segments. The increase in technical support services revenue was driven by an increase in software and solution support offerings. Advanced services revenue, which relates to professional services for specific customer network needs, had solid revenue growth in our EMEA and Americas segments and declined in our APJC segment.

[0000858877-18-000004:mdna:165]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:166]
Service revenue increased across all geographic segments. Technical support services revenue increased by 2% and advanced services increased by 3%. Technical support services revenue had solid growth in APJC and increased to a lesser extent in our Americas and EMEA segments. Advanced services revenue had strong growth in the EMEA segment and grew modestly in our APJC and Americas segments.

[0000858877-18-000004:mdna:167]
[same as prior period, unchanged from 0000858877-17-000019:mdna:135]

[0000858877-18-000004:mdna:168]
[same as prior period, unchanged from 0000858877-17-000019:mdna:136]

[0000858877-18-000004:mdna:169]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,355 |  |  | $ | 5,186 |  |  | 61.5 | % |  | 61.1 | % |  | $ | 10,794 |  |  | $ | 11,085 |  |  | 60.8 | % |  | 62.3 | % |
| Service |  | 2,143 |  |  | 2,090 |  |  | 67.4 | % |  | 67.7 | % |  | 4,131 |  |  | 4,075 |  |  | 66.0 | % |  | 66.4 | % |
| Total |  | $ | 7,498 |  |  | $ | 7,276 |  |  | 63.1 | % |  | 62.8 | % |  | $ | 14,925 |  |  | $ | 15,160 |  |  | 62.1 | % |  | 63.3 | % |

[0000858877-18-000004:mdna:170]
[same as prior period, unchanged from 0000858877-17-000019:mdna:162]

[0000858877-18-000004:mdna:171]
[same as prior period, unchanged from 0000858877-17-000019:mdna:163]

[0000858877-18-000004:mdna:172]
[same as prior period, unchanged from 0000858877-17-000019:mdna:140]

[0000858877-18-000004:mdna:173]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2018 as compared with the corresponding prior year periods:

[0000858877-18-000004:mdna:174]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2017 |  | 61.1 | % |  | 62.3 | % |
| Product pricing |  | (1.3 | )% |  | (1.7 | )% |
| Legal and indemnification settlements |  | — | % |  | (0.7 | )% |
| Amortization of purchased intangibles |  | (0.4 | )% |  | (0.4 | )% |
| Mix of products sold |  | 0.5 | % |  | 0.3 | % |
| Productivity (1) |  | 1.7 | % |  | 0.9 | % |
| Other |  | (0.1 | )% |  | 0.1 | % |
| Fiscal 2018 |  | 61.5 | % |  | 60.8 | % |

[0000858877-18-000004:mdna:175]
[same as prior period, unchanged from 0000858877-17-000019:mdna:143]

[0000858877-18-000004:mdna:176]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:177]
Product gross margin increased by 0.4 percentage points driven by productivity improvements and a favorable mix impact partially offset by unfavorable impacts from product pricing.

[0000858877-18-000004:mdna:178]
Productivity improvements were driven by value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes), lower warranty expenses and continued operational efficiency in manufacturing operations. Our productivity continued to be negatively impacted by an increase in the cost of certain memory components which are currently constrained. We expect the higher costs on these memory components to continue to impact productivity in the near term. The favorable product mix impact was driven by our products within the Infrastructure Platforms product category. The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets.

[0000858877-18-000004:mdna:179]
Our product gross margin was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-18-000004:mdna:180]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:181]
Product gross margin decreased by 1.5 percentage points due largely to unfavorable impacts from product pricing and a charge of $127 million to product cost of sales recorded in the first six months of fiscal 2018 related to legal and indemnification settlements, partially offset by productivity benefits and favorable product mix.

[0000858877-18-000004:mdna:182]
The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets. While productivity was positive to overall product gross margin, the benefit was lower than the prior year as these improvements were adversely impacted by an increase in the cost of certain memory components which are currently constrained.  In addition, productivity was negatively impacted by decreases in Infrastructure Platforms revenue which limited our ability to generate cost savings. Productivity improvements were driven by value engineering efforts, lower warranty expenses and continued operational efficiency in manufacturing operations. Our product gross margin was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-18-000004:mdna:183]
[same as prior period, unchanged from 0000858877-17-000019:mdna:176]

[0000858877-18-000004:mdna:184]
[same as prior period, unchanged from 0000858877-17-000019:mdna:177]

[0000858877-18-000004:mdna:185]
[same as prior period, unchanged from 0000858877-17-000019:mdna:150]

[0000858877-18-000004:mdna:186]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:187]
Our service gross margin percentage decreased by 0.3 percentage points due to increased headcount-related costs and unfavorable mix. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-18-000004:mdna:188]
[same as prior period, unchanged from 0000858877-17-000019:mdna:153]

[0000858877-18-000004:mdna:189]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:190]
Service gross margin percentage decreased by 0.4 percentage points due largely to increased headcount-related costs and, to a lesser extent, increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-18-000004:mdna:191]
[same as prior period, unchanged from 0000858877-17-000019:mdna:154]

[0000858877-18-000004:mdna:192]
[same as prior period, unchanged from 0000858877-17-000019:mdna:155]

[0000858877-18-000004:mdna:193]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,614 |  |  | $ | 4,288 |  |  | 65.9 | % |  | 64.4 | % |  | $ | 9,336 |  |  | $ | 9,121 |  |  | 65.0 | % |  | 64.7 | % |
| EMEA | 1,977 |  |  | 2,012 |  |  | 64.6 | % |  | 65.6 | % |  | 3,816 |  |  | 4,025 |  |  | 63.9 | % |  | 66.2 | % |
| APJC | 1,094 |  |  | 1,121 |  |  | 60.1 | % |  | 60.4 | % |  | 2,259 |  |  | 2,325 |  |  | 61.1 | % |  | 62.0 | % |
| Segment total | 7,685 |  |  | 7,421 |  |  | 64.7 | % |  | 64.1 | % |  | 15,411 |  |  | 15,471 |  |  | 64.2 | % |  | 64.6 | % |
| Unallocated corporate items (1) | (187 | ) |  | (145 | ) |  |  |  |  |  | (486 | ) |  | (311 | ) |  |  |  |  |
| Total | $ | 7,498 |  |  | $ | 7,276 |  |  | 63.1 | % |  | 62.8 | % |  | $ | 14,925 |  |  | $ | 15,160 |  |  | 62.1 | % |  | 63.3 | % |

[0000858877-18-000004:mdna:194]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-18-000004:mdna:195]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:196]
The Americas segment experienced a gross margin percentage increase due to productivity improvements and favorable product mix, partially offset by negative impacts from pricing. The favorable mix impact was driven by our products within the Infrastructure Platforms product category.

[0000858877-18-000004:mdna:197]
The gross margin percentage decrease in our EMEA segment was due primarily to negative impacts from pricing and mix partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-18-000004:mdna:198]
Our APJC segment gross margin percentage decreased due to negative impacts from pricing and mix, partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-18-000004:mdna:199]
63

[0000858877-18-000004:mdna:200]
[same as prior period, unchanged from 0000858877-17-000019:mdna:189]

[0000858877-18-000004:mdna:201]
[same as prior period, unchanged from 0000858877-17-000019:mdna:190]

[0000858877-18-000004:mdna:202]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:203]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and, to a lesser extent, a favorable product mix, partially offset by unfavorable impacts from pricing.

[0000858877-18-000004:mdna:204]
The gross margin percentage decrease in our EMEA segment was due primarily to the negative impacts from pricing and, to a lesser extent, an unfavorable product mix partially offset by productivity improvements.

[0000858877-18-000004:mdna:205]
The APJC segment gross margin percentage decreased due primarily to negative impacts from pricing, partially offset by productivity improvements and favorable product mix.

[0000858877-18-000004:mdna:206]
[same as prior period, unchanged from 0000858877-17-000019:mdna:164]

[0000858877-18-000004:mdna:207]
[same as prior period, unchanged from 0000858877-17-000019:mdna:165]

[0000858877-18-000004:mdna:208]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,549 |  |  | $ | 1,508 |  |  | $ | 41 |  |  | 3 | % |  | $ | 3,116 |  |  | $ | 3,053 |  |  | $ | 63 |  |  | 2 | % |
| Percentage of revenue | 13.0 | % |  | 13.0 | % |  |  |  |  |  | 13.0 | % |  | 12.8 | % |  |  |  |  |
| Sales and marketing | 2,235 |  |  | 2,222 |  |  | 13 |  |  | 1 | % |  | 4,569 |  |  | 4,640 |  |  | (71 | ) |  | (2 | )% |
| Percentage of revenue | 18.8 | % |  | 19.2 | % |  |  |  |  |  | 19.0 | % |  | 19.4 | % |  |  |  |  |
| General and administrative | 483 |  |  | 456 |  |  | 27 |  |  | 6 | % |  | 1,040 |  |  | 1,011 |  |  | 29 |  |  | 3 | % |
| Percentage of revenue | 4.1 | % |  | 3.9 | % |  |  |  |  |  | 4.3 | % |  | 4.2 | % |  |  |  |  |
| Total | $ | 4,267 |  |  | $ | 4,186 |  |  | $ | 81 |  |  | 2 | % |  | $ | 8,725 |  |  | $ | 8,704 |  |  | $ | 21 |  |  | — | % |
| Percentage of revenue | 35.9 | % |  | 36.1 | % |  |  |  |  |  | 36.3 | % |  | 36.4 | % |  |  |  |  |

[0000858877-18-000004:mdna:209]
[same as prior period, unchanged from 0000858877-17-000019:mdna:167]

[0000858877-18-000004:mdna:210]
R&D expenses increased in the second quarter and first six months of fiscal 2018, as compared with the corresponding periods of fiscal 2017, primarily due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services and lower acquisition-related costs.

[0000858877-18-000004:mdna:211]
[same as prior period, unchanged from 0000858877-17-000019:mdna:169]

[0000858877-18-000004:mdna:212]
[same as prior period, unchanged from 0000858877-17-000019:mdna:170]

[0000858877-18-000004:mdna:213]
Sales and marketing expenses increased in the second quarter of fiscal 2018, as compared with the second quarter of fiscal 2017, due to higher headcount-related expenses and higher share-based compensation expense, partially offset by lower contracted services and lower discretionary spending.

[0000858877-18-000004:mdna:214]
Sales and marketing expenses decreased in the first six months of fiscal 2018, as compared with the first six months of fiscal 2017, due to lower contracted services and lower discretionary spending, partially offset by higher headcount-related expenses and, to a lesser extent, higher share-based compensation expense.

[0000858877-18-000004:mdna:215]
[same as prior period, unchanged from 0000858877-17-000019:mdna:172]

[0000858877-18-000004:mdna:216]
G&A expenses increased in the second quarter of fiscal 2018, as compared with the second quarter of fiscal 2017, due to increases in contracted services, share-based compensation expense, headcount-related expenses and discretionary spending, partially offset by the gains on divestitures.

[0000858877-18-000004:mdna:217]
G&A expenses increased in the first six months of fiscal 2018, as compared with the first six months of fiscal 2017, due to increases in contracted services, share-based compensation expense, discretionary spending and acquisition-related costs, partially offset by a decrease in headcount-related expenses.

[0000858877-18-000004:mdna:218]
[same as prior period, unchanged from 0000858877-17-000019:mdna:241]

[0000858877-18-000004:mdna:219]
[same as prior period, unchanged from 0000858877-17-000019:mdna:203]

[0000858877-18-000004:mdna:220]
[same as prior period, unchanged from 0000858877-17-000019:mdna:204]

[0000858877-18-000004:mdna:221]
[same as prior period, unchanged from 0000858877-17-000019:mdna:174]

[0000858877-18-000004:mdna:222]
In the second quarter of fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $24 million, or 0.6%, compared with the second quarter of fiscal 2017.

[0000858877-18-000004:mdna:223]
In the first six months of fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $41 million, or 0.5%, compared with the first six months of fiscal 2017.

[0000858877-18-000004:mdna:224]
[same as prior period, unchanged from 0000858877-17-000019:mdna:178]

[0000858877-18-000004:mdna:225]
[same as prior period, unchanged from 0000858877-17-000019:mdna:179]

[0000858877-18-000004:mdna:226]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Cost of sales—product |  | $ | 23 |  |  | $ | 19 |  |  | $ | 46 |  |  | $ | 40 |  |
| Cost of sales—service |  | 31 |  |  | 34 |  |  | 65 |  |  | 67 |  |
| Share-based compensation expense in cost of sales |  | 54 |  |  | 53 |  |  | 111 |  |  | 107 |  |
| Research and development |  | 134 |  |  | 129 |  |  | 270 |  |  | 255 |  |
| Sales and marketing |  | 135 |  |  | 125 |  |  | 270 |  |  | 265 |  |
| General and administrative |  | 64 |  |  | 45 |  |  | 128 |  |  | 94 |  |
| Restructuring and other charges |  | 12 |  |  | — |  |  | 18 |  |  | 3 |  |
| Share-based compensation expense in operating expenses |  | 345 |  |  | 299 |  |  | 686 |  |  | 617 |  |
| Total share-based compensation expense |  | $ | 399 |  |  | $ | 352 |  |  | $ | 797 |  |  | $ | 724 |  |

[0000858877-18-000004:mdna:227]
The increase in share-based compensation expense in the second quarter and first six months of fiscal 2018, as compared with the corresponding periods of fiscal 2017, was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions and higher restructuring charges.

[0000858877-18-000004:mdna:228]
[same as prior period, unchanged from 0000858877-17-000019:mdna:182]

[0000858877-18-000004:mdna:229]
[same as prior period, unchanged from 0000858877-17-000019:mdna:183]

[0000858877-18-000004:mdna:230]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 160 |  |  | $ | 124 |  |  | $ | 314 |  |  | $ | 253 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 60 |  |  | 64 |  |  | 121 |  |  | 142 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | — |  |  | 38 |  |
| Total |  | $ | 220 |  |  | $ | 188 |  |  | $ | 435 |  |  | $ | 433 |  |

[0000858877-18-000004:mdna:231]
Amortization of purchased intangible assets increased for the second quarter of fiscal 2018, as compared with the second quarter of fiscal 2017, due to amortization of purchased intangible assets from our recent acquisitions.

[0000858877-18-000004:mdna:232]
Amortization of purchased intangible assets increased slightly for the first six months of fiscal 2018, as compared with the first six months of fiscal 2017, due to amortization of purchased intangible assets from our recent acquisitions, partially offset by the impact of the impairment charges in the prior period.

[0000858877-18-000004:mdna:233]
65

[0000858877-18-000004:mdna:234]
[same as prior period, unchanged from 0000858877-17-000019:mdna:214]

[0000858877-18-000004:mdna:235]
[same as prior period, unchanged from 0000858877-17-000019:mdna:215]

[0000858877-18-000004:mdna:236]
[same as prior period, unchanged from 0000858877-17-000019:mdna:186]

[0000858877-18-000004:mdna:237]
We incurred restructuring and other charges of $98 million and $133 million for the second quarter of fiscal 2018 and fiscal 2017, respectively, and $250 million and $544 million for first six months of fiscal 2018 and fiscal 2017, respectively. These charges were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. In the second quarter of fiscal 2018, we extended the restructuring action to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. We have substantially completed the restructuring action and have incurred cumulative charges of $1.0 billion as of January 27, 2018.

[0000858877-18-000004:mdna:238]
[same as prior period, unchanged from 0000858877-17-000019:mdna:188]

[0000858877-18-000004:mdna:239]
[same as prior period, unchanged from 0000858877-17-000019:mdna:191]

[0000858877-18-000004:mdna:240]
[same as prior period, unchanged from 0000858877-17-000019:mdna:192]

[0000858877-18-000004:mdna:241]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Operating income |  | $ | 3,073 |  |  | $ | 2,893 |  |  | $ | 5,829 |  |  | $ | 5,770 |  |
| Operating income as a percentage of revenue |  | 25.9 | % |  | 25.0 | % |  | 24.3 | % |  | 24.1 | % |

[0000858877-18-000004:mdna:242]
For the second quarter of fiscal 2018, as compared with the second quarter of fiscal 2017, operating income increased by 6% and as a percentage of revenue operating income increased by 0.9 percentage points. These increases resulted primarily from a revenue increase, a gross margin percentage increase and a decrease in restructuring and other charges related to the restructuring actions announced in August 2016.

[0000858877-18-000004:mdna:243]
For the first six months of fiscal 2018, as compared with the first six months of fiscal 2017, operating income increased by 1% and as a percentage of revenue operating income increased by 0.2 percentage points. These increases resulted primarily from a decrease in restructuring and other charges related to the restructuring actions announced in August 2016, partially offset by a gross margin percentage decrease driven by unfavorable impacts from pricing and the charge of $127 million for legal and indemnification settlements.

[0000858877-18-000004:mdna:244]
[same as prior period, unchanged from 0000858877-17-000019:mdna:195]

[0000858877-18-000004:mdna:245]
[same as prior period, unchanged from 0000858877-17-000019:mdna:196]

[0000858877-18-000004:mdna:246]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |
| Interest income |  | $ | 396 |  |  | $ | 329 |  |  | $ | 67 |  |  | $ | 775 |  |  | $ | 624 |  |  | $ | 151 |  |
| Interest expense |  | (247 | ) |  | (222 | ) |  | (25 | ) |  | (482 | ) |  | (420 | ) |  | (62 | ) |
| Interest income (expense), net |  | $ | 149 |  |  | $ | 107 |  |  | $ | 42 |  |  | $ | 293 |  |  | $ | 204 |  |  | $ | 89 |  |

[0000858877-18-000004:mdna:247]
Interest income increased driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio. The increase in interest expense was driven by higher average debt balances and the impact of higher effective interest rates.

[0000858877-18-000004:mdna:248]
[same as prior period, unchanged from 0000858877-17-000019:mdna:228]

[0000858877-18-000004:mdna:249]
[same as prior period, unchanged from 0000858877-17-000019:mdna:229]

[0000858877-18-000004:mdna:250]
[same as prior period, unchanged from 0000858877-17-000019:mdna:200]

[0000858877-18-000004:mdna:251]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |  | January 27, 2018 |  | January 28, 2017 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 154 |  |  | $ | 4 |  |  | $ | 150 |  |  | $ | 183 |  |  | $ | 9 |  |  | $ | 174 |  |
| Fixed income securities |  | (96 | ) |  | (34 | ) |  | (62 | ) |  | (92 | ) |  | (24 | ) |  | (68 | ) |
| Total available-for-sale investments |  | 58 |  |  | (30 | ) |  | 88 |  |  | 91 |  |  | (15 | ) |  | 106 |  |
| Privately held companies |  | 2 |  |  | (3 | ) |  | 5 |  |  | 37 |  |  | (53 | ) |  | 90 |  |
| Net gains (losses) on investments |  | 60 |  |  | (33 | ) |  | 93 |  |  | 128 |  |  | (68 | ) |  | 196 |  |
| Other gains (losses), net |  | (50 | ) |  | (4 | ) |  | (46 | ) |  | (56 | ) |  | 10 |  |  | (66 | ) |
| Other income (loss), net |  | $ | 10 |  |  | $ | (37 | ) |  | $ | 47 |  |  | $ | 72 |  |  | $ | (58 | ) |  | $ | 130 |  |

[0000858877-18-000004:mdna:252]
Three Months Ended January 27, 2018 Compared with Three Months Ended January 28, 2017

[0000858877-18-000004:mdna:253]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities, partially offset by higher realized losses on fixed income securities as a result of market conditions and the timing of sales of these securities.

[0000858877-18-000004:mdna:254]
The change in net gains (losses) on investments in privately held companies was primarily due to lower impairment charges on investments in privately held companies partially offset by lower realized gains on investments in privately held companies.

[0000858877-18-000004:mdna:255]
The change in other gains (losses), net was primarily driven by net unfavorable foreign exchange impacts and, to a lesser extent, impacts from equity derivatives.

[0000858877-18-000004:mdna:256]
Six Months Ended January 27, 2018 Compared with Six Months Ended January 28, 2017

[0000858877-18-000004:mdna:257]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities, partially offset by higher realized losses on fixed income securities as a result of market conditions and the timing of sales of these securities and $26 million of impairment charges on publicly traded equity securities.

[0000858877-18-000004:mdna:258]
The change in net gains (losses) on investments in privately held companies was primarily due to lower impairment charges and higher realized gains on investments in privately held companies.

[0000858877-18-000004:mdna:259]
The change in other gains (losses), net was primarily driven by net unfavorable foreign exchange impacts and to a lesser extent, impacts from equity derivatives.

[0000858877-18-000004:mdna:260]
[same as prior period, unchanged from 0000858877-17-000019:mdna:273]

[0000858877-18-000004:mdna:261]
[same as prior period, unchanged from 0000858877-17-000019:mdna:242]

[0000858877-18-000004:mdna:262]
[same as prior period, unchanged from 0000858877-17-000019:mdna:243]

[0000858877-18-000004:mdna:263]
[same as prior period, unchanged from 0000858877-17-000019:mdna:209]

[0000858877-18-000004:mdna:264]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.  As a fiscal-year taxpayer, certain provisions of the Tax Act impact us in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system and other changes to how foreign earnings are subject to U.S. tax, and elimination of the domestic manufacturing deduction.

[0000858877-18-000004:mdna:265]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, we have computed our income tax expense for the July 28, 2018 fiscal year using a blended federal tax rate of 27%.  The 21% federal tax rate will apply to our fiscal year ending July 27, 2019 and each year thereafter. We must remeasure our deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000858877-18-000004:mdna:266]
As of January 27, 2018, we had approximately $75 billion in undistributed earnings for certain foreign subsidiaries. Substantially all of these undistributed earnings are subject to the U.S. mandatory one-time transition tax and are eligible to be repatriated to the U.S. without additional U.S. tax under the Tax Act. We have historically asserted our intention to indefinitely reinvest foreign earnings in certain foreign subsidiaries. We have reevaluated our historic assertion as a result of enactment of the Tax Act and no longer consider these earnings to be indefinitely reinvested in our foreign subsidiaries.  As a result of this change in assertion, we have recorded a $1.2 billion tax expense for foreign withholding tax in the second quarter of fiscal 2018.  In the third quarter of fiscal 2018, we anticipate repatriating $67 billion of foreign subsidiary earnings to the U.S. (in the form of cash, cash equivalents, or investments), of which $26 billion was repatriated to the U.S. in February 2018.

[0000858877-18-000004:mdna:267]
During the three months ended January 27, 2018, we recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $9.0 billion of U.S. transition tax, $1.2 billion of foreign withholding tax (discussed above), and $0.9 billion re-measurement of net DTA. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. The $1.2 billion foreign withholding tax was paid in February 2018. The Tax Act is discussed more fully in Note 16 to the Consolidated Financial Statements.

[0000858877-18-000004:mdna:268]
The provision for income taxes resulted in an effective tax rate of 371.6% for the second quarter of fiscal 2018 compared with 20.8% for the second quarter of fiscal 2017, a net 350.8 percentage point increase for the second quarter of fiscal 2018 as compared with the second quarter of fiscal 2017. The provision for income taxes resulted in an effective tax rate of 203.1% for the first six months of fiscal 2018 as compared with 21.1% for the first six months of fiscal 2017, a net 182.0 percentage point increase for the first six months of fiscal 2018 as compared with the first six months of fiscal 2017. The increase in the effective tax rate was primarily due to the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement during the second quarter of fiscal 2018.

[0000858877-18-000004:mdna:269]
[same as prior period, unchanged from 0000858877-17-000019:mdna:212]

[0000858877-18-000004:mdna:270]
[same as prior period, unchanged from 0000858877-17-000019:mdna:285]

[0000858877-18-000004:mdna:271]
[same as prior period, unchanged from 0000858877-17-000019:mdna:252]

[0000858877-18-000004:mdna:272]
[same as prior period, unchanged from 0000858877-17-000019:mdna:253]

[0000858877-18-000004:mdna:273]
[same as prior period, unchanged from 0000858877-17-000019:mdna:216]

[0000858877-18-000004:mdna:274]
[same as prior period, unchanged from 0000858877-17-000019:mdna:217]

[0000858877-18-000004:mdna:275]
[same as prior period, unchanged from 0000858877-17-000019:mdna:218]

[0000858877-18-000004:mdna:276]
[same as prior period, unchanged from 0000858877-17-000019:mdna:219]

[0000858877-18-000004:mdna:277]
|  | January 27, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 17,624 |  |  | $ | 11,708 |  |  | $ | 5,916 |  |
| Fixed income securities | 54,439 |  |  | 57,077 |  |  | (2,638 | ) |
| Publicly traded equity securities | 1,620 |  |  | 1,707 |  |  | (87 | ) |
| Total | $ | 73,683 |  |  | $ | 70,492 |  |  | $ | 3,191 |  |

[0000858877-18-000004:mdna:278]
The net increase in cash and cash equivalents and investments in the first six months of fiscal 2018 was primarily driven by cash provided by operating activities of $7.2 billion and a net increase in debt of $5.7 billion. These sources of cash were partially offset by cash returned to shareholders in the form of repurchases of common stock of $5.5 billion under the stock repurchase program and cash dividends of $2.9 billion; net cash paid for acquisitions of $0.8 billion; and capital expenditures of $0.4 billion.

[0000858877-18-000004:mdna:279]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $71.3 billion and $67.5 billion as of January 27, 2018 and July 29, 2017, respectively. The balance of cash and cash equivalents and investments available in the United States as of January 27, 2018 and July 29, 2017 was $2.4 billion and $3.0 billion, respectively. During the three months ended January 27, 2018, as a result of the Tax Act, all historical undistributed foreign subsidiary earnings were subject to a mandatory one-time transition tax, which resulted in a provisional tax expense of $9.0 billion. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. Approximately $0.8 billion is payable in less than one year; $1.4 billion is payable between 1 to 3 years; another $1.4 billion is payable between 3 to 5 years; and the remaining $5.4 billion is payable in more than 5 years. In February 2018, we repatriated to the U.S. $26 billion of historical undistributed foreign subsidiary earnings and paid foreign withholding tax of $1.2 billion. In the third quarter of fiscal 2018, we anticipate repatriating to the U.S. an additional $41 billion of historical undistributed foreign subsidiary earnings. Future repatriation of cash and other property held by our foreign subsidiaries will generally not be subject to U.S. federal tax. As we evaluate the impact of the Tax Act and the future cash needs of our global operations, we may revise the amount of foreign earnings considered to be permanently reinvested in our foreign subsidiaries.

[0000858877-18-000004:mdna:280]
In addition to cash requirements in the normal course of business, in the third quarter of fiscal 2018, we closed the acquisition of BroadSoft for a purchase price of approximately $1.9 billion net of cash and investments. Additionally, $9.0 billion of commercial paper notes and $4.75 billion of long term debt which were outstanding at January 27, 2018 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-18-000004:mdna:281]
[same as prior period, unchanged from 0000858877-17-000019:mdna:223]

[0000858877-18-000004:mdna:282]
[same as prior period, unchanged from 0000858877-17-000019:mdna:260]

[0000858877-18-000004:mdna:283]
[same as prior period, unchanged from 0000858877-17-000019:mdna:261]

[0000858877-18-000004:mdna:284]
[same as prior period, unchanged from 0000858877-17-000019:mdna:224]

[0000858877-18-000004:mdna:285]
[same as prior period, unchanged from 0000858877-17-000019:mdna:225]

[0000858877-18-000004:mdna:286]
|  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |
| Net cash provided by operating activities | $ | 7,150 |  |  | $ | 6,502 |  |
| Acquisition of property and equipment | (379 | ) |  | (526 | ) |
| Free cash flow | $ | 6,771 |  |  | $ | 5,976 |  |

[0000858877-18-000004:mdna:287]
[same as prior period, unchanged from 0000858877-17-000019:mdna:227]

[0000858877-18-000004:mdna:288]
[same as prior period, unchanged from 0000858877-17-000019:mdna:230]

[0000858877-18-000004:mdna:289]
[same as prior period, unchanged from 0000858877-17-000019:mdna:231]

[0000858877-18-000004:mdna:290]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0000858877-18-000004:mdna:291]
On February 14, 2018, our Board of Directors declared a quarterly dividend of $0.33 per common share to be paid on April 25, 2018 to all shareholders of record as of the close of business on April 5, 2018.  Any future dividends are subject to the approval of our Board of Directors.

[0000858877-18-000004:mdna:292]
On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $31 billion, with no termination date.  We expect to utilize this remaining authorized amount for stock repurchases over the next 18 to 24 months.

[0000858877-18-000004:mdna:293]
[same as prior period, unchanged from 0000858877-17-000019:mdna:274]

[0000858877-18-000004:mdna:294]
[same as prior period, unchanged from 0000858877-17-000019:mdna:275]

[0000858877-18-000004:mdna:295]
[same as prior period, unchanged from 0000858877-17-000019:mdna:234]

[0000858877-18-000004:mdna:296]
|  | January 27, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 3,963 |  |  | $ | 5,146 |  |  | $ | (1,183 | ) |

[0000858877-18-000004:mdna:297]
Our accounts receivable net, as of January 27, 2018 decreased by approximately 23%, as compared with the end of fiscal 2017, primarily due to product billings being more linear and the amount and timing of service billings in the second quarter of fiscal 2018 compared with the fourth quarter of fiscal 2017.

[0000858877-18-000004:mdna:298]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-18-000004:mdna:299]
|  | January 27, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Inventories | $ | 1,896 |  |  | $ | 1,616 |  |  | $ | 280 |  |

[0000858877-18-000004:mdna:300]
Inventory as of January 27, 2018 increased by 17% from our inventory balance at the end of fiscal 2017. The increase in inventory was due to higher levels of manufactured finished goods in support of current order activity and an increase in raw materials due to securing memory supply which is currently constrained.

[0000858877-18-000004:mdna:301]
[same as prior period, unchanged from 0000858877-17-000019:mdna:240]

[0000858877-18-000004:mdna:302]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.  Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.  The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-18-000004:mdna:303]
| Commitments by Period | January 27, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 4,498 |  |  | $ | 4,620 |  |
| 1 to 3 years | 690 |  |  | 20 |  |
| 3 to 5 years | 540 |  |  | — |  |
| Total | $ | 5,728 |  |  | $ | 4,640 |  |

[0000858877-18-000004:mdna:304]
Purchase commitments with contract manufacturers and suppliers increased by approximately 23% compared to the end of fiscal 2017.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 22% compared with the end of fiscal 2017.

[0000858877-18-000004:mdna:305]
We record a liability, included in other current liabilities, for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-18-000004:mdna:306]
[same as prior period, unchanged from 0000858877-17-000019:mdna:246]

[0000858877-18-000004:mdna:307]
CISCO SYSTEMS, INC.

[0000858877-18-000004:mdna:308]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-18-000004:mdna:309]
[same as prior period, unchanged from 0000858877-17-000019:mdna:247]

[0000858877-18-000004:mdna:310]
|  | January 27, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,620 |  |  | $ | 2,650 |  |  | $ | (30 | ) |
| Loan receivables, net | 4,752 |  |  | 4,457 |  |  | 295 |  |
| Financed service contracts, net | 2,466 |  |  | 2,487 |  |  | (21 | ) |
| Total, net | $ | 9,838 |  |  | $ | 9,594 |  |  | $ | 244 |  |

[0000858877-18-000004:mdna:311]
[same as prior period, unchanged from 0000858877-17-000019:mdna:249]

[0000858877-18-000004:mdna:312]
[same as prior period, unchanged from 0000858877-17-000019:mdna:250]

[0000858877-18-000004:mdna:313]
The volume of channel partner financing was $13.6 billion and $13.2 billion for the first six months of fiscal 2018 and 2017, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of January 27, 2018 and July 29, 2017. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 27, 2018, the total maximum potential future payments related to these guarantees was approximately $341 million, of which approximately $131 million was recorded as deferred revenue.

[0000858877-18-000004:mdna:314]
72

[0000858877-18-000004:mdna:315]
CISCO SYSTEMS, INC.

[0000858877-18-000004:mdna:316]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-18-000004:mdna:317]
[same as prior period, unchanged from 0000858877-17-000019:mdna:254]

[0000858877-18-000004:mdna:318]
[same as prior period, unchanged from 0000858877-17-000019:mdna:255]

[0000858877-18-000004:mdna:319]
|  | Maturity Date |  | January 27, 2018 |  | July 29, 2017 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 30,500 |  |  | $ | 30,500 |  |

[0000858877-18-000004:mdna:320]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of January 27, 2018.

[0000858877-18-000004:mdna:321]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $9.0 billion and $3.2 billion commercial paper notes outstanding as of January 27, 2018 and July 29, 2017, respectively.

[0000858877-18-000004:mdna:322]
Credit Facilities On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-18-000004:mdna:323]
CISCO SYSTEMS, INC.

[0000858877-18-000004:mdna:324]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-18-000004:mdna:325]
In addition, on March 30, 2017 we entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides us the option to, for a fee, convert any borrowings outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

[0000858877-18-000004:mdna:326]
These credit agreements require that we comply with certain covenants, including that we maintain interest coverage ratios as defined in these agreements. As of January 27, 2018, we were in compliance with the required interest coverage ratios and the other covenants, and we had not borrowed any funds under these credit facilities.

[0000858877-18-000004:mdna:327]
[same as prior period, unchanged from 0000858877-17-000019:mdna:264]

[0000858877-18-000004:mdna:328]
|  | January 27, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Service | $ | 10,963 |  |  | $ | 11,302 |  |  | $ | (339 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers | 5,451 |  |  | 4,971 |  |  | 480 |  |
| Other product deferred revenue | 2,374 |  |  | 2,221 |  |  | 153 |  |
| Total product deferred revenue | 7,825 |  |  | 7,192 |  |  | 633 |  |
| Total | $ | 18,788 |  |  | $ | 18,494 |  |  | $ | 294 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,102 |  |  | $ | 10,821 |  |  | $ | 281 |  |
| Noncurrent | 7,686 |  |  | 7,673 |  |  | 13 |  |
| Total | $ | 18,788 |  |  | $ | 18,494 |  |  | $ | 294 |  |

[0000858877-18-000004:mdna:329]
Deferred product revenue increased 9% primarily due to increased deferrals related to recurring software and subscription offers. The portion of product deferred revenue related to recurring software and subscription offers grew 36% on a year-over-year basis to $5.5 billion as of January 27, 2018. Security and Applications continued to experience strong product deferred revenue growth during the period. The 3% decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-18-000004:mdna:330]
[same as prior period, unchanged from 0000858877-17-000019:mdna:267]

[0000858877-18-000004:mdna:331]
[same as prior period, unchanged from 0000858877-17-000019:mdna:268]

[0000858877-18-000004:mdna:332]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of January 27, 2018 were $1.2 billion.

[0000858877-18-000004:mdna:333]
[same as prior period, unchanged from 0000858877-17-000019:mdna:270]

[0000858877-18-000004:mdna:334]
[same as prior period, unchanged from 0000858877-17-000019:mdna:271]

[0000858877-18-000004:mdna:335]
Insieme Networks, Inc.  In fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of our technology. During fiscal 2014, we acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million during the first six months of fiscal 2017. During the first six months of fiscal 2017, we recorded compensation expense of  $32 million related to these milestone payments. We do not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-18-000004:mdna:336]
CISCO SYSTEMS, INC.

[0000858877-18-000004:mdna:337]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-18-000004:mdna:338]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $215 million as of January 27, 2018, compared with $216 million as of July 29, 2017.

[0000858877-18-000004:mdna:339]
[same as prior period, unchanged from 0000858877-17-000019:mdna:277]

[0000858877-18-000004:mdna:340]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies including venture funds and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of January 27, 2018 there were no material unconsolidated variable interest entities.

[0000858877-18-000004:mdna:341]
[same as prior period, unchanged from 0000858877-17-000019:mdna:279]

[0000858877-18-000004:mdna:342]
[same as prior period, unchanged from 0000858877-17-000019:mdna:280]

[0000858877-18-000004:mdna:343]
[same as prior period, unchanged from 0000858877-17-000019:mdna:281]

[0000858877-18-000004:mdna:344]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 27, 2018 and January 28, 2017 was $0.4 billion and $0.9 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of January 27, 2018 and July 29, 2017, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-18-000004:mdna:345]
[same as prior period, unchanged from 0000858877-17-000019:mdna:283]

[0000858877-18-000004:mdna:346]
[same as prior period, unchanged from 0000858877-17-000019:mdna:284]

[0000858877-18-000004:mdna:347]
75
