# CSCO notes — 0000858877-18-000004


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-18-000004:notes:1]
[same as prior period, unchanged from 0000858877-17-000019:notes:1]

[0000858877-18-000004:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Compensation expense related to acquisitions | $ | 46 |  |  | $ | 73 |  |  | $ | 88 |  |  | $ | 137 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-18-000004:notes:3]
[same as prior period, unchanged from 0000858877-17-000019:notes:5]

[0000858877-18-000004:notes:4]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Income before provision for income taxes | $ | 3,232 |  |  | $ | 2,963 |  |  | $ | 6,194 |  |  | $ | 5,916 |  |
| Provision for income taxes | $ | 12,010 |  |  | $ | 615 |  |  | $ | 12,578 |  |  | $ | 1,246 |  |
| Effective tax rate | 371.6 | % |  | 20.8 | % |  | 203.1 | % |  | 21.1 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-18-000004:notes:5]
[same as prior period, unchanged from 0000858877-17-000019:notes:7]

[0000858877-18-000004:notes:6]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,694 |  |  | $ | 6,545 |  |  | $ | 13,664 |  |  | $ | 13,818 |  |
| Applications | 1,184 |  |  | 1,116 |  |  | 2,387 |  |  | 2,252 |  |
| Security | 558 |  |  | 528 |  |  | 1,143 |  |  | 1,068 |  |
| Other Products | 273 |  |  | 302 |  |  | 569 |  |  | 655 |  |
| Total Product | 8,709 |  |  | 8,491 |  |  | 17,763 |  |  | 17,793 |  |
| Services | 3,178 |  |  | 3,089 |  |  | 6,260 |  |  | 6,139 |  |
| Total | $ | 11,887 |  |  | $ | 11,580 |  |  | $ | 24,023 |  |  | $ | 23,932 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-18-000004:notes:7]
A summary of the stock repurchase activity for fiscal year 2018 and 2017 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-18-000004:notes:8]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2018 |  |  |  |  |  |  |
| January 27, 2018 |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |
| October 28, 2017 |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |
| Fiscal 2017 |  |  |  |  |  |  |
| July 29, 2017 |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |
| April 29, 2017 |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |
| January 28, 2017 |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |
| October 29, 2016 |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-18-000004:notes:9]
[same as prior period, unchanged from 0000858877-17-000019:notes:12]

[0000858877-18-000004:notes:10]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | (63 | ) |  | $ | (175 | ) |  | $ | 63 |  |  | $ | 172 |  |
| Equity derivatives |  | Other income (loss), net |  | (35 | ) |  | — |  |  | 35 |  |  | — |  |
| Total |  |  |  | $ | (98 | ) |  | $ | (175 | ) |  | $ | 98 |  |  | $ | 172 |  |

[0000858877-18-000004:notes:11]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THESIX MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE SIX MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | (109 | ) |  | $ | (266 | ) |  | $ | 109 |  |  | $ | 262 |  |
| Equity derivatives |  | Other income (loss), net |  | (49 | ) |  | — |  |  | 49 |  |  | — |  |
| Total |  |  |  | $ | (158 | ) |  | $ | (266 | ) |  | $ | 158 |  |  | $ | 262 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-18-000004:notes:12]
[same as prior period, unchanged from 0000858877-17-000019:notes:14]

[0000858877-18-000004:notes:13]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 160 |  |  | $ | 124 |  |  | $ | 314 |  |  | $ | 253 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets | 60 |  |  | 64 |  |  | 121 |  |  | 142 |  |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | 38 |  |
| Total | $ | 220 |  |  | $ | 188 |  |  | $ | 435 |  |  | $ | 433 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-18-000004:notes:14]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the six months ended January 27, 2018 (in millions, except years):

[0000858877-18-000004:notes:15]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Viptela | 5.0 |  | $ | 144 |  |  | 6.0 |  | $ | 35 |  |  | 1.0 |  | $ | 1 |  |  | $ | — |  |  | $ | 180 |  |
| Springpath | 4.0 |  | 157 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 3 |  |  | 160 |  |
| Others (three in total) | 2.5 |  | 18 |  |  | 4.0 |  | 3 |  |  | 0.0 |  | — |  |  | — |  |  | 21 |  |
| Total |  |  | $ | 319 |  |  |  |  | $ | 38 |  |  |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 361 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-18-000004:notes:16]
[same as prior period, unchanged from 0000858877-17-000019:notes:18]

[0000858877-18-000004:notes:17]
| January 27, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,465 |  |  | $ | (1,659 | ) |  | $ | 1,806 |  |
| Customer relationships |  | 1,387 |  |  | (867 | ) |  | 520 |  |
| Other |  | 82 |  |  | (51 | ) |  | 31 |  |
| Total purchased intangible assets with finite lives |  | 4,934 |  |  | (2,577 | ) |  | 2,357 |  |
| In-process research and development, with indefinite lives |  | 117 |  |  | — |  |  | 117 |  |
| Total |  | $ | 5,051 |  |  | $ | (2,577 | ) |  | $ | 2,474 |  |

[0000858877-18-000004:notes:18]
[same as prior period, unchanged from 0000858877-17-000019:notes:20]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-18-000004:notes:19]
[same as prior period, unchanged from 0000858877-17-000019:notes:21]

[0000858877-18-000004:notes:20]
[same as prior period, unchanged from 0000858877-17-000019:notes:22]

[0000858877-18-000004:notes:21]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-18-000004:notes:22]
Summarized financial information by segment for the three and six months ended January 27, 2018 and January 28, 2017, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-18-000004:notes:23]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,004 |  |  | $ | 6,660 |  |  | $ | 14,354 |  |  | $ | 14,103 |  |
| EMEA | 3,062 |  |  | 3,065 |  |  | 5,971 |  |  | 6,078 |  |
| APJC | 1,821 |  |  | 1,855 |  |  | 3,698 |  |  | 3,751 |  |
| Total | $ | 11,887 |  |  | $ | 11,580 |  |  | $ | 24,023 |  |  | $ | 23,932 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,614 |  |  | $ | 4,288 |  |  | $ | 9,336 |  |  | $ | 9,121 |  |
| EMEA | 1,977 |  |  | 2,012 |  |  | 3,816 |  |  | 4,025 |  |
| APJC | 1,094 |  |  | 1,121 |  |  | 2,259 |  |  | 2,325 |  |
| Segment total | 7,685 |  |  | 7,421 |  |  | 15,411 |  |  | 15,471 |  |
| Unallocated corporate items | (187 | ) |  | (145 | ) |  | (486 | ) |  | (311 | ) |
| Total | $ | 7,498 |  |  | $ | 7,276 |  |  | $ | 14,925 |  |  | $ | 15,160 |  |

[0000858877-18-000004:notes:24]
Revenue in the United States was $6.1 billion and $5.9 billion for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $12.6 billion and $12.5 billion for the six months ended January 27, 2018 and January 28, 2017, respectively.

[0000858877-18-000004:notes:25]
[same as prior period, unchanged from 0000858877-17-000019:notes:27]

[0000858877-18-000004:notes:26]
[same as prior period, unchanged from 0000858877-17-000019:notes:28]

[0000858877-18-000004:notes:27]
[same as prior period, unchanged from 0000858877-17-000019:notes:29]

[0000858877-18-000004:notes:28]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, was attributable to its U.S. operations as of each of January 27, 2018 and July 29, 2017. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $71.3 billion and $67.5 billion as of January 27, 2018 and July 29, 2017, respectively, and the remaining $2.4 billion and $3.0 billion at the respective period ends were available in the United States.

[0000858877-18-000004:notes:29]
[same as prior period, unchanged from 0000858877-17-000019:notes:31]

[0000858877-18-000004:notes:30]
|  | January 27, 2018 |  | July 29, 2017 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,555 |  |  | $ | 2,711 |  |
| International | 558 |  |  | 611 |  |
| Total | $ | 3,113 |  |  | $ | 3,322 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-18-000004:notes:31]
[same as prior period, unchanged from 0000858877-17-000019:notes:34]

[0000858877-18-000004:notes:32]
| Three months ended January 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 28, 2017 | $ | 160 |  |  | $ | 106 |  |  | $ | 23 |  |  | $ | 289 |  |
| Provisions | 3 |  |  | (13 | ) |  | (10 | ) |  | (20 | ) |
| Foreign exchange and other | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of January 27, 2018 | $ | 165 |  |  | $ | 94 |  |  | $ | 13 |  |  | $ | 272 |  |

[0000858877-18-000004:notes:33]
| Six months ended January 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions | 1 |  |  | (11 | ) |  | (16 | ) |  | (26 | ) |
| Foreign exchange and other | 2 |  |  | 2 |  |  | (1 | ) |  | 3 |  |
| Allowance for credit loss as of January 27, 2018 | $ | 165 |  |  | $ | 94 |  |  | $ | 13 |  |  | $ | 272 |  |

[0000858877-18-000004:notes:34]
| Three months ended January 28, 2017 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 29, 2016 | $ | 227 |  |  | $ | 111 |  |  | $ | 48 |  |  | $ | 386 |  |
| Provisions | 2 |  |  | — |  |  | (1 | ) |  | 1 |  |
| Recoveries (write-offs), net | (2 | ) |  | (4 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | (2 | ) |  | (1 | ) |  | — |  |  | (3 | ) |
| Allowance for credit loss as of January 28, 2017 | $ | 225 |  |  | $ | 106 |  |  | $ | 47 |  |  | $ | 378 |  |

[0000858877-18-000004:notes:35]
| Six months ended January 28, 2017 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | (2 | ) |  | 12 |  |  | (1 | ) |  | 9 |  |
| Recoveries (write-offs), net | (2 | ) |  | (4 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | (1 | ) |  | 1 |  |  | — |  |  | — |  |
| Allowance for credit loss as of January 28, 2017 | $ | 225 |  |  | $ | 106 |  |  | $ | 47 |  |  | $ | 378 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-18-000004:notes:36]
[same as prior period, unchanged from 0000858877-17-000019:notes:37]

[0000858877-18-000004:notes:37]
The accompanying financial data as of January 27, 2018 and for the three and six months ended January 27, 2018 and January 28, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

[0000858877-18-000004:notes:38]
[same as prior period, unchanged from 0000858877-17-000019:notes:39]

[0000858877-18-000004:notes:39]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three and six months ended January 27, 2018 and January 28, 2017; the statements of cash flows and equity for the six months ended January 27, 2018 and January 28, 2017, as applicable, have been made. The results of operations for the three and six months ended January 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-18-000004:notes:40]
[same as prior period, unchanged from 0000858877-17-000019:notes:41]

[0000858877-18-000004:notes:41]
The Company completed five acquisitions during the six months ended January 27, 2018. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-18-000004:notes:42]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Viptela | $ | 497 |  |  | $ | (18 | ) |  | $ | 180 |  |  | $ | 335 |  |
| Springpath | 248 |  |  | (11 | ) |  | 160 |  |  | 99 |  |
| Others (three in total) | 43 |  |  | (2 | ) |  | 21 |  |  | 24 |  |
| Total | $ | 788 |  |  | $ | (31 | ) |  | $ | 361 |  |  | $ | 458 |  |

[0000858877-18-000004:notes:43]
[same as prior period, unchanged from 0000858877-17-000019:notes:44]

[0000858877-18-000004:notes:44]
[same as prior period, unchanged from 0000858877-17-000019:notes:45]

[0000858877-18-000004:notes:45]
The total purchase consideration related to acquisitions completed during the six months ended January 27, 2018 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $12 million. Total transaction costs related to acquisition activities were $14 million and $3 million for the six months ended January 27, 2018 and January 28, 2017, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations. The Company recognized a gain of $46 million in the first quarter of fiscal 2018 in connection with a step acquisition. This gain was recognized in other income (loss), net in the Consolidated Statement of Operations.

[0000858877-18-000004:notes:46]
[same as prior period, unchanged from 0000858877-17-000019:notes:47]

[0000858877-18-000004:notes:47]
The goodwill generated from acquisitions completed during the six months ended January 27, 2018 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-18-000004:notes:48]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the six months ended January 27, 2018 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-18-000004:notes:49]
The Company completed two divestitures during the second quarter of fiscal 2018. The financial statement impact of these divestitures was not material for the three and six months ended January 27, 2018.

[0000858877-18-000004:notes:50]
Acquisition of BroadSoft On February 1, 2018, the Company completed its acquisition of BroadSoft, Inc. ("BroadSoft"), a cloud calling and contact center solutions company for total consideration of approximately $1.9 billion, net of cash and short-term investments. Revenue from the BroadSoft acquisition will be included in the Company's Applications product category. The Company expects that most of the purchase price will be allocated to goodwill and purchased intangible assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-18-000004:notes:51]
Commitments and Contingencies

[0000858877-18-000004:notes:52]
| (a) | Operating Leases |

[0000858877-18-000004:notes:53]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 27, 2018 are as follows (in millions):

[0000858877-18-000004:notes:54]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 220 |  |
| 2019 | 323 |  |
| 2020 | 239 |  |
| 2021 | 147 |  |
| 2022 | 122 |  |
| Thereafter | 178 |  |
| Total | $ | 1,229 |  |

[0000858877-18-000004:notes:55]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-18-000004:notes:56]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

[0000858877-18-000004:notes:57]
The following table summarizes the Company's purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-18-000004:notes:58]
| Commitments by Period | January 27, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 4,498 |  |  | $ | 4,620 |  |
| 1 to 3 years | 690 |  |  | 20 |  |
| 3 to 5 years | 540 |  |  | — |  |
| Total | $ | 5,728 |  |  | $ | 4,640 |  |

[0000858877-18-000004:notes:59]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 27, 2018 and July 29, 2017, the liability for these purchase commitments was $159 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-18-000004:notes:60]
| (c) | Other Commitments |

[0000858877-18-000004:notes:61]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-18-000004:notes:62]
As of January 27, 2018, the Company estimated that future cash compensation expense of up to $246 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-18-000004:notes:63]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million during the six months ended January 28, 2017. The Company recorded compensation expense of $12 million during the three months ended January 28, 2017, and $32 million during the six months ended January 28, 2017, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-18-000004:notes:64]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $215 million and $216 million as of January 27, 2018 and July 29, 2017, respectively.

[0000858877-18-000004:notes:65]
| (d) | Product Warranties |

[0000858877-18-000004:notes:66]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-18-000004:notes:67]
|  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 287 |  |  | 367 |  |
| Adjustments for pre-existing warranties | (21 | ) |  | (3 | ) |
| Settlements | (292 | ) |  | (352 | ) |
| Balance at end of period | $ | 381 |  |  | $ | 426 |  |

[0000858877-18-000004:notes:68]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-18-000004:notes:69]
| (e) | Financing and Other Guarantees |

[0000858877-18-000004:notes:70]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-18-000004:notes:71]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $13.6 billion and $13.2 billion for the six months ended January 27, 2018 and January 28, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of January 27, 2018 and July 29, 2017.

[0000858877-18-000004:notes:72]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $12 million and $30 million for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $26 million and $36 million for the six months ended January 27, 2018 and January 28, 2017, respectively.

[0000858877-18-000004:notes:73]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 27, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-18-000004:notes:74]
|  | January 27, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 288 |  |  | $ | 240 |  |
| End user | 53 |  |  | 74 |  |
| Total | $ | 341 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (91 | ) |  | $ | (82 | ) |
| End user | (40 | ) |  | (52 | ) |
| Total | $ | (131 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 210 |  |  | $ | 180 |  |

[0000858877-18-000004:notes:75]
Other Guarantees   The Company’s other guarantee arrangements as of January 27, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

[0000858877-18-000004:notes:76]
| (f) | Supplier Component Remediation Liabilities |

[0000858877-18-000004:notes:77]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of January 27, 2018 and July 29, 2017 were $120 million and $174 million, respectively.

[0000858877-18-000004:notes:78]
| (g) | Indemnifications |

[0000858877-18-000004:notes:79]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-18-000004:notes:80]
The Company has been asked to indemnify certain of the Company’s service provider customers that have been subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and, on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. On December 6, 2017, Sprint and Cox Communications, Inc. reached resolution of the claims in Sprint's lawsuit against Cox, and the Delaware court dismissed Sprint's lawsuit against Cox on December 7, 2017.

[0000858877-18-000004:notes:81]
The Company believes that Time Warner Cable continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the Time Warner Cable litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify Time Warner Cable for damages, mediation awards, or settlement amounts arising from its use of Cisco products.

[0000858877-18-000004:notes:82]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringed 12 patents. Huawei's infringement allegations for some of the patents were based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On December 22, 2017, the Eastern District of Texas court dismissed Huawei's four lawsuits after the parties reached settlement, and T-Mobile's indemnity request was subsequently resolved.

[0000858877-18-000004:notes:83]
During the first six months of fiscal 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.

[0000858877-18-000004:notes:84]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-18-000004:notes:85]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-18-000004:notes:86]
| (h) | Legal Proceedings |

[0000858877-18-000004:notes:87]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-18-000004:notes:88]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $257 million for the alleged evasion of import and other taxes, $1.6 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 27, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-18-000004:notes:89]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-18-000004:notes:90]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has appealed this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-18-000004:notes:91]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

[0000858877-18-000004:notes:92]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

[0000858877-18-000004:notes:93]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-18-000004:notes:94]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.

[0000858877-18-000004:notes:95]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-18-000004:notes:96]
Comprehensive Income (Loss)

[0000858877-18-000004:notes:97]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the six months ended January 27, 2018 and January 28, 2017 are summarized as follows (in millions):

[0000858877-18-000004:notes:98]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (174 | ) |  | 38 |  |  | 292 |  |  | 156 |  |
| (Gains) losses reclassified out of AOCI | (91 | ) |  | (31 | ) |  | 5 |  |  | (117 | ) |
| Tax benefit (expense) | 3 |  |  | 1 |  |  | (6 | ) |  | (2 | ) |
| BALANCE AT JANUARY 27, 2018 | $ | 111 |  |  | $ | 40 |  |  | $ | (68 | ) |  | $ | 83 |  |

[0000858877-18-000004:notes:99]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (559 | ) |  | (48 | ) |  | (69 | ) |  | (676 | ) |
| (Gains) losses reclassified out of AOCI | 15 |  |  | 39 |  |  | (1 | ) |  | 53 |  |
| Tax benefit (expense) | 148 |  |  | 1 |  |  | (1 | ) |  | 148 |  |
| BALANCE AT JANUARY 28, 2017 | $ | 17 |  |  | $ | (67 | ) |  | $ | (751 | ) |  | $ | (801 | ) |

[0000858877-18-000004:notes:100]
[same as prior period, unchanged from 0000858877-17-000019:notes:99]

[0000858877-18-000004:notes:101]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 14 |  |  | (21 | ) |  | 24 |  |  | (30 | ) | Operating expenses |
| Foreign currency derivatives |  | 4 |  |  | (6 | ) |  | 7 |  |  | (9 | ) | Cost of sales—service |
|  |  | 18 |  |  | (27 | ) |  | 31 |  |  | (39 | ) |  |
| Cumulative translation adjustment and actuarial gains and losses |  | (4 | ) |  | 1 |  |  | (5 | ) |  | 1 |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 72 |  |  | $ | (56 | ) |  | $ | 117 |  |  | $ | (53 | ) |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-18-000004:notes:102]
Borrowings

[0000858877-18-000004:notes:103]
| (a) | Short-Term Debt |

[0000858877-18-000004:notes:104]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-18-000004:notes:105]
|  | January 27, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,749 |  |  | 1.78 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 8,992 |  |  | 1.51 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 13,741 |  |  |  |  | $ | 7,992 |  |  |  |

[0000858877-18-000004:notes:106]
The Company has a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-18-000004:notes:107]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-18-000004:notes:108]
| (b) | Long-Term Debt |

[0000858877-18-000004:notes:109]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-18-000004:notes:110]
|  |  |  | January 27, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 2.11% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.96% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.04% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.01% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.04% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.18% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.11% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.34% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.60% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.46% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.76% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (125 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (1 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,749 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,625 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |

[0000858877-18-000004:notes:111]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-18-000004:notes:112]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2018, the Company was in compliance with all debt covenants.

[0000858877-18-000004:notes:113]
As of January 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-18-000004:notes:114]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |

[0000858877-18-000004:notes:115]
| (c) | Credit Facilities |

[0000858877-18-000004:notes:116]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-18-000004:notes:117]
In addition, on March 30, 2017, the Company entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides the Company with the option to, for a fee, convert any borrowing outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company's senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

[0000858877-18-000004:notes:118]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of January 27, 2018, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-18-000004:notes:119]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,963 |  |  | $ | 11,302 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  | 5,451 |  |  | 4,971 |  |
| Other product deferred revenue |  | 2,374 |  |  | 2,221 |  |
| Total product deferred revenue |  | 7,825 |  |  | 7,192 |  |
| Total |  | $ | 18,788 |  |  | $ | 18,494 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,102 |  |  | $ | 10,821 |  |
| Noncurrent |  | 7,686 |  |  | 7,673 |  |
| Total |  | $ | 18,788 |  |  | $ | 18,494 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-18-000004:notes:120]
[same as prior period, unchanged from 0000858877-17-000019:notes:119]

[0000858877-18-000004:notes:121]
[same as prior period, unchanged from 0000858877-17-000019:notes:120]

[0000858877-18-000004:notes:122]
[same as prior period, unchanged from 0000858877-17-000019:notes:121]

[0000858877-18-000004:notes:123]
[same as prior period, unchanged from 0000858877-17-000019:notes:122]

[0000858877-18-000004:notes:124]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 27, 2018 |  | July 29, 2017 |  | Balance Sheet Line Item |  | January 27, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 47 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | — |  |  | $ | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 49 |  |  | — |  |
| Interest rate derivatives | Other assets |  | 18 |  |  | 102 |  |  | Other long-term liabilities |  | 26 |  |  | — |  |
| Total |  |  | 65 |  |  | 148 |  |  |  |  | 75 |  |  | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 24 |  |  | 1 |  |  | Other current liabilities |  | 1 |  |  | 3 |  |
| Total return swaps—deferred compensation | Other current assets |  | 1 |  |  | — |  |  | Other current liabilities |  | — |  |  | — |  |
| Total |  |  | 25 |  |  | 1 |  |  |  |  | 1 |  |  | 3 |  |
| Total |  |  | $ | 90 |  |  | $ | 149 |  |  |  |  | $ | 76 |  |  | $ | 4 |  |

[0000858877-18-000004:notes:125]
[same as prior period, unchanged from 0000858877-17-000019:notes:124]

[0000858877-18-000004:notes:126]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Line Item in Statements of Operations |  | January 27, 2018 |  | January 28, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 30 |  |  | $ | (2 | ) |  | Operating expenses |  | $ | 14 |  |  | $ | (21 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | 4 |  |  | (6 | ) |
| Total |  | $ | 30 |  |  | $ | (2 | ) |  |  |  | $ | 18 |  |  | $ | (27 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (12 | ) |  | $ | (3 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-18-000004:notes:127]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE SIX MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THESIX MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 27, 2018 |  | January 28, 2017 |  | Line Item in Statements of Operations |  | January 27, 2018 |  | January 28, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 38 |  |  | $ | (48 | ) |  | Operating expenses |  | $ | 24 |  |  | $ | (30 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | 7 |  |  | (9 | ) |
| Total |  | $ | 38 |  |  | $ | (48 | ) |  |  |  | $ | 31 |  |  | $ | (39 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (17 | ) |  | $ | 6 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-18-000004:notes:128]
As of January 27, 2018, the Company estimates that approximately $56 million of net derivative gains related to its cash flow hedges included in accumulated other comprehensive income ("AOCI") will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-18-000004:notes:129]
[same as prior period, unchanged from 0000858877-17-000019:notes:127]

[0000858877-18-000004:notes:130]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 66 |  |  | $ | (20 | ) |  | $ | 73 |  |  | $ | (36 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 41 |  |  | 26 |  |  | 57 |  |  | 23 |  |
| Equity derivatives |  | Other income (loss), net |  | 2 |  |  | 8 |  |  | 3 |  |  | 9 |  |
| Total |  |  |  | $ | 109 |  |  | $ | 14 |  |  | $ | 133 |  |  | $ | (4 | ) |

[0000858877-18-000004:notes:131]
[same as prior period, unchanged from 0000858877-17-000019:notes:129]

[0000858877-18-000004:notes:132]
|  | January 27, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 792 |  |  | $ | 1,696 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 214 |  |  | 351 |  |
| Equity derivatives | 302 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 3,072 |  |  | 2,258 |  |
| Total return swaps—deferred compensation | 590 |  |  | 535 |  |
| Total | $ | 11,720 |  |  | $ | 11,590 |  |

[0000858877-18-000004:notes:133]
[same as prior period, unchanged from 0000858877-17-000019:notes:131]

[0000858877-18-000004:notes:134]
[same as prior period, unchanged from 0000858877-17-000019:notes:132]

[0000858877-18-000004:notes:135]
|  | January 27, 2018 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | (32 | ) |  | $ | (18 | ) |  | $ | 40 |  |
| Derivatives liabilities | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |  | $ | (32 | ) |  | $ | (18 | ) |  | $ | 26 |  |

[0000858877-18-000004:notes:136]
[same as prior period, unchanged from 0000858877-17-000019:notes:134]

[0000858877-18-000004:notes:137]
[same as prior period, unchanged from 0000858877-17-000019:notes:135]

[0000858877-18-000004:notes:138]
[same as prior period, unchanged from 0000858877-17-000019:notes:136]

[0000858877-18-000004:notes:139]
[same as prior period, unchanged from 0000858877-17-000019:notes:137]

[0000858877-18-000004:notes:140]
[same as prior period, unchanged from 0000858877-17-000019:notes:138]

[0000858877-18-000004:notes:141]
[same as prior period, unchanged from 0000858877-17-000019:notes:139]

[0000858877-18-000004:notes:142]
[same as prior period, unchanged from 0000858877-17-000019:notes:140]

[0000858877-18-000004:notes:143]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of January 27, 2018 and July 29, 2017, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-18-000004:notes:144]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the six months ended January 27, 2018, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-18-000004:notes:145]
[same as prior period, unchanged from 0000858877-17-000019:notes:143]

[0000858877-18-000004:notes:146]
[same as prior period, unchanged from 0000858877-17-000019:notes:144]

[0000858877-18-000004:notes:147]
[same as prior period, unchanged from 0000858877-17-000019:notes:145]

[0000858877-18-000004:notes:148]
[same as prior period, unchanged from 0000858877-17-000019:notes:146]

[0000858877-18-000004:notes:149]
[same as prior period, unchanged from 0000858877-17-000019:notes:147]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-18-000004:notes:150]
[same as prior period, unchanged from 0000858877-17-000019:notes:148]

[0000858877-18-000004:notes:151]
[same as prior period, unchanged from 0000858877-17-000019:notes:149]

[0000858877-18-000004:notes:152]
Stock Incentive Plan Program Description    As of January 27, 2018, the Company had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plan is summarized as follows:

[0000858877-18-000004:notes:153]
2005 Plan    As of January 27, 2018, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-18-000004:notes:154]
[same as prior period, unchanged from 0000858877-17-000019:notes:152]

[0000858877-18-000004:notes:155]
[same as prior period, unchanged from 0000858877-17-000019:notes:153]

[0000858877-18-000004:notes:156]
[same as prior period, unchanged from 0000858877-17-000019:notes:154]

[0000858877-18-000004:notes:157]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of January 27, 2018. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 12 million shares under the Purchase Plan during the six months ended January 27, 2018 and January 28, 2017. As of January 27, 2018, 88 million shares were available for issuance under the Purchase Plan.

[0000858877-18-000004:notes:158]
[same as prior period, unchanged from 0000858877-17-000019:notes:156]

[0000858877-18-000004:notes:159]
[same as prior period, unchanged from 0000858877-17-000019:notes:157]

[0000858877-18-000004:notes:160]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Cost of sales—product | $ | 23 |  |  | $ | 19 |  |  | $ | 46 |  |  | $ | 40 |  |
| Cost of sales—service | 31 |  |  | 34 |  |  | 65 |  |  | 67 |  |
| Share-based compensation expense in cost of sales | 54 |  |  | 53 |  |  | 111 |  |  | 107 |  |
| Research and development | 134 |  |  | 129 |  |  | 270 |  |  | 255 |  |
| Sales and marketing | 135 |  |  | 125 |  |  | 270 |  |  | 265 |  |
| General and administrative | 64 |  |  | 45 |  |  | 128 |  |  | 94 |  |
| Restructuring and other charges | 12 |  |  | — |  |  | 18 |  |  | 3 |  |
| Share-based compensation expense in operating expenses | 345 |  |  | 299 |  |  | 686 |  |  | 617 |  |
| Total share-based compensation expense | $ | 399 |  |  | $ | 352 |  |  | $ | 797 |  |  | $ | 724 |  |
| Income tax benefit for share-based compensation | $ | 96 |  |  | $ | 102 |  |  | $ | 271 |  |  | $ | 207 |  |

[0000858877-18-000004:notes:161]
As of January 27, 2018, the total compensation cost related to unvested share-based awards not yet recognized was $3.4 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-18-000004:notes:162]
[same as prior period, unchanged from 0000858877-17-000019:notes:160]

[0000858877-18-000004:notes:163]
[same as prior period, unchanged from 0000858877-17-000019:notes:161]

[0000858877-18-000004:notes:164]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 30, 2016 | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (76 | ) |
| Share-based awards canceled/forfeited/expired | 78 |  |
| Shares withheld for taxes and not issued | 28 |  |
| BALANCE AT JULY 29, 2017 | 272 |  |
| Restricted stock, stock units, and other share-based awards granted | (46 | ) |
| Share-based awards canceled/forfeited/expired | 10 |  |
| Shares withheld for taxes and not issued | 18 |  |
| BALANCE AT JANUARY 27, 2018 | 254 |  |

[0000858877-18-000004:notes:165]
[same as prior period, unchanged from 0000858877-17-000019:notes:163]

[0000858877-18-000004:notes:166]
[same as prior period, unchanged from 0000858877-17-000019:notes:164]

[0000858877-18-000004:notes:167]
[same as prior period, unchanged from 0000858877-17-000019:notes:165]

[0000858877-18-000004:notes:168]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | $ | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | 26.94 |  |  |  |
| Granted | 31 |  |  | 33.30 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (36 | ) |  | 25.21 |  |  | $ | 1,174 |  |
| Canceled/forfeited | (10 | ) |  | 27.83 |  |  |  |
| UNVESTED BALANCE AT JANUARY 27, 2018 | 127 |  |  | $ | 28.90 |  |  |  |

[0000858877-18-000004:notes:169]
[same as prior period, unchanged from 0000858877-17-000019:notes:167]

[0000858877-18-000004:notes:170]
[same as prior period, unchanged from 0000858877-17-000019:notes:168]

[0000858877-18-000004:notes:171]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 30, 2016 | 73 |  |  | $ | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (4 | ) |  | 5.28 |  |
| BALANCE AT JANUARY 27, 2018 | 11 |  |  | $ | 7.03 |  |

[0000858877-18-000004:notes:172]
The following table summarizes significant ranges of outstanding and exercisable stock options as of January 27, 2018 (in millions, except years and share prices):

[0000858877-18-000004:notes:173]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 35.00 |  | 11 |  |  | 6.5 |  | $ | 7.03 |  |  | $ | 380 |  |  | 5 |  |  | $ | 6.40 |  |  | $ | 194 |  |

[0000858877-18-000004:notes:174]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $42.56 as of January 26, 2018, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of January 27, 2018 was 5 million. As of July 29, 2017, 6 million outstanding stock options were exercisable and the weighted-average exercise price was $5.61.

[0000858877-18-000004:notes:175]
[same as prior period, unchanged from 0000858877-17-000019:notes:173]

[0000858877-18-000004:notes:176]
[same as prior period, unchanged from 0000858877-17-000019:notes:174]

[0000858877-18-000004:notes:177]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Number of shares granted (in millions) | 21 |  |  | 15 |  |  | — |  |  | 3 |  |
| Grant date fair value per share | $ | 34.89 |  |  | $ | 27.68 |  |  | $ | 32.47 |  |  | $ | 27.90 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 3.4 | % |  | 3.2 | % |  | 3.4 | % |
| Range of risk-free interest rates | 0.0% – 2.1% |  |  | 0.0% – 1.5% |  |  | 1.0% – 1.8% |  |  | 0.3% – 1.5% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.2% – 81.0% |  |  | N/A |  |

[0000858877-18-000004:notes:178]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Six Months Ended | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Number of shares granted (in millions) | 28 |  |  | 23 |  |  | 3 |  |  | 6 |  |
| Grant date fair value per share | $ | 33.50 |  |  | $ | 27.96 |  |  | $ | 31.31 |  |  | $ | 28.78 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 3.4 | % |  | 3.6 | % |  | 3.4 | % |
| Range of risk-free interest rates | 0.0% – 2.1% |  |  | 0.0% – 1.5% |  |  | 1.0% – 1.8% |  |  | 0.1% – 1.5% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.2% – 81.0% |  |  | 16.7% – 46.8% |  |

[0000858877-18-000004:notes:179]
[same as prior period, unchanged from 0000858877-17-000019:notes:176]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-18-000004:notes:180]
[same as prior period, unchanged from 0000858877-17-000019:notes:177]


## us-gaap:EarningsPerShareTextBlock

[0000858877-18-000004:notes:181]
Net Income (Loss) per Share

[0000858877-18-000004:notes:182]
The following table presents the calculation of basic and diluted net income (loss) per share (in millions, except per-share amounts):

[0000858877-18-000004:notes:183]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Net income (loss) | $ | (8,778 | ) |  | $ | 2,348 |  |  | $ | (6,384 | ) |  | $ | 4,670 |  |
| Weighted-average shares—basic | 4,924 |  |  | 5,015 |  |  | 4,942 |  |  | 5,021 |  |
| Effect of dilutive potential common shares | — |  |  | 25 |  |  | — |  |  | 33 |  |
| Weighted-average shares—diluted | 4,924 |  |  | 5,040 |  |  | 4,942 |  |  | 5,054 |  |
| Net income (loss) per share—basic | $ | (1.78 | ) |  | $ | 0.47 |  |  | $ | (1.29 | ) |  | $ | 0.93 |  |
| Net income (loss) per share—diluted | $ | (1.78 | ) |  | $ | 0.47 |  |  | $ | (1.29 | ) |  | $ | 0.92 |  |

[0000858877-18-000004:notes:184]
For the three and six months ended January 27, 2018, the Company excluded the impact of potentially dilutive common shares from the calculation of net income (loss) per share as the inclusion would have an antidilutive effect. The Company excluded antidilutive employee-share based awards of 20 million and 103 million for the three and six months ended January 28, 2017.


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-18-000004:notes:185]
[same as prior period, unchanged from 0000858877-17-000019:notes:183]

[0000858877-18-000004:notes:186]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | TOTAL GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Investments in privately held companies (impaired) | $ | (18 | ) |  | $ | (64 | ) |  | $ | (39 | ) |  | $ | (111 | ) |
| Purchased intangible assets (impaired) | — |  |  | — |  |  | — |  |  | (42 | ) |
| Property held for sale—land and buildings | 20 |  |  | (24 | ) |  | 20 |  |  | (24 | ) |
| Total gains (losses) for nonrecurring measurements | $ | 2 |  |  | $ | (88 | ) |  | $ | (19 | ) |  | $ | (177 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-18-000004:notes:187]
[same as prior period, unchanged from 0000858877-17-000019:notes:185]

[0000858877-18-000004:notes:188]
[same as prior period, unchanged from 0000858877-17-000019:notes:186]

[0000858877-18-000004:notes:189]
[same as prior period, unchanged from 0000858877-17-000019:notes:187]

[0000858877-18-000004:notes:190]
[same as prior period, unchanged from 0000858877-17-000019:notes:188]

[0000858877-18-000004:notes:191]
[same as prior period, unchanged from 0000858877-17-000019:notes:189]

[0000858877-18-000004:notes:192]
[same as prior period, unchanged from 0000858877-17-000019:notes:190]

[0000858877-18-000004:notes:193]
[same as prior period, unchanged from 0000858877-17-000019:notes:191]

[0000858877-18-000004:notes:194]
[same as prior period, unchanged from 0000858877-17-000019:notes:192]

[0000858877-18-000004:notes:195]
Assets and liabilities measured at fair value on a recurring basis as of January 27, 2018 and July 29, 2017 were as follows (in millions):

[0000858877-18-000004:notes:196]
|  | JANUARY 27, 2018FAIR VALUE MEASUREMENTS |  | JULY 29, 2017FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 15,537 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,537 |  |  | $ | 9,567 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,567 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 139 |  |  | — |  |  | 139 |  |
| Commercial paper | — |  |  | 41 |  |  | — |  |  | 41 |  |  | — |  |  | 160 |  |  | — |  |  | 160 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 17,366 |  |  | — |  |  | 17,366 |  |  | — |  |  | 19,823 |  |  | — |  |  | 19,823 |  |
| U.S. government agency securities | — |  |  | 1,712 |  |  | — |  |  | 1,712 |  |  | — |  |  | 2,052 |  |  | — |  |  | 2,052 |  |
| Non-U.S. government and agency securities | — |  |  | 339 |  |  | — |  |  | 339 |  |  | — |  |  | 388 |  |  | — |  |  | 388 |  |
| Corporate debt securities | — |  |  | 31,355 |  |  | — |  |  | 31,355 |  |  | — |  |  | 31,735 |  |  | — |  |  | 31,735 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,057 |  |  | — |  |  | 2,057 |  |  | — |  |  | 2,023 |  |  | — |  |  | 2,023 |  |
| Commercial paper | — |  |  | 1,414 |  |  | — |  |  | 1,414 |  |  | — |  |  | 996 |  |  | — |  |  | 996 |  |
| Certificates of deposit | — |  |  | 196 |  |  | — |  |  | 196 |  |  | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Publicly traded equity securities | 1,620 |  |  | — |  |  | — |  |  | 1,620 |  |  | 1,707 |  |  | — |  |  | — |  |  | 1,707 |  |
| Derivative assets | — |  |  | 90 |  |  | — |  |  | 90 |  |  | — |  |  | 149 |  |  | — |  |  | 149 |  |
| Total | $ | 17,157 |  |  | $ | 54,570 |  |  | $ | — |  |  | $ | 71,727 |  |  | $ | 11,274 |  |  | $ | 57,550 |  |  | $ | — |  |  | $ | 68,824 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0000858877-18-000004:notes:197]
[same as prior period, unchanged from 0000858877-17-000019:notes:195]

[0000858877-18-000004:notes:198]
[same as prior period, unchanged from 0000858877-17-000019:notes:196]

[0000858877-18-000004:notes:199]
[same as prior period, unchanged from 0000858877-17-000019:notes:197]

[0000858877-18-000004:notes:200]
[same as prior period, unchanged from 0000858877-17-000019:notes:198]

[0000858877-18-000004:notes:201]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $44 million as of each of January 27, 2018 and January 28, 2017.

[0000858877-18-000004:notes:202]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was $9 million as of January 28, 2017.

[0000858877-18-000004:notes:203]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charge as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of the property held for sale that was impaired was zero and $11 million as of January 27, 2018 and January 28, 2017, respectively.

[0000858877-18-000004:notes:204]
[same as prior period, unchanged from 0000858877-17-000019:notes:201]

[0000858877-18-000004:notes:205]
The carrying value of investments in privately held companies that were accounted for under the cost method was $861 million and $859 million as of January 27, 2018 and July 29, 2017, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-18-000004:notes:206]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of January 27, 2018 and July 29, 2017 was $3.5 billion and $3.4 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-18-000004:notes:207]
As of January 27, 2018, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of January 27, 2018, the fair value of the Company’s senior notes and other long-term debt was $31.8 billion with a carrying amount of $30.4 billion. This compares to a fair value of $32.1 billion and a carrying amount of $30.5 billion as of July 29, 2017. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-18-000004:notes:208]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of January 27, 2018 and July 29, 2017 are summarized as follows (in millions):

[0000858877-18-000004:notes:209]
|  | INTERNAL CREDIT RISK RATING |
| January 27, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,322 |  |  | $ | 1,244 |  |  | $ | 51 |  |  | $ | 2,617 |  |
| Loan receivables | 3,054 |  |  | 1,716 |  |  | 76 |  |  | 4,846 |  |
| Financed service contracts | 1,572 |  |  | 895 |  |  | 12 |  |  | 2,479 |  |
| Total | $ | 5,948 |  |  | $ | 3,855 |  |  | $ | 139 |  |  | $ | 9,942 |  |

[0000858877-18-000004:notes:210]
[same as prior period, unchanged from 0000858877-17-000019:notes:207]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-18-000004:notes:211]
[same as prior period, unchanged from 0000858877-17-000019:notes:208]

[0000858877-18-000004:notes:212]
[same as prior period, unchanged from 0000858877-17-000019:notes:209]

[0000858877-18-000004:notes:213]
[same as prior period, unchanged from 0000858877-17-000019:notes:210]

[0000858877-18-000004:notes:214]
[same as prior period, unchanged from 0000858877-17-000019:notes:211]

[0000858877-18-000004:notes:215]
| January 27, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,762 |  |  | $ | 4,846 |  |  | $ | 2,479 |  |  | $ | 10,087 |  |
| Residual value | 168 |  |  | — |  |  | — |  |  | 168 |  |
| Unearned income | (145 | ) |  | — |  |  | — |  |  | (145 | ) |
| Allowance for credit loss | (165 | ) |  | (94 | ) |  | (13 | ) |  | (272 | ) |
| Total, net | $ | 2,620 |  |  | $ | 4,752 |  |  | $ | 2,466 |  |  | $ | 9,838 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,222 |  |  | $ | 2,258 |  |  | $ | 1,445 |  |  | $ | 4,925 |  |
| Noncurrent | 1,398 |  |  | 2,494 |  |  | 1,021 |  |  | 4,913 |  |
| Total, net | $ | 2,620 |  |  | $ | 4,752 |  |  | $ | 2,466 |  |  | $ | 9,838 |  |

[0000858877-18-000004:notes:216]
[same as prior period, unchanged from 0000858877-17-000019:notes:213]

[0000858877-18-000004:notes:217]
Future minimum lease payments to the Company on lease receivables as of January 27, 2018 are summarized as follows (in millions):

[0000858877-18-000004:notes:218]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 707 |  |
| 2019 | 1,054 |  |
| 2020 | 602 |  |
| 2021 | 292 |  |
| 2022 | 98 |  |
| Thereafter | 9 |  |
| Total | $ | 2,762 |  |

[0000858877-18-000004:notes:219]
[same as prior period, unchanged from 0000858877-17-000019:notes:216]

[0000858877-18-000004:notes:220]
[same as prior period, unchanged from 0000858877-17-000019:notes:217]

[0000858877-18-000004:notes:221]
[same as prior period, unchanged from 0000858877-17-000019:notes:218]

[0000858877-18-000004:notes:222]
[same as prior period, unchanged from 0000858877-17-000019:notes:219]

[0000858877-18-000004:notes:223]
[same as prior period, unchanged from 0000858877-17-000019:notes:220]

[0000858877-18-000004:notes:224]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of January 27, 2018 and July 29, 2017 (in millions):

[0000858877-18-000004:notes:225]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 27, 2018 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 98 |  |  | $ | 96 |  |  | $ | 278 |  |  | $ | 472 |  |  | $ | 2,145 |  |  | $ | 2,617 |  |  | $ | 19 |  |  | $ | 19 |  |
| Loan receivables | 66 |  |  | 124 |  |  | 151 |  |  | 341 |  |  | 4,505 |  |  | 4,846 |  |  | 45 |  |  | 45 |  |
| Financed service contracts | 54 |  |  | 85 |  |  | 414 |  |  | 553 |  |  | 1,926 |  |  | 2,479 |  |  | 2 |  |  | 2 |  |
| Total | $ | 218 |  |  | $ | 305 |  |  | $ | 843 |  |  | $ | 1,366 |  |  | $ | 8,576 |  |  | $ | 9,942 |  |  | $ | 66 |  |  | $ | 66 |  |

[0000858877-18-000004:notes:226]
[same as prior period, unchanged from 0000858877-17-000019:notes:223]

[0000858877-18-000004:notes:227]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $462 million and $666 million as of January 27, 2018 and July 29, 2017, respectively.

[0000858877-18-000004:notes:228]
As of January 27, 2018, the Company had financing receivables of $358 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $315 million as of July 29, 2017.

[0000858877-18-000004:notes:229]
[same as prior period, unchanged from 0000858877-17-000019:notes:226]

[0000858877-18-000004:notes:230]
[same as prior period, unchanged from 0000858877-17-000019:notes:227]

[0000858877-18-000004:notes:231]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 27, 2018 and July 29, 2017, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-18-000004:notes:232]
[same as prior period, unchanged from 0000858877-17-000019:notes:229]

[0000858877-18-000004:notes:233]
[same as prior period, unchanged from 0000858877-17-000019:notes:230]

[0000858877-18-000004:notes:234]
[same as prior period, unchanged from 0000858877-17-000019:notes:231]

[0000858877-18-000004:notes:235]
|  | January 27, 2018 |  | July 29, 2017 |
| Operating lease assets | $ | 364 |  |  | $ | 356 |  |
| Accumulated depreciation | (232 | ) |  | (212 | ) |
| Operating lease assets, net | $ | 132 |  |  | $ | 144 |  |

[0000858877-18-000004:notes:236]
Minimum future rentals on noncancelable operating leases as of January 27, 2018 are summarized as follows (in millions):

[0000858877-18-000004:notes:237]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 103 |  |
| 2019 | 137 |  |
| 2020 | 68 |  |
| 2021 | 15 |  |
| Thereafter | 2 |  |
| Total | $ | 325 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-18-000004:notes:238]
[same as prior period, unchanged from 0000858877-17-000019:notes:235]

[0000858877-18-000004:notes:239]
[same as prior period, unchanged from 0000858877-17-000019:notes:236]

[0000858877-18-000004:notes:240]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the six months ended January 27, 2018 (in millions):

[0000858877-18-000004:notes:241]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 29, 2017 |  | Acquisitions |  | Other |  | January 27, 2018 |
| Americas | $ | 18,691 |  |  | $ | 337 |  |  | $ | 101 |  |  | $ | 19,129 |  |
| EMEA | 7,057 |  |  | 93 |  |  | 42 |  |  | 7,192 |  |
| APJC | 4,018 |  |  | 28 |  |  | 24 |  |  | 4,070 |  |
| Total | $ | 29,766 |  |  | $ | 458 |  |  | $ | 167 |  |  | $ | 30,391 |  |

[0000858877-18-000004:notes:242]
[same as prior period, unchanged from 0000858877-17-000019:notes:239]

[0000858877-18-000004:notes:243]
[same as prior period, unchanged from 0000858877-17-000019:notes:240]

[0000858877-18-000004:notes:244]
[same as prior period, unchanged from 0000858877-17-000019:notes:241]

[0000858877-18-000004:notes:245]
There were no impairment charges related to purchased intangible assets for the three and six months ended January 27, 2018. Impairment charges related to purchased intangible assets for the three and six months ended January 28, 2017 were zero and $42 million, respectively. Of these impairment charges, $38 million was recorded to restructuring and other charges in connection with the Company's decision to exit certain product lines, and the corresponding elimination of future associated cash flows. Impairment charges were primarily as a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets.

[0000858877-18-000004:notes:246]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 27, 2018 is as follows (in millions):

[0000858877-18-000004:notes:247]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 431 |  |
| 2019 | 781 |  |
| 2020 | 564 |  |
| 2021 | 364 |  |
| 2022 | 145 |  |
| Thereafter | 72 |  |
| Total | $ | 2,357 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-18-000004:notes:248]
[same as prior period, unchanged from 0000858877-17-000019:notes:245]

[0000858877-18-000004:notes:249]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.  As a fiscal-year taxpayer, certain provisions of the Tax Act impact the Company in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system and other changes to how foreign earnings are subject to U.S. tax, and elimination of the domestic manufacturing deduction.

[0000858877-18-000004:notes:250]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, the Company has computed its income tax expense for the July 28, 2018 fiscal year using a blended federal tax rate of 27%.  The 21% federal tax rate will apply to the Company’s fiscal year ending July 27, 2019 and each year thereafter. The Company must remeasure its deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000858877-18-000004:notes:251]
As of January 27, 2018, the Company has approximately $75 billion in undistributed earnings for certain foreign subsidiaries. Substantially all of these undistributed earnings are subject to the U.S. mandatory one-time transition tax and are eligible to be repatriated to the U.S. without additional U.S. tax under the Tax Act. The Company has historically asserted its intention to indefinitely reinvest foreign earnings in certain foreign subsidiaries. The Company has reevaluated its historic assertion as a result of enactment of the Tax Act and no longer considers these earnings to be indefinitely reinvested in its foreign subsidiaries. As a result of this change in assertion, the Company has recorded a $1.2 billion tax expense for foreign withholding tax in the second quarter of fiscal 2018.  In the third quarter of fiscal 2018, the Company anticipates repatriating $67 billion of foreign subsidiary earnings to the U.S. (in the form of cash, cash equivalents, or investments), of which $26 billion was repatriated to the U.S. in February 2018.

[0000858877-18-000004:notes:252]
During the three months ended January 27, 2018, the Company recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $9.0 billion of U.S. transition tax, $1.2 billion of foreign withholding tax (discussed above), and $0.9 billion re-measurement of net DTA. The Company plans to pay the transition tax in installments over eight years in accordance with the Tax Act. The $1.2 billion foreign withholding tax was paid in February 2018.

[0000858877-18-000004:notes:253]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional amounts due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. The Company has determined that the $9.0 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $0.9 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of January 27, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000004:notes:254]
As of January 27, 2018, the Company had $2.0 billion of unrecognized tax benefit, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at January 27, 2018 could be reduced by approximately $250 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-18-000004:notes:255]
The following table summarizes the maturities of the Company’s fixed income securities as of January 27, 2018 (in millions):

[0000858877-18-000004:notes:256]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,881 |  |  | $ | 15,847 |  |
| Due in 1 to 2 years | 12,267 |  |  | 12,188 |  |
| Due in 2 to 5 years | 22,095 |  |  | 21,926 |  |
| Due after 5 years | 2,443 |  |  | 2,421 |  |
| Mortgage-backed securities with no single maturity | 2,106 |  |  | 2,057 |  |
| Total | $ | 54,792 |  |  | $ | 54,439 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-18-000004:notes:257]
Investments

[0000858877-18-000004:notes:258]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-18-000004:notes:259]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-18-000004:notes:260]
| January 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 17,506 |  |  | $ | — |  |  | $ | (140 | ) |  | $ | 17,366 |  |
| U.S. government agency securities | 1,722 |  |  | — |  |  | (10 | ) |  | 1,712 |  |
| Non-U.S. government and agency securities | 340 |  |  | — |  |  | (1 | ) |  | 339 |  |
| Corporate debt securities | 31,508 |  |  | 80 |  |  | (233 | ) |  | 31,355 |  |
| U.S. agency mortgage-backed securities | 2,106 |  |  | — |  |  | (49 | ) |  | 2,057 |  |
| Commercial paper | 1,414 |  |  | — |  |  | — |  |  | 1,414 |  |
| Certificates of deposit | 196 |  |  | — |  |  | — |  |  | 196 |  |
| Total fixed income securities | 54,792 |  |  | 80 |  |  | (433 | ) |  | 54,439 |  |
| Publicly traded equity securities | 924 |  |  | 697 |  |  | (1 | ) |  | 1,620 |  |
| Total (1) | $ | 55,716 |  |  | $ | 777 |  |  | $ | (434 | ) |  | $ | 56,059 |  |

[0000858877-18-000004:notes:261]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |

[0000858877-18-000004:notes:262]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(3) million and $(30) million as of January 27, 2018 and July 29, 2017, respectively.

[0000858877-18-000004:notes:263]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-18-000004:notes:264]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-18-000004:notes:265]
The following table presents the gross realized gains and gross realized losses related to available-for-sale investments (in millions):

[0000858877-18-000004:notes:266]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Gross realized gains | $ | 165 |  |  | $ | 18 |  |  | $ | 232 |  |  | $ | 48 |  |
| Gross realized losses | (107 | ) |  | (48 | ) |  | (141 | ) |  | (63 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |

[0000858877-18-000004:notes:267]
The following table presents the realized net gains (losses) related to available-for-sale investments by security type (in millions):

[0000858877-18-000004:notes:268]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 154 |  |  | $ | 4 |  |  | $ | 183 |  |  | $ | 9 |  |
| Net gains (losses) on investments in fixed income securities | (96 | ) |  | (34 | ) |  | (92 | ) |  | (24 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |

[0000858877-18-000004:notes:269]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2018 and July 29, 2017 (in millions):

[0000858877-18-000004:notes:270]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,553 |  |  | $ | (96 | ) |  | $ | 5,804 |  |  | $ | (44 | ) |  | $ | 17,357 |  |  | $ | (140 | ) |
| U.S. government agency securities | 1,152 |  |  | (5 | ) |  | 559 |  |  | (5 | ) |  | 1,711 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 136 |  |  | — |  |  | 203 |  |  | (1 | ) |  | 339 |  |  | (1 | ) |
| Corporate debt securities | 16,003 |  |  | (146 | ) |  | 4,287 |  |  | (87 | ) |  | 20,290 |  |  | (233 | ) |
| U.S. agency mortgage-backed securities | 1,161 |  |  | (19 | ) |  | 876 |  |  | (30 | ) |  | 2,037 |  |  | (49 | ) |
| Total fixed income securities | 30,005 |  |  | (266 | ) |  | 11,729 |  |  | (167 | ) |  | 41,734 |  |  | (433 | ) |
| Publicly traded equity securities | 10 |  |  | (1 | ) |  | — |  |  | — |  |  | 10 |  |  | (1 | ) |
| Total | $ | 30,015 |  |  | $ | (267 | ) |  | $ | 11,729 |  |  | $ | (167 | ) |  | $ | 41,744 |  |  | $ | (434 | ) |

[0000858877-18-000004:notes:271]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

[0000858877-18-000004:notes:272]
The net realized losses related to the Company's available-for-sale investments included impairment charges of zero and $26 million for the three and six months ended January 27, 2018, respectively. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2017.

[0000858877-18-000004:notes:273]
As of January 27, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 27, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 27, 2018.

[0000858877-18-000004:notes:274]
The Company has evaluated its publicly traded equity securities as of January 27, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-18-000004:notes:275]
| (c) | Maturities of Fixed Income Securities |

[0000858877-18-000004:notes:276]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-18-000004:notes:277]
| (d) | Securities Lending |

[0000858877-18-000004:notes:278]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 27, 2018 and January 28, 2017 was $0.4 billion and $0.9 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 27, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.

[0000858877-18-000004:notes:279]
| (e) | Investments in Privately Held Companies |

[0000858877-18-000004:notes:280]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 27, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-18-000004:notes:281]
|  | January 27, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 121 |  |  | $ | 124 |  |
| Cost method investments | 861 |  |  | 859 |  |
| Total | $ | 982 |  |  | $ | 983 |  |

[0000858877-18-000004:notes:282]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-18-000004:notes:283]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-18-000004:notes:284]
As of January 27, 2018, the carrying value of investments in privately held companies was $982 million, of which $528 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $215 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-18-000004:notes:285]
(a) New Accounting Updates Recently Adopted

[0000858877-18-000004:notes:286]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the six months ended January 27, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

[0000858877-18-000004:notes:287]
(b) Recent Accounting Standards or Updates Not Yet Effective as of Period End

[0000858877-18-000004:notes:288]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-18-000004:notes:289]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

[0000858877-18-000004:notes:290]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

[0000858877-18-000004:notes:291]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details both the current and expected revenue recognition timing in these areas:

[0000858877-18-000004:notes:292]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-18-000004:notes:293]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

[0000858877-18-000004:notes:294]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

[0000858877-18-000004:notes:295]
Cisco will be required to record cumulative effect adjustments to retained earnings (net of tax) upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

[0000858877-18-000004:notes:296]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

[0000858877-18-000004:notes:297]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-18-000004:notes:298]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-18-000004:notes:299]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-18-000004:notes:300]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-18-000004:notes:301]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

[0000858877-18-000004:notes:302]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-18-000004:notes:303]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.

[0000858877-18-000004:notes:304]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued a new accounting standard update that allows companies to reclassify from Accumulated Other Comprehensive Income to Retained Earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). Cisco will adopt this accounting standard update in the third quarter of fiscal 2018 on a retrospective basis. The application of this accounting standard update will not have a material impact on the Company's Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-18-000004:notes:305]
[same as prior period, unchanged from 0000858877-17-000019:notes:295]

[0000858877-18-000004:notes:306]
[same as prior period, unchanged from 0000858877-17-000019:notes:296]

[0000858877-18-000004:notes:307]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-18-000004:notes:308]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,790 |  |  | $ | 4,926 |  |
| Computer equipment and related software |  | 1,207 |  |  | 1,258 |  |
| Production, engineering, and other equipment |  | 5,702 |  |  | 5,707 |  |
| Operating lease assets |  | 364 |  |  | 356 |  |
| Furniture and fixtures |  | 375 |  |  | 572 |  |
| Total gross property and equipment |  | 12,438 |  |  | 12,819 |  |
| Less: accumulated depreciation and amortization |  | (9,325 | ) |  | (9,497 | ) |
| Total |  | $ | 3,113 |  |  | $ | 3,322 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-18-000004:notes:309]
[same as prior period, unchanged from 0000858877-17-000019:notes:299]

[0000858877-18-000004:notes:310]
The Company began taking action under a restructuring plan in August 2016 (the "Fiscal 2017 Plan"), in order to reinvest in its key priority areas. In the first quarter of fiscal 2018, the Company extended the Fiscal 2017 Plan to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. The Company has substantially completed the Fiscal 2017 Plan and has incurred cumulative charges of $1.0 billion. These aggregate pretax charges are primarily cash based and consist of employee severance and other one-time termination benefits, and other associated costs. In connection with this Plan, the Company incurred charges of $98 million and $133 million for the three months ended January 27, 2018 and January 28, 2017, respectively, and $250 million and $544 million for the six months ended January 27, 2018 and January 28, 2017, respectively.

[0000858877-18-000004:notes:311]
[same as prior period, unchanged from 0000858877-17-000019:notes:301]

[0000858877-18-000004:notes:312]
|  |  | FISCAL 2017 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | 117 |  |
| Charges |  | 223 |  |  | 27 |  |  | 250 |  |
| Cash payments |  | (213 | ) |  | (27 | ) |  | (240 | ) |
| Non-cash items |  | 3 |  |  | (18 | ) |  | (15 | ) |
| Liability as of January 27, 2018 |  | $ | 87 |  |  | $ | 25 |  |  | $ | 112 |  |

[0000858877-18-000004:notes:313]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | 45 |  |
| Charges |  | 452 |  |  | 92 |  |  | 544 |  |
| Cash payments |  | (381 | ) |  | (7 | ) |  | (388 | ) |
| Non-cash items |  | (6 | ) |  | (67 | ) |  | (73 | ) |
| Liability as of January 28, 2017 |  | $ | 86 |  |  | $ | 42 |  |  | $ | 128 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-18-000004:notes:314]
[same as prior period, unchanged from 0000858877-17-000019:notes:304]

[0000858877-18-000004:notes:315]
|  |  | January 27, 2018 |  | July 29, 2017 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 385 |  |  | $ | 289 |  |
| Work in Process |  | — |  |  | 1 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 465 |  |  | 451 |  |
| Manufactured finished goods |  | 727 |  |  | 552 |  |
| Total finished goods |  | 1,192 |  |  | 1,003 |  |
| Service-related spares |  | 292 |  |  | 300 |  |
| Demonstration systems |  | 27 |  |  | 23 |  |
| Total |  | $ | 1,896 |  |  | $ | 1,616 |  |

[0000858877-18-000004:notes:316]
For such investments that were accounted for under the equity and cost method as of January 27, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-18-000004:notes:317]
[same as prior period, unchanged from 0000858877-17-000019:notes:306]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-18-000004:notes:318]
[same as prior period, unchanged from 0000858877-17-000019:notes:307]

[0000858877-18-000004:notes:319]
[same as prior period, unchanged from 0000858877-17-000019:notes:308]

[0000858877-18-000004:notes:320]
During the six months ended January 27, 2018, the Company declared and paid cash dividends of $0.58 per common share, or $2.9 billion, on the Company’s outstanding common stock. During the six months ended January 28, 2017, the Company declared and paid cash dividends of $0.52 per common share, or $2.6 billion, on the Company’s outstanding common stock.

[0000858877-18-000004:notes:321]
On February 14, 2018, the Company’s Board of Directors declared a quarterly dividend of $0.33 per common share to be paid on April 25, 2018 to all shareholders of record as of the close of business on April 5, 2018.  Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-18-000004:notes:322]
[same as prior period, unchanged from 0000858877-17-000019:notes:311]

[0000858877-18-000004:notes:323]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. On February 14, 2018, the Company’s Board of Directors authorized a $25 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $31 billion, with no termination date. A summary of the stock repurchase activity for fiscal year 2018 and 2017 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-18-000004:notes:324]
There were $240 million stock repurchases pending settlement as of January 27, 2018. There were $66 million of stock repurchases that were pending settlement as of July 29, 2017.

[0000858877-18-000004:notes:325]
[same as prior period, unchanged from 0000858877-17-000019:notes:313]

[0000858877-18-000004:notes:326]
[same as prior period, unchanged from 0000858877-17-000019:notes:314]

[0000858877-18-000004:notes:327]
The Company repurchased approximately 13 million and 14 million shares, for the six months ended January 27, 2018 and January 28, 2017, or $433 million and $432 million of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-18-000004:notes:328]
[same as prior period, unchanged from 0000858877-17-000019:notes:316]

[0000858877-18-000004:notes:329]
[same as prior period, unchanged from 0000858877-17-000019:notes:317]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-18-000004:notes:330]
[same as prior period, unchanged from 0000858877-17-000019:notes:318]
