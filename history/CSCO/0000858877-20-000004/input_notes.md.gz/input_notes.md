# CSCO notes — 0000858877-20-000004


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-20-000004:notes:1]
[same as prior period, unchanged from 0000858877-19-000018:notes:1]

[0000858877-20-000004:notes:2]
[same as prior period, unchanged from 0000858877-19-000018:notes:2]

[0000858877-20-000004:notes:3]
We have prepared the accompanying financial data as of January 25, 2020 and for the second quarter and first six months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

[0000858877-20-000004:notes:4]
[same as prior period, unchanged from 0000858877-19-000018:notes:4]

[0000858877-20-000004:notes:5]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2020 and 2019; and the statements of cash flows for the first six months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-20-000004:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-20-000004:notes:7]
[same as prior period, unchanged from 0000858877-19-000018:notes:7]

[0000858877-20-000004:notes:8]
[same as prior period, unchanged from 0000858877-19-000018:notes:8]

[0000858877-20-000004:notes:9]
[same as prior period, unchanged from 0000858877-19-000018:notes:9]

[0000858877-20-000004:notes:10]
[same as prior period, unchanged from 0000858877-19-000018:notes:10]

[0000858877-20-000004:notes:11]
[same as prior period, unchanged from 0000858877-19-000018:notes:11]

[0000858877-20-000004:notes:12]
[same as prior period, unchanged from 0000858877-19-000018:notes:12]

[0000858877-20-000004:notes:13]
[same as prior period, unchanged from 0000858877-19-000018:notes:13]

[0000858877-20-000004:notes:14]
[same as prior period, unchanged from 0000858877-19-000018:notes:14]

[0000858877-20-000004:notes:15]
[same as prior period, unchanged from 0000858877-19-000018:notes:15]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-20-000004:notes:16]
[same as prior period, unchanged from 0000858877-19-000018:notes:16]

[0000858877-20-000004:notes:17]
[same as prior period, unchanged from 0000858877-19-000018:notes:17]

[0000858877-20-000004:notes:18]
[same as prior period, unchanged from 0000858877-19-000018:notes:18]

[0000858877-20-000004:notes:19]
[same as prior period, unchanged from 0000858877-19-000018:notes:19]

[0000858877-20-000004:notes:20]
[same as prior period, unchanged from 0000858877-19-000018:notes:20]

[0000858877-20-000004:notes:21]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative

[0000858877-20-000004:notes:22]
marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-20-000004:notes:23]
[same as prior period, unchanged from 0000858877-19-000018:notes:22]

[0000858877-20-000004:notes:24]
[same as prior period, unchanged from 0000858877-19-000018:notes:23]

[0000858877-20-000004:notes:25]
[same as prior period, unchanged from 0000858877-19-000018:notes:24]

[0000858877-20-000004:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

[0000858877-20-000004:notes:27]
[same as prior period, unchanged from 0000858877-19-000018:notes:26]

[0000858877-20-000004:notes:28]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.

[0000858877-20-000004:notes:29]
[same as prior period, unchanged from 0000858877-19-000018:notes:28]

[0000858877-20-000004:notes:30]
[same as prior period, unchanged from 0000858877-19-000018:notes:29]

[0000858877-20-000004:notes:31]
[same as prior period, unchanged from 0000858877-19-000018:notes:30]

[0000858877-20-000004:notes:32]
[same as prior period, unchanged from 0000858877-19-000018:notes:31]

[0000858877-20-000004:notes:33]
[same as prior period, unchanged from 0000858877-19-000018:notes:32]

[0000858877-20-000004:notes:34]
[same as prior period, unchanged from 0000858877-19-000018:notes:33]

[0000858877-20-000004:notes:35]
[same as prior period, unchanged from 0000858877-19-000018:notes:34]

[0000858877-20-000004:notes:36]
Accounts receivable, net was $4.3 billion as of January 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

[0000858877-20-000004:notes:37]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of January 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $966 million and $860 million, respectively, and were included in other current assets and other assets.

[0000858877-20-000004:notes:38]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.7 billion as of January 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.9 billion and $6.6 billion of revenue during the second quarter and first six months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.

[0000858877-20-000004:notes:39]
[same as prior period, unchanged from 0000858877-19-000018:notes:38]

[0000858877-20-000004:notes:40]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 25, 2020, the aggregate amount of RPO was $24.9 billion, comprised of $18.7 billion of deferred revenue and $6.2 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-20-000004:notes:41]
[same as prior period, unchanged from 0000858877-19-000018:notes:40]

[0000858877-20-000004:notes:42]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $708 million and $750 million as of January 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $122 million and $238 million for the second quarter and first six months of fiscal 2020, respectively, and $100 million and $212 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-20-000004:notes:43]
[same as prior period, unchanged from 0000858877-19-000018:notes:42]

[0000858877-20-000004:notes:44]
[same as prior period, unchanged from 0000858877-19-000018:notes:43]

[0000858877-20-000004:notes:45]
(1) Includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-20-000004:notes:46]
[same as prior period, unchanged from 0000858877-19-000018:notes:45]

[0000858877-20-000004:notes:47]
We completed four acquisitions during the first six months of fiscal 2020. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-20-000004:notes:48]
[same as prior period, unchanged from 0000858877-19-000018:notes:47]

[0000858877-20-000004:notes:49]
The total purchase consideration related to acquisitions completed during the first six months of fiscal 2020 consisted of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $10 million. Total transaction costs related to acquisition and divestiture activities were $9 million and $11 million for the first six months of fiscal 2020 and 2019, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-20-000004:notes:50]
The goodwill generated from acquisitions completed during the first six months of fiscal 2020 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-20-000004:notes:51]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2020 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-20-000004:notes:52]
Divestiture of Service Provider Video Software Solutions Business     On October 28, 2018, we completed the sale of the Service Provider Video Software Solutions business. We recognized an immaterial gain from this transaction in fiscal 2019.

[0000858877-20-000004:notes:53]
[same as prior period, unchanged from 0000858877-19-000018:notes:51]

[0000858877-20-000004:notes:54]
[same as prior period, unchanged from 0000858877-19-000018:notes:52]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-20-000004:notes:55]
[same as prior period, unchanged from 0000858877-19-000018:notes:53]

[0000858877-20-000004:notes:56]
[same as prior period, unchanged from 0000858877-19-000018:notes:54]

[0000858877-20-000004:notes:57]
The following table presents the goodwill allocated to our reportable segments as of January 25, 2020 and during the first six months of fiscal 2020 (in millions):

[0000858877-20-000004:notes:58]
|  | Balance at July 27, 2019 |  | Acquisitions |  | Other |  | Balance at January 25, 2020 |
| Americas | $ | 21,120 |  |  | $ | 62 |  |  | $ | 1 |  |  | $ | 21,183 |  |
| EMEA | 7,977 |  |  | 17 |  |  | — |  |  | 7,994 |  |
| APJC | 4,432 |  |  | 4 |  |  | (1 | ) |  | 4,435 |  |
| Total | $ | 33,529 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 33,612 |  |

[0000858877-20-000004:notes:59]
[same as prior period, unchanged from 0000858877-19-000018:notes:57]

[0000858877-20-000004:notes:60]
[same as prior period, unchanged from 0000858877-19-000018:notes:58]

[0000858877-20-000004:notes:61]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2020 (in millions, except years):

[0000858877-20-000004:notes:62]
[same as prior period, unchanged from 0000858877-19-000018:notes:60]

[0000858877-20-000004:notes:63]
[same as prior period, unchanged from 0000858877-19-000018:notes:61]

[0000858877-20-000004:notes:64]
| January 25, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,245 |  |  | $ | (2,103 | ) |  | $ | 1,142 |  |
| Customer relationships |  | 749 |  |  | (304 | ) |  | 445 |  |
| Other |  | 34 |  |  | (23 | ) |  | 11 |  |
| Total purchased intangible assets with finite lives |  | 4,028 |  |  | (2,430 | ) |  | 1,598 |  |
| In-process research and development, with indefinite lives |  | 308 |  |  | — |  |  | 308 |  |
| Total |  | $ | 4,336 |  |  | $ | (2,430 | ) |  | $ | 1,906 |  |

[0000858877-20-000004:notes:65]
[same as prior period, unchanged from 0000858877-19-000018:notes:63]

[0000858877-20-000004:notes:66]
[same as prior period, unchanged from 0000858877-19-000018:notes:64]

[0000858877-20-000004:notes:67]
[same as prior period, unchanged from 0000858877-19-000018:notes:65]

[0000858877-20-000004:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 165 |  |  | $ | 156 |  |  | $ | 331 |  |  | $ | 307 |  |
| Operating expenses | 38 |  |  | 39 |  |  | 74 |  |  | 73 |  |
| Total | $ | 203 |  |  | $ | 195 |  |  | $ | 405 |  |  | $ | 380 |  |

[0000858877-20-000004:notes:69]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 25, 2020 is as follows (in millions):

[0000858877-20-000004:notes:70]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 383 |  |
| 2021 | $ | 591 |  |
| 2022 | $ | 333 |  |
| 2023 | $ | 191 |  |
| 2024 | $ | 93 |  |
| Thereafter | $ | 7 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-20-000004:notes:71]
[same as prior period, unchanged from 0000858877-19-000018:notes:69]

[0000858877-20-000004:notes:72]
We initiated a restructuring plan during fiscal 2018 (the “Fiscal 2018 Plan”) in order to realign the organization and enable further investment in key priority areas. The aggregate pretax charges related to the Fiscal 2018 Plan were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. In connection with the Fiscal 2018 Plan, we incurred charges of $42 million and $226 million for the second quarter and first six months of fiscal 2020, respectively, and have incurred cumulative charges of $656 million. We completed the Fiscal 2018 Plan in the second quarter of fiscal 2020.

[0000858877-20-000004:notes:73]
[same as prior period, unchanged from 0000858877-19-000018:notes:71]

[0000858877-20-000004:notes:74]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | — |  |  | $ | 5 |  |  | $ | 22 |  |  | $ | 6 |  |  | $ | 33 |  |
| Charges |  | — |  |  | — |  |  | 209 |  |  | 17 |  |  | 226 |  |
| Cash payments |  | — |  |  | — |  |  | (202 | ) |  | (1 | ) |  | (203 | ) |
| Non-cash items |  | — |  |  | (2 | ) |  | — |  |  | (21 | ) |  | (23 | ) |
| Liability as of January 25, 2020 |  | $ | — |  |  | $ | 3 |  |  | $ | 29 |  |  | $ | 1 |  |  | $ | 33 |  |

[0000858877-20-000004:notes:75]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | — |  |  | (1 | ) |  | 222 |  |  | 43 |  |  | 264 |  |
| Cash payments |  | (31 | ) |  | (3 | ) |  | (202 | ) |  | (1 | ) |  | (237 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (42 | ) |  | (42 | ) |
| Liability as of January 26, 2019 |  | $ | 10 |  |  | $ | 9 |  |  | $ | 39 |  |  | $ | — |  |  | $ | 58 |  |

[0000858877-20-000004:notes:76]
Fiscal 2020 Plan     We initiated a restructuring plan in the third quarter of fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. These aggregate pretax charges are primarily cash based and consist of employee severance and other one-time termination benefits, and other costs. We expect the Fiscal 2020 Plan to be substantially completed in fiscal 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-20-000004:notes:77]
[same as prior period, unchanged from 0000858877-19-000018:notes:74]

[0000858877-20-000004:notes:78]
[same as prior period, unchanged from 0000858877-19-000018:notes:75]

[0000858877-20-000004:notes:79]
|  |  | January 25, 2020 |  | July 27, 2019 |
| Cash and cash equivalents |  | $ | 8,475 |  |  | $ | 11,750 |  |
| Restricted cash included in other current assets |  | 21 |  |  | 21 |  |
| Restricted cash included in other assets |  | 3 |  |  | 1 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 8,499 |  |  | $ | 11,772 |  |

[0000858877-20-000004:notes:80]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 384 |  |  | $ | 374 |  |
| Work in process |  | 12 |  |  | 10 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 59 |  |  | 109 |  |
| Manufactured finished goods |  | 667 |  |  | 643 |  |
| Total finished goods |  | 726 |  |  | 752 |  |
| Service-related spares |  | 212 |  |  | 225 |  |
| Demonstration systems |  | 19 |  |  | 22 |  |
| Total |  | $ | 1,353 |  |  | $ | 1,383 |  |

[0000858877-20-000004:notes:81]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,438 |  |  | $ | 4,545 |  |
| Computer equipment and related software |  | 900 |  |  | 922 |  |
| Production, engineering, and other equipment |  | 5,196 |  |  | 5,711 |  |
| Operating lease assets |  | 411 |  |  | 485 |  |
| Furniture, fixtures and other |  | 392 |  |  | 376 |  |
| Total gross property and equipment |  | 11,337 |  |  | 12,039 |  |
| Less: accumulated depreciation and amortization |  | (8,716 | ) |  | (9,250 | ) |
| Total |  | $ | 2,621 |  |  | $ | 2,789 |  |

[0000858877-20-000004:notes:82]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,526 |  |  | $ | 11,709 |  |
| Product |  | 7,160 |  |  | 6,758 |  |
| Total |  | $ | 18,686 |  |  | $ | 18,467 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,638 |  |  | $ | 10,668 |  |
| Noncurrent |  | 8,048 |  |  | 7,799 |  |
| Total |  | $ | 18,686 |  |  | $ | 18,467 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-20-000004:notes:83]
[same as prior period, unchanged from 0000858877-19-000018:notes:80]

[0000858877-20-000004:notes:84]
[same as prior period, unchanged from 0000858877-19-000018:notes:81]

[0000858877-20-000004:notes:85]
We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-20-000004:notes:86]
[same as prior period, unchanged from 0000858877-19-000018:notes:83]

[0000858877-20-000004:notes:87]
As of January 25, 2020, our operating lease right-of-use assets were $1.0 billion and were recorded in other assets, and our operating lease liabilities were $1.1 billion, of which $380 million was included in other current liabilities and $698 million was included in other long-term liabilities. The weighted-average lease term was 4.1 years and the weighted-average discount rate was 1.8% as of January 25, 2020.

[0000858877-20-000004:notes:88]
[same as prior period, unchanged from 0000858877-19-000018:notes:85]

[0000858877-20-000004:notes:89]
|  | January 25, 2020 |
|  | Three Months Ended |  | Six Months Ended |
| Operating lease expense | $ | 101 |  |  | $ | 214 |  |
| Short-term lease expense | 16 |  |  | 33 |  |
| Variable lease expense | 39 |  |  | 79 |  |
| Total lease expense | $ | 156 |  |  | $ | 326 |  |

[0000858877-20-000004:notes:90]
[same as prior period, unchanged from 0000858877-19-000018:notes:87]

[0000858877-20-000004:notes:91]
|  | Six Months Ended |
| In millions: | January 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 206 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 77 |  |

[0000858877-20-000004:notes:92]
The maturities of our operating leases (undiscounted) as of January 25, 2020 are as follows (in millions):

[0000858877-20-000004:notes:93]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 204 |  |
| 2021 | 316 |  |
| 2022 | 216 |  |
| 2023 | 166 |  |
| 2024 | 104 |  |
| Thereafter | 111 |  |
| Total lease payments | 1,117 |  |
| Less interest | (39 | ) |
| Total | $ | 1,078 |  |

[0000858877-20-000004:notes:94]
[same as prior period, unchanged from 0000858877-19-000018:notes:92]

[0000858877-20-000004:notes:95]
[same as prior period, unchanged from 0000858877-19-000018:notes:93]

[0000858877-20-000004:notes:96]
[same as prior period, unchanged from 0000858877-19-000018:notes:94]

[0000858877-20-000004:notes:97]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the second quarter and first six months of fiscal 2020 was $23 million and $49 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-20-000004:notes:98]
Future minimum lease payments on our lease receivables as of January 25, 2020 are summarized as follows (in millions):

[0000858877-20-000004:notes:99]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 438 |  |
| 2021 | 882 |  |
| 2022 | 479 |  |
| 2023 | 267 |  |
| 2024 | 123 |  |
| Thereafter | 58 |  |
| Total | 2,247 |  |
| Less: Present value of lease payments | 2,117 |  |
| Difference between undiscounted cash flows and discounted cash flows | $ | 130 |  |

[0000858877-20-000004:notes:100]
[same as prior period, unchanged from 0000858877-19-000018:notes:98]

[0000858877-20-000004:notes:101]
[same as prior period, unchanged from 0000858877-19-000018:notes:99]

[0000858877-20-000004:notes:102]
[same as prior period, unchanged from 0000858877-19-000018:notes:100]

[0000858877-20-000004:notes:103]
[same as prior period, unchanged from 0000858877-19-000018:notes:101]

[0000858877-20-000004:notes:104]
|  | January 25, 2020 |  | July 27, 2019 |
| Operating lease assets | $ | 411 |  |  | $ | 485 |  |
| Accumulated depreciation | (247 | ) |  | (306 | ) |
| Operating lease assets, net | $ | 164 |  |  | $ | 179 |  |

[0000858877-20-000004:notes:105]
Our lease income for the second quarter and first six months of fiscal 2020 was $50 million and $94 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-20-000004:notes:106]
Minimum future rentals on noncancelable operating leases as of January 25, 2020 are summarized as follows (in millions):

[0000858877-20-000004:notes:107]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 61 |  |
| 2021 | 70 |  |
| 2022 | 24 |  |
| 2023 | 4 |  |
| Total | $ | 159 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-20-000004:notes:108]
[same as prior period, unchanged from 0000858877-19-000018:notes:106]

[0000858877-20-000004:notes:109]
[same as prior period, unchanged from 0000858877-19-000018:notes:107]

[0000858877-20-000004:notes:110]
[same as prior period, unchanged from 0000858877-19-000018:notes:108]

[0000858877-20-000004:notes:111]
[same as prior period, unchanged from 0000858877-19-000018:notes:109]

[0000858877-20-000004:notes:112]
| January 25, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,247 |  |  | $ | 5,297 |  |  | $ | 2,182 |  |  | $ | 9,726 |  |
| Residual value | 133 |  |  | — |  |  | — |  |  | 133 |  |
| Unearned income | (130 | ) |  | — |  |  | — |  |  | (130 | ) |
| Allowance for credit loss | (42 | ) |  | (95 | ) |  | (8 | ) |  | (145 | ) |
| Total, net | $ | 2,208 |  |  | $ | 5,202 |  |  | $ | 2,174 |  |  | $ | 9,584 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 999 |  |  | $ | 2,496 |  |  | $ | 1,332 |  |  | $ | 4,827 |  |
| Noncurrent | 1,209 |  |  | 2,706 |  |  | 842 |  |  | 4,757 |  |
| Total, net | $ | 2,208 |  |  | $ | 5,202 |  |  | $ | 2,174 |  |  | $ | 9,584 |  |

[0000858877-20-000004:notes:113]
[same as prior period, unchanged from 0000858877-19-000018:notes:111]

[0000858877-20-000004:notes:114]
[same as prior period, unchanged from 0000858877-19-000018:notes:112]

[0000858877-20-000004:notes:115]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of January 25, 2020 and July 27, 2019 are summarized as follows (in millions):

[0000858877-20-000004:notes:116]
|  | INTERNAL CREDIT RISK RATING |
| January 25, 2020 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,133 |  |  | $ | 936 |  |  | $ | 48 |  |  | $ | 2,117 |  |
| Loan receivables | 3,262 |  |  | 1,855 |  |  | 180 |  |  | 5,297 |  |
| Financed service contracts | 1,256 |  |  | 900 |  |  | 26 |  |  | 2,182 |  |
| Total | $ | 5,651 |  |  | $ | 3,691 |  |  | $ | 254 |  |  | $ | 9,596 |  |

[0000858877-20-000004:notes:117]
[same as prior period, unchanged from 0000858877-19-000018:notes:115]

[0000858877-20-000004:notes:118]
[same as prior period, unchanged from 0000858877-19-000018:notes:116]

[0000858877-20-000004:notes:119]
[same as prior period, unchanged from 0000858877-19-000018:notes:117]

[0000858877-20-000004:notes:120]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of January 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000004:notes:121]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 25, 2020 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 58 |  |  | $ | 34 |  |  | $ | 172 |  |  | $ | 264 |  |  | $ | 1,853 |  |  | $ | 2,117 |  |  | $ | 22 |  |  | $ | 22 |  |
| Loan receivables | 129 |  |  | 31 |  |  | 219 |  |  | 379 |  |  | 4,918 |  |  | 5,297 |  |  | 78 |  |  | 78 |  |
| Financed service contracts | 82 |  |  | 45 |  |  | 309 |  |  | 436 |  |  | 1,746 |  |  | 2,182 |  |  | 2 |  |  | 2 |  |
| Total | $ | 269 |  |  | $ | 110 |  |  | $ | 700 |  |  | $ | 1,079 |  |  | $ | 8,517 |  |  | $ | 9,596 |  |  | $ | 102 |  |  | $ | 102 |  |

[0000858877-20-000004:notes:122]
[same as prior period, unchanged from 0000858877-19-000018:notes:120]

[0000858877-20-000004:notes:123]
[same as prior period, unchanged from 0000858877-19-000018:notes:121]

[0000858877-20-000004:notes:124]
As of January 25, 2020, we had financing receivables of $201 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $215 million as of July 27, 2019.

[0000858877-20-000004:notes:125]
[same as prior period, unchanged from 0000858877-19-000018:notes:123]

[0000858877-20-000004:notes:126]
[same as prior period, unchanged from 0000858877-19-000018:notes:124]

[0000858877-20-000004:notes:127]
| Three months ended January 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 26, 2019 | $ | 43 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 133 |  |
| Provisions (benefits) | (1 | ) |  | 15 |  |  | — |  |  | 14 |  |
| Recoveries (write-offs), net | (1 | ) |  | (1 | ) |  | — |  |  | (2 | ) |
| Foreign exchange and other | 1 |  |  | — |  |  | (1 | ) |  | — |  |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |

[0000858877-20-000004:notes:128]
| Six months ended January 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (4 | ) |  | 42 |  |  | — |  |  | 38 |  |
| Recoveries (write-offs), net | (1 | ) |  | (17 | ) |  | — |  |  | (18 | ) |
| Foreign exchange and other | 1 |  |  | (1 | ) |  | (1 | ) |  | (1 | ) |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |

[0000858877-20-000004:notes:129]
| Three months ended January 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 27, 2018 | $ | 131 |  |  | $ | 60 |  |  | $ | 8 |  |  | $ | 199 |  |
| Provisions (benefits) | (4 | ) |  | 4 |  |  | 1 |  |  | 1 |  |
| Allowance for credit loss as of January 26, 2019 | $ | 127 |  |  | $ | 64 |  |  | $ | 9 |  |  | $ | 200 |  |

[0000858877-20-000004:notes:130]
| Six months ended January 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (7 | ) |  | 4 |  |  | (1 | ) |  | (4 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Allowance for credit loss as of January 26, 2019 | $ | 127 |  |  | $ | 64 |  |  | $ | 9 |  |  | $ | 200 |  |

[0000858877-20-000004:notes:131]
[same as prior period, unchanged from 0000858877-19-000018:notes:127]

[0000858877-20-000004:notes:132]
Typically, we also consider receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 25, 2020 and July 27, 2019, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-20-000004:notes:133]
We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use expected default

[0000858877-20-000004:notes:134]
frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-20-000004:notes:135]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-20-000004:notes:136]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-20-000004:notes:137]
|  | January 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,587 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,587 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,155 |  |  | 1,113 |  |
| Equity method investments included in other assets | 61 |  |  | 87 |  |
| Total | $ | 19,803 |  |  | $ | 22,863 |  |

[0000858877-20-000004:notes:138]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-20-000004:notes:139]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-20-000004:notes:140]
| January 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,218 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 2,231 |  |
| U.S. government agency securities | 20 |  |  | — |  |  | — |  |  | 20 |  |
| Corporate debt securities | 13,405 |  |  | 196 |  |  | (4 | ) |  | 13,597 |  |
| U.S. agency mortgage-backed securities | 1,612 |  |  | 14 |  |  | (3 | ) |  | 1,623 |  |
| Commercial paper | 1,052 |  |  | — |  |  | — |  |  | 1,052 |  |
| Certificates of deposit | 64 |  |  | — |  |  | — |  |  | 64 |  |
| Total (1) | $ | 18,371 |  |  | $ | 223 |  |  | $ | (7 | ) |  | $ | 18,587 |  |

[0000858877-20-000004:notes:141]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

[0000858877-20-000004:notes:142]
(1) Net unsettled investment sales were $13 million as of January 25, 2020 and were included in other current assets.

[0000858877-20-000004:notes:143]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-20-000004:notes:144]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Gross realized gains | $ | 13 |  |  | $ | 1 |  |  | $ | 25 |  |  | $ | 3 |  |
| Gross realized losses | (2 | ) |  | (6 | ) |  | (4 | ) |  | (14 | ) |
| Total | $ | 11 |  |  | $ | (5 | ) |  | $ | 21 |  |  | $ | (11 | ) |

[0000858877-20-000004:notes:145]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000004:notes:146]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 44 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |
| U.S. government agency securities | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Corporate debt securities | 260 |  |  | (1 | ) |  | 439 |  |  | (3 | ) |  | 699 |  |  | (4 | ) |
| U.S. agency mortgage-backed securities | 56 |  |  | — |  |  | 374 |  |  | (3 | ) |  | 430 |  |  | (3 | ) |
| Commercial paper | 51 |  |  | — |  |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Certificates of deposit | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Total | $ | 447 |  |  | $ | (1 | ) |  | $ | 836 |  |  | $ | (6 | ) |  | $ | 1,283 |  |  | $ | (7 | ) |

[0000858877-20-000004:notes:147]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

[0000858877-20-000004:notes:148]
For available-for-sale debt investments that were in an unrealized loss position as of January 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-20-000004:notes:149]
The following table summarizes the maturities of our available-for-sale debt investments as of January 25, 2020 (in millions):

[0000858877-20-000004:notes:150]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,704 |  |  | $ | 5,717 |  |
| After 1 year through 5 years | 8,898 |  |  | 8,995 |  |
| After 5 years through 10 years | 2,150 |  |  | 2,245 |  |
| After 10 years | 7 |  |  | 7 |  |
| Mortgage-backed securities with no single maturity | 1,612 |  |  | 1,623 |  |
| Total | $ | 18,371 |  |  | $ | 18,587 |  |

[0000858877-20-000004:notes:151]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-20-000004:notes:152]
| (b) | Summary of Equity Investments |

[0000858877-20-000004:notes:153]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):

[0000858877-20-000004:notes:154]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 71 |  |  | $ | 67 |  |  | $ | 78 |  |  | $ | 75 |  |
| Less: Net gains and losses recognized on equity investments sold | (68 | ) |  | 5 |  |  | (75 | ) |  | (7 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | 3 |  |  | $ | 72 |  |  | $ | 3 |  |  | $ | 68 |  |

[0000858877-20-000004:notes:155]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):

[0000858877-20-000004:notes:156]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 11 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 24 |  |
| Downward adjustments, including impairments | (8 | ) |  | (2 | ) |  | (9 | ) |  | (18 | ) |
| Net adjustments | $ | 3 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 6 |  |

[0000858877-20-000004:notes:157]
As of January 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.

[0000858877-20-000004:notes:158]
| (c) | Variable Interest Entities |

[0000858877-20-000004:notes:159]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-20-000004:notes:160]
As of January 25, 2020, the carrying value of investments in privately held companies was $1.2 billion. $669 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $291 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-20-000004:notes:161]
[same as prior period, unchanged from 0000858877-19-000018:notes:157]

[0000858877-20-000004:notes:162]
[same as prior period, unchanged from 0000858877-19-000018:notes:158]

[0000858877-20-000004:notes:163]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-20-000004:notes:164]
[same as prior period, unchanged from 0000858877-19-000018:notes:161]

[0000858877-20-000004:notes:165]
[same as prior period, unchanged from 0000858877-19-000018:notes:162]

[0000858877-20-000004:notes:166]
[same as prior period, unchanged from 0000858877-19-000018:notes:163]

[0000858877-20-000004:notes:167]
[same as prior period, unchanged from 0000858877-19-000018:notes:164]

[0000858877-20-000004:notes:168]
[same as prior period, unchanged from 0000858877-19-000018:notes:165]

[0000858877-20-000004:notes:169]
|  | JANUARY 25, 2020FAIR VALUE MEASUREMENTS |  | JULY 27, 2019FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,556 |  |  | $ | — |  |  | $ | 6,556 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 10,083 |  |
| Commercial paper | — |  |  | 216 |  |  | 216 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 18 |  |  | 18 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,231 |  |  | 2,231 |  |  | — |  |  | 808 |  |  | 808 |  |
| U.S. government agency securities | — |  |  | 20 |  |  | 20 |  |  | — |  |  | 169 |  |  | 169 |  |
| Corporate debt securities | — |  |  | 13,597 |  |  | 13,597 |  |  | — |  |  | 19,262 |  |  | 19,262 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,623 |  |  | 1,623 |  |  | — |  |  | 1,421 |  |  | 1,421 |  |
| Commercial paper | — |  |  | 1,052 |  |  | 1,052 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 64 |  |  | 64 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets | — |  |  | 103 |  |  | 103 |  |  | — |  |  | 89 |  |  | 89 |  |
| Total | $ | 6,556 |  |  | $ | 18,924 |  |  | $ | 25,480 |  |  | $ | 10,086 |  |  | $ | 21,749 |  |  | $ | 31,835 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |
| Total | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-20-000004:notes:170]
[same as prior period, unchanged from 0000858877-19-000018:notes:167]

[0000858877-20-000004:notes:171]
[same as prior period, unchanged from 0000858877-19-000018:notes:168]

[0000858877-20-000004:notes:172]
[same as prior period, unchanged from 0000858877-19-000018:notes:169]

[0000858877-20-000004:notes:173]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | TOTAL GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Non-marketable equity securities and equity method investments | $ | (11 | ) |  | $ | 12 |  |  | $ | (32 | ) |  | $ | 6 |  |
| Purchased intangible assets (impaired) | (3 | ) |  | — |  |  | (3 | ) |  | — |  |
| Total gains (losses) for nonrecurring measurements | $ | (14 | ) |  | $ | 12 |  |  | $ | (35 | ) |  | $ | 6 |  |

[0000858877-20-000004:notes:174]
[same as prior period, unchanged from 0000858877-19-000018:notes:171]

[0000858877-20-000004:notes:175]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5. The remaining carrying value of the specific purchased intangible assets that were impaired was zero as of January 25, 2020.

[0000858877-20-000004:notes:176]
[same as prior period, unchanged from 0000858877-19-000018:notes:172]

[0000858877-20-000004:notes:177]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of January 25, 2020 and July 27, 2019 was $3.5 billion and $3.7 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of January 25, 2020, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 25, 2020, the fair value of our senior notes and other long-term debt was $18.0 billion with a carrying amount of $16.0 billion. This compares to a fair value of $22.1 billion and a carrying amount of $20.5 billion as of July 27, 2019. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-20-000004:notes:178]
Borrowings

[0000858877-20-000004:notes:179]
| (a) | Short-Term Debt |

[0000858877-20-000004:notes:180]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-20-000004:notes:181]
|  | January 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,499 |  |  | 2.54 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 1,499 |  |  |  |  | $ | 10,191 |  |  |  |

[0000858877-20-000004:notes:182]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-20-000004:notes:183]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-20-000004:notes:184]
| (b) | Long-Term Debt |

[0000858877-20-000004:notes:185]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-20-000004:notes:186]
|  |  |  | January 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.51% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.71% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.63% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.88% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (94 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 87 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,499 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,494 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |

[0000858877-20-000004:notes:187]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-20-000004:notes:188]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2020, we were in compliance with all debt covenants.

[0000858877-20-000004:notes:189]
As of January 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-20-000004:notes:190]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |

[0000858877-20-000004:notes:191]
| (c) | Credit Facility |

[0000858877-20-000004:notes:192]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-20-000004:notes:193]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-20-000004:notes:194]
[same as prior period, unchanged from 0000858877-19-000018:notes:190]

[0000858877-20-000004:notes:195]
[same as prior period, unchanged from 0000858877-19-000018:notes:191]

[0000858877-20-000004:notes:196]
[same as prior period, unchanged from 0000858877-19-000018:notes:192]

[0000858877-20-000004:notes:197]
[same as prior period, unchanged from 0000858877-19-000018:notes:193]

[0000858877-20-000004:notes:198]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 25, 2020 |  | July 27, 2019 |  | Balance Sheet Line Item |  | January 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 8 |  |  | $ | 5 |  |  | Other current liabilities |  | $ | 7 |  |  | $ | 8 |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Interest rate derivatives | Other assets |  | 89 |  |  | 75 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 97 |  |  | 80 |  |  |  |  | 7 |  |  | 9 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 6 |  |  | 9 |  |  | Other current liabilities |  | 8 |  |  | 6 |  |
| Total |  |  | 6 |  |  | 9 |  |  |  |  | 8 |  |  | 6 |  |
| Total |  |  | $ | 103 |  |  | $ | 89 |  |  |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-20-000004:notes:199]
[same as prior period, unchanged from 0000858877-19-000018:notes:195]

[0000858877-20-000004:notes:200]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | January 25, 2020 |  | July 27, 2019 |  | January 25, 2020 |  | July 27, 2019 |
| Short-term debt |  | $ | — |  |  | $ | (2,000 | ) |  | $ | — |  |  | $ | — |  |
| Long-term debt |  | $ | (2,580 | ) |  | $ | (2,565 | ) |  | $ | (87 | ) |  | $ | (73 | ) |

[0000858877-20-000004:notes:201]
See Note 17 for the effects of our cash flow hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations.

[0000858877-20-000004:notes:202]
[same as prior period, unchanged from 0000858877-19-000018:notes:198]

[0000858877-20-000004:notes:203]
|  | January 25, 2020 |
|  | Three Months Ended |  | Six Months Ended |
|  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded | $ | 12,005 |  |  | $ | 4,241 |  |  | $ | 4,384 |  |  | $ | 154 |  |  | $ | 25,164 |  |  | $ | 8,936 |  |  | $ | 9,269 |  |  | $ | 261 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |
| Interest rate derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hedged items | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | — |  |  | — |  |  | (14 | ) |
| Derivatives designated as hedging instruments | — |  |  | — |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | — |  |  | 16 |  |
| Gains (losses) on cash flow hedging relationships: |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income | (2 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |  | 1 |  |  | 2 |  |  | — |  |
| Total gains (losses) | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | (5 | ) |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |

[0000858877-20-000004:notes:204]
|  | January 26, 2019 |
|  | Three Months Ended |  | Six Months Ended |
|  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded | $ | 12,446 |  |  | $ | 4,673 |  |  | $ | 4,562 |  |  | $ | 132 |  |  | $ | 25,518 |  |  | $ | 9,599 |  |  | $ | 8,903 |  |  | $ | 236 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |
| Interest rate derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hedged items | — |  |  | — |  |  | — |  |  | (61 | ) |  | — |  |  | — |  |  | — |  |  | (52 | ) |
| Derivatives designated as hedging instruments | — |  |  | — |  |  | — |  |  | 64 |  |  | — |  |  | — |  |  | — |  |  | 55 |  |
| Gains (losses) on cash flow hedging relationships: |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income | 2 |  |  | (1 | ) |  | — |  |  | — |  |  | 3 |  |  | (1 | ) |  | (1 | ) |  | — |  |
| Total gains (losses) | $ | 2 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | 3 |  |

[0000858877-20-000004:notes:205]
[same as prior period, unchanged from 0000858877-19-000018:notes:201]

[0000858877-20-000004:notes:206]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (2 | ) |  | $ | (1 | ) |  | $ | (9 | ) |  | $ | (28 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 40 |  |  | (9 | ) |  | 44 |  |  | (33 | ) |
|  |  | Cost of sales |  | 4 |  |  | (1 | ) |  | 4 |  |  | (3 | ) |
|  |  | Other income (loss), net |  | (3 | ) |  | (4 | ) |  | (7 | ) |  | (8 | ) |
| Equity derivatives |  | Other income (loss), net |  | 3 |  |  | — |  |  | 5 |  |  | 1 |  |
| Total |  |  |  | $ | 42 |  |  | $ | (15 | ) |  | $ | 37 |  |  | $ | (71 | ) |

[0000858877-20-000004:notes:207]
[same as prior period, unchanged from 0000858877-19-000018:notes:203]

[0000858877-20-000004:notes:208]
|  | January 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 595 |  |  | $ | 663 |  |
| Interest rate derivatives | 2,500 |  |  | 4,500 |  |
| Net investment hedging instruments | 272 |  |  | 309 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,798 |  |  | 2,708 |  |
| Total return swaps—deferred compensation | 630 |  |  | 574 |  |
| Total | $ | 6,795 |  |  | $ | 8,754 |  |

[0000858877-20-000004:notes:209]
[same as prior period, unchanged from 0000858877-19-000018:notes:205]

[0000858877-20-000004:notes:210]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of January 25, 2020 and July 27, 2019, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $14 million and $13 million, respectively.

[0000858877-20-000004:notes:211]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of January 25, 2020 and July 27, 2019 was $86 million and $76 million, respectively. Including the effects of collateral, this results in a net derivative asset of $2 million and a net derivative liability of $2 million as of January 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000004:notes:212]
[same as prior period, unchanged from 0000858877-19-000018:notes:208]

[0000858877-20-000004:notes:213]
[same as prior period, unchanged from 0000858877-19-000018:notes:209]

[0000858877-20-000004:notes:214]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings. During the periods presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-20-000004:notes:215]
[same as prior period, unchanged from 0000858877-19-000018:notes:211]

[0000858877-20-000004:notes:216]
[same as prior period, unchanged from 0000858877-19-000018:notes:212]

[0000858877-20-000004:notes:217]
[same as prior period, unchanged from 0000858877-19-000018:notes:213]

[0000858877-20-000004:notes:218]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2021 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-20-000004:notes:219]
[same as prior period, unchanged from 0000858877-19-000018:notes:215]

[0000858877-20-000004:notes:220]
We may hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-20-000004:notes:221]
Commitments and Contingencies

[0000858877-20-000004:notes:222]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-20-000004:notes:223]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory

[0000858877-20-000004:notes:224]
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $4.5 billion and $5.0 billion, respectively.

[0000858877-20-000004:notes:225]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2020 and July 27, 2019, the liability for these purchase commitments was $126 million and $129 million, respectively, and was included in other current liabilities.

[0000858877-20-000004:notes:226]
| (b) | Other Commitments |

[0000858877-20-000004:notes:227]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-20-000004:notes:228]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-20-000004:notes:229]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Compensation expense related to acquisitions | $ | 50 |  |  | $ | 66 |  |  | $ | 111 |  |  | $ | 175 |  |

[0000858877-20-000004:notes:230]
As of January 25, 2020, we estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-20-000004:notes:231]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $291 million and $326 million as of January 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000004:notes:232]
| (c) | Product Warranties |

[0000858877-20-000004:notes:233]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-20-000004:notes:234]
|  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 283 |  |  | 297 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (5 | ) |
| Settlements | (291 | ) |  | (300 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 331 |  |  | $ | 349 |  |

[0000858877-20-000004:notes:235]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-20-000004:notes:236]
| (d) | Financing and Other Guarantees |

[0000858877-20-000004:notes:237]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-20-000004:notes:238]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.3 billion for the second quarter of fiscal

[0000858877-20-000004:notes:239]
2020 and 2019, respectively, and was $14.2 billion and $14.5 billion for the first six months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.4 billion as of January 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000004:notes:240]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $6 million for the second quarter of fiscal 2020 and 2019, respectively, and was $6 million and $9 million for the first six months of fiscal 2020 and 2019, respectively.

[0000858877-20-000004:notes:241]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-20-000004:notes:242]
|  | January 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 258 |  |  | $ | 197 |  |
| End user | 13 |  |  | 21 |  |
| Total | $ | 271 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (69 | ) |  | $ | (62 | ) |
| End user | (13 | ) |  | (15 | ) |
| Total | $ | (82 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 141 |  |

[0000858877-20-000004:notes:243]
| (e) | Indemnifications |

[0000858877-20-000004:notes:244]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-20-000004:notes:245]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC's post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

[0000858877-20-000004:notes:246]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-20-000004:notes:247]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-20-000004:notes:248]
| (f) | Legal Proceedings |

[0000858877-20-000004:notes:249]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-20-000004:notes:250]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.2 billion for the alleged evasion of import and other taxes, $0.9 billion for interest, and $0.5 billion for various penalties, all determined using an exchange rate as of January 25, 2020.

[0000858877-20-000004:notes:251]
We have completed a thorough review of the matters and believe the remaining asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-20-000004:notes:252]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, a panel of which, after various proceedings, on July 12, 2019, issued an opinion vacating the enhanced damages award; vacating and remanding in part the willful infringement finding; vacating and remanding the attorneys’ fees award for further proceedings; and affirming the district court's other findings. Cisco paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales. This payment is subject to a refund if any portion of the affirmed judgment is reversed or vacated by the U.S. Supreme Court. On November 8, 2019, Cisco filed a petition for a writ of certiorari with the U.S. Supreme Court, seeking review of the judgment on the grounds that the asserted patents describe patent-ineligible subject matter. While the remanded proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-20-000004:notes:253]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for four patents in the instituted IPR Proceedings, and all claims of three patents have been found unpatentable and a portion of the claims of a fourth patent have been found unpatentable. The court set a trial for April 7, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement arguments and that the patents are invalid, as well as other defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, however, we are unable to reasonably estimate the ultimate monetary outcome of this litigation at this time.

[0000858877-20-000004:notes:254]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23,

[0000858877-20-000004:notes:255]
2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

[0000858877-20-000004:notes:256]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-20-000004:notes:257]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory 
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-20-000004:notes:258]
[same as prior period, unchanged from 0000858877-19-000018:notes:253]

[0000858877-20-000004:notes:259]
[same as prior period, unchanged from 0000858877-19-000018:notes:254]

[0000858877-20-000004:notes:260]
We declared and paid cash dividends of $0.35 and $0.33 per common share, or $1.5 billion on our outstanding common stock for each of the second quarters of fiscal 2020 and 2019. We declared and paid cash dividends of $0.70 and $0.66 per common share, or $3.0 billion, on our outstanding common stock for each of the first six months of fiscal 2020 and 2019.

[0000858877-20-000004:notes:261]
On February 12, 2020, our Board of Directors declared a quarterly dividend of $0.36 per common share to be paid on April 22, 2020 to all shareholders of record as of the close of business on April 3, 2020. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-20-000004:notes:262]
[same as prior period, unchanged from 0000858877-19-000018:notes:257]

[0000858877-20-000004:notes:263]
In September 2001, our Board of Directors authorized a stock repurchase program.  As of January 25, 2020, the remaining authorized amount for stock repurchases under this program, including the additional authorization, was approximately $11.8 billion with no termination date. A summary of the stock repurchase activity for fiscal 2020 and 2019 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-20-000004:notes:264]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2020 |  |  |  |  |  |  |
| January 25, 2020 |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |
| Fiscal 2019 |  |  |  |  |  |  |
| July 27, 2019 |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |
| April 27, 2019 |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |
| January 26, 2019 |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |
| October 27, 2018 |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |

[0000858877-20-000004:notes:265]
There were $30 million and $40 million of stock repurchases that were pending settlement as of January 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000004:notes:266]
[same as prior period, unchanged from 0000858877-19-000018:notes:261]

[0000858877-20-000004:notes:267]
[same as prior period, unchanged from 0000858877-19-000018:notes:262]

[0000858877-20-000004:notes:268]
[same as prior period, unchanged from 0000858877-19-000018:notes:263]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-20-000004:notes:269]
[same as prior period, unchanged from 0000858877-19-000018:notes:264]

[0000858877-20-000004:notes:270]
[same as prior period, unchanged from 0000858877-19-000018:notes:265]

[0000858877-20-000004:notes:271]
Stock Incentive Plan Program Description    As of January 25, 2020, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-20-000004:notes:272]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of January 25, 2020, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-20-000004:notes:273]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 25, 2020, 197 million shares were authorized for future grant under the 2005 Plan.

[0000858877-20-000004:notes:274]
[same as prior period, unchanged from 0000858877-19-000018:notes:269]

[0000858877-20-000004:notes:275]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of January 25, 2020. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 9 million shares during the second quarter and first six months of fiscal 2020 and 9 million shares during the second quarter and first six months of fiscal 2019. As of January 25, 2020, 150 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-20-000004:notes:276]
[same as prior period, unchanged from 0000858877-19-000018:notes:271]

[0000858877-20-000004:notes:277]
[same as prior period, unchanged from 0000858877-19-000018:notes:272]

[0000858877-20-000004:notes:278]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Cost of sales—product | $ | 23 |  |  | $ | 22 |  |  | $ | 46 |  |  | $ | 45 |  |
| Cost of sales—service | 36 |  |  | 31 |  |  | 70 |  |  | 64 |  |
| Share-based compensation expense in cost of sales | 59 |  |  | 53 |  |  | 116 |  |  | 109 |  |
| Research and development | 146 |  |  | 133 |  |  | 292 |  |  | 263 |  |
| Sales and marketing | 119 |  |  | 125 |  |  | 246 |  |  | 262 |  |
| General and administrative | 55 |  |  | 65 |  |  | 115 |  |  | 127 |  |
| Restructuring and other charges | 5 |  |  | 19 |  |  | 13 |  |  | 42 |  |
| Share-based compensation expense in operating expenses | 325 |  |  | 342 |  |  | 666 |  |  | 694 |  |
| Total share-based compensation expense | $ | 384 |  |  | $ | 395 |  |  | $ | 782 |  |  | $ | 803 |  |
| Income tax benefit for share-based compensation | $ | 109 |  |  | $ | 126 |  |  | $ | 240 |  |  | $ | 291 |  |

[0000858877-20-000004:notes:279]
As of January 25, 2020, the total compensation cost related to unvested share-based awards not yet recognized was $3.9 billion which is expected to be recognized over approximately 2.8 years on a weighted-average basis.

[0000858877-20-000004:notes:280]
| (d) | Restricted Stock and Stock Unit Awards |

[0000858877-20-000004:notes:281]
[same as prior period, unchanged from 0000858877-19-000018:notes:280]

[0000858877-20-000004:notes:282]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | $ | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50 | ) |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14 | ) |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | 38.66 |  |  |  |
| Granted | 28 |  |  | 42.09 |  |  |  |
| Vested | (25 | ) |  | 33.28 |  |  | $ | 1,207 |  |
| Canceled/forfeited/other | (5 | ) |  | 39.29 |  |  |  |
| UNVESTED BALANCE AT JANUARY 25, 2020 | 98 |  |  | $ | 40.94 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-20-000004:notes:283]
[same as prior period, unchanged from 0000858877-19-000018:notes:286]

[0000858877-20-000004:notes:284]
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2020 and 2019 are summarized as follows (in millions):

[0000858877-20-000004:notes:285]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14 | ) |  | $ | (778 | ) |  | $ | (792 | ) |
| Other comprehensive income (loss) before reclassifications | 168 |  |  | — |  |  | (42 | ) |  | 126 |  |
| (Gains) losses reclassified out of AOCI | (21 | ) |  | 2 |  |  | 2 |  |  | (17 | ) |
| Tax benefit (expense) | (17 | ) |  | 1 |  |  | (1 | ) |  | (17 | ) |
| BALANCE AT JANUARY 25, 2020 | $ | 130 |  |  | $ | (11 | ) |  | $ | (819 | ) |  | $ | (700 | ) |

[0000858877-20-000004:notes:286]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |
| Other comprehensive income (loss) before reclassifications | 86 |  |  | (9 | ) |  | (184 | ) |  | (107 | ) |
| (Gains) losses reclassified out of AOCI | 11 |  |  | (1 | ) |  | 3 |  |  | 13 |  |
| Tax benefit (expense) | — |  |  | 2 |  |  | (1 | ) |  | 1 |  |
| Total change for the period | 97 |  |  | (8 | ) |  | (182 | ) |  | (93 | ) |
| Effect of adoption of accounting standard | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT JANUARY 26, 2019 | $ | (381 | ) |  | $ | (19 | ) |  | $ | (710 | ) |  | $ | (1,110 | ) |

[0000858877-20-000004:notes:287]
[same as prior period, unchanged from 0000858877-19-000018:notes:290]

[0000858877-20-000004:notes:288]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |  |  |
| Comprehensive Income Components | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments | $ | 11 |  |  | $ | (5 | ) |  | $ | 21 |  |  | $ | (11 | ) |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | (2 | ) |  | 2 |  |  | (5 | ) |  | 3 |  |  | Revenue |
| Foreign currency derivatives | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |  | Cost of sales |
| Foreign currency derivatives | — |  |  | — |  |  | 2 |  |  | (1 | ) |  | Operating expenses |
|  | (2 | ) |  | 1 |  |  | (2 | ) |  | 1 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses | (1 | ) |  | (4 | ) |  | (2 | ) |  | $ | (3 | ) |  | Other income (loss), net |
| Total amounts reclassified out of AOCI | $ | 8 |  |  | $ | (8 | ) |  | $ | 17 |  |  | $ | (13 | ) |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-20-000004:notes:289]
[same as prior period, unchanged from 0000858877-19-000018:notes:292]

[0000858877-20-000004:notes:290]
[same as prior period, unchanged from 0000858877-19-000018:notes:293]

[0000858877-20-000004:notes:291]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Income before provision for income taxes | $ | 3,534 |  |  | $ | 3,343 |  |  | $ | 7,220 |  |  | $ | 7,252 |  |
| Provision for income taxes | $ | 656 |  |  | $ | 521 |  |  | $ | 1,416 |  |  | $ | 881 |  |
| Effective tax rate | 18.6 | % |  | 15.6 | % |  | 19.6 | % |  | 12.1 | % |

[0000858877-20-000004:notes:292]
The effective tax rate for the first six months of fiscal 2019 includes a $152 million tax benefit relating to indirect effects from adoption of ASC 606 at the beginning of fiscal 2019.

[0000858877-20-000004:notes:293]
In the first quarter of fiscal 2020, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, which included a reduction in interest expense of $4 million. We are no longer subject to U.S. federal tax audit through fiscal 2013.
As of January 25, 2020, we had $2.0 billion of unrecognized tax benefits, of which $1.7 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at January 25, 2020 could be reduced by approximately $50 million in the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-20-000004:notes:294]
[same as prior period, unchanged from 0000858877-19-000018:notes:298]

[0000858877-20-000004:notes:295]
[same as prior period, unchanged from 0000858877-19-000018:notes:299]

[0000858877-20-000004:notes:296]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-20-000004:notes:297]
Summarized financial information by segment for the second quarter and the first six months of fiscal 2020 and 2019, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-20-000004:notes:298]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,013 |  |  | $ | 7,352 |  |  | $ | 14,990 |  |  | $ | 15,103 |  |
| EMEA | 3,134 |  |  | 3,223 |  |  | 6,417 |  |  | 6,447 |  |
| APJC | 1,859 |  |  | 1,872 |  |  | 3,758 |  |  | 3,968 |  |
| Total | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,692 |  |  | $ | 4,796 |  |  | $ | 10,008 |  |  | $ | 9,866 |  |
| EMEA | 2,062 |  |  | 2,070 |  |  | 4,229 |  |  | 4,141 |  |
| APJC | 1,219 |  |  | 1,109 |  |  | 2,413 |  |  | 2,309 |  |
| Segment total | 7,974 |  |  | 7,975 |  |  | 16,650 |  |  | 16,316 |  |
| Unallocated corporate items | (210 | ) |  | (202 | ) |  | (422 | ) |  | (397 | ) |
| Total | $ | 7,764 |  |  | $ | 7,773 |  |  | $ | 16,228 |  |  | $ | 15,919 |  |

[0000858877-20-000004:notes:299]
[same as prior period, unchanged from 0000858877-19-000018:notes:303]

[0000858877-20-000004:notes:300]
Revenue in the United States was $6.2 billion and $6.4 billion for the second quarter of fiscal 2020 and 2019, respectively, and $13.3 billion for each of the first six months of fiscal 2020 and 2019.

[0000858877-20-000004:notes:301]
[same as prior period, unchanged from 0000858877-19-000018:notes:305]

[0000858877-20-000004:notes:302]
We design, manufacture, and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-20-000004:notes:303]
[same as prior period, unchanged from 0000858877-19-000018:notes:311]

[0000858877-20-000004:notes:304]
[same as prior period, unchanged from 0000858877-19-000018:notes:312]

[0000858877-20-000004:notes:305]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Net income | $ | 2,878 |  |  | $ | 2,822 |  |  | $ | 5,804 |  |  | $ | 6,371 |  |
| Weighted-average shares—basic | 4,242 |  |  | 4,470 |  |  | 4,244 |  |  | 4,517 |  |
| Effect of dilutive potential common shares | 18 |  |  | 35 |  |  | 21 |  |  | 40 |  |
| Weighted-average shares—diluted | 4,260 |  |  | 4,505 |  |  | 4,265 |  |  | 4,557 |  |
| Net income per share—basic | $ | 0.68 |  |  | $ | 0.63 |  |  | $ | 1.37 |  |  | $ | 1.41 |  |
| Net income per share—diluted | $ | 0.68 |  |  | $ | 0.63 |  |  | $ | 1.36 |  |  | $ | 1.40 |  |
| Antidilutive employee share-based awards, excluded | 29 |  |  | 27 |  |  | 32 |  |  | 28 |  |

[0000858877-20-000004:notes:306]
[same as prior period, unchanged from 0000858877-19-000018:notes:314]
