# CSCO note change history — 0000858877-19-000018 → 0000858877-20-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory
  (was, 2019-11-19, similarity 0.8529):
[0000858877-19-000018:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported

- changed (2020-02-18):
[0000858877-20-000004:note_history:2]
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $4.5 billion and $5.0 billion, respectively.
  (was, 2019-11-19, similarity 0.789):
[0000858877-19-000018:note_history:2]
purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2020-02-18):
[0000858877-20-000004:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2020 and July 27, 2019, the liability for these purchase commitments was $126 million and $129 million, respectively, and was included in other current liabilities.
  (was, 2019-11-19, similarity 0.9576):
[0000858877-19-000018:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2019 and July 27, 2019, the liability for these purchase commitments was $121 million and $129 million, respectively, and was included in other current liabilities.

- changed (2020-02-18):
[0000858877-20-000004:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Compensation expense related to acquisitions | $ | 50 |  |  | $ | 66 |  |  | $ | 111 |  |  | $ | 175 |  |
  (was, 2019-11-19, similarity 0.6985):
[0000858877-19-000018:note_history:4]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 109 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:5]
As of January 25, 2020, we estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2019-11-19, similarity 0.9669):
[0000858877-19-000018:note_history:5]
As of October 26, 2019, we estimated that future cash compensation expense of up to $430 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2020-02-18):
[0000858877-20-000004:note_history:6]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $291 million and $326 million as of January 25, 2020 and July 27, 2019, respectively.
  (was, 2019-11-19, similarity 0.9797):
[0000858877-19-000018:note_history:6]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $311 million and $326 million as of October 26, 2019 and July 27, 2019, respectively.

- changed (2020-02-18):
[0000858877-20-000004:note_history:7]
|  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 283 |  |  | 297 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (5 | ) |
| Settlements | (291 | ) |  | (300 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 331 |  |  | $ | 349 |  |
  (was, 2019-11-19, similarity 0.8316):
[0000858877-19-000018:note_history:7]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 140 |  |  | 156 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (3 | ) |
| Settlements | (149 | ) |  | (145 | ) |
| Balance at end of period | $ | 330 |  |  | $ | 367 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:8]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.3 billion for the second quarter of fiscal
  (was, 2019-11-19, similarity 0.8461):
[0000858877-19-000018:note_history:8]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $7.2 billion for the first quarter of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of October 26, 2019 and July 27, 2019, respectively.

- added (2020-02-18):
[0000858877-20-000004:note_history:9]
2020 and 2019, respectively, and was $14.2 billion and $14.5 billion for the first six months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.4 billion as of January 25, 2020 and July 27, 2019, respectively.

- changed (2020-02-18):
[0000858877-20-000004:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $6 million for the second quarter of fiscal 2020 and 2019, respectively, and was $6 million and $9 million for the first six months of fiscal 2020 and 2019, respectively.
  (was, 2019-11-19, similarity 0.8877):
[0000858877-19-000018:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million and $3 million for the first quarter of fiscal 2020 and 2019, respectively.

- changed (2020-02-18):
[0000858877-20-000004:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2019-11-19, similarity 0.9776):
[0000858877-19-000018:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 26, 2019 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2020-02-18):
[0000858877-20-000004:note_history:12]
|  | January 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 258 |  |  | $ | 197 |  |
| End user | 13 |  |  | 21 |  |
| Total | $ | 271 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (69 | ) |  | $ | (62 | ) |
| End user | (13 | ) |  | (15 | ) |
| Total | $ | (82 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 141 |  |

- added (2020-02-18):
[0000858877-20-000004:note_history:13]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC's post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

- changed (2020-02-18):
[0000858877-20-000004:note_history:14]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.
  (was, 2019-11-19, similarity 0.9959):
[0000858877-19-000018:note_history:14]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

- added (2020-02-18):
[0000858877-20-000004:note_history:15]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.2 billion for the alleged evasion of import and other taxes, $0.9 billion for interest, and $0.5 billion for various penalties, all determined using an exchange rate as of January 25, 2020.

- changed (2020-02-18):
[0000858877-20-000004:note_history:16]
We have completed a thorough review of the matters and believe the remaining asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.
  (was, 2019-11-19, similarity 0.7209):
[0000858877-19-000018:note_history:16]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $202 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $0.9 billion for various penalties, all determined using an exchange rate as of October 26, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

- added (2020-02-18):
[0000858877-20-000004:note_history:17]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for four patents in the instituted IPR Proceedings, and all claims of three patents have been found unpatentable and a portion of the claims of a fourth patent have been found unpatentable. The court set a trial for April 7, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement arguments and that the patents are invalid, as well as other defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, however, we are unable to reasonably estimate the ultimate monetary outcome of this litigation at this time.

- changed (2020-02-18):
[0000858877-20-000004:note_history:18]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23,
  (was, 2019-11-19, similarity 0.8973):
[0000858877-19-000018:note_history:18]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

- added (2020-02-18):
[0000858877-20-000004:note_history:19]
2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

- changed (2020-02-18):
[0000858877-20-000004:note_history:20]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.
  (was, 2019-11-19, similarity 0.8286):
[0000858877-19-000018:note_history:20]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

- removed (2020-02-18):
[0000858877-19-000018:note_history:21]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

- removed (2020-02-18):
[0000858877-19-000018:note_history:22]
| Commitments by Period | October 26, 2019 |  | July 27, 2019 |
| Less than 1 year | $ | 3,903 |  |  | $ | 4,239 |  |
| 1 to 3 years | 633 |  |  | 728 |  |
| Total | $ | 4,536 |  |  | $ | 4,967 |  |

- removed (2020-02-18):
[0000858877-19-000018:note_history:23]
|  | October 26, 2019 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 148 |  |  | $ | 197 |  |
| End user | 15 |  |  | 21 |  |
| Total | $ | 163 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (61 | ) |  | $ | (62 | ) |
| End user | (15 | ) |  | (15 | ) |
| Total | $ | (76 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 87 |  |  | $ | 141 |  |

- removed (2020-02-18):
[0000858877-19-000018:note_history:24]
Charter Communications, Inc., which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019, which was denied on March 19, 2019. TWC petitioned the U.S. Supreme Court for review of the judgment, which was denied on November 4, 2019. At this time, we do not believe that our indemnity obligations under our agreement will be material.

- removed (2020-02-18):
[0000858877-19-000018:note_history:25]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to 
resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:26]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory 
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2019-11-19, similarity 0.7516):
[0000858877-19-000018:note_history:26]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported

- removed (2020-02-18):
[0000858877-19-000018:note_history:27]
purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:28]
We have prepared the accompanying financial data as of January 25, 2020 and for the second quarter and first six months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.
  (was, 2019-11-19, similarity 0.9736):
[0000858877-19-000018:note_history:28]
We have prepared the accompanying financial data as of October 26, 2019 and for the first quarter of fiscal 2020 and fiscal 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

- added (2020-02-18):
[0000858877-20-000004:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2020 and 2019; and the statements of cash flows for the first six months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2020-02-18):
[0000858877-19-000018:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 26, 2019, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2020 and fiscal 2019, as applicable, have been made. The results of operations for the first quarter of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:31]
|  | January 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,499 |  |  | 2.54 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 1,499 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2019-11-19, similarity 0.9751):
[0000858877-19-000018:note_history:31]
|  | October 26, 2019 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,000 |  |  | 3.70 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,000 |  |  |  |  | $ | 10,191 |  |  |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:32]
|  |  |  | January 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.51% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.71% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.63% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.88% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (94 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 87 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,499 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,494 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2019-11-19, similarity 0.989):
[0000858877-19-000018:note_history:32]
|  |  |  | October 26, 2019 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.39% |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.77% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.95% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.89% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 18,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (97 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 94 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,000 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,497 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:33]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2020, we were in compliance with all debt covenants.
  (was, 2019-11-19, similarity 0.9319):
[0000858877-19-000018:note_history:33]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2019, we were in compliance with all debt covenants.

- changed (2020-02-18):
[0000858877-20-000004:note_history:34]
As of January 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2019-11-19, similarity 0.9556):
[0000858877-19-000018:note_history:34]
As of October 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-02-18):
[0000858877-20-000004:note_history:35]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |
  (was, 2019-11-19, similarity 0.9836):
[0000858877-19-000018:note_history:35]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 4,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 18,500 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:36]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.
  (was, 2019-11-19, similarity 0.9782):
[0000858877-19-000018:note_history:36]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:37]
|  | January 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,587 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,587 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,155 |  |  | 1,113 |  |
| Equity method investments included in other assets | 61 |  |  | 87 |  |
| Total | $ | 19,803 |  |  | $ | 22,863 |  |
  (was, 2019-11-19, similarity 0.9718):
[0000858877-19-000018:note_history:37]
|  | October 26, 2019 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 19,445 |  |  | $ | 21,660 |  |
| Marketable equity securities | 3 |  |  | 3 |  |
| Total investments | 19,448 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets (1) | 1,151 |  |  | 1,113 |  |
| Equity method investments included in other assets | 66 |  |  | 87 |  |
| Total | $ | 20,665 |  |  | $ | 22,863 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:38]
| January 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,218 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 2,231 |  |
| U.S. government agency securities | 20 |  |  | — |  |  | — |  |  | 20 |  |
| Corporate debt securities | 13,405 |  |  | 196 |  |  | (4 | ) |  | 13,597 |  |
| U.S. agency mortgage-backed securities | 1,612 |  |  | 14 |  |  | (3 | ) |  | 1,623 |  |
| Commercial paper | 1,052 |  |  | — |  |  | — |  |  | 1,052 |  |
| Certificates of deposit | 64 |  |  | — |  |  | — |  |  | 64 |  |
| Total (1) | $ | 18,371 |  |  | $ | 223 |  |  | $ | (7 | ) |  | $ | 18,587 |  |
  (was, 2019-11-19, similarity 0.8957):
[0000858877-19-000018:note_history:38]
| October 26, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 1,322 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 1,324 |  |
| U.S. government agency securities | 98 |  |  | — |  |  | — |  |  | 98 |  |
| Corporate debt securities | 16,057 |  |  | 153 |  |  | (11 | ) |  | 16,199 |  |
| U.S. agency mortgage-backed securities | 1,509 |  |  | 9 |  |  | (8 | ) |  | 1,510 |  |
| Commercial paper | 283 |  |  | — |  |  | — |  |  | 283 |  |
| Certificates of deposit | 31 |  |  | — |  |  | — |  |  | 31 |  |
| Total | $ | 19,300 |  |  | $ | 165 |  |  | $ | (20 | ) |  | $ | 19,445 |  |

- added (2020-02-18):
[0000858877-20-000004:note_history:39]
(1) Net unsettled investment sales were $13 million as of January 25, 2020 and were included in other current assets.

- changed (2020-02-18):
[0000858877-20-000004:note_history:40]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Gross realized gains | $ | 13 |  |  | $ | 1 |  |  | $ | 25 |  |  | $ | 3 |  |
| Gross realized losses | (2 | ) |  | (6 | ) |  | (4 | ) |  | (14 | ) |
| Total | $ | 11 |  |  | $ | (5 | ) |  | $ | 21 |  |  | $ | (11 | ) |
  (was, 2019-11-19, similarity 0.6988):
[0000858877-19-000018:note_history:40]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Gross realized gains | $ | 12 |  |  | $ | 2 |  |
| Gross realized losses | (2 | ) |  | (8 | ) |
| Total | $ | 10 |  |  | $ | (6 | ) |

- changed (2020-02-18):
[0000858877-20-000004:note_history:41]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2020 and July 27, 2019 (in millions):
  (was, 2019-11-19, similarity 0.967):
[0000858877-19-000018:note_history:41]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2019 and July 27, 2019 (in millions):

- changed (2020-02-18):
[0000858877-20-000004:note_history:42]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 44 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |
| U.S. government agency securities | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Corporate debt securities | 260 |  |  | (1 | ) |  | 439 |  |  | (3 | ) |  | 699 |  |  | (4 | ) |
| U.S. agency mortgage-backed securities | 56 |  |  | — |  |  | 374 |  |  | (3 | ) |  | 430 |  |  | (3 | ) |
| Commercial paper | 51 |  |  | — |  |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Certificates of deposit | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Total | $ | 447 |  |  | $ | (1 | ) |  | $ | 836 |  |  | $ | (6 | ) |  | $ | 1,283 |  |  | $ | (7 | ) |
  (was, 2019-11-19, similarity 0.9211):
[0000858877-19-000018:note_history:42]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 479 |  |  | $ | (1 | ) |  | $ | 25 |  |  | $ | — |  |  | $ | 504 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 98 |  |  | — |  |  | 98 |  |  | — |  |
| Corporate debt securities | 1,642 |  |  | (4 | ) |  | 1,200 |  |  | (7 | ) |  | 2,842 |  |  | (11 | ) |
| U.S. agency mortgage-backed securities | 378 |  |  | (1 | ) |  | 462 |  |  | (7 | ) |  | 840 |  |  | (8 | ) |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Certificates of deposit | 6 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |
| Total | $ | 2,530 |  |  | $ | (6 | ) |  | $ | 1,785 |  |  | $ | (14 | ) |  | $ | 4,315 |  |  | $ | (20 | ) |

- changed (2020-02-18):
[0000858877-20-000004:note_history:43]
For available-for-sale debt investments that were in an unrealized loss position as of January 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.
  (was, 2019-11-19, similarity 0.9684):
[0000858877-19-000018:note_history:43]
For available-for-sale debt investments that were in an unrealized loss position as of October 26, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

- changed (2020-02-18):
[0000858877-20-000004:note_history:44]
The following table summarizes the maturities of our available-for-sale debt investments as of January 25, 2020 (in millions):
  (was, 2019-11-19, similarity 0.9504):
[0000858877-19-000018:note_history:44]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2019 (in millions):

- added (2020-02-18):
[0000858877-20-000004:note_history:45]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 71 |  |  | $ | 67 |  |  | $ | 78 |  |  | $ | 75 |  |
| Less: Net gains and losses recognized on equity investments sold | (68 | ) |  | 5 |  |  | (75 | ) |  | (7 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | 3 |  |  | $ | 72 |  |  | $ | 3 |  |  | $ | 68 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 11 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 24 |  |
| Downward adjustments, including impairments | (8 | ) |  | (2 | ) |  | (9 | ) |  | (18 | ) |
| Net adjustments | $ | 3 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 6 |  |
  (was, 2019-11-19, similarity 0.704):
[0000858877-19-000018:note_history:46]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 1 |  |  | $ | 10 |  |
| Downward adjustments, including impairments | (2 | ) |  | (16 | ) |
| Net adjustments | $ | (1 | ) |  | $ | (6 | ) |

- changed (2020-02-18):
[0000858877-20-000004:note_history:47]
As of January 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.
  (was, 2019-11-19, similarity 0.8355):
[0000858877-19-000018:note_history:47]
(1) We held equity interests in certain private equity funds of $0.7 billion and $0.6 billion as of October 26, 2019 and July 27, 2019, respectively, which are accounted for under the NAV practical expedient.

- changed (2020-02-18):
[0000858877-20-000004:note_history:48]
| (c) | Variable Interest Entities |
  (was, 2019-11-19, similarity 0.9722):
[0000858877-19-000018:note_history:48]
| (d) | Variable Interest Entities |

- changed (2020-02-18):
[0000858877-20-000004:note_history:49]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2019-11-19, similarity 0.9881):
[0000858877-19-000018:note_history:49]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2019, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2020-02-18):
[0000858877-20-000004:note_history:50]
As of January 25, 2020, the carrying value of investments in privately held companies was $1.2 billion. $669 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $291 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.
  (was, 2019-11-19, similarity 0.9883):
[0000858877-19-000018:note_history:50]
As of October 26, 2019, the carrying value of investments in privately held companies was $1.2 billion. $659 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $311 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.

- removed (2020-02-18):
[0000858877-19-000018:note_history:51]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 7 |  |  | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (8 | ) |  | (12 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (1 | ) |  | $ | (4 | ) |

- removed (2020-02-18):
[0000858877-19-000018:note_history:52]
| (c) | Securities Lending |

- removed (2020-02-18):
[0000858877-19-000018:note_history:53]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $21 million and $0.5 billion for the first quarter of fiscal 2020 and 2019, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 26, 2019 and July 27, 2019, we had no outstanding securities lending transactions.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:54]
|  |  |  | January 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.51% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.71% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.63% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.88% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (94 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 87 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,499 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,494 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2019-11-19, similarity 0.989):
[0000858877-19-000018:note_history:54]
|  |  |  | October 26, 2019 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.39% |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.77% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.95% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.89% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 18,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (97 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 94 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,000 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,497 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:55]
As of January 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2019-11-19, similarity 0.9556):
[0000858877-19-000018:note_history:55]
As of October 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-02-18):
[0000858877-20-000004:note_history:56]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |
  (was, 2019-11-19, similarity 0.9836):
[0000858877-19-000018:note_history:56]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 4,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 18,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0000858877-20-000004:note_history:57]
|  | January 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,499 |  |  | 2.54 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 1,499 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2019-11-19, similarity 0.9751):
[0000858877-19-000018:note_history:57]
|  | October 26, 2019 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,000 |  |  | 3.70 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,000 |  |  |  |  | $ | 10,191 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-18):
[0000858877-20-000004:note_history:58]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:59]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.
  (was, 2019-11-19, similarity 0.9126):
[0000858877-19-000018:note_history:59]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.

- added (2020-02-18):
[0000858877-20-000004:note_history:60]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:61]
(1) Includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.
  (was, 2019-11-19, similarity 0.9112):
[0000858877-19-000018:note_history:61]
(1) Includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.

- removed (2020-02-18):
[0000858877-19-000018:note_history:62]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |

- removed (2020-02-18):
[0000858877-19-000018:note_history:63]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-18):
[0000858877-20-000004:note_history:64]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative

- changed (2020-02-18):
[0000858877-20-000004:note_history:65]
marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2019-11-19, similarity 0.7736):
[0000858877-19-000018:note_history:65]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-18):
[0000858877-20-000004:note_history:66]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative

- changed (2020-02-18):
[0000858877-20-000004:note_history:67]
marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2019-11-19, similarity 0.7736):
[0000858877-19-000018:note_history:67]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- added (2020-02-18):
[0000858877-20-000004:note_history:68]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-02-18):
[0000858877-20-000004:note_history:69]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.
  (was, 2019-11-19, similarity 0.9126):
[0000858877-19-000018:note_history:69]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.

- changed (2020-02-18):
[0000858877-20-000004:note_history:70]
Accounts receivable, net was $4.3 billion as of January 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.
  (was, 2019-11-19, similarity 0.9577):
[0000858877-19-000018:note_history:70]
Accounts receivable, net was $4.9 billion as of October 26, 2019 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

- changed (2020-02-18):
[0000858877-20-000004:note_history:71]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of January 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $966 million and $860 million, respectively, and were included in other current assets and other assets.
  (was, 2019-11-19, similarity 0.9852):
[0000858877-19-000018:note_history:71]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 26, 2019 and July 27, 2019, our contract assets for these unbilled receivables were $954 million and $860 million, respectively, and were included in other current assets and other assets.

- changed (2020-02-18):
[0000858877-20-000004:note_history:72]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.7 billion as of January 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.9 billion and $6.6 billion of revenue during the second quarter and first six months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.
  (was, 2019-11-19, similarity 0.6581):
[0000858877-19-000018:note_history:72]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of October 26, 2019 compared to $18.5 billion as of July 27, 2019. We recognized approximately $3.7 billion of revenue during the first quarter of fiscal 2020, that was included in the deferred revenue balance at July 27, 2019.

- added (2020-02-18):
[0000858877-20-000004:note_history:73]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 25, 2020, the aggregate amount of RPO was $24.9 billion, comprised of $18.7 billion of deferred revenue and $6.2 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- changed (2020-02-18):
[0000858877-20-000004:note_history:74]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $708 million and $750 million as of January 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $122 million and $238 million for the second quarter and first six months of fiscal 2020, respectively, and $100 million and $212 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.
  (was, 2019-11-19, similarity 0.8679):
[0000858877-19-000018:note_history:74]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $707 million and $750 million as of October 26, 2019 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $116 million and $112 million for the first quarter of fiscal 2020 and fiscal 2019, respectively, and was included in sales and marketing expenses.

- removed (2020-02-18):
[0000858877-19-000018:note_history:75]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |

- removed (2020-02-18):
[0000858877-19-000018:note_history:76]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 26, 2019, the aggregate amount of RPO was $24.9 billion, comprised of $18.6 billion of deferred revenue and $6.3 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.
