# CSCO 8-K — 0001193125-20-033208 filed 2020-02-12

## item codes, every 8-K on or before 2020-02-18

- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2020-02-18

- none on or before 2020-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-033208:8k_2_02:1]
EX-99.1
2
d885601dex991.htm
EX-99.1

[0001193125-20-033208:8k_2_02:2]
EX-99.1

[0001193125-20-033208:8k_2_02:3]
Exhibit 99.1

[0001193125-20-033208:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-20-033208:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-20-033208:8k_2_02:6]
Dividend Increased 3 Percent

[0001193125-20-033208:8k_2_02:7]
|  | • |  | Q2 Results: |

[0001193125-20-033208:8k_2_02:8]
|  | • |  | Revenue: $12.0 billion |

[0001193125-20-033208:8k_2_02:9]
|  | • |  | Decrease of (4)% year over year |

[0001193125-20-033208:8k_2_02:10]
|  | • |  | Earnings per Share: GAAP: $0.68; Non-GAAP: $0.77 |

[0001193125-20-033208:8k_2_02:11]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-20-033208:8k_2_02:12]
|  | • |  | Q3 Guidance: |

[0001193125-20-033208:8k_2_02:13]
|  | • |  | Revenue: (1.5)% to (3.5)% decline year over year |

[0001193125-20-033208:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.62 to $0.67; Non-GAAP: $0.79 to $0.81 |

[0001193125-20-033208:8k_2_02:15]
SAN JOSE, Calif. — February 12, 2020 — Cisco today reported second quarter results for the period ended January 25,
2020. Cisco reported second quarter revenue of $12.0 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.9 billion or $0.68 per share, and non-GAAP net income of
$3.3 billion or $0.77 per share.

[0001193125-20-033208:8k_2_02:16]
“I am incredibly proud of the innovation our teams continue to drive,” said Chuck Robbins, chairman and
CEO of Cisco. “I am confident in our long-term growth opportunities as we help our customers build out the networks for the future.”

[0001193125-20-033208:8k_2_02:17]
GAAP Results

[0001193125-20-033208:8k_2_02:18]
|  |  | Q2 FY 2020 |  |  | Q2 FY 2019 |  |  | Vs. Q2 FY 2019 |  |
| Revenue |  | $ | 12.0 billion |  |  | $ | 12.4 billion |  |  |  | (4 | )% |
| Net Income |  | $ | 2.9 billion |  |  | $ | 2.8 billion |  |  |  | 2 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.68 |  |  | $ | 0.63 |  |  |  | 8 | % |
| Non-GAAP Results |  |
|  |  | Q2 FY 2020 |  |  | Q2 FY 2019 |  |  | Vs. Q2 FY 2019 |  |
| Net Income |  | $ | 3.3 billion |  |  | $ | 3.3 billion |  |  |  | — | % |
| EPS |  | $ | 0.77 |  |  | $ | 0.73 |  |  |  | 5 | % |

[0001193125-20-033208:8k_2_02:19]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-033208:8k_2_02:20]
1

[0001193125-20-033208:8k_2_02:21]
Cisco Increases Quarterly Cash Dividend

[0001193125-20-033208:8k_2_02:22]
Cisco has declared a quarterly dividend of $0.36 per common share, a $0.01 increase or up 3% over the previous quarter’s dividend, to be paid on
April 22, 2020 to all shareholders of record as of the close of business on April 3, 2020. Future dividends will be subject to Board approval.

[0001193125-20-033208:8k_2_02:23]
“We executed well this quarter by delivering strong margins and EPS growth while driving more software and subscriptions,” said Kelly Kramer, CFO of
Cisco. Our increased dividend shows confidence in the strength of our ongoing cash flows and demonstrates our commitment to shareholder return.”

[0001193125-20-033208:8k_2_02:24]
Financial Summary

[0001193125-20-033208:8k_2_02:25]
All comparative percentages are on
a year-over-year basis unless otherwise noted.

[0001193125-20-033208:8k_2_02:26]
Q2 FY 2020 Highlights

[0001193125-20-033208:8k_2_02:27]
Revenue — Total revenue was $12.0 billion, down 4%, with product revenue down 6% and service revenue up 5%. Revenue by geographic
segment was: Americas down 5%, EMEA down 3%, and APJC down 1%. Product revenue was led by growth in Security, up 9%. Infrastructure Platforms and Applications were each down 8%.

[0001193125-20-033208:8k_2_02:28]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 64.7%, 63.9%, and 66.6%,
respectively, as compared with 62.5%, 61.0%, and 66.6%, respectively, in the second quarter of fiscal 2019.

[0001193125-20-033208:8k_2_02:29]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 66.4%, 65.9%, and 67.7%, respectively, as compared with 64.1%, 62.8%, and 67.7%, respectively, in the second quarter of
fiscal 2019.

[0001193125-20-033208:8k_2_02:30]
Total gross margins by geographic segment were: 66.9% for the Americas, 65.8% for EMEA and 65.6% for APJC.

[0001193125-20-033208:8k_2_02:31]
Operating Expenses — On a GAAP basis, operating expenses were $4.4 billion, down 4%.
Non-GAAP operating expenses were $3.9 billion, down 1%, and were 32.7% of revenue.

[0001193125-20-033208:8k_2_02:32]
Operating Income
— GAAP operating income was $3.4 billion, up 5%, with GAAP operating margin of 28.2%. Non-GAAP operating income was $4.0 billion, up 1%, with
non-GAAP operating margin at 33.7%.

[0001193125-20-033208:8k_2_02:33]
Provision for Income Taxes — The GAAP tax provision rate
was 18.6%. The non-GAAP tax provision rate was 20.0%.

[0001193125-20-033208:8k_2_02:34]
Net Income and EPS — On a GAAP basis,
net income was $2.9 billion and EPS was $0.68. On a non-GAAP basis, net income was flat at $3.3 billion, and EPS was $0.77, an increase of 5%.

[0001193125-20-033208:8k_2_02:35]
Cash Flow from Operating Activities — $3.8 billion for the second quarter of fiscal 2020, flat compared with $3.8 billion for the
second quarter of fiscal 2019.

[0001193125-20-033208:8k_2_02:36]
Balance Sheet and Other Financial Highlights

[0001193125-20-033208:8k_2_02:37]
Cash and Cash Equivalents and Investments — $27.1 billion at the end of the second quarter of fiscal 2020, compared with
$33.4 billion at the end of fiscal 2019.

[0001193125-20-033208:8k_2_02:38]
Deferred Revenue — $18.7 billion, up 8% in total, with deferred product revenue up
19%. Deferred service revenue was up 2%.

[0001193125-20-033208:8k_2_02:39]
Remaining Performance Obligations — $24.9 billion at the end of the second
quarter of fiscal 2020, up 11%.

[0001193125-20-033208:8k_2_02:40]
Capital Allocation — In the second quarter of fiscal 2020, we returned $2.4 billion to
shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.35 per common share, or $1.5 billion, and repurchased approximately 18 million shares of common stock under our stock repurchase program at an
average price of $46.71 per share for an aggregate purchase price of $870 million. The remaining authorized amount for stock repurchases under the program is $11.8 billion with no termination date.

[0001193125-20-033208:8k_2_02:41]
2

[0001193125-20-033208:8k_2_02:42]
Guidance for Q3 FY 2020

[0001193125-20-033208:8k_2_02:43]
Cisco expects to achieve the following results for the third quarter of fiscal 2020:

[0001193125-20-033208:8k_2_02:44]
| Q3 FY 2020 |  |  |
| Revenue |  | (1.5)% - (3.5)% decline Y/Y |
| Non-GAAP gross margin rate |  | 64.5% - 65.5% |
| Non-GAAP operating margin rate |  | 32.5% - 33.5% |
| Non-GAAP tax provision rate |  | 20% |
| Non-GAAP EPS |  | $0.79 - $0.81 |

[0001193125-20-033208:8k_2_02:45]
Cisco estimates that GAAP EPS will be $0.62 to $0.67 in the third quarter of fiscal 2020.

[0001193125-20-033208:8k_2_02:46]
A reconciliation between the Guidance for Q3 FY 2020 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q3 FY 2020” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-033208:8k_2_02:47]
Editor’s Notes:

[0001193125-20-033208:8k_2_02:48]
|  | • |  | Q2 fiscal year 2020 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, February 12, 2020 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-20-033208:8k_2_02:49]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 12, 2020 to 4:00 p.m. Pacific Time, February 19, 2020 at 1-800-839-1160 (United States) or 1-402-998-0925 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-033208:8k_2_02:50]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 12, 2020. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-033208:8k_2_02:51]
3

[0001193125-20-033208:8k_2_02:52]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:53]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-20-033208:8k_2_02:54]
(In millions, except per-share amounts)

[0001193125-20-033208:8k_2_02:55]
(Unaudited)

[0001193125-20-033208:8k_2_02:56]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 25,2020 |  |  | January 26,2019 |  |  | January 25,2020 |  |  | January 26,2019 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,671 |  |  | $ | 9,273 |  |  | $ | 18,549 |  |  | $ | 19,163 |  |
| Service |  |  | 3,334 |  |  |  | 3,173 |  |  |  | 6,615 |  |  |  | 6,355 |  |
| Total revenue |  |  | 12,005 |  |  |  | 12,446 |  |  |  | 25,164 |  |  |  | 25,518 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,126 |  |  |  | 3,614 |  |  |  | 6,650 |  |  |  | 7,413 |  |
| Service |  |  | 1,115 |  |  |  | 1,059 |  |  |  | 2,286 |  |  |  | 2,186 |  |
| Total cost of sales |  |  | 4,241 |  |  |  | 4,673 |  |  |  | 8,936 |  |  |  | 9,599 |  |
| GROSS MARGIN |  |  | 7,764 |  |  |  | 7,773 |  |  |  | 16,228 |  |  |  | 15,919 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,570 |  |  |  | 1,557 |  |  |  | 3,236 |  |  |  | 3,165 |  |
| Sales and marketing |  |  | 2,279 |  |  |  | 2,271 |  |  |  | 4,759 |  |  |  | 4,681 |  |
| General and administrative |  |  | 455 |  |  |  | 509 |  |  |  | 974 |  |  |  | 720 |  |
| Amortization of purchased intangible assets |  |  | 38 |  |  |  | 39 |  |  |  | 74 |  |  |  | 73 |  |
| Restructuring and other charges |  |  | 42 |  |  |  | 186 |  |  |  | 226 |  |  |  | 264 |  |
| Total operating expenses |  |  | 4,384 |  |  |  | 4,562 |  |  |  | 9,269 |  |  |  | 8,903 |  |
| OPERATING INCOME |  |  | 3,380 |  |  |  | 3,211 |  |  |  | 6,959 |  |  |  | 7,016 |  |
| Interest income |  |  | 242 |  |  |  | 328 |  |  |  | 515 |  |  |  | 672 |  |
| Interest expense |  |  | (158 | ) |  |  | (223 | ) |  |  | (336 | ) |  |  | (444 | ) |
| Other income (loss), net |  |  | 70 |  |  |  | 27 |  |  |  | 82 |  |  |  | 8 |  |
| Interest and other income (loss), net |  |  | 154 |  |  |  | 132 |  |  |  | 261 |  |  |  | 236 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,534 |  |  |  | 3,343 |  |  |  | 7,220 |  |  |  | 7,252 |  |
| Provision for income taxes |  |  | 656 |  |  |  | 521 |  |  |  | 1,416 |  |  |  | 881 |  |
| NET INCOME |  | $ | 2,878 |  |  | $ | 2,822 |  |  | $ | 5,804 |  |  | $ | 6,371 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.63 |  |  | $ | 1.37 |  |  | $ | 1.41 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.63 |  |  | $ | 1.36 |  |  | $ | 1.40 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,242 |  |  |  | 4,470 |  |  |  | 4,244 |  |  |  | 4,517 |  |
| Diluted |  |  | 4,260 |  |  |  | 4,505 |  |  |  | 4,265 |  |  |  | 4,557 |  |

[0001193125-20-033208:8k_2_02:57]
The Consolidated Statements of Operations include the results of the divested Service Provider Video Software Solutions
(SPVSS) business for the six months ended January 26, 2019.

[0001193125-20-033208:8k_2_02:58]
4

[0001193125-20-033208:8k_2_02:59]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:60]
REVENUE BY SEGMENT

[0001193125-20-033208:8k_2_02:61]
(In
millions, except percentages)

[0001193125-20-033208:8k_2_02:62]
|  |  | January 25, 2020 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,013 |  |  |  | (5 | )% |  | $ | 14,990 |  |  |  | — | % |  |  | (1 | )% |
| EMEA |  |  | 3,134 |  |  |  | (3 | )% |  |  | 6,417 |  |  |  | 1 | % |  |  | — | % |
| APJC |  |  | 1,859 |  |  |  | (1 | )% |  |  | 3,758 |  |  |  | (5 | )% |  |  | (5 | )% |
| Total |  | $ | 12,005 |  |  |  | (4 | )% |  | $ | 25,164 |  |  |  | (1 | )% |  |  | (1 | )% |

[0001193125-20-033208:8k_2_02:63]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-033208:8k_2_02:64]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the six
months ended January 26, 2019 was $168 million.

[0001193125-20-033208:8k_2_02:65]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:66]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-20-033208:8k_2_02:67]
(In percentages)

[0001193125-20-033208:8k_2_02:68]
|  |  | January 25, 2020 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 66.9 | % |  |  | 66.8 | % |
| EMEA |  |  | 65.8 | % |  |  | 65.9 | % |
| APJC |  |  | 65.6 | % |  |  | 64.2 | % |

[0001193125-20-033208:8k_2_02:69]
5

[0001193125-20-033208:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:71]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-20-033208:8k_2_02:72]
(In millions, except percentages)

[0001193125-20-033208:8k_2_02:73]
|  |  | January 25, 2020 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,528 |  |  |  | (8 | )% |  | $ | 14,067 |  |  |  | (4 | )% |  |  | (4 | )% |
| Applications |  |  | 1,349 |  |  |  | (8 | )% |  |  | 2,847 |  |  |  | (1 | )% |  |  | (1 | )% |
| Security |  |  | 748 |  |  |  | 9 | % |  |  | 1,563 |  |  |  | 15 | % |  |  | 15 | % |
| Other Products |  |  | 46 |  |  |  | 110 | % |  |  | 72 |  |  |  | 33 | % |  |  | (64 | )% |
| Total Product |  |  | 8,671 |  |  |  | (6 | )% |  |  | 18,549 |  |  |  | (2 | )% |  |  | (3 | )% |
| Services |  |  | 3,334 |  |  |  | 5 | % |  |  | 6,615 |  |  |  | 4 | % |  |  | 4 | % |
| Total |  | $ | 12,005 |  |  |  | (4 | )% |  | $ | 25,164 |  |  |  | (1 | )% |  |  | (1 | )% |

[0001193125-20-033208:8k_2_02:74]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-033208:8k_2_02:75]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the six
months ended January 26, 2019 was $168 million.

[0001193125-20-033208:8k_2_02:76]
6

[0001193125-20-033208:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:78]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-20-033208:8k_2_02:79]
(In millions)

[0001193125-20-033208:8k_2_02:80]
(Unaudited)

[0001193125-20-033208:8k_2_02:81]
|  |  | January 25, 2020 |  |  | July 27, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,475 |  |  | $ | 11,750 |  |
| Investments |  |  | 18,587 |  |  |  | 21,663 |  |
| Accounts receivable, net of allowance for doubtful accounts of $112 at January 25, 2020 and $136 at July 27, 2019 |  |  | 4,330 |  |  |  | 5,491 |  |
| Inventories |  |  | 1,353 |  |  |  | 1,383 |  |
| Financing receivables, net |  |  | 4,827 |  |  |  | 5,095 |  |
| Other current assets |  |  | 2,481 |  |  |  | 2,373 |  |
| Total current assets |  |  | 40,053 |  |  |  | 47,755 |  |
| Property and equipment, net |  |  | 2,621 |  |  |  | 2,789 |  |
| Financing receivables, net |  |  | 4,757 |  |  |  | 4,958 |  |
| Goodwill |  |  | 33,612 |  |  |  | 33,529 |  |
| Purchased intangible assets, net |  |  | 1,906 |  |  |  | 2,201 |  |
| Deferred tax assets |  |  | 3,896 |  |  |  | 4,065 |  |
| Other assets |  |  | 3,581 |  |  |  | 2,496 |  |
| TOTAL ASSETS |  | $ | 90,426 |  |  | $ | 97,793 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1,499 |  |  | $ | 10,191 |  |
| Accounts payable |  |  | 1,935 |  |  |  | 2,059 |  |
| Income taxes payable |  |  | 819 |  |  |  | 1,149 |  |
| Accrued compensation |  |  | 2,690 |  |  |  | 3,221 |  |
| Deferred revenue |  |  | 10,638 |  |  |  | 10,668 |  |
| Other current liabilities |  |  | 4,507 |  |  |  | 4,424 |  |
| Total current liabilities |  |  | 22,088 |  |  |  | 31,712 |  |
| Long-term debt |  |  | 14,494 |  |  |  | 14,475 |  |
| Income taxes payable |  |  | 8,227 |  |  |  | 8,927 |  |
| Deferred revenue |  |  | 8,048 |  |  |  | 7,799 |  |
| Other long-term liabilities |  |  | 2,036 |  |  |  | 1,309 |  |
| Total liabilities |  |  | 54,893 |  |  |  | 64,222 |  |
| Total equity |  |  | 35,533 |  |  |  | 33,571 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 90,426 |  |  | $ | 97,793 |  |

[0001193125-20-033208:8k_2_02:82]
7

[0001193125-20-033208:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:84]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-20-033208:8k_2_02:85]
(In millions)

[0001193125-20-033208:8k_2_02:86]
(Unaudited)

[0001193125-20-033208:8k_2_02:87]
|  |  | Six Months Ended |  |
|  |  | January 25,2020 |  |  | January 26,2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,804 |  |  | $ | 6,371 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 918 |  |  |  | 952 |  |
| Share-based compensation expense |  |  | 779 |  |  |  | 792 |  |
| Provision (benefit) for receivables |  |  | 46 |  |  |  | 30 |  |
| Deferred income taxes |  |  | 128 |  |  |  | (257 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (162 | ) |  |  | (77 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,084 |  |  |  | 1,613 |  |
| Inventories |  |  | 25 |  |  |  | (203 | ) |
| Financing receivables |  |  | 408 |  |  |  | 161 |  |
| Other assets |  |  | 130 |  |  |  | (652 | ) |
| Accounts payable |  |  | (126 | ) |  |  | (296 | ) |
| Income taxes, net |  |  | (1,007 | ) |  |  | (830 | ) |
| Accrued compensation |  |  | (521 | ) |  |  | (339 | ) |
| Deferred revenue |  |  | 236 |  |  |  | 207 |  |
| Other liabilities |  |  | (355 | ) |  |  | 88 |  |
| Net cash provided by operating activities |  |  | 7,387 |  |  |  | 7,560 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (4,250 | ) |  |  | (677 | ) |
| Proceeds from sales of investments |  |  | 3,410 |  |  |  | 3,055 |  |
| Proceeds from maturities of investments |  |  | 4,044 |  |  |  | 6,263 |  |
| Acquisitions and divestitures |  |  | (163 | ) |  |  | (1,599 | ) |
| Purchases of investments in privately held companies |  |  | (97 | ) |  |  | (68 | ) |
| Return of investments in privately held companies |  |  | 91 |  |  |  | 43 |  |
| Acquisition of property and equipment |  |  | (391 | ) |  |  | (473 | ) |
| Proceeds from sales of property and equipment |  |  | 131 |  |  |  | 10 |  |
| Other |  |  | (10 | ) |  |  | (12 | ) |
| Net cash provided by investing activities |  |  | 2,765 |  |  |  | 6,542 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 334 |  |  |  | 312 |  |
| Repurchases of common stock - repurchase program |  |  | (1,648 | ) |  |  | (10,062 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (437 | ) |  |  | (514 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (3,470 | ) |  |  | — |  |
| Repayments of debt |  |  | (5,220 | ) |  |  | — |  |
| Dividends paid |  |  | (2,972 | ) |  |  | (2,970 | ) |
| Other |  |  | (12 | ) |  |  | 18 |  |
| Net cash used in financing activities |  |  | (13,425 | ) |  |  | (13,216 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | (3,273 | ) |  |  | 886 |  |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 11,772 |  |  |  | 8,993 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 8,499 |  |  | $ | 9,879 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 349 |  |  | $ | 425 |  |
| Cash paid for income taxes, net |  | $ | 2,295 |  |  | $ | 1,968 |  |

[0001193125-20-033208:8k_2_02:88]
8

[0001193125-20-033208:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:90]
DEFERRED REVENUE

[0001193125-20-033208:8k_2_02:91]
(In
millions)

[0001193125-20-033208:8k_2_02:92]
|  |  | January 25,2020 |  |  | October 26,2019 |  |  | January 26,2019 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,526 |  |  | $ | 11,497 |  |  | $ | 11,246 |  |
| Product |  |  | 7,160 |  |  |  | 7,105 |  |  |  | 6,015 |  |
| Total |  | $ | 18,686 |  |  | $ | 18,602 |  |  | $ | 17,261 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,638 |  |  | $ | 10,646 |  |  | $ | 9,976 |  |
| Noncurrent |  |  | 8,048 |  |  |  | 7,956 |  |  |  | 7,285 |  |
| Total |  | $ | 18,686 |  |  | $ | 18,602 |  |  | $ | 17,261 |  |

[0001193125-20-033208:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:94]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-20-033208:8k_2_02:95]
(In millions, except per-share amounts)

[0001193125-20-033208:8k_2_02:96]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0001193125-20-033208:8k_2_02:97]
9

[0001193125-20-033208:8k_2_02:98]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:99]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-033208:8k_2_02:100]
GAAP TO NON-GAAP NET INCOME

[0001193125-20-033208:8k_2_02:101]
(In millions, except per-share amounts)

[0001193125-20-033208:8k_2_02:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 25,2020 |  |  | January 26,2019 |  |  | January 25,2020 |  |  | January 26,2019 |  |
| GAAP net income |  | $ | 2,878 |  |  | $ | 2,822 |  |  | $ | 5,804 |  |  | $ | 6,371 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 59 |  |  |  | 53 |  |  |  | 116 |  |  |  | 109 |  |
| Amortization of acquisition-related intangible assets |  |  | 150 |  |  |  | 141 |  |  |  | 300 |  |  |  | 277 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 3 |  |  |  | 2 |  |  |  | 7 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |
| Total adjustments to GAAP cost of sales |  |  | 210 |  |  |  | 202 |  |  |  | 422 |  |  |  | 397 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 320 |  |  |  | 323 |  |  |  | 653 |  |  |  | 652 |  |
| Amortization of acquisition-related intangible assets |  |  | 38 |  |  |  | 39 |  |  |  | 74 |  |  |  | 73 |  |
| Acquisition-related/divestiture costs |  |  | 53 |  |  |  | 39 |  |  |  | 125 |  |  |  | 160 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (395 | ) |
| Significant asset impairments and restructurings |  |  | 42 |  |  |  | 186 |  |  |  | 226 |  |  |  | 264 |  |
| Total adjustments to GAAP operating expenses |  |  | 453 |  |  |  | 587 |  |  |  | 1,078 |  |  |  | 754 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (87 | ) |  |  | (64 | ) |  |  | (100 | ) |  |  | (73 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 576 |  |  |  | 725 |  |  |  | 1,400 |  |  |  | 1,078 |  |
| Income tax effect of non-GAAP adjustments |  |  | (166 | ) |  |  | (209 | ) |  |  | (375 | ) |  |  | (394 | ) |
| Significant tax matters |  |  | — |  |  |  | (43 | ) |  |  | 67 |  |  |  | (308 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (166 | ) |  |  | (252 | ) |  |  | (308 | ) |  |  | (702 | ) |
| Non-GAAP net income |  | $ | 3,288 |  |  | $ | 3,295 |  |  | $ | 6,896 |  |  | $ | 6,747 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.68 |  |  | $ | 0.63 |  |  | $ | 1.36 |  |  | $ | 1.40 |  |
| Non-GAAP |  | $ | 0.77 |  |  | $ | 0.73 |  |  | $ | 1.62 |  |  | $ | 1.48 |  |

[0001193125-20-033208:8k_2_02:103]
10

[0001193125-20-033208:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:105]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-033208:8k_2_02:106]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-20-033208:8k_2_02:107]
(In millions, except percentages)

[0001193125-20-033208:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | January 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,545 |  |  | $ | 2,219 |  |  | $ | 7,764 |  |  | $ | 4,384 |  |  |  | (4 | )% |  | $ | 3,380 |  |  |  | 5 | % |  | $ | 154 |  |  |  | 17 | % |  | $ | 2,878 |  |  |  | 2 | % |
| % of revenue |  |  | 63.9 | % |  |  | 66.6 | % |  |  | 64.7 | % |  |  | 36.5 | % |  |  |  |  |  |  | 28.2 | % |  |  |  |  |  |  | 1.3 | % |  |  |  |  |  |  | 24.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 36 |  |  |  | 59 |  |  |  | 320 |  |  |  |  |  |  |  | 379 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 379 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 150 |  |  |  | — |  |  |  | 150 |  |  |  | 38 |  |  |  |  |  |  |  | 188 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 188 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 53 |  |  |  |  |  |  |  | 54 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 54 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  |  |  |  |  | 42 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 42 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (87 | ) |  |  |  |  |  |  | (87 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (166 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,718 |  |  | $ | 2,256 |  |  | $ | 7,974 |  |  | $ | 3,931 |  |  |  | (1 | )% |  | $ | 4,043 |  |  |  | 1 | % |  | $ | 67 |  |  |  | (1 | )% |  | $ | 3,288 |  |  |  | — | % |
| % of revenue |  |  | 65.9 | % |  |  | 67.7 | % |  |  | 66.4 | % |  |  | 32.7 | % |  |  |  |  |  |  | 33.7 | % |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  |  | 27.4 | % |  |  |  |  |

[0001193125-20-033208:8k_2_02:109]
|  |  | Three Months Ended |  |
|  |  | January 26, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,659 |  |  | $ | 2,114 |  |  | $ | 7,773 |  |  | $ | 4,562 |  |  | $ | 3,211 |  |  | $ | 132 |  |  | $ | 2,822 |  |
| % of revenue |  |  | 61.0 | % |  |  | 66.6 | % |  |  | 62.5 | % |  |  | 36.7 | % |  |  | 25.8 | % |  |  | 1.1 | % |  |  | 22.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 22 |  |  |  | 31 |  |  |  | 53 |  |  |  | 323 |  |  |  | 376 |  |  |  | — |  |  |  | 376 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 39 |  |  |  | 180 |  |  |  | — |  |  |  | 180 |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |  |  | 39 |  |  |  | 42 |  |  |  | — |  |  |  | 42 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 186 |  |  |  | 186 |  |  |  | — |  |  |  | 186 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (64 | ) |  |  | (64 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (252 | ) |
| Non-GAAP amount |  | $ | 5,828 |  |  | $ | 2,147 |  |  | $ | 7,975 |  |  | $ | 3,975 |  |  | $ | 4,000 |  |  | $ | 68 |  |  | $ | 3,295 |  |
| % of revenue |  |  | 62.8 | % |  |  | 67.7 | % |  |  | 64.1 | % |  |  | 31.9 | % |  |  | 32.1 | % |  |  | 0.5 | % |  |  | 26.5 | % |

[0001193125-20-033208:8k_2_02:110]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-033208:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-20-033208:8k_2_02:112]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-033208:8k_2_02:113]
EFFECTIVE TAX RATE

[0001193125-20-033208:8k_2_02:114]
(In
percentages)

[0001193125-20-033208:8k_2_02:115]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 25,2020 |  |  | January 26,2019 |  |  | January 25,2020 |  |  | January 26,2019 |  |
| GAAP effective tax rate |  |  | 18.6 | % |  |  | 15.6 | % |  |  | 19.6 | % |  |  | 12.1 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 1.4 | % |  |  | 3.4 | % |  |  | 0.4 | % |  |  | 6.9 | % |
| Non-GAAP effective tax rate |  |  | 20.0 | % |  |  | 19.0 | % |  |  | 20.0 | % |  |  | 19.0 | % |

[0001193125-20-033208:8k_2_02:116]
GAAP TO NON-GAAP GUIDANCE FOR Q3 FY 2020

[0001193125-20-033208:8k_2_02:117]
| Q3 FY 2020 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 63% - 64% |  | 26% - 27% |  | 19% |  | $0.62 - $0.67 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.07 - $0.08 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | — |  | $0.05 - $0.06 |
| Significant asset impairments and restructurings (1) |  | — |  | 1.5% |  | — |  | $0.02 - $0.03 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 1% |  |  |
| Non-GAAP |  | 64.5% - 65.5% |  | 32.5% - 33.5% |  | 20% |  | $0.79 - $0.81 |

[0001193125-20-033208:8k_2_02:118]
| (1) | In the third quarter of fiscal 2020, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $300 million consisting of severance and other one-time termination benefits, and other costs. We expect to recognize approximately $150 million of these charges in the third quarter of fiscal 2020. |

[0001193125-20-033208:8k_2_02:119]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-20-033208:8k_2_02:120]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-20-033208:8k_2_02:121]
12

[0001193125-20-033208:8k_2_02:122]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-20-033208:8k_2_02:123]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax
rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-20-033208:8k_2_02:124]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles
and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they
do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the
corresponding GAAP measures.

[0001193125-20-033208:8k_2_02:125]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures,
provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-20-033208:8k_2_02:126]
For its internal budgeting process, Cisco’s management uses financial statements that do not include,
when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-20-033208:8k_2_02:127]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of fiscal 2019 on October 28, 2018. This release
includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its
financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SPVSS business in reviewing
the financial results of Cisco.

[0001193125-20-033208:8k_2_02:128]
About Cisco

[0001193125-20-033208:8k_2_02:129]
Cisco
(Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at
newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-20-033208:8k_2_02:130]
Copyright © 2020 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo
are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of
their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-20-033208:8k_2_02:131]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-20-033208:8k_2_02:132]
14
