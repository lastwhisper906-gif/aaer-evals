# CSCO MD&A — 0000858877-20-000004


## mdna

[0000858877-20-000004:mdna:1]
[same as prior period, unchanged from 0000858877-19-000018:mdna:1]

[0000858877-20-000004:mdna:2]
[same as prior period, unchanged from 0000858877-19-000018:mdna:2]

[0000858877-20-000004:mdna:3]
[same as prior period, unchanged from 0000858877-19-000018:mdna:3]

[0000858877-20-000004:mdna:4]
[same as prior period, unchanged from 0000858877-19-000018:mdna:4]

[0000858877-20-000004:mdna:5]
[same as prior period, unchanged from 0000858877-19-000018:mdna:5]

[0000858877-20-000004:mdna:6]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 25, 2020 |  | January 26, 2019 |  | % Variance |  | January 25, 2020 |  | January 26, 2019 |  | % Variance |  |
| Revenue (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | (4 | )% |  | $ | 25,164 |  |  | $ | 25,518 |  |  | (1 | )% |  |
| Gross margin percentage | 64.7 | % |  | 62.5 | % |  | 2.2 |  | pts | 64.5 | % |  | 62.4 | % |  | 2.1 |  | pts |
| Research and development | $ | 1,570 |  |  | $ | 1,557 |  |  | 1 | % |  | $ | 3,236 |  |  | $ | 3,165 |  |  | 2 | % |  |
| Sales and marketing | $ | 2,279 |  |  | $ | 2,271 |  |  | — | % |  | $ | 4,759 |  |  | $ | 4,681 |  |  | 2 | % |  |
| General and administrative | $ | 455 |  |  | $ | 509 |  |  | (11 | )% |  | $ | 974 |  |  | $ | 720 |  |  | 35 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,304 |  |  | $ | 4,337 |  |  | (1 | )% |  | $ | 8,969 |  |  | $ | 8,566 |  |  | 5 | % |  |
| Total as a percentage of revenue | 35.9 | % |  | 34.8 | % |  | 1.1 |  | pts | 35.6 | % |  | 33.6 | % |  | 2.0 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 38 |  |  | $ | 39 |  |  | (3 | )% |  | $ | 74 |  |  | $ | 73 |  |  | 1 | % |  |
| Restructuring and other charges included in operating expenses | $ | 42 |  |  | $ | 186 |  |  | (77 | )% |  | $ | 226 |  |  | $ | 264 |  |  | (14 | )% |  |
| Operating income as a percentage of revenue | 28.2 | % |  | 25.8 | % |  | 2.4 |  | pts | 27.7 | % |  | 27.5 | % |  | 0.2 |  | pts |
| Interest and other income (loss), net | $ | 154 |  |  | $ | 132 |  |  | 17 | % |  | $ | 261 |  |  | $ | 236 |  |  | 11 | % |  |
| Income tax percentage | 18.6 | % |  | 15.6 | % |  | 3.0 |  | pts | 19.6 | % |  | 12.1 | % |  | 7.5 |  | pts |
| Net income | $ | 2,878 |  |  | $ | 2,822 |  |  | 2 | % |  | $ | 5,804 |  |  | $ | 6,371 |  |  | (9 | )% |  |
| Net income as a percentage of revenue | 24.0 | % |  | 22.7 | % |  | 1.3 |  | pts | 23.1 | % |  | 25.0 | % |  | (1.9 | ) | pts |
| Earnings per share—diluted | $ | 0.68 |  |  | $ | 0.63 |  |  | 8 | % |  | $ | 1.36 |  |  | $ | 1.40 |  |  | (3 | )% |  |

[0000858877-20-000004:mdna:7]
(1) During the second quarter of fiscal 2019, we completed the sale of our Service Provider Video Software Solutions (“SPVSS”) business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.

[0000858877-20-000004:mdna:8]
[same as prior period, unchanged from 0000858877-19-000018:mdna:16]

[0000858877-20-000004:mdna:9]
[same as prior period, unchanged from 0000858877-19-000018:mdna:8]

[0000858877-20-000004:mdna:10]
[same as prior period, unchanged from 0000858877-19-000018:mdna:9]

[0000858877-20-000004:mdna:11]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:12]
In the second quarter of fiscal 2020, we delivered strong gross margin and growth in earnings per share. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue declined in Infrastructure Platforms and Applications, partially offset by growth in Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We continue to operate in a challenging macroeconomic and highly competitive environment. During the second quarter of fiscal 2020, we experienced continuing weakness in the service provider market and emerging countries, and we expect ongoing uncertainty in these markets. We also continued to see a more broad-based weakening in the global macroeconomic environment during the quarter which impacted our enterprise and commercial markets. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-20-000004:mdna:13]
Total revenue decreased by 4% compared with the second quarter of fiscal 2019. Within total revenue, product revenue decreased by 6% and service revenue increased by 5%. Total gross margin increased by 2.2 percentage points, driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.1 percentage points. Operating income as a percentage of revenue increased by 2.4 percentage points. Diluted earnings per share increased by 8%, driven by a 2% increase in net income and a decrease in diluted share count of 245 million shares.

[0000858877-20-000004:mdna:14]
In terms of our geographic segments, revenue from the Americas decreased $339 million, EMEA revenue decreased by $89 million and APJC revenue decreased by $13 million. The “BRICM” countries experienced a product revenue decline of 28% in the aggregate, driven by decreased product revenue in the emerging countries of Mexico, China, India and Brazil.

[0000858877-20-000004:mdna:15]
From a customer market standpoint, we experienced product revenue declines across all customer segments. During the second quarter of fiscal 2020, we saw a decline in business momentum in the enterprise and commercial markets, which we believe was significantly related to weakness in the global macroeconomic environment.

[0000858877-20-000004:mdna:16]
From a product category perspective, the product revenue decrease of 6% was driven by declines in revenue in Infrastructure Platforms and Applications each of 8%, and these declines were partially offset by a product revenue increase in Security of 9%.

[0000858877-20-000004:mdna:17]
[same as prior period, unchanged from 0000858877-19-000018:mdna:17]

[0000858877-20-000004:mdna:18]
[same as prior period, unchanged from 0000858877-19-000018:mdna:18]

[0000858877-20-000004:mdna:19]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:20]
Total revenue decreased 1%, with product revenue decreasing 3% and service revenue increasing 4%. Total gross margin increased by 2.1 percentage points due to productivity benefits and product mix, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 2.0 percentage points due to higher general and administrative expenses. General and administrative expenses increased due to the impact of the benefit from the $400 million litigation settlement with Arista Networks, Inc. (“Arista”) in the first quarter of fiscal 2019. Operating income as a percentage of revenue increased by 0.2 percentage points.

[0000858877-20-000004:mdna:21]
[same as prior period, unchanged from 0000858877-19-000018:mdna:19]

[0000858877-20-000004:mdna:22]
[same as prior period, unchanged from 0000858877-19-000018:mdna:20]

[0000858877-20-000004:mdna:23]
[same as prior period, unchanged from 0000858877-19-000018:mdna:21]

[0000858877-20-000004:mdna:24]
[same as prior period, unchanged from 0000858877-19-000018:mdna:22]

[0000858877-20-000004:mdna:25]
The following is a summary of our other key financial measures for the second quarter of fiscal 2020 (in millions):

[0000858877-20-000004:mdna:26]
|  |  | January 25, 2020 |  | July 27, 2019 |
| Cash and cash equivalents and investments |  | $ | 27,062 |  |  | $ | 33,413 |  |
| Deferred revenue |  | $ | 18,686 |  |  | $ | 18,467 |  |
| Inventories |  | $ | 1,353 |  |  | $ | 1,383 |  |

[0000858877-20-000004:mdna:27]
|  |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |
| Cash provided by operating activities |  | $ | 7,387 |  |  | $ | 7,560 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,638 |  |  | $ | 10,042 |  |
| Dividends |  | $ | 2,972 |  |  | $ | 2,970 |  |

[0000858877-20-000004:mdna:28]
[same as prior period, unchanged from 0000858877-19-000018:mdna:26]

[0000858877-20-000004:mdna:29]
[same as prior period, unchanged from 0000858877-19-000018:mdna:27]

[0000858877-20-000004:mdna:30]
[same as prior period, unchanged from 0000858877-19-000018:mdna:28]

[0000858877-20-000004:mdna:31]
[same as prior period, unchanged from 0000858877-19-000018:mdna:29]

[0000858877-20-000004:mdna:32]
[same as prior period, unchanged from 0000858877-19-000018:mdna:30]

[0000858877-20-000004:mdna:33]
[same as prior period, unchanged from 0000858877-19-000018:mdna:31]

[0000858877-20-000004:mdna:34]
[same as prior period, unchanged from 0000858877-19-000018:mdna:32]

[0000858877-20-000004:mdna:35]
[same as prior period, unchanged from 0000858877-19-000018:mdna:33]

[0000858877-20-000004:mdna:36]
[same as prior period, unchanged from 0000858877-19-000018:mdna:34]

[0000858877-20-000004:mdna:37]
[same as prior period, unchanged from 0000858877-19-000018:mdna:35]

[0000858877-20-000004:mdna:38]
[same as prior period, unchanged from 0000858877-19-000018:mdna:49]

[0000858877-20-000004:mdna:39]
[same as prior period, unchanged from 0000858877-19-000018:mdna:36]

[0000858877-20-000004:mdna:40]
[same as prior period, unchanged from 0000858877-19-000018:mdna:37]

[0000858877-20-000004:mdna:41]
[same as prior period, unchanged from 0000858877-19-000018:mdna:38]

[0000858877-20-000004:mdna:42]
[same as prior period, unchanged from 0000858877-19-000018:mdna:39]

[0000858877-20-000004:mdna:43]
|  |  | January 25, 2020 |  | July 27, 2019 |
| Allowance for doubtful accounts |  | $ | 112 |  |  | $ | 136 |  |
| Percentage of gross accounts receivable |  | 2.5 | % |  | 2.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 42 |  |  | $ | 46 |  |
| Percentage of gross lease receivables(1) |  | 1.8 | % |  | 1.8 | % |
| Allowance for credit loss—loan receivables |  | $ | 95 |  |  | $ | 71 |  |
| Percentage of gross loan receivables |  | 1.8 | % |  | 1.3 | % |

[0000858877-20-000004:mdna:44]
[same as prior period, unchanged from 0000858877-19-000018:mdna:41]

[0000858877-20-000004:mdna:45]
[same as prior period, unchanged from 0000858877-19-000018:mdna:42]

[0000858877-20-000004:mdna:46]
[same as prior period, unchanged from 0000858877-19-000018:mdna:43]

[0000858877-20-000004:mdna:47]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 25, 2020 and July 27, 2019 was $87 million and $84 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-20-000004:mdna:48]
[same as prior period, unchanged from 0000858877-19-000018:mdna:45]

[0000858877-20-000004:mdna:49]
[same as prior period, unchanged from 0000858877-19-000018:mdna:46]

[0000858877-20-000004:mdna:50]
[same as prior period, unchanged from 0000858877-19-000018:mdna:47]

[0000858877-20-000004:mdna:51]
Our provision for inventory was $30 million and $23 million for the first six months of fiscal 2020 and 2019, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $67 million and $48 million for the first six months of fiscal 2020 and 2019, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-20-000004:mdna:52]
47

[0000858877-20-000004:mdna:53]
[same as prior period, unchanged from 0000858877-19-000018:mdna:50]

[0000858877-20-000004:mdna:54]
[same as prior period, unchanged from 0000858877-19-000018:mdna:51]

[0000858877-20-000004:mdna:55]
Loss Contingencies and Product Warranties

[0000858877-20-000004:mdna:56]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-20-000004:mdna:57]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-20-000004:mdna:58]
[same as prior period, unchanged from 0000858877-19-000018:mdna:55]

[0000858877-20-000004:mdna:59]
[same as prior period, unchanged from 0000858877-19-000018:mdna:56]

[0000858877-20-000004:mdna:60]
[same as prior period, unchanged from 0000858877-19-000018:mdna:57]

[0000858877-20-000004:mdna:61]
[same as prior period, unchanged from 0000858877-19-000018:mdna:58]

[0000858877-20-000004:mdna:62]
[same as prior period, unchanged from 0000858877-19-000018:mdna:59]

[0000858877-20-000004:mdna:63]
[same as prior period, unchanged from 0000858877-19-000018:mdna:60]

[0000858877-20-000004:mdna:64]
[same as prior period, unchanged from 0000858877-19-000018:mdna:61]

[0000858877-20-000004:mdna:65]
[same as prior period, unchanged from 0000858877-19-000018:mdna:62]

[0000858877-20-000004:mdna:66]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2020 and 2019.

[0000858877-20-000004:mdna:67]
[same as prior period, unchanged from 0000858877-19-000018:mdna:64]

[0000858877-20-000004:mdna:68]
[same as prior period, unchanged from 0000858877-19-000018:mdna:65]

[0000858877-20-000004:mdna:69]
[same as prior period, unchanged from 0000858877-19-000018:mdna:66]

[0000858877-20-000004:mdna:70]
[same as prior period, unchanged from 0000858877-19-000018:mdna:67]

[0000858877-20-000004:mdna:71]
[same as prior period, unchanged from 0000858877-19-000018:mdna:68]

[0000858877-20-000004:mdna:72]
[same as prior period, unchanged from 0000858877-19-000018:mdna:69]

[0000858877-20-000004:mdna:73]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 18.6% and 15.6% in the second quarter of fiscal 2020 and 2019, respectively. Our effective tax rate was 19.6% and 12.1% in the first six months of fiscal 2020 and 2019, respectively.

[0000858877-20-000004:mdna:74]
[same as prior period, unchanged from 0000858877-19-000018:mdna:71]

[0000858877-20-000004:mdna:75]
[same as prior period, unchanged from 0000858877-19-000018:mdna:72]

[0000858877-20-000004:mdna:76]
[same as prior period, unchanged from 0000858877-19-000018:mdna:73]

[0000858877-20-000004:mdna:77]
[same as prior period, unchanged from 0000858877-19-000018:mdna:74]

[0000858877-20-000004:mdna:78]
[same as prior period, unchanged from 0000858877-19-000018:mdna:75]

[0000858877-20-000004:mdna:79]
[same as prior period, unchanged from 0000858877-19-000018:mdna:76]

[0000858877-20-000004:mdna:80]
[same as prior period, unchanged from 0000858877-19-000018:mdna:77]

[0000858877-20-000004:mdna:81]
[same as prior period, unchanged from 0000858877-19-000018:mdna:78]

[0000858877-20-000004:mdna:82]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,671 |  |  | $ | 9,273 |  |  | $ | (602 | ) |  | (6 | )% |  | $ | 18,549 |  |  | $ | 19,163 |  |  | $ | (614 | ) |  | (3 | )% |
| Percentage of revenue |  | 72.2 | % |  | 74.5 | % |  |  |  |  |  |  |  | 73.7 | % |  | 75.1 | % |  |  |  |  |  |
| Service |  | 3,334 |  |  | 3,173 |  |  | 161 |  |  | 5 | % |  | 6,615 |  |  | 6,355 |  |  | 260 |  |  | 4 | % |
| Percentage of revenue |  | 27.8 | % |  | 25.5 | % |  |  |  |  |  |  |  | 26.3 | % |  | 24.9 | % |  |  |  |  |  |
| Total |  | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | (441 | ) |  | (4 | )% |  | $ | 25,164 |  |  | $ | 25,518 |  |  | $ | (354 | ) |  | (1 | )% |

[0000858877-20-000004:mdna:83]
[same as prior period, unchanged from 0000858877-19-000018:mdna:81]

[0000858877-20-000004:mdna:84]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,013 |  |  | $ | 7,352 |  |  | $ | (339 | ) |  | (5 | )% |  | $ | 14,990 |  |  | $ | 15,103 |  |  | $ | (113 | ) |  | (1 | )% |
| Percentage of revenue |  | 58.4 | % |  | 59.1 | % |  |  |  |  |  | 59.6 | % |  | 59.2 | % |  |  |  |  |
| EMEA |  | 3,134 |  |  | 3,223 |  |  | (89 | ) |  | (3 | )% |  | 6,417 |  |  | 6,447 |  |  | (30 | ) |  | — | % |
| Percentage of revenue |  | 26.1 | % |  | 25.9 | % |  |  |  |  |  | 25.5 | % |  | 25.3 | % |  |  |  |  |
| APJC |  | 1,859 |  |  | 1,872 |  |  | (13 | ) |  | (1 | )% |  | 3,758 |  |  | 3,968 |  |  | (210 | ) |  | (5 | )% |
| Percentage of revenue |  | 15.5 | % |  | 15.0 | % |  |  |  |  |  | 14.9 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | (441 | ) |  | (4 | )% |  | $ | 25,164 |  |  | $ | 25,518 |  |  | $ | (354 | ) |  | (1 | )% |

[0000858877-20-000004:mdna:85]
[same as prior period, unchanged from 0000858877-19-000018:mdna:83]

[0000858877-20-000004:mdna:86]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:87]
Total revenue decreased by 4%. Product revenue decreased by 6% and service revenue increased by 5%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 28% product revenue decline, with decreases in Mexico, India, China and Brazil.

[0000858877-20-000004:mdna:88]
[same as prior period, unchanged from 0000858877-19-000018:mdna:86]

[0000858877-20-000004:mdna:89]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:90]
Total revenue decreased by 1%. Product revenue decreased by 3% and service revenue increased by 4%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 29% product revenue decline, with decreases primarily in Mexico, China, India and Brazil.

[0000858877-20-000004:mdna:91]
[same as prior period, unchanged from 0000858877-19-000018:mdna:87]

[0000858877-20-000004:mdna:92]
[same as prior period, unchanged from 0000858877-19-000018:mdna:88]

[0000858877-20-000004:mdna:93]
[same as prior period, unchanged from 0000858877-19-000018:mdna:89]

[0000858877-20-000004:mdna:94]
[same as prior period, unchanged from 0000858877-19-000018:mdna:90]

[0000858877-20-000004:mdna:95]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,935 |  |  | $ | 5,349 |  |  | $ | (414 | ) |  | (8 | )% |  | $ | 10,842 |  |  | $ | 11,060 |  |  | $ | (218 | ) |  | (2 | )% |
| Percentage of product revenue |  | 56.9 | % |  | 57.7 | % |  |  |  |  |  | 58.4 | % |  | 57.7 | % |  |  |  |  |  |  |
| EMEA |  | 2,393 |  |  | 2,512 |  |  | (119 | ) |  | (5 | )% |  | 4,951 |  |  | 5,039 |  |  | (88 | ) |  | (2 | )% |
| Percentage of product revenue |  | 27.6 | % |  | 27.1 | % |  |  |  |  |  | 26.7 | % |  | 26.3 | % |  |  |  |  |  |  |
| APJC |  | 1,343 |  |  | 1,413 |  |  | (70 | ) |  | (5 | )% |  | 2,757 |  |  | 3,064 |  |  | (307 | ) |  | (10 | )% |
| Percentage of product revenue |  | 15.5 | % |  | 15.2 | % |  |  |  |  |  | 14.9 | % |  | 16.0 | % |  |  |  |  |  |  |
| Total |  | $ | 8,671 |  |  | $ | 9,273 |  |  | $ | (602 | ) |  | (6 | )% |  | $ | 18,549 |  |  | $ | 19,163 |  |  | $ | (614 | ) |  | (3 | )% |

[0000858877-20-000004:mdna:96]
[same as prior period, unchanged from 0000858877-19-000018:mdna:92]

[0000858877-20-000004:mdna:97]
[same as prior period, unchanged from 0000858877-19-000018:mdna:94]

[0000858877-20-000004:mdna:98]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:99]
Product revenue in the Americas segment decreased by 8%. The product revenue decrease was across all of customer segments. From a country perspective, product revenue decreased by 6% in the United States, 12% in Canada, 42% in Mexico and 15% in Brazil.

[0000858877-20-000004:mdna:100]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:101]
The decrease in product revenue in the Americas segment was driven by declines in the service provider, commercial and enterprise markets. The decreases were partially offset by product revenue growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada, Mexico and Brazil by 1%, 9%, 42% and 11%, respectively.

[0000858877-20-000004:mdna:102]
[same as prior period, unchanged from 0000858877-19-000018:mdna:96]

[0000858877-20-000004:mdna:103]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:104]
Product revenue in the EMEA segment decreased by 5%, with declines in the service provider, enterprise and commercial markets partially offset by growth in the public sector market. Product revenue from emerging countries within EMEA increased by 3%, while product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 7%. From a country perspective, product revenue decreased in Germany, United Kingdom and France by 5%, 8% and 7%, respectively.

[0000858877-20-000004:mdna:105]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:106]
Product revenue in the EMEA segment decreased by 2%, with declines in the service provider, enterprise and commercial markets partially offset by growth in the public sector market. Product revenue from emerging countries within EMEA increased by 3% and product revenue for the remainder of the EMEA segment decreased by 3%. From a country perspective, product revenue declined 7% in the United Kingdom and 3% in France, partially offset by a product revenue increase of 1% in Germany.

[0000858877-20-000004:mdna:107]
[same as prior period, unchanged from 0000858877-19-000018:mdna:98]

[0000858877-20-000004:mdna:108]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:109]
Product revenue in the APJC segment decreased by 5%, driven by declines in the commercial, public sector and enterprise markets, partially offset by growth in the service provider market. From a country perspective, product revenue decreased in Australia, India and China by 9%, 30%, and 38%, respectively, partially offset by a product revenue increase of 31% in Japan.

[0000858877-20-000004:mdna:110]
[same as prior period, unchanged from 0000858877-19-000018:mdna:100]

[0000858877-20-000004:mdna:111]
[same as prior period, unchanged from 0000858877-19-000018:mdna:101]

[0000858877-20-000004:mdna:112]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:113]
Product revenue in the APJC segment decreased by 10%, with a decline across each of the customer markets in this geographic segment. From a country perspective, product revenue decreased in Australia, China and India by 12%, 35% and 34%, respectively, partially offset by a product revenue increase of 20% in Japan.

[0000858877-20-000004:mdna:114]
[same as prior period, unchanged from 0000858877-19-000018:mdna:102]

[0000858877-20-000004:mdna:115]
[same as prior period, unchanged from 0000858877-19-000018:mdna:103]

[0000858877-20-000004:mdna:116]
[same as prior period, unchanged from 0000858877-19-000018:mdna:104]

[0000858877-20-000004:mdna:117]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | (574 | ) |  | (8 | )% |  | $ | 14,067 |  |  | $ | 14,724 |  |  | $ | (657 | ) |  | (4 | )% |
| Applications |  | 1,349 |  |  | 1,465 |  |  | (116 | ) |  | (8 | )% |  | 2,847 |  |  | 2,884 |  |  | (37 | ) |  | (1 | )% |
| Security |  | 748 |  |  | 684 |  |  | 64 |  |  | 9 | % |  | 1,563 |  |  | 1,354 |  |  | 209 |  |  | 15 | % |
| Other Products |  | 46 |  |  | 22 |  |  | 24 |  |  | 110 | % |  | 72 |  |  | 200 |  |  | (128 | ) |  | (64 | )% |
| Total |  | $ | 8,671 |  |  | $ | 9,273 |  |  | $ | (602 | ) |  | (6 | )% |  | $ | 18,549 |  |  | $ | 19,163 |  |  | $ | (614 | ) |  | (3 | )% |

[0000858877-20-000004:mdna:118]
[same as prior period, unchanged from 0000858877-19-000018:mdna:106]

[0000858877-20-000004:mdna:119]
[same as prior period, unchanged from 0000858877-19-000018:mdna:108]

[0000858877-20-000004:mdna:120]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:121]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 8%, or $574 million. Switching revenue declined in both campus switching and data center switching, although we had revenue growth in our intent-based networking Catalyst 9000 Series and in our Nexus 9000 Series. We experienced a decrease in sales of routing products, driven by continued weakness in the service provider market. We experienced a revenue decline from wireless products, although we saw revenue growth in our Meraki and WiFi6 products. Revenue from data center declined driven by server products partially offset by strong growth of our HyperFlex products.

[0000858877-20-000004:mdna:122]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:123]
Revenue from the Infrastructure Platforms product category decreased 4%, or $657 million, with declines across the portfolio with the exception of data center. Switching revenue declined in both campus switching and data center switching, although we saw revenue growth in our intent-based networking Catalyst 9000 Series and Nexus 9000 Series. The decrease in routing was driven by continued weakness in the service provider market. We experienced a revenue decline from wireless products, although we saw revenue growth in Meraki and WiFi6 products. Revenue from data center increased driven by higher sales of our HyperFlex products.

[0000858877-20-000004:mdna:124]
[same as prior period, unchanged from 0000858877-19-000018:mdna:110]

[0000858877-20-000004:mdna:125]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:126]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category decreased by 8%, or $116 million, with a decline in Unified Communications partially offset by double digit growth in AppDynamics.

[0000858877-20-000004:mdna:127]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:128]
Revenue in our Applications product category decreased by 1%, or $37 million, with declines in Unified Communications partially offset by double digit growth in AppDynamics.

[0000858877-20-000004:mdna:129]
[same as prior period, unchanged from 0000858877-19-000018:mdna:116]

[0000858877-20-000004:mdna:130]
[same as prior period, unchanged from 0000858877-19-000018:mdna:117]

[0000858877-20-000004:mdna:131]
[same as prior period, unchanged from 0000858877-19-000018:mdna:112]

[0000858877-20-000004:mdna:132]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:133]
Revenue in our Security product category increased 9%, or $64 million, driven by strong sales of our identity and access, advanced threat security and unified threat management products.

[0000858877-20-000004:mdna:134]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:135]
Revenue in our Security product category increased by 15%, or $209 million, driven by higher sales of identity and access, advanced threat security, unified threat management and web security products.

[0000858877-20-000004:mdna:136]
[same as prior period, unchanged from 0000858877-19-000018:mdna:114]

[0000858877-20-000004:mdna:137]
The increase in revenue from our Other Products category for the second quarter of fiscal 2020 was primarily driven by an increase in revenue from our cloud and system management products. The decrease in revenue from our Other Products category for the first six months of fiscal 2020 was primarily driven by a decrease in revenue from the SPVSS business which we divested in the second quarter of fiscal 2019.

[0000858877-20-000004:mdna:138]
[same as prior period, unchanged from 0000858877-19-000018:mdna:118]

[0000858877-20-000004:mdna:139]
[same as prior period, unchanged from 0000858877-19-000018:mdna:119]

[0000858877-20-000004:mdna:140]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,078 |  |  | $ | 2,003 |  |  | $ | 75 |  |  | 4 | % |  | $ | 4,148 |  |  | $ | 4,043 |  |  | $ | 105 |  |  | 3 | % |
| Percentage of service revenue |  | 62.3 | % |  | 63.1 | % |  |  |  |  |  | 62.7 | % |  | 63.6 | % |  |  |  |  |  |  |
| EMEA |  | 741 |  |  | 711 |  |  | 30 |  |  | 4 | % |  | 1,466 |  |  | 1,408 |  |  | 58 |  |  | 4 | % |
| Percentage of service revenue |  | 22.2 | % |  | 22.4 | % |  |  |  |  |  | 22.2 | % |  | 22.2 | % |  |  |  |  |  |  |
| APJC |  | 515 |  |  | 459 |  |  | 56 |  |  | 12 | % |  | 1,001 |  |  | 904 |  |  | 97 |  |  | 11 | % |
| Percentage of service revenue |  | 15.5 | % |  | 14.5 | % |  |  |  |  |  | 15.1 | % |  | 14.2 | % |  |  |  |  |  |  |
| Total |  | $ | 3,334 |  |  | $ | 3,173 |  |  | $ | 161 |  |  | 5 | % |  | $ | 6,615 |  |  | $ | 6,355 |  |  | $ | 260 |  |  | 4 | % |

[0000858877-20-000004:mdna:141]
[same as prior period, unchanged from 0000858877-19-000018:mdna:121]

[0000858877-20-000004:mdna:142]
Service revenue increased 5% in the second quarter of fiscal 2020 and increased 4% in the first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019. The increases in both periods were driven by an increase in software and solution support offerings. Service revenue increased across all geographic segments.

[0000858877-20-000004:mdna:143]
[same as prior period, unchanged from 0000858877-19-000018:mdna:124]

[0000858877-20-000004:mdna:144]
[same as prior period, unchanged from 0000858877-19-000018:mdna:125]

[0000858877-20-000004:mdna:145]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,545 |  |  | $ | 5,659 |  |  | 63.9 | % |  | 61.0 | % |  | $ | 11,899 |  |  | $ | 11,750 |  |  | 64.1 | % |  | 61.3 | % |
| Service |  | 2,219 |  |  | 2,114 |  |  | 66.6 | % |  | 66.6 | % |  | 4,329 |  |  | 4,169 |  |  | 65.4 | % |  | 65.6 | % |
| Total |  | $ | 7,764 |  |  | $ | 7,773 |  |  | 64.7 | % |  | 62.5 | % |  | $ | 16,228 |  |  | $ | 15,919 |  |  | 64.5 | % |  | 62.4 | % |

[0000858877-20-000004:mdna:146]
53

[0000858877-20-000004:mdna:147]
[same as prior period, unchanged from 0000858877-19-000018:mdna:131]

[0000858877-20-000004:mdna:148]
[same as prior period, unchanged from 0000858877-19-000018:mdna:132]

[0000858877-20-000004:mdna:149]
[same as prior period, unchanged from 0000858877-19-000018:mdna:127]

[0000858877-20-000004:mdna:150]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2020, as compared with the corresponding prior year periods:

[0000858877-20-000004:mdna:151]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2019 |  | 61.0 | % |  | 61.3 | % |
| Productivity (1) |  | 3.4 | % |  | 2.6 | % |
| Product pricing |  | (1.1 | )% |  | (0.5 | )% |
| Mix of products sold |  | 0.8 | % |  | 0.7 | % |
| Impact from divestiture of SPVSS business |  | — | % |  | 0.2 | % |
| Others |  | (0.2 | )% |  | (0.2 | )% |
| Fiscal 2020 |  | 63.9 | % |  | 64.1 | % |

[0000858877-20-000004:mdna:152]
[same as prior period, unchanged from 0000858877-19-000018:mdna:130]

[0000858877-20-000004:mdna:153]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:154]
Product gross margin increased by 2.9 percentage points driven by productivity improvements and product mix, partially offset by unfavorable impacts from product pricing.

[0000858877-20-000004:mdna:155]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations. The negative pricing impact was driven by typical market factors and impacted each of our geographic segments. The favorable product mix was driven by impacts from each of our product categories.

[0000858877-20-000004:mdna:156]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:157]
Product gross margin increased by 2.8 percentage points driven by productivity improvements and product mix, partially offset by unfavorable impacts from product pricing. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-20-000004:mdna:158]
Productivity improvements were driven by cost reductions including value engineering efforts and continued operational efficiency in manufacturing operations.

[0000858877-20-000004:mdna:159]
[same as prior period, unchanged from 0000858877-19-000018:mdna:136]

[0000858877-20-000004:mdna:160]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:161]
Our service gross margin percentage was flat due to increased headcount-related and delivery costs offset by higher sales volume.

[0000858877-20-000004:mdna:162]
[same as prior period, unchanged from 0000858877-19-000018:mdna:139]

[0000858877-20-000004:mdna:163]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:164]
Service gross margin percentage decreased by 0.2 percentage points due to increased headcount-related and increased delivery costs. These costs impacts were partially offset by the resulting benefit to gross margin of higher sales volume.

[0000858877-20-000004:mdna:165]
[same as prior period, unchanged from 0000858877-19-000018:mdna:150]

[0000858877-20-000004:mdna:166]
[same as prior period, unchanged from 0000858877-19-000018:mdna:151]

[0000858877-20-000004:mdna:167]
[same as prior period, unchanged from 0000858877-19-000018:mdna:140]

[0000858877-20-000004:mdna:168]
[same as prior period, unchanged from 0000858877-19-000018:mdna:141]

[0000858877-20-000004:mdna:169]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,692 |  |  | $ | 4,796 |  |  | 66.9 | % |  | 65.2 | % |  | $ | 10,008 |  |  | $ | 9,866 |  |  | 66.8 | % |  | 65.3 | % |
| EMEA | 2,062 |  |  | 2,070 |  |  | 65.8 | % |  | 64.2 | % |  | 4,229 |  |  | 4,141 |  |  | 65.9 | % |  | 64.2 | % |
| APJC | 1,219 |  |  | 1,109 |  |  | 65.6 | % |  | 59.2 | % |  | 2,413 |  |  | 2,309 |  |  | 64.2 | % |  | 58.2 | % |
| Segment total | 7,974 |  |  | 7,975 |  |  | 66.4 | % |  | 64.1 | % |  | 16,650 |  |  | 16,316 |  |  | 66.2 | % |  | 63.9 | % |
| Unallocated corporate items (1) | (210 | ) |  | (202 | ) |  |  |  |  |  | (422 | ) |  | (397 | ) |  |  |  |  |
| Total | $ | 7,764 |  |  | $ | 7,773 |  |  | 64.7 | % |  | 62.5 | % |  | $ | 16,228 |  |  | $ | 15,919 |  |  | 64.5 | % |  | 62.4 | % |

[0000858877-20-000004:mdna:170]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-20-000004:mdna:171]
[same as prior period, unchanged from 0000858877-19-000018:mdna:144]

[0000858877-20-000004:mdna:172]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:173]
We experienced a gross margin percentage increase in our Americas segment due to favorable impacts from productivity improvements and product mix, partially offset by unfavorable impacts from pricing.

[0000858877-20-000004:mdna:174]
Gross margin in our EMEA segment increased due to productivity improvements and product mix, partially offset by negative impacts from pricing.

[0000858877-20-000004:mdna:175]
[same as prior period, unchanged from 0000858877-19-000018:mdna:148]

[0000858877-20-000004:mdna:176]
[same as prior period, unchanged from 0000858877-19-000018:mdna:149]

[0000858877-20-000004:mdna:177]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:178]
The Americas segment had a gross margin percentage increase driven by productivity improvements, and to a lesser extent, product mix, partially offset by unfavorable impacts from pricing.

[0000858877-20-000004:mdna:179]
The gross margin percentage increase in our EMEA segment was due to productivity improvements and product mix, partially offset by negative impacts from pricing.

[0000858877-20-000004:mdna:180]
The APJC segment gross margin percentage increase was driven by productivity improvements and product mix, partially offset by negative impacts from pricing.

[0000858877-20-000004:mdna:181]
[same as prior period, unchanged from 0000858877-19-000018:mdna:170]

[0000858877-20-000004:mdna:182]
[same as prior period, unchanged from 0000858877-19-000018:mdna:171]

[0000858877-20-000004:mdna:183]
[same as prior period, unchanged from 0000858877-19-000018:mdna:152]

[0000858877-20-000004:mdna:184]
[same as prior period, unchanged from 0000858877-19-000018:mdna:153]

[0000858877-20-000004:mdna:185]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 1,570 |  |  | $ | 1,557 |  |  | $ | 13 |  |  | 1 | % |  | $ | 3,236 |  |  | $ | 3,165 |  |  | $ | 71 |  |  | 2 | % |
| Percentage of revenue | 13.1 | % |  | 12.5 | % |  |  |  |  |  | 12.9 | % |  | 12.4 | % |  |  |  |  |
| Sales and marketing | 2,279 |  |  | 2,271 |  |  | 8 |  |  | — | % |  | 4,759 |  |  | 4,681 |  |  | 78 |  |  | 2 | % |
| Percentage of revenue | 19.0 | % |  | 18.2 | % |  |  |  |  |  | 18.9 | % |  | 18.3 | % |  |  |  |  |
| General and administrative | 455 |  |  | 509 |  |  | (54 | ) |  | (11 | )% |  | 974 |  |  | 720 |  |  | 254 |  |  | 35 | % |
| Percentage of revenue | 3.8 | % |  | 4.1 | % |  |  |  |  |  | 3.9 | % |  | 2.8 | % |  |  |  |  |
| Total | $ | 4,304 |  |  | $ | 4,337 |  |  | $ | (33 | ) |  | (1 | )% |  | $ | 8,969 |  |  | $ | 8,566 |  |  | $ | 403 |  |  | 5 | % |
| Percentage of revenue | 35.9 | % |  | 34.8 | % |  |  |  |  |  | 35.6 | % |  | 33.6 | % |  |  |  |  |

[0000858877-20-000004:mdna:186]
[same as prior period, unchanged from 0000858877-19-000018:mdna:156]

[0000858877-20-000004:mdna:187]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:188]
R&D expenses increased due to higher headcount-related expenses and higher share-based compensation expense. These increases were partially offset by lower contracted services and discretionary spending.

[0000858877-20-000004:mdna:189]
[same as prior period, unchanged from 0000858877-19-000018:mdna:158]

[0000858877-20-000004:mdna:190]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:191]
R&D expenses increased primarily due to higher headcount-related expenses and higher share-based compensation expense. These increases were partially offset by lower contracted services spending.

[0000858877-20-000004:mdna:192]
[same as prior period, unchanged from 0000858877-19-000018:mdna:159]

[0000858877-20-000004:mdna:193]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:194]
Sales and marketing expenses were flat due to higher headcount-related expenses, offset by lower contracted services spending, discretionary spending and, to a lesser extent, lower share-based compensation expense.

[0000858877-20-000004:mdna:195]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:196]
Sales and marketing expenses increased due to higher headcount-related expenses, partially offset by lower discretionary spending, lower contracted services and, to a lesser extent, lower share-based compensation expense.

[0000858877-20-000004:mdna:197]
[same as prior period, unchanged from 0000858877-19-000018:mdna:161]

[0000858877-20-000004:mdna:198]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:199]
G&A expenses decreased due to a gain recognized on the sale of property that had been held for sale, partially offset by higher discretionary spending.

[0000858877-20-000004:mdna:200]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:201]
G&A expenses increased due to the impact of the benefit from the $400 million litigation settlement with Arista from the first quarter of fiscal 2019 and higher discretionary spending, partially offset by lower contracted services spending, lower acquisition-related/divestiture costs and lower share-based compensation expense.

[0000858877-20-000004:mdna:202]
[same as prior period, unchanged from 0000858877-19-000018:mdna:163]

[0000858877-20-000004:mdna:203]
In the second quarter of fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $12 million, or 0.3%, compared with the second quarter of fiscal 2019.

[0000858877-20-000004:mdna:204]
In the first six months of fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $58 million, or 0.7%, compared with the first six months of fiscal 2019.

[0000858877-20-000004:mdna:205]
56

[0000858877-20-000004:mdna:206]
[same as prior period, unchanged from 0000858877-19-000018:mdna:185]

[0000858877-20-000004:mdna:207]
[same as prior period, unchanged from 0000858877-19-000018:mdna:186]

[0000858877-20-000004:mdna:208]
[same as prior period, unchanged from 0000858877-19-000018:mdna:165]

[0000858877-20-000004:mdna:209]
[same as prior period, unchanged from 0000858877-19-000018:mdna:166]

[0000858877-20-000004:mdna:210]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 165 |  |  | $ | 156 |  |  | $ | 331 |  |  | $ | 307 |  |
| Operating expenses |  | 38 |  |  | 39 |  |  | 74 |  |  | 73 |  |
| Total |  | $ | 203 |  |  | $ | 195 |  |  | $ | 405 |  |  | $ | 380 |  |

[0000858877-20-000004:mdna:211]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:212]
The increase in amortization of purchased intangible assets in the second quarter of fiscal 2020 was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-20-000004:mdna:213]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:214]
Amortization of purchased intangible assets increased due largely to the amortization of purchased intangibles from our recent acquisitions, partially offset by the purchased intangible assets related to the divestiture of SPVSS business in the second quarter of fiscal 2019.

[0000858877-20-000004:mdna:215]
[same as prior period, unchanged from 0000858877-19-000018:mdna:172]

[0000858877-20-000004:mdna:216]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $42 million and $226 million for the second quarter and first six months of fiscal 2020, respectively, and have incurred cumulative charges of $656 million since inception. We completed the Fiscal 2018 Plan in the second quarter of fiscal 2020.

[0000858877-20-000004:mdna:217]
We initiated a restructuring plan in the third quarter of fiscal 2020 in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. We expect the Fiscal 2020 Plan to be substantially completed in fiscal 2021.

[0000858877-20-000004:mdna:218]
These charges are primarily cash-based and consisted of employee severance and other one-time termination benefits, and other costs. We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas. As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-20-000004:mdna:219]
[same as prior period, unchanged from 0000858877-19-000018:mdna:175]

[0000858877-20-000004:mdna:220]
[same as prior period, unchanged from 0000858877-19-000018:mdna:176]

[0000858877-20-000004:mdna:221]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Operating income |  | $ | 3,380 |  |  | $ | 3,211 |  |  | $ | 6,959 |  |  | $ | 7,016 |  |
| Operating income as a percentage of revenue |  | 28.2 | % |  | 25.8 | % |  | 27.7 | % |  | 27.5 | % |

[0000858877-20-000004:mdna:222]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:223]
Operating income increased by 5%, and as a percentage of revenue operating income increased by 2.4 percentage points. These increases resulted primarily from: lower restructuring and other charges and a gross margin percentage increase (driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing).

[0000858877-20-000004:mdna:224]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:225]
Operating income decreased by 1%, and as a percentage of revenue operating income increased by 0.2 percentage points. These increases resulted primarily from: the impact of the benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019 and a revenue decrease, partially offset by a gross margin percentage increase (driven by productivity improvements).

[0000858877-20-000004:mdna:226]
57

[0000858877-20-000004:mdna:227]
[same as prior period, unchanged from 0000858877-19-000018:mdna:194]

[0000858877-20-000004:mdna:228]
[same as prior period, unchanged from 0000858877-19-000018:mdna:195]

[0000858877-20-000004:mdna:229]
[same as prior period, unchanged from 0000858877-19-000018:mdna:180]

[0000858877-20-000004:mdna:230]
[same as prior period, unchanged from 0000858877-19-000018:mdna:181]

[0000858877-20-000004:mdna:231]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |
| Interest income |  | $ | 242 |  |  | $ | 328 |  |  | $ | (86 | ) |  | $ | 515 |  |  | $ | 672 |  |  | $ | (157 | ) |
| Interest expense |  | (158 | ) |  | (223 | ) |  | 65 |  |  | (336 | ) |  | (444 | ) |  | 108 |  |
| Interest income (expense), net |  | $ | 84 |  |  | $ | 105 |  |  | $ | (21 | ) |  | $ | 179 |  |  | $ | 228 |  |  | $ | (49 | ) |

[0000858877-20-000004:mdna:232]
For each of the second quarter and first six months of fiscal 2020, interest income decreased driven by a decrease in the average balance of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-20-000004:mdna:233]
[same as prior period, unchanged from 0000858877-19-000018:mdna:187]

[0000858877-20-000004:mdna:234]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25, 2020 |  | January 26, 2019 |  | Variancein Dollars |  | January 25, 2020 |  | January 26, 2019 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 11 |  |  | $ | (5 | ) |  | $ | 16 |  |  | $ | 21 |  |  | $ | (11 | ) |  | $ | 32 |  |
| Marketable equity investments |  | — |  |  | 61 |  |  | (61 | ) |  | — |  |  | 57 |  |  | (57 | ) |
| Non-marketable equity and other investments |  | 81 |  |  | (3 | ) |  | 84 |  |  | 91 |  |  | 1 |  |  | 90 |  |
| Net gains (losses) on investments |  | 92 |  |  | 53 |  |  | 39 |  |  | 112 |  |  | 47 |  |  | 65 |  |
| Other gains (losses), net |  | (22 | ) |  | (26 | ) |  | 4 |  |  | (30 | ) |  | (39 | ) |  | 9 |  |
| Other income (loss), net |  | $ | 70 |  |  | $ | 27 |  |  | $ | 43 |  |  | $ | 82 |  |  | $ | 8 |  |  | $ | 74 |  |

[0000858877-20-000004:mdna:235]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:236]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net realized gains and higher unrealized gains, partially offset by higher impairment charges. The change in other gains (losses), net was driven by impacts from our equity derivatives.

[0000858877-20-000004:mdna:237]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:238]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized gains and higher unrealized gains, partially offset by higher impairment charges. The change in other gains (losses), net was driven by higher gains from customer lease terminations and impacts from our equity derivatives, partially offset by higher donation expense and unfavorable foreign exchange impacts.

[0000858877-20-000004:mdna:239]
[same as prior period, unchanged from 0000858877-19-000018:mdna:191]

[0000858877-20-000004:mdna:240]
Three Months Ended January 25, 2020 Compared with Three Months Ended January 26, 2019

[0000858877-20-000004:mdna:241]
The provision for income taxes resulted in an effective tax rate of 18.6% for the second quarter of fiscal 2020 compared with 15.6% for the second quarter of fiscal 2019. The increase in the effective tax rate was primarily due to a decrease in foreign income taxed at lower than U.S. rates (1.3 point increase) and a decrease in discrete net tax benefits in fiscal 2020 as compared to fiscal 2019 (1.7 point increase).

[0000858877-20-000004:mdna:242]
[same as prior period, unchanged from 0000858877-19-000018:mdna:223]

[0000858877-20-000004:mdna:243]
[same as prior period, unchanged from 0000858877-19-000018:mdna:208]

[0000858877-20-000004:mdna:244]
[same as prior period, unchanged from 0000858877-19-000018:mdna:209]

[0000858877-20-000004:mdna:245]
[same as prior period, unchanged from 0000858877-19-000018:mdna:193]

[0000858877-20-000004:mdna:246]
Six Months Ended January 25, 2020 Compared with Six Months Ended January 26, 2019

[0000858877-20-000004:mdna:247]
The provision for income taxes resulted in an effective tax rate of 19.6% for the first six months of fiscal 2020 compared with 12.1% for the first six months of fiscal 2019. The increase in the effective tax rate was primarily due to a decrease in foreign income taxed at lower than U.S. rates (1.5 point increase) and a decrease in discrete net tax benefits in the first six months of fiscal 2020 compared to the first six months of fiscal 2019 (5.8 point increase).

[0000858877-20-000004:mdna:248]
[same as prior period, unchanged from 0000858877-19-000018:mdna:235]

[0000858877-20-000004:mdna:249]
[same as prior period, unchanged from 0000858877-19-000018:mdna:224]

[0000858877-20-000004:mdna:250]
[same as prior period, unchanged from 0000858877-19-000018:mdna:225]

[0000858877-20-000004:mdna:251]
[same as prior period, unchanged from 0000858877-19-000018:mdna:196]

[0000858877-20-000004:mdna:252]
[same as prior period, unchanged from 0000858877-19-000018:mdna:197]

[0000858877-20-000004:mdna:253]
[same as prior period, unchanged from 0000858877-19-000018:mdna:198]

[0000858877-20-000004:mdna:254]
[same as prior period, unchanged from 0000858877-19-000018:mdna:199]

[0000858877-20-000004:mdna:255]
|  | January 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,475 |  |  | $ | 11,750 |  |  | $ | (3,275 | ) |
| Available-for-sale debt investments | 18,587 |  |  | 21,660 |  |  | (3,073 | ) |
| Marketable equity securities | — |  |  | 3 |  |  | (3 | ) |
| Total | $ | 27,062 |  |  | $ | 33,413 |  |  | $ | (6,351 | ) |

[0000858877-20-000004:mdna:256]
The decrease in cash and cash equivalents and investments in the first six months of fiscal 2020 was primarily driven by a net decrease in debt of $8.7 billion; cash dividends of $3.0 billion; cash returned to shareholders in the form of repurchases of common stock of $1.6 billion under the stock repurchase program; capital expenditures of $0.4 billion; and net cash paid for acquisitions and divestitures of $0.2 billion. These uses of cash were partially offset by cash provided by operating activities of $7.4 billion.

[0000858877-20-000004:mdna:257]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia for a purchase consideration of approximately $2.6 billion in cash. In addition, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Also, $1.5 billion of long-term debt outstanding at January 25, 2020 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-20-000004:mdna:258]
[same as prior period, unchanged from 0000858877-19-000018:mdna:203]

[0000858877-20-000004:mdna:259]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented.

[0000858877-20-000004:mdna:260]
[same as prior period, unchanged from 0000858877-19-000018:mdna:204]

[0000858877-20-000004:mdna:261]
[same as prior period, unchanged from 0000858877-19-000018:mdna:205]

[0000858877-20-000004:mdna:262]
|  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |
| Net cash provided by operating activities | $ | 7,387 |  |  | $ | 7,560 |  |
| Acquisition of property and equipment | (391 | ) |  | (473 | ) |
| Free cash flow | $ | 6,996 |  |  | $ | 7,087 |  |

[0000858877-20-000004:mdna:263]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-20-000004:mdna:264]
[same as prior period, unchanged from 0000858877-19-000018:mdna:236]

[0000858877-20-000004:mdna:265]
[same as prior period, unchanged from 0000858877-19-000018:mdna:237]

[0000858877-20-000004:mdna:266]
deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-20-000004:mdna:267]
[same as prior period, unchanged from 0000858877-19-000018:mdna:210]

[0000858877-20-000004:mdna:268]
[same as prior period, unchanged from 0000858877-19-000018:mdna:211]

[0000858877-20-000004:mdna:269]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0000858877-20-000004:mdna:270]
On February 12, 2020, our Board of Directors declared a quarterly dividend of $0.36 per common share to be paid on April 22, 2020 to all shareholders of record as of the close of business on April 3, 2020. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-20-000004:mdna:271]
The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $11.8 billion, with no termination date.

[0000858877-20-000004:mdna:272]
[same as prior period, unchanged from 0000858877-19-000018:mdna:215]

[0000858877-20-000004:mdna:273]
|  | January 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,330 |  |  | $ | 5,491 |  |  | $ | (1,161 | ) |

[0000858877-20-000004:mdna:274]
Our accounts receivable net, as of January 25, 2020 decreased by approximately 21%, as compared with the end of fiscal 2019, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2020 compared with the fourth quarter of fiscal 2019.

[0000858877-20-000004:mdna:275]
[same as prior period, unchanged from 0000858877-19-000018:mdna:218]

[0000858877-20-000004:mdna:276]
|  | January 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Inventories | $ | 1,353 |  |  | $ | 1,383 |  |  | $ | (30 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,482 |  |  | $ | 4,967 |  |  | $ | (485 | ) |

[0000858877-20-000004:mdna:277]
Inventory as of January 25, 2020 decreased by 2% from our inventory balance at the end of fiscal 2019. The decrease in inventory was primarily due to lower deferred cost of sales, partially offset by an increase in finished goods and raw materials. Purchase commitments with contract manufacturers and suppliers decreased 10% compared to the end of fiscal 2019. On a combined basis,

[0000858877-20-000004:mdna:278]
61

[0000858877-20-000004:mdna:279]
[same as prior period, unchanged from 0000858877-19-000018:mdna:244]

[0000858877-20-000004:mdna:280]
[same as prior period, unchanged from 0000858877-19-000018:mdna:245]

[0000858877-20-000004:mdna:281]
inventories and purchase commitments with contract manufacturers and suppliers decreased by 8% compared with the end of fiscal 2019. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-20-000004:mdna:282]
[same as prior period, unchanged from 0000858877-19-000018:mdna:221]

[0000858877-20-000004:mdna:283]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-20-000004:mdna:284]
[same as prior period, unchanged from 0000858877-19-000018:mdna:229]

[0000858877-20-000004:mdna:285]
[same as prior period, unchanged from 0000858877-19-000018:mdna:230]

[0000858877-20-000004:mdna:286]
|  | January 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,208 |  |  | $ | 2,326 |  |  | $ | (118 | ) |
| Loan receivables, net | 5,202 |  |  | 5,367 |  |  | (165 | ) |
| Financed service contracts, net | 2,174 |  |  | 2,360 |  |  | (186 | ) |
| Total, net | $ | 9,584 |  |  | $ | 10,053 |  |  | $ | (469 | ) |

[0000858877-20-000004:mdna:287]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 5%.

[0000858877-20-000004:mdna:288]
[same as prior period, unchanged from 0000858877-19-000018:mdna:233]

[0000858877-20-000004:mdna:289]
The volume of channel partner financing was $14.2 billion and $14.5 billion for the first six months of fiscal 2020 and 2019, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.4 billion as of January 25, 2020 and July 27, 2019, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 25, 2020, the total maximum potential future payments related to these guarantees was approximately $271 million, of which approximately $82 million was recorded as deferred revenue.

[0000858877-20-000004:mdna:290]
CISCO SYSTEMS, INC.

[0000858877-20-000004:mdna:291]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-20-000004:mdna:292]
[same as prior period, unchanged from 0000858877-19-000018:mdna:238]

[0000858877-20-000004:mdna:293]
[same as prior period, unchanged from 0000858877-19-000018:mdna:239]

[0000858877-20-000004:mdna:294]
|  | Maturity Date |  | January 25, 2020 |  | July 27, 2019 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | $ | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | — |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 16,000 |  |  | $ | 20,500 |  |

[0000858877-20-000004:mdna:295]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 25, 2020.

[0000858877-20-000004:mdna:296]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $4.2 billion in commercial paper notes outstanding as of July 27, 2019. We had no commercial paper outstanding as of January 25, 2020.

[0000858877-20-000004:mdna:297]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.  As of January 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-20-000004:mdna:298]
CISCO SYSTEMS, INC.

[0000858877-20-000004:mdna:299]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-20-000004:mdna:300]
[same as prior period, unchanged from 0000858877-19-000018:mdna:246]

[0000858877-20-000004:mdna:301]
|  | January 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Service | $ | 11,526 |  |  | $ | 11,709 |  |  | $ | (183 | ) |
| Product | 7,160 |  |  | 6,758 |  |  | 402 |  |
| Total | $ | 18,686 |  |  | $ | 18,467 |  |  | $ | 219 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,638 |  |  | $ | 10,668 |  |  | $ | (30 | ) |
| Noncurrent | 8,048 |  |  | 7,799 |  |  | 249 |  |
| Total | $ | 18,686 |  |  | $ | 18,467 |  |  | $ | 219 |  |

[0000858877-20-000004:mdna:302]
[same as prior period, unchanged from 0000858877-19-000018:mdna:248]

[0000858877-20-000004:mdna:303]
[same as prior period, unchanged from 0000858877-19-000018:mdna:249]

[0000858877-20-000004:mdna:304]
[same as prior period, unchanged from 0000858877-19-000018:mdna:250]

[0000858877-20-000004:mdna:305]
The income tax payable outstanding as of January 25, 2020 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $7.6 billion. Approximately $0.7 billion is payable in less than one year; $1.4 billion is payable between 1 to 3 years; $3.2 billion is payable between 3 to 5 years; and the remaining $2.3 billion is payable in more than 5 years.

[0000858877-20-000004:mdna:306]
For our Contractual Obligations see our Annual Report on Form 10-K for the year ended July 27, 2019.

[0000858877-20-000004:mdna:307]
[same as prior period, unchanged from 0000858877-19-000018:mdna:253]

[0000858877-20-000004:mdna:308]
[same as prior period, unchanged from 0000858877-19-000018:mdna:254]

[0000858877-20-000004:mdna:309]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $291 million as of January 25, 2020, compared with $326 million as of July 27, 2019.

[0000858877-20-000004:mdna:310]
[same as prior period, unchanged from 0000858877-19-000018:mdna:256]

[0000858877-20-000004:mdna:311]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of January 25, 2020 there were no material unconsolidated variable interest entities.

[0000858877-20-000004:mdna:312]
[same as prior period, unchanged from 0000858877-19-000018:mdna:258]

[0000858877-20-000004:mdna:313]
[same as prior period, unchanged from 0000858877-19-000018:mdna:259]

[0000858877-20-000004:mdna:314]
[same as prior period, unchanged from 0000858877-19-000018:mdna:260]

[0000858877-20-000004:mdna:315]
[same as prior period, unchanged from 0000858877-19-000018:mdna:261]

[0000858877-20-000004:mdna:316]
64
