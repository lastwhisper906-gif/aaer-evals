# CSCO MD&A — 0000858877-19-000012


## mdna

[0000858877-19-000012:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-19-000012:mdna:2]
Forward-Looking Statements

[0000858877-19-000012:mdna:3]
OVERVIEW

[0000858877-19-000012:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration, applications and the cloud, we are integrating intent-based technologies to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-19-000012:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-19-000012:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 27, 2019 |  | July 28, 2018 |  | Variance |  | July 27, 2019 |  | July 28, 2018 |  | Variance |  |
| Revenue (1) | $ | 13,428 |  |  | $ | 12,844 |  |  | 5 | % |  | $ | 51,904 |  |  | $ | 49,330 |  |  | 5 | % |  |
| Gross margin percentage | 63.9 | % |  | 61.7 | % |  | 2.2 |  | pts | 62.9 | % |  | 62.0 | % |  | 0.9 |  | pts |
| Research and development | $ | 1,753 |  |  | $ | 1,626 |  |  | 8 | % |  | $ | 6,577 |  |  | $ | 6,332 |  |  | 4 | % |  |
| Sales and marketing | $ | 2,487 |  |  | $ | 2,348 |  |  | 6 | % |  | $ | 9,571 |  |  | $ | 9,242 |  |  | 4 | % |  |
| General and administrative | $ | 566 |  |  | $ | 543 |  |  | 4 | % |  | $ | 1,827 |  |  | $ | 2,144 |  |  | (15 | )% |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,806 |  |  | $ | 4,517 |  |  | 6 | % |  | $ | 17,975 |  |  | $ | 17,718 |  |  | 1 | % |  |
| Total as a percentage of revenue | 35.8 | % |  | 35.2 | % |  | 0.6 |  | pts | 34.6 | % |  | 35.9 | % |  | (1.3 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 38 |  |  | $ | 33 |  |  | 15 | % |  | $ | 150 |  |  | $ | 221 |  |  | (32 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 40 |  |  | $ | 26 |  |  | 54 | % |  | $ | 322 |  |  | $ | 358 |  |  | (10 | )% |  |
| Operating income as a percentage of revenue | 27.5 | % |  | 26.1 | % |  | 1.4 |  | pts | 27.4 | % |  | 25.0 | % |  | 2.4 |  | pts |
| Interest and other income (loss), net | $ | 14 |  |  | $ | 246 |  |  | (94 | )% |  | $ | 352 |  |  | $ | 730 |  |  | (52 | )% |  |
| Income tax percentage (2) | 40.4 | % |  | (5.9 | )% |  | 46.3 |  | pts | 20.2 | % |  | 99.2 | % |  | NM |  |  |
| Net income (2) | $ | 2,206 |  |  | $ | 3,803 |  |  | (42 | )% |  | $ | 11,621 |  |  | $ | 110 |  |  | NM |  |  |
| Net income as a percentage of revenue | 16.4 | % |  | 29.6 | % |  | (13.2 | ) | pts | 22.4 | % |  | 0.2 | % |  | NM |  |  |
| Earnings per share—diluted (2) | $ | 0.51 |  |  | $ | 0.81 |  |  | (37 | )% |  | $ | 2.61 |  |  | $ | 0.02 |  |  | NM |  |  |

[0000858877-19-000012:mdna:7]
We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective method. See Note 2 to the Consolidated Financial Statements for impact of this adoption on our operating results in fiscal 2019.

[0000858877-19-000012:mdna:8]
(1) During the second quarter of fiscal 2019, we completed the sale of our SPVSS business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $0 and $206 million for the fourth quarter of fiscal 2019 and 2018, respectively, and $168 million and $903 million for fiscal 2019 and 2018, respectively.

[0000858877-19-000012:mdna:9]
(2) Includes a $0.9 billion charge and a $0.9 billion benefit for the fourth quarter of fiscal 2019 and 2018, respectively, and charges of $0.9 billion and $10.4 billion for fiscal 2019 and 2018, respectively, related to the Tax Act.

[0000858877-19-000012:mdna:10]
NM - Not meaningful

[0000858877-19-000012:mdna:11]
Fiscal 2019 Compared with Fiscal 2018

[0000858877-19-000012:mdna:12]
In fiscal 2019, we had strong performance across the business and delivered growth in revenue, margins, net income, earnings per share and operating cash flow. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. Notwithstanding the fiscal 2019 results, we continue to operate in a challenging and highly competitive environment. We expect ongoing uncertainty in the service provider customer market. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-19-000012:mdna:13]
Total revenue increased by 5% compared with fiscal 2018. Within total revenue, product revenue increased 6% and service revenue increased by 2%. In the second quarter of fiscal 2019, on October 28, 2018, we completed the sale of our SPVSS business. Total revenue for fiscal 2019 increased 7% not including revenue from the SPVSS business for fiscal 2019 and fiscal 2018. Total gross margin increased by 0.9 percentage points, driven primarily by productivity benefits partially offset by unfavorable impacts from pricing and mix.  Our gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019 and the $127 million legal and indemnification settlement charge recorded in fiscal 2018. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.3 percentage points. Operating income as a percentage of revenue increased by 2.4 percentage points. Net income and diluted earnings per share for fiscal 2018 included the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding taxes, and re-measurement of net deferred tax assets and liabilities as related to the Tax Act.

[0000858877-19-000012:mdna:14]
In terms of our geographic segments, revenue from the Americas increased by $1.9 billion, driven in large part by product revenue growth in the United States. EMEA revenue increased by $0.7 billion and revenue in our APJC segment increased slightly. The “BRICM” countries experienced a product revenue decline of 1% in the aggregate, driven by a 16% decrease in product revenue in China. This decrease was partially offset by increased product revenue in Mexico, Russia and India of 26%, 6%, and 5%, respectively.

[0000858877-19-000012:mdna:15]
From a customer market standpoint, we experienced product revenue growth in the enterprise, public sector and commercial markets, partially offset by a product revenue decline in the service provider market.

[0000858877-19-000012:mdna:16]
From a product category perspective, total product revenue, not including SPVSS products in the prior year, increased 8% year over year. The increase was driven by growth in Security and Applications of 16% and 15%, respectively.  We also experienced a 7% product revenue increase in Infrastructure Platforms.

[0000858877-19-000012:mdna:17]
Fourth Quarter Snapshot

[0000858877-19-000012:mdna:18]
For the fourth quarter of fiscal 2019, as compared with the fourth quarter of fiscal 2018, total revenue increased by 5%. Within total revenue, product revenue increased by 5% and service revenue increased by 3%.  With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas and EMEA increased by 8% and 4%, respectively, while revenue in APJC decreased by 5%. From a product category perspective, we experienced broad strength across the portfolio. We experienced weakness in the service provider market due to ongoing uncertainty in that market. Total gross margin increased by 2.2 percentage points, driven by improved productivity benefits and favorable product mix partially offset by unfavorable pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.6 percentage points. Operating income as a percentage of revenue increased by 1.4 percentage points. Diluted earnings per share decreased by 37% and net income decreased by 42%, due to a $0.9 billion tax charge and $0.9 billion tax benefit for the fourth quarter of fiscal 2019 and 2018, respectively, related to the Tax Act.

[0000858877-19-000012:mdna:19]
Strategy and Priorities

[0000858877-19-000012:mdna:20]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network continues to be extremely critical. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers. Our strategic priorities include the following: accelerating our pace of innovation, increasing the value of the network, and transforming our business model.

[0000858877-19-000012:mdna:21]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-19-000012:mdna:22]
Other Key Financial Measures

[0000858877-19-000012:mdna:23]
The following is a summary of our other key financial measures for fiscal 2019 compared with fiscal 2018 (in millions):

[0000858877-19-000012:mdna:24]
|  |  | Fiscal 2019 |  | Fiscal 2018 |
| Cash and cash equivalents and investments |  | $33,413 |  | $46,548 |
| Cash provided by operating activities |  | $15,831 |  | $13,666 |
| Deferred revenue (1) |  | $18,467 |  | $19,685 |
| Repurchases of common stock—stock repurchase program |  | $20,577 |  | $17,661 |
| Dividends |  | $5,979 |  | $5,968 |
| Inventories |  | $1,383 |  | $1,846 |

[0000858877-19-000012:mdna:25]
(1)  Deferred revenue decreased primarily due to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019. See Note 2 to the Consolidated Financial Statements for the impact of this adoption.

[0000858877-19-000012:mdna:26]
33

[0000858877-19-000012:mdna:27]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-19-000012:mdna:28]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-19-000012:mdna:29]
Revenue Recognition

[0000858877-19-000012:mdna:30]
In May 2014, the Financial Accounting Standards Board (FASB) issued ASC 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services.

[0000858877-19-000012:mdna:31]
ASC 606 allowed two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). At the beginning of our first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018.

[0000858877-19-000012:mdna:32]
ASC 606 primarily impacted our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

[0000858877-19-000012:mdna:33]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-19-000012:mdna:34]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-19-000012:mdna:35]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-19-000012:mdna:36]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, potential penalties and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-19-000012:mdna:37]
See Notes 2 and 3 to the Consolidated Financial Statements for more details.

[0000858877-19-000012:mdna:38]
Allowances for Receivables and Sales Returns

[0000858877-19-000012:mdna:39]
The allowances for receivables were as follows (in millions, except percentages):

[0000858877-19-000012:mdna:40]
|  |  | July 27, 2019 |  |  | July 28, 2018 |  |
| Allowance for doubtful accounts |  | $ | 136 |  |  | $ | 129 |  |
| Percentage of gross accounts receivable |  | 2.4 | % |  | 2.3 | % |
| Allowance for credit loss—lease receivables |  | $ | 46 |  |  | $ | 135 |  |
| Percentage of gross lease receivables (1) |  | 1.8 | % |  | 4.7 | % |
| Allowance for credit loss—loan receivables |  | $ | 71 |  |  | $ | 60 |  |
| Percentage of gross loan receivables |  | 1.3 | % |  | 1.2 | % |

[0000858877-19-000012:mdna:41]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables and residual value before unearned income.

[0000858877-19-000012:mdna:42]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay as well as historical and expected default frequency rates, which are published by major third-party credit-rating agencies and are updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-19-000012:mdna:43]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay. When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation. Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results. Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-19-000012:mdna:44]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of July 27, 2019 and July 28, 2018 was $84 million and $123 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-19-000012:mdna:45]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-19-000012:mdna:46]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-19-000012:mdna:47]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-19-000012:mdna:48]
Our provision for inventory was $77 million, $63 million, and $74 million in fiscal 2019, 2018, and 2017, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $95 million, $105 million, and $124 million in fiscal 2019, 2018, and 2017, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-19-000012:mdna:49]
Loss Contingencies and Product Warranties

[0000858877-19-000012:mdna:50]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-19-000012:mdna:51]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-19-000012:mdna:52]
Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-19-000012:mdna:53]
If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-19-000012:mdna:54]
Impairment of Investments

[0000858877-19-000012:mdna:55]
We recognize an impairment charge when the declines in the fair values of our available-for-sale debt investments below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-19-000012:mdna:56]
If the fair value of a debt security is less than its amortized cost, we assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of its entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost of the security. If an impairment is considered other than temporary based on (i) or (ii) described in the prior sentence, the entire difference between the amortized cost and the fair value of the security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit loss, defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security, will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI). In estimating the amount and timing of cash flows expected to be collected, we consider all available information, including past events, current conditions, the remaining payment terms of the security, the financial condition of the issuer, expected defaults, and the value of underlying collateral.

[0000858877-19-000012:mdna:57]
We hold non-marketable equity and other investments, some of which are in startup or development stage companies. As of July 27, 2019, our non-marketable equity and other investments were $1.2 billion, compared with $1.1 billion as of July 28, 2018, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-19-000012:mdna:58]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-19-000012:mdna:59]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-19-000012:mdna:60]
The goodwill recorded in the Consolidated Balance Sheets as of July 27, 2019 and July 28, 2018 was $33.5 billion and $31.7 billion, respectively. The increase in goodwill during fiscal 2019 was due in large part to our acquisition of Duo Security, Inc. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2019, 2018, and 2017. For the annual impairment testing in fiscal 2019, the excess of the fair value over the carrying value for each of our reporting units was $69.2 billion for the Americas, $56.3 billion for EMEA, and $32.2 billion for APJC.

[0000858877-19-000012:mdna:61]
During the fourth quarter of fiscal 2019, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-19-000012:mdna:62]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-19-000012:mdna:63]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Impairment charges related to purchased intangible assets was approximately $47 million for fiscal 2017. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-19-000012:mdna:64]
Income Taxes

[0000858877-19-000012:mdna:65]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 20.2%, 99.2%, and 21.8% in fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:mdna:66]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. As a result of the Tax Act enactment, we recorded a provisional tax expense of $10.4 billion in fiscal 2018. The provisional tax expense included an $863 million benefit associated with the U.S. taxation of deemed foreign dividends in the transition fiscal year. As previously disclosed, the benefit could be subject to reduction or elimination by subsequent government action. In the fourth quarter of fiscal 2019 we recorded an $872 million charge, which was the reversal of the previously recorded benefit associated with the U.S. taxation of deemed foreign dividends recorded in fiscal 2018, as a result of a retroactive final U.S. Treasury regulation issued during the quarter. The total tax charge as a result of the Tax Act was $11.3 billion, consisting of $9 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax, and $1.1 billion of tax expense for DTA re-measurement.

[0000858877-19-000012:mdna:67]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-19-000012:mdna:68]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred

[0000858877-19-000012:mdna:69]
tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-19-000012:mdna:70]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction, foreign-derived intangible income deduction, global intangible low-tax income, and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 36 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-19-000012:mdna:71]
38

[0000858877-19-000012:mdna:72]
RESULTS OF OPERATIONS

[0000858877-19-000012:mdna:73]
A discussion regarding our financial condition and results of operations for fiscal 2019 compared to fiscal 2018 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2018 compared to fiscal 2017 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018, filed with the SEC on September 6, 2018, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.cisco.com.

[0000858877-19-000012:mdna:74]
Revenue

[0000858877-19-000012:mdna:75]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-19-000012:mdna:76]
|  |  | Years Ended |  | 2019 vs. 2018 |
|  |  | July 27, 2019 (1) |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 2,296 |  |  | 6 | % |
| Percentage of revenue |  | 75.1 | % |  | 74.4 | % |  | 74.4 | % |  |  |  |  |  |  |
| Service |  | 12,899 |  |  | 12,621 |  |  | 12,300 |  |  | 278 |  |  | 2 | % |
| Percentage of revenue |  | 24.9 | % |  | 25.6 | % |  | 25.6 | % |  |  |  |  |  |  |
| Total |  | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 2,574 |  |  | 5 | % |

[0000858877-19-000012:mdna:77]
(1) Total revenue, product revenue and service revenue not including the SPVSS business in the prior year increased 7%, 8% and 3%, respectively.

[0000858877-19-000012:mdna:78]
We manage our business on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-19-000012:mdna:79]
|  |  | Years Ended |  | 2019 vs. 2018 |
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 30,927 |  |  | $ | 29,070 |  |  | $ | 28,351 |  |  | $ | 1,857 |  |  | 6 | % |
| Percentage of revenue |  | 59.6 | % |  | 58.9 | % |  | 59.1 | % |  |  |  |  |
| EMEA |  | 13,100 |  |  | 12,425 |  |  | 12,004 |  |  | 675 |  |  | 5 | % |
| Percentage of revenue |  | 25.2 | % |  | 25.2 | % |  | 25.0 | % |  |  |  |  |
| APJC |  | 7,877 |  |  | 7,834 |  |  | 7,650 |  |  | 43 |  |  | 1 | % |
| Percentage of revenue |  | 15.2 | % |  | 15.9 | % |  | 15.9 | % |  |  |  |  |
| Total |  | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 2,574 |  |  | 5 | % |

[0000858877-19-000012:mdna:80]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:mdna:81]
Total revenue in fiscal 2019 increased by 5% compared with fiscal 2018. Product revenue increased by 6% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the BRICM countries, in the aggregate, experienced 1% product revenue decline, driven by a 16% decrease in product revenue in China and a decrease of 1% in Brazil.  These decreases were partially offset by increased product revenue in Mexico, Russia and India of 26%, 6% and 5%, respectively.

[0000858877-19-000012:mdna:82]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-19-000012:mdna:83]
Product Revenue by Segment

[0000858877-19-000012:mdna:84]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-19-000012:mdna:85]
|  |  | Years Ended |  | 2019 vs. 2018 |
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,754 |  |  | $ | 21,088 |  |  | $ | 20,487 |  |  | $ | 1,666 |  |  | 8 | % |
| Percentage of product revenue |  | 58.3 | % |  | 57.5 | % |  | 57.4 | % |  |  |  |  |
| EMEA |  | 10,246 |  |  | 9,671 |  |  | 9,369 |  |  | 575 |  |  | 6 | % |
| Percentage of product revenue |  | 26.3 | % |  | 26.3 | % |  | 26.2 | % |  |  |  |  |
| APJC |  | 6,005 |  |  | 5,950 |  |  | 5,849 |  |  | 55 |  |  | 1 | % |
| Percentage of product revenue |  | 15.4 | % |  | 16.2 | % |  | 16.4 | % |  |  |  |  |
| Total |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 2,296 |  |  | 6 | % |

[0000858877-19-000012:mdna:86]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:mdna:87]
Americas

[0000858877-19-000012:mdna:88]
Product revenue in the Americas segment increased by 8%, driven by growth in the enterprise, public sector and commercial markets. These increases were partially offset by a product revenue decline in the service provider market. From a country perspective, product revenue increased by 9% in the United States, 26% in Mexico and 6% in Canada, partially offset by a product revenue decrease of 1% in Brazil.

[0000858877-19-000012:mdna:89]
EMEA

[0000858877-19-000012:mdna:90]
The increase in product revenue in the EMEA segment of 6% was driven by growth in the public sector and enterprise markets, partially offset by a decline in the service provider market. Product revenue in the commercial market was flat. Product revenue from emerging countries within EMEA increased by 9%, and product revenue for the remainder of the EMEA segment increased by 5%.

[0000858877-19-000012:mdna:91]
APJC

[0000858877-19-000012:mdna:92]
Product revenue in the APJC segment increased by 1%, driven by growth in the public sector and enterprise markets, partially offset by declines in the service provider and commercial markets. From a country perspective, product revenue increased by 9% in Japan and 5% in India, partially offset by a product revenue decrease of 16% in China.

[0000858877-19-000012:mdna:93]
Product Revenue by Groups of Similar Products

[0000858877-19-000012:mdna:94]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-19-000012:mdna:95]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-19-000012:mdna:96]
|  |  | Years Ended |  | 2019 vs. 2018 |
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 30,191 |  |  | $ | 28,322 |  |  | $ | 27,817 |  |  | $ | 1,869 |  |  | 7 | % |
| Applications |  | 5,803 |  |  | 5,036 |  |  | 4,568 |  |  | 767 |  |  | 15 | % |
| Security |  | 2,730 |  |  | 2,352 |  |  | 2,152 |  |  | 378 |  |  | 16 | % |
| Other Products |  | 281 |  |  | 999 |  |  | 1,168 |  |  | (718 | ) |  | (72 | )% |
| Total |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 2,296 |  |  | 6 | % |

[0000858877-19-000012:mdna:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:mdna:98]
40

[0000858877-19-000012:mdna:99]
Infrastructure Platforms

[0000858877-19-000012:mdna:100]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 7%, or $1,869 million, with growth across the portfolio. Switching had solid growth, with strong revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series, and with growth in data center switching driven by increased revenue from our ACI portfolio. Routing experienced modest revenue growth driven by an increase in sales of SD-WAN products, partially offset by weakness in the service provider market. We experienced double digit revenue growth from wireless products driven by increases across the portfolio. Revenue from data center increased driven by higher sales of HyperFlex and our server products.

[0000858877-19-000012:mdna:101]
Applications

[0000858877-19-000012:mdna:102]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as IoT and AppDynamics analytics software offerings.  Revenue in our Applications product category increased by 15%, or $767 million, with double digit growth in unified communications, TelePresence, AppDynamics, and IoT software.

[0000858877-19-000012:mdna:103]
Security

[0000858877-19-000012:mdna:104]
Revenue in our Security product category increased 16%, or $378 million, driven by higher sales of identity and access, advanced threat security, unified threat management and web security products. The Duo acquisition in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000012:mdna:105]
Other Products

[0000858877-19-000012:mdna:106]
The decrease in revenue from our Other Products category was primarily driven by a decrease in revenue from SPVSS business which we divested on October 28, 2018.

[0000858877-19-000012:mdna:107]
Service Revenue by Segment

[0000858877-19-000012:mdna:108]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-19-000012:mdna:109]
|  | Years Ended |  | 2019 vs. 2018 |
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,173 |  |  | $ | 7,982 |  |  | $ | 7,864 |  |  | $ | 191 |  |  | 2 | % |
| Percentage of service revenue | 63.4 | % |  | 63.3 | % |  | 63.9 | % |  |  |  |  |
| EMEA | 2,854 |  |  | 2,754 |  |  | 2,635 |  |  | 100 |  |  | 4 | % |
| Percentage of service revenue | 22.1 | % |  | 21.8 | % |  | 21.4 | % |  |  |  |  |
| APJC | 1,872 |  |  | 1,885 |  |  | 1,801 |  |  | (13 | ) |  | (1 | )% |
| Percentage of service revenue | 14.5 | % |  | 14.9 | % |  | 14.7 | % |  |  |  |  |
| Total | $ | 12,899 |  |  | $ | 12,621 |  |  | $ | 12,300 |  |  | $ | 278 |  |  | 2 | % |

[0000858877-19-000012:mdna:110]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:mdna:111]
Service revenue increased 2%, driven by an increase in software and solution support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by decreased revenue in our APJC segment.

[0000858877-19-000012:mdna:112]
Gross Margin

[0000858877-19-000012:mdna:113]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-19-000012:mdna:114]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 24,142 |  |  | $ | 22,282 |  |  | $ | 22,006 |  |  | 61.9 | % |  | 60.7 | % |  | 61.6 | % |
| Service | 8,524 |  |  | 8,324 |  |  | 8,218 |  |  | 66.1 | % |  | 66.0 | % |  | 66.8 | % |
| Total | $ | 32,666 |  |  | $ | 30,606 |  |  | $ | 30,224 |  |  | 62.9 | % |  | 62.0 | % |  | 63.0 | % |

[0000858877-19-000012:mdna:115]
Product Gross Margin

[0000858877-19-000012:mdna:116]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2018 to fiscal 2019:

[0000858877-19-000012:mdna:117]
|  |  | Product Gross Margin Percentage |
| Fiscal 2018 |  | 60.7 | % |
| Productivity (1) |  | 1.6 | % |
| Product pricing |  | (0.7 | )% |
| Mix of products sold |  | (0.4 | )% |
| Impact from divestiture of SPVSS business |  | 0.5 | % |
| Legal and indemnification settlements |  | 0.3 | % |
| Others |  | (0.1 | )% |
| Fiscal 2019 |  | 61.9 | % |

[0000858877-19-000012:mdna:118]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-19-000012:mdna:119]
Product gross margin increased by 1.2 percentage points driven by productivity improvements, partially offset by unfavorable impacts from product pricing and product mix. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000012:mdna:120]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations. The negative pricing impact, which was lower than the year-over-year impact we experienced in fiscal 2018, was driven by typical market factors and impacted each of our geographic segments and customer markets. The unfavorable product mix impact was driven by our products within the Infrastructure Platforms product category. Our product gross margin also benefited from the $127 million charge to product cost of sales recorded in fiscal 2018 related to legal and indemnification settlements.

[0000858877-19-000012:mdna:121]
Service Gross Margin

[0000858877-19-000012:mdna:122]
Our service gross margin percentage increased by 0.1 percentage point due to higher sales volume, partially offset by increased headcount-related and delivery costs.

[0000858877-19-000012:mdna:123]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-19-000012:mdna:124]
Gross Margin by Segment

[0000858877-19-000012:mdna:125]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-19-000012:mdna:126]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 20,338 |  |  | $ | 18,792 |  |  | $ | 18,284 |  |  | 65.8 | % |  | 64.6 | % |  | 64.5 | % |
| EMEA |  | 8,457 |  |  | 7,945 |  |  | 7,855 |  |  | 64.6 | % |  | 63.9 | % |  | 65.4 | % |
| APJC |  | 4,683 |  |  | 4,726 |  |  | 4,741 |  |  | 59.5 | % |  | 60.3 | % |  | 62.0 | % |
| Segment total |  | 33,479 |  |  | 31,463 |  |  | 30,880 |  |  | 64.5 | % |  | 63.8 | % |  | 64.3 | % |
| Unallocated corporate items (1) |  | (813 | ) |  | (857 | ) |  | (656 | ) |  |  |  |  |  |  |
| Total |  | $ | 32,666 |  |  | $ | 30,606 |  |  | $ | 30,224 |  |  | 62.9 | % |  | 62.0 | % |  | 63.0 | % |

[0000858877-19-000012:mdna:127]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-19-000012:mdna:128]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:mdna:129]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements, partially offset by unfavorable impacts from pricing and product mix. The unfavorable product mix impact was driven by products within the Infrastructure Platforms product category. Our gross margin in this segment also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000012:mdna:130]
Product gross margin in our EMEA segment increased due to productivity improvements, partially offset by negative impacts from pricing and mix.

[0000858877-19-000012:mdna:131]
The APJC segment gross margin percentage decrease was due to negative impacts from pricing, partially offset by productivity improvements and favorable product mix. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-19-000012:mdna:132]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-19-000012:mdna:133]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-19-000012:mdna:134]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-19-000012:mdna:135]
|  |  | Years Ended |  | 2019 vs. 2018 |
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,577 |  |  | $ | 6,332 |  |  | $ | 6,059 |  |  | $ | 245 |  |  | 4 | % |
| Percentage of revenue |  | 12.7 | % |  | 12.8 | % |  | 12.6 | % |  |  |  |  |
| Sales and marketing |  | 9,571 |  |  | 9,242 |  |  | 9,184 |  |  | 329 |  |  | 4 | % |
| Percentage of revenue |  | 18.4 | % |  | 18.7 | % |  | 19.1 | % |  |  |  |  |
| General and administrative |  | 1,827 |  |  | 2,144 |  |  | 1,993 |  |  | (317 | ) |  | (15 | )% |
| Percentage of revenue |  | 3.5 | % |  | 4.3 | % |  | 4.2 | % |  |  |  |  |
| Total |  | $ | 17,975 |  |  | $ | 17,718 |  |  | $ | 17,236 |  |  | $ | 257 |  |  | 1 | % |
| Percentage of revenue |  | 34.6 | % |  | 35.9 | % |  | 35.9 | % |  |  |  |  |

[0000858877-19-000012:mdna:136]
R&D Expenses

[0000858877-19-000012:mdna:137]
R&D expenses increased due to higher headcount-related expenses and, to a lesser extent, higher acquisition-related costs, higher contracted services and higher discretionary spending.

[0000858877-19-000012:mdna:138]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-19-000012:mdna:139]
Sales and Marketing Expenses

[0000858877-19-000012:mdna:140]
Sales and marketing expenses increased due to higher headcount-related expenses, higher discretionary spending and, to a lesser extent, higher contracted services and higher acquisition-related costs, partially offset by lower share-based compensation expense.

[0000858877-19-000012:mdna:141]
G&A Expenses

[0000858877-19-000012:mdna:142]
G&A expenses decreased due to a benefit from the $400 million litigation settlement with Arista Networks and lower contracted services, partially offset by higher discretionary spending and higher headcount-related expenses.

[0000858877-19-000012:mdna:143]
Effect of Foreign Currency

[0000858877-19-000012:mdna:144]
In fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $233 million, or 1.3%, compared with fiscal 2018. In fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $93 million, or 0.5%, compared with fiscal 2017.

[0000858877-19-000012:mdna:145]
43

[0000858877-19-000012:mdna:146]
Amortization of Purchased Intangible Assets

[0000858877-19-000012:mdna:147]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-19-000012:mdna:148]
| Years Ended |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 624 |  |  | $ | 640 |  |  | $ | 556 |  |
| Operating expenses |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 150 |  |  | 221 |  |  | 259 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | 38 |  |
| Total |  | $ | 774 |  |  | $ | 861 |  |  | $ | 853 |  |

[0000858877-19-000012:mdna:149]
The decrease in amortization of purchased intangible assets was due largely to the purchased intangible assets related to the divestiture of SPVSS business on October 28, 2018, partially offset by amortization from our recent acquisitions.

[0000858877-19-000012:mdna:150]
Restructuring and Other Charges

[0000858877-19-000012:mdna:151]
The following table presents the restructuring and other charges (in millions):

[0000858877-19-000012:mdna:152]
| Years Ended |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Restructuring and other charges included in operating expenses |  | $ | 322 |  |  | $ | 358 |  |  | $ | 756 |  |

[0000858877-19-000012:mdna:153]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of $600 million. In connection with this restructuring plan, we incurred charges of $322 million during fiscal 2019, and have incurred cumulative charges of $430 million. We expect this restructuring plan to be substantially completed in the first half of fiscal 2020.

[0000858877-19-000012:mdna:154]
These charges were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas.  As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-19-000012:mdna:155]
Operating Income

[0000858877-19-000012:mdna:156]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-19-000012:mdna:157]
| Years Ended |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Operating income |  | $ | 14,219 |  |  | $ | 12,309 |  |  | $ | 11,973 |  |
| Operating income as a percentage of revenue |  | 27.4 | % |  | 25.0 | % |  | 24.9 | % |

[0000858877-19-000012:mdna:158]
Operating income increased by 16%, and as a percentage of revenue operating income increased by 2.4 percentage points. These increases resulted primarily from: a revenue increase, a gross margin percentage increase, a benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019, and lower restructuring and other charges.

[0000858877-19-000012:mdna:159]
44

[0000858877-19-000012:mdna:160]
Interest and Other Income (Loss), Net

[0000858877-19-000012:mdna:161]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-19-000012:mdna:162]
|  | Years Ended |  | 2019 vs. 2018 |
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |
| Interest income | $ | 1,308 |  |  | $ | 1,508 |  |  | $ | 1,338 |  |  | $ | (200 | ) |
| Interest expense | (859 | ) |  | (943 | ) |  | (861 | ) |  | 84 |  |
| Interest income (expense), net | $ | 449 |  |  | $ | 565 |  |  | $ | 477 |  |  | $ | (116 | ) |

[0000858877-19-000012:mdna:163]
Interest income decreased, driven by a decrease in the average balance of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance, partially offset by the impact of higher effective interest rates.

[0000858877-19-000012:mdna:164]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-19-000012:mdna:165]
|  | Years Ended |  | 2019 vs. 2018 |
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | (13 | ) |  | $ | (242 | ) |  | $ | (42 | ) |  | $ | 229 |  |
| Marketable equity investments | (3 | ) |  | 529 |  |  | (45 | ) |  | (532 | ) |
| Non-marketable equity and other investments | 6 |  |  | 11 |  |  | (46 | ) |  | (5 | ) |
| Net gains (losses) on investments | (10 | ) |  | 298 |  |  | (133 | ) |  | (308 | ) |
| Other gains (losses), net | (87 | ) |  | (133 | ) |  | (30 | ) |  | 46 |  |
| Other income (loss), net | $ | (97 | ) |  | $ | 165 |  |  | $ | (163 | ) |  | $ | (262 | ) |

[0000858877-19-000012:mdna:166]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized losses as a result of market conditions, and the timing of sales of these investments.

[0000858877-19-000012:mdna:167]
The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses.

[0000858877-19-000012:mdna:168]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to lower realized gains, partially offset by higher unrealized gains.

[0000858877-19-000012:mdna:169]
The change in other gains (losses), net was primarily driven by higher donation expense in the prior year.

[0000858877-19-000012:mdna:170]
Provision for Income Taxes

[0000858877-19-000012:mdna:171]
The provision for income taxes resulted in an effective tax rate of 20.2% for fiscal 2019, compared with 99.2% for fiscal 2018. The net 79.0 percentage point decrease in the effective tax rate was primarily due to the $10.4 billion mandatory one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement recorded during fiscal 2018.

[0000858877-19-000012:mdna:172]
As a result of the adoption of the new accounting standard on share-based compensation in fiscal 2018, our effective tax rate will increase or decrease based upon the tax effect of the difference between the share-based compensation expenses and the benefits taken on the company's tax returns. We recognize excess tax benefits on a discrete basis and therefore anticipate the effective tax rate to vary from quarter to quarter depending on our share price in each period.

[0000858877-19-000012:mdna:173]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 17 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:174]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-19-000012:mdna:175]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-19-000012:mdna:176]
Balance Sheet and Cash Flows

[0000858877-19-000012:mdna:177]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-19-000012:mdna:178]
|  | July 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 11,750 |  |  | $ | 8,934 |  |  | $ | 2,816 |  |
| Available-for-sale debt investments | 21,660 |  |  | 37,009 |  |  | (15,349 | ) |
| Marketable equity securities | 3 |  |  | 605 |  |  | (602 | ) |
| Total | $ | 33,413 |  |  | $ | 46,548 |  |  | $ | (13,135 | ) |

[0000858877-19-000012:mdna:179]
The net decrease in cash and cash equivalents and investments from fiscal 2018 to fiscal 2019 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $20.7 billion under the stock repurchase program and cash dividends of $6.0 billion, net cash paid for acquisitions and divestitures of $2.2 billion, a net decrease in debt of $1.1 billion, and capital expenditures of $0.9 billion.  These uses of cash were partially offset by cash provided by operating activities of $15.8 billion and the timing of settlements of investments and other of $2.0 billion.

[0000858877-19-000012:mdna:180]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia Communications, Inc. (“Acacia”) for a purchase consideration of approximately $2.6 billion in cash. Additionally, $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries, $6.0 billion of long-term debt and $4.2 billion of commercial paper notes outstanding at July 27, 2019, are payable within the next 12 months from the balance sheet date. See further discussion of liquidity and future payments under “Contractual Obligations” and “Liquidity and Capital Resource Requirements” below.

[0000858877-19-000012:mdna:181]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-19-000012:mdna:182]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-19-000012:mdna:183]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-19-000012:mdna:184]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Net cash provided by operating activities | $ | 15,831 |  |  | $ | 13,666 |  |  | $ | 13,876 |  |
| Acquisition of property and equipment | (909 | ) |  | (834 | ) |  | (964 | ) |
| Free cash flow | $ | 14,922 |  |  | $ | 12,832 |  |  | $ | 12,912 |  |

[0000858877-19-000012:mdna:185]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-19-000012:mdna:186]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not

[0000858877-19-000012:mdna:187]
46

[0000858877-19-000012:mdna:188]
represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-19-000012:mdna:189]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-19-000012:mdna:190]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 27, 2019 |  | $ | 1.36 |  |  | $ | 5,979 |  |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |  | $ | 26,556 |  |
| July 28, 2018 |  | $ | 1.24 |  |  | $ | 5,968 |  |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |  | $ | 23,629 |  |
| July 29, 2017 |  | $ | 1.10 |  |  | $ | 5,511 |  |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |  | $ | 9,217 |  |

[0000858877-19-000012:mdna:191]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-19-000012:mdna:192]
On February 13, 2019, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $13.5 billion, with no termination date.

[0000858877-19-000012:mdna:193]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-19-000012:mdna:194]
|  | July 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,491 |  |  | $ | 5,554 |  |  | $ | (63 | ) |

[0000858877-19-000012:mdna:195]
Our accounts receivable net, as of July 27, 2019 decreased by approximately 1% compared with the end of fiscal 2018.

[0000858877-19-000012:mdna:196]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-19-000012:mdna:197]
|  | July 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Inventories | $ | 1,383 |  |  | $ | 1,846 |  |  | $ | (463 | ) |

[0000858877-19-000012:mdna:198]
Inventory as of July 27, 2019 decreased by 25% from our inventory balance at the end of fiscal 2018. The decrease in inventory was due primarily to lower deferred cost of sales related to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019.

[0000858877-19-000012:mdna:199]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-19-000012:mdna:200]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-19-000012:mdna:201]
The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-19-000012:mdna:202]
| Commitments by Period | July 27, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 4,239 |  |  | $ | 5,407 |  |
| 1 to 3 years | 728 |  |  | 710 |  |
| 3 to 5 years | — |  |  | 360 |  |
| Total | $ | 4,967 |  |  | $ | 6,477 |  |

[0000858877-19-000012:mdna:203]
Purchase commitments with contract manufacturers and suppliers decreased by approximately 23% compared to the end of fiscal 2018.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 24% compared with the end of fiscal 2018.

[0000858877-19-000012:mdna:204]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-19-000012:mdna:205]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-19-000012:mdna:206]
|  | July 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,326 |  |  | $ | 2,576 |  |  | $ | (250 | ) |
| Loan receivables, net | 5,367 |  |  | 4,939 |  |  | 428 |  |
| Financed service contracts, net | 2,360 |  |  | 2,316 |  |  | 44 |  |
| Total, net | $ | 10,053 |  |  | $ | 9,831 |  |  | $ | 222 |  |

[0000858877-19-000012:mdna:207]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables increased by 2%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-19-000012:mdna:208]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-19-000012:mdna:209]
The volume of channel partner financing was $29.6 billion, $28.2 billion, and $27.0 billion in fiscal 2019, 2018, and 2017, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.0 billion as of July 27, 2019 and July 28, 2018, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 27, 2019, the total maximum potential future payments related to these guarantees was approximately $218 million, of which approximately $77 million was recorded as deferred revenue.

[0000858877-19-000012:mdna:210]
Borrowings

[0000858877-19-000012:mdna:211]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-19-000012:mdna:212]
|  | Maturity Date |  | July 27, 2019 |  | July 28, 2018 |  |
| Senior notes: |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | — |  |  | $ | 500 |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | — |  |  | 2,000 |  |  |
| 1.60% | February 28, 2019 |  | — |  |  | 1,000 |  |  |
| 2.125% | March 1, 2019 |  | — |  |  | 1,750 |  |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |  |
| Total |  |  | $ | 20,500 |  |  | $ | 25,750 |  |  |

[0000858877-19-000012:mdna:213]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of July 27, 2019.

[0000858877-19-000012:mdna:214]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $4.2 billion in commercial paper notes outstanding as of July 27, 2019 and no commercial paper notes outstanding as of July 28, 2018.

[0000858877-19-000012:mdna:215]
Credit Facility  On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of July 27, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-19-000012:mdna:216]
49

[0000858877-19-000012:mdna:217]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-19-000012:mdna:218]
|  | July 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Service | $ | 11,709 |  |  | $ | 11,431 |  |  | $ | 278 |  |
| Product | 6,758 |  |  | 8,254 |  |  | (1,496 | ) |
| Total | $ | 18,467 |  |  | $ | 19,685 |  |  | $ | (1,218 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,668 |  |  | $ | 11,490 |  |  | $ | (822 | ) |
| Noncurrent | 7,799 |  |  | 8,195 |  |  | (396 | ) |
| Total | $ | 18,467 |  |  | $ | 19,685 |  |  | $ | (1,218 | ) |

[0000858877-19-000012:mdna:219]
Deferred revenue decreased primarily due to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019. Of the total deferred revenue decrease related to the adoption of ASC 606 of $2.8 billion, $2.6 billion relates to deferred product revenue and $0.2 billion relates to deferred service revenue. Of the adjustment to deferred product revenue, $1.3 billion related to our recurring software and subscription offers, $0.6 billion related to two-tier distribution, and the remainder related to non-recurring software and other adjustments. The decrease related to the adoption of ASC 606 was partially offset by an increase in product deferred revenue during the fiscal year. The increase in deferred service revenue was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-19-000012:mdna:220]
Contractual Obligations

[0000858877-19-000012:mdna:221]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 27, 2019 (in millions):

[0000858877-19-000012:mdna:222]
|  | PAYMENTS DUE BY PERIOD |
| July 27, 2019 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,179 |  |  | $ | 441 |  |  | $ | 494 |  |  | $ | 190 |  |  | $ | 54 |  |
| Purchase commitments with contract manufacturers and suppliers | 4,967 |  |  | 4,239 |  |  | 728 |  |  | — |  |  | — |  |
| Other purchase obligations | 1,490 |  |  | 676 |  |  | 622 |  |  | 98 |  |  | 94 |  |
| Senior notes | 20,500 |  |  | 6,000 |  |  | 5,500 |  |  | 2,250 |  |  | 6,750 |  |
| Transition tax payable | 8,343 |  |  | 749 |  |  | 1,498 |  |  | 2,113 |  |  | 3,983 |  |
| Other long-term liabilities | 1,214 |  |  | — |  |  | 220 |  |  | 136 |  |  | 858 |  |
| Total by period | $ | 37,693 |  |  | $ | 12,105 |  |  | $ | 9,062 |  |  | $ | 4,787 |  |  | $ | 11,739 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 1,428 |  |  |  |  |  |  |  |  |  |
| Total | $ | 39,121 |  |  |  |  |  |  |  |  |  |

[0000858877-19-000012:mdna:223]
Operating Leases  For more information on our operating leases, see Note 13 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:224]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.” As of July 27, 2019, the liability for these purchase commitments was $129 million and is recorded in other current liabilities and is not included in the preceding table.

[0000858877-19-000012:mdna:225]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-19-000012:mdna:226]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 11 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:227]
Transition Tax Payable Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings of foreign subsidiaries as a result of the Tax Act. See Note 17 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:228]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1.3 billion and deferred tax liabilities of $95 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 17 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:229]
Other Commitments

[0000858877-19-000012:mdna:230]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 13 to the Consolidated Financial Statements.

[0000858877-19-000012:mdna:231]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $326 million as of July 27, 2019, compared with $223 million as of July 28, 2018.

[0000858877-19-000012:mdna:232]
Off-Balance Sheet Arrangements

[0000858877-19-000012:mdna:233]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of July 27, 2019 there were no material unconsolidated variable interest entities.

[0000858877-19-000012:mdna:234]
On an ongoing basis, we reassess our non-marketable equity and other investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-19-000012:mdna:235]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-19-000012:mdna:236]
Liquidity and Capital Resource Requirements

[0000858877-19-000012:mdna:237]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
